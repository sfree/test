---
title: Risk Assessment
subtitle: An expert assessment of the risks in your system
type: activity
category: risk
roles: dev, qa
layout: article
status: draft
---

[![Risk Assessment](../images/risk/risk-assessment.png)](risk/risk-assessment.html)

Risk assessments are performed as a service by Group IT Risk to identify and evaluate risks in existing systems or solutions that are being developed. Similarly to penetration testing, the findings discovered during the course of a risk assessment need to be acknowledged by the business, whereby mitigation action plans, due dates and respective action owners need to be defined.

Objectives
----------

- To understand the current threats to the Bank or the solution.
- Identify all security risks around information technology solutions;
- Define findings basing on Operational Risk Framework (ORF) in version 2 including a specific description and evaluation for each identified risk for better understanding of the threats;
- Assure the findings are acknowledged by a respective business stream;
- Define risk mitigation plan concerning each identified potential risk including timeframes and due dates;
- Assure implementation of the agreed risk mitigation plan. 

People
------

- The delivery manager/solution owner/project manager, who typically initiates the exercise by contacting IT Risk;
- A risk analyst, who performs the analysis and prepares a report and recommendations;
- Technical leaders to provide specific technical description to the risk analyst.
- Operational risk managers/stream risk managers who assist the delivery manager/solution owner/project manager in the definition of mitigation plan. In some cases, they can also be the initiators of a risk assessment exercise.

Process
-------

The purpose of a risk assessment is usually driven by a development of a new application or solution that is going to be used within the bank as well as re-assessing already processed solutions after the risk mitigation plan has been implemented (residual risk assessment). It is of high importance to assure the existence of technical documentation regarding a particular solution together with technical contact persons that can provide details on a request.

In most cases the risk assessment service is requested by the delivery manager or the solution owner of the project. Nevertheless a request can also be provided by a respective ORM in case of existing systems that have been already implemented within the bank without being the subject of a risk assessment exercise. 
The Risk Assessment looks at three main factors before determining the Risk, these are Threat, Impact and Likelihood. 

### Threat

The Threat is the source of a scenario or event that has the intention to cause an undesirable outcome. A Threat could be but not limited to Human Error, a Computer Hacker, a System Failure or a Natural Disaster.

### Impact

The Impact is a measurement to how that particular Threat will affect a Company or an Environment. Within the ORF 2 Framework, a number of Impact levels are described, these are Impact Levels associated with Security and Availability, Regulatory Impacts and also Reputational Impacts. Confidentiality including Data Classification, Integrity and Availability also has Impact scales according to ORF2. These are used to determine the Impact of an undesirable event. 

### Likelihood

The Likelihood is simply the Likelihood of the undesirable event occurring. A more frequent event will increase a particular risk merely due to it happening more often. The ORF 2 Framework provides a scale based on how a particular event will take place or within the Information Security area, how likely it would be for an attack to succeed based on the Attackers motivation and skill level.

### Risk Rating

The Risk Rating is made from a calculation of Impact and Likelihood. This simple calculation provides a score that can be measured against the ORF2 Risk Matrix. This is important as it defines how the overall risk should be scored. Changes in Impact and Likelihood through mitigating factors will reduce the risk.

The risk assessment service is a complex exercise supporting the risk management process. 
 
A risk assessment exercise follows the steps hereafter:
- Gathering data from the delivery manager/solution owner/project manager or from technical contacts.
- Identifying threats and vulnerabilities applicable.
- Identifying the controls in place.
- Identifying the risks faced by the application.
- Writing the report, including comments from peer reviews.
- Defining the mitigation action plans.

Outputs
-------

The main outputs of the risk assessment are:

- A detailed report sent by e-mail to the stakeholders, including the scope of the assessment, a technical description on the system reviewed, the list of issues identified together with their ratings and mitigation recommendations;
- A discussion of next steps between IT Risk and the stakeholders regarding addressing or accepting the risks;
- Agreed risk mitigation plan and its implementation timeframes and due dates. 

Managing the Risk
-----------------

Once the risks have been understood by all parties, IT Risk requires the Project to respond to each of the risks. Within the response, the following will always be required:

- A Risk Owner for the Risk
- A Business Response to the Risk
- An Action Plan to Treat the Risk through:
  - Mitigation
  - Acceptance
  - Termination (Removing the issue)
- An Action Owner
- A Target date to complete the action.

Risk Acceptance has to be accepted by someone at Executive Director level. If the risk is rated as High or Critical, then a more complex process will need to take place which may involve an ORI item and also acceptance from a manager higher than Executive Director.