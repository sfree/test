---
title: Segregation of Duties
subtitle: Ensuring the integrity of software released by UBS
layout: article
category: risk
type: control
roles: dev, qa, dm
status: unstarted
---

Describe what segregation of duties means, why it is important, and how it can be controlled, with reference to example solutions and tools in UBS.