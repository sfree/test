---
title: IT Security & Risk Management
subtitle: Manage security and risk pro-actively in software development
category: risk
layout: category
---

Managing security and risk is of utmost important for UBS and our clients. We apply industry best practices, including measures recommended by [OWASP](https://www.owasp.org), to ensure the security of the software that we develop. There is a centralised team named [IT Risk](http://goto/itrisk) to assist with risk management processes during the software development process. [IT Risk](http://goto/itrisk) prescribe a three-phase process that is summarised in this section of the dev-guide.

[![Risk Opinion]({{site.img}}risk/security-assurance.png)]({{site.url}}risk/security-assurance.html)

[Risk Opinion]({{site.url}}risk/security-assurance.html)
-------------------------------------------------------

The Risk Opinion process helps teams identify potential areas of risk in their projects. Unlike other risk management services, such as Risk Assessment and Penteration Testing, the findings reported from a Risk Opinion exercise are not formally tracked. However, a Risk Opinion exercise may result in a decision to proceed to a Risk Assessment if uncertainties or security concerns are uncovered.

[Find out more about the Risk Opinion]({{site.url}}risk/security-assurance.html)

---

[![Risk Assessment]({{site.img}}risk/risk-assessment.png)]({{site.url}}risk/risk-assessment.html)

[Risk Assessment]({{site.url}}risk/risk-assessment.html)
--------------------------------------------------------

Risk assessments are performed as a service by Group IT Risk to identify and evaluate risks in existing systems or solutions that are being developed. Similarly to penetration testing, the findings discovered during the course of a risk assessment need to be acknowledged by the business, whereby mitigation action plans, due dates and respective action owners need to be defined.

[Find out more about the Security Assurance]({{site.url}}risk/risk-assessment.html)

---

[![Penetration Testing]({{site.img}}risk/pen-testing.png)]({{site.url}}risk/pen-testing.html)

[Penetration Testing]({{site.url}}risk/pen-testing.html)
--------------------------------------------------------

Penetration Testing is a form of testing carried out against a running system that attempts to gain unauthorised access and/or locate other vulnerabilities. The purpose is to assess whether software contains vulnerabilities that may allow exploitation of the system. These vulnerabilities may be coding errors, architectural design, the use of vulnerable components or standards and business logic errors, where the system functions as designed but the business design has flaws within it.

[Find out more about Penetration Testing]({{site.url}}risk/pen-testing.html)

---
