---
title: Penetration Testing
subtitle: Identify insecurities in running software
type: activity
category: risk
roles: dev, qa
links:
  - title: US Government Guide 
    url: https://buildsecurityin.us-cert.gov/articles/best-practices/security-testing/adapting-penetration-testing-software-development-purposes
  - title: UK Government Guide
    url: https://www.gov.uk/service-manual/operations/penetration-testing.html
  - title: Wikipedia
    url: http://en.wikipedia.org/wiki/Penetration_test
  - title: Attack Trees
    url: https://www.schneier.com/paper-attacktrees-ddj-ft.html
layout: article
status: unstarted
---

[![Penetration Testing](../images/risk/pen-testing.png)](risk/pen-testing.html)

Penetration-testing is the attempt to gain access and/or locate vulnerabilities within a running system or component.
 
Objectives
----------

The purpose of the test is to assess whether the software contains vulnerabilities that may allow exploitation of the system. These vulnerabilities may be coding errors, architectural design, the use of vulnerable components or standards and business logic errors, where the system functions as designed but the business design has flaws within it. Pen-testing can also encompass human interaction or physical security. In general, however, all vulnerabilities are the product of unwarranted assumptions about a particular state, leading to a mistaken response.

Process
-------

Pen-testing starts from an examination of the attack surface and trust boundaries of a product, that is the parts of the system accessible to users and maintainers and the methods in place to deal with unwelcome data. In web-based systems this includes the servers running the code, the ports open on the servers and the protocols running on those ports. These need to be catalogued and particular attention paid to the ability of the code to withstand unexpected inputs. On client software the greatest dangers are information leakage and insecure lockout systems. The assessment of the above issues will cover a basic vulnerability scan of the system, though in depth pen-testing can involve several days work on a single component or the leveraging of several components to gain access to a system.
 
To pass pen-tests successfully security should be considered during development in the architectural and design phases: one useful method is the construction of [attack trees](https://www.schneier.com/paper-attacktrees-ddj-ft.html). Attack trees are created by imagining how an attacker - external or malicious insider - could subvert the design to gain access to the data within the system. During implementation the material constructed by the security design phase must be considered as part of the code review.
 
Penetration testing itself is usually carried out towards the end of the software development lifecycle on release candidate or production software. Testing at this phase is most likely to elucidate the  vulnerabilities that may only be found when all components have been integrated into the finished product. However, pen-testing can also be part of agile or iterative development with regular tests carried out during each internal release of the software. At this stage the tests should be as automated as possible to ensure consistency between releases.

Outputs
-------

The output of a pen-test is typically a report listing the vulnerabilities discovered during the test. These are classified in terms of their severity. The report should also make recommendations for how to remediate these risks.