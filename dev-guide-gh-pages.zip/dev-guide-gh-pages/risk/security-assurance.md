---
title: Risk Opinion
subtitle: Identify potential risk early
type: activity
category: risk
image: risk/security-assurance.png
roles: dev, qa
standards:
  - title: Operational Risk Framework
    url: http://goto/orf
  - title: Secure Coding Guidelines
    url: https://teams.ib.cnet.ubs.net/sites/appsec/SiteCollectionDocuments/guidelines.aspx
links:
  - title: Open Web Application Security Project
    url: https://www.owasp.org
  - title: Top 10 Risks
    url: https://www.owasp.org/index.php/Category:OWASP_Top_Ten_Project
layout: article
status: unstarted
---

Risk Opinion is a service provided by the IT Risk department to help teams identify potential areas of risk in their projects. Unlike other services, such as [Risk Assessment](risk-assessment.html) and [Penteration Testing](penetration-testing.html), the findings reported from a Risk Opinion exercise are not formally tracked. However, a Risk Opinion exercise may result in a decision to proceed to a [Risk Assessment](risk-assessment.html).

Objectives
----------

- Identify specific security threats for a project
- Explain the "attack vectors", which are the means by which a malicious person could exploit a vulnerability
- Highlight any areas of potential risk that should be considered
- Highlight any security weaknesses that may be present in such a system
- Recommend security controls that should be applied to mitigate risks and remove weaknesses

People
------

- The [delivery manager](../people/delivery-managers.html), who typically initiates the exercise by contacting IT Risk
- A risk analyst, who performs the analysis and prepares a report and recommendations
- [Developers](../people/developers.html) to provide technical information to the risk analyst

Note that a risk analyst has a different responsibility to a member of the security testing services team or the vulnerability management team. A risk analyst does not assess the validity of controls in place to reduce risk. Their job is simply to "look under the hood".

Process
-------

It is best for Risk Opinion to take place early in the lifecycle, during the [discovery](../process/discovery-phase.html) or [alpha](../process/alpha-phase.html) phases, to make sure security concerns are taken into consideration when planning. Risk Opinion must take place prior to a [beta](../process/beta-phase.html) release to real users and may take place on multiple occassions when new components or significant changes are underway.

In most cases, Risk Opinion is initiated by the delivery manager, who should be aware of his need for security advice. However, in some cases, Risk Advice is mandated by the IT Risk department in response to the discovery of a software component or process that has not undergone any previous risk review.

The process of Risk Opinion is based on the [Open Web Application Security Project (OWASP)](https://www.owasp.org) methodology used to derive the [Top 10 risks](https://www.owasp.org/index.php/Category:OWASP_Top_Ten_Project). This is shown in the figure below with a purple line constituting a potential risk, connecting a threat agent to the technical and business impact of an exploitation.

![An attack](../images/risk/attack.png)

During Risk Opinion, the risk analyst will attempt to discover, rank and classify vulnerabilities by following these steps:

- Gather information about the "threat agents" involved, understanding what attacks they may use to try and exploit the system.
- Consider the exploitation attempts that could be made to see whe if controls could be bypassed or are unlikely to be present.
- Estimate the severity of all relevant risks based on the use cases provided by the development team. Risks are quantified in terms of likelihood and impact according to the [standard risk framework](http://goto/orf).

Outputs
-------

The outputs of Risk Opinion are:

- A report sent by e-mail to the stakeholders
- A discussion of next steps between IT Risk and the stakeholders regarding addressing or accepting the risks
- An decision from IT Risk on whether it will be necesary to proceed to a formal [Risk Assessment](rish-assessment.html) exercise

Proceeding to a [Risk Assessment](risk-assessment.html) can help all parties better understand any specific risks, so they can be remediated early, removing the "surprise factor" towards the end of a projects where potential blockers can arise from those risks.
