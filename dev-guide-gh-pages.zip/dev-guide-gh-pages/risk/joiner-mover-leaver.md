---
title: Joiner-Mover-Leaver
subtitle: Keeping access rights in sync
category: control
type: article
roles: dev, qa, dm
layout: article
status: unstarted
---
