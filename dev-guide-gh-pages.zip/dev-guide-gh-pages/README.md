dev-guide
=========

**DEPRECATED: See OpenUbs/flow instead.**

A guide to help teams develop great software using an agile process, modern tools and a global platform.

The guide is published as a website at: 

- http://goto/devguide

The content of the guide lives on the [gh-pages](https://github.ldn.swissbank.com/OpenUBS/dev-guide/tree/gh-pages) branch.

This guide was partly inspired by the [Government Service Design Manual](https://www.gov.uk/service-manual).

How to Contribute
-----------------

The guide is open for contributions, so you are encouraged to:

1. Raise an [issue](https://github.ldn.swissbank.com/OpenUBS/dev-guide/issues) 
2. Pick up an [issue](https://github.ldn.swissbank.com/OpenUBS/dev-guide/issues) 
3. Fork the repository and send a [pull-request](https://github.ldn.swissbank.com/OpenUBS/dev-guide/pulls)

The content of the guide is authored using [Markdown](http://en.wikipedia.org/wiki/Markdown) and transformed into a website automatically using [Jekyll](http://jekyllrb.com/), which is built into the [Pages](http://pages.github.com/) feature of GitHub Enterprise. Thus the published content lives on the [gh-pages](https://github.ldn.swissbank.com/OpenUBS/dev-guide/tree/gh-pages) branch.

Page Metadata
-------------

Metadata for each page of the guide is expressed using [YAML front-matter](http://jekyllrb.com/docs/frontmatter/). This metadata is used as input to the HTML [layout templates](https://github.ldn.swissbank.com/OpenUBS/dev-guide/tree/gh-pages/_layouts) and [includes](https://github.ldn.swissbank.com/OpenUBS/dev-guide/tree/gh-pages/_includes) to build dynamic content into the guide. For example, you can see how standards, activities and tools are linked into the role pages by looking at [sidebar-role.html](https://github.ldn.swissbank.com/OpenUBS/dev-guide/blob/gh-pages/_includes/sidebar-role.html).

| Key | Expected value |
|:----|:-----|
| category | The parent category for the page, used for building the breadcrumb trail. The main categories are `people`, `process`, `tools` and `platform` |
| duration | This is used for activity pages to specify the typical duration of an activity. It is optional. Example: `2 - 4 weeks` |
| examples | A list of title+url pairs linking to internal examples of the output from an activity or phase |
| layout | The layout template to use for the page which should be `category`, `article` or `role` in most cases |
| links | A list of title+url pairs linking to related content external to UBS |
| roles | A comma separated list of the roles that a page is applicable to containing `ux` (user-experience designer), `dev` (developer), `qa` (qwuality analyst), `dm` (delivery manager), `pm` (product manager) |
| subtitle | A subtitle in one short sentence |
| status | The status of a page which should be `unstarted`, `in-progress`, `for-review` or `done` |
| title | A concise title for the page |
| type | The type of content which should one of `activity`, `standard`, `article`, `tool`, `control` |

Here is a template of the YAML front-matter to paste into a new Markdown file:

```
---
title: Big Title
subtitle: A nice concise subtitle
category: people|process|tools|platform
type: article|activity|standard|tool
roles: ux, dev, qa, dm, pm
links:
  - title: Some link title
    url: http://www.google.co.uk
layout: article|category|role
status: unstarted|in-progress|for-review|done
---
```
