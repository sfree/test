---
title: To Do
subtitle: Let's get this done collaboratively
type: article
roles: ux,dev, qa, dm, pm
layout: category
status: in-progress
---

This delivery of this dev-guide is managed using GitHub milestones and issues:

- [View the Milestones](https://github.ldn.swissbank.com/OpenUBS/dev-guide/issues/milestones)
- [View the Issues](https://github.ldn.swissbank.com/OpenUBS/dev-guide/issues?milestone=&page=1&state=open)

You can help to finish the dev guide by picking up issues and sending pull-requests. See the [README](https://github.ldn.swissbank.com/OpenUBS/dev-guide) for documentation.

---

| Status | Pages |
|:----|:------|
| unstarted | {% for p in site.pages %}{% if p.status == "unstarted" %}[{{ p.title }}](http://goto/devguide{{ p.url }}), {% endif %}{% endfor %} |
| in progress | {% for p in site.pages %}{% if p.status == "in-progress" %}[{{ p.title }}](http://goto/devguide{{ p.url }}), {% endif %}{% endfor %} |
| for review | {% for p in site.pages %}{% if p.status == "for-review" %}[{{ p.title }}](http://goto/devguide{{ p.url }}), {% endif %}{% endfor %} |
| done | {% for p in site.pages %}{% if p.status == "done" %}[{{ p.title }}](http://goto/devguide{{ p.url }}), {% endif %}{% endfor %} |

---