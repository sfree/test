---
title: Tools
subtitle: For collaborative development
category: tools
layout: category
---

A set of tools are provided to support the full software development lifecycle, from defining requirements to automated deployment.

[![Source]({{site.img}}tools/source.png)](http://goto/devops/source)

[Source](http://goto/devops/source)
-----------------------------------

A digital asset management too for UX designers to publish, discover and discuss design specifications with their product managers and development teams.

[Find out more about Source](http://goto/devops/source)

---

<br>

[![GitHub]({{site.img}}tools/github.png)](http://goto/devops/git)

[GitHub](http://goto/devops/git)
--------------------------------

Agile development depends on the good source code management and close collaboration amongst developers. GitHub has revolutionised the open-source community with their social coding platform that streamlines the exchange of code and provides clear visibility of relevant development activity. Now developers in UBS can benefit from the same technology, to collaborate with teammates and share code across organisational boundaries.

[Find out more about GitHub](http://goto/devops/git)

---

[![TeamCity]({{site.img}}tools/teamcity.png)](http://goto/devops/teamcity)

[TeamCity](http://goto/devops/teamcity)
---------------------------------------

The sooner bugs are identified the easier they are to fix. TeamCity Enteprise is a continuous integration service that can build and test your software automatically whenever the source code in GitHub changes, then package successful builds and publish them into Nexus, ready for deployment. The service manages a pool of build agents and automatically distributes work. It can target Linux, Windows and Mac operating systems.

[Find out more about TeamCity](http://goto/devops/teamcity)

---

[![Nexus]({{site.img}}tools/nexus.png)](http://goto/devops/nexus)

[Nexus](http://goto/devops/nexus)
---------------------------------

Software systems are typically composed from many separate artifacts, some of which are developed in-house, while others are commercial or open-source. There can be complex dependencies and version compatibility rules amongst these artifacts. Nexus Professional is an artifact management service that stores and catalogues artifacts in a structure way, so they can be analysed and provided to development and deployment tooling in a controlled way.

[Find out more about Nexus](http://goto/devops/nexus)

---

[![Swift]({{site.img}}tools/swift.png)](http://goto/devops/swift)

[Swift](http://goto/devops/swift)
---------------------------------

Agile teams know that software should be developed and released in short and frequent iterations to deliver value quickly and reduce risk. Swift is designed to achieve faster and safer releases, by automating repetitive, error-prone manual processes and providing clear visibility of deployment activity across environments. Swift provides a user-friendly facade onto a variety of tools involved in the release definition and deployment processes.

[Find out more about Swift](http://goto/devops/swift)

---
