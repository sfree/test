---
title: Pre-Planning  
subtitle: Understanding what is possible in the next iteration
category: activities
duration: 30 minutes
image: process.png
type: activity
roles: ux, dev, qa, dm, pm
layout: article
status: done
---

{:.intro} One of the key aspects of agile development is to enable development teams to easily change priorties so they are always delivering the features with the highest business value. To help with that a pre-planning meeting takes place before the beginning of each iteration.

Objectives
----------

The objective of the pre-planning meeting is to establish how much and what can done in the next iteration.


Team
----

This meeting is usually conducted by the business lead which with the help of the development lead. Although some teams choose to have more developers present, the pre-planning process should be very straighforward and rather quick, so the smaller the audience the better.

Inputs
------

In order to establish what should be done in the next iteration we usually find the following set of materials to kick-off the meeting:
- On-going stories from the previous iteration.
- Prioritized story backlog (where each story has already been weighted in story points).
- Knowlegde of the team's capacity, e.g., how many story points does the team deliver on average per iteration.

Process
------

The Dev lead can start the meeting by explaining if there is any on-going work that needs to be allocated in this iteration. If this is the case, teams shouldn't be worried, as carry over work is frequent, and capacity is adjusted so next time less work is assigned to the iteration. Nevertheless teams should be self-critical in understanding how productivity can be improved in order to delivery more and better software.

Usually the business lead will be happy to continue with on-going work and deduct that from the available capacity. From this point on, the pre-planning meeting is just a shopping budget exercise from the business. "I really want to buy all the items in the shop, but for the next iteration I can only spend X, let me see where my 'money' is better invested".

When this process is over, we'll have the next iteration planned with a realistic scope of what can be achieved. If the team finished the iteration before time, it can always pick up the next high priority stories from the backlog. If the team is unable to finish all the stories in the current iteration, then there will be carry-over work to discuss in the next pre-planning meeting.

Technical Debt and Defects
------

Dev leads are encouraged to reserve a percentage of the capacity to on-going defect fixing and technical debt tackling. This is a way to try to achieve fluent story delivery, since it avoids iterations for emergency refactoring or iterations which the scope if full of regression defects.



