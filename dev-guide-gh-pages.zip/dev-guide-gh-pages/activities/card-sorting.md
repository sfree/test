---
title: Card Sorting
subtitle: 
category: process
type: activity
roles: ux
links:
examples:
layout: article
status: in-progress
---

Card sorting is a common UX exercise that is carried out in workshops to figure out logical collections of information. This technique is particularly useful in defining a navigational structure of a system.