---
title: Setup and Teardown
subtitle: Starting and ending a delivery
image: process.png
category: activity
type: activity
roles: dev, qa, dm, pm
layout: article
status: in-progress
---

It is the responsibility of the delivery manager to run the team for the full project life cycle. You are responsible for the delivery of the project and ensuring it adheres to the [departmental policies (PIP)](http://confluence.swissbank.com/display/psdev/PIP+Release+1.0.0). This includes:

Project Creation
-----
- Creating the team DL/Chat in line with the [naming standards](http://confluence.swissbank.com/display/psdev/Naming) - or reuse an existing one
- Make sure the [delivery page](https://github.ldn.swissbank.com/pages/PS-Dev/org/#Deliverables) is up to date wtih Team, DL and Chat details.
 - The underlying YAML files is [here](https://github.ldn.swissbank.com/PS-Dev/org/blob/gh-pages/data/deliverables.yaml) and you will need to fork the project

Project Closure
-----
Post project delivery there are a few tasks that must be completed.

- Ensure all [documentation](http://confluence.swissbank.com/display/psdev/Documentation) is up to date and in line with policy
- Close down the chat channel
- Remove all members of the DL and replace with the support DL (DL-PSDev-Support)
- Remove the section from the [delivery page](https://github.ldn.swissbank.com/pages/PS-Dev/org/#Deliverables)
