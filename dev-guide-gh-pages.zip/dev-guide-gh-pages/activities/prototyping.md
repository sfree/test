---
title: Prototyping
subtitle: 
category: process
type: activity
roles: ux
links:
examples:
layout: article
status: in-progress
---

Prototypes take the wireframes one step further by introducing interactivity to them. The actual fidelity of both wireframes and prototypes vary considerably from practitioner to practitioner and from the actual objective of the exercise.
