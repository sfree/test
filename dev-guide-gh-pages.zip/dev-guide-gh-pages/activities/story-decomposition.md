---
title: Story Decomposition
subtitle: Understanding what needs to be done
category: activities
type: activity
roles: ux, dev, qa, dm, pm
layout: article
status: unstarted
---