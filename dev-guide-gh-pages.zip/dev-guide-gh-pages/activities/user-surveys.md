---
title: User Surveys
subtitle: 
category: process
type: activity
roles: ux, pm
links:
layout: article
status: in-progress
---

A User Survey involves interviewing existing and potential users of the system to gain insight into what would be the most effective design. Because the user’s experience is subjective, the best way to directly obtain information is by studying and interacting with users.