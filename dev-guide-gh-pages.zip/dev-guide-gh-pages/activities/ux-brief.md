---
title: UX Brief
subtitle: Define the scope for a discrete UX deliverable
category: process
type: activity
roles: pm, ux, dev
links:
  - title: UX Brief Template
    url: http://goto/devguide/assets/ux-brief-template.pdf
layout: article
status: in-progress
---

The initial requirements brief is created by the Product Manager based on a standard template. The template includes a standardised set of questions, which allows the PM to pre-emptively gather appropriate information before a new project or task is started. Once the brief has been created it should be circulated amongst the UX practitioners as well as the Dev Leads so that any queries etc. can be dealt with and both teams can do their initial research before attending the following workshop.
