---
title: User Flows
subtitle: 
category: process
type: activity
roles: ux
links:
examples:
layout: article
status: in-progress
---

A User Flow illustrates how users should move through a system in the form of a flow diagram. These are again a very popular deliverable, especially at the early stages in a project where the overall user journey is still being considered.