---
title: Wireframing
subtitle: 
category: process
type: activity
roles: ux
links:
  - title: Illustrator Stencils
    url: 
  - title: InDesign Stencils
    url: 
  - title: Keynote Stencils
    url: 
examples:
layout: article
status: in-progress
---

Wireframes are in essence blueprints for user interfaces that describe in detail how a particular interface should work and how various UI elements should be positioned on the screen. This is perhaps one of the most commonly used UX deliverables. The fidelity of wireframes can vary considerably from practitioner to practitioner, ranging from pencil sketches to meticulously produced documents. The former are prefered during as part of a lean user-experience design process.

- Image of sketched wireframe
- Image of high-fidelity wireframe