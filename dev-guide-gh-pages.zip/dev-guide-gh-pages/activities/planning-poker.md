---
title: Planning Poker
subtitle: Estimating the size of work collaboratively
category: activities
type: activity
roles: ux, dev, qa, dm, pm
layout: article
duration: 5-10m per item
status: in-progress
image: people.png
tools:  
  - title: Planning Deck
    url: http://www.tekool.net/blogfiles/printable-agile-planning-poker/agile_planning_poker_front.pdf
  - title: iOS Planning Poker
    url: https://itunes.apple.com/en/app/centare-planning-poker/id490139619?mt=8
  - title: Android Planning Poker
    url: https://play.google.com/store/apps/details?id=com.pxr.planningpoker&hl=en
  - title: Lync Whiteboard 
    url: http://office.microsoft.com/en-gb/communicator-help/collaborate-on-a-whiteboard-HA102186821.aspx
---

{:.intro}
Planning poker is an activity that allows the whole team to come up with a high level estimate that the business can use to make backlog prioritization.

Team
------

The whole team, from UX to QA, should be involved in this meeting. Don't worry that people with different skills with under/over weight a given feature. With time the team will improve its concision. This also promotes a learning experience with all the participants. UX will understand why developing this new button is more expensive than it usually is, and DEV will understand why there's a lot of testing required for this upcoming feature or none at all for the another which is fully automated.

Some practices use a moderator who cannot play the poker and whose goal is to make sure the activity flows smoothly, stopping any prolonged discussions and off-topic chatter. An experienced team should be able to survive the Planning Poker without such role, but if some topics take more than 10 minutes to estimate, then it probably raises the need one.

The game
------------

In order to play the "game", the business comes up with a list of top level deliverables, for example:
* Users should be able to see a unified log of all their activities across the company products;
* Users should be notified by e-mail when we're about to start a marketing campaign;

For each of the deliverables, the business owner provides a short overview of the feature without going into much detail. The team then coordinates, so that all players show their cards at the same time. This is critical in Planning Poker because it assures that the player are not influenciated by their peers and provide their most honest oppinion.

If the team is in perfect tune and all the players choose roughly the same values, the feature is estimated. For example, if some people choose a 2 card and others a 3, just keep it as a 3.

The real challenge and fun of the Planning Poker is trying to achieve concision when initially there are very different cards played. Image on a team of five people, where three of played an eight card, Alice played a 2 and Bob played a 20. Obvisouly Bob thinks there's lot more work in it and Alice feels this is a trivial feature. Both players are given roughly one minute to explain their plays and afterwards all players will take another go. Hopefully the values will be more concise this time around after Alice and Bob's discussion, for example, Alice forgot that the service that the team needs to consume is third-party and it's not been developed yet, thus Bob's 20 card.

When the values are fairly concise again, the team moves to the next deliverable and so on.

Decks, plays and other tricks
--------------------------------------------

The values on the cards are usually story points, but you can change it for duration or whatever metric is more convient to your team, like duration or ideal days.

If a deliverable is taking more than two/three rounds to reach a consensus, just drop it, and gather the necessary people for a side discussing after the Planning Poker. Pursuing a controversial estimate during this activity can make it dull and the features evaluated in the end will suffer from people's tiredness

The most used decks represent the fibonacci sequence with a couple of extra cards. _The reason for using the Fibonacci sequence is to reflect the inherent uncertainty in estimating larger items_. There's usually an infinite or question mark card to represent something too large or too complext to provide an estimate.  Traditionally decks also contain a coffee cup card, which are used to ask for a break. If your Planning Poker is taking so long that you need a coffee break, you either didn't have much sleep or your planning poker session is taking much more time than it should. Maybe then a moderator could be of use for future sessions.

