---
layout: home
title: UBS Neo Development Guide
subtitle: A guide to help <a href="people">teams</a> develop great software using an <a href="process">agile process</a>, <a href="tools">modern tools</a> and a global <a href="platform">application platform</a>
status: done
---

[![People](images/people.png)]({{site.url}}people)

[People]({{site.url}}people)
----------------------------

Agile teams are cross-functional and made up of the right people to deliver end-to-end. Browse resources relevant to different roles.

- [Designers]({{site.url}}people/designers.html)
- [Developers]({{site.url}}people/developers.html)
- [Quality Analysts]({{site.url}}people/quality-analysts.html)
- [Product Managers]({{site.url}}people/product-managers.html)
- [Delivery Managers]({{site.url}}people/delivery-managers.html)

---

[![Process](images/process.png)]({{site.url}}process)

[Process]({{site.url}}process)
------------------------------

Our process combines user-experience design with agile development to meet user needs and maximise business value. Effective [risk management]({{site.url}}risk) is integral. There are five phases:

- [1. Discovery]({{site.url}}process/discovery-phase.html) - find out what is needed
- [2. Alpha]({{site.url}}process/alpha-phase.html) - prototype solutions for early feedback
- [3. Beta]({{site.url}}process/beta-phase.html) - develop in a live environment for the first real users
- [4. Live]({{site.url}}process/live-phase.html) - launch the service and keep improving it iteratively
- [5. Retirement]({{site.url}}process/retirement-phase.html) - turn off services that are no longer needed

---

[![Tools](images/tools.png)](tools)

[Tools]({{site.url}}tools)
--------------------------

Staff need the best tools to be motivated and productive. A set of tools are available to facilitate the development process.

- [Jira Agile](http://goto/devops/jira) for agile project management
- [Source]({{site.url}}tools#source) for sharing UX design standards and specifications
- [GitHub]({{site.url}}tools#github) for source code management and developer collaboration
- [TeamCity]({{site.url}}tools#teamcity) for continuous integration, testing and packaging of artifacts
- [Nexus]({{site.url}}tools#nexus) for managing the versioned artifacts that make up software releases
- [Swift]({{site.url}}tools#swift) for continuous delivery of software releases into production

---

[![Platform](images/platform.png)](platform)

[Platform]({{site.url}}platform)
--------------------------------

Our platform simplifies development, deployment and operation of applications across globalised environments.

- [User Interface SDKs]({{site.url}}platform/ui-sdks.html) for making consistent front-ends
- [Server SDKs]({{site.url}}platform/server-sdks.html) for developing consistent server-side components
- [Service APIs]({{site.url}}platform/service-apis.html) for accessing existing data and functionality over standard protocols
- [Shared Subsystems]({{site.url}}platform/shared-subsystems.html) for providing back-end functionality to your applications
- [Environments]({{site.url}}platform/environments.html) for hosting your application components

---
