---
title: Quality Analysts
subtitle: Test early, test often
category: people
role: qa
standards:
  - title: QA Strategy
    url: https://connections.swissbank.com/docs/DOC-16200
  - title: Mobile QA Strategy
    url: https://connections.swissbank.com/docs/DOC-6529
layout: role
status: for-review
---

Software development is complex, so all teams need to test their work carefully to meet quality standards and deliver valuable services to clients. Although developers need to unit test their own code, teams can benefit greatly from dedicated quality analysts, who take a broader view of the quality assurance. 

Quality analysts help to determine the acceptance criteria for new features and they carry out intensive, exploratory testing, to find issues that developers missed but users could run into. They work closely with developers to automate repetetive forms of testing and build sustainable test suites.

As well as focussing on the functionality of applications, quality analysts care about the non-functional and operational aspects of a system. They make sure the application will be straightforward to support and operate in production.

Responsibilities
----------------

Quality analysts have the following responsibilities within a delivery team:

- Ensure that the delivery result in a product that meets its functional and non-functional requirements
- Raise quality awareness and make quality standards the responsibility of every member of the project. 
- Ensure that the whole team becomes "test infected", testing from the unit level up, driving the coding approach
- Provide early feedback to stakeholders regarding the quality of their product
- Enable developers to spend more of their time on value added features and technical improvements by delegating some testing responsibilities
- Reduce production outages and support tickets
- Reduce our operational "run the bank" costs
- Consistently deliver high quality applications to our users
- Help the team learn how the application should work
- Give QA sign-off when a task or [user story](activities/user-stories.html) is done 
- Make [user stories](activities/user-stories.html) testable
- Ensure solutions can be operated and supported efficiently
- Sharing tools and scripts between developers and quality analysts

Tools
-----

The following tools are in use to facilitate QA processes:

| Tool | Use |
|:----|:------|
| [Chai](https://github.ldn.swissbank.com/HTML-external/chai) | JavaScript test assertion library |
| Charles Proxy | For proxying and intercepting client-server communication |
| [Mocha](https://github.ldn.swissbank.com/HTML-external/mocha) | JavaScript test runner library |
| RIATest | user-interface automation testing for Flex and AIR applications |
| Selenium | user-interface automation testing for Web applications |
| [Test Runner](https://github.ldn.swissbank.com/HTML/test-runner) | A browser-based test runner |	

Community
---------

There are a number of community resources in UBS for quality analysts:

* [Mobile QA Connections Group](https://connections.swissbank.com/groups/mobile-qa)
* [HTML5 QA Connections Group](httpshttps://connections.swissbank.com/groups/htm) 
* [Mobile QA chat channel](http://chatcentral.swissbank.com/website/do/channel/directory?channelID=48226) 
* [eCommerce QA chat channel](http://chatcentral.swissbank.com/website/do/channel/directory?channelID=42938) 
* [QA CoE](https://connections.swissbank.com/groups/qa-coe)
* [QA CoE Working Group Testing Tools](https://connections.swissbank.com/groups/qa-coe-wg-testing-tools)

Hiring Quality Analysts
-----------------------

A number of job-specs are available for hiring quality analysts:

* [Functional QA Analyst](https://teams.ib.cnet.ubs.net/sites/f35/program/Hiring/Job%20Specs/PSD%20-%20Application%20QA%20Profile.pdf)
* [Non Functional/ Technical QA Analyst](https://teams.ib.cnet.ubs.net/sites/f35/program/Hiring/Job%20Specs/PSD%20-%20Non%20Functional%20QA%20Analyst.pdf)
* [Mobile QA Analyst](https://teams.ib.cnet.ubs.net/sites/f35/program/Hiring/Job%20Specs/PSD%20-%20Mobile%20QA%20Profile.pdf)
* [QA Lead](https://teams.ib.cnet.ubs.net/sites/f35/program/Hiring/Job%20Specs/PSD%20-%20QA%20Lead%20Zurich.pdf)
* [QA Manager](https://teams.ib.cnet.ubs.net/sites/f35/program/Hiring/Job%20Specs/PSD%20-%20QA%20Lead%20Zurich.pdf) 

Skills and Attributes
---------------------

A great QA person has the following skills and attributes:

* Has excellent testing experience of the full testing lifecycle from unit testing to user acceptance testing
* Got an in-depth understanding and knowledge of Test Methodologies
* Previous experience in coordinating test environments and releases
* Must be able to demonstrate strong business skills
* Quick learner
* Ability to prioritise and organise
* Results driven : able to deliver good quality accurate solutions to tight time-scales
* Conscientious : Always give 100% to tasks assigned
* Versatile : Able to multi-task
* Team Player : Must be able to work with and participate within a large professional team
* Professional : Expect to work the hours the job demands
* Strong communication skills
* Strong problem solving skills
