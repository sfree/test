---
title: Delivery Managers
subtitle: Help teams be as effective as possible
category: people
role: dm
status: unstarted
layout: role
---

Delivery managers are facilitators of great teamwork. They help the team to deliver successfully by removing obstacles, resolving dependencies, and coaching them to become more self-organising. They keep teams focussed on getting work done rather than prescribing how that work should be done. They report development progress transparently and highlight new risks and issues to product managers. 

Responsibilities
----------------

- Ensure the team understands the goals, strategy, priorities and release deadlines
- Support the team in having clear and effective working practices and help them improve
- Ensure the key team activities are prepared for, carried out and done well
- Ensure the team's progress tracking information is accurate on any given day
- Ensure the team collaborates well
- Ensure the team establishes its velocity for future projections
- Foster a culture of collaboration and delivery focus the team (see below)
- Carry out some management chores to help others keep focus (see below)

Activities
----------

There are a number of acitivites of particular relevance to delivery managers:

- [Setup / Tear Down](../activities/setup-teardown.html) - ensure department policies are followed when starting/ending a project
- [Story decomposition](../activities/story-decomposition.md) - ensure early collaboration between UX, QA and Dev to reach a common understanding of what needs to be done
- [Planning poker](../activities/planning-poker.html) - help the team understand what work is coming up and what size the different pieces of work are
- [Pre-planning](../activities/pre-planning.html) - help the product manager understand what is possible in the next iteration or near future
- [Game planning](../activities/game-planning.html) - help the team understand the goal for an iteration and break stories down into tasks for distribution
- [Retrospective](../activities/retrospective.html) - help the team to reflect on the effectiveness of their own teamwork and self-improve


Culture
-------

A delivery manager is responsible for establishing and continuously improving a strong culture of collaboration and delivery focus in the team. This could include:

- Instilling a sense of joint ownership in the team, both of the product delivered and the information produced for stakeholders. 
- Encouraging healthy and constructive debate to solve problems in the team.
- Encouraging cross-discipline problem solving. E.g. problems are team problems not dev, qa, ux owned).
- Help the team to measure success by the value they deliver to their customer and other dependent teams.
- Make sure teams appreciate that time spent collaborating is work still real work and not a luxury!

Chores
------

There are some organisation chores that a delivery manager is typically responsible for, including:

- Ensuring the team is well organised which may include managing calendar invites
- Spot checking status information to make sure reports given to others are useful
- Keep the team's wall space up-to-date with key information
- Keep an eye on progress and particularly blockers, flagging when something needs to be done inside and outside the team
- Ensure that work is defined and understood sufficiently
- Be the key contact for new stories and know the backlog well
- Support the definition of longer term plans
- Ensure delivery flows smoothly into release management
