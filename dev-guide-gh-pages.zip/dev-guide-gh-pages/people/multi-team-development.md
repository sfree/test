---
title: Multi-Team Development
subtitle: Delivering at scale by coordinating multiple teams
category: people
type: guide
layout: article
status: unstarted
---

- Technical Architect to advise across multiple teams
- Service Manager or Head of Product Management?
- Proxy teams to resolve dependencies
- Value-based planning
- Rotation pattern applied in mobile