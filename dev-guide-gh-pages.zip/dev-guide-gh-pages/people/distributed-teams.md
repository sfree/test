---
title: Distributed Teams
subtitle: Making distributed development work
category: people
layout: article
status: draft
---