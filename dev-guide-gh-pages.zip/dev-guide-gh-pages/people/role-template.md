---
title: Role Title
subtitle: A short sentence to express the purpose of the role
category: people
role: designer - used for automatically matching activity pages
layout: role
status: draft
standards: 
  - title: Title for a link that will be added to the standards section
    url: http://
  - title: Typography
    url: http://
  - title: Iconography
    url: http://
  - title: Form Inputs
    url: http://
  - title: Grids
    url: http://
---

Design is an essential aspect of modern software development that has often been neglected in the past. The days of developers without aptitude in design specifying user interfaces must be put behind us, because client expectations have changed and enterprises now compete with one another in terms of design.

Skills in design are relevant to all phases of software development, from user research and sketching early in the process, through to prototyping, information architecture and interaction design, and on to visual design and digital asset production. Designers often specialise in one area of design or another, so it can be necessary to distinguish between the more analytical role of user-experience designer and the more aesthetic role of visual designer. 

Responsibilities
----------------

Designers have the following responsibilies within software development teams:

- Consulting with developers to make sure their design concepts can be implemented within the technical and time constraints of the deliver.
- Reviewing the implementation of design specifications and working closely with developers to ensure they have been done right.
- Add more

Community
---------

There is no overall design organisation in UBS, but there are pockets of design excellence in different parts of the company. There is an initiative underway to bring together these disparate designers and form a community of practice, to share knowledge, experience and digital design assets. You can join this community by visiting the [User Experience Design Group](http://goto/connections/groups/ux-design) in UBS Connections and participating in their discussions and events.

Hiring Designers
----------------

_Sample job specs for visual designers and IAs to be added. Also info about agencies we have worked with and their work._