---
title: Designers
subtitle: A better client experience by design
category: people
role: ux
layout: role
status: unstarted
image: people/designer.png
standards: 
  - title: Brand Design Platform
    url: http://bw.bdp.ubs.com/bdp/index.htm
  - title: UBS Neo Design Standards
    url: http://goto/neo-source
community:
  - title: User Experience Group
    url: https://connections.swissbank.com/groups/user-experience
links:
  - title: Communications & Branding
    url: http://intra.ubs.net/ChiefCommunicationOfficer/index.htm
---

Applications have become increasingly complex as the scope of what's achievable with technology advances. In particular, the web, which used to be a fairly static medium has evolved into a dynamic, expressive and rich application medium. However, irrespective of the advances in technology, the true success of an application is dependent on how it's perceived by its users. 

Over the years businesses have started to realise that in order to maximise the adoption of any software application, it is critical for the application to be perceived as being valuable, easy to use and pleasurable. This is the key reason why now more than ever, Design should be considered as a critical aspect of most software development initiatives. The overall Design discipline in the context of application development can broadly be divided into two key areas which are discussed in further detail below. 

User Experience Design
----------------------

User Experience (often abbreviated as UX or UE) Design deals with how a user feels as they interact with an application. UX Design has its roots in the traditional field of Human-Computer Interaction (HCI), however over the last decade this field has evolved considerably with a number of sub-disciplines like User Research, [Content Strategy](http://en.wikipedia.org/wiki/Content_strategy) and [Information Architecture](http://en.wikipedia.org/wiki/Information_architecture) being formed which can all be considered specialist areas within their own right.

A UX Designer plans, studies and evaluates how a user interacts with a system and in turn feels about it. They look at things such as ease of use, perceived value, efficiency in performing tasks etc. Overall a UX Designer practices what's known as User-Centred Design (UCD) – a discipline which suggests that any design related decisions need to be based on the needs and wants of the actual users. By practicing UCD, a UX designer ensures that the solution that is being developed matches the needs of the users, while ensuring that all processes within the solution are optimised for ease of use. 

In an ideal world, all application development initiatives should be designed with UCD in mind and would involve the planning and analysis of a UX designer. However, depending on the size of the project, there might be limitations in terms of resources, so it is important to identify and prioritise which elements stand to gain the most from the involvement of a UX designer. As a general rule, the more complex the system, the more planning it will need, and as a result the more benefit a UX designer will be able to bring to the mix. On the other hand, getting a UX designer involved in designing a basic brochure-ware microsite might not be that fruitful.

It's also important to understand that User Experience is not the same as Usability. UX deals with how a user feels when using a system, while Usability is about the user-friendliness and efficiency of the interface. Usability, without a doubt, is a big part of the user experience and plays a major role in experiences that are effective and pleasant, but then [human factors science](https://en.wikipedia.org/wiki/Human_factors_and_ergonomics), psychology, [information architecture](http://en.wikipedia.org/wiki/Information_architecture) and [user-centred design](http://en.wikipedia.org/wiki/User-centered_design) principles also play major roles.

Visual Design
-------------

Visual Design involves the aesthetic representation of the user interface of any application. This includes elements like colour palettes, [branding](http://intra.ubs.net/ChiefCommunicationOfficer/index.htm) components, visual treatments, iconography and typography – amongst other things. Visual Designers seek to attract, inspire, create desires and motivate the users to respond to messages. 

As far as the users are concerned, their first impression of any application is based on what they see – which in essence is what the Visual Designer would have created. Therefore effective visual design is critical for establishing not just a good first impression but also to keep the users engaged throughout their interaction with the application. 

Visual Designers work hand-in-hand with UX Designers on most projects. Visual elements like colours, imagery, typography and even use of white space on the screen evoke emotions that can play a significant part in delivering the desired 'feel' for an application that the UX Designer might have aimed for. Also, in order for the Visual Designers to create the correct feel for the interface, it is critical for them to truly understand the user's needs. Therefore the concept of User-Centred Design principles plays a significant role for Visual Designers just as it does for UX Designers.

Depending on the nature of the project, Visual Designers aim to establish a Visual Language for the user interface which allows the interface to grow and provides a framework for the look and feel for future interface elements. This approach allows the design of an application to be managed as a single integrated process rather than a series of discrete and disjointed efforts.

Responsibilities
----------------

Designers have the following responsibilies within software development teams:

- Working with the Product Manager to conduct research and user needs analysis
- Producing sketches and low-fidelity design specifications for review by the product manager, business stakeholders and other team members
- Designing application screens and user journeys through an application
- Designing the visual elements of the user interface including colours, imagery, typography, use of whitespace
- Consulting with developers to make sure their design concepts can be implemented within the technical and time constraints of the deliver.
- Reviewing the implementation of design specifications and working closely with developers to ensure they have been done right.

Community
---------

There is no overall design organisation in UBS, but there are pockets of design excellence in different parts of the company. 

There is an initiative underway to bring together these disparate designers and form a community of practice, to share knowledge, experience and digital design assets. You can join this community by visiting the [User Experience Group](https://connections.swissbank.com/groups/user-experience) in UBS Connections and participating in their discussions and events.

A large volume of UX design specifications and social activity around UX design production can be found in the [Source](../tools/source.html) tool.