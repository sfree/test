---
title: People
subtitle: Great people make great software
category: people
status: done
layout: category
---

While a good [process](process) helps reduce risk and increase the predictability of software development, it is the quality of the people and the strength of their teamwork that makes the biggest difference. A high-performing team needs to be multi-disciplinary, made up of people with a range of skills required for end-to-end delivery. These people need to work closely and communicate often to deliver efficiently as a team. This page describes the key roles and provides links to resources specific to each.

[![Designer]({{site.img}}people/designer.png)](people/designers.html)

[Designers](people/designers.html)
----------------------------------

Design is an essential aspect of modern software development that was often neglected in the past. The days of developers without aptitude in design specifying user interfaces are behind us, because client expectations have changed and enterprises must now compete in terms of design. Skills in design are relevant to all phases of software development, from user research and sketching early in the process, through to prototyping, information architecture and interaction design, and on to visual design and digital asset production.

[Browse resources for Designers](people/designers.html)

---

[![Developer]({{site.img}}people/developer.png)](people/developers.html)

[Developers](people/developers.html)
------------------------------------

Developers make up the majority of a software development team. The best developers are progressive technologists with strong delivery focus. They are up-to-date with technology trends and keep a look-out for smart ways to apply new technology, yet they are pragmatic, productive and thoughtful programmers, who can make technical architecture recommendations, and understand the importance of clear communication and collaboration to get things done. Developers help product managers and designers realise their vision within the constraints of available technology.

[Browse resources for Developers](people/developers.html)

---

[![Quality Analyst]({{site.img}}people/quality-analyst.png)](people/quality-analysts.html)

[Quality Analysts](people/quality-analysts.html)
------------------------------------------------

Software development is complex, so all teams need to test their work carefully to meet quality standards and deliver valuable services to clients. Although developers need to unit test their own code, teams can benefit greatly from dedicated quality analysts, who take a broader view of quality assurance. Quality analysts help to determine the acceptance criteria for new features and they carry out intensive, exploratory testing, to find issues that developers missed but users could run into. They work closely with developers to automate repetetive forms of testing and build sustainable test suites.

[Browse resources for Quality Analysts](people/quality-analysts.html)

---

[![Product Manager]({{site.img}}people/product-manager.png)](people/product-managers.html)

[Product Managers](people/product-managers.html)
------------------------------------------------

Product managers care deeply about the value and relevance of their product to users and their business stakeholders. They are accountable for making the right product decisions, setting the key performance indicators and measuring success. To do so, they must understand their users and the business context well. Although good ideas can come from anywhere in a team, the product manager defines most of the requirements and owns the prioritisation of work. The product manager facilitates access to users and the business stakeholders, and works closely with the rest of the team on a daily basis, to decide when work is ready for release to users.

[Browse resources for Product Managers](people/product-managers.html)

---

[![Delivery Manager]({{site.img}}people/delivery-manager.png)](people/delivery-managers.html)

[Delivery Managers](people/delivery-managers.html)
--------------------------------------------------

A team often contains an assortment of talented people, who are experts in their fields, but ensuring they work well together to accomplish the overall goals is another matter. Delivery managers are facilitators of great teamwork. They help the team to deliver successfully by removing obstacles, resolving dependencies, and coaching them to become more self-organising. They keep teams focussed on getting work done rather than prescribing how that work should be done. They report development progress transparently and highlight new risks and issues to product managers. 
 
[Browse resources for Delivery Managers](people/delivery-managers.html)

---

Note that the ideal team structure is not set in stone and needs to be adjusted to the context of delivery. In many cases, it should include the above roles, but it may also need to be supplemented by external specialists or require the services of other departments, such as HR, [IT Risk & Security](risk), Sourcing, Marketing and the CTO. Furthermore, there is no hierarchy necessary between these roles; all are complementary and may be carried out by junior or senior practitioners depending on complexity. 

Teams need a comfortable working environment to perform at their best, with well specified hardware, [modern tools](tools), plenty of space and whiteboards. There are special considerations to be made for [distributed teams](people/distributed-teams.html) with staff spread across geographic locations. [Larger development programmes](people/multi-team-development.html) that coordinate multiple teams can also require additional roles and organisational effort.
