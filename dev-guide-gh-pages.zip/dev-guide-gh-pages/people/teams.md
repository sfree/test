---
layout: article
category: home
title: Delivery Teams
status: draft
---

Proxy team pattern to resolve dependencies