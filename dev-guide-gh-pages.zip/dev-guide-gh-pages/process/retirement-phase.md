---
layout: article
title: Retirement Phase
subtitle: What to do when a digital service is no longer needed
type: phase
phase: retirement
image: process/retirement.png
category: process
duration: 8-16 weeks
status: done
---

{:.intro}
Even the best services may eventually reach retirement. Changes in business priority or regulation may mean that certain services are no longer offered to clients, or new insights and understanding may suggest that those user needs are now better provided through a different service altogether. Whatever the reason, the retirement of digital services should be handled with the same degree of care as their creation, with a constant focus on user needs.

Objectives
----------

The objectives when retiring a service are to:

- Understand how user needs will be met without the service
- Plan and implement a smooth transition for users to prevent unnecessary disruption
- Ensure any replacement services are ready to accomodate the transitioning users
- Exit any vendor contracts or software licenses that are no longer needed
- Free up any infrastructure for use by other services
- Ensure other services are not dependent on APIs or components of your service
- Archive any data and source code appropriately

Team
----

Like the development phases, a multi-disciplinary team is needed to retire a service. 

A UX designer should be involved in designing the user journeys to transition users onto new services, so they are not unnecessarily disrupted or confused by the apparent change.

Similarly, developers may be needed to implemented automated transitions from old to new services, such as URL redirection solutions, so visitors of old services can reach the most appropriate new destination easily.

The assistance of external teams is also likely to be needed during retirement, including properly briefing the operational and support functions such as [Global Production Services (GPS)]() in order to handle any user enquiries relating to the retirement knowledgeably.

Process
-------

The first step is to understand how the user needs addressed by your service will be met without the service. Should the users be transitioned onto a different service or do they need to be notified that the service will cease to be offered? How can this be achieved with minimal disruption to those users? 

The same processes that are used for designing and developing services can be applied to deliver a smooth transitional user experience that enables the decommissioning of the service. Think about how users arrive at the existing service and what their expectations will be. Try to manage those expectations such that they understand the reasons for the change, and ideally the benefit to them of the change. Identify the discrete user stories to implement the retirement.

For example, information about the replacement service could start to be incorporated into the user experience of the existing service to raise awareness and encourage voluntary early migration, or a redirection service can be deployed to route visitors arriving at old service destinations to new automatically. Usage tracking can be used to measure migration and understand which aspects of the service remain most critical to existing users.

Depending on how the long the existing service has been in operation, it may in fact be necessary to conduct a variation of the [discovery phase]({{ site.url }}/process/discovery-phase.html) just to understand the constraints, requirements and options for implementing the retirement. It is important not to forget operational, support and compliance matters. For instance, there may be a compliance obligation to archive code and data of the retired systems for some period of time.

Outputs
-------

Retirement is complete when:

- Users have been transitioned off the retired service and optionally onto a replacement
- Other services are no longer dependent on any technical component or API of your service
- Ongoing maintenance costs associated with the service are no longer required
- Data and code has been archived properly to meet all compliance obligations

[Previous phase: live]({{ site.url }}/process/live-phase.html)