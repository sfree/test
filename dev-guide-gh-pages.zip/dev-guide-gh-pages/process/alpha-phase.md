---
layout: article
title: Alpha Phase
subtitle: Build a prototype, test it with users and learn from it
type: phase
phase: alpha
category: process
duration: 4-8 weeks
image: process/alpha.png
status: done
examples:
  - label: A video explaining an alpha phase
    url: https://www.youtube.com/watch?v=PmaE-12KqEQ
  - label: A prototype for FX Trading
    url: 
---

The alpha phase is about exploring solution opportunities and developing an interactive prototype for early feedback from stakeholders or a closed group of users. It builds on the knowledge gained during the [discovery phase](process/discovery-phase.html) and prepares the team for delivering the first end-to-end version of the service to real users during the [beta phase](process/beta-phase.html).

Objectives
----------

The objective is to build a working [prototype](process/prototypes.html) in order to:

- gain a greater understanding of the service requirements
- test some different design approaches
- test some new and existing technology options
- carry out [technical spikes](process/technical-spike.html) to gain confidence in a technical approach
- form a high-level picture of the main system components and integration points
- begin forming [the delivery team](people)
- understand what will be needed to deliver a [beta](process/beta-phase.html)

Team
----

You may need to bring more [designers](people/designer.html) and [developers](people/developer.html) into [the team](people) to help make and test [prototypes](process/prototypes.html). The team may now consist of:

- the [product manager](people/product-manager.html) to make product decisions and ensure the stakeholders are engaged
- [business stakeholders](people/stakeholder.html) to provide feedback and access to users as required
- 1-3 [developers](people/developer.html) to test technologies, develop [prototypes](process/prototypes.html) and carry out [technical spikes](process/technical-spikes.html)
- 1-2 [UX designers](people/designer.html) to try different design approaches and carry out more [user research](process/user-research.html)

During the alpha phase, the [product manager](people/product-manager.html) can continue to lead the team, or one of the developers or designers can assume the role of [delivery manager](people/deliver-manager.html). In any case, someone has to make sure the team is working efficiently together on a daily basis and any blockers are cleared promptly.

Process
-------

The [product manager](people/product-manager.html) should analyse the research carried out during the [discovery phase](process/discovery-phase.html) and set-up an open, enagement process with the business and technology stakeholders. A series of workshops may be necessary to develop the solution options and inform decision making. If you

The team should now be working closely together, attending a daily [stand-up meeting](process/stand-up.html) and working on shared deliverables, such as prototypes. The developers will need to split their time between testing out technologies and working with UX to build prototypes. The team should run weekly [show and tell](process/show-and-tell.html) meetings to demonstrate progress, be that a working prototype or a new test automation tool.

By the end of the beta phase, the team should have developed a series of working prototypes that tackle the principle business and technical challenges. There may be gaps and rough edges, but the prototype should convey the first clear impression of an appropriate and viable solution, such that a decision can be made to proceed to the [beta phase](process/beta-phase.html).

Outputs
-------

You should complete the alpha phase with:

- a set of high-level [user stories](process/user-stories.html)
- a [release roadmap](process/roadmap.html) for the [beta phase](process/beta-phase.html)
- a very high-level plan for running of the [live](process/live-phase.html) service
- a basic working system providing limited functionality that can be shown to a number of users
- a good understanding of legacy systems to replace, wrap or integrate with
- an understanding of the non-functional requirements, including compliance and [risk management](process/risk-management.html) controls
- a decision of whether to progress to the [beta phase](process/beta-phase.html)

**[Next phase: beta]({{ site.url }}/process/beta-phase.html)**

[Previous phase: discovery]({{ site.url }}/process/discovery-phase.html)