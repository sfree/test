---
title: Discovery Phase
subtitle: Find out what your users need, what your constraints are and how to measure success
layout: article
type: phase
category: process
phase: discovery
image: process/discovery.png
status: done
duration: 4-8 weeks
examples:
  - title: Mobile Discovery Report
    url: http://neosource.ldn.swissbank.com/files/Research_Evaluation/Research_Evaluation/mobile-discovery.pdf
  - title: FX Mobile Discovery Report
    url: http://neosource.ldn.swissbank.com/files/Federal/Mobile/fx-mobile-app-discovery-presentation.pdf
  - title: Vision Prototype
    url: http://neosource.ldn.swissbank.com/files/UX_Prototypes/Vision_Prototype/HookVision.zip
links:
  - title: YouTube Discovery Video
    url: https://www.youtube.com/watch?v=PmaE-12KqEQ
---

The first phase of a software development project is about discovery. You need to learn about the needs of your users and the context for the project. You need to understand the business goals and the technical constraints. You will start to identify solution opportunities and form ideas about what the initial prototypes should explore. A decision will be made on whether to proceed to the [alpha phase](process/alpha-phase.html).

Objectives
----------

Find out who your users are:

- what are their needs?
- how do they use digital services today? 
- are they satisfied with our services?
- how could we better assist them with technology?
- how can user satisfaction be measured?

Find out about the business context:

- what is the business model?
- what are the main business transactions?
- who are the competititors and what are they up to?
- what processes are involved in day-to-day running of the business?
- what are the business targets and how is performance?
- are there any jurisdictional challenges?
- are there changes in regulation that influence the business?
- what measurements indicate [success][]?
- are there any relevant [compliance regulations](process/compliance-regulations.html)?
- are there already good ideas for innovation?

[success]: process/performance-measurement.html

Find out about the technical constraints:

- what technology is already in place?
- what infrastructure is needed?
- what do the interfaces look like?
- how are the existing systems operated?
- where are the pain-points?
- are there special [security/risk-management](process/risk-management.html) requirements?
- how and where could new technology help?
- are there components due for replacement or [decommissioning](process/retirement-phase.html)?

Team
----

The discovery phase only requires a small [team](people/team.html), usually consisting of:

- the [product manager](people/product-manager.html) to coordinate the effort and make decisions
- [business stakeholders](people/stakeholder.html) to provide business context and access to users
- an experienced [developer](people/developer.html) to analyse the technical constraints and options
- an experienced [UX designer](people/designer.html) to carry out user research and sketching

Process
-------

The discovery process takes 4-8 weeks, depending on the scale of the project and complexity 
of existing services. During this time, there are many activities that can be carried out
to gather information and gain understanding, including:

- introductory workshops with users and business stakeholders
- demos of existing services, including competitor offerings
- technical analysis of existing services and relevant technology
- lots of whiteboard sessions!
- [paper prototypes](process/paper-prototypes.html) to try out ideas for rapid feedback
- capturing the initial set of [user stories](process/user-stories.html)
- [card sorting](process/card-sorting.html) to get a sense of priority and value

During the final week, you should be setting up the broad scope of a project and an initial set of [user stories](process/user-stories.html) to deliver against, known as the [backlog](process/backlog.html). By the end of the discovery phase, a decision should be made on whether to proceed to the [alpha phase](process/alpha-phase.html).

Outputs
-------

You should complete the discovery phase with:

* a prioritised list of [user stories](/service-manual/agile/writing-user-stories.html) to feed into development teams
* an understanding of existing services in UBS and those available from competitors
* an understanding of the [team](people) required to deliver the service
* some sketches and perhaps a simple, interactive prototype
* a list of stakeholders and an understanding of their needs and expectations
* a decision on whether to progress to the [alpha phase](process/alpha-phase.html)

**[Next phase: alpha]({{ site.url }}/alpha-phase.html)**
