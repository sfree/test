---
title: Live Phase
subtitle: Continuously improve your live service based on measurements, user feedback and new ideas
phase: live
category: process
image: process/live.png
type: phase
layout: article
status: done
---

The live phase begins when the service is ready to be launched to all users. By now, the [beta](process/beta-phase.html) should have been running well in production for some time and the team will be confident that the essential user needs are satisfied. Analytics will be in place to measure the service performance against the KPIs. The service implementation will be fast, scalable, secure and resilient. Repetitive development and operational processes will have been automated.

For a successful service, the live phase will be long-running and may span quite a number of years, until the service is no longer required and can be [retired](process/retirement-phase.html). During this time, the dedicated development team may change form or cease to exist, since the bulk of the design and development work may become complete. However, new opportunities for innovation may also become apparent, leading the [product manager](people/product-manager.html) to initiate new phases of [discovery](process/discovery-phase.html), [alpha](process/alpha-phase.html) and [beta](process/beta-phase.html) development.

Objectives
----------

The objectives of the live phase are to:

- Operate an efficient service for all users in production
- Observe, measure and report on the service performance
- Fix any unexpected issues that occur promptly
- Continue improving and optimising the service iteratively
- Adjust the team based on demand for ongoing development
- Recognise when the service is no longer needed

Team
----

When a service goes live, it is likely that some responsiblities change hands. For example, daily operations and user support is likely to become more structured and handled by a centralised group, such as [Global Production Services (GPS)](http://).

At the start of the live phase, the development team maintains the same essential form as during the [beta](process/beta-phase.html), with fluctuations in size to accomodate specialists as appropriate. As time goes on, the business demand for further development may reduce and so the team structure should be adjusted in response, reducing in size and capacity. Eventually, the system may be handed over to another part of the organisation who can handle routine maintenance and minor enhancements.

Process
-------

Services should generally go live as soon as their essential functionality is completed and proven effective, but this is not the end of the development process. Supplementary features and general improvements to the service should continue to be researched, designed, developed and released in rapid iterations for as long as the business demand remains.

During this period, the development team should continue to follow an agile process, much like the previous [beta phase](/deb-guide/process/beta-phase.html), delivering user stories, carrying out sprint planning, improving via retrospectives, and so on. The whole process (discovery, alpha, beta and live) may be repeated for certain pieces of work and new ideas for innovation may arise and be acted on. The basic philosophy is to find something that needs improvement, research solutions, iterate, release. That should be a constant rhythm for the team.

Outputs
-------

The live phase produces:

- a steady flow of releases containing improvements and optimisations
- realtime reports demonstrating the performance trends for the service
- new ideas for innovation in the service and related services
- a service that can be operated and supported by another organisation
- a service that can be maintained and enhanced easily by another organisation

**[Final phase: retirement]({{ site.url }}/process/retirement-phase.html)**

[Previous phase: beta]({{ site.url }}/process/beta-phase.html)