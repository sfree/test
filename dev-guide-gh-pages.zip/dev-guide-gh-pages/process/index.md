---
title: Software Development Process
subtitle: Combining user-experience design with agile development
category: process
status: done
layout: category
---

A good software development process reduces risks, minimises waste and accelerates the delivery of business value, while stimulating innovation. To achieve this, we combine practices from [user-experience design](people/designers.html) and [agile development](people/developers.html) into a five-phase process with integral [risk management]({{site.url}}risk).

[![Discovery Phase]({{site.img}}process/discovery.png)](process/discovery-phase.html)

[Discovery](process/discovery-phase.html)
-----------------------------------------

The first phase of a software development project is about discovery. You need to learn about the needs of your users and the context for the project. You need to understand the business goals and the technical constraints. You will start to identify solution opportunities and form ideas about what the initial prototypes should explore. You will figure out how to measure success. A decision will be made on whether to proceed to the alpha phase.

[Find out more about the Discovery Phase](process/discovery-phase.html)

---

[![Alpha Phase]({{site.img}}process/alpha.png)](process/alpha-phase.html)

[Alpha](process/alpha-phase.html)
---------------------------------

The alpha phase is about exploring the solution opportunities and developing an interactive prototype for early feedback from stakeholders or a closed group of users. It builds on the knowledge gained during the discovery phase and helps the team establish the right design and technical direction. It is the groundwork for delivering the first functioning version of the service to real users during the beta phase.

[Find out more about the Alpha Phase](process/alpha-phase.html)

---

[![Beta Phase]({{site.img}}process/beta.png)](process/beta-phase.html)

[Beta](process/beta-phase.html)
-------------------------------

The beta phase is about delivering and evolving an end-to-end version of the service for the first real users in a production environment. The team is well prepared for this because of the testing and planning carried out in the alpha phase. During the beta phase, the service will be developed and released in rapid iterations, repetitive tasks will be automated, and performance measurements will be taken to help decide when to go live.

[Find out more about the Beta Phase](process/beta-phase.html)

---

[![Live Phase]({{site.img}}process/live.png)](process/live-phase.html)

[Live](process/live-phase.html)
-------------------------------

The live phase includes the general release of the service to users, its iterative improvement over time, and its effective operation until the service is no longer needed and can be retired. A live service needs to be fast, scalable, secure and resilient. For a successful service, the live phase will be long-running and may span a number of years, during which time the original development team may change form or even cease to exist.

[Find out more about the Live Phase](process/live-phase.html)

---

[![Retirement Phase]({{site.img}}process/retirement.png)](process/retirement-phase.html)

[Retirement](process/retirement-phase.html)
-------------------------------------------

Even the best services may eventually reach retirement. Changes in business priority or regulation can mean that certain services are no longer offered to clients, or new insights and understanding may suggest that those user needs are now better provided through a different service altogether. Whatever the reason, the retirement of digital services needs to be handled with the same degree of care as their creation, with a constant focus on user needs.

[Find out more about the Retirement Phase](process/retirement-phase.html)

---
