---
title: Global Environments
subtitle: Managed environments for hosting your applications
category: platform
type: article
roles: dev, qa, dm
image: platform/environments.png
layout: article
status: unstarted
---

Intro paragraph with mention of hardware, networks, Swift, etc.

Dev Environments
----------------

- [Find out more about the Dev Environments]()

QA Environments
---------------

- [Find out more about the QA Environments]()

UAT Environment
---------------

- [Find out more about the UAT Environments]()

NFR Environment
---------------

- [Find out more about the NFR Environments]()

Production Environments
-----------------------

- [Find out more about the Production Environments]()