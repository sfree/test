---
title: Server SDKs
subtitle: For developing new services and workers
category: platform
type: article
roles: dev, qa, dm
image: platform/server-sdks.png
layout: article
status: done
links:
  - title: The 12 Factor App
    url: http://12factor.net/
  - title: Micro-Services Architecture
    url: http://yobriefca.se/blog/2013/04/29/micro-service-architecture/
tutorials:
---
<!--
  - title: Developing a REST service
    url: http://
  - title: Developing a STOMP service
    url: http://
  - title: Developing a Search Ingestor
    url: http://
  - title: Developing a Search Query
    url: http://
  - title: Developing a Data Feed
    url: http://
  - title: Developing a Worker
    url: http://
 -->
UBS have hundreds of existing systems that hold business data, execute transactions and carry out business processes, but many are not designed to serve user-interfaces or integrate with one another. Server SDKs are provided to make it easy to develop new services and worker processes that run on the platform and integrate with back-end systems.

Developing Services
-------------------

Services are standalone components that provide access to data and functionality over a networked API, such as a REST over HTTP and in future STOMP over WebSockets. Services can be made accessible externally or limited to internal use only.

A number of Java and JavaScript libraries are provided to make it simple to develop services that run on the platform. These take care of cross-cutting concerns, so developers can focus on specific application requirements. 

<table>
  <thead>
    <tr>
      <th align="left" width="40%">Repo</th>
      <th>Summary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedCore/core-server-rest-api">FedCore/core-server-rest-api</a></td>
      <td>REST-over-HTTP services using Java, Spring and an embedded Tomcat server.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedCore/rest-api-example">FedCore/rest-api-example</a></td>
      <td>Basic REST-over-HTTP project - showing the core-service-rest-api usage and helping to test network/infrastructure setup</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedCore/core-node-rest-api">FedCore/core-node-rest-api</a></td>
      <td>REST-over-HTTP services using JavaScript, NodeJS and Express.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedCore/core-server-ws-api">FedCore/core-server-ws-api</a></td>
      <td><em>In Development</em>: Streaming STOMP-over-WebSocket services using Java and Vertx.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedCore/core-server-lcds-adaptor">FedCore/core-server-lcds-adaptor</a></td>
      <td>Java LCDS adaptors that adapt AMF messages over RTMP onto 29West and other transports.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedCore/core-server-standalone">FedCore/core-server-standalone</a></td>
      <td>Java and Spring services that interface over 29West messaging.</td>
    </tr>
  </tbody>
</table>

Developing Workers
------------------

Workers are standalone processes that carry out work in the background, such as ingesting a market-data feed into a database or indexing content into the search engine. Workers often interface with other components via messaging systems. Libraries are available to simplify development of workers.

<table>
  <thead>
    <tr>
      <th align="left" width="40%">Repo</th>
      <th>Summary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedData/analytics-server-sdk">FedData/analytics-server-sdk</a></td>
      <td>For developing instrument data feeds that populate our database and search engine.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedSearch/search-server-sdk">FedSearch/search-server-sdk</a></td>
      <td>For developing ingestors that index data into our search engine.</td>
    </tr>
  </tbody>
</table>

Additional Libraries
--------------------

Various libraries are provided for use when developing services or workers. These add functionality like JMX and encapsulate access to shared subsystems like Cassandra and Redis, providing higher-level programming APIs tailered to our platform.

<table>
  <thead>
    <tr>
      <th align="left" width="50%">Repo</th>
      <th>Summary</th>
    </tr>
  </thead>
  <tbody>
    <tr>  
      <td><a href="https://github.ldn.swissbank.com/FedCore/core-server-jmx">FedCore/core-server-jmx</a></td>
      <td>Exposes JMX operations to control processes, including over HTTP.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedCore/core-server-sso-auth-lib">FedCore/core-server-sso-auth-lib</a></td>
      <td>Secures access to JMX operations with a set of ARP roles.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedCore/core-server-redis-launcher">FedCore/core-server-redis-launcher</a></td>
      <td>Launches a local Redis environment from Java for integration testing without external dependencies.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedCore/core-server-redis-api">FedCore/core-server-redis-api</a></td>
      <td>Java client library for integrating with the Redis shared subsystem.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedCore/core-server-zookeeperClient">FedCore/core-server-zookeeperClient</a></td>
      <td>Java client library for integrating with ZooKeeper using a standard Spring approach.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedEntitle/entitlements-permissions-api">FedEntitle/entitlements-permissions-api</a></td>
      <td>Java client library for checking entitlements over 29West.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedEntitle/entitlements-reporting-api">FedEntitle/entitlements-reporting-api</a></td>
      <td>Java client library for executing pre-defined queries against the Entitlements database.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedSearch/search-server-sdk">FedSearch/search-server-sdk</a></td>
      <td>Contains a Java client library for performing search queries.</td>
    </tr>
    <tr>
      <td><a href="https://github.ldn.swissbank.com/FedSearch/share-token-sdk">FedSearch/share-token-sdk</a></td>
      <td>Java client library for creating and validating tokens used to identify shared content.</td>
    </tr>
  </tbody>
</table>
