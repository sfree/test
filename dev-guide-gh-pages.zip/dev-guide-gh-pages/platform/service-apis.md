---
title: Service APIs
subtitle: For easy access to services over standard protocols
category: platform
type: article
roles: dev, qa, dm
image: platform/service-apis.png
layout: article
status: done
---

Service APIs are provided to make it easy to access UBS data and functionality over standard protocols. This includes REST-over-HTTP APIs and STOMP-over-WebSocket APIs. The Service APIs can be used by front-end client applications and also for system-to-system use cases, with a variety of authentication schemes supported. You can also develop and publish your own APIs to provide services to others.

API Docs
--------

Documentation for all of the Service APIs is published at [goto/api](http://goto/api). Here you can browse through each API to see what resources, methods and data-formats are available. Included are APIs for instrument timeseries data, search, personal profiles, statistics and more.

- [View API docs at goto/api](http://goto/api)

Design Standards
----------------

Design standards are available to help achieve consistency and quality across services. They include conventions for resource naming, query parameters and versioning, as well as patterns for making flexible APIs that suit a variety of client needs.

- [Read the Design Standards](http://goto/devguide/standards/rest-api-design.html)

API Management Layer
--------------------

All API requests pass through an API management layer. This performs authentication, monitoring, measurement, rate-limiting and other cross-cutting concerns. The API management layer is deployed globally for high-availability and regional performance.

- [Learn about REST API management](https://github.ldn.swissbank.com/FedCore/core-server-restproxy)
- [Learn about STOMP API management](https://github.ldn.swissbank.com/FedCore/core-server-wsproxy)

AMF-over-RTMP APIs
------------------

AMF-over-RTMP APIs are available for some UBS Neo services. AMF is a binary message-format native to Flash Player, while RTMP is a duplex messaging protocol. These APIs are not recommended for new development, and REST and STOMP APIs are prefered

- [Learn about the AMF-over-RTMP APIs](http://confluence.swissbank.com/display/neo/Execution+Server+Framework)
