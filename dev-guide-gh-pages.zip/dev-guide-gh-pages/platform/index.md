---
title: Platform
subtitle: Accelerate application development by building on a platform
category: platform
status: done
layout: category
---

Our platform simplifies the development, deployment and operation of applications. You can view the [architecture diagram]({{site.img}}platform/architecture.png) for a high-level overview. The platform includes SDKs to streamline [user-interface]({{site.url}}platform/ui-sdks.html) and [server-side]({{site.url}}platform/service-sdks.html) development, together with [service APIs]({{site.url}}platform/service-apis.html) and [shared subsystems]({{site.url}}platform/shared-subsystems.html) for adding capabilities to your apps. The platform is globalised with [environments]({{site.url}}platform/environments.html) that span UBS data-centers and [tooling]({{site.url}}/tools/swift.html) to automate deployment. 

[![UI Toolkits]({{site.img}}platform/ui-sdks.png)]({{site.url}}platform/ui-sdks.html)

[User Interface SDKs]({{site.url}}platform/ui-sdks.html)
--------------------------------------------------------

The user-interface SDKs contain the building blocks to make consistently well-designed front-ends for applications built on the platform. Three user-interface technologies are currently supported: Web, Apple iOS and Adobe Flex. Each toolkit implements a standardised look-and-feel, so teams can focus on the requirements specific to their applications, rather than styling or other cross-cutting concerns.

[Find out more about the User Interface SDKs]({{site.url}}platform/ui-sdks.html)

---

[![Service APIs]({{site.img}}platform/service-apis.png)]({{site.url}}platform/service-apis.html)

[Service APIs]({{site.url}}platform/service-apis.html)
------------------------------------------------------

The Service APIs provide easy access to UBS business data and functionality using standard protocols including REST over HTTP and soon STOMP over Web Sockets. The services are designed to accommodate the varying needs of different kinds of client, from mobile apps, to web apps and traditional thick-clients running on the desktop. All service APIs are secured, filtered, monitored and measured consistently.

[Find out more about the Service APIs]({{site.url}}platform/service-apis.html)

---

[![Server SDKs]({{site.img}}platform/server-sdks.png)]({{site.url}}platform/server-sdks.html)

[Server SDKs]({{site.url}}platform/server-sdks.html)
----------------------------------------------------

The Server SDKs are provided for developing new services and workers that run on the platform and integrate with back-end systems. They consist predominantly of Java libraries, but some JavaScript libraries are also available for NodeJS development. The Server SDKs make it simple to develop and operate your server-side components consistently, and to interface with shared subsystems using higher-level libraries.

[Find out more about the Server SDKs]({{site.url}}platform/server-sdks.html)

---

[![Shared Subsystems]({{site.img}}platform/shared-subsystems.png)]({{site.url}}platform/shared-subsystems.html)

[Shared Subsystems]({{site.url}}platform/shared-subsystems.html)
----------------------------------------------------------------

Different applications can have many of the same technology needs, so a range of subsystems have been deployed globally for shared use by teams developing on the platform. This includes a variety of persistence technologies, a search engine, multimedia transcoding and streaming capabilities, entitlements, property management and more. Sharing these helps to eliminate overheads of operating your own siloed deployments.

[Find out more about the Shared Subsystems]({{site.url}}platform/shared-subsystems.html)

---

[![Environments]({{site.img}}platform/environments.png)]({{site.url}}platform/environments.html)

[Global Environments]({{site.url}}platform/environments.html)
-------------------------------------------------------------

Applications developed on the platform are for clients of UBS and internal users distributed around the globe. We need high-performance and resilience for all users in all regions, with around the clock operations and intra-day deployment. To accomplish this we have a range of pre-production and production environments spanning UBS data-centers in the UK, North America, Sydney, Hong Kong and Tokyo, with Switzerland planned for 2014.

[Find out more about the Global Environments]({{site.url}}platform/environments.html)

---
