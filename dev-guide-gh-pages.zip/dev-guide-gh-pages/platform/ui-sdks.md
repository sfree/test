---
title: UI Toolkits
subtitle: Building blocks for making consistent user interfaces
category: platform
type: article
roles: dev, qa, dm
image: platform/ui-sdks.png
layout: article
standards:
  - title: Brand Design Platform
    url: http://bw.bdp.ubs.com/bdp/index.htm
  - title: UBS Neo Design Standards
    url: http://goto/neo-source
tools:
  - title: UBS Web SDK
    url: http://goto/websdk
  - title: UBS iOS SDK
    url: http://goto/iossdk
  - title: UBS Flex SDK
    url: http://goto/flexsdk
links:
  - title: HTML5
    url: http://html5rocks.com
  - title: Apple iOS
    url: http://
  - title: Adobe Flex
    url: http://
status: done
---

A set of toolkits are provided for developing user interfaces that are consistent in look-and-feel. These also include provisions for security, client-server connectivity and other concerns of user-interface development.

There are three technologies targeted for user-interface development:

- Web
- Apple iOS
- Adobe Flex

Progress in web browsers and open web standards makes Web technology the strategic choice for most new user-interface development. However, Apple iOS is compelling and productive for delivering the very best user experiences on Apple mobile devices, and Adobe Flex enables us to reach clients without modern web browsers as well as enhancing existing Flex applications in UBS. These technologies can also be hybridised.

The UI toolkits are developed with [GitHub Enterprise](../tools/github.html) using an open-source like process, so developers who use them are empowered and encouraged to contribute additions and improvements.

UBS Web SDK
-----------

The UBS Web SDK is our toolkit for modern Web development. It embraces open web standards like HTML5, CSS3 and SVG, together with popular open-source JavaScript libraries like jQuery and D3. The UBS Web SDK provides many capabilities for developing applications that run in web browsers or other web runtimes.

This should be your first choice for most new application development, unless you need to deliver the highest performance user experience onto Apple mobile devices. The Web SDK consists of many optional parts so can provide value to a broad range of new and existing applications.

[Get Started with the UBS Web SDK](http://goto/websdk)

UBS iOS SDK
-----------

No user-interface technology has transformed user expectations more over the last five years that Apple's iOS. Apple devices are very popular with UBS client segments, and also with UBS staff, so the native development technology of iOS is important.

To streamline development of native iOS applications, an SDK has been created consisting of reusable UI components, security libraries and other capabilities. 

[Get Started with the UBS iOS SDK](http://confluence.swissbank.com/display/CFTMOB/Mobile+SDK)

UBS Flex SDK
------------

Adobe Flex provides extensive capabilities for developing user interfaces that run within the Flash Player plug-in in web browsers or Adobe AIR on desktop. Although not the first choice for new application development, this technology has been used widely within UBS and remains important for enhancing and maintaining existing applications.

The UBS Flex SDK consists of custom components and extensions to the Adobe Flex SDK specifically for developing applications within UBS Neo.

[Get Started with the UBS Flex SDK](http://confluence.swissbank.com/display/neo/Core+Component+SDK)