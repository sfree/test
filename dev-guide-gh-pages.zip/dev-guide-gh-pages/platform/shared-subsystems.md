---
title: Shared Subsystems
subtitle: Globally deployed capabilities for your applications
category: platform
type: article
roles: dev, qa, dm
image: platform/shared-subsystems.png
layout: article
status: in-progress
links:
  - title: 29West
    url: http://www.informatica.com/us/products/messaging/
  - title: Activitii
    url: http://www.activiti.org/
  - title: Adobe CQ5
    url: http://www.adobe.com/solutions/web-experience-management.html
  - title: Adobe FMS
    url: http://www.adobe.com/products/adobe-media-server-family.html
  - title: Adobe LCES Output
    url: http://www.adobe.com/products/livecycle.html
  - title: Apache Hive
    url: http://hive.apache.org/
  - title: APNS
    url: https://developer.apple.com/library/ios/documentation/NetworkingInternet/Conceptual/RemoteNotificationsPG/Chapters/ApplePushService.html
  - title: Attivio Search
    url: http://www.attivio.com/
  - title: Cassandra
    url: http://cassandra.apache.org/
  - title: Cisco MXE
    url: http://www.cisco.com/en/US/products/ps9892/
  - title: Gemfire
    url: http://www.vmware.com/products/vfabric-gemfire
  - title: Jetty
    url: http://www.eclipse.org/jetty/
  - title: LogStash
    url: http://logstash.net/
  - title: Neo4J
    url: http://www.neo4j.org/
  - title: Oracle
    url: http://www.oracle.com/us/products/database/overview/index.html
  - title: Redis
    url: http://redis.io/
  - title: Smartlogic
    url: http://www.smartlogic.com/
  - title: Swisscomm SMS
    url: http://confluence.swissbank.com/download/attachments/383107039/05-02-2010-SMS_Gateway_with_Email-to-SMS_Converter_User_Guide_v1.0.pdf?version=1&modificationDate=1350053204000
  - title: Tibco EMS
    url: http://www.tibco.co.uk/products/automation/messaging/enterprise-messaging/enterprise-message-service/default.jsp
  - title: Vert.x
    url: http://vertx.io/
  - title: ZooKeeper
    url: http://zookeeper.apache.org/
---

Different applications can have many of the same technology needs, so a range of subsystems are deployed globally for shared use by teams developing on the platform. In addition, some subsystems are provided as managed services by other departments in UBS. Both kinds of shared subsystem are described on this page.

The shared subsystems include a variety of databases and content management systems, as well as integration technology such as messaging systems. The use of these shared subsystems eliminates the overhead of operating your own siloed deployments and centralises concerns such as security and performance tuning. 

Databases
---------

The platform embraces the [polyglot-persistence](http://www.martinfowler.com/bliki/PolyglotPersistence.html) principle to provide a choice of database technologies to suit different use cases.

### Oracle Relational Database

Oracle is the standard relational database technology in UBS. It is well suited to the persistence of structured data that may need to be queried and joined in many different ways. The platform has no special provisions for Oracle but can integrate seamlessly with the Oracle DB-as-a-Service and the classic Oracle managed service.

- [Visit the Oracle website](http://www.oracle.com/us/products/database/overview/index.html)

### Cassandra NoSQL Database

Cassandra is a NoSQL column-store database suitable for large scale persistence of denormalised data with high performance reads. A globalised and replicated Cassandra cluster is deployed on the platform. It is used for storing large volumes of instrument reference and time-series data as well as other purposes. With Cassandra, you store the data in the way you intend to use the data, since it is less flexible than a relational database for ad-hoc querying with joins.

- [Visit the Cassandra website](http://cassandra.apache.org/)
- [Develop data feeds into Cassandra]({{site.ghe}}FedData/analytics-server-sdk)

### Redis Data Structure Server

Redis is an extremely fast in-memory data-structure server that can be used to map keys to a variety of value types, including lists, hashes, sets, and ordered sets. It also includes a publish/subscribe messaging system. It is well suited to transient data and low latency use cases, such as storing session state, capturing metrics and keeping high-score tables, such as most-read article, most-followed author, etc. A globalised and replicated Redis cluster is deployed on the platform.

- [Try Redis online](http://try.redis.io/)
- [Read the Redis documentation](http://redis.io/documentation)
- [Run a local Redis environment]({{site.ghe}}FedCore/core-server-redis-launcher)
- [Integrate your code with Redis]({{site.ghe}}FedCore/core-server-redis-api)

### Neo4J Graph Database

Neo4J is a graph database that can be used for modelling complex relationships between entities. The data held in a graph can be queried in many ways using traversal algorithms. [Connected data operations](http://www.infoq.com/presentations/Challenge-Connected-Data) can be many times faster with a graph database than a relational database. Neo4J is currently used for modelling entitlements and understanding relationships between clients. It is deployed in a globalised and replicated cluster.

- [Visit the Neo4J website](http://www.neo4j.org)
- [Try Neo4J online](http://www.neo4j.org/learn/try)

### Apache Hive Big-Data Archive

Apache Hive is a data-warehousing technology designed for big-data archiving and map-reduce processing via Apache Hadoop. It is not well suited for real-time querying, but is a good choice for holding historic records that may need to be mined for information in future. Apache Hive is currently only deployed in a Dev environment for archiving development activity from [GitHub](../tools/github.html), but may be promoted for further use cases if the need arises.

- [Visit the Apache Hive website](http://hive.apache.org/)

Content Systems
---------------

A variety of systems are in place for managing content, including storing publications, tagging and indexing content for search retrieval, recording, transcoding and playback of audio and video streams, and more.

### Adobe CQ5 CRX Content Repository

Adobe CQ5 include a content repository known as CRX, which implements the Java Content Repository (JCR) standard. It can be used for storing publications and other content-related assets, such as static images. CRX is deployed in a globalised and replicated cluster. This deployment is now end of life.

- [Visit the Adobe Experience Management (CQ5) website](http://www.adobe.com/solutions/web-experience-management.html)

### Attivio Search Engine

Attivio is a search engine technology based on Apache Lucene that is designed to handle structured and unstructured data, and to be able to apply a security model to search queries. A globally replicated Attivio deployment is in place and many data sources have been ingested into the search index, including client identifying data that is carefully controlled and secured.

- [Visit the Attivio website](http://www.attivio.com/)
- [Develop search queries and ingestors]({{site.ghe}}FedSearch/search-server-sdk)

### Smartlogic Taxonomy Server

Smartlogic Taxonomy Server is used to manage a taxonomy for content and to perform automatic tagging of content based on this taxonomy. *What is the deployment topology for Smartlogic?*

- [Visit the Smartlogic website](http://www.smartlogic.com/)

### Activiti Workflow Engine

t.b.c.

### Adobe LiveCycle Output

Adobe LiveCycle Output is a server-side component used for producing UBS branded PDF documents by passing input data through XFA templates. 

### Adobe Flash Media Server (FMS)

Flash Media Server (FMS) is used within Neo to record videos form the user's desktop to be embedded into publications. FMS then permits global playback of both the original recording and the transcoded videos (see Cisco MXE Multimedia Transcoder). This is made possible by using the globally deployed Edge streaming servers that have both internal and external access point. Content on the server can be made available both protected by using the Neo video token system or publically with no authentication.

### Cisco MXE Multimedia Transcoder

The Cisco MXE 3500 enable any to any media adaptation where recorded and live video content is automatically adapted from a range of incompatible media formats, resolutions, and speeds, from standard-definition (SD) up to full high-definition (HD), so they can be viewed on demand or live by a wide variety of playback devices and applications.

Neo utilise the service by taking desktop video recording for publications (see Flash Media Server above) and turning the flv video into mp4 renditions at different bit rates for difference appliances.

### Apple Push Notification Service (APNS)

t.b.c.

### Swisscomm SMS Service

t.b.c.

Integration Systems
-------------------

### Jetty Reverse Proxy

Jetty is a lightweight and high-performing application server written in Java and released as open-source technology by the Eclipse Foundation. It is used by the platform as a reverse proxy to provide secured and managed access to internal REST-over-HTTP services. The Jetty deployment is stateless and deployed globally behind load-balancers and firewalls.

- [Visit the Jetty website](http://www.eclipse.org/jetty/)
- [Learn how to use the Jetty reverse proxy at UBS](https://github.ldn.swissbank.com/FedCore/core-server-restproxy)

### Netty WebSocket Proxy

t.b.c.

- [Visit the Netty website](http://netty.io/)

### Adobe LiveCycle Data Services

t.b.c.

### ZooKeeper

ZooKeeper is a centralized service for maintaining configuration information and providing reliable distributed coordination services. In our platform there is a ZooKeeper cluster in each environment as well as one per production data center.  It is used by the platform for property management and in Swift, our deployment tool, for distributed coordination of releases and environment state.

- [Visit the ZooKeeper website](http://zookeeper.apache.org/)

### Informatica Ultra Messaging System (formerly 29West)

Ultra Messaging (formerly 29West) is a low latency messaging technology based on a peer-to-peer design the leverages muticast and eliminates the need for brokers. It is used by the platform for service to service communication and deployed globally.

- [Visit the UMS website](http://www.informatica.com/us/products/messaging/ultra-messaging-streaming-edition/)

### Tibco Enterprise Messaging System

A JMS based enterprise messaging platform for data distribution. Offered as a managed service at UBS. It is used by the platform for replicating data across data centers as well as various data distribution use cases like real time loading of instrument reference and timeseries data into Cassandra.  Where reliabile delivery is important, we tend to favor this solution over Ultra Messaging (29West).

- [Visit the Tibco EMS website](http://www.tibco.com/products/automation/messaging/enterprise-messaging/enterprise-message-service/default.jsp)

### Gemfire Distributed Cache

Gemfire is a scalable in-memory distributed cache with support for features like replication, partitioning, and data-aware routing.  It is used by the platform for caching search results.

- [Visit the Gemfire website](http://www.vmware.com/products/vfabric-gemfire)

### LogStash/Elasticsearch Log Management Service

Logstash allows you to source logs over 30+ protocols, parse/filter them, and send to numerous output locations.  Elasticsearch is on such output from Logstash, and used by the platform for indexing and analyzing log data.  Elasticsearch log data can be visualized via the Kibana web tool.  This solution has completed a successful POC and is currently being considered against several others commercial solutions before we promote through the environments.

- [Visit the Logstash website](http://logstash.net/)
- [Visit the Elasticsearch website](http://www.elasticsearch.org/)
- [Learn about how Logstash was implemented at UBS](https://connections.swissbank.com/groups/ps-development/blog/2013/07/19/redis-elasticsearch-kibana-and-logstash-an-interesting-poc)

### Vert.x

t.b.c.

- [Visit the Vert.x website](http://vertx.io/)
