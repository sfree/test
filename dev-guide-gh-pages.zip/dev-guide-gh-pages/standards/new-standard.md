---
title: New Standard
subtitle: This is a place holder
category: people
type: standard
roles: dev, qa, dm
layout: article
status: unstarted
---

This is a placeholder.