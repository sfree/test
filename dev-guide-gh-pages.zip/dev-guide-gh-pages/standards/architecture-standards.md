---
title: Architecture
status: draft
type: standard
roles: dev
layout: article
status: unstarted
---

Very Rough Notes (not approved and applicable to web apps)
----------------------------------------------------------

1. Service-Oriented Architecture

Encapsulate distinct responsibilities into services that can be reused, composed and orchestrated via simple [apis](standards/api-standards.html). Disallow backdoors into underlying datastores when integrating systems.

2. Simple, Standard, Documented Service APIs

Make services accessible over standard protocols using simple, well-documented APIs, so they are easy to consume regardless of the technology of the consumer. 

Favour the text data format of JSON, since it is universally supported and does not encode platform-specific type information into messages, thus achieving loose coupling. 

Centralise and curate the API documentation of services, so we can maintain consistency and it is easier for consumers to discover and use them.

3. Distribute content close to consumers

If [security](risk) constraints allow us to distribute content over a CDN, we should do so, since it improves user experience by reducing latency and ensuring the high-availability of content better than we can.

4. Minimise Requests at Start-up

The number of requests required to formulate an HTML page has a large effect on the perceived performance for users and it is a standard best practice to minimise these. This is particularly true for mobile clients that are more likely to experience low bandwidth and network disruption during use.

5. Unobtrusive JavaScript

Try to serve the primary content of a page or app in the first response without requiring JavaScript, then enrich the page and user-experience with JavaScript. This improves the user experience, particularly for mobile web applications. 

7. Polyglot Platform

Allow some diversity of programming language and other technology choices in the components of a system to make continuous technological progress and foster innovation. 

By focussing on [API](standards/api-design.html) design and standard, platform-agnostic protocols, specific technology choices become loosely coupled and can be changed independently while preserving system integrity.

6. Consider running the same HTML generation code in client and server

Modern Web applications often generate HTML fragments dynamically at runtime using JavaScript within the client. However, there remain many cases for generating HTML content on the server-side. Unless the same generation logic can be executed in both contexts there will be duplication of effort and discrepancies in output. JavaScript runtimes are now well-proven and high-performing so consider applying them.