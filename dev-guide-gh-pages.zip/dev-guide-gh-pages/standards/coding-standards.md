---
title: Coding Standards
status: draft
type: standard
roles: dev
links:
  - title: Clean Code Book
    url: http://www.amazon.co.uk/Clean-Code-Handbook-Software-Craftsmanship/dp/0132350882
layout: article
status: draft
---

Presently there are a number of different coding standards. A rationalisation exercise is underway to reach one preference. In general, dogma in coding standards is not appreciated, and contributors should honour the coding standard that they find in a project that they contribute to.

C++
---

t.b.c.

CSS
---

The following general guidance is available:

- [Modular CSS for Enterprise Web Applications](https://github.ldn.swissbank.com/HTML/theme/wiki/Modular-CSS-for-Enterprise-Web-Applications)
- [CSS Best Practices](https://github.ldn.swissbank.com/HTML/theme/wiki/CSS-Best-Practices)

The following coding style guides are in use and will be rationalised:

- [CSS Coding Style](https://github.ldn.swissbank.com/HTML/css-coding-style)
- [Swift CSS Coding Style](https://github.ldn.swissbank.com/NeoSwift/docs/blob/master/style/css.md)

Flex
----

t.b.c.

HTML
----

t.b.c.

Java
----

t.b.c.

JavaScript
----------

The following style guides are in use and will be rationalised:

- [JavaScript Coding Style](https://github.ldn.swissbank.com/HTML/coding-style)
- [Swift JavaScript Coding Style](https://github.ldn.swissbank.com/NeoSwift/docs/blob/master/style/js.md)

These were influenced by:

- [The NPM JavaScript Coding Style](https://npmjs.org/doc/coding-style.html)

Objective C
-----------

t.b.c.

Perl
----

t.b.c.
