---
title: API Design
subtitle: Simple, standardised, versioned interfaces
category: standards
type: standard
roles: dev
links:
  - title: Gov UK API Design
    url: https://www.gov.uk/service-manual/making-software/apis.html
  - title: WhiteHouse API Standards
    url: https://github.com/WhiteHouse/api-standards
  - title: Designing Better JavaScript APIs
    url: http://coding.smashingmagazine.com/2012/10/09/designing-javascript-apis-usability
  - title: Secrets of JavaScript API Design
    url: http://webstandardssherpa.com/reviews/secrets-of-awesome-javascript-api-design
layout: article
status: in-progress
---

Rough notes
-----------

- Favour open protocols of HTTP/REST and Web Sockets for client simplicity and reach
- Favour text-based open-standard message formats of JSON and HTML for simplicity and reach
- Standardise cross-cutting concerns of authentication, parameterisation, errors, redirects, verbs, hypermedia, pagination, rate-limiting, callbacks, etc.
- Prefer not to encode platform specific type information into messages for loosely coupled service-oriented architecture
- Apply semantic versioning to APIs for compatibility management
- Centralise service API documentation management with GitHub Enterprise
- Document service APIs with Markdown, so it is easy to generate, read, write and transform