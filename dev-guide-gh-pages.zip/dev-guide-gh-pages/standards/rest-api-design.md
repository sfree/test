---
title: REST API Standards
subtitle: For easy access to data and functionilty over HTTP
category: standards
type: standard
roles: ux, dev, dm
links:
  - title: Cool URIs Don't Change
    url: http://www.w3.org/Provider/Style/URI.html
  - title: Web API Design
    url: http://pages.apigee.com/web-api-design-ebook.html
  - title: GOV.UK API Guidance
    url: https://www.gov.uk/service-manual/making-software/apis.html
  - title: White House API Standards
    url: https://github.com/WhiteHouse/api-standards
  - title: The RESTful CookBook
    url: http://restcookbook.com
  - title: REST Security Cheat Sheet
    url: https://www.owasp.org/index.php/REST_Security_Cheat_Sheet
  - title: Building Hypermedia APIs with HTML5 & Node
    url: http://www.amazon.co.uk/Building-Hypermedia-APIs-HTML5-Node/dp/1449306578
layout: article
status: in-progress
---

This page defines standards for REST API design. Its purpose is to encourage consistency, advocate best practices and simplify development. There are many cross-cutting concerns in REST API design, so these can be defined once and applied repeatedly. Then SDKs can be used to streamline implementation.

- Design Principles: [URL as UI](#url_as_ui), [Client Needs Vary](#client_needs_vary), [Hypermedia as the Engine of Application State](#hypermedia_as_the_engine_of_application_state)
- URL Conventions: [Domains](#domains), [Resource Naming](#resource_naming), [Associations](#associations), [Query Parameters](#query_parameters), [Pagination](#pagination), [Partial Responses](#partial_responses), [Attribute Names](#attribute_names), [JSON-P Callbacks](#jsonp_callbacks)
- Other Conventions: [Batch Requests](#batch_requests)
- Security: t.b.c.
- Managing Change: [API Versioning](#api_versioning)
- Development: [Libraries and SDKs](#libraries_and_SDKs)
- Documentation: [Documenting APIs](#documenting_apis)
- Operations: t.b.c.

Design Principles
-----------------

### URL as UI

As Jakob Neilsen wrote in 1999, ["The URL will continue to be part of the Web user interface for several more years"](http://www.nngroup.com/articles/url-as-ui/). Similarly, developers will continue to need to type, memorize and guess URLs for _several_ more years. 

URLs should be designed to be simple, memorable and meaningful. Unnecessary implementation details should not leak into the URL. The URL is for consumers of the service and it should be easy to use.

Yes:

{% highlight text %}
https://arp.swissbank.com/access-rights?user=sugdenth
{% endhighlight %}

No:

{% highlight text %}
https://arp.swissbank.com/idm/user/ubs_arpEndUser.jsp?gwtModule= \
membershipview.MembershipView
{% endhighlight %}

The above includes implementation details of `jsp` and `gwt`. It contains duplicated information in inconsistent formatting, `membershipView` and `MembershipView`, making it hard to memorize. It has an internal team name, `idm`, that isn't relevant to users of the URL.

### Client Needs Vary

In order to serve a wide variety of clients with the same services, it is important to grant the client adequate control over the quantity and content-type of data returned. For example, a mobile client is likely to require fewer data fields and smaller result pages than a thick desktop client on a permanent internet connection. There are conventional solutions to help achieve this flexibility, such as [Pagination](#pagination), [Partial Responses](#partial_responses) and [Batching](#batching).

### Hypermedia as the Engine of Application State

Hypermedia APIs can make distributed systems easier to develop and more resilient to change. When designing APIs, look for opportunities to apply elements of hypermedia API design, such as hypermedia content types, hyperlinks and embedded resources. For example, when exposing Search over REST, we you could provide a response using HTML5 as the base media-type, containing an ordered-list of people represented with the [hCard micro-format](http://microformats.org/wiki/hcard) , and each result element containing an outward link. Then clients can understand more about the meaning of the data and act on it more intelligently and automatically.

### Cool URIs Don't Change

t.b.c.

### Pragmatic REST

t.b.c.

### Backwards and Forwards Compatibility

t.b.c.

URL Conventions
---------------

### Domains

- Consolidate API requests under an `api` subdomain

Yes:

{% highlight text %}
api.ubs.com
api.ubs.net
{% endhighlight %}

No:

{% highlight text %}
www.ubs.com/api
www.ubs.net/intranet/api
{% endhighlight %}

### Resource Naming

- Use nouns not verbs
- Prefer concrete names to abstractions
- Hyphenate multi-word resource names
- Use plural nouns and not singulars
- Define 2 base URLs per resource, one for a collection, the other for a specific item.

Yes:

{% highlight text %}
/equities  
/equities/:id  
/trade-ideas  
/trade-ideas/:id  
{% endhighlight %}

No:

{% highlight text %}
/getTradeIdeas  
/content?type=tradeIdea  
/equity/:id
{% endhighlight %}

### Associations

- Try not to include more than 2 resource names in a URL. ``/resource-a/:id/resource-b``
- Address the parent of an association then the child collection. ``/parents/:id/children``

Yes:

{% highlight text %}
/user/:id/settings  
/settings/:id/options  
{% endhighlight %}

No:

{% highlight text %}
/user/:user-id/settings/:setting-id/options  
{% endhighlight %}

### Query Parameters

t.b.c

### Pagination

- Don't return entire collections
- Allow the requester to paginate collections
- Use `offset` and `limit` query parameters for pagination
- Default to `limit=10` and `offset=0`; lower the limit for large resources, increase for small.
- Prefer to include metadata in the response for total records available

Yes:

{% highlight text %}
/articles?limit=20&amp;offset=80
{% endhighlight %}

No:

{% highlight text %}
/articles?number=20&amp;page=5
{% endhighlight %}

### Partial Responses

- Let the requester specify optional data fields that they require
- Use a `fields` query parameter and comma delimited list of field names

Yes:

{% highlight text %}
/trade-ideas?fields=title,author,summary
{% endhighlight %}

No:
 
{% highlight text %}
/trade-ideas:(title,author,summary) 
{% endhighlight %}

### Attribute Names

- Apply JavaScript camelCase conventions to keys in JSON response data to it looks conventional when those keys are accessed in code.

Yes:

{% highlight text %}
{
  'createdAt': 1320296464
, 'editedAt': 1320296465
}
{% endhighlight %}

No:

{% highlight text %}
{
  'created_at': 1320296464
, 'EditedAt': 1320296465
}
{% endhighlight %}

- Don't place values into keys

Yes:

{% highlight text %}
{
  'tags': [
    {'id': '12', 'name': 'Government Bond'}
  , {'id': '45', 'name': 'Precious Metals'}
  ]
}
{% endhighlight %}

No:

{% highlight text %}
{
  'Tags': [
    {'12': 'Government Bond'}
  , {'45': 'Precious Metals'}
  ]
}
{% endhighlight %}

### JSONP Callbacks

- Use JSON-P if you need to support cross-domain GET requests
- Accept a `callback` query parameter on any GET call to have the results wrapped in a JavaScript function call.
- JSONP support can be added transparently by the [UBS API](http://goto/api) Reverse Proxy, so you may not need to implement it in your own REST service.

Yes:

{% highlight text %}
https://api.ubs.net/analytics/v1/instrument/timeseries?callback=renderInstruments
{% endhighlight %}

No:

{% highlight text %}
https://api.ubs.net/analytics/v1/instrument/timeseries?cb=renderInstruments
{% endhighlight %}

Other Conventions
-----------------

### Verbs
### Content Types
### Status Codes
### Redirection
### Errors
### Hypermedia
### Micro formats
### Cross Origin Resource Sharing
### Aggregation
### Batch Requests

- Implement a batch API if your service needs support large insert and update operations
- Follow the conventions from the [Neo4J batch operations API](http://docs.neo4j.org/chunked/stable/rest-api-batch-ops.html)

Managing Change
---------------

### API Versioning

- Version number to appear between the API name and the resource `http://api.ubs.net/{api-name}/{version}/{resource}`
- Version number to be major only
- Lower case v

Yes:

{% highlight text %}
/equities/v1/trade/:id  
/trade-ideas/v3/user/:id/settings  
{% endhighlight %}

No:

{% highlight text %}
/equities/V1/:id
/equities/v1.0.1/:id  
/v1/equities/:id
/v1-equities/:id
/equities-v1/:id  
{% endhighlight %}

### Forwards Compatibility
### Robustness Principle
### Backwards Compatibility
### Redirection

Security
--------

### Authentication
### Authorization
### API Keys
### eMidas
### WebSSO

Development
-----------

### Libraries and SDKs

There are some libraries available in UBS to simplify the development of REST services.

- [core-server-rest-api](https://github.ldn.swissbank.com/FedCore/core-server-rest-api) - a custom Java Spring namespace handler for creating REST APIs easily.

There are some examples of REST APIs developed against this standard in different technologies:

- [analytics-restful-service](https://github.ldn.swissbank.com/FedData/analytics-restful-service) - a service providing instrument reference and timeseries data from a Cassandra data-warehouse.
- [core-node-article-rendition](https://github.ldn.swissbank.com/FedCore/core-node-article-rendition) - a odeJS and Express service for producing different renditions of articles accessible on UBS Neo.

Documentation
-------------

### Documenting APIs

- Provide API documentation via `profile` link relation as described [here](http://www.designinghypermediaapis.com/blog/the-profile-link-relation-and-you.html).
- Provide API documentation at a URL that mirrors the service API itself
- Provide API documentation using a `developer` subdomain

Yes:

{% highlight text %}
https://api.ubs.net/analytics/v1
https://developer.ubs.net/analytics/v1
{% endhighlight %}

No:

{% highlight text %}
https://api.ubs.net/execution/v1
http://confluence.swissbank.com/display/neo/Execution+Server+Framework
{% endhighlight %}

### Mocking
### Virtualisation
### Masking

Operations
----------

### Rate Limiting
### Expected Responsiveness
### Utilisation Measurement
