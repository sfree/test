swift-demo-script
======================

This script provides a quick introduction to the glu script framework and deployments with swift.  
To keep things simple, it's hard coded to only support deployment of the swift-demo-server 
artifact.

Checkout out the glu documentation
http://pongasoft.github.io/glu/docs/latest/html/glu-script.html

For further examples, check out 
https://github.ldn.swissbank.com/NeoSwift/swift-neo-server-script
https://github.ldn.swissbank.com/NeoSwift/swift-neo-client-script
https://github.ldn.swissbank.com/NeoSwift/swift-neo-redis-script