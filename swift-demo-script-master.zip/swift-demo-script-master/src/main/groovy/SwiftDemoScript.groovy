import org.linkedin.glu.agent.api.ShellExecException
import com.ubs.swift.properties.PropertiesExporter

/**
 *Deploys SwiftDemoServer java app to a linux host
 */
class SwiftDemoScript {
    def group
    def artifact
    def projectVersion
    def installDest
    def startPort = 8090
    def installRootDir
    def logsDir

    def install = {
        group = params.project.g
        artifact = params.project.a
        projectVersion = params.project.v

        installDest = artifact + '/' + projectVersion

        log.info("Installing to ${installDest}...")

        def installRoot = shell.mkdirs(installDest)
        installRootDir = installRoot.file

        logsDir = "${installRootDir}/logs"
        // can't use shell.fetch as it doesn't follow redirects.  But if no redirects required, use this.
        // shell.fetch(buildRepositoryUrl(), installDest)

        def repoUrl = buildRepositoryUrl()
        log.info("Downloading from ${repoUrl}... to ${installRoot}")

        shell.exec("curl -L '${repoUrl}' -o ${installRootDir}/install-dist.tar.gz")

        log.info("Extracting installation bundle '${installRoot}/install-dist.tar.gz'")
        shell.untar("${installRoot}/install-dist.tar.gz", installRoot)

        log.info("Install Complete")
    }

    def configure = {
        log.info "Configuring..."

        // Export properties for the application locally.
        PropertiesExporter.get().exportProperties(this, shell.toResource(installDest + '/swift-demo-server.properties'))

        // setup some process monitoring
        timers.schedule(timer: "processMonitor",
            repeatFrequency: params.serverMonitorFrequency ?: '30s')

        log.info "Configuration complete."
    }

    def start = {
        log.info "Starting..."
        def pid = getProcessId()
        if(pid!=null){
            shell.fail("Process is already started. Process id:${pid}")
        }
        if(isListening()){
            shell.fail("Port already in use. startPort:${startPort}")
        }

        // TODO application should have a start script which handles this.
        String classpath = "${installRootDir}:${installRootDir}/lib/tomcat-embed-core-7.0.42.jar:${installRootDir}/lib/tomcat-embed-logging-log4j-7.0.42.jar:${installRootDir}/lib/log4j-1.2.17.jar"

        String javaCmd = '$GLU_JAVA_HOME/bin/java'

        // check that java is available.
        shell.exec("${javaCmd} -version")

        // Command must run in the back ground and not cause the agent to block
        String startCommand = "${javaCmd} -classpath ${classpath} -DlogDir=${logsDir} com.ubs.swift.demo.SwiftDemoServer &"

        log.info "Starting with command ${startCommand}"
        shell.exec(redirectStderr:true, command: startCommand)

        shell.waitFor(timeout: params.startTimeout ?: '15s', heartbeat: '1s') {
            log.info("Waiting for process to start")
            return isProcessUp() && isListening()
        }
    }

    def stop = {
        log.info "Stopping"
        def pid = getProcessId()
        if (pid != null) {
            shell.exec("kill ${pid}")
            shell.waitFor(timeout: params.stopTimeout ?: '15s', heartbeat: '1s') {
                log.info("Waiting for process to terminate")
                return isProcessDown()
            }
        }
        log.info("Stop Phase Completed")
    }

    def unconfigure = {
        log.info "Stopping process monitor"
        timers.cancel(timer: "processMonitor")
    }

    def uninstall = {
        log.info "Uninstalling"
        shell.rmdirs(installDest)
    }

    /**
     * Defines the timer that will check for the server to be up and running and will act
     * according if not (change state)
     */
    def processMonitor = {
        try
        {
            log.info "Performing process monitoring"
            def up = isProcessUp()
            def listening = isListening()
            log.info "up [$up]"

            def currentState = stateManager.state.currentState
            def currentError = stateManager.state.error

            def newState = null
            def newError = null
            def forceChangeState = false

            // case when current state is running
            if (currentState == 'running') {
                if (isProcessDown()) {
                    newState = 'stopped'
                    newError = 'Server down detected. Check the log file for errors.'
                    log.warn "${newError} => forcing new state ${newState}"
                } else if (currentError && listening) {
                    // reset the error now the process is up
                    forceChangeState = true
                } else if (!currentError && !listening) {
                    newError = "Server is not listening on port ${startPort}"
                    log.warn "${newError} => leaving in state runing"
                }
            } else {
                if(up)
                {
                    newState = 'running'
                    log.info "Server up detected."
                }
            }

            if (newState || newError || forceChangeState)
                stateManager.forceChangeState(newState, newError)

            log.debug "Server Monitor: ${stateManager.state.currentState} / ${up}"
        }
        catch(Throwable th)
        {
            log.warn "Exception while running serverMonitor: ${th.message}"
            log.debug("Exception while running serverMonitor (ignored)", th)
        }
        log.info "Exit processMonitor"
    }


    private String buildRepositoryUrl() {
        String nexusUrl = "http://cft-nexus.ldn.swissbank.com:8081/nexus/service/local/artifact/maven/redirect?r=g-internal-releases-and-snapshots" +
                "&g=${group}&a=${artifact}&v=${projectVersion}&e=tar.gz&c=dist"

        log.info("Download URL '${nexusUrl}'")

        return nexusUrl
    }

    private Integer getProcessId() {
        def output = shell.exec(redirectStderr: true, command: "ps -ef | grep 'SwiftDemoServer' | grep -v 'grep' | awk '{ print \$2 }'")
        log.info("Processid '${output}'");

        if (output == '') return null

        return output as int
    }

    private boolean isProcessUp()
    {
        return !isProcessDown()
    }

    private boolean isProcessDown()
    {
        return getProcessId() == null
    }

    private boolean isListening()
    {
        def listening = shell.listening('localhost', startPort)
        log.info("Process is listening on port ${startPort} = ${listening}")
        return listening
    }
}
