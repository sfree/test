import org.linkedin.glu.agent.api.ShellExecException

/**
 * This is a glu script managing the Cassandra server
 */
class CassandraServerScript extends BaseServerGluScript {
    transient def localDir = "/sbclocal/apps/f35"

    def installDir
    def appDir
    def logsDir
    def confDir

    def install = {
        baseServerInstall()

        installDir = "${baseInstallDir}/${group}/${artifact}/${env}"
        appDir = localDir + "/" + artifact
        logsDir = localDir + "/logs/" + artifact
        confDir = "${appDir}/cassandra-conf-${startPort}"

        rootShell.mkdirs(appDir)
        rootShell.mkdirs(logsDir)
        backUpConfFiles()
        rootShell.mkdirs(confDir)
        copyConfFiles()
        createYamlFile()
        createEnvConfShell()
        createLogProperties()
        createCassandraTopology()
    }

    def stop = {
        def pidFile = "${appDir}/cassandra-conf-${startPort}/cassandra-${startPort}.pid"

        def stopCommand = "${installDir}/bin/stop ${pidFile}"
        log.info "stop command [${stopCommand}]"

        try {
            shell.exec(stopCommand)
        } catch (ShellExecException e) {
            log.info('stop command failed', e)
        }
    }

    protected String getStartCommand() {

        def javaHome = params.javaHome

        def pidFile = "${appDir}/cassandra-conf-${startPort}/cassandra-${startPort}.pid"

        return "export JAVA_HOME=${javaHome} && export CASSANDRA_CONF=${appDir}/cassandra-conf-${startPort} && ${installDir}/bin/cassandra -p ${pidFile}"
    }

    protected String getStartTimeout() {
        '2m'
    }

    protected void copyConfFiles() {
        try{
            shell.exec("cp -r ${installDir}/conf/*  ${appDir}/cassandra-conf-{startPort}")
        } catch (ShellExecException e) {
            log.info('copy conf folder command failed', e)
        }
    }

    protected boolean isRunning() {
        def pidFile = "${appDir}/cassandra-conf-${startPort}/cassandra-${startPort}.pid"

        def checkRunningCommand = "${installDir}/bin/cassandra-status.sh ${pidFile}"

        log.info "checking server is up with command [${checkRunningCommand}]"

        boolean up = false
        try {
            shell.exec(checkRunningCommand)
            return true
        } catch (ShellExecException e) {
            return false
        }
    }

    protected void backUpConfFiles() {
        def confFolder = new File("${confDir}")


        if(confFolder.exists()) {
            try {
                shell.exec("mv ${confDir} ${confDir}-bck")
            } catch (ShellExecException e) {
                log.info('move command failed', e)
            }
        }
    }

    protected void createCassandraTopology() {
        def cassandraTopology = params.cassandraTopology

        def templateCassandraTopology = "${installDir}/conf/cassandra-topology.properties-template"

        def tempValue = cassandraTopology.replaceAll(',', '\n')

        def fileContent = readFile(templateCassandraTopology)

        fileContent = replaceToken(fileContent, 'cassandra.topology', tempValue)

        writeFile("${confDir}/cassandra-topology.properties", fileContent)
    }

    protected void createYamlFile() {
        def yamlFile = params.yamlFile
        def rpcAddress = params.rpcAddress
        def clusterName = params.clusterName
        def initialToken = params.initialToken
        def dataFileDirectory = params.dataFileDirectory
        def seeds = params.seeds
        def listenAddress = params.listenAddress
        def storagePort = params.storagePort
        def sslStoragePort = params.sslStoragePort
        def host = shell.env["glu.agent.hostname"]

        def templateYaml = yamlFile?.trim() ? yamlFile : "${installDir}/conf/cassandra.yaml-template"
        def fileContent = readFile(templateYaml)

        fileContent = replaceToken(fileContent, 'cassandra.rpc.address', rpcAddress, host)

        fileContent = replaceToken(fileContent, 'cassandra.rpc.port', startPort)

        if(clusterName?.trim())
            fileContent = replaceToken(fileContent, 'cassandra.cluster.name', clusterName)

        fileContent = replaceToken(fileContent, 'cassandra.token', initialToken)

        if(dataFileDirectory?.trim())
            fileContent = replaceToken(fileContent, 'cassandra.data.file.dir', dataFileDirectory)

        if(seeds?.trim())
            fileContent = replaceToken(fileContent, 'cassandra.cluster.seeds', seeds)

        fileContent = replaceToken(fileContent, 'cassandra.listen.address', listenAddress, host)

        fileContent = replaceToken(fileContent, 'cassandra.storage.port', storagePort, '7001')

        fileContent = replaceToken(fileContent, 'cassandra.ssl.storage.port', sslStoragePort, '7002')

        def filePath = "${confDir}/cassandra.yaml"
        writeFile(filePath, fileContent)
    }

    protected void createEnvConfShell() {
        def envConfFile = params.envConfFile
        def jmxPort = params.jmxPort
        def heapMaxSize = params.heapMaxSize
        def heapYoungGenSize = params.heapYoungGenSize

        def templateEnvFile = envConfFile?.trim() ? envConfFile : "${installDir}/conf/cassandra-env.sh-template"
        def fileContent = readFile(templateEnvFile)

        fileContent = replaceToken(fileContent, 'cassandra.jmx.port', jmxPort, '8081')

        fileContent = replaceToken(fileContent, 'cassandra.max.heap.size', heapMaxSize, '8G' )

        fileContent = replaceToken(fileContent, 'cassandra.heap.newsize', heapYoungGenSize, '1G' )

        def envFilePath = "${confDir}/cassandra-env.sh"
        writeFile(envFilePath, fileContent)
    }

    protected void createLogProperties() {
        def templateLogFile = "${installDir}/conf/log4j-server.properties-template"
        def fileContent = readFile(templateLogFile)
        fileContent = replaceToken(fileContent, 'cassandra.log.file', "${logsDir}/system-${startPort}.log")
        def logFilePath = "${confDir}/log4j-server.properties"
        writeFile(logFilePath, fileContent)
    }

    private String readFile(String fileWithPath) {
        def file = new File(fileWithPath)
        return file.text
    }

    private void writeFile(String fileWithPath, String content) {
        def file = new File(fileWithPath)
        if(file.exists())
            file.delete();
        def printWriter = file.newPrintWriter()
        printWriter.write(content)
        printWriter.flush()
        printWriter.close()
    }

    private String replaceToken(String content, String token, String value) {
        return content.replaceAll('\\$\\{__' + token + '__\\}', value)
    }

    private String replaceToken(String content, String token, String value, String defaultValue) {
        return replaceToken(content, token, value?.trim() ? value: defaultValue)
    }
}
