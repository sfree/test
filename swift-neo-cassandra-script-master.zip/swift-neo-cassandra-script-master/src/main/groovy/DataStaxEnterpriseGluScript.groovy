import org.linkedin.glu.agent.api.ShellExecException

import com.ubs.swift.properties.PropertiesExporter

/**
 * This is a glu script managing the Datastax Enterprise server
 */
class DataStaxEnterpriseGluScript extends BaseServerGluScript {
    transient def localDir = "/sbclocal/apps/f35"

    def installDir
    def appDir
    def logsDir
    def confDir
    def runDir

    def pidFile
    transient Map<String, String> properties
    def clusterId

    def logFile
    def jmxPasswordFilePath
    def jmxAccessFilePath
    def templatesFilePath
    def install = {
        baseServerInstall()

        installDir = "${baseInstallDir}/${group}/${artifact}/${env}"
        appDir = localDir + "/" + artifact
        logsDir = localDir + "/logs/" + artifact
        confDir = appDir + "/" + "cassandra-conf-${startPort}"
        runDir = "${installDir}/DSE"

        logFile="${logsDir}/system-${startPort}.log"
        jmxPasswordFilePath = "${confDir}/jmx-password.properties"
        jmxAccessFilePath="${confDir}/jmx-access.properties"
        templatesFilePath="${installDir}/templates"
        rootShell.mkdirs(appDir)
        rootShell.mkdirs(logsDir)

        linkToDSEVersion()
    }

    def stop = {
        def fileContent = readFile("${pidFile}")

        def javaHome = params.javaHome

        def stopCommand = "export JAVA_HOME=${javaHome} && export CASSANDRA_CONF=${confDir} && ${runDir}/bin/dse cassandra-stop -p ${fileContent} && ${runDir}/datastax-agent/bin/stop-datastax-agent"

        log.info "stop command [${stopCommand}]"

        try {
            shell.exec(stopCommand)
        } catch (ShellExecException e) {
            log.info('stop command failed', e)
        }
    }

    private void linkToDSEVersion(){
        def dseVersion = readFile("${installDir}/version")
        shell.exec( "tar -zxvf ${installDir}/DSE-${dseVersion}.tar.gz -C ${installDir} && ln -s ${installDir}/DSE-${dseVersion} ${runDir}")
    }

    protected String getStartCommand() {
        populateZookeeperProperties()
        backUpConfFiles()
        rootShell.mkdirs(confDir)
        copyConfFiles()
        createJmxPasswordFile()
        createJmxAccessFile()
        createYamlFile()
        createEnvConfShell()
        createLogProperties()
        createCassandraTopology()
        createDSEAgentConf()
        createDSECommandScirpt()
        createStopAgentCommandScript()
        def javaHome = params.javaHome
        pidFile =  "${confDir}/cassandra-${startPort}.pid"
        return "export JAVA_HOME=${javaHome} && export CASSANDRA_CONF=${confDir} && ${runDir}/bin/dse cassandra -p ${pidFile} &&  ${runDir}/datastax-agent/bin/datastax-agent"
    }

    protected String getStartTimeout() {
        '10m'
    }

    protected boolean isRunning() {
        pidFile =  "${appDir}/cassandra-conf-${startPort}/cassandra-${startPort}.pid"
        def checkRunningCommand = "${runDir}/bin/dse-status.sh ${pidFile}"
        log.info "checking server is up with command [${checkRunningCommand}]"
        boolean up = false
        try {
            shell.exec(checkRunningCommand)
            return true
        } catch (ShellExecException e) {
            return false
        }
    }

    private void populateZookeeperProperties() {
        properties = PropertiesExporter.get().retrieveProperties(this)
        clusterId = params.clusterInstance
    }

    protected void backUpConfFiles() {
        def confFolder = new File("${confDir}")
        if(confFolder.exists()){
            try {
                shell.exec("mkdir -p ${confDir}-bck & mv ${confDir}/* ${confDir}-bck")
            }catch (ShellExecException e) {
                log.info('stop command failed', e)
            }
        }
    }

    private void createDSECommandScirpt() {

        def jmxUsername
        def jmxPassword
        boolean isAuthenticate=true
        try {
            jmxUsername = properties.getAt("${clusterId}.jmxUsername")
            jmxPassword = properties.getAt("${clusterId}.jmxPassword")
        } catch (Exception e) {
            log.info('read jmx authentication in properties failed ', e)
            isAuthenticate=false
        }

        if(jmxUsername==null||jmxPassword==null){
            log.info('no jmx authentication in properties , jmxUsername:'+jmxUsername+'  ,  jmxPassword:'+jmxPassword)
            isAuthenticate=false
        }

        def authenticateLine=""

        if(isAuthenticate){
            authenticateLine="-u ${jmxUsername} -pw ${jmxPassword}"
        }

        def templateFile = "${templatesFilePath}/bin/dse-template"
        def fileContent = readFile(templateFile)

        fileContent = replaceToken(fileContent, 'jmx.authenticate.line', authenticateLine, '')


        writeFile("${runDir}/bin/dse", fileContent)

        shell.exec( "chmod 755 ${runDir}/bin/dse");
    }

    private void createStopAgentCommandScript() {

        def templateFile = "${templatesFilePath}/datastax-agent/bin/stop-datastax-agent-template"
        def fileContent = readFile(templateFile)

        def stopAgentScriptFile = "${runDir}/datastax-agent/bin/stop-datastax-agent"
        writeFile(stopAgentScriptFile, fileContent)

        shell.exec( "chmod 755 ${stopAgentScriptFile}");
    }

    private void createDSEAgentConf() {
        def opscenterHost = properties.getAt("${clusterId}.opscenterHost")
        def templateAddressFile = "${templatesFilePath}/datastax-agent/conf/address.yaml-template"
        def fileContent = readFile(templateAddressFile)

        def yamlFilePath = "${confDir}/cassandra.yaml"

        fileContent = replaceToken(fileContent, 'cassandra.opscenter.host', opscenterHost, '')

        fileContent = replaceToken(fileContent, 'cassandra.log.location', logFile, '')
        fileContent = replaceToken(fileContent, 'cassandra.install.location', runDir, '')
        fileContent = replaceToken(fileContent, 'cassandra.conf', yamlFilePath, '')

        def addressFilePath = "${runDir}/datastax-agent/conf/address.yaml"
        writeFile(addressFilePath, fileContent)
    }

    private void copyConfFiles() {
        try{
            shell.exec("cp -r ${runDir}/resources/cassandra/conf/*  ${confDir}")
        } catch (ShellExecException e) {
            log.info('stop command failed', e)
        }
    }

    private void createCassandraTopology() {
        def cassandraTopology = properties.getAt("${clusterId}.cassandraTopology")
        def templateCassandraTopology = "${templatesFilePath}/resources/cassandra/conf/cassandra-topology.properties-template"
        def tempValue = cassandraTopology.replaceAll(',', '\n')
        def fileContent = readFile(templateCassandraTopology)
        fileContent = replaceToken(fileContent, 'cassandra.topology', tempValue)
        def cassandraTopologyFilePath = "${confDir}/cassandra-topology.properties"
        writeFile(cassandraTopologyFilePath, fileContent)
    }

    private void createYamlFile() {
        def clusterName = properties.getAt("${clusterId}.clusterName")
        def seeds = properties.getAt("${clusterId}.seeds")
        def storagePort = properties.getAt("${clusterId}.storagePort")
        def sslStoragePort = properties.getAt("${clusterId}.sslStoragePort")
        def initialToken = params.initialToken
        def dataFileDirectory = params.dataFileDirectory
        def host = shell.env["glu.agent.hostname"]
        def autoBootstrap = params.autoBootstrap
        def templateYaml = "${templatesFilePath}/resources/cassandra/conf/cassandra.yaml-template"
        def fileContent = readFile(templateYaml)

        def authenticator = properties.getAt("${clusterId}.authenticator")
        def authorizer = properties.getAt("${clusterId}.authorizer")


        fileContent = replaceToken(fileContent, 'cassandra.rpc.address', host)

        fileContent = replaceToken(fileContent, 'cassandra.rpc.port', startPort)

        fileContent = replaceToken(fileContent, 'cassandra.cluster.name', clusterName)

        fileContent = replaceToken(fileContent, 'cassandra.token', initialToken)

        if(dataFileDirectory?.trim())
            fileContent = replaceToken(fileContent, 'cassandra.data.file.dir', dataFileDirectory)

        if(seeds?.trim())
            fileContent = replaceToken(fileContent, 'cassandra.cluster.seeds', seeds)

        fileContent = replaceToken(fileContent, 'cassandra.listen.address', host)

        fileContent = replaceToken(fileContent, 'cassandra.storage.port', storagePort, '7001')

        fileContent = replaceToken(fileContent, 'cassandra.ssl.storage.port', sslStoragePort, '7002')

        fileContent = replaceToken(fileContent, 'cassandra.auto.bootstrap', autoBootstrap, 'true' )

        if(authenticator?.trim())
            fileContent = replaceToken(fileContent, 'cassandra.authenticator', authenticator)

        if(authorizer?.trim())
            fileContent = replaceToken(fileContent, 'cassandra.authorizer', authorizer)


        def yamlFilePath = "${confDir}/cassandra.yaml"

        writeFile(yamlFilePath, fileContent)
    }

    private void createEnvConfShell() {

        def heapMaxSize = params.heapMaxSize
        def heapYoungGenSize = params.heapYoungGenSize

        def jmxPort = properties.getAt("${clusterId}.jmxPort")
        def templateEnvFile = "${templatesFilePath}/resources/cassandra/conf/cassandra-env.sh-template"
        def fileContent = readFile(templateEnvFile)

        fileContent = replaceToken(fileContent, 'cassandra.jmx.port', jmxPort, '8081')

        fileContent = replaceToken(fileContent, 'cassandra.max.heap.size', heapMaxSize, '8G' )

        fileContent = replaceToken(fileContent, 'cassandra.heap.newsize', heapYoungGenSize, '1G' )
        fileContent = replaceToken(fileContent, 'cassandra.jmx.password.file', jmxPasswordFilePath)
        fileContent = replaceToken(fileContent, 'cassandra.jmx.access.file', jmxAccessFilePath)

        def envConfigFilePath = "${confDir}/cassandra-env.sh"
        writeFile(envConfigFilePath, fileContent)
    }

    private void createLogProperties() {
        def templateLogFile = "${templatesFilePath}/resources/cassandra/conf/log4j-server.properties-template"
        def fileContent = readFile(templateLogFile)
        fileContent = replaceToken(fileContent, 'cassandra.log.file', logFile)
        def logFilePath = "${confDir}/log4j-server.properties"
        writeFile(logFilePath, fileContent)
    }

    private void createJmxPasswordFile() {

        def jmxUsername = properties.getAt("${clusterId}.jmxUsername")
        def jmxPassword = properties.getAt("${clusterId}.jmxPassword")
        def templateFile = "${templatesFilePath}/resources/cassandra/conf/jmx-password.properties-template"
        def fileContent = readFile(templateFile)

        fileContent = replaceToken(fileContent, 'cassandra.jmx.username', jmxUsername, 'admin')
        fileContent = replaceToken(fileContent, 'cassandra.jmx.password', jmxPassword, 'password')

        writeFile(jmxPasswordFilePath, fileContent)

        shell.exec( "chmod 600 ${jmxPasswordFilePath}")
    }

    private void createJmxAccessFile() {

        def jmxUsername = properties.getAt("${clusterId}.jmxUsername")

        def templateFile = "${templatesFilePath}/resources/cassandra/conf/jmx-access.properties-template"
        def fileContent = readFile(templateFile)

        fileContent = replaceToken(fileContent, 'cassandra.jmx.username', jmxUsername, 'admin')

        writeFile(jmxAccessFilePath, fileContent)
    }



    private String readFile(String fileWithPath) {
        def file = new File(fileWithPath)
        return file.text
    }

    private void writeFile(String fileWithPath, String content) {
        def file = new File(fileWithPath)
        if(file.exists())
            file.delete();
        def printWriter = file.newPrintWriter()
        printWriter.write(content)
        printWriter.flush()
        printWriter.close()
    }

    private String replaceToken(String content, String token, String value) {
        return content.replaceAll('\\$\\{__' + token + '__\\}', value)
    }

    private String replaceToken(String content, String token, String value, String defaultValue) {
        return replaceToken(content, token, value?.trim() ? value: defaultValue)
    }
}
