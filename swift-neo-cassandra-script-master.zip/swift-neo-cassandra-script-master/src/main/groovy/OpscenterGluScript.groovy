import org.linkedin.glu.agent.api.ShellExecException
import com.ubs.swift.properties.PropertiesExporter

/**
 * This is a glu script managing the deployment of OpsCenter
 */

class OpscenterGluScript extends BaseServerGluScript {
    transient def localDir = "/sbclocal/apps/f35"

    def installDir
    def appDir
    def confDir
    def pidFile
    def logsDir
    transient Map<String, String> properties

    def install = {
        baseServerInstall()

        installDir = "${baseInstallDir}/${group}/${artifact}/${env}"
        appDir = "${localDir}/${artifact}"
       
        confDir = "${appDir}/conf"

        rootShell.mkdirs(appDir)
        rootShell.mkdirs("${appDir}/conf")
        rootShell.mkdirs("${appDir}/conf/clusters")
        rootShell.mkdirs("${appDir}/conf/event-plugins")

        logsDir = localDir + "/logs/" + artifact
        log.info("Get log path [${logsDir}]")
        rootShell.mkdirs(logsDir)       

        unTarFile()
    }

    def stop = {
    	pidFile = "${appDir}/twistd.pid"
        def fileContent = readFile(pidFile)
        if (fileContent != null) {
            try {
                shell.exec("kill ${fileContent}")
            } catch (ShellExecException e) {
                log.info("Cannot stop the process ${fileContent}")
            }
        }
        log.info "opscenter has already stopped"
    }

    protected String getStartCommand() {
        populateZookeeperProperties()
        clearClusterAndEmailFiles()
        copyConfFiles()
        createEnvConfigFile()
        createClusterFile()
        createEmailConfigFile()

        def path = System.getenv('PATH')
        def pythonPath = properties.getAt("pythonPath")

        def startCommand = "export OPSCENTERD_CONFIG_DIR=${confDir} &&" +
                "export PATH=${path}:${pythonPath} &&" +
                "${installDir}/opscenter/bin/opscenter"

        return startCommand
    }

    private void populateZookeeperProperties() {
        properties = PropertiesExporter.get().retrieveProperties(this)
        if (properties) {
            log.info("zookeeper properties is not null")
        }
    }

    protected boolean isRunning() {
        pidFile = "${appDir}/twistd.pid"
        def checkRunningCommand = "${installDir}/opscenter/bin/opscenter-status.sh ${pidFile}"

        log.info "checking server is up with command [${checkRunningCommand}]"

        try {
            shell.exec(checkRunningCommand)
            return true
        } catch (ShellExecException e) {
            return false
        }
    }

    protected void unTarFile() {
        def opsCenterVersion = readFile("${installDir}/version")
        def unTarCommand = "tar -zxvf ${installDir}/opscenter-${opsCenterVersion}.tar.gz -C ${installDir}"
        def renameCommand = "find $installDir/ -maxdepth 1 -type d -name \"opscenter*\" -exec mv {} $installDir/opscenter \\;"
        shell.exec(unTarCommand)
        shell.exec(renameCommand) //remove version info from folder
    }

    protected void clearClusterAndEmailFiles() {
        try {
            shell.exec("rm -f ${confDir}/event-plugins/email*")
        } catch (ShellExecException e) {
            log.info('rm cluster and email files failed', e)
        }
    }

    protected void copyConfFiles() {
        try {
            shell.exec("cp ${installDir}/conf/opscenterd.conf-template ${installDir}/opscenter/conf/")
            shell.exec("cp ${installDir}/conf/clusters/cluster.conf-template ${confDir}/clusters/")
            shell.exec("cp ${installDir}/conf/event-plugins/email.conf-template ${confDir}/event-plugins/")
            shell.exec("cp ${installDir}/passwd.db ${installDir}/opscenter/")
            shell.exec("cp -rf ${installDir}/bin/* ${installDir}/opscenter/bin/")
            shell.exec("cp -r ${installDir}/opscenter/conf/*  ${confDir}")
        } catch (ShellExecException e) {
            log.info('copy conf file failed', e)
        }
    }

    protected void createClusterFile() {
        def cassandraRpcPort = properties.getAt("cassandraRpcPort")
        def jmxPort = properties.getAt("jmxPort")
        def clusterName = properties.getAt("clusterName")
        def clusterNodes = properties.getAt("clusterNodes")
        def clusterConfTemplate = confDir + "/clusters/cluster.conf-template"
        def yamlPath = "/sbclocal/apps/f35/datastax-enterprise/cassandra-conf-${cassandraRpcPort}/cassandra.yaml"
        def jmxUserName = properties.getAt("jmxUserName")
        def jmxPassword = properties.getAt("jmxPassword")
        def cassandraUserName = properties.getAt("cassandraUserName")
        def cassandraPassword = properties.getAt("cassandraPassword")
        def cassandraInstallDir = properties.getAt("cassandraInstallDir")
        log.info("Get [${cassandraRpcPort}], [${jmxPort}], [${clusterName}], [${clusterNodes}], [${jmxUserName}], [${jmxPassword}], [${cassandraInstallDir}], [${cassandraUserName}], [${cassandraPassword}] from master.properties")

        def clusterFile = readFile(clusterConfTemplate)

        clusterFile = replaceToken(clusterFile, 'cassandra.rpc.port', cassandraRpcPort)
        clusterFile = replaceToken(clusterFile, 'cassandra.jmx.port', jmxPort,'8081')
        clusterFile = replaceToken(clusterFile, 'cluster.seed.hosts', clusterNodes)
        clusterFile = replaceToken(clusterFile, 'cassandra.yaml.path', yamlPath)
        clusterFile = replaceToken(clusterFile, 'opscenter.log.path', logsDir)
        clusterFile = replaceToken(clusterFile, 'jmx.username', jmxUserName)
        clusterFile = replaceToken(clusterFile, 'jmx.password', jmxPassword)
        clusterFile = replaceToken(clusterFile, 'cassandra.username', cassandraUserName)
        clusterFile = replaceToken(clusterFile, 'cassandra.password', cassandraPassword)
        clusterFile = replaceToken(clusterFile, 'cassandra.install.dir', cassandraInstallDir)

        clusterName = clusterName.replaceAll(' ','_')
        writeFile("${confDir}/clusters/${clusterName}.conf", clusterFile)
        log.info("successfully write clusterFile [${clusterFile}]")
    }

    protected void createEnvConfigFile() {
        def opscenterd = confDir + "/opscenterd.conf"
        def opscenterdTemplate = confDir +"/opscenterd.conf-template"
        def fileContent = readFile(opscenterdTemplate)
        def serverAddress = shell.env["glu.agent.hostname"]

        log.info('Looking up startPort')
        log.info("Get startPort [${startPort}] from artifact argument")

        fileContent = replaceToken(fileContent, 'opscenter.port', startPort)
        fileContent = replaceToken(fileContent, 'opscenter.install.server', serverAddress)
        fileContent = replaceToken(fileContent, 'opscenter.log.path', logsDir)

        writeFile(opscenterd, fileContent)
        log.info("Successfully write Env fileContent [${fileContent}]")
    }

    protected void createEmailConfigFile() {
        def emailConfTemplate = confDir + "/event-plugins/email.conf-template"
        def emailSmtpHost = properties.getAt("emailSmtpHost")
        def emailSmtpPort = properties.getAt("emailSmtpPort")
        def emailSmtpUser = properties.getAt("emailSmtpUser")
        def emailSmtpPass = properties.getAt("emailSmtpPass")
        def emailFromAddress = properties.getAt("emailFromAddress")
        def emailToAddresses = properties.getAt("emailToAddresses")
        def toAddresses = emailToAddresses.split(',')
        log.info("Get [${emailSmtpHost}], [${emailSmtpPort}], [${emailSmtpUser}], [${emailSmtpPass}], [${emailFromAddress}], [${emailToAddresses}] from master.properties")

        def index = 0
        for (toAddress in toAddresses) {
            if (toAddress) {
                def fileContent = readFile(emailConfTemplate)
                def emailConf
                if (index == 0) {
                    emailConf = confDir + "/event-plugins/email.conf"
                } else {
                    emailConf = confDir + "/event-plugins/email${index}.conf"
                }

                fileContent = replaceToken(fileContent, 'email.smtp.host', emailSmtpHost)
                fileContent = replaceToken(fileContent, 'email.smtp.port', emailSmtpPort)
                fileContent = replaceToken(fileContent, 'email.smtp.user', emailSmtpUser)
                fileContent = replaceToken(fileContent, 'email.smtp.pass', emailSmtpPass)
                fileContent = replaceToken(fileContent, 'email.from.address', emailFromAddress)
                fileContent = replaceToken(fileContent, 'email.to.address', toAddress)
                writeFile(emailConf, fileContent)
                log.info("Successfully write email fileContent [${fileContent}]")

                index += 1
            }
        }
    }

    private String readFile(String fileWithPath) {
        def file = new File(fileWithPath)
        return file.text
    }

    private void writeFile(String fileWithPath, String content) {
        def file = new File(fileWithPath)
        if (file.exists()) {
            file.delete();
        }
        def printWriter = file.newPrintWriter()
        printWriter.write(content)
        printWriter.flush()
        printWriter.close()
    }

    private String replaceToken(String content, String token, String value) {
        return content.replaceAll('\\$\\{__' + token + '__\\}', value)
    }

    private String replaceToken(String content, String token, String value, String defaultValue) {
        return replaceToken(content, token, value?.trim() ? value: defaultValue)
    }

    protected String getStartTimeout() { '2m' }
}
