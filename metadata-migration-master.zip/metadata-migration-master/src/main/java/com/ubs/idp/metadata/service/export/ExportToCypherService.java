package com.ubs.idp.metadata.service.export;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.neo4j.graphdb.Label;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;
import org.neo4j.graphdb.RelationshipType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.idp.metadata.model.enums.RELATIONSHIP_TYPE;

/**
 * Defines the interface for exporting a data source
 * to a cypher script
 * 
 * @author loverids
 *
 */
public abstract class ExportToCypherService
{
	protected final static Logger logger = LoggerFactory.getLogger(ExportToCypherService.class);

	/**
	 * The maximum number of nodes to fetch at a time when doing a database dump
	 */
	private final static int MAX_NODE_FETCH = 1500;
	
	/**
	 * There is a limit to how many commands can be executed in a single
	 * cypher statement before a stack overflow error occurs so we
	 * limit it here
	 */
	private int CYPHER_COMMAND_LIMIT = 200;
	
	/**
	 * Holds the neo4j node ids of all nodes that have already been added to
	 * the export script during a dump. This prevents us from creating duplicates
	 */
	private List<Long> nodesAlreadyCreated;

	/**
	 * Holds the neo4j relationships that have already been added to
	 * the export script during a dump. This prevents us from creating duplicates.
	 * Stored in the format <startNodeId>-<endNodeId> and vice-versa
	 */
	private List<String> relationshipsAlreadyCreated;

	
	/**
	 * Returns all nodes of the specified label, bounded by the offset and limit
	 * @param offset
	 * @param limit
	 * @param labelType
	 * @return
	 */
	public abstract List<Node> getAllNodesOfLabelType(int offset, int limit, String labelType);
	
	/**
	 * Returns all attribute nodes for the specified dataset id
	 * @param datasetId
	 * @return
	 */
	public abstract List<Node> getAllAttributesForDataset(String datasetId);

	/**
	 * Returns the physical key node for the specified dataset id
	 * @param datasetId
	 * @return
	 */
	public abstract Node getKeyForDataset(String datasetId);
	
	/**
	 * Returns a map keyed by attribute nodes that map to the corresponding PhysicalKeyElement
	 * node. The map contains all attribtues and physical key elements for the specified physical key
	 * @param keyId
	 * @return
	 */
	public abstract Map<Node,Node> getAttributesAndKeyElementsForKey(String keyId);


	/**
	 * Returns all relationships associated with the specified attribute belonging to
	 * the specified dataset
	 * @param datasetId
	 * @param attributeId
	 * @return
	 */
	public abstract List<Relationship> getAllRelationshipsForAttribute(String datasetId, String attributeId);

	/**
	 * Returns all relationships bounded by the offset and limit
	 * @param offset
	 * @param limit
	 * @return
	 */
	public abstract List<Relationship> getAllRelationships(int offset, int limit);

	
	/**
	 * Returns a list of maps containing nodes for all joined attribtues. 
	 * Map is keyed as follows:
	 * 
	 * d1 = Left dataset
	 * a1 = Left attribute
	 * d2 = Right dataset
	 * a2 = Right attribute
	 * @return
	 */
	public abstract List<Map<String,Node>> getAllJoinedAttributes();
	
	/**
	 * Exports the datasource to the file as cypher	
	 * @param file
	 * @throws IOException
	 */
	public void exportToFileAsCypher( File file ) throws IOException
	{
		logger.info("Starting export to file {}",file);	
		
		FileOutputStream fos = new FileOutputStream(file);		
		exportToStreamAsCypher( fos);				
		fos.close();		
		
		logger.info("Finished export to file {}",file);
	}

	/**
	 * Generates the cypher export from the datasource and returns it
	 * as text
	 * @return
	 * @throws IOException
	 */
	public String getNeo4jDatabaseDumpAsCypher() throws IOException
	{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		exportToStreamAsCypher( baos);
		baos.close();
		
		return baos.toString();
	}
	
	/**
	 * Exports the datasource to stream as a cypher
	 * @param file
	 * @throws IOException
	 */
	@Transactional
	public void exportToStreamAsCypher( OutputStream os )
	{
		logger.info("Starting export");	

		PrintStream ps = new PrintStream (os);
		nodesAlreadyCreated = new ArrayList<Long>();
		relationshipsAlreadyCreated = new ArrayList<String>();

		// First do an explicit export of datasets and attributes
		logger.info("Exporting datasets, attributes and views");
		writeAllDatasetsAndViewsToStream(ps);
		
		// Now export all other nodes and relationships
		logger.info("Exporting remaining nodes and relationships");
		writeRemainingRelationshipsToStream( ps);
		
		ps.close();

		logger.info("Finished export");
	}

	/**
	 * As attributes can have the same id property, it is better to export the
	 * datasets and views explicitly using cypher with variables as trying to create
	 * them generically involves doing a cypher match on the attribute then creating 
	 * a relationship with the dataset or view e.g.:
	 * 
	 * MATCH (n1:Dataset:PhysicalDataset:_PhysicalDataset {id:"BONDTL.IDP"}),(n2:PhysicalAttribute:_PhysicalAttribute {id:"tL.ubsId"})
	 * CREATE (n1)-[:OWNS]->(n2);
	 *
	 * If there are more than one attributes with id="tL.ubsId", this match won't work. So instead we create it altogether in one statement:
	 * 
	 * CREATE (pd:Dataset:PhysicalDataset:_PhysicalDataset {id:"MartiniCDRStatic",name:"MartiniCDRStatic",tableId:"MartiniCDRStatic",delimiter:"	",namespaces:""})
	 * CREATE (a0:PhysicalAttribute:_PhysicalAttribute {id:"tL.ubsId",name:"tL.ubsId",position:"80",queryable:"true",active:"true",derived:"false"})
	 * CREATE pd-[:OWNS]->a0;
	 * 
	 * 
	 */
	private void writeAllDatasetsAndViewsToStream( PrintStream ps )
	{
		String cypher = "";
		
		// Get all our nodes
		int offset = 0;
		List<Node> nodes = new ArrayList<Node>();

		// Export all the datasets first so that we create the attributes
		do
		{
			nodes = getAllNodesOfLabelType(offset,MAX_NODE_FETCH,"PhysicalDataset");
			for (Node datasetNode : nodes)
			{
				logger.debug("Extracting " + datasetNode.getProperty("id") );
				if (shouldIgnoreNodeForDump(datasetNode)) 
				{
					logger.debug("Already created node with id " + datasetNode.getId() + " ignoring " + datasetNode.getProperty("id"));
					continue;
				}
				
				// Fetch the cypher for generating the datasets, attributes and views
				cypher = generateCypherForDatasetAndOwningAttributes(datasetNode);
				
				ps.println(cypher);			
			}
			offset += nodes.size();

			if( logger.isDebugEnabled() && nodes.size() > 0 )
			{
				logger.debug("Exported " + offset + " dataset nodes");
			}


		}while( nodes.size() > 0 );
		
		// When all datasets and attributes have been created, createthe join releationships	
		cypher = generateCypherForAllJoinedAttributes();
		ps.println(cypher);	
	}
	
	/**
	 * Iterates all relationships in the datasource and generates cypher for them. If
	 * either the start node or end node has not been created it will generate a create
	 * command for them, otherwise it will create a match.
	 * 
	 * 
	 * 
	 * @param ps
	 * @return
	 */
	private void writeRemainingRelationshipsToStream( PrintStream ps )
	{
		String cypher = "";
		int commandCount = 1;
		int varCounter = 0;
		int offset = 0;
		String varPrefix = "_";
		Map<Long,String> nodeIdsInCurrentStatement = new HashMap<Long,String>();

		cypher = addBlockCommentToCypher(cypher,"Create the remaining nodes and relationships that havent been created already" );
		
		List<Relationship> relationships = new ArrayList<Relationship>();
		do
		{
			relationships = getAllRelationships(offset,MAX_NODE_FETCH);				
			for (Relationship relationship : relationships)
			{
				Node startNode = relationship.getStartNode();
				Node endNode = relationship.getEndNode();
				
				logger.debug("Extracting " + startNode.getProperty("id")  + "-[:" + relationship.getType().name() + "]->" + endNode.getProperty("id") );
				
				if( relationshipsAlreadyCreated.contains( startNode.getId() + ":"+relationship.getType().name()+":" + endNode.getId()  ) )
				{
					continue;
				}

				
				List<Node> nodes = Arrays.asList(startNode,endNode);	
				String startNodeVarId = "";
				String endNodeVarId = "";
				
				// Create or match start and end nodes
				for( Node node: nodes )
				{					
					String nodeCounterId = varPrefix + varCounter;
					
					// Create it if its not been created already
					if( !nodesAlreadyCreated.contains(node.getId() ) )
					{
						cypher += "CREATE " +  nodeAsCypher(nodeCounterId, node,true) + "\n";
						nodesAlreadyCreated.add(node.getId());
						commandCount ++;
						
						nodeIdsInCurrentStatement.put(node.getId(),nodeCounterId);
					}
					// If the view has previously been created then create amatch for it instead
					else
					{
						// Have we already got a match command for this view in the statement
						nodeCounterId = nodeIdsInCurrentStatement.get(node.getId());
						if( nodeCounterId == null )
						{
							// No, so create a new match for it it
							nodeCounterId = varPrefix + varCounter;
							cypher += "MATCH " +  nodeAsCypher(nodeCounterId, node,false) + "\n";
							nodeIdsInCurrentStatement.put(node.getId(),nodeCounterId);
							
						}
					}
					
					if( node.equals(startNode) )startNodeVarId = nodeCounterId;
					if( node.equals(endNode) )endNodeVarId = nodeCounterId;
						
					varCounter++;
				}
				
				
				cypher += convertRelationshipToCypherInsert(startNodeVarId, endNodeVarId,relationship);
				commandCount ++;
				
				// If we reach the limit of cypher commands per statement
				// we need to close the statement then re match the datasetnode
				if( commandCount > CYPHER_COMMAND_LIMIT )
				{
					if( cypher.contains(";") )
					{
						String lastStatement = cypher.substring(cypher.lastIndexOf(";") + 1 ).trim();
						lastStatement = sortCypherSoMatchesComeFirst( lastStatement );
						cypher = cypher.substring(0, cypher.lastIndexOf(";\n") + 2) + lastStatement;
					}
					else
					{
						cypher = sortCypherSoMatchesComeFirst(cypher);
					}
					cypher += ";\n";
					
					commandCount = 0;
					varCounter = 0;
					nodeIdsInCurrentStatement.clear();
				}
				
			}
			offset += relationships.size();

			if( logger.isDebugEnabled() && relationships.size() > 0 )
			{
				logger.debug("Exported " + offset + " relationships");
			}

		}while( relationships.size() > 0 );	

		
		// Need to get all commands up to the last statement and order them 
		if( cypher.contains(";") )
		{
			String lastStatement = cypher.substring(cypher.lastIndexOf(";") + 1 ).trim();
			lastStatement = sortCypherSoMatchesComeFirst( lastStatement );
			cypher = cypher.substring(0, cypher.lastIndexOf(";\n") + 2) + lastStatement;
		}
		else
		{
			cypher = sortCypherSoMatchesComeFirst(cypher);
		}
		
		
		// And close the statement
		cypher += ";\n";
		
		ps.println( cypher );
	}

	
	/**
	 * Returns true if the node has already had a CREATE command
	 * created for it
	 * 
	 * @return
	 */
	private boolean shouldIgnoreNodeForDump(Node node)
	{
		return nodesAlreadyCreated.contains(node.getId());
	}

	/**
	 * Generates the cypher for attributes that are joined to each other after
	 * both attributes have been created 
	 * @param datasetNode
	 * @return
	 */
	private String generateCypherForAllJoinedAttributes()
	{
		String cypher = "";	
		Node leftDataset = null;
		Node leftAttribute = null;
		Node rightDataset = null ;
		Node rightAttribute = null;

		logger.debug("Extracting attribute joins");
		
		List<Map<String,Node>> results = getAllJoinedAttributes();
		
		cypher = addBlockCommentToCypher(cypher,"Create the Joins between all the attributes" );

		int counter = 0;
		for( Map<String,Node> row : results )
		{									
			leftDataset = (Node)row.get("d1");
			leftAttribute = (Node)row.get("a1");
			rightDataset = (Node)row.get("d2");
			rightAttribute = (Node)row.get("a2");
						
			if( relationshipsAlreadyCreated.contains( leftAttribute.getId() + ":"+RELATIONSHIP_TYPE.JOINED_TO.toString()+":" + rightAttribute.getId()  ) )
			{
				continue;
			}
			
			cypher += "MATCH " + nodeAsCypher("d1" + counter, leftDataset, false) + "-[:OWNS]->" + nodeAsCypher("a1" + counter, leftAttribute, false) + "\n";
			cypher += "MATCH " + nodeAsCypher("d2" + counter, rightDataset, false) + "-[:OWNS]->" + nodeAsCypher("a2" + counter, rightAttribute, false) + "\n";
			cypher += "CREATE a1" + counter + "-[:"+RELATIONSHIP_TYPE.JOINED_TO.toString()+"]->a2" + counter  +"\n";
			
			addToCreatedRelationships(leftAttribute, rightAttribute, RELATIONSHIP_TYPE.JOINED_TO.toString());
			
			counter ++;
		}
					
		cypher = sortCypherSoMatchesComeFirst(cypher);
		cypher += ";";
		
		return cypher;
	}

	
	/**
	 * Creates cypher specifically for datasets and attributes. As this is the largest
	 * part of the data model, we can make the cypher script a lot more efficient by
	 * creating the cypher for these datasets explicitly
	 * @param datasetNode
	 * @return
	 */
	private String generateCypherForDatasetAndOwningAttributes( Node datasetNode )
	{
		String cypher = "";
		int commandCount = 1;
		int varCounter = 0;
		String varPrefix = "_";
		
		// A list of nodes that have already been added to the statement
		Map<Long,String> nodeIdsInCurrentStatement = new HashMap<Long,String>();

		cypher = addBlockCommentToCypher(cypher,"Create Dataset " + datasetNode.getProperty("id") + " and the following associated nodes:\nPhysicalAttribute\nPhysicalKey\nPhysicalKeyElement\nView" );

		cypher += "CREATE " +  nodeAsCypher("pd", datasetNode,true) + "\n";
		nodesAlreadyCreated.add(datasetNode.getId());
		nodeIdsInCurrentStatement.put(datasetNode.getId(),"pd");
		
		// Add any associated keys
		Node keyIdentifier = getKeyForDataset( "" + datasetNode.getProperty("id") );
		Map<Node,Node> attributesAndKeyElements = new HashMap<Node,Node>();
		
		if( keyIdentifier != null )
		{
			// If we have a key create the relationship with the dataset
			cypher += "CREATE " +  nodeAsCypher("pk", keyIdentifier,true) + "\n";
			cypher += "CREATE pd<-[:"+RELATIONSHIP_TYPE.PRIMARY_IDENTIFIER_OF+"]-pk\n";
			
			addToCreatedRelationships(keyIdentifier,datasetNode,RELATIONSHIP_TYPE.PRIMARY_IDENTIFIER_OF.toString());
			
			nodesAlreadyCreated.add(keyIdentifier.getId());					
			commandCount += 2;
			
			// And fetch key elements and attributes
			attributesAndKeyElements = getAttributesAndKeyElementsForKey( "" + keyIdentifier.getProperty("id") );
			
		}
						
		List<Node> attributeNodes = getAllAttributesForDataset("" + datasetNode.getProperty("id"));
		for(int i = 0 ; i < attributeNodes.size() ; i++ )
		{
			Node attributeNode = attributeNodes.get(i);
			
			if(nodesAlreadyCreated.contains(attributeNode.getId()) )
			{
				continue;
			}	
			
			cypher += "CREATE " +  nodeAsCypher("a" + i, attributeNode,true) + "\n";
			nodesAlreadyCreated.add(attributeNode.getId());
			commandCount ++;

			// As the attribute node is non unique (i.e. not uniquely identifiable by id alone) we need to create any neighbouring nodes and
			// relationships
			List<Relationship> attrRelationships = getAllRelationshipsForAttribute( "" + datasetNode.getProperty("id"), "" + attributeNode.getProperty("id") );
			for( Relationship relationship : attrRelationships )
			{
				// Ignore JOINED_TO and MAKES_UP as we do these separately
				if( relationship.getType().name().equals(RELATIONSHIP_TYPE.JOINED_TO.toString()) ||
					relationship.getType().name().equals(RELATIONSHIP_TYPE.MAKES_UP.toString())	)
				{
					continue;
				}
				
				Node startNode = relationship.getStartNode();
				Node endNode = relationship.getEndNode();
				Node node = null;
				
				// Ignore if this has already been created
				if( relationshipsAlreadyCreated.contains( startNode.getId() + ":" + relationship.getType().name() + ":" + endNode.getId()  ) )
				{
					continue;
				}
				
				
				String startNodeVarId = "";
				String endNodeVarId = "";
				
				if( startNode.equals(attributeNode) )
				{
					startNodeVarId = "a" + i;
					endNodeVarId = varPrefix + varCounter;
					node = endNode;					
				}
				else
				{
					startNodeVarId = varPrefix + varCounter;
					endNodeVarId = "a" + i;
					node = startNode;					
					
				}
				
				// Create or match start and end nodes
				String nodeCounterId = varPrefix + varCounter;
				
				// Create it if its not been created already
				if( !nodesAlreadyCreated.contains(node.getId() ) )
				{
					cypher += "CREATE " +  nodeAsCypher(nodeCounterId, node,true) + "\n";
					nodesAlreadyCreated.add(node.getId());
					commandCount ++;
					
					nodeIdsInCurrentStatement.put(node.getId(),nodeCounterId);
				}
				// If the view has previously been created then create amatch for it instead
				else
				{
					// Have we already got a match command for this view in the statement
					nodeCounterId = nodeIdsInCurrentStatement.get(node.getId());
					if( nodeCounterId == null )
					{
						// No, so create a new match for it it
						nodeCounterId = varPrefix + varCounter;
						cypher += "MATCH " +  nodeAsCypher(nodeCounterId, node,false) + "\n";
						nodeIdsInCurrentStatement.put(node.getId(),nodeCounterId);
					}
					
					if( startNode.equals(attributeNode) )
					{
						endNodeVarId = nodeCounterId;
					}
					else
					{
						startNodeVarId = nodeCounterId;
					}
				}
					
				varCounter++;
				
				
				cypher += convertRelationshipToCypherInsert(startNodeVarId, endNodeVarId,relationship);
				
				addToCreatedRelationships(startNode, endNode, relationship.getType().name());
				
				commandCount ++;
			}
			
			// Create relationship between dataset and attribute
			cypher += "CREATE pd-[:"+RELATIONSHIP_TYPE.OWNS.toString()+"]->a" + i + "\n";	
			addToCreatedRelationships(datasetNode, attributeNode, RELATIONSHIP_TYPE.OWNS.toString());

			commandCount ++;
										
			
			// Create key elements if this attribute forms part of the key
			if( attributesAndKeyElements.containsKey( attributeNode) )
			{
				Node keyElementNode = attributesAndKeyElements.get(attributeNode);
				cypher += "CREATE " + nodeAsCypher("pke" + i, keyElementNode,true) + "\n";
				cypher += "CREATE pk<-[:" + RELATIONSHIP_TYPE.KEY_ELEMENT_OF + "]-pke" + i + " \n";
				cypher += "CREATE pke" + i +"<-[:" + RELATIONSHIP_TYPE.MAKES_UP + "]-a"+ i + "\n";
				
				addToCreatedRelationships(keyIdentifier, keyElementNode, RELATIONSHIP_TYPE.KEY_ELEMENT_OF.toString());
				addToCreatedRelationships(attributeNode, keyElementNode, RELATIONSHIP_TYPE.MAKES_UP.toString());
				
				commandCount += 3;
				
				nodesAlreadyCreated.add(keyElementNode.getId());
			}
			
			
			// If we reach the limit of cypher commands per statement
			// we need to close the statement then re match the datasetnode
			if( commandCount > CYPHER_COMMAND_LIMIT && i < attributeNodes.size()-1 )
			{
				if( cypher.contains(";") )
				{
					String lastStatement = cypher.substring(cypher.lastIndexOf(";") + 1 ).trim();
					lastStatement = sortCypherSoMatchesComeFirst( lastStatement );
					cypher = cypher.substring(0, cypher.lastIndexOf(";\n") + 2) + lastStatement;
				}
				else
				{
					cypher = sortCypherSoMatchesComeFirst(cypher);
				}
				cypher += ";\n";

				commandCount = 0;
				varCounter = 0;
				nodeIdsInCurrentStatement.clear();
				
				cypher = addBlockCommentToCypher(cypher,"There is a limit to how many commands the engine can commit in one statement\nso we create a break here and re-match the Dataset and PhysicalKey created in the previous statment" );
				
				cypher += "MATCH " + nodeAsCypher("pd", datasetNode,false) + "\n";
				nodeIdsInCurrentStatement.put(datasetNode.getId(), "pd");
				
				if( keyIdentifier != null )
				{
					cypher += "MATCH " + nodeAsCypher("pk", keyIdentifier,false) + "\n";
					nodeIdsInCurrentStatement.put(keyIdentifier.getId(), "pk");
				}
			}
		}

		// Need to get all commands up to the last statement and order them 
		if( cypher.contains(";") )
		{
			String lastStatement = cypher.substring(cypher.lastIndexOf(";") + 1 ).trim();
			lastStatement = sortCypherSoMatchesComeFirst( lastStatement );
			cypher = cypher.substring(0, cypher.lastIndexOf(";\n") + 2) + lastStatement;
		}
		else
		{
			cypher = sortCypherSoMatchesComeFirst(cypher);
		}
		
		
		// And close the statement
		cypher += ";\n";
		
		return cypher;
	}
	
	/**
	 * Wraps a node in a cypher description without any commands associated with
	 * it e.g. (n1:Person {name:"bob"})
	 * 
	 * @param nodePrefix
	 * @param node
	 * @return
	 */
	private String nodeAsCypher(String nodePrefix, Node node, boolean includeProperties )
	{
		String cypher = "(" + nodePrefix + ":";
		Iterable<Label> labels = node.getLabels();
		Iterable<String> propNames = node.getPropertyKeys();

		// Add all the labels
		for (Label label : labels)
		{
			cypher += label.name() + ":";
		}
		cypher = cypher.substring(0, cypher.length() - 1);

		// add all the props
		if( includeProperties )
		{
			if (propNames != null && propNames.iterator().hasNext())
			{
				cypher += " {";
				for (String propName : propNames)
				{
					Object propValue = node.getProperty(propName);
					String convertedPropValue = convertPropValue( propValue );
					
					if( propValue != null )
					{
						cypher += propName + ":" + convertedPropValue + ",";
					}
				}
				cypher = cypher.substring(0, cypher.length() - 1) + "}";
			}
		}
		// Otherwise just include the "id" proeprty to use as an identifier
		else
		{
			cypher += " {id:\"" + escapeValue(node.getProperty("id").toString() ) + "\"}";
		}
		
		// Close off
		cypher += ")";

		return cypher;
	}
	
	/**
	 * Examines the class type of the object and converts it to string text to be inserted
	 * in a cypher statement. For example, if the value is a number then we dont want to
	 * wrap it in double quotes otherwise the cypher will treat the value as a string rather
	 * than a number
	 * @param value
	 * @return
	 */
	private String convertPropValue( Object value )
	{
		if( value instanceof Number )
		{
			return "" + value.toString();
		}
		else if( 	value instanceof Boolean || 
					value.toString().toLowerCase().equals("true") ||
					value.toString().toLowerCase().equals("false"))
		{
			return "" + value.toString();
		}
		else
		{
			return "\"" + escapeValue(value.toString()) + "\"";
		}
	}

	/**
	 * Takes a node and returns the cypher command to create it as a string
	 * 
	 * @param node
	 * @return
	 */
	private String convertRelationshipToCypherInsert(Relationship relationship)
	{
		String cypher = "MATCH ";

		Node n1 = relationship.getStartNode();
		Iterable<Label> n1Labels = n1.getLabels();

		Node n2 = relationship.getEndNode();
		Iterable<Label> n2Labels = n2.getLabels();

		RelationshipType type = relationship.getType();
		Iterable<String> propNames = relationship.getPropertyKeys();

		// Create the match for both nodes
		cypher += nodeAsCypher("n1", n1,false) + "," + nodeAsCypher("n2", n2,false) + "\n";

		// Create the relationship
		cypher += "CREATE (n1)-[:" + type.name();// + " {status:2}]->(n2)"

		// add all the props
		if (propNames != null && propNames.iterator().hasNext())
		{
			cypher += " {";
			for (String propName : propNames)
			{
				Object propValue = relationship.getProperty(propName);
				String convertedPropValue = convertPropValue( propValue );
				cypher += propName + ":" + convertedPropValue + ",";
			}
			cypher = cypher.substring(0, cypher.length() - 1) + "}";
		}

		// Close off
		cypher += "]->(n2);";

		return cypher;
	}

	/**
	 * Takes a relationship node and returns the cypher command to create it as a string using the specified start and end node
	 * variable names. Presumes the start node variable ID and end node variable ID already exist within the statement  
	 * @param node
	 * @return
	 */
	private String convertRelationshipToCypherInsert(String startNodeId, String endNodeId, Relationship relationship)
	{
		String cypher = "";

		Node n1 = relationship.getStartNode();

		Node n2 = relationship.getEndNode();

		RelationshipType type = relationship.getType();
		Iterable<String> propNames = relationship.getPropertyKeys();

		// Create the relationship
		cypher += "CREATE ("+startNodeId+")-[:" + type.name();

		// add all the props
		if (propNames != null && propNames.iterator().hasNext())
		{
			cypher += " {";
			for (String propName : propNames)
			{
				Object propValue = relationship.getProperty(propName);
				String convertedPropValue = convertPropValue( propValue );
				cypher += propName + ":" + convertedPropValue + ",";
			}
			cypher = cypher.substring(0, cypher.length() - 1) + "}";
		}

		// Close off
		cypher += "]->("+endNodeId+")\n";

		return cypher;
	}

	/**
	 * Escapes any characters that would cause an InvalidSyntax error when run as
	 * Cypher
	 * @param value
	 * @return
	 */
	private String escapeValue( String value )
	{
		value = value.replaceAll("\\\\", "\\\\\\\\");
		value = value.replaceAll("\"", "\\\\\"");

		return value;
	}

	/**
	 * A cypher statement needs to have all the MATCH commands executed up front
	 * so this method extracts the commands from a cypher statement (newline separated)
	 * and orders them so all the MATCH commands are first and returns the new cypher string
	 * @param cypher
	 * @return
	 */
	private String sortCypherSoMatchesComeFirst( String cypher )
	{
		List<String> commands = new LinkedList<String>(Arrays.asList(cypher.split("\n")));
		ListIterator<String> iterator = commands.listIterator();
		List<String> matchCommands = new ArrayList<String>();
		
		cypher = "";
		while( iterator.hasNext() )
		{
			String command = iterator.next();
			if( command.startsWith("MATCH") )
			{
				iterator.remove();
				if( !matchCommands.contains(command) )
				{
					matchCommands.add(command);
				}
			}
		}
		
		// Add the match commands
		for(String matchCommand: matchCommands )
		{
			cypher += matchCommand + "\n";
		}

		// Add the other commands
		for(String command: commands )
		{
			cypher += command + "\n";
		}
		
		return cypher;
	}

	/**
	 * Adds the relationship to the list of created relationships
	 * @param node1
	 * @param node2
	 * @param relationshipType
	 */
	private void addToCreatedRelationships(Node node1, Node node2, String relationshipType )
	{
		relationshipsAlreadyCreated.add(node1.getId() + ":"+ relationshipType +":" + node2.getId() );
		relationshipsAlreadyCreated.add(node2.getId() +":" + relationshipType +":" + node1.getId());
	}
	
	/**
	 * Appends the text string to the cypher as a comment block
	 * @param cypher
	 * @return
	 */
	private String addBlockCommentToCypher( String cypher, String text )
	{
		cypher += "//=========================================================================================================\n";
		for( String line : text.split("\n") )
		{
			cypher += "// " + line + "\n";
		}
		cypher += "//=========================================================================================================\n";

		return cypher;
	}
}
