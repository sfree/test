package com.ubs.idp.metadata.service.export.excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;
import org.neo4j.graphdb.RelationshipType;
import org.springframework.util.Assert;

import com.ubs.idp.metadata.model.Channel;
import com.ubs.idp.metadata.model.HTTPChannel;
import com.ubs.idp.metadata.model.JDBCChannel;
import com.ubs.idp.metadata.model.JoinRelation;
import com.ubs.idp.metadata.model.PhysicalAttribute;
import com.ubs.idp.metadata.model.PhysicalDataset;
import com.ubs.idp.metadata.model.PhysicalKey;
import com.ubs.idp.metadata.model.PhysicalKeyElement;
import com.ubs.idp.metadata.model.Role;
import com.ubs.idp.metadata.model.RulesTransformer;
import com.ubs.idp.metadata.model.Service;
import com.ubs.idp.metadata.model.ServiceImplementation;
import com.ubs.idp.metadata.model.Source;
import com.ubs.idp.metadata.model.ThinToWideTransformer;
import com.ubs.idp.metadata.model.Transformer;
import com.ubs.idp.metadata.model.View;
import com.ubs.idp.metadata.model.enums.PROTOCOL;
import com.ubs.idp.metadata.model.enums.RELATIONSHIP_TYPE;
import com.ubs.idp.metadata.model.relationships.AccessedViaRelationshipType;
import com.ubs.idp.metadata.model.relationships.JoinsRelationshipType;
import com.ubs.idp.metadata.model.relationships.KeyColumnRelationshipType;
import com.ubs.idp.metadata.model.relationships.SelectsRelationshipType;
import com.ubs.idp.metadata.service.export.ExportToCypherService;

/**
 * Implementation of the cypher exporter that converts a metadata spreadsheet 
 * into optimised cypher commands to be used as a seed for a neo4j database
 * instance
 * @author loverids
 *
 */
@org.springframework.stereotype.Service
public class ExcelExportToCypherService extends ExportToCypherService
{
	/*
	 * Worksheet names
	 */
	public final static String DATA_MODEL_SHEET_NAME = "IDPDataModel";
	public final static String SOURCE_SHEET_NAME = "Sources";
	public final static String TRANSFORMATIONS_SHEET_NAME = "Transformations";
	public final static String JOINS_SHEET_NAME = "Joins";

	/*
	 * Data model sheet
	 */
	public final static int VIEW_NAME_LINE_NUMBER = 0;
	public final static int DELIMITERS_LINE_NUMBER = 1;
	public final static int UNIONALL_LINE_NUMBER = 2;
	public final static int RELATIONS_LINE_NUMBER = 3;
	public final static int GMT_LINE_NUMBER = 4;
	public final static int DATASETS_LINE_NUMBER = 5;
	public final static int ACTIVE_COL = 0;
	public final static int QUERYABLE_COL = 1;
	public final static int DERIVED_COL = 2;
	public final static int ENTITY_COL = 3;
	public final static int DATASET_COL = 4;
	public final static int LOGICAL_ATTR_COL = 5;
	public final static int PHYSICAL_ATTR_COL = 6;
	public final static int VIEWS_START_COL = 7;
	
	/*
	 * Sources Sheet
	 */
	public final static int SOURCES_START_ROW = 1;
	public final static int SOURCES_DASTASET_COL = 0;
	public final static int SOURCES_KEY_COL = 1;
	public final static int SOURCES_ROLES_COL = 2;
	public final static int SOURCES_DELIMITER_COL = 3;
	public final static int SOURCES_URL_COL = 4;
	public final static int SOURCES_URL_DELTA_COL = 5;
	public final static int SOURCES_URL_DELTA_APPEND_COL = 6;
	public final static int SOURCES_NAMESPACE_COL = 7;
	public final static int SOURCES_SYSTEM_COL = 8;
	public final static int SOURCES_TABLEID_COL = 9;
	public final static int SOURCES_AUTH_URI_COL = 10;
	public final static int SOURCES_USERNAME_COL = 11;
	public final static int SOURCES_PASSWORD_COL = 12;
	public final static int SOURCES_DRIVERCLASS_COL = 13;
	public final static int SOURCES_SQL_COL = 14;
	public final static int SOURCES_DELTA_SQL_COL = 15;
	public final static int SOURCES_JOBS_COL = 16;
	
	/*
	 * Transformations sheet
	 */
	public final static int TRANSFORMATIONS_START_ROW = 1;
	public final static int SRC_DATASET_COL = 0;
	public final static int TRGT_DATASET_COL = 1;
	public final static int TRANSFORMER_TYPE_COL = 2;
	public final static int PRE_PROCESSOR_RULESET_COL = 3;
	public final static int RULESET_COL = 4;
	public final static int KEY_COLUMNS_COL = 5;
	public final static int PIVOT_COLUMN_COL = 6;
	public final static int ASSOCIATED_PIVOT_COLUMNS_COL = 7;
	public final static int TARGET_PIVOT_VALUES_COL = 8;

	/**
	 * Holds a list of all the nodes keys by the label type
	 */
	private Map<String,List<Node>> nodesOfLabelType = new HashMap<String,List<Node>>();

	/**
	 * Holds a list of attribute nodes keyed by dataset id
	 */
	private Map<String,List<Node>> attributesForDataset = new HashMap<String,List<Node>>();

	/**
	 * Holds a map of physical nodes keyed by dataset id
	 */
	private Map<String,Node> keyForDataset = new HashMap<String,Node>();

	/**
	 * Holds a Map of a Map of Key element nodes, keyed by the attribute node that it is associated with.
	 * The outer Map is keyed by the PhysicalKey id
	 */
	private Map<String,Map<Node, Node>> attributesAndKeyElements = new HashMap<String,Map<Node,Node>>();
	
	/**
	 * Holds all relationships that an attribute has keyed by a concatenation of owning dataset id and attribute id
	 * <datasetid>-<attributeid>
	 */
	private Map<String,List<Relationship>> attributeRelationships = new HashMap<String,List<Relationship>>();

	/**
	 * Holds a list of all relationships between all nodes
	 */
	private List<Relationship> allRelationships = new ArrayList<Relationship>();
	
	/**
	 * Holds a list of all joined attributes stored as a map in the following format:
	 * 
	 * d1 = Left dataset
	 * a1 = Left attribute
	 * d2 = Right dataset
	 * a2 = Right attribute
	 */
	private List<Map<String, Node>> allJoinedAttributes = new ArrayList<Map<String,Node>>();
	
	
	/*
	 * The excel workbook and work sheets	
	 */
	private Workbook workbook;
	private Sheet idpMetamodelSheet;
	private Sheet sourcesSheet;
	private Sheet transformationsSheet;
	private Sheet joinsSheet;
	
	
	private PhysicalAttribute gmtAttr;	
	private Map<String, Integer> datasetAttributePositions = new HashMap<String, Integer>();
	private List<String> joinToDatasets = new ArrayList<String>();
	private Map<String, String> viewRelations = new HashMap<String, String>();
	
	/**
	 * A list of View nodes that have been read in
	 */
	private List<View> viewNodes = new ArrayList<View>();
	
	/**
	 * Map of all view nodes keyed by view id
	 */
	private Map<String,View> viewNodesMap = new HashMap<String,View>();
	
	/**
	 * Map of all dataset nodes keyed by dataset id
	 */
	private Map<String,PhysicalDataset> datasetNodesMap = new HashMap<String,PhysicalDataset>();
	
	/**
	 * MAp of all roles keyed by role name	
	 */
	private Map<String,Role> roleNodesMap = new HashMap<String,Role>();
	
	/**
	 * Map of all source nodes keyed by source id
	 */
	private Map<String,Source> sourceNodesMap = new HashMap<String,Source>();
	
	/**
	 * Map of all service nodes keyed by service id	
	 */
	private Map<String,Service> serviceNodesMap = new HashMap<String,Service>();
	
	/**
	 * An internal counter for all node ids
	 */
	private long nodeCounterId;
	
	/**
	 * Loads in the excel file and populates the various map
	 * member variables from the sheet
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public void loadExcelFile( File excelFile ) throws Exception
	{
		try (InputStream is = new FileInputStream(excelFile))
		{
			loadExcelFromStream( is );
		}
	}
	
	/**
	 * Loads in the excel file and populates the various map
	 * member variables from the sheet
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public void loadExcelFromStream( InputStream is ) throws Exception
	{
		workbook = Workbook.getWorkbook(is);
		idpMetamodelSheet = workbook.getSheet(DATA_MODEL_SHEET_NAME);
		sourcesSheet = workbook.getSheet(SOURCE_SHEET_NAME);
		transformationsSheet = workbook.getSheet(TRANSFORMATIONS_SHEET_NAME);
		joinsSheet = workbook.getSheet(JOINS_SHEET_NAME);

		clearDown();

		createTimeAttributes();
		processSources();
		processDatasets();
		processKeys();
		processJoins();
		createViewRelations();
		setViewRoles();
		processTransformations();
	}
	
	/**
	 * Clears the details of any spreadsheet that has been currently loaded in
	 */
	public void clearDown()
	{
		nodesOfLabelType.clear();
		attributesForDataset.clear();
		keyForDataset.clear();
		attributesAndKeyElements.clear();
		attributeRelationships.clear();
		allRelationships.clear();
		allJoinedAttributes.clear();
		datasetAttributePositions.clear();
		joinToDatasets.clear();
		viewRelations.clear();
		viewNodes.clear();
		viewNodesMap.clear();
		datasetNodesMap.clear();
		roleNodesMap.clear();
		sourceNodesMap.clear();
		serviceNodesMap.clear();
		nodeCounterId = 0;
	}
	
	/**
	 * There are some 
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private void createTimeAttributes() throws IllegalArgumentException, IllegalAccessException
	{
		gmtAttr = new PhysicalAttribute();
		gmtAttr.nodeId = this.getNextNodeId();
		gmtAttr.id = "System.gmt";
		gmtAttr.name = "gmt";
		addNodeToTypes(PhysicalAttribute.class.getSimpleName(),gmtAttr.toNode());
		
		PhysicalDataset system = new PhysicalDataset();
		system.nodeId = this.getNextNodeId();
		system.id = "System";
		system.name = "System";
		system.attributes.add(gmtAttr);
		system.tableId = "System";
		
		datasetNodesMap.put(system.id, system);
		addNodeToTypes(PhysicalDataset.class.getSimpleName(),system.toNode());
		Relationship rel = addRelationship(system.toNode(), gmtAttr.toNode(), RELATIONSHIP_TYPE.OWNS);
		addAttributeRelationship(system.id,gmtAttr.id, rel);
		
		List<Node> attributeNodes = attributesForDataset.get(system.id);
		if( attributeNodes == null )
		{
			attributeNodes = new ArrayList<Node>();
			attributesForDataset.put(system.id,attributeNodes);
		}
		attributeNodes.add(gmtAttr.toNode());
	}
	
	/**
	 * Adds a node to the list nodes that are of a specified label 
	 * @param label
	 * @param node
	 */
	private void addNodeToTypes( String label, Node node )
	{
		List<Node> nodeTypes = nodesOfLabelType.get(label);
		if( nodeTypes == null )
		{
			nodeTypes = new ArrayList<Node>();
			nodesOfLabelType.put(label,nodeTypes);
		}
		nodeTypes.add(node);
	}
	
	/**
	 * Creates a relationship of the specified type between the two nodes and saves
	 * it in the list of all relationships. This list is used during the export service
	 * to generate cypher for all relationships 
	 * @param node1
	 * @param node2
	 * @param relType
	 * @return
	 */
	private Relationship addRelationship(Node node1, Node node2, final RELATIONSHIP_TYPE relType )
	{
		Relationship rel = 		
			node1.createRelationshipTo(node2, new RelationshipType(){			
				@Override
				public String name()
				{
					return relType.toString();
				}
			});
		
		allRelationships.add(rel);
				
		return rel;
	}

	/**
	 * Creates and adds a DATASET->ATTRIBUTE relationship (if not already created) to the list
	 * of DATASET->ATTRIBUTE relationships.
	 * 
	 * These specific releationships are used because attributes are not uniquely identifiable on 
	 * their and can only be identified in relationship to the owning dataset
	 * 
	 * @param datasetId
	 * @param attributeId
	 * @param rel
	 */
	private void addAttributeRelationship(String datasetId, String attributeId, Relationship rel )
	{
		String key = datasetId + "-" + attributeId;
		List<Relationship> existingRelationships = attributeRelationships.get(key);
		if( existingRelationships == null )
		{
			existingRelationships = new ArrayList<Relationship>();
			attributeRelationships.put( key, existingRelationships );
		}
		existingRelationships.add(rel);
	}
	
	/**
	 * Adds to the list of attributes that have a join relationship
	 * @param dataset1
	 * @param attribute1
	 * @param dataset2
	 * @param attribute2
	 */
	private void addJoinedAttribute( Node dataset1, Node attribute1, Node dataset2, Node attribute2 )
	{
		Map<String,Node> map = new HashMap<String,Node>();
		map.put("d1",dataset1);
		map.put("a1",attribute1);
		map.put("d2",dataset2);
		map.put("a2",attribute2);
		allJoinedAttributes.add(map);
	}
	
	
	/**
	 * Reads in the spread sheet and populates a map of each attribte node
	 * keyed by dataset id
	 * @throws Exception 
	 */
	private void processDatasets() throws Exception
	{
		logger.info("Processing datasets and attributes, please wait....");

		processHeaders();

		int lineNumber = 1;
		int totalLines = idpMetamodelSheet.getRows() - DATASETS_LINE_NUMBER;

		for (int rowIndex = DATASETS_LINE_NUMBER; rowIndex < idpMetamodelSheet.getRows(); rowIndex++)
		{
			
			if (lineNumber % 100 == 0)
			{
				logger.info("Processed " + (lineNumber) + " of " + totalLines + " lines");
			}
			lineNumber++;

			Integer attributePosition;
			String active = idpMetamodelSheet.getCell(ACTIVE_COL, rowIndex).getContents();
			String queryable = idpMetamodelSheet.getCell(QUERYABLE_COL, rowIndex).getContents();
			String derived = idpMetamodelSheet.getCell(DERIVED_COL, rowIndex).getContents();
			String logicalDatasetName = idpMetamodelSheet.getCell(ENTITY_COL, rowIndex).getContents();
			String physicalDatasetName = idpMetamodelSheet.getCell(DATASET_COL, rowIndex).getContents();
			String logicalAttributeName = idpMetamodelSheet.getCell(LOGICAL_ATTR_COL, rowIndex).getContents();
			String physicalAttributeName = idpMetamodelSheet.getCell(PHYSICAL_ATTR_COL, rowIndex).getContents();
			
			attributePosition = datasetAttributePositions.get(physicalDatasetName);
			if (attributePosition == null)
				attributePosition = 0;

			PhysicalAttribute physicalAttribute = new PhysicalAttribute();
			physicalAttribute.nodeId = getNextNodeId();
			physicalAttribute.id = logicalAttributeName;
			physicalAttribute.name = logicalAttributeName;
			physicalAttribute.position = attributePosition;
			physicalAttribute.active = active.toLowerCase().equals("y");
			physicalAttribute.queryable = queryable.toLowerCase().equals("y");
			physicalAttribute.derived = derived.toLowerCase().equals("y");			
			if( !physicalAttributeName.equals(logicalAttributeName) )
			{
				physicalAttribute.xpath = physicalAttributeName;
			}			
			
			addNodeToTypes(PhysicalAttribute.class.getSimpleName(),physicalAttribute.toNode());
						
			// Dataset will already exist as its created in processSources (otherwise throw error)
			PhysicalDataset physicalDataset = datasetNodesMap.get(physicalDatasetName); 			
			if( physicalDataset == null )
			{
				throw new RuntimeException("Dataset with name " + physicalDatasetName + " in the Datasets tab on line " + (lineNumber+DATASETS_LINE_NUMBER) + " has not been correctly defined in the sources tab.");
			}
			
			physicalDataset.attributes.add(physicalAttribute);

			addRelationship( physicalDataset.toNode(), physicalAttribute.toNode(), RELATIONSHIP_TYPE.OWNS );
			
			List<Node> attributeNodes = attributesForDataset.get(physicalDataset.id);
			if( attributeNodes == null )
			{
				attributeNodes = new ArrayList<Node>();
				attributesForDataset.put(physicalDataset.id,attributeNodes);
			}
			
			// Check for duplicates
			if( idAlreadyExists(attributeNodes,physicalAttribute.id) )
			{
				throw new RuntimeException("Duplicate attribute detected on row "+ (rowIndex+1) +"! The dataset with id=" + physicalDataset.id + " already has an attribute with id=" + physicalAttribute.id );
			}			
			
			Node attributeNode = physicalAttribute.toNode();
			attributeNodes.add(attributeNode);
			
			// Update the attribute positions for this dataset
			attributePosition++;
			datasetAttributePositions.put(physicalDatasetName, attributePosition);

			processFieldPositions(rowIndex, physicalDataset,physicalAttribute);
		}
	}
	
	/**
	 * Checks a list of nodes to see if there is any node with the 
	 * an "id" property value matching the specified id
	 * @param attributeNodes
	 * @param attributeId
	 * @return
	 */
	private boolean idAlreadyExists(List<Node> nodes, String idToCheck )
	{
		for( Node node : nodes )
		{
			if( node.getProperty("id").equals(idToCheck) )
			{
				return true;
			}
		}		
		return false;
	}
		
	/**
	 * Reads in the header of the dataset definition worksheet that defines the views
	 * and the join relations between datasets
	 * @throws Exception
	 */
	private void processHeaders() throws Exception
	{
		processViews();
		processRelations();
	}

	/**
	 * Processes all the views defined in the dataset worksheet
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private void processViews() throws IllegalArgumentException, IllegalAccessException
	{
		int colCount = idpMetamodelSheet.getColumns();
		for (int colIndex = VIEWS_START_COL; colIndex < colCount; colIndex++)
		{

			String viewName = idpMetamodelSheet.getCell(colIndex, VIEW_NAME_LINE_NUMBER).getContents();
			String delimeter = idpMetamodelSheet.getCell(colIndex, DELIMITERS_LINE_NUMBER).getContents();
			String unionAll = idpMetamodelSheet.getCell(colIndex, UNIONALL_LINE_NUMBER).getContents();
			String gmtPos = idpMetamodelSheet.getCell(colIndex, GMT_LINE_NUMBER).getContents();

			View view = new View();
			view.nodeId = getNextNodeId();
			view.id = viewName;
			view.name = viewName;
			view.delimiter = delimeter;
			view.unionAll = unionAll != null && unionAll.toUpperCase().trim().equals("Y");
			if (gmtPos != null && gmtPos.trim().length() > 0)
			{
				allRelationships.add( new SelectsRelationshipType(view, gmtAttr, Integer.parseInt(gmtPos),gmtAttr.id).toRelationship() );
			}
			
			addNodeToTypes(View.class.getSimpleName(), view.toNode());

			viewNodes.add(view);
			viewNodesMap.put(view.id,view);
		}
	}

	/**
	 * Processes the selected attribute positions for each view that are specified
	 * by position values going down the column 
	 * 
	 * The dataset at the the row index, with the PhysicalDataset & PhysicalAttribute
	 * 
	 * @param rowIndex 
	 * @param physicalDatasetNode
	 * @param physicalAttributeNode
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private void processFieldPositions(int rowIndex,PhysicalDataset physicalDatasetNode, PhysicalAttribute physicalAttributeNode) throws IllegalArgumentException, IllegalAccessException
	{
		// The view nodes in the list line up with the columns
		Iterator<View> viewsIterator = viewNodes.iterator();
		
		// Get the count of all view columns defined
		int colCount = idpMetamodelSheet.getColumns();
		
		for (int colIndex = VIEWS_START_COL; colIndex < colCount; colIndex++)
		{
			// Get a position value for the view selecting this attribute
			String position = idpMetamodelSheet.getCell(colIndex, rowIndex).getContents();
			String viewAttributeName = physicalAttributeNode.id;
			if( position.contains(",") )
			{
				String[] split = position.split(",");
				position = split[0];
				viewAttributeName = split[1];
			}
			
			View viewNode = viewsIterator.next();
			
			if (position != null && position.trim().length() > 0)
			{
				// Create a "Selects" relationship between the view and the attribute
				int positionVal = Integer.parseInt(position);
				Relationship selectsRelationship = new SelectsRelationshipType(viewNode, physicalAttributeNode, positionVal,viewAttributeName).toRelationship(); 
				allRelationships.add(  selectsRelationship );
				addAttributeRelationship(physicalDatasetNode.id,physicalAttributeNode.id, selectsRelationship);
			}
		}
	}
	
	/**
	 * Reads in the Join/Union definitions for a view in the dataset tab header 
	 * @throws Exception
	 */
	private void processRelations() throws Exception
	{
		Iterator<View> viewIterator = viewNodes.iterator();
		int colCount = idpMetamodelSheet.getColumns();
		for (int colIndex = VIEWS_START_COL; colIndex < colCount; colIndex++)
		{
			String relations = idpMetamodelSheet.getCell(colIndex, RELATIONS_LINE_NUMBER).getContents();

			View viewNode = viewIterator.next();
			viewRelations.put(viewNode.id, relations);
		}
	}

	/**
	 * PRocesses the joins worksheet
	 * @throws Exception
	 */
	private void processJoins() throws Exception
	{
		logger.info("Parsing joins, please wait....");

		proccessJoinsHeader();
		proccessJoinsEntry();

		logger.info("Added all joins successfully");
	}

	/**
	 * Reads in and stores all the top row column definitions of the joins
	 * that represents the "join to" datasets
	 */
	private void proccessJoinsHeader()
	{
		for (int colIndex = 1; colIndex < joinsSheet.getColumns(); colIndex++)
		{
			String name = joinsSheet.getCell(colIndex, 0).getContents();
			joinToDatasets.add(name);
		}
	}

	/**
	 * Proceses each row of the joins worksheet by creating a join from
	 * and a join to relationship based on the joined attributes  
	 * @throws Exception
	 */
	private void proccessJoinsEntry() throws Exception
	{
		int colCount = joinsSheet.getColumns();
		for (int rowIndex = 1; rowIndex < joinsSheet.getRows(); rowIndex++)
		{
			String joinFromDataset = joinsSheet.getCell(0, rowIndex).getContents();
			
			for (int colIndex = 1; colIndex < colCount; colIndex++)
			{
				String entry = joinsSheet.getCell(colIndex, rowIndex).getContents();
				if (entry != null && entry.length() > 0)
				{
					String[] srcAndTarget = entry.split(",");
					String fromAttribute = srcAndTarget[0];
					String toAttribute = srcAndTarget[1];
					String joinToDataset = joinToDatasets.get(colIndex - 1);
					
					logger.debug("Processing join from {} to {}",joinFromDataset,joinToDataset);
					
					// fetch the join from node
					PhysicalDataset joinFromDatasetNode = datasetNodesMap.get(joinFromDataset);
					if( joinFromDatasetNode == null )
					{
						throw new RuntimeException("Could not find dataset " + joinFromDataset + " when processing Joins on line " + rowIndex + ". Ensure it is defined the same in the datasets tab. Case is sensitive");
					}

					Node joinFromAttributeNode = null;
					for( Node attrNode :  attributesForDataset.get(joinFromDatasetNode.id) )
					{
						if( attrNode.getProperty("id").equals(fromAttribute) )
						{
							joinFromAttributeNode = attrNode;
							break;
						}
					}
					if( joinFromAttributeNode == null )
					{
						throw new RuntimeException("Could not find attribute " + fromAttribute + " in dataset " + joinFromDataset + " when processing Joins on line " + rowIndex + ". Ensure it is defined the same in the datasets tab. Case is sensitive" );
					}
					

					// fetch the join to node
					PhysicalDataset joinToDatasetNode = datasetNodesMap.get(joinToDataset);
					if( joinToDatasetNode == null )
					{
						throw new RuntimeException("Could not find dataset " + joinToDatasetNode + " when processing Joins on line " + rowIndex + ". Ensure it is defined the same in the datasets tab. Case is sensitive");
					}
					Node joinToAttributeNode = null;
					for( Node attrNode : attributesForDataset.get(joinToDatasetNode.id) )
					{
						if( attrNode.getProperty("id").equals(toAttribute) )
						{
							joinToAttributeNode = attrNode;
							break;
						}
					}
					if( joinToAttributeNode == null )
					{
						throw new RuntimeException("Could not find attribute " + toAttribute + " in dataset " + joinToDatasetNode + " when processing Joins on line " + rowIndex + ". Ensure it is defined the same in the datasets tab. Case is sensitive" );
					}
					
					// Create the relationship
					
					// Add the relationship to our maps
					Relationship newRel = addRelationship(joinFromAttributeNode, joinToAttributeNode, RELATIONSHIP_TYPE.JOINED_TO);
					String key = joinFromDatasetNode.id + "-" + joinFromAttributeNode.getProperty("id");
					List<Relationship> relationsList = attributeRelationships.get( key );
					if( relationsList == null )
					{
						relationsList = new ArrayList<Relationship>();
						attributeRelationships.put(key,relationsList );
					}
					relationsList.add(newRel);
					
					// Store the joined attributes
					addJoinedAttribute(joinFromDatasetNode.toNode(), joinFromAttributeNode, joinToDatasetNode.toNode(), joinToAttributeNode );

					// Add the relationship to all relations
					addRelationship(joinFromAttributeNode, joinToAttributeNode, RELATIONSHIP_TYPE.JOINED_TO);
				}
			}
		}
	}
	
	/**
	 * Processes all the entries in the sources worksheet
	 * @throws Exception
	 */
	private void processSources() throws Exception
	{
		logger.info("Parsing sources, please wait....");

		int lineNumber = 1;
		int totalLines = sourcesSheet.getRows() - SOURCES_START_ROW;
		for (int rowIndex = SOURCES_START_ROW; rowIndex < sourcesSheet.getRows(); rowIndex++)
		{
			if (lineNumber % 100 == 0)
				logger.info("Processed " + (lineNumber) + " of " + totalLines + " lines");
			lineNumber++;
			
			String datasetName = sourcesSheet.getCell(SOURCES_DASTASET_COL, rowIndex).getContents();
			String roles = sourcesSheet.getCell(SOURCES_ROLES_COL, rowIndex).getContents();
			String delimiter = sourcesSheet.getCell(SOURCES_DELIMITER_COL, rowIndex).getContents();
			String delta = sourcesSheet.getCell(SOURCES_URL_DELTA_COL, rowIndex).getContents();
			String deltaAppend = sourcesSheet.getCell(SOURCES_URL_DELTA_APPEND_COL, rowIndex).getContents();
			String link = sourcesSheet.getCell(SOURCES_URL_COL, rowIndex).getContents();
			String namespaces = sourcesSheet.getCell(SOURCES_NAMESPACE_COL, rowIndex).getContents();
			String system = sourcesSheet.getCell(SOURCES_SYSTEM_COL, rowIndex).getContents();
			String tableId = sourcesSheet.getCell(SOURCES_TABLEID_COL, rowIndex).getContents();
			String authUri = sourcesSheet.getCell(SOURCES_AUTH_URI_COL, rowIndex).getContents();
			String username = sourcesSheet.getCell(SOURCES_USERNAME_COL, rowIndex).getContents();
			String password = sourcesSheet.getCell(SOURCES_PASSWORD_COL, rowIndex).getContents();
			String driverClass = sourcesSheet.getCell(SOURCES_DRIVERCLASS_COL, rowIndex).getContents();
			String querySQL = sourcesSheet.getCell(SOURCES_SQL_COL, rowIndex).getContents();
			String deltaSQL = sourcesSheet.getCell(SOURCES_DELTA_SQL_COL, rowIndex).getContents();
			String jobs = sourcesSheet.getCell(SOURCES_JOBS_COL, rowIndex).getContents();
			
			if( delimiter.length() == 0 )
			{
				logger.warn("No delimiter set for {}!",datasetName);
			}
			
			// fetch the dataset node
			PhysicalDataset datasetNode = datasetNodesMap.get(datasetName);
			if(datasetNode == null )
			{
				datasetNode = new PhysicalDataset();
				datasetNode.nodeId = getNextNodeId();
				datasetNode.id = datasetName;
				datasetNode.name = datasetName;
				datasetNode.delimiter = delimiter;
				datasetNode.namespaces = namespaces;
				datasetNode.tableId = tableId;
				datasetNode.jobs = jobs;

				datasetNodesMap.put(datasetNode.id, datasetNode);
				addNodeToTypes(PhysicalDataset.class.getSimpleName(),datasetNode.toNode());
				logger.debug("Adding " + datasetName );
			}
			
			if( system == null || system.isEmpty() )
			{
				throw new RuntimeException("No source system defined for dataset " + datasetName + " at line " + lineNumber + " on the Sources tab");
			}
				
						
			// Create a system if it doesnt exist
			Source source = sourceNodesMap.get(system);
			if( source == null )
			{
				source = new Source();
				source.nodeId = getNextNodeId();
				source.id = system;
				source.name = system;
				addNodeToTypes(Source.class.getSimpleName(), source.toNode());
				sourceNodesMap.put(system,source);
			}
			
			// Create a service			
			Service service = serviceNodesMap.get(datasetName + "Service");
			if( service == null )
			{
				service = new Service();
				service.nodeId = getNextNodeId();
				service.id = datasetName + "Service";
				service.name = datasetName + " Service";
				addNodeToTypes(Service.class.getSimpleName(), service.toNode());
				serviceNodesMap.put(service.id,service);
			}
			source.services.add(service);
			addRelationship(source.toNode(), service.toNode(), RELATIONSHIP_TYPE.OFFERS);
			
			// Create a service implementation
			String type = "";
			
			// TODO: Horrible! Get rid of this when we refactor the spreadsheet to
			// define different channel types correctly!!
			if( link.startsWith("${RDDH_WS_HOST}") )type = PROTOCOL.http.name();
			else if( link.startsWith("${DAS_URL}") )type = PROTOCOL.http.name();
			
			else if( link.startsWith("http") )type = PROTOCOL.http.name();
			else if( link.startsWith("file") )type = PROTOCOL.file.name();			
			else if( link.startsWith("jdbc") )type = PROTOCOL.jdbc.name();			
			ServiceImplementation serviceImpl = new ServiceImplementation();
			serviceImpl.nodeId = getNextNodeId();
			serviceImpl.id = datasetName + "ServiceImpl" + type;
			serviceImpl.name = datasetName + " Service " + type;
			serviceImpl.dataset = datasetNode;

			addNodeToTypes(ServiceImplementation.class.getSimpleName(), serviceImpl.toNode());
			addRelationship(service.toNode(), serviceImpl.toNode(), RELATIONSHIP_TYPE.IMPLEMENTED_BY);
			addRelationship(serviceImpl.toNode(), datasetNode.toNode(), RELATIONSHIP_TYPE.PROVIDES);
			
			String[] links;
			if( link.contains("\n") )
			{
				links = link.split("\n");
			}
			else
			{
				links = new  String[]{link};
			}
			
			// And now add the channels
			int channelIndex = 1;
			for( String newLink : links )
			{
				Channel channel = null;
				if (channel == null)
				{
					if( type.equals(PROTOCOL.http.toString()) )
					{
						channel = new HTTPChannel();
						((HTTPChannel)channel).authenticationUri = authUri;
					}
					else if( type.equals(PROTOCOL.jdbc.toString()) )
					{
						channel = new JDBCChannel();
						((JDBCChannel)channel).username = username;
						((JDBCChannel)channel).password = password;
						((JDBCChannel)channel).driverClass = driverClass;
						((JDBCChannel)channel).querySQL = querySQL;
					}
					else
					{
						channel = new Channel();
					}
					
					channel.nodeId = getNextNodeId();
					channel.id = datasetName + "ServiceInbound" + type + channelIndex;
					channel.name = datasetName + " Service Inbound " + type + channelIndex;					
					if( type != null && type.length() > 0 )
					{					
						channel.protocol = PROTOCOL.valueOf( type.toLowerCase() );
					}
					channel.url = newLink;
					
					// Delta URLs
					if( deltaAppend !=null && deltaAppend.trim().length() > 0 )
					{
						((HTTPChannel)channel).deltaUrl = channel.url + deltaAppend;
					}
					else if( delta !=null && delta.trim().length() > 0 )
					{
						if( channel instanceof HTTPChannel )
						{
							String[] deltas = delta.split("\n");
							
							if( channelIndex > deltas.length )
							{
								throw new RuntimeException("The number of Delta URLS do not match the number of URLs for dataset " + datasetName + " on row " + lineNumber + " on the " + SOURCE_SHEET_NAME + " sheet. There are " + links.length + " URLS but only " + deltas.length + " delta URLs. Please make sure they match in number");
							}
							
							((HTTPChannel)channel).deltaUrl = deltas[channelIndex-1];						
						}
					}
					
					// Delta SQL
					if( deltaSQL !=null && !deltaSQL.isEmpty() )
					{
						((JDBCChannel)channel).queryDeltaSQL = deltaSQL;
					}

					
					addNodeToTypes(Channel.class.getSimpleName(), channel.toNode());

				}			
				//serviceImpl.channels.add( new AccessedViaRelationshipType(serviceImpl, channel,channelIndex) );
				allRelationships.add(new AccessedViaRelationshipType(serviceImpl, channel,channelIndex).toRelationship() );
				channelIndex ++;
			}
			
			// Create the role node if its not there already
			if (roles != null && roles.length() > 0)
			{
				String[] roleNames = roles.split(",");
				for (String roleName : roleNames)
				{				
					roleName = roleName.trim();
					Role role = roleNodesMap.get(roleName);
					if( role == null )
					{
						role = new Role();
						role.nodeId = getNextNodeId();
						role.id = roleName;
						role.name = roleName;
						roleNodesMap.put(roleName,role);
					}
					
					datasetNode.getRoles().add(role);
					addNodeToTypes(ServiceImplementation.class.getSimpleName(), serviceImpl.toNode());
					addRelationship(datasetNode.toNode(), role.toNode(), RELATIONSHIP_TYPE.REQUIRES);
				}
			}

		}

		logger.info("Added all sources successfully");
	}
	
	/**
	 * Creates the metadata key definitions for all dataset entries in the soruces worksheet
	 * @throws Exception
	 */
	private void processKeys() throws Exception
	{
		logger.info("Parsing sources, please wait....");

		for (int rowIndex = SOURCES_START_ROW; rowIndex < sourcesSheet.getRows(); rowIndex++)
		{
			String datasetName = sourcesSheet.getCell(SOURCES_DASTASET_COL, rowIndex).getContents();
			String keyList = sourcesSheet.getCell(SOURCES_KEY_COL, rowIndex).getContents();
			
			if( keyList == null || keyList.isEmpty() )
			{
				throw new RuntimeException("No key attributes specified for dataset " + datasetName + " on row " + rowIndex + " on the Sources tab");
			}
			
			PhysicalDataset datasetNode = datasetNodesMap.get(datasetName);
			
			// Create the physical key node and join it to the dataset
			PhysicalKey physicalKey = new PhysicalKey();
			physicalKey.nodeId = getNextNodeId();
			physicalKey.id = datasetName + "PhyisicalIdentifier";
			physicalKey.name = "Phyisical Identifier";
			physicalKey.setDataset( datasetNode );

			addRelationship(physicalKey.toNode(), datasetNode.toNode(), RELATIONSHIP_TYPE.PRIMARY_IDENTIFIER_OF);
			addNodeToTypes(PhysicalKey.class.getSimpleName(), physicalKey.toNode());
			keyForDataset.put(datasetName,physicalKey.toNode());


			// Create all the key elements and join them to the physical
			// attributes
			String[] keys = keyList.split(",");
			int keyCount = 0;
			for (String keyElement : keys)
			{
				keyElement = keyElement.trim();
				PhysicalKeyElement physicalKeyElement = new PhysicalKeyElement();
				physicalKeyElement.nodeId = getNextNodeId();
				physicalKeyElement.id = datasetName + "KeyElement" + keyCount;
				physicalKeyElement.name = "Key Element" + keyCount;
				physicalKeyElement.position = keyCount;
				
				physicalKeyElement.setKey( physicalKey );
				addRelationship(physicalKeyElement.toNode(), physicalKey.toNode(), RELATIONSHIP_TYPE.KEY_ELEMENT_OF);				
				addNodeToTypes(PhysicalKeyElement.class.getSimpleName(), physicalKeyElement.toNode());
				
				List<Node> attributeNodes = attributesForDataset.get(datasetName);				
				
				// Now join the physical key to the physical attribute
				boolean found = false;
				for( Node attrNode : attributeNodes )
				{
					if( attrNode.getProperty("id").equals(keyElement) )
					{
						found = true;
						Map<Node,Node> attributeToKeyElements = attributesAndKeyElements.get(physicalKey.id);
						if( attributeToKeyElements == null )
						{
							attributeToKeyElements = new HashMap<Node,Node>();
							attributesAndKeyElements.put(physicalKey.id,attributeToKeyElements);
						}
						
						attributeToKeyElements.put( attrNode, physicalKeyElement.toNode() );
						addRelationship(attrNode, physicalKeyElement.toNode(), RELATIONSHIP_TYPE.MAKES_UP);
						break;
					}
				}

				if( !found )
				{
					// Suppressing for now until we sort out GCRSHIERARCHY.IDP
					//throw new RuntimeException("The dataset " + datasetNode + " does not have an attribute called " + keyElement + " as defined in the source tab on row " + (rowIndex+1));
				}
				
				keyCount++;
			}

		}
	}


	/**
	 * Once all the dataset and view nodes have been created, we create all the
	 * join relation nodes that link them together
	 * 
	 * @throws Exception
	 */
	private void createViewRelations() throws Exception
	{
		logger.info("Creating view relations");
		
		Iterator<String> viewNames = viewRelations.keySet().iterator();
		while (viewNames.hasNext())
		{
			String viewName = viewNames.next();
			if( viewName.trim().length() == 0 )continue;
			
			String[] relations = viewRelations.get(viewName).split(",");

			// Grab the view node and each of the datasets
			View viewNode = viewNodesMap.get(viewName);

			int position = 0;
			
			for (String relation : relations)
			{
				// Create the join relation node
				JoinRelation joinRelation = new JoinRelation();
				joinRelation.nodeId = getNextNodeId();
				joinRelation.id = viewName + relation + position;
				joinRelation.name = viewName + relation + position;
				joinRelation.position = position++;
				
				viewNode.joinRelations.add(joinRelation);
				
				addNodeToTypes(JoinRelation.class.getSimpleName(), joinRelation.toNode());
				addRelationship(viewNode.toNode(), joinRelation.toNode(), RELATIONSHIP_TYPE.REPRESENTED_AS);				

				List<PhysicalDataset> datasetNodes = new ArrayList<PhysicalDataset>();
				String[] datasetNames = relation.split("_");
				for (String datasetName : datasetNames)
				{
					PhysicalDataset datasetNode = datasetNodesMap.get(datasetName); 
					if( datasetNode != null )
					{
						datasetNodes.add(datasetNode);
					}
				}

				int datasetPosition = 0;
				for( PhysicalDataset pd : datasetNodes )
				{
					JoinsRelationshipType joinRelationshipType = new JoinsRelationshipType(joinRelation, pd, datasetPosition++ );
					joinRelation.datasets.add(joinRelationshipType);
					allRelationships.add(joinRelationshipType.toRelationship());
				}				
			}
		}
		
		logger.info("View relations created");
	}
	
	/**
	 * Adds the roles to the views based on the roles that the selected datasets within
	 * the view require
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private void setViewRoles() throws IllegalArgumentException, IllegalAccessException
	{
		logger.info("Setting roles in views");
		
		Iterator<String> viewNames = viewRelations.keySet().iterator();
		while (viewNames.hasNext())
		{
			String viewName = viewNames.next();
			if( viewName.trim().length() == 0 )continue;
			
			// Grab the view node and each of the datasets
			View viewNode = viewNodesMap.get(viewName);
			
			if( viewNode == null )
			{
				throw new RuntimeException("Could not find view with name " + viewName );
			}

			// Add the role for the associated datasets to the view				
			Iterable<PhysicalDataset> iterable = getAssociatedDatasetsFromView(viewNode);
			if( iterable != null )
			{
				Iterator<PhysicalDataset> datasetNodes = iterable.iterator();
				while( datasetNodes.hasNext() )
				{
					PhysicalDataset datasetNode = datasetNodes.next();
					for( Role role : datasetNode.roles )
					{					
						if( !viewNode.getRoles().contains(role) )
						{
							viewNode.roles.add(role);
							addRelationship(viewNode.toNode(), role.toNode(), RELATIONSHIP_TYPE.REQUIRES);
						}
					}
				}
			}
		}		
		
		logger.info("All view roles set");
	}

	/**
	 * Iterates the join relations associated with the view and pulls out a unique set of
	 * datasets 
	 * @param viewNode
	 * @return
	 */
	private Set<PhysicalDataset> getAssociatedDatasetsFromView(View viewNode)
	{
		Set<PhysicalDataset> datasets = new HashSet<PhysicalDataset>();
		
		for( JoinRelation jr : viewNode.joinRelations )
		{
			for( JoinsRelationshipType jrt :jr.datasets )
			{
				datasets.add( jrt.physicalDataset );
			}
		}
		
		return datasets;
	}
	
	/**
	 * Creates transformations between datasets
	 * @throws Exception
	 */
	private void processTransformations() throws Exception 
	{
		logger.info("Parsing transformatons, please wait....");
		
		int lineNumber = 1;
		int totalLines = transformationsSheet.getRows() - TRANSFORMATIONS_START_ROW;
		for (int rowIndex = TRANSFORMATIONS_START_ROW; rowIndex < transformationsSheet.getRows(); rowIndex++)
		{
			// Dump out progress
			if (lineNumber % 100 == 0)
				logger.info("Processed " + (lineNumber) + " of " + totalLines + " transformations");
			lineNumber++;

			String sourceDatasetId = transformationsSheet.getCell(SRC_DATASET_COL, rowIndex).getContents();
			String targetDatasetId = transformationsSheet.getCell(TRGT_DATASET_COL, rowIndex).getContents();
			String transformerClass = transformationsSheet.getCell(TRANSFORMER_TYPE_COL, rowIndex).getContents();
			String preProcessorRulesets= transformationsSheet.getCell(PRE_PROCESSOR_RULESET_COL, rowIndex).getContents();
			String rulesets= transformationsSheet.getCell(RULESET_COL, rowIndex).getContents();
			String keyColumns= transformationsSheet.getCell(KEY_COLUMNS_COL, rowIndex).getContents();
			String pivotColumn= transformationsSheet.getCell(PIVOT_COLUMN_COL, rowIndex).getContents();
			String associatedPivotColumns= transformationsSheet.getCell(ASSOCIATED_PIVOT_COLUMNS_COL, rowIndex).getContents();
			String targetPivotValues = transformationsSheet.getCell(TARGET_PIVOT_VALUES_COL, rowIndex).getContents();
			
			try
			{
			
				PhysicalDataset sourceDataset = datasetNodesMap.get(sourceDatasetId);
				Assert.notNull(sourceDataset, "Could not find source dataset " + sourceDatasetId);
				
				// Check if the transformation is pointing to itself (i.e. source and target are the same)
				PhysicalDataset targetDataset = null;
				if( sourceDatasetId.equals(targetDatasetId) )
				{
					targetDataset = sourceDataset;
				}
				else
				{
					targetDataset = datasetNodesMap.get(targetDatasetId);
					Assert.notNull(targetDataset,"Could not find target dataset " + targetDatasetId);
				}
				

				
				Transformer transformer = (Transformer)Class.forName(transformerClass).newInstance();
				transformer.nodeId = getNextNodeId();
				transformer.id = sourceDatasetId + ".To." + targetDatasetId + ".Transformer";
				transformer.name = sourceDatasetId + " To " + targetDatasetId + " Transformer";

				logger.info("Creating " + transformer.name);

				addNodeToTypes(Transformer.class.getSimpleName(), transformer.toNode());

				
				/*
				 * If rulesets are specified then we assume the class is a rule transformer
				 */
				if( rulesets != null && rulesets.trim().length() > 0 )
				{
					((RulesTransformer)transformer).ruleset = rulesets;
				}

				/*
				 * If pre processor rulesets are specified then we assume the class is a ThinToWideTransformer
				 */
				if( preProcessorRulesets != null && preProcessorRulesets.trim().length() > 0 )
				{
					((ThinToWideTransformer)transformer).preProcessorRules = preProcessorRulesets;
				}

				
				/*
				 * Set values for ThinToWideTransformer
				 */
				if( transformer instanceof ThinToWideTransformer )
				{
					/*
					 * first we need to set all the values in the transformer 
					 */

					// Set the target pivot values
					((ThinToWideTransformer) transformer).targetPivotValues = targetPivotValues;
					
					// Set the pivot column
					PhysicalAttribute pivotColumnAttribute = sourceDataset.getAttributeWithId(pivotColumn);
					((ThinToWideTransformer) transformer).pivotColumn = pivotColumnAttribute;

					// Fetch each of the associated pivot columns and set it
					for( String associatedPivotColumn : associatedPivotColumns.split(",") )
					{
						PhysicalAttribute associatedPivotColumnAttribute = sourceDataset.getAttributeWithId(associatedPivotColumn);
						((ThinToWideTransformer) transformer).columnsAssociatedWithPivot.add(associatedPivotColumnAttribute);
					}					
					
					/*
					 * Now we can create the relationships knowing that the transformer has all its properties set 
					 */
					
					// Fetch each of the key columns and set it
					int orderCount = 0;
					for( String keyColumn : keyColumns.split(",") )
					{
						PhysicalAttribute keyColumnAttribute = sourceDataset.getAttributeWithId(keyColumn);
						Relationship rel = new KeyColumnRelationshipType((ThinToWideTransformer)transformer, keyColumnAttribute, orderCount++).toRelationship();
						allRelationships.add(rel);
						addAttributeRelationship(sourceDataset.id,keyColumnAttribute.id, rel);
					}
					
					// Fetch each of the associated pivot columns and set it
					for( String associatedPivotColumn : associatedPivotColumns.split(",") )
					{
						PhysicalAttribute associatedPivotColumnAttribute = sourceDataset.getAttributeWithId(associatedPivotColumn);
						Relationship rel = addRelationship(transformer.toNode(), associatedPivotColumnAttribute.toNode(), RELATIONSHIP_TYPE.HAS_ASSOCIATED_PIVOT_COLUMN);
						addAttributeRelationship(sourceDataset.id,associatedPivotColumnAttribute.id, rel);
					}
					
					
					Relationship rel = addRelationship(transformer.toNode(), pivotColumnAttribute.toNode(), RELATIONSHIP_TYPE.HAS_PIVOT_COLUMN);
					addAttributeRelationship(sourceDataset.id,pivotColumnAttribute.id, rel);
				}
								
				sourceDataset.setOutgoingTransformer(transformer);
				addRelationship(sourceDataset.toNode(), transformer.toNode(), RELATIONSHIP_TYPE.SOURCE_OF);
				
				targetDataset.setIncomingTransformer(transformer);
				addRelationship(targetDataset.toNode(), transformer.toNode(), RELATIONSHIP_TYPE.TARGET_OF);
								
			}
			catch (Exception e)
			{
				throw new RuntimeException("Failed to create transformer of type " + transformerClass + " between " + sourceDatasetId + " and " + targetDatasetId + ": " + e,e );
			}		
		}
		
		logger.info("Processed {} transformatons successfully",lineNumber);
	}

	

	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.metadata.service.export.ExportToCypherService#getAllNodesOfLabelType(int, int, java.lang.String)
	 */
	@Override
	public List<Node> getAllNodesOfLabelType(int offset, int limit, String labelType)
	{
		List<Node> nodes = nodesOfLabelType.get(labelType);
		
		int endIndex = offset + limit;
		if( endIndex > nodes.size() )
		{
			endIndex = nodes.size();
		}
		
		return nodes.subList(offset, endIndex);
	}

	@Override
	public List<Node> getAllAttributesForDataset(String datasetId)
	{
		List<Node> attributeNodes = attributesForDataset.get(datasetId);
		
		if( attributeNodes == null )
		{
			throw new RuntimeException("There are no attributes defined for the dataset with id=" + datasetId);
		}
		
		return attributeNodes;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.metadata.service.export.ExportToCypherService#getKeyForDataset(java.lang.String)
	 */
	@Override
	public Node getKeyForDataset(String datasetId)
	{
		return keyForDataset.get(datasetId);
	}

	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.metadata.service.export.ExportToCypherService#getAttributesAndKeyElementsForKey(java.lang.String)
	 */
	@Override
	public Map<Node, Node> getAttributesAndKeyElementsForKey(String keyId)
	{		
		Map<Node, Node> keyList = attributesAndKeyElements.get(keyId);
		if( keyList == null )
		{
			keyList = new HashMap<Node,Node>();
		}
		return keyList;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.metadata.service.export.ExportToCypherService#getAllRelationshipsForAttribute(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Relationship> getAllRelationshipsForAttribute(String datasetId, String attributeId)
	{		
		List<Relationship> relList = attributeRelationships.get(datasetId + "-" + attributeId);
		if( relList == null )
		{
			relList = new ArrayList<Relationship>();
		}
		return relList; 
	}

	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.metadata.service.export.ExportToCypherService#getAllRelationships(int, int)
	 */
	@Override
	public List<Relationship> getAllRelationships(int offset, int limit)
	{
		int endIndex = offset + limit;
		if( endIndex > allRelationships.size() )
		{
			endIndex = allRelationships.size();
		}
		
		return allRelationships.subList(offset, endIndex);
	}

	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.metadata.service.export.ExportToCypherService#getAllJoinedAttributes()
	 */
	@Override
	public List<Map<String, Node>> getAllJoinedAttributes()
	{
		return allJoinedAttributes;
	}	

	private long getNextNodeId()
	{
		return nodeCounterId ++;
	}
}
