package com.ubs.idp.metadata.service.imprt.excel;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jxl.Workbook;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.neo4j.graphdb.DynamicLabel;
import org.neo4j.graphdb.Node;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.client.Neo4jUtils;
import com.ubs.idp.metadata.model.Channel;
import com.ubs.idp.metadata.model.HTTPChannel;
import com.ubs.idp.metadata.model.JDBCChannel;
import com.ubs.idp.metadata.model.JoinRelation;
import com.ubs.idp.metadata.model.PhysicalAttribute;
import com.ubs.idp.metadata.model.PhysicalDataset;
import com.ubs.idp.metadata.model.RulesTransformer;
import com.ubs.idp.metadata.model.ThinToWideTransformer;
import com.ubs.idp.metadata.model.Transformer;
import com.ubs.idp.metadata.model.View;
import com.ubs.idp.metadata.model.enums.RELATIONSHIP_TYPE;
import com.ubs.idp.metadata.model.exceptions.MetadataException;
import com.ubs.idp.metadata.service.export.excel.ExcelExportToCypherService;

/**
 * This class is designed to run as an embedded Neo4j server, import a
 * cypher seed script then generate an excel file from the contents of the DB
 * 
 * TODO: Switch to Apache POI to get more functionality in the spreadsheet such as Autofilters 
 * 
 * @author loverids
 *
 */
@org.springframework.stereotype.Service
public class ImportToExcelService
{
	private static Logger logger = LoggerFactory.getLogger(ImportToExcelService.class);
	
	@Autowired
	Neo4jUtils neo4jUtils;
	
	@Autowired
	@Qualifier("neo4jMetadataService")
	MetadataService mds;

	/* 
	 * Cell formats
	 */
	private static WritableCellFormat GREY_CELL_FORMAT = new WritableCellFormat();
	private static WritableCellFormat BOLD_CELL_FORMAT = new WritableCellFormat();
	private static WritableCellFormat BOLD_CELL_GREENBACK_FORMAT = new WritableCellFormat();
	private static WritableCellFormat BOLD_BLUE_CELL_FORMAT = new WritableCellFormat();
	private static WritableFont arial10font = new WritableFont(WritableFont.ARIAL,10,WritableFont.BOLD);
	private static WritableFont arial10fontBlue = new WritableFont(WritableFont.ARIAL,10,WritableFont.BOLD);
	
	static
	{		 
		try
		{
			arial10fontBlue.setColour(Colour.BLUE);
			
			BOLD_CELL_FORMAT.setFont(arial10font);
			
			BOLD_CELL_GREENBACK_FORMAT.setFont(arial10font);
			BOLD_CELL_GREENBACK_FORMAT.setBackground(Colour.LIGHT_GREEN);
			BOLD_CELL_GREENBACK_FORMAT.setBorder(Border.ALL, BorderLineStyle.THIN);
			
			BOLD_BLUE_CELL_FORMAT.setFont(arial10fontBlue);
			GREY_CELL_FORMAT.setBackground(Colour.GREY_25_PERCENT);
		}
		catch (WriteException e)
		{
			e.printStackTrace();
		}		
	}


	
	/**
	 * The workbook used to write out excel data
	 */
	private WritableWorkbook workbook;
		
	/**
	 * Uses metadata services to extract data from the running instance of
	 * Neo4j and generate an excel file from it to be used for editting the 
	 * metadata
	 * @param excelFile
	 * @throws IOException 
	 * @throws WriteException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws InvocationTargetException 
	 * @throws NoSuchMethodException 
	 */
	public void generateExcelFile( File excelFile ) throws IOException, WriteException, IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException, InvocationTargetException
	{
		logger.info("Generating excel file {} from neo4j",excelFile);
		
		workbook = Workbook.createWorkbook(excelFile);
		generateDatasets();
		generateSources();
		generateTransformations();
		generateJoins();
		
		workbook.write(); 		
		workbook.close();
		
		logger.info("Excel file generated {}",excelFile);
	}
	
	/**
	 * Queries the database for all datasets and writes them to a worksheet
	 * @throws WriteException 
	 * @throws RowsExceededException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws InvocationTargetException 
	 * @throws NoSuchMethodException 
	 */
	private void generateDatasets() throws RowsExceededException, WriteException, IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException, InvocationTargetException
	{
		WritableSheet sheet = workbook.createSheet(ExcelExportToCypherService.DATA_MODEL_SHEET_NAME, 0);
		Map<String,Object> params = new HashMap<String,Object>();
		String cypherQuery = "match (pd:PhysicalDataset {id:{id}})-[:OWNS]->(pa:PhysicalAttribute) return pa order by pa.position";
		Map<String,Integer> datasetAttrRowMap = new HashMap<String,Integer>();
		
		// Write the header
		writeDatsetSheetHeader( sheet );
		
		// Fetch all datasets and attributes
		List<String> datasets  = mds.getAllDatasets();
		
		int rowCount = ExcelExportToCypherService.DATASETS_LINE_NUMBER;
		for( String dataset : datasets )
		{
			// Ignore defining a source for "System"
			// TODO: Does anything actually _use_ this dataset??
			if( dataset.equals("System") )
			{			
				continue;
			}
			
			// Grab all the attributes for this dataset
			params.put("id", dataset);
			List<Object> attributes = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params, "pa");
			
			// Dump all attribute details out
			for( Object attribute: attributes )
			{
				PhysicalAttribute pa = new PhysicalAttribute();
				pa.fromNode((Node)attribute);
				
				// dataset name
				Label label = new Label(ExcelExportToCypherService.DATASET_COL,rowCount,dataset);
				sheet.addCell(label);
				
				// Attribute is active
				label = new Label(ExcelExportToCypherService.ACTIVE_COL,rowCount, pa.active? "Y" : "N");
				sheet.addCell(label);

				// Attribute is queryable
				label = new Label(ExcelExportToCypherService.QUERYABLE_COL,rowCount, pa.queryable? "Y" : "N");
				sheet.addCell(label);

				// Attribute is derived
				label = new Label(ExcelExportToCypherService.DERIVED_COL,rowCount, pa.derived? "Y" : "N");
				sheet.addCell(label);

				// attribute name
				label = new Label(ExcelExportToCypherService.LOGICAL_ATTR_COL,rowCount,pa.id);
				sheet.addCell(label);
				
				// xpath
				label = new Label(ExcelExportToCypherService.PHYSICAL_ATTR_COL,rowCount,pa.xpath);
				sheet.addCell(label);
				
				datasetAttrRowMap.put(dataset + "-" + pa.id, rowCount);

				rowCount++;
			}
		}	
		
		// Now add all the views attribute positions
		cypherQuery = "match (v:View) return v order by v.id";
		List<Object> views = neo4jUtils.executeCypherQueryForObjects(cypherQuery, Collections.EMPTY_MAP, "v");
		int colNumber = ExcelExportToCypherService.PHYSICAL_ATTR_COL + 1;
		for( Object viewObj : views )
		{
			View view  = new View();
			view.fromNode( (Node)viewObj );
			
			// Now get all the attributes that the view selects
			params = new HashMap<String,Object>();
			cypherQuery = "match (v:View {id:{id}})-[r:SELECTS]->(pa:PhysicalAttribute)<-[:OWNS]-(pd:PhysicalDataset) return r.physicalAttribute as attr,r.viewAttributeName as viewAttrName,r.position as pos,pd.id as dataset order by r.position ASC";
			params.put("id",view.id);
			Iterator<Map<String,Object>> results = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
			
			while( results.hasNext() )
			{
				Map<String,Object> properties = results.next();
				String datasetName = properties.get("dataset").toString();
				String viewAttrName = properties.get("viewAttrName").toString();
				String attrName = properties.get("attr").toString();
				int pos = Integer.parseInt( properties.get("pos").toString() );
				String key = datasetName + "-" + attrName;
				int rowNumber = datasetAttrRowMap.get(key);
								
				String posString = "" + pos;
				if( !viewAttrName.equals(attrName) )
				{
					posString += "," + viewAttrName;
				}
				
				// attribute select position				
				Label label = new Label(colNumber,rowNumber,posString);				
				sheet.addCell(label);
			}
			colNumber++;
		}
	}
	
	/**
	 * Queries the database for all dataset and their sources and writes them to a worksheet
	 * @throws WriteException 
	 * @throws RowsExceededException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws InvocationTargetException 
	 * @throws NoSuchMethodException 
	 */
	private void generateSources() throws RowsExceededException, WriteException, IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException, InvocationTargetException
	{
		WritableSheet sheet = workbook.createSheet(ExcelExportToCypherService.SOURCE_SHEET_NAME, 1);
		
		writeSourcesSheetHeader(sheet);
		
		// Fetch all datasets and attributes
		List<String> datasets  = mds.getAllDatasets();
		
		int rowCount = ExcelExportToCypherService.SOURCES_START_ROW;
		for( String dataset : datasets )
		{
			// Ignore defining a source for "System"
			// TODO: Does anything actually _use_ this dataset??
			if( dataset.equals("System") )
			{			
				continue;
			}
			
			// dataset name
			Label label = new Label(ExcelExportToCypherService.SOURCES_DASTASET_COL,rowCount,dataset);
			label.setCellFormat(BOLD_BLUE_CELL_FORMAT);
			sheet.addCell(label);
			
			List<String> keys = mds.getDatasetKeyAttributeNames(dataset);
			String keysStr = keys.toString();
			keysStr = keysStr.substring(1,keysStr.length() - 1 );

			// key attributes name
			label = new Label(ExcelExportToCypherService.SOURCES_KEY_COL,rowCount,keysStr);
			sheet.addCell(label);

			List<String> roles = mds.getRolesForDataset(dataset);
			String rolesStr = roles.toString();
			rolesStr = rolesStr.substring(1,rolesStr.length() - 1 );

			// roles
			label = new Label(ExcelExportToCypherService.SOURCES_ROLES_COL,rowCount,rolesStr);
			sheet.addCell(label);

			// delimiter
			String delimiter = mds.getDelimiter(dataset);
			label = new Label(ExcelExportToCypherService.SOURCES_DELIMITER_COL,rowCount,delimiter);
			sheet.addCell(label);

			
			// URLS
			Map<String,Object> params = new HashMap<String,Object>();
			String cypherQuery = "match (d:Dataset {id:{id}})<-[:" + RELATIONSHIP_TYPE.PROVIDES + "]-(si:ServiceImplementation)-[r:" + RELATIONSHIP_TYPE.ACCESSED_VIA + "]->(n:Channel) return n";
			params.put("id",dataset);
			List <Node> nodes = neo4jUtils.executeCypherQueryForNodes(cypherQuery, params);
			if( nodes != null && nodes.size() > 0 )
			{
				String urls = "";
				for( Node node : nodes )
				{
					Channel channel  = convertNodeToChannel( node );
					if(channel.url != null )
					{
						urls += channel.url + "\n";
					}
				}
				if( !urls.isEmpty() )
				{
					label = new Label(ExcelExportToCypherService.SOURCES_URL_COL,rowCount,urls);
					sheet.addCell(label);
				}
			}

			// Fetch the delta URL directly without any property substituion that MDS does				
			params = new HashMap<String,Object>();
			cypherQuery = "match (d:Dataset {id:{id}})<-[:" + RELATIONSHIP_TYPE.PROVIDES + "]-(si:ServiceImplementation)-[r:" + RELATIONSHIP_TYPE.ACCESSED_VIA + "]->(n:HTTPChannel) return n";
			params.put("id",dataset);
			nodes = neo4jUtils.executeCypherQueryForNodes(cypherQuery, params);
			if( nodes != null && nodes.size() > 0 )
			{
				String appendDeltaUrl = "";
				String deltaUrl = "";
				for( Node node : nodes )
				{
					HTTPChannel channel  = new HTTPChannel();
					channel.fromNode(node);
					
					if( channel.deltaUrl != null && !channel.deltaUrl.isEmpty() )
					{
						// Is it a delta append
						if( channel.deltaUrl.startsWith(channel.url) )
						{
							appendDeltaUrl = channel.deltaUrl.substring(channel.url.length() );
							break;
						}
						// Otherwise its a new absolute Delta URL
						else
						{
							deltaUrl += channel.deltaUrl + "\n";
						}
					}
				}
				
				if( !appendDeltaUrl.isEmpty() )
				{
					label = new Label(ExcelExportToCypherService.SOURCES_URL_DELTA_APPEND_COL,rowCount,appendDeltaUrl);
					sheet.addCell(label);
				}
				
				if( !deltaUrl.isEmpty() )
				{
					label = new Label(ExcelExportToCypherService.SOURCES_URL_DELTA_COL,rowCount,deltaUrl);
					sheet.addCell(label);
				}
			}
			
			// namespaces
			Map<String,String> namespaceMap = mds.getNamespacesForDataset(dataset);
			String namespaces = "";
			for( String key : namespaceMap.keySet() )
			{
				namespaces += key + "=" + namespaceMap.get(key) + ",";
			}
			if( !namespaces.isEmpty() )namespaces = namespaces.substring(0,namespaces.length()-1);
			
			label = new Label(ExcelExportToCypherService.SOURCES_NAMESPACE_COL,rowCount,namespaces);
			sheet.addCell(label);

			// system
			params = new HashMap<String,Object>();
			cypherQuery = "match (d:Dataset {id:{id}})<-[:PROVIDES]-(si)<-[:IMPLEMENTED_BY]-(s)<-[:OFFERS]-(so:Source) return so.id;";
			params.put("id", dataset);
			List<Object> systemIDs = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params, "so.id");
			if( systemIDs != null && systemIDs.size() > 0 )
			{			
				String system = systemIDs.get(0).toString();
				label = new Label(ExcelExportToCypherService.SOURCES_SYSTEM_COL,rowCount,system);
				sheet.addCell(label);
			}

			// tableid
			try
			{
				String tableId = mds.getTableIdForDataset(dataset);
				label = new Label(ExcelExportToCypherService.SOURCES_TABLEID_COL,rowCount,tableId);
				sheet.addCell(label);
			}
			catch (Exception e1)
			{
				// Ignore if there is no table id
			}

			// authentication uri
			try
			{
				String authUri = mds.getSourceAuthenticationUriForDataset(dataset);
				label = new Label(ExcelExportToCypherService.SOURCES_AUTH_URI_COL,rowCount,authUri);
				sheet.addCell(label);
			}
			catch (MetadataException e)
			{
				// Ignore if there is no authentication uri
			}
			
			// JDBC details
			try
			{
				JDBCChannel jdbcDetails = mds.getDatabaseDetailsForDataset(dataset);
				label = new Label(ExcelExportToCypherService.SOURCES_USERNAME_COL,rowCount,jdbcDetails.username);
				sheet.addCell(label);
				label = new Label(ExcelExportToCypherService.SOURCES_PASSWORD_COL,rowCount,jdbcDetails.password);
				sheet.addCell(label);
				label = new Label(ExcelExportToCypherService.SOURCES_DRIVERCLASS_COL,rowCount,jdbcDetails.driverClass);
				sheet.addCell(label);
				label = new Label(ExcelExportToCypherService.SOURCES_SQL_COL,rowCount,jdbcDetails.querySQL);
				sheet.addCell(label);
				label = new Label(ExcelExportToCypherService.SOURCES_DELTA_SQL_COL,rowCount,jdbcDetails.queryDeltaSQL);
				sheet.addCell(label);
			}
			catch (MetadataException e)
			{
				// Ignore if there are jdbc details uri
			}

			// Jobs
			try
			{
				String jobs = "";
				for(String job : mds.getJobNamesForDataset(dataset)) {
					String separator = (jobs.equals("")?"":",");
					jobs += (separator + job);
				}
				label = new Label(ExcelExportToCypherService.SOURCES_JOBS_COL,rowCount,jobs);
				sheet.addCell(label);
			}
			catch (MetadataException e)
			{
				// Ignore if there are no defined jobs
			}

			rowCount ++;
		}
	}
	
	/**
	 * Queries the database for all transformations between datasets and writes them to a worksheet
	 * @throws WriteException 
	 * @throws RowsExceededException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws InvocationTargetException 
	 * @throws NoSuchMethodException 
	 */
	private void generateTransformations() throws RowsExceededException, WriteException, IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException, InvocationTargetException
	{
		WritableSheet sheet = workbook.createSheet(ExcelExportToCypherService.TRANSFORMATIONS_SHEET_NAME, 2);
		
		writeTransformationsSheetHeader(sheet);
		
		// Fetch all Transformations
		Map<String,Object> params = new HashMap<String,Object>();
		String cypherQuery = "match (sd:Dataset)-[r:SOURCE_OF]->(t:Transformer)<-[:TARGET_OF]-(td:Dataset) return sd,t,td order by sd.id";
		Iterator<Map<String,Object>> results = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
		
		int rowCount = ExcelExportToCypherService.TRANSFORMATIONS_START_ROW;
		while( results.hasNext() )
		{
			Map<String,Object> result = results.next();
			PhysicalDataset sd = new PhysicalDataset(); 
			sd.fromNode( (Node)result.get("sd") );

			PhysicalDataset td = new PhysicalDataset(); 
			td.fromNode( (Node)result.get("td") );
			 
			Transformer transformer = convertNodeToTransformer((Node)result.get("t"));
			
			// source dataset name
			Label label = new Label(ExcelExportToCypherService.SRC_DATASET_COL,rowCount,sd.id);
			sheet.addCell(label);

			// target dataset name
			label = new Label(ExcelExportToCypherService.TRGT_DATASET_COL,rowCount,td.id);
			sheet.addCell(label);
			
			// Transformer type
			String transformerType = transformer.getClass().getName();	
			label = new Label(ExcelExportToCypherService.TRANSFORMER_TYPE_COL,rowCount,transformerType);
			sheet.addCell(label);

			if( transformer instanceof ThinToWideTransformer )
			{
				// pre processor type
				label = new Label(ExcelExportToCypherService.PRE_PROCESSOR_RULESET_COL,rowCount,((ThinToWideTransformer)transformer).preProcessorRules);
				sheet.addCell(label);
								
				// Key Columns
				String keyColumns = "";
				cypherQuery = "match (t:Transformer {id:{id}})-[:HAS_KEY_COLUMN]->(pa:PhysicalAttribute) return pa.id";
				params = new HashMap<String,Object>();
				params.put("id", transformer.id);
				List<Object> attrIds = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params, "pa.id");				
				for( Object attrId: attrIds )
				{
					keyColumns += attrId.toString() + ",";
				}
				keyColumns =keyColumns.substring(0,keyColumns.length()-1);				
				label = new Label(ExcelExportToCypherService.KEY_COLUMNS_COL,rowCount,keyColumns);
				sheet.addCell(label);
				
				// pivot column
				cypherQuery = "match (t:Transformer {id:{id}})-[:HAS_PIVOT_COLUMN]->(pa:PhysicalAttribute) return pa.id";
				params = new HashMap<String,Object>();
				params.put("id", transformer.id);
				List<Object> pivotColumnValue = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params, "pa.id");										
				label = new Label(ExcelExportToCypherService.PIVOT_COLUMN_COL,rowCount,pivotColumnValue.get(0).toString());
				sheet.addCell(label);
				
				// Associated Pivot Columns
				String associatedPivotColumns = "";
				cypherQuery = "match (t:Transformer {id:{id}})-[:HAS_ASSOCIATED_PIVOT_COLUMN]->(pa:PhysicalAttribute) return pa.id";
				params = new HashMap<String,Object>();
				params.put("id", transformer.id);
				attrIds = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params, "pa.id");				
				for( Object attrId: attrIds )
				{
					associatedPivotColumns += attrId.toString() + ",";
				}
				associatedPivotColumns = associatedPivotColumns.substring(0,associatedPivotColumns.length()-1);				
				label = new Label(ExcelExportToCypherService.ASSOCIATED_PIVOT_COLUMNS_COL,rowCount,associatedPivotColumns);
				sheet.addCell(label);

				// target pivot value
				label = new Label(ExcelExportToCypherService.TARGET_PIVOT_VALUES_COL,rowCount,((ThinToWideTransformer)transformer).targetPivotValues);
				sheet.addCell(label);

			}

			// Rulesets
			if( transformer instanceof RulesTransformer )
			{
				label = new Label(ExcelExportToCypherService.RULESET_COL,rowCount,((RulesTransformer)transformer).ruleset);
				sheet.addCell(label);
			}

			rowCount++;
		}	
	}
	
	/**
	 * Queries the database for all joins between attributes and writes them to a worksheet
	 * @throws WriteException 
	 * @throws RowsExceededException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws InvocationTargetException 
	 * @throws NoSuchMethodException 
	 */
	private void generateJoins() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, RowsExceededException, WriteException, NoSuchMethodException, InvocationTargetException
	{
		WritableSheet sheet = workbook.createSheet(ExcelExportToCypherService.JOINS_SHEET_NAME, 2);
		
		// Fetch all Transformations
		Map<String,Object> params = new HashMap<String,Object>();
		String cypherQuery = "match (pd1:PhysicalDataset)-[:OWNS]->(pa1:PhysicalAttribute)-[:JOINED_TO]->(pa2:PhysicalAttribute)<-[:OWNS]-(pd2:PhysicalDataset) return pd1,pa1,pd2,pa2 order by pd1.id,pd2.id";
		Iterator<Map<String,Object>> results = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
		
		Map<String,Integer> fromDatasetRowMap = new HashMap<String,Integer>();
		Map<String,Integer> toDatasetColMap = new HashMap<String,Integer>();
		
		int rowCount = 1;
		int colCount = 1;
		Integer row = -1;
		Integer col = -1;
		while( results.hasNext() )
		{
			Map<String,Object> result = results.next();
			
			PhysicalDataset pd1 = new PhysicalDataset(); 
			pd1.fromNode( (Node)result.get("pd1") );
			
			row = fromDatasetRowMap.get(pd1.id);
			if( row == null )
			{
				row = rowCount++;
				fromDatasetRowMap.put(pd1.id,row);
			}

			PhysicalDataset pd2 = new PhysicalDataset(); 
			pd2.fromNode( (Node)result.get("pd2") );
			
			col = toDatasetColMap.get(pd2.id);
			if( col == null )
			{
				col = colCount++;
				toDatasetColMap.put(pd2.id,col);
			}

			
			PhysicalAttribute pa1 = new PhysicalAttribute(); 
			pa1.fromNode( (Node)result.get("pa1") );

			PhysicalAttribute pa2 = new PhysicalAttribute(); 
			pa2.fromNode( (Node)result.get("pa2") );
						
			// From dataset name
			Label label = new Label(0,row,pd1.id);
			sheet.addCell(label);
			
			// To dataset name
			label = new Label(col,0,pd2.id);
			sheet.addCell(label);

			// Join
			String attributes = pa1.id + "," + pa2.id;
			label = new Label(col,row,attributes);
			sheet.addCell(label);			
		}
	}
	
	/**
	 * Converts a Node with label type of Transformer to a specific
	 * sub class of Transformer
	 * @param node
	 * @return
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws InvocationTargetException 
	 * @throws NoSuchMethodException 
	 */
	private Transformer convertNodeToTransformer( Node node ) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException, InvocationTargetException
	{
		if( !node.hasLabel(DynamicLabel.label(Transformer.class.getSimpleName())) )
		{
			throw new RuntimeException("Node " + node + " is not a Transformer node");
		}
		if( node.hasLabel(DynamicLabel.label(ThinToWideTransformer.class.getSimpleName())) )
		{
			ThinToWideTransformer transformer = new ThinToWideTransformer();
			transformer.fromNode(node);
			return transformer;
		}
		else if( node.hasLabel(DynamicLabel.label(RulesTransformer.class.getSimpleName())) )
		{
			RulesTransformer transformer = new RulesTransformer();
			transformer.fromNode(node);
			return transformer;
		}
		else
		{
			Transformer transformer = new Transformer();
			transformer.fromNode(node);
			return transformer;			
		}
	}

	/**
	 * Converts a Node with label type of Channel to a specific
	 * sub class of Channel
	 * @param node
	 * @return
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws InvocationTargetException 
	 * @throws NoSuchMethodException 
	 */
	private Channel convertNodeToChannel( Node node ) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException, InvocationTargetException
	{
		if( !node.hasLabel(DynamicLabel.label(Channel.class.getSimpleName())) )
		{
			throw new RuntimeException("Node " + node + " is not a Channel node");
		}
		if( node.hasLabel(DynamicLabel.label(HTTPChannel.class.getSimpleName())) )
		{
			HTTPChannel channel = new HTTPChannel();
			channel.fromNode(node);
			return channel;
		}
		else if( node.hasLabel(DynamicLabel.label(JDBCChannel.class.getSimpleName())) )
		{
			JDBCChannel channel = new JDBCChannel();
			channel.fromNode(node);
			return channel;
		}
		else
		{
			Channel channel = new Channel();
			channel.fromNode(node);
			return channel;			
		}
	}

	
	/**
	 * Writes the header columns to the dataset sheet
	 * @param sheet
	 * @throws WriteException 
	 * @throws RowsExceededException 
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws InvocationTargetException 
	 * @throws NoSuchMethodException 
	 */
	private void writeDatsetSheetHeader( WritableSheet sheet ) throws RowsExceededException, WriteException, IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException, InvocationTargetException
	{
		Label label = new Label(ExcelExportToCypherService.ACTIVE_COL,0, "Active");
		label.setCellFormat(BOLD_CELL_FORMAT);
		sheet.addCell(label);

		label = new Label(ExcelExportToCypherService.QUERYABLE_COL,0, "Queryable");
		label.setCellFormat(BOLD_CELL_FORMAT);
		sheet.addCell(label);

		label = new Label(ExcelExportToCypherService.DERIVED_COL,0, "Derived");
		label.setCellFormat(BOLD_CELL_FORMAT);
		sheet.addCell(label);

		label = new Label(ExcelExportToCypherService.ENTITY_COL,0, "Entity");
		label.setCellFormat(BOLD_CELL_FORMAT);
		sheet.addCell(label);

		label = new Label(ExcelExportToCypherService.DATASET_COL,0, "Dataset");
		label.setCellFormat(BOLD_CELL_FORMAT);
		sheet.addCell(label);

		
		label = new Label(ExcelExportToCypherService.DATASET_COL,1, "Delimiter");
		label.setCellFormat(GREY_CELL_FORMAT);
		sheet.addCell(label);
		label = new Label(ExcelExportToCypherService.DATASET_COL,2, "Union All");
		label.setCellFormat(GREY_CELL_FORMAT);
		sheet.addCell(label);
		label = new Label(ExcelExportToCypherService.DATASET_COL,3, "Relations");
		label.setCellFormat(GREY_CELL_FORMAT);
		sheet.addCell(label);
		label = new Label(ExcelExportToCypherService.DATASET_COL,4, "FileService");
		label.setCellFormat(GREY_CELL_FORMAT);
		sheet.addCell(label);
		label = new Label(ExcelExportToCypherService.LOGICAL_ATTR_COL,4, "SYSDATE");
		sheet.addCell(label);

		
		label = new Label(ExcelExportToCypherService.LOGICAL_ATTR_COL,0, "Logical Attribute");
		label.setCellFormat(BOLD_CELL_FORMAT);
		sheet.addCell(label);

		label = new Label(ExcelExportToCypherService.PHYSICAL_ATTR_COL,0, "Physical Attribute");
		label.setCellFormat(BOLD_CELL_FORMAT);
		sheet.addCell(label);

		// Now add all the views across remaining columns
		String cypherQuery = "match (v:View) return v order by v.id";
		List<Object> views = neo4jUtils.executeCypherQueryForObjects(cypherQuery, Collections.EMPTY_MAP, "v");
		int colNumber = ExcelExportToCypherService.PHYSICAL_ATTR_COL + 1;
		for( Object viewObj : views )
		{
			View view  = new View();
			view.fromNode( (Node)viewObj );
			
			// View name
			label = new Label(colNumber,0, view.id);
			label.setCellFormat(BOLD_BLUE_CELL_FORMAT);
			sheet.addCell(label);

			// Delimiter
			label = new Label(colNumber,ExcelExportToCypherService.DELIMITERS_LINE_NUMBER, view.delimiter);
			sheet.addCell(label);

			// union all
			label = new Label(colNumber,ExcelExportToCypherService.UNIONALL_LINE_NUMBER, view.unionAll ? "Y":"N");
			sheet.addCell(label);
			
			// Joins Relations
			List<JoinRelation> joinRelations = mds.getJoinRelationsForDataset(view.id);
			String joinRelationString = "";
			for( JoinRelation jr : joinRelations )
			{
				List<PhysicalDataset> physicalDatasets = jr.getOrderedDatasets();
				for( PhysicalDataset pd : physicalDatasets )
				{
					joinRelationString += pd.id + "_";
				}
				joinRelationString = joinRelationString.substring(0,joinRelationString.length()-1) + ",";
			}
			joinRelationString = joinRelationString.substring(0,joinRelationString.length()-1);
			
			// Selected attributes positions
			label = new Label(colNumber,ExcelExportToCypherService.RELATIONS_LINE_NUMBER, joinRelationString);
			sheet.addCell(label);
			
			
			colNumber++;
		}
	}
	
	/**
	 * Writes the header columns to the sources sheet
	 * @param sheet
	 * @throws WriteException 
	 * @throws RowsExceededException 
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	private void writeSourcesSheetHeader( WritableSheet sheet ) throws RowsExceededException, WriteException, IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException
	{
		String[] headers = {"Dataset","Key","Roles","Delimiter","URL","URL Delta","URL Delta Append","Namespace","System","TableId","Authentication URI","Username","Password","Driver","SQL","SQL Delta","Jobs"};
		
		int colCount = 0;
		for( String header : headers )
		{
			Label label = new Label(colCount++,0, header);
			label.setCellFormat(BOLD_BLUE_CELL_FORMAT);
			sheet.addCell(label);			
		}
	}
	
	/**
	 * Writes the header columns to the transformations sheet
	 * @param sheet
	 * @throws WriteException 
	 * @throws RowsExceededException 
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	private void writeTransformationsSheetHeader( WritableSheet sheet ) throws RowsExceededException, WriteException, IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException
	{
		String[] headers = {"Source Dataset","Target Dataset","Transformer Type","Pre-processor Rulesets","Rulesets","KeyColumns","Pivot Column","Associated Pivot Columns","Target Pivot Values"};
		
		int colCount = 0;
		for( String header : headers )
		{
			Label label = new Label(colCount++,0, header);
			label.setCellFormat(BOLD_CELL_GREENBACK_FORMAT);
			sheet.addCell(label);			
		}
	}
}
