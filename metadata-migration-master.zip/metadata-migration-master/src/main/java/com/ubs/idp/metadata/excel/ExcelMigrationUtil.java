package com.ubs.idp.metadata.excel;

import java.io.File;
import java.io.InputStream;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.PosixParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.ubs.idp.metadata.client.Neo4jUtils;
import com.ubs.idp.metadata.service.export.excel.ExcelExportToCypherService;

/**
 * Tool to export the excel meta model to Neo4j
 * 
 * @author loverids
 * 
 */
@Component
@ComponentScan("com.ubs.idp.metadata.client")
public class ExcelMigrationUtil {
    
    ExcelExportToCypherService excelExportService = new ExcelExportToCypherService();

    @Autowired
    Neo4jUtils neo4jUtils;

    private static Logger logger = LoggerFactory.getLogger(ExcelMigrationUtil.class);

    private static final String OPTION_HELP = "--help";
    private static final String OPTION_NEO4J_DB_PATH = "neo4jDatabasePath";

    /**
     * Provides a service that exports an excel spreadsheet to cypher then seeds
     * the current database instance with it.
     * 
     * Intended to be the main method called from a macro within the Excel
     * spreadsheet so that changes to the metadata can be quickly seeded into
     * the database for testing
     * 
     * @param excelFile
     * @throws Exception
     */
    public void exportFromExcelAndSeedDatabase(File cypherFile) throws Exception {
        try (InputStream is = getClass().getResourceAsStream("/IDPMetadataModel.xls")) {
            excelExportService.loadExcelFromStream(is);
            excelExportService.exportToFileAsCypher(cypherFile);

            neo4jUtils.clearDatabase();
            neo4jUtils.loadMetaDataFromCypherFile(cypherFile);
        }
    }

    public final static void main(String[] args) throws Exception {
        Options options = new Options();

        // Mandatory bits
        Option serverPath = new Option(null, OPTION_NEO4J_DB_PATH, true, "The file path to the Neo4j database");
        serverPath.setRequired(true);
        options.addOption(serverPath);

        printHelp(args, options);

        CommandLineParser clp = new PosixParser();
        CommandLine cmd = null;
        try {
            cmd = clp.parse(options, args);
        } catch (Exception e) {
            printHelp(new String[] { OPTION_HELP }, options);
        }

        String dbPath = cmd.getOptionValue(OPTION_NEO4J_DB_PATH).trim();

        System.setProperty("neo4j.dbUrl", "");
        System.setProperty("neo4j.dbPath", dbPath);
        System.setProperty("neo4j.mode", "embedded");

        // ------------
        System.setProperty("neo4jDBPath", cmd.getOptionValue(OPTION_NEO4J_DB_PATH).trim());

        
        ApplicationContext context = new AnnotationConfigApplicationContext(ExcelMigrationUtil.class);
        ExcelMigrationUtil exportTool = context.getBean(ExcelMigrationUtil.class);
        exportTool.exportFromExcelAndSeedDatabase(new File(dbPath + "/dump.cypher"));

        logger.info("Seeded database successfully at {}", dbPath);
    }

    private static void printHelp(String[] args, Options options) {
        for (int i = 0; i < args.length; i++) {
            if (OPTION_HELP.equals(args[i])) {
                HelpFormatter formatter = new HelpFormatter();
                formatter.printHelp(ExcelMigrationUtil.class.getSimpleName(), options);
                System.exit(0);
            }
        }
    }
}
