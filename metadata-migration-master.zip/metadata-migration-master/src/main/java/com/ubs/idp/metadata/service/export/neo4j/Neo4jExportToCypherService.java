package com.ubs.idp.metadata.service.export.neo4j;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ubs.idp.metadata.client.Neo4jUtils;
import com.ubs.idp.metadata.model.enums.RELATIONSHIP_TYPE;
import com.ubs.idp.metadata.service.export.ExportToCypherService;

/**
 * Implementation of the cypher exporter that converts Neo4j database instance
 * into a full export as a cypher script
 * @author loverids
 *
 */
@Service
public class Neo4jExportToCypherService extends ExportToCypherService
{
	@Autowired
	Neo4jUtils neo4jUtils;
	
	
	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.metadata.service.export.ExportToCypherService#getAllNodesOfLabelType(int, int, java.lang.String)
	 */
	@Override
	public List<Node> getAllNodesOfLabelType(int offset, int limit, String labelType)
	{
		List<Node> nodes = null;
		String cypherQuery = "match (n:" + labelType + ") return n SKIP {offset} LIMIT {limit} ";

		// Create the query params
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("offset", offset);
		params.put("limit", limit);
				
		nodes = neo4jUtils.executeCypherQueryForNodes(cypherQuery, params);
		return nodes;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.metadata.service.export.ExportToCypherService#getAllAttributesForDataset(java.lang.String)
	 */
	@Override
	public List<Node> getAllAttributesForDataset(String datasetId)
	{
		List<Node> nodes = null;
		String cypherQuery = "match (pd:Dataset {id:{id}})-[r:OWNS|SELECTS]->(n) return n order by r.position,n.position ASC";

		// Create the query params
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", datasetId);
				
		nodes = neo4jUtils.executeCypherQueryForNodes(cypherQuery, params);
		return nodes;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.metadata.service.export.ExportToCypherService#getKeyForDataset(java.lang.String)
	 */
	@Override
	public Node getKeyForDataset(String datasetId)
	{
		List<Node> nodes = null;
		String cypherQuery = "match (pd:Dataset {id:{id}})<-["+ RELATIONSHIP_TYPE.PRIMARY_IDENTIFIER_OF +"]-(n:PhysicalKey) return n";

		// Create the query params
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", datasetId);
				
		nodes = neo4jUtils.executeCypherQueryForNodes(cypherQuery, params);
		
		return nodes.size() > 0 ? nodes.get(0) : null;
	}

	@Override
	public Map<Node,Node> getAttributesAndKeyElementsForKey(String keyId)
	{
		Map<Node,Node> nodes = new HashMap<Node,Node>();
		String cypherQuery = "match (pk:PhysicalKey {id:{id}})<-[:KEY_ELEMENT_OF]-(pke:PhysicalKeyElement)<-[:MAKES_UP]-(pa:PhysicalAttribute) return pke,pa";

		// Create the query params
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", keyId);

		
        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);

        while (result.hasNext()) {
            Map<String, Object> row = result.next();

            Node attribute = (Node)row.get("pa");
            Node keyElement = (Node)row.get("pke");

            nodes.put(attribute,keyElement);
        }
		
		return nodes;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.metadata.service.export.ExportToCypherService#getAllRelationshipsForAttribute(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Relationship> getAllRelationshipsForAttribute(String datasetId, String attributeId)
	{
		String cypherQuery = "match (d:PhysicalDataset {id:{did}})-[:"+RELATIONSHIP_TYPE.OWNS+"]->(a:PhysicalAttribute {id:{id}})-[r]-(m) return r";

		// Create the query params
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", attributeId);
		params.put("did", datasetId);
				
		return neo4jUtils.executeCypherQueryForRelationsips(cypherQuery, params);
	}

	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.metadata.service.export.ExportToCypherService#getAllRelationships(int, int)
	 */
	@Override
	public List<Relationship> getAllRelationships(int offset, int limit)
	{
		return neo4jUtils.getAllRelationships(offset, limit);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.metadata.service.export.ExportToCypherService#getAllJoinedAttributes()
	 */
	@Override
	public List<Map<String,Node>> getAllJoinedAttributes()
	{
		List<Map<String,Node>> joinedAttributes = new ArrayList<Map<String,Node>>();
		
		String cypherQuery = "MATCH (d1:PhysicalDataset)-[:OWNS]->(a1:PhysicalAttribute)-[:JOINED_TO]-(a2:PhysicalAttribute)<-[:OWNS]-(d2:PhysicalDataset) return d1,d2,a1,a2";
		Iterator<Map<String,Object>> results = neo4jUtils.executeCypherQueryForObjects(cypherQuery, Collections.EMPTY_MAP);

		while( results.hasNext() )
		{									
			Map<String,Object> row = results.next();
			Map<String,Node> nodeRow = new HashMap<String,Node>();
			
			Iterator<String> keys = row.keySet().iterator();
			while( keys.hasNext() )
			{
				String key = keys.next();
				nodeRow.put(key, (Node)row.get(key));
				joinedAttributes.add(nodeRow);
			}			
		}
		
		return joinedAttributes;
	}
}
