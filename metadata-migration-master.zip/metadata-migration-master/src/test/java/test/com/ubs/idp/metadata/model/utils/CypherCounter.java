package test.com.ubs.idp.metadata.model.utils;

public class CypherCounter {
    public int nodeCreateCount = 0;
    public int relCreateCount = 0;
}
