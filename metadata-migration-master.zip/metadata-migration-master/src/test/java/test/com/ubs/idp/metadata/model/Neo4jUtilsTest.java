package test.com.ubs.idp.metadata.model;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.HashSet;
import java.util.Set;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import test.com.ubs.idp.metadata.model.utils.CypherCounter;

import com.ubs.idp.metadata.service.export.neo4j.Neo4jExportToCypherService;

public class Neo4jUtilsTest extends EmbeddedBaseTest {
    @Autowired
    Neo4jExportToCypherService exportService;

    @Test
    public void testLargeLoad() throws IOException {
        neo4jUtils.clearDatabase();
        assertEquals("Node count incorrect", 0, neo4jUtils.getNodeCount());
        assertEquals("Node count incorrect", 0, neo4jUtils.getRelationshipCount());

        neo4jUtils.loadMetaDataFromCypherFile(new File("src/test/resources/dump.cypher"));

        neo4jUtils.dumpAllNodesWithIdsFromDatabase("target/COMP_NODES_DB_AFTER.txt");

        assertEquals("Node count incorrect", 6478, neo4jUtils.getNodeCount());
        assertEquals("Relationship count incorrect", 8314, neo4jUtils.getRelationshipCount());
    }

    public static CypherCounter getNodeAndRelationshipCountFromCypherFile(String filename) throws FileNotFoundException, IOException {
        return getNodeAndRelationshipCountFromCypherFile(new FileInputStream(filename));
    }

    public static CypherCounter getNodeAndRelationshipCountFromCypherFile(InputStream is) throws FileNotFoundException, IOException {
        CypherCounter counter = new CypherCounter();
        Set<String> idStore = new HashSet<String>();
        int lineCount = 1;

        try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            String line = "";

            while ((line = br.readLine()) != null) {
                if (line.trim().startsWith("CREATE")) {
                    // Check for relationships
                    if (line.contains("-[") && line.contains("]-")) {
                        counter.relCreateCount++;
                    } else {
                        counter.nodeCreateCount++;
                        String id = line.substring(line.indexOf("id:\"") + 4);
                        id = id.substring(0, id.indexOf("\""));

                        String labels = line.substring(line.indexOf(":") + 1);

                        if (labels.contains(":")) {
                            labels = labels.substring(0, labels.indexOf(":"));
                        } else {
                            labels = labels.substring(0, labels.indexOf(" ")).trim();
                        }

                        String key = labels + ":" + id;

                        if (!idStore.contains(key)) {
                            idStore.add(key);
                        } else if (!line.contains("PhysicalAttribute")) {
                            System.err.println("Possible duplicate node at line " + lineCount + " key=" + key);
                        }

                    }
                }

                lineCount++;
            }
        } catch (Exception ex) {
            System.err.println("Error on line " + lineCount + ": " + ex);
            ex.printStackTrace();
        }

        return counter;
    }

    public static void dumpAllNodesAndRelationshipsFromCypherFile(String filename) throws FileNotFoundException {
        dumpAllNodesAndRelationshipsFromCypherInputStream(new FileInputStream(filename));
    }

    public static void dumpAllNodesAndRelationshipsFromCypherInputStream(InputStream is) {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is));
                PrintStream nodeFile = new PrintStream("target/COMP_NODES_CYPHER.txt");
                PrintStream relFile = new PrintStream("target/COMP_RELS_CYPHER.txt")) {
            String line = "";

            while ((line = br.readLine()) != null) {
                if (line.trim().startsWith("CREATE")) {
                    if (line.contains("-[") && line.contains("]-")) {
                        String rel = line.substring(line.indexOf(" ") + 1).trim();
                        rel = rel.substring(rel.indexOf("-"));
                        if (rel.contains(" ") && rel.indexOf(" ") < rel.lastIndexOf("]")) {
                            rel = rel.substring(0, rel.indexOf(" ")).trim() + "]-";
                        } else {
                            rel = rel.substring(0, rel.lastIndexOf("-") + 1);
                        }
                        relFile.println(rel);
                    } else {
                        String id = line.substring(line.indexOf("id:\"") + 4);
                        id = id.substring(0, id.indexOf("\""));

                        String labels = line.substring(line.indexOf(":") + 1);
                        labels = labels.substring(0, labels.indexOf(" "));
                        labels = labels.replace(":", ", ");

                        nodeFile.println("[" + labels + "]:" + id);
                    }
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}