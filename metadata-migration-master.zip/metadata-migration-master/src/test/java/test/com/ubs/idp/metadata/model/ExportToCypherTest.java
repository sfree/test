package test.com.ubs.idp.metadata.model;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileNotFoundException;

import junitx.framework.FileAssert;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.internal.runners.statements.ExpectException;
import org.junit.rules.ExpectedException;
import org.springframework.beans.factory.annotation.Autowired;

import test.com.ubs.idp.metadata.model.utils.CypherCounter;

import com.ubs.idp.metadata.service.export.excel.ExcelExportToCypherService;
import com.ubs.idp.metadata.service.export.neo4j.Neo4jExportToCypherService;

public class ExportToCypherTest extends EmbeddedBaseTest {
    @Autowired
    ExcelExportToCypherService excelExportService;

    @Autowired
    Neo4jExportToCypherService neo4jExportService;
    
    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    private final static String EXCEL_CYPHER_DUMP_COMPARE_FILE = "src/test/resources/excel_dump.cypher";
    
    private final static String EXCEL_CYPHER_DUMP_FILE = "target/excel_dump.cypher";

    private final static String NEO4J_CYPHER_DUMP_FILE = "target/neo4j_dump.cypher";

    private final static String MAIN_EXCEL_FILE = "src/main/resources/IDPMetadataModel.xls";

    private final static String TEST_EXCEL_FILE = "src/test/resources/TEST-IDPMetadataModel.xls";

    private final static String TEST_EXCEL_FILE_DUP_ATTRIBUTE = "src/test/resources/TEST2-IDPMetadataModel.xls";

    @Before
    public void clear() {
        neo4jUtils.clearDatabase();
        assertEquals(0, neo4jUtils.getNodeCount());
        assertEquals(0, neo4jUtils.getRelationshipCount());

        new File(EXCEL_CYPHER_DUMP_FILE).delete();
        new File(NEO4J_CYPHER_DUMP_FILE).delete();
    }

    public void dumpOutDifferences() throws FileNotFoundException {
        neo4jUtils.dumpAllNodesWithIdsFromDatabase("target/COMP_NODES_DB.txt");
        neo4jUtils.dumpAllRelationshipsFromDatabase("target/COMP_RELS_DB.txt");
        Neo4jUtilsTest.dumpAllNodesAndRelationshipsFromCypherFile(EXCEL_CYPHER_DUMP_FILE);
    }

    @Test
    public void testExcelToCypherToNeo4jToCypherToExcel() throws Exception {
        File excelFile = new File(TEST_EXCEL_FILE);
        File excelCypherdumpFile = new File(EXCEL_CYPHER_DUMP_FILE);
        File neo4jCypherdumpFile = new File(NEO4J_CYPHER_DUMP_FILE);

        // Export from the master test spreadsheet to cypher script
        excelExportService.loadExcelFile(excelFile);
        excelExportService.exportToFileAsCypher(excelCypherdumpFile);

        // Check the cypher output
        CypherCounter counter = Neo4jUtilsTest.getNodeAndRelationshipCountFromCypherFile(EXCEL_CYPHER_DUMP_FILE);
        assertEquals("Node count incorrect", 850, counter.nodeCreateCount);                
        assertEquals("Relationship count incorrect", 935, counter.relCreateCount);
        
        FileAssert.assertEquals(new File(EXCEL_CYPHER_DUMP_COMPARE_FILE), excelCypherdumpFile);

        // Clear the embedded neo instance and load in from cypher
        neo4jUtils.clearDatabase();
        neo4jUtils.loadMetaDataFromCypherFile(excelCypherdumpFile);

        // Export from neo and check
        neo4jExportService.exportToFileAsCypher(neo4jCypherdumpFile);
        counter = Neo4jUtilsTest.getNodeAndRelationshipCountFromCypherFile(NEO4J_CYPHER_DUMP_FILE);
        assertEquals("Node count incorrect", 850, counter.nodeCreateCount);
        assertEquals("Relationship count incorrect", 935, counter.relCreateCount);
        
        dumpOutDifferences();
    }
    
    @Test
    public void validateMainSpreadsheet() throws Exception
    {
        File excelFile = new File(MAIN_EXCEL_FILE);

        excelExportService.loadExcelFile(excelFile);
    }

    
    @Test
    public void shouldFailIfDatasetHasDupAttribute() throws Exception
    {
        File excelFile = new File(TEST_EXCEL_FILE_DUP_ATTRIBUTE);
        File excelCypherdumpFile = new File(EXCEL_CYPHER_DUMP_FILE);
        
        expectedException.expect(RuntimeException.class);
        expectedException.expectMessage("Duplicate attribute detected on row 8! The dataset with id=BONDISSUE already has an attribute with id=party.lastUpdatedTime");

        // Export from the master test spreadsheet to cypher script
        excelExportService.loadExcelFile(excelFile);
        excelExportService.exportToFileAsCypher(excelCypherdumpFile);        
    }
}
