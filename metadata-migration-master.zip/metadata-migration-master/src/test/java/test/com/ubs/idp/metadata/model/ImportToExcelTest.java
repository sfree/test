package test.com.ubs.idp.metadata.model;

import static org.junit.Assert.assertEquals;

import java.io.File;

import junitx.framework.FileAssert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.ubs.idp.metadata.service.export.excel.ExcelExportToCypherService;
import com.ubs.idp.metadata.service.export.neo4j.Neo4jExportToCypherService;
import com.ubs.idp.metadata.service.imprt.excel.ImportToExcelService;

public class ImportToExcelTest extends EmbeddedBaseTest {
    @Autowired
    ImportToExcelService excelImportService;

    @Autowired
    ExcelExportToCypherService excelExportService;

    @Autowired
    Neo4jExportToCypherService neo4jExportService;

    private final static String SRC_CYPHER_FILE = "src/test/resources/excel_dump.cypher";
    private final static String TGT_CYPHER_FILE = "target/generated_excel_dump.cypher";
    private final static String TGT_EXCEL_FILE = "target/metadata.xls";

    @Before
    public void clear() {
        neo4jUtils.clearDatabase();

        assertEquals(0, neo4jUtils.getNodeCount());
        assertEquals(0, neo4jUtils.getRelationshipCount());

        new File(TGT_CYPHER_FILE).delete();
        new File(TGT_EXCEL_FILE).delete();
    }

    @Test
    public void testExcelToCypherToNeo4jToCypher() throws Exception {
        File excelFile = new File(TGT_EXCEL_FILE);
        File srcCypherFile = new File(SRC_CYPHER_FILE);
        File tgtCypherFile = new File(TGT_CYPHER_FILE);

        // Seed the neo4j instance from the test cypher dump
        neo4jUtils.loadMetaDataFromCypherFile(srcCypherFile);

        // Create an excel file from the database
        excelImportService.generateExcelFile(excelFile);

        // Now export the spreadsheet to cypher and compare to the original dump
        excelExportService.loadExcelFile(excelFile);
        excelExportService.exportToFileAsCypher(tgtCypherFile);

        // Do the diff
        FileAssert.assertEquals(srcCypherFile, tgtCypherFile);
    }
}
