package test.com.ubs.idp.metadata.model;

import org.neo4j.graphdb.GraphDatabaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AdviceMode;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.neo4j.config.JtaTransactionManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EnableTransactionManagement(mode = AdviceMode.ASPECTJ)
@Configuration
public class Neo4jTransactionConfiguration {
    @Autowired
    GraphDatabaseService graphDatabaseService;

    @Bean(name = { "neo4jTransactionManager", "transactionManager" })
    @Qualifier("neo4jTransactionManager")
    public PlatformTransactionManager neo4jTransactionManager() throws Exception {
        return new JtaTransactionManagerFactoryBean(graphDatabaseService).getObject();
    }
}
