package test.com.ubs.idp.metadata;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.metadata.client.CustomNeo4jConfiguration;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.client.Neo4jUtils;
import com.ubs.idp.metadata.model.JDBCChannel;
import com.ubs.idp.metadata.model.JoinRelation;
import com.ubs.idp.metadata.model.PhysicalDataset;
import com.ubs.idp.metadata.service.export.excel.ExcelExportToCypherService;

@RunWith(SpringJUnit4ClassRunner.class)
@PropertySource("classpath:applicationTest.properties")
@ContextConfiguration(classes = {CustomNeo4jConfiguration.class, ExcelMigrationIntegrationTest.class})
@Configuration
@ComponentScan({ "com.ubs.idp.metadata.client", "com.ubs.idp.metadata.service" })
public class ExcelMigrationIntegrationTest
{
    private final static String EXCEL_CYPHER_DUMP_FILE = "src/main/resources/ExcelCypherExport.txt";
    private final static String SRC_EXCEL_FILE = "src/main/resources/IDPMetadataModel.xls";
    private static boolean migrationComplete = false;
    private static boolean migrationFailed = false;

    @Autowired
    @Qualifier("neo4jMetadataService")
    private MetadataService mds;

	@Autowired
	private ExcelExportToCypherService excelExportService;

	@Autowired
	private Neo4jUtils neo4jUtils;

	static {
        System.setProperty("environment", "test");
    }

	@Before
	public void doMigration() throws Exception
	{
		if( migrationFailed )
		{
			throw new Exception("Not running migration again as it has previously failed!");
		}

		if( !migrationComplete )
		{
			try
			{
				File excelFile = new File(SRC_EXCEL_FILE);
				File excelCypherdumpFile = new File(EXCEL_CYPHER_DUMP_FILE);

				excelExportService.loadExcelFile(excelFile);
				excelExportService.exportToFileAsCypher(excelCypherdumpFile);

				neo4jUtils.clearDatabase();
				neo4jUtils.loadMetaDataFromCypherFile(excelCypherdumpFile);
				migrationComplete = true;
			}
			catch (Exception e)
			{
				migrationFailed = true;
				throw e;
			}
		}
	}

	@Test
	public void testGetDelimiter()
	{
		assertEquals("\t", mds.getDelimiter("EQUITY"));
		assertEquals(",", mds.getDelimiter("InstrumentPricing"));
		assertEquals("\t", mds.getDelimiter("DSCURRENCY.IDP"));
		assertEquals("\t", mds.getDelimiter("CURRENCY"));
		assertEquals("\t", mds.getDelimiter("CURRENCY.IDP"));
		assertEquals("\t", mds.getDelimiter("EQUITY.IDP"));
		assertEquals("\t", mds.getDelimiter("BONDTL.IDP"));
		assertEquals("\t", mds.getDelimiter("EQUITY.TRANSFORMED"));
		assertEquals("\t", mds.getDelimiter("BONDTL.TRANSFORMED"));
		assertEquals("\t", mds.getDelimiter("Ultrabond.IDP"));
		assertEquals("\t", mds.getDelimiter("RATING.IDP"));
	}

	@Test
	public void testGetJobNamesForDataset()
	{
		assertEquals(Arrays.asList("loadDSCurrency", "loadRating", "loadMTS", "loadBondIssue", "loadBondTL",
				"loadEquity"), mds.getJobNamesForDataset("InstrumentSecFunding"));
		assertEquals(Arrays.asList("loadDSCurrency"), mds.getJobNamesForDataset("DSCURRENCY.IDP"));
		assertEquals(Arrays.asList("loadMTS"), mds.getJobNamesForDataset("MTS.IDP"));
		assertEquals(Arrays.asList("loadBondIssue"), mds.getJobNamesForDataset("BONDISSUE.IDP"));
		assertEquals(Arrays.asList("loadBondTL"), mds.getJobNamesForDataset("BONDTL.IDP"));
		assertEquals(Arrays.asList("loadEquity"), mds.getJobNamesForDataset("EQUITY.IDP"));
		assertEquals(Arrays.asList("loadRating"), mds.getJobNamesForDataset("RATING.IDP"));
	}


    @Test
    public void testGetUrlForChannel() throws Exception
    {
        String expectedBONDTL = "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=tL&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJyNWduS4ygS_aGJntiI-QGX3TXh2Kq2p1zdEfOIBJJpI1ADctn99Xu4SKBLrfxiiZMpSPIOti9fStVJq-_fC7Onf9iXLw35qfQPpg1X0o0FMfZ7S4ll9J03zEGktPzq34wltjPuzXLauCe7lWcia08tO62ZLO9-GmVP_Hf4iFEl3MuvTuF7rPN-b1mYpLww7d80oWwbRHNjzUv_AEJf0lRdYV6JvjD7SuKH3FDyxuoovGrDSprVp7PaErvxMnZaSXazI8qTl1hJowQPuz1rZs5K0L30imG2-HqzTEsi4nAv05C36lmQOmjQSXRidcOk7aWIkxTFNlMKdnWoMEskts3p3hRB4rAP8RXq3CrKMujNapPDDa84dYpQxr7wXx2nP5jsPIk24lWyRsmgPal0Q0RQWK_BkggmKdFh917fh8op0MAENqqRdKV7PTHTewU3J0YMtEijGeA83JiOzfwloCOvClD0ojCIjhQG3KhtxXs2Y5jdYlaTA95j4qcMfsbtPYOK4jQHy87wtn9XTTMIwg3vX69EKFgnjj6Yti1pOTxrvNQzFJnNLFXD4QaDZQMK77EwMPTwAmV6a8XFuTQznkNVZerKcJnBcaEfRHTsUH2X3EYCDPCOiCGFSCr4lwmhPv7L7sM28fuNDJP53x3sNFsz13ZCsek3ZhjR5XlCg02PmiunmaWvTnCxxemcyFzWS6TjZseImBOx1Ba2c4GV7cI7czaGNGXaVn1y8RVHnWD_-euvTUK4OVT_dFhrEP5MjLNYWty5d-6S7NZyfc9UhzShbaZawzQftlwqIcCqiRg5rRwpLOSMvXvPuIiUCMkytxI3z52seW7o3Nd3zBIuGB2I7yGlxqGS1K-hs0UqZdI-4VO_4BXMlJq3NgVrUQTKEOa0a5r7NgspD-xTKCFDWNU6Ew-SKnXJwiAkDcSyFZP8ELFpJolwxbVBdnXvXi8Rpl3MV3E8JLZ-3EdnHIeH86RNneNClRfV2SNMqOi3rlnEU-jp5YSnFzKeDs6pk6PolHL3slS6VXEPPTXUo36I4qGalsj7MF-JGkQ744pkguAPVukcgKrnWAvZRijKSJHsk8m2Q9opuZgT3ri59CDWOBJt77Apu0KrYwUEaKoqFHOxVBrG1cWGNPHCZUhfgLwPeN_yLhDblAREm7WaVQxmp6epsV0kfDGgE5rC4G91jZUmVPEayRaBlvksmLZElBlCGqeMQ2dRwaTPZq7gl-Xr0ufcxVcQM1v2qBVFgf0bzU3rqy1t9yk7_YMmidGNgeOhWTiSvj26pRSGD7zYaATKzH9Sxv_zQuTPPnsNyWqEVi44zhBNGuLT7Du5LUxjCT4iA8ESzf8gAg0MfLBz-t3TL5Pxn4YJ9B9rXCWzyCWrc53VBfV5jY1Rs8qjinWeomigLE5XGYkLQk7WJbugv3iAreJ2XTpSrCv_J0HCQNle3yoT9SMbqBA566KVZy6Ly7SljmU189xp9GSVzpLbED6jnL3tM_uaEA0p1_eNetmydT1SIrk5P7CkXleOrskqDzfNOhO6eXI3_AHGm0SuX_cBTX5zse4DDeM10evLOi9gtwfU1ipUudWAFdY0j675-wHDPxAVqMjWcF6s20tSOPoDpsBZ8BFHQj967h4IR7SW10fCtpC1oFjXFz5udhyl2rfJNEDT0uzBUWnOSuaTqxWuZQ23BkuUvIX09I8zk773pP6cHOXAu-2PARGCVFeIcRSIXt_oR_wJbH3hRq5tfQsbaWHijd1x45uTHn_thOXDuSzuyfpu2Wcaj1TuTPU6g9HKXkZrSIMWE934E0FLHXdd4nhocXgw6R4jsCObkWfeNJRMSvMwGxhOQodxQeRlG6bKdti6_PeEYcAw_5m9dfJgdVqoB9-ZbsbIJpyv43onuEKJLTL6TfU7xGGSN13j-xH0n9qr25-lZuSEoglFB5QEyFuiHhh1ND2YuqswD84OKExmR-5bJV17OGinEorYI4Et7jMgWziBODyjNAT4zpmgr8yeFc0Av8rgGB56c3dJ8DvX489R3-En-FkznH7gRGPuAU7srQuq2dwjNDGX6OcjOF9hiZg-DaVzQ3-i88jDZEvMGar5AOXp7trFwF2WGofcNxx_M4DRvbQJg5e0yDsvStbhmBNNRZts0tFyCLZWyY0XZbbnJWKSv-9sD_Jfp8n4SRv5x_bCWU5s8rPwgH6tKub9fAyHC4DE5dwreY6DDu0kYI3LHZpZ115EauJGzGDCdCZcJKS9UVYRZJ4F4dozR-Sz29Tl3UnIE_wJZww9EddBy2wW7mB_C7QJdwa5S0y7qWVSv-tNXWtWg2-zzEE-pWe5H1mFNW28B-oV33Z2UW0TPIuczk6t0ifrOTJO6vBcZGsXKF2fLV39UR-jtB4cclbqIhwefqWIVHlITjEvdwSRziFN3QmEW4R0tmCMtcGn-68wA0dMZpz-XLsJsbqb4lv_nsMtk3CzOR4eg4rGYuRxukzJt-aUddR0s7yFSss3VvGby08jJSU4nwz4s9uJJ472pyUy-dDYT6b5DPfRkYHhzD2WI2ATIV7YlWlS58u_8AqR306QZ6HUsGyLWsPQcPdjdtvxK6cQLXn4J6TJ-u4eNeTdKTa3zZSUTxUer0ra81dJc9cVosUcfRafSZWzJjRKhMzkO74QjD4PhVifkeaRNGEIgHXXlU_3OVmlcP_kU_Mp3V_ChpZqRvPVdglWV-7GJBaIGYef8P_JMs1oD7JGoy1oNtzPuv9z5nQ0YNsBC_k3XJnZaBA_8KflbJz9YRLp_uravy9ewA2XxJGdy_AW_qeLh3HD-pvG_n-nXx2-GjzR55qYivKM5v5nQ2i7lmF8YX5h8n-0MxHn";
        String receivedBONDTL = mds.getUrlForChannel("BONDTLServiceInboundhttp9").toString();
        assertEquals( expectedBONDTL, receivedBONDTL );

        String expectedBONDTLDelta = expectedBONDTL+"&event.lastUpdatedTime=${START},${END}&event.lastUpdatedTime.relation=between";
        String receivedBONDTLDelta = mds.getUrlForChannel("BONDTLServiceInboundhttp9",true).toString();
        assertEquals( expectedBONDTLDelta, receivedBONDTLDelta );

        String expectedRATING = "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE";
        String receivedRATING = mds.getUrlForChannel("RATINGServiceInboundhttp9").toString();
        assertEquals( expectedRATING, receivedRATING );

        String expectedRATINGDelta = expectedRATING+"&event.lastUpdatedTime=${START},${END}&event.lastUpdatedTime.relation=between";
        String receivedRATINGDelta = mds.getUrlForChannel("RATINGServiceInboundhttp9",true).toString();
        assertEquals( expectedRATINGDelta, receivedRATINGDelta );

        String expectedBONDISSUE = "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issue&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJyNWety46gSfqGpbJ2qfQHHmUy5NplknWSr9ieClswYgQ4gx56n3-YiQBdH_pOYr5umaaBv6oi2lztBjP3oGLHA3nkL33rJxF1Lfin9D2jDlfzGjenhjps3IEZJYIFlOq9Skt05yk4yON8TA4JLeEB6INVcEvFMbK-5vWS45ZK3ffuuCYOdpBpakPaN_14ge9SAtQLuOg01aA3szY_dpE0Dkl6CclZ8VGYXNfX6F2NiUMgW9TcDXW1rHn5X1TunR9ADhcvwywBTIlniQ3LrVWIRsuRMKgFbxSAitTJbIugY-aFOceG4jfAPGUEyoiMjaVUv7UtvjSWScdl4aw1r49-fpIU_jkT-4hE1B6XtDK01GuSAekpDqMWTfCfnBTGW4CSSCJZo_o0Iu5PG6t4ZdsfuJuM_3OHSVS4Klnfrsg7qCHKVDZhZ5VHVOk9VtWgszlYZSY8DTtY1OyoNN7DV3K5rR6p14_8iHZFgYH2rIJpbNlDjS1tXjR64rI6rbC2h65pZwjtY3ykjkpvDDUvqdfV1Q1Z5uGnXmVoiyMXwGxjP0sD6K6k0-c3F-im1wBui15d15wTnG8zWKXRpq09KWNPeuubvGw7-hnvb4QM1nFfr5yWZkrccRafELRdJcHvob3gwgtjTLQ-rko1guG4KAK9asZ7aH1r1XQhwGFaRn2JYBPZTJT9PWOcDBa85JbaMwn_3yMU25hU0falfr0eNiE_jdEAXAryLEaeBjkJsb9KiPkBGthw9C-D90qWpQH2ML6CqepuDtDcYHeJv1bbFHvnw80QEOtdh9AnadqTjoCdLPSrdFpKlal2yse219ilBQDU4f07RDk8Y5YrATLk0M56Xui7MVeCygONC_xDRw0vtsoJI6Cvj8gOXEyQT_AtCqM-_4DKNweW4CPV5zdLaGcVN7zEKEE0PExqe6avmyllmadYbphuL4pzK-eKMSK-bByBiTsSltnh2eN3LXfhMrRijNjRvq3nDFHEY9QL-9-efm4xw81L_3eNaSfkDMe7E8uJo3V15JeHccX0pTJfyoXRPNE9bpkrg-wVNxOjSypHBMKQcwe7c74KLSImPjMIoIXvsZcPLgy7v-gNgqBMpT0zpZRyiB_Br6GIRdBN5n3in_o-3AgzVvCv8QFUFym6QzPq2vWyLJ-WBXX5KztGozmetaXV1LJ5B7zPk6JQeONYG_tgitJjuj7yIRwwm5oSVv-9dEurM-ZHlTyjl9jz98wDS24U9CtIMOuFvO1zRCKGGJ1TpVWDS4S9hxO-R7RLXwnvaefNGWhC8sQ_cUOcyB_y5F5YnnxH3Ny1X0J7HkTBpekywKdwTPNe4PYo-yuINNt5zF-zol8kjb1tGJs49SUOGN6HDuCLyuA2iiq10zqnc4zBgKP8A-16-WJ0XGsB30O0Y2QQnH-RXrkLJs8qSZQDmAWtUxgQ5eOswHzUP5LJV8oTHkLZUC0XsK0EDXmZAsXAG0e1iNAnwhYNgz2APihWAXyUdm4f2OHa34mffLqDeLWf4UQO-GzziMXeCM3vnrv9M9gjNzBjBugjOV1gi5qkhcm_YLyw4yku8JeaApvlEyv3FBfrATalG97hHx1kAwHbSZgwfe4ce9EnJBvMErlg8KtYWQkfL4VPolNx4VWZ7XiJm_Yec5EX-6ywZp3SRf3xelAixKb1oQr_XNfjLOYbL0GEN4AtxZdnFX9KgFiYS7s1iRHejvZsdCZiSumvlNjkODq7ezAu7G5svo4NeusnDNc5ZaLCuVI_UzI1pG-oY7JxNNiFkczGoCbqahf12B-6bJ9NXlLoqPqQNrgTOPu_YhChVXqUyCVyG85rcbJoGYzICmyuTr9ILj47ZK7RdzDzosJ_eLtpmghcvrrdT0w8ueI6MXTXeeHTN7oH1g2t0UUV9jlpOse0yilsRmwa4CNdcGxuaTKUEhl7fFrPp0MIZxoNyo0ZP0aYaVlX0qHqbDbSE58RSL6fzeiGf1yH10jkN0nc-3ml0sjtJlcYyqygtkEqxmBq6XNqFB3RbRF6SPFoNz6-AMNuxSpcAJhJzrEPdRmjNWZWzj0K3B0yqKRdzwp6b4wDiGq-ufYn3Lz72qWEG5-D_-dsTkbp0z1PMmzqCGI_xEJte4LFGSBfeJfrd5N-GWSiBo38uOP0d2gS__TDFg9sq4Q4k-oc5Hv6laz9Wo_TZy5Rya85Yr5ptlrdQa7mHmp9drBoZKcOlMMQf3U48cbQ_LdH9pu7mRMw13Hu6AnwmuuFyrEfAJko8wQmz-qZc_onX6LK7CfIolErLdph3gCDJnnB-4CfOULX8KK-QJuu7aizE4Ck2P5spqRQV_j0raQ_fJSuvrhAdyhgi-kyrkjWjhUY_eoLJqoW5t5vSXRvYFmeZKShxEddYVvEh3cg7vcJQ7DdzhDA1g_slXsyxN8vsSFmUXrtTvzLH0_wsTO8k5R0R1221wJLNtUAcLLZAijteoPRXlMn7XiZe20S5-2vka3NT_hEC_lccPtp04cMSlnjPROKD1BGh6mmGoSOPYpR2sgfwpRK8GUMuctp7LIoSiHX9CdOIQZbVGJxgWL8ZxH5zyUlo1bhwNzvPCRlGidmEOB76BzfhaEPBMp0X3_nSDCyGT1z1xhfrV2jJ61-hh5MNpe3XPGV-d4URI6tPLa_Rn7nMH-RWeNw3Pc_nvro0ePAz8yeCdYX0IbTEpmDZIki0mriEwh9Twj6BNwe7OTUhfi4QXARYghWReMMWKHtoCZdDHpkZWPwEiZUXuH5YpqARMKy8dYCHMQH9BZhgz5gGiQy6xCu1qEK7qKA92wa24xZWokoMDkoJM5cVvt26M0-k3AcbWzDlW3mVcs9EoHO_91-MilVcdzDogo4rNUXmZz2icvcL9DbmnUtEF2mpK1LHRCzFtKJgXLo7ZClfc3jf9gWLS2B8C8JOtVxi23_N9kRuERa5VmR9dI8aU4EVrr3rOaJfblb4XEcoPtVHmDKOOveT06hiJ2iB1l2lWHL-fnZ14QSPnxqoq3N9yRKqPh9GQoyZkeYJy4QhANZ1Yu8vc7LKdeWVqeYq3feXQ6k0o_l20BKsTtyNSexgzDi8wK90mZbON7LG3GfBssGXfD_Tw5yOl2KbsJgmgGtCjCvLAC32grnZKpwP7D8_G3Hl";
        String receivedBONDISSUE = mds.getUrlForChannel("BONDISSUEServiceInboundhttp9").toString();
        assertEquals( expectedBONDISSUE, receivedBONDISSUE );

        String expectedBONDISSUEDelta = expectedBONDISSUE+"&event.lastUpdatedTime=${START},${END}&event.lastUpdatedTime.relation=between";
        String receivedBONDISSUEDelta = mds.getUrlForChannel("BONDISSUEServiceInboundhttp9",true).toString();
        assertEquals( expectedBONDISSUEDelta, receivedBONDISSUEDelta );
    }

	@Test
	public void testGetSourceDeltaUrlForDataset() throws Exception
	{
		String expected = "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=EQUITY&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx1V9tu2zgQ_aHAi6IF9jnrJEWAZJ3aTt8pamSzpkiFFzfar9_Dm0TL7ksinpE45JkzFwtrPa1E-PvAHN3Fp5U9MkN24511TLVCHf6EV98YL-nLt2_3X_nfz6rN4Fk7sm9kduHDO_eyGrRxnZZCvzJzEIo1kta6jSYhpfjwot05zU8BaJq17gdthaPHT35k6kB3DbMncqtWnIXVpiyV7zfdWivrhPOknL2z5JykVev4oxQHATfpRGblG_vGjFNkntsKw8KrVq6cfJ8X0VytmcW-a4l_ad2zX9r8JGOFVgmBzb0PLWhp96KnBDbNXvATmbSy1GpZCA08MtOCDdxjJ_4rbAq76X54JoUbAxXpOmsmKbw-RQNk_svgJd_25lus116561h22r4Z3Xruvhvth4wqcTqRiCHYj0M5jbOEmHrrzBijJWbVBP9_nZj6JZanukDTvjc26QwpftwbpizjDjzu2We4cSeMdYDbpMugD5yeMyfO8HneCh7l1ON5N_YNGMXSCHuSZHExobgYWASL6_PewHm8FdCefYbdgwDBs3KZ6Ap-0e6OIEg3IkzgYzcgGpXgQeB3fc5ySNCR2RcBEdYkIxy8uu9VOC53nKhFCIZ4_YwshZXQCwFmBzxQNOvL-XlTve5KQCopV0AVc0vcG1y-gppmdw1yb0VRD9d9Px1EWFEez0xqxDmvfpNxAxsEmYWrJ236amele1QIufYmaGQsdYagIMHBQ6C6YpYLZa_e2XRdRVeFqwrOjn4y6WnTvSvhCr2iE3CTqtIpgygWRSL1azFYWxom5q-TOr53f0bIhRz33ih9nji4aVtPt47mtGGN7ODlFF0sWErva1yX5BmvLMxT6l4RU0tiRhGZLVlihh8XNggP2aZD-G59tUMxurldoGvOkwvT2_0DofJdGeEKDaFHfb9oR2gvDxTbhDbjljiJwU1fHnZzMyodakZYO8T7gqxQWSbpOvY5daaEQAL8NH1lppZW6Hz10olBUo02DZjpkTKhjU0dbGEL_xa2zrE6Cqk5oTbxUDnM-F7WF8mP9bJEAMrFIHSQVAnw5HCTKMr43PbhP5UTBDdFKmFL7cqrTYPE-PBps9jC8PDhtYvElbLqUqMLTyEf1unI6fv9ZDOpehfosfIuNUfK55FgLjjxK2zWvswnAjEpI15Z3pdr6V5VugRYwjxgylYu6e1FqKT7uHvtWNiWbemQudRD7ihQ0FGvmbuPNHmjFX26C8s_ybOyGGsS-Ueo8qhlG4QWvnJw5Mio1I-wfFbz8veR1HMIdPsk2SGeZNDlMYT0ogn2qabQIabBwnHuPdltuEJ-xCRVBRXsbzocIRsHoU4_QhxDQatchFniJ6kU8VhPnryKo1SS39DPjTeRJwOf0ziXoK0ztoZTYTrV-5d4RFMIKspWKrqT-7aXr4rQW5JwEMzPfHrMD_QkNXNISZ45CaqkSigKfYXJqhwH3sqUFJgyLZmt9oG8rU8s5GTbdEET0FEqD3EwEdu5IOVTMB9XO8we-TX35WtiYTMESyEX5TiOMPiO4pyDElSyeTkQa86vp2TUYIVjXgzVqZgwM14kkhKpioTDIEFCP4kUmBopukr1LSUVzpPnnmVFyfBF4clYmMhbMDoJbYFP513gsXAssCcD4OYmbIwHXsAo-gjhLcsDcQmnN22PnzWKpIvLPEpfXDFjSzamqZt9oO9j6s25l3Ee-la1jhNtkn3tKex6jQ6uf6HzeD9g6ORRPNkQShCXUEG1M2p7Pyw97wL44N1YG4roy8-jafY0twdMc2PCNGl6MPP4YOZseVYIBbiouimsqUiVZfpdx9Q47ceb8sugglD60dFrANq8xgac7QJFEWnmzl2d7QFjHhfy2rDFz4bFz8MxJMEZ9WQh9ggtqPofpq7cOw&event.lastUpdatedTime=${START},${END}&event.lastUpdatedTime.relation=between";
		String received = mds.getSourceDeltaUrlForDataset("EQUITY").toString();
		assertEquals( expected, received );
		//assertEquals(null, mds.getSourceDeltaUrlForDataset("BookFull"));
	}

	@Test
	@Ignore // TODO: How are we fetching the attribute names for a view?
	public void testGetAttributeNamesForDataset() throws Exception
	{
		// Dataset
		List<String> expectedList = Arrays.asList("GLcconsol", "Class", "Factive", "CPType", "RXM", "ReverseEntity");
		List<String> outputList = mds.getAttributeNamesForDataset("GLCCONSOL");
		doObjectListComparison(outputList, expectedList.toArray(),"Attributes");

		// View
		expectedList = Arrays.asList("issue.assetClass", "issue.assetType", "issue.cusip", "issue.isin", "issue.nominalCurrency", "issue.issueName", "issue.ubsId", "issuer.cconsol", "issuer.ubsPartyId", "tL.countryUbsId", "tL.sedol", "isoCode", "description", "currencyOffset", "domain");
		outputList = mds.getAttributeNamesForDataset("InstrumentSecFunding");
		Set<String> uniqueList = new HashSet<String>(outputList);

		doObjectListComparison(new ArrayList<String>(uniqueList), expectedList.toArray(),"Attributes");
	}

	@Test
	public void testGetAttributePositionsForDataset() throws Exception
	{
		// Invalid
		assertTrue(mds.getAttributePositionsForDataset("EQUITY").get("xyz") == null);

		// Valid
		assertTrue(mds.getAttributePositionsForDataset("EQUITY").get("issue.issueName") == 77);
	}

	@Test
	public void testGetPrimarySourceUrlsForDataset()
	{
		// Explicit fields
		assertTrue(mds
				.getPrimarySourceUrlForDataset("INDEXCOMPOSITION")
				.endsWith(
						"&rddh.requesttype=TEXT&fields=issue.assetClass," + "perm.source,issue.lastUpdatedTime,tL.ubsId,issue.isoCfi,indexComps.majorVersion," + "issue.isin,tL.isdaRegion,tL.isdaRelRtrsExchCode,issue.bbSecurityType,tL.exchange,"
								+ "issue.status,tL.bbUnique,issue.ubsId,indexComps.lastUpdatedTime,tL.pmSymbol," + "tL.majorVersion,tL.currency,perm.result,tL.isdaRelExchCode,tL.tradeCountry,tL.ric," + "tL.active,issue.majorVersion,issue.issueName,issue.active,tL.lastUpdatedTime,"
								+ "perm.value,tL.bbTicker,perm.type,tL.ticker,event.majorVersion,event.lastUpdatedTime," + "comp.lastUpdatedTime,comp.indexShareFactor,comp.numOfShares,comp.tLUbsId," + "comp.tLActive,comp.weighting,comp.majorVersion,comp.issueUbsId,comp.issueActive,"
								+ "comp.sedol,comp.ticker,comp.tLName,comp.issuerName,comp.issuerUbsId,comp.active," + "instrumentGroup.majorVersion,instrumentGroup.weightingOfficialInd," + "instrumentGroup.divisor,instrumentGroup.complete,instrumentGroup.compositionEffectiveDate,"
								+ "instrumentGroup.lastUpdatedTime,instrumentGroup.divisorOfficialInd," + "instrumentGroup.totalShares,instrumentGroup.numOfConstituents," + "instrumentGroup.constituentsExchange"));
	}

	@Test
	public void testGetSourceUrlsForDataset()
	{
		// Explicit fields
		assertTrue(mds
				.getSourceUrlsForDataset("INDEXCOMPOSITION")
				.get(0)
				.toString()
				.endsWith(
						"&rddh.requesttype=TEXT&fields=issue.assetClass," + "perm.source,issue.lastUpdatedTime,tL.ubsId,issue.isoCfi,indexComps.majorVersion," + "issue.isin,tL.isdaRegion,tL.isdaRelRtrsExchCode,issue.bbSecurityType,tL.exchange,"
								+ "issue.status,tL.bbUnique,issue.ubsId,indexComps.lastUpdatedTime,tL.pmSymbol," + "tL.majorVersion,tL.currency,perm.result,tL.isdaRelExchCode,tL.tradeCountry,tL.ric," + "tL.active,issue.majorVersion,issue.issueName,issue.active,tL.lastUpdatedTime,"
								+ "perm.value,tL.bbTicker,perm.type,tL.ticker,event.majorVersion,event.lastUpdatedTime," + "comp.lastUpdatedTime,comp.indexShareFactor,comp.numOfShares,comp.tLUbsId," + "comp.tLActive,comp.weighting,comp.majorVersion,comp.issueUbsId,comp.issueActive,"
								+ "comp.sedol,comp.ticker,comp.tLName,comp.issuerName,comp.issuerUbsId,comp.active," + "instrumentGroup.majorVersion,instrumentGroup.weightingOfficialInd," + "instrumentGroup.divisor,instrumentGroup.complete,instrumentGroup.compositionEffectiveDate,"
								+ "instrumentGroup.lastUpdatedTime,instrumentGroup.divisorOfficialInd," + "instrumentGroup.totalShares,instrumentGroup.numOfConstituents," + "instrumentGroup.constituentsExchange"));

		// TEst source that hits the das
		assertEquals("${DAS_URL}/v1/EQPRICINGEODVIEW.AR?priceDate=${SPECIFIC_DATE}" ,mds.getSourceUrlsForDataset("EQPRICINGEOD.TAR").get(0));
	}
	@Test
	public void testGetSourceUrlsForDataset_EncodedFields() throws Exception
	{
		String expected = "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&issue.assetType=MISC&messageLevel=issue&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJyNWety46gSfqGpbJ2qfQHHmUy5NplknWSr9ieClswYgQ4gx56n3-YiQBdH_pOYr5umaaBv6oi2lztBjP3oGLHA3nkL33rJxF1Lfin9D2jDlfzGjenhjps3IEZJYIFlOq9Skt05yk4yON8TA4JLeEB6INVcEvFMbK-5vWS45ZK3ffuuCYOdpBpakPaN_14ge9SAtQLuOg01aA3szY_dpE0Dkl6CclZ8VGYXNfX6F2NiUMgW9TcDXW1rHn5X1TunR9ADhcvwywBTIlniQ3LrVWIRsuRMKgFbxSAitTJbIugY-aFOceG4jfAPGUEyoiMjaVUv7UtvjSWScdl4aw1r49-fpIU_jkT-4hE1B6XtDK01GuSAekpDqMWTfCfnBTGW4CSSCJZo_o0Iu5PG6t4ZdsfuJuM_3OHSVS4Klnfrsg7qCHKVDZhZ5VHVOk9VtWgszlYZSY8DTtY1OyoNN7DV3K5rR6p14_8iHZFgYH2rIJpbNlDjS1tXjR64rI6rbC2h65pZwjtY3ykjkpvDDUvqdfV1Q1Z5uGnXmVoiyMXwGxjP0sD6K6k0-c3F-im1wBui15d15wTnG8zWKXRpq09KWNPeuubvGw7-hnvb4QM1nFfr5yWZkrccRafELRdJcHvob3gwgtjTLQ-rko1guG4KAK9asZ7aH1r1XQhwGFaRn2JYBPZTJT9PWOcDBa85JbaMwn_3yMU25hU0falfr0eNiE_jdEAXAryLEaeBjkJsb9KiPkBGthw9C-D90qWpQH2ML6CqepuDtDcYHeJv1bbFHvnw80QEOtdh9AnadqTjoCdLPSrdFpKlal2yse219ilBQDU4f07RDk8Y5YrATLk0M56Xui7MVeCygONC_xDRw0vtsoJI6Cvj8gOXEyQT_AtCqM-_4DKNweW4CPV5zdLaGcVN7zEKEE0PExqe6avmyllmadYbphuL4pzK-eKMSK-bByBiTsSltnh2eN3LXfhMrRijNjRvq3nDFHEY9QL-9-efm4xw81L_3eNaSfkDMe7E8uJo3V15JeHccX0pTJfyoXRPNE9bpkrg-wVNxOjSypHBMKQcwe7c74KLSImPjMIoIXvsZcPLgy7v-gNgqBMpT0zpZRyiB_Br6GIRdBN5n3in_o-3AgzVvCv8QFUFym6QzPq2vWyLJ-WBXX5KztGozmetaXV1LJ5B7zPk6JQeONYG_tgitJjuj7yIRwwm5oSVv-9dEurM-ZHlTyjl9jz98wDS24U9CtIMOuFvO1zRCKGGJ1TpVWDS4S9hxO-R7RLXwnvaefNGWhC8sQ_cUOcyB_y5F5YnnxH3Ny1X0J7HkTBpekywKdwTPNe4PYo-yuINNt5zF-zol8kjb1tGJs49SUOGN6HDuCLyuA2iiq10zqnc4zBgKP8A-16-WJ0XGsB30O0Y2QQnH-RXrkLJs8qSZQDmAWtUxgQ5eOswHzUP5LJV8oTHkLZUC0XsK0EDXmZAsXAG0e1iNAnwhYNgz2APihWAXyUdm4f2OHa34mffLqDeLWf4UQO-GzziMXeCM3vnrv9M9gjNzBjBugjOV1gi5qkhcm_YLyw4yku8JeaApvlEyv3FBfrATalG97hHx1kAwHbSZgwfe4ce9EnJBvMErlg8KtYWQkfL4VPolNx4VWZ7XiJm_Yec5EX-6ywZp3SRf3xelAixKb1oQr_XNfjLOYbL0GEN4AtxZdnFX9KgFiYS7s1iRHejvZsdCZiSumvlNjkODq7ezAu7G5svo4NeusnDNc5ZaLCuVI_UzI1pG-oY7JxNNiFkczGoCbqahf12B-6bJ9NXlLoqPqQNrgTOPu_YhChVXqUyCVyG85rcbJoGYzICmyuTr9ILj47ZK7RdzDzosJ_eLtpmghcvrrdT0w8ueI6MXTXeeHTN7oH1g2t0UUV9jlpOse0yilsRmwa4CNdcGxuaTKUEhl7fFrPp0MIZxoNyo0ZP0aYaVlX0qHqbDbSE58RSL6fzeiGf1yH10jkN0nc-3ml0sjtJlcYyqygtkEqxmBq6XNqFB3RbRF6SPFoNz6-AMNuxSpcAJhJzrEPdRmjNWZWzj0K3B0yqKRdzwp6b4wDiGq-ufYn3Lz72qWEG5-D_-dsTkbp0z1PMmzqCGI_xEJte4LFGSBfeJfrd5N-GWSiBo38uOP0d2gS__TDFg9sq4Q4k-oc5Hv6laz9Wo_TZy5Rya85Yr5ptlrdQa7mHmp9drBoZKcOlMMQf3U48cbQ_LdH9pu7mRMw13Hu6AnwmuuFyrEfAJko8wQmz-qZc_onX6LK7CfIolErLdph3gCDJnnB-4CfOULX8KK-QJuu7aizE4Ck2P5spqRQV_j0raQ_fJSuvrhAdyhgi-kyrkjWjhUY_eoLJqoW5t5vSXRvYFmeZKShxEddYVvEh3cg7vcJQ7DdzhDA1g_slXsyxN8vsSFmUXrtTvzLH0_wsTO8k5R0R1221wJLNtUAcLLZAijteoPRXlMn7XiZe20S5-2vka3NT_hEC_lccPtp04cMSlnjPROKD1BGh6mmGoSOPYpR2sgfwpRK8GUMuctp7LIoSiHX9CdOIQZbVGJxgWL8ZxH5zyUlo1bhwNzvPCRlGidmEOB76BzfhaEPBMp0X3_nSDCyGT1z1xhfrV2jJ61-hh5MNpe3XPGV-d4URI6tPLa_Rn7nMH-RWeNw3Pc_nvro0ePAz8yeCdYX0IbTEpmDZIki0mriEwh9Twj6BNwe7OTUhfi4QXARYghWReMMWKHtoCZdDHpkZWPwEiZUXuH5YpqARMKy8dYCHMQH9BZhgz5gGiQy6xCu1qEK7qKA92wa24xZWokoMDkoJM5cVvt26M0-k3AcbWzDlW3mVcs9EoHO_91-MilVcdzDogo4rNUXmZz2icvcL9DbmnUtEF2mpK1LHRCzFtKJgXLo7ZClfc3jf9gWLS2B8C8JOtVxi23_N9kRuERa5VmR9dI8aU4EVrr3rOaJfblb4XEcoPtVHmDKOOveT06hiJ2iB1l2lWHL-fnZ14QSPnxqoq3N9yRKqPh9GQoyZkeYJy4QhANZ1Yu8vc7LKdeWVqeYq3feXQ6k0o_l20BKsTtyNSexgzDi8wK90mZbON7LG3GfBssGXfD_Tw5yOl2KbsJgmgGtCjCvLAC32grnZKpwP7D8_G3Hl";
		String source = "BONDISSUE";
		List<String> receivedList = mds.getSourceUrlsForDataset(source);
		assertEquals(9, receivedList.size());
		assertEquals(expected,receivedList.get(0));
	}

	@Test
	public void testGetRolesForDataset() throws Exception
	{
		assertEquals(Arrays.asList("IDP_QUERYSERVICE_THIRD_PARTY_READER"), mds.getRolesForDataset("EQUITY"));
		assertEquals(Arrays.asList("IDP_QUERYSERVICE_THIRD_PARTY_READER"), mds.getRolesForDataset("InstrumentSecFunding"));
	}

	@Test
	public void testGetAttributeNamesForPhysicalDataset() throws Exception
	{
		List<String> expected = Arrays.asList("issue.issueDate", "issue.sharesOutstanding", "issue.sharesOutstandingDate", "issue.rule144A3c7Ind", "issue.votesPerShare", "tL.portfolioMarginableCode", "tL.illiquidStock", "tL.bbCompositeExchange", "basket.divisor", "basket.numOfConstituents",
				"settle.dtcEligible", "issuer.ubsPartnerId", "issuer.ubsId", "undl.tlUbsId", "undl.issueUbsId", "undl.assetClass", "undl.majorVersion", "undl.lastUpdatedTime", "undl.bbTicker", "undl.sedol", "issue.standardMarketSize", "issue.isOfQuality", "tL.settleCalendar", "issue.shortName",
				"settle.settleCalendar", "issue.amountOutstanding", "issue.fosProductGroup", "issue.nikkeiStockType", "issue.tseIndustryCode", "issue.issueName/kanji", "issue.shortName/kanji", "issue.nikkeiIndustryCode", "issue.frenchTransactionTax", "tL.firstTradeDate", "tL.indicativeNavRic",
				"tL.pmNavSymbol", "tL.risklessPrincipal", "tL.nikkeiInvTrustType", "tL.maxTradableQuantity", "tL.maxTradableLot", "equity.stockSplitDate", "issue.fosGovtClass", "issue.hasListing", "issue.fosCalcCode", "issue.amountOutstandingDate", "issue.fos", "issue.isStopTrade",
				"issue.lastUpdatedTime", "issue.majorVersion", "issue.active", "issue.status", "issue.isoCfi", "issue.assetClass", "issue.assetType", "issue.securityType", "issue.bbSecurityType", "issue.cusip", "issue.common", "issue.isin", "issue.valoren", "issue.wertpapier",
				"issue.securityFormType", "issue.nominalCurrency", "issue.restrictedListCode", "issue.cins", "issue.restrictedOffTime", "issue.restrictedOnTime", "issue.nominalValueOfUnit", "issue.mifidLiquidStk", "issue.ubsTradable", "issue.mifidTradeRep", "issue.stdMarketSize",
				"issue.mifidAvgDailyTurnover", "issue.mifidAvgDailyTurnoverCcy", "issue.mifidMarket", "issue.mifidStdMktSizeCurrency", "issue.mifidMostrelvMktCurrency", "issue.issueName", "issue.restrictedClass", "issue.restrictedForResearch", "issue.restrictionPriority",
				"issue.restrictedForSales", "issue.restrictedForTrading", "issue.restrictedForPADealing", "issue.restrictionComment", "issue.sharesPerDepositoryReceipt", "issue.regSInd", "issue.rule144AInd", "issue.adpClassification", "issue.taxableCode", "issue.quick", "issue.adrPerShare",
				"issue.isMultipleShare", "issue.bbPrimSecCompExchange", "issue.bbPrimSecPrimExchange", "issue.ftaClass", "issue.ubsId", "tL.countryUbsId", "tL.majorVersion", "tL.lastUpdatedTime", "tL.active", "tL.status", "tL.tickSize", "tL.tidm", "tL.exchange", "tL.currency", "tL.lotSize",
				"tL.bbUnique", "tL.sedol", "tL.quotationType", "tL.ticker", "tL.tradeCountry", "tL.bbTicker", "tL.ric", "tL.bbTickerExchange", "tL.localCode", "tL.bbSecurity", "tL.roundLotSize", "tL.ubsMarketMaker", "tL.coltMn", "tL.cubsInstrCode", "tL.tradingLineName", "tL.bbExchange",
				"tL.isdaRegion", "tL.opol", "tL.regShoCatA", "tL.euronext", "tL.regShoCatB", "tL.consolidatedThresholdInd", "tL.etbExternal", "tL.etbInternal", "tL.whenIssuedFlag", "tL.ipoFlag", "tL.lastTradeDate", "tL.marketSegment", "tL.consolidatedListingInd", "tL.opolInd", "tL.bbCurrency",
				"tL.ricOfIntInd", "tL.pinkQuotable", "tL.marketSettleVenue", "tL.mifidFungibleId", "tL.pmSymbol", "tL.isdaRelExchCode", "tL.isdaRelRtrsExchCode", "tL.mifidMktSettleVenueName", "tL.mifidubsMostLiquidVenue", "tL.dmlMnemonic", "tL.traxInd", "tL.freeFloatPercent", "tL.quoteLotSize",
				"tL.normalMarketSize", "tL.calendar", "tL.orderRoutingRule", "tL.countryOfRegistration", "tL.fiiRestrictionInd", "tL.auctionSession", "tL.t13", "tL.isOptionable", "tL.relativeIndex", "tL.adpId", "tL.marginableCode", "tL.occMarginableCode", "tL.earningsPerShare",
				"tL.bbPrimaryExchange", "tL.lniClass", "tL.takeoverMarker", "tL.takeoverDate", "tL.quick", "tL.ubsId", "equity.lastUpdatedTime", "equity.majorVersion", "equity.dividendCurrency", "equity.dividendPerShare", "equity.dividendType", "equity.dividendFrequency", "equity.dividendPayDate",
				"equity.dividendRecordDate", "equity.dividendDeclaredDate", "equity.dividendExDate", "equity.ipoDate", "settle.majorVersion", "settle.lastUpdatedTime", "settle.seaqReportingInd", "settle.crestInd", "settle.firstSettleDate", "settle.lastSettleDate", "settle.ptmLevyApplicable",
				"settle.euroclearInd", "settle.stampInd", "settle.crestStampDutyInd", "settle.calendar", "settle.date", "issuer.lastUpdatedTime", "issuer.majorVersion", "issuer.issuerName", "issuer.countryOfIncorporation", "issuer.cconsol", "issuer.bbCompany", "issuer.icbIndustry",
				"issuer.icbSector", "issuer.icbSubsector", "issuer.icbSupersector", "issuer.fidbCode", "issuer.countryOfDomicile", "issuer.countryOfRisk", "issuer.ubsPartyId", "event.majorVersion", "event.lastUpdatedTime");

		List<String> receivedList = mds.getAttributeNamesForPhysicalDataset("EQUITY");
		doObjectListComparison(receivedList, expected.toArray(), "Attributes");
	}


    protected void doObjectListComparison( List<?> receivedList, Object[] expected, String name )
    {
		assertNotNull("No " + name + " returned",receivedList);
		assertEquals("Wrong number of " + name,expected.length, receivedList.size());

		Object[] received = receivedList.toArray();

		// Sort so that they should match
		Arrays.sort(expected);
		Arrays.sort(received);

		assertArrayEquals(name + " not as expected",expected, received );

    }

    protected void doObjectListComparisonNoSort( List<?> receivedList, Object[] expected, String name )
    {
		assertNotNull("No " + name + " returned",receivedList);
		assertEquals("Wrong number of " + name,expected.length, receivedList.size());

		Object[] received = receivedList.toArray();

		assertArrayEquals(name + " not as expected",expected, received );

    }

	@Test
	public void testGetJoinRelationsForView() throws Exception
	{
		List<String> expectedList1 = Arrays.asList("DSCURRENCY.IDP","RATING.IDP");
		List<String> expectedList2 = Arrays.asList("MTS.IDP");
		List<String> expectedList3 = Arrays.asList("BONDISSUE.IDP","BONDTL.IDP","RATING.IDP");
		List<String> expectedList4 = Arrays.asList("EQUITY.IDP","RATING.IDP");


		List<JoinRelation> joinRelations = mds.getJoinRelationsForDataset("InstrumentSecFunding");
		assertEquals("No Joins returned",4,joinRelations.size());

		List<PhysicalDataset> receivedList1 = joinRelations.get(0).getOrderedDatasets();
		List<PhysicalDataset> receivedList2 = joinRelations.get(1).getOrderedDatasets();
		List<PhysicalDataset> receivedList3 = joinRelations.get(2).getOrderedDatasets();
		List<PhysicalDataset> receivedList4 = joinRelations.get(3).getOrderedDatasets();

		assertEquals(expectedList1.toString(),receivedList1.toString());
		assertEquals(expectedList2.toString(),receivedList2.toString());
		assertEquals(expectedList3.toString(),receivedList3.toString());
		assertEquals(expectedList4.toString(),receivedList4.toString());
	}

	@Test
	public void testTransformations() throws Exception
	{
		Object[] expected = Arrays.asList("com.ubs.idp.orchestrator.processor.rules.CurrencyRule").toArray();
		List<String> receivedList = mds.getTransformerRulesetsForDataset("CURRENCY");

		doObjectListComparison(receivedList, expected, "Rulesets");

		assertEquals("CURRENCY Delimiter incorrect","\t", mds.getDelimiter("CURRENCY") );
		assertEquals("CURRENCY.IDP TableId","CURRENCY", mds.getTableIdForDataset("CURRENCY.IDP"));

		expected = Arrays.asList(0,35,39,40).toArray();
		List<Integer> receivedIntList = mds.getThinToWideKeyColumnPositionsForDataset("BONDPRICING");
		doObjectListComparison(receivedIntList, expected, "Key Column positions");

		expected = Arrays.asList("Fitch","DMSI_Fitch","Moodys","DMSI_Moodys","SandP","DMSI_SandP").toArray();
		receivedList = mds.getThinToWideTargetPivotValuesForDataset("RATING");
		doObjectListComparison(receivedList, expected, "Target pivot values");

		expected = Arrays.asList("event.lastUpdatedTime","issueRating.lastUpdatedTime","issueRating.code","event.majorVersion","issueRating.validDate","issueRating.ratingGroup","issueRating.rawCode","issueRating.endorsementInd").toArray();
		receivedList = mds.getThinToWideColumnsAssociatedWithPivotForDataset("RATING");
		doObjectListComparison(receivedList, expected, "Associated pivot columns");

		expected = Arrays.asList("issue.ubsId").toArray();
		receivedList = mds.getThinToWideKeyColumnsForDataset("RATING");
		doObjectListComparison(receivedList, expected, "Key Column");

		expected = Arrays.asList("event.lastUpdatedTime","issueRating.lastUpdatedTime","issueRating.code","event.majorVersion","issueRating.validDate","issueRating.ratingGroup","issueRating.rawCode","issueRating.endorsementInd").toArray();
		assertEquals("Wrong pivot columns","issueRating.ratingAgency",mds.getThinToWidePivotColumnForDataset("RATING") );
	}

	@Test
	public void testGetTableIdForDataset() throws Exception
	{
		assertEquals("Table id incorrect","EQUITY",mds.getTableIdForDataset("EQUITY.IDP") );
		assertEquals("Table id incorrect","CURRENCY",mds.getTableIdForDataset("CURRENCY.IDP") );
		assertEquals("Table id incorrect","RATING_LATEST_RAW",mds.getTableIdForDataset("RATING") );
		assertEquals("Table id incorrect","RATING",mds.getTableIdForDataset("RATING.IDP") );
		assertEquals("Table id incorrect","BONDPRICING_RAW",mds.getTableIdForDataset("BONDPRICING") );
		assertEquals("Table id incorrect","BONDPRICING",mds.getTableIdForDataset("BONDPRICING.IDP") );
		assertEquals("Table id incorrect","BONDTL_RAW",mds.getTableIdForDataset("BONDTL") );
		assertEquals("Table id incorrect","BONDTL",mds.getTableIdForDataset("BONDTL.IDP") );
	}

	@Test
	public void testDSCurrencyTransformation() throws Exception
	{
		Object[] expected = Arrays.asList("com.ubs.idp.orchestrator.processor.rules.AssetTypeRule","com.ubs.idp.orchestrator.processor.rules.AssetClassRule","com.ubs.idp.orchestrator.processor.rules.FIAssetTypeRule","com.ubs.idp.orchestrator.processor.rules.IsCallableRule","com.ubs.idp.orchestrator.processor.rules.CouponTypeRule","com.ubs.idp.orchestrator.processor.rules.DSCurrencyRule").toArray();
		List<String> receivedList = mds.getTransformerRulesetsForDataset("DSCURRENCY");
		doObjectListComparison(receivedList, expected, "DSCurrency rules");
	}

	@Test
	public void testEquityTransformation() throws Exception
	{
		Object[] expected = Arrays.asList("com.ubs.idp.orchestrator.processor.rules.AssetTypeRule","com.ubs.idp.orchestrator.processor.rules.AssetClassRule","com.ubs.idp.orchestrator.processor.rules.FIAssetTypeRule","com.ubs.idp.orchestrator.processor.rules.IsCallableRule","com.ubs.idp.orchestrator.processor.rules.CouponTypeRule","com.ubs.idp.orchestrator.processor.rules.EQUITYRule").toArray();
		List<String> receivedList = mds.getTransformerRulesetsForDataset("EQUITY.TRANSFORMED");
		doObjectListComparison(receivedList, expected, "EQUITY rules");
	}

	@Test
	public void testAuthenticationUri() throws Exception
	{
		assertEquals("Authentication URI incorrect for RATING","${RDDH_WS_HOST}", mds.getSourceAuthenticationUriForDataset("RATING") );
		assertEquals("Authentication URI incorrect for EQUITY","${RDDH_WS_HOST}", mds.getSourceAuthenticationUriForDataset("EQUITY") );
		assertEquals("Authentication URI incorrect for BONDTL","${RDDH_WS_HOST}", mds.getSourceAuthenticationUriForDataset("BONDTL") );
	}

	@Test
	public void testBookData() throws Exception
	{
		JDBCChannel channel = mds.getDatabaseDetailsForDataset("Book.BOOKSTORE");
		assertEquals("URL is incorrect","jdbc:${bookdb.channel.url}",channel.url);
		assertEquals("Username is incorrect","${bookdb.channel.username}",channel.username);
		assertEquals("Password is incorrect","${bookdb.channel.password}",channel.password);
		assertEquals("Driver is incorrect","${bookdb.channel.driverClass}",channel.driverClass);
		assertEquals("SQL is incorrect","select BUSINESS_GROUP_ID,BUSINESS_GROUP_NAME,BUSINESS_GROUP_CODE,BUSINESS_UNIT_ID,BUSINESS_UNIT_NAME,BUSINESS_UNIT_CODE,BUSINESS_AREA_ID,BUSINESS_AREA_NAME,BUSINESS_AREA_CODE,BUSINESS_SECTOR_ID,BUSINESS_SECTOR_NAME,BUSINESS_SECTOR_CODE,BUSINESS_SEGMENT_ID,BUSINESS_SEGMENT_NAME,BUSINESS_SEGMENT_CODE,BUSINESS_FUNCTION_ID,BUSINESS_FUNCTION_NAME,BUSINESS_FUNCTION_CODE,DESK_ID,DESK_NAME,DESK_CODE,SUB_DESK_ID,SUB_DESK_NAME,SUB_DESK_CODE,COST_CENTER_ID,COST_CENTER_NAME,f.COST_CENTER_CODE,f.BOOK_ID,BOOK_NAME,BOOK_CODE,SOURCE_NAME,RISKCLASS,BOOK_KEY,BOOK_TYPE,BOOK_STATUS,BOOK_DESCRIPTION,RISK_BOOK,FINANCE_BOOK,MARKET_RISK_INDICATOR,REGULATORY_CAPITAL_INDICATOR,BOOK_MASTER_SOURCE_STATUS,BOOK_MASTER_SYSTEM,MR_SPEC_RISK_TRMT,REGCAP_SPEC_RISK_TRMNT,RISK_RELEVANT_FLAG,FINANCE_RELEVANT_FLAG,BOOK_LOCATION,LEGALENTITYCODE,FULL_REVALUATION_TREATMENT,INTERNAL_RISK_CONTROL,REGULATORY_CAPITAL,SPECIFIC_RISK_TREATMENT,STRESS_FULL_REVALUATION,STRESS_RELEVANT,FX_SELL_DOWN,DEFINED_CURRENCY,OPERATIONS_SETTLEMENT_FLAG,VRT_ACTIVITY,VR_EXEMPTION,TREASURY_RISK,BACK_TO_BACK_TYPE,B2B_LEGALENTITYCODE,SUPERVISION_RELEVANT,CONFIDENTIAL FROM V_FUNC_DESK_FLAT_HIERARCHY f INNER JOIN V_BOOK_ATTRIBUTES b on b.book_id=f.book_id",channel.querySQL);
	}

	@Test
	public void testAccountAndRXMData()
	{
		assertEquals("TableId IDP incorrect","AccountsAndRXM", mds.getTableIdForDataset("AccountsAndRXM.IDP") );
		assertEquals("Dataset MF delimiter incorrect","	", mds.getDelimiter("AccountsAndRXM.MF") );
		assertEquals("Dataset IDP delimiter incorrect","	", mds.getDelimiter("AccountsAndRXM.IDP") );

		// Test roles
		assertEquals("Wrong role","[IDP_QUERYSERVICE_COUNTERPARTY_READER]",mds.getRolesForDataset("AccountsAndRXM.IDP").toString());
		assertEquals("Wrong role","[IDP_QUERYSERVICE_COUNTERPARTY_READER]",mds.getRolesForDataset("AccountsAndRXM.IDP").toString());

		JDBCChannel channel = mds.getDatabaseDetailsForDataset("AccountsAndRXM.MF");
		assertEquals("URL is incorrect","jdbc:${creditRelationship.channel.url}",channel.url);
		assertEquals("Username is incorrect","${creditRelationship.channel.username}",channel.username);
		assertEquals("Password is incorrect","${creditRelationship.channel.password}",channel.password);
		assertEquals("Driver is incorrect","${creditRelationship.channel.driverClass}",channel.driverClass);
		assertEquals("SQL is incorrect","execute get_rxm_account",channel.querySQL);
	}

	@Test
	public void testRatingData()
	{
		assertEquals("TableId IDP incorrect","RATING", mds.getTableIdForDataset("RATING.IDP") );
		assertEquals("Dataset IDP delimiter incorrect","	", mds.getDelimiter("RATING.IDP") );
		assertEquals("Dataset RDDH delimiter incorrect","	", mds.getDelimiter("RATING") );

		// Test role
		assertEquals("Wrong role","[IDP_QUERYSERVICE_THIRD_PARTY_READER]",mds.getRolesForDataset("RATING").toString());
		assertEquals("Transformer pre-processor rules incorrect","[com.ubs.idp.orchestrator.processor.rules.rddh.rating.RatingPreProcessorFilterRule]",mds.getTransformerPreProcessorRulesetsForDataset("RATING").toString());

		assertEquals("Wrong role","[IDP_QUERYSERVICE_THIRD_PARTY_READER]",mds.getRolesForDataset("RATING.IDP").toString());

		Object[] expected = Arrays.asList("${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.assetType=MISC&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE","${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.assetType=MONEY_MARKET&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE","${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.assetType=PREFERRED&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE","${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.assetType=MUNI&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE","${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.assetType=GOVT&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE","${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.assetType=CORP&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE","${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.assetType=CONVERTIBLE&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE","${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.assetType=MORTGAGE&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE","${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE").toArray();

		List<String> receivedList = mds.getSourceUrlsForDataset("RATING");

		doObjectListComparison(receivedList, expected, "URLs");
	}

	@Test
	public void testView()
	{
		assertFalse("InstrumentSecFunding should not union all",mds.getUnionAllForView("InstrumentSecFunding"));
	}

	@Test
	public void testHQLATreasuryARDatasets()
	{
		Object[] expected = Arrays.asList("UBSID", "ISIN", "CUSIP", "VALOREN", "CINS", "COMMON", "WERTPAPIER", "SEDOL", "TL_UBSID", "AR_ISSUER_TYPE_CD", "AR_SEC_CAT_CD", "AR_ISSUE_GUARANTOR", "AR_ISSUER_DOM_CCY", "AR_ISSUER_DOM", "AR_ISSUER_NAME", "AR_NOMINAL_CCY", "GRP_RISK_WEIGHT", "GRP_NORM_RATING_LT", "GRP_NORM_RATING_ST", "GRP_SEC_CLASS", "GRP_SEC_CLASS_DECISION", "GRP_SEC_CLASS_DECISION_CD", "GRP_SEC_CLASS_RULE", "GRP_SEC_CLASS_VLD_UNT_DT", "US_RISK_WEIGHT", "US_NORM_RATING_LT", "US_NORM_RATING_ST", "US_SEC_CLASS", "US_SEC_CLASS_DECISION", "US_SEC_CLASS_DECISION_CD", "US_SEC_CLASS_RULE", "US_SEC_CLASS_VLD_UNT_DT", "EU_RISK_WEIGHT", "EU_NORM_RATING_LT", "EU_NORM_RATING_ST", "EU_SEC_CLASS", "EU_SEC_CLASS_DECISION", "EU_SEC_CLASS_DECISION_CD", "EU_SEC_CLASS_RULE", "EU_SEC_CLASS_VLD_UNT_DT", "SG_RISK_WEIGHT", "SG_NORM_RATING_LT", "SG_NORM_RATING_ST", "SG_SEC_CLASS", "SG_SEC_CLASS_DECISION", "SG_SEC_CLASS_DECISION_CD", "SG_SEC_CLASS_RULE", "SG_SEC_CLASS_VLD_UNT_DT", "CH_RISK_WEIGHT", "CH_NORM_RATING_LT", "CH_NORM_RATING_ST", "CH_SEC_CLASS", "CH_SEC_CLASS_DECISION", "CH_SEC_CLASS_DECISION_CD", "CH_SEC_CLASS_RULE", "CH_SEC_CLASS_VLD_UNT_DT", "AU_RISK_WEIGHT", "AU_NORM_RATING_LT", "AU_NORM_RATING_ST", "AU_SEC_CLASS", "AU_SEC_CLASS_DECISION", "AU_SEC_CLASS_DECISION_CD", "AU_SEC_CLASS_RULE", "AU_SEC_CLASS_VLD_UNT_DT").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("HQLAUltrabond");
		doObjectListComparisonNoSort(receivedList, expected, "HQLAUltrabond Attributes");

		receivedList = mds.getAttributeIdsForDataset("HQLABond");
		doObjectListComparisonNoSort(receivedList, expected, "HQLABond Attributes");

		receivedList = mds.getAttributeIdsForDataset("HQLAEquity");
		doObjectListComparisonNoSort(receivedList, expected, "HQLAEquity Attributes");

		receivedList = mds.getAttributeIdsForDataset("HQLAFI");
		doObjectListComparisonNoSort(receivedList, expected, "HQLAFI Attributes");
	}

	@Test
	public void testCBETreasuryARDatasets()
	{
		Object[] expected = Arrays.asList("UBSID", "ISIN", "CUSIP", "VALOREN", "CINS", "COMMON", "WERTPAPIER", "SEDOL", "TL_UBSID", "ALL_CB_ELIGIBILITY", "ALL_CB_ELIGIBILITY_DECISION", "ALL_CB_ELIGIBILITY_DECISION_CD", "ALL_CB_ELIGIBILITY_RULE", "ALL_CB_HC", "ALL_CB_HC_DECISION", "ALL_CB_HC_DECISION_CD", "ALL_CB_HC_RULE", "SNB_CB_ELIGIBILITY", "SNB_CB_ELIGIBILITY_DECISION", "SNB_CB_ELIGIBILITY_DECISION_CD", "SNB_CB_ELIGIBILITY_RULE", "SNB_CB_HC", "SNB_CB_HC_DECISION", "SNB_CB_HC_DECISION_CD", "SNB_CB_HC_RULE", "FRB_CB_ELIGIBILITY", "FRB_CB_ELIGIBILITY_DECISION", "FRB_CB_ELIGIBILITY_DECISION_CD", "FRB_CB_ELIGIBILITY_RULE", "FRB_CB_HC", "FRB_CB_HC_DECISION", "FRB_CB_HC_DECISION_CD", "FRB_CB_HC_RULE", "BOJ_CB_ELIGIBILITY", "BOJ_CB_ELIGIBILITY_DECISION", "BOJ_CB_ELIGIBILITY_DECISION_CD", "BOJ_CB_ELIGIBILITY_RULE", "BOJ_CB_HC", "BOJ_CB_HC_DECISION", "BOJ_CB_HC_DECISION_CD", "BOJ_CB_HC_RULE", "HKM_CB_ELIGIBILITY", "HKM_CB_ELIGIBILITY_DECISION", "HKM_CB_ELIGIBILITY_DECISION_CD", "HKM_CB_ELIGIBILITY_RULE", "HKM_CB_HC", "HKM_CB_HC_DECISION", "HKM_CB_HC_DECISION_CD", "HKM_CB_HC_RULE", "BOK_CB_ELIGIBILITY", "BOK_CB_ELIGIBILITY_DECISION", "BOK_CB_ELIGIBILITY_DECISION_CD", "BOK_CB_ELIGIBILITY_RULE", "BOK_CB_HC", "BOK_CB_HC_DECISION", "BOK_CB_HC_DECISION_CD", "BOK_CB_HC_RULE", "BCA_CB_ELIGIBILITY", "BCA_CB_ELIGIBILITY_DECISION", "BCA_CB_ELIGIBILITY_DECISION_CD", "BCA_CB_ELIGIBILITY_RULE", "BCA_CB_HC", "BCA_CB_HC_DECISION", "BCA_CB_HC_DECISION_CD", "BCA_CB_HC_RULE", "RBA_CB_ELIGIBILITY", "RBA_CB_ELIGIBILITY_DECISION", "RBA_CB_ELIGIBILITY_DECISION_CD", "RBA_CB_ELIGIBILITY_RULE", "RBA_CB_HC", "RBA_CB_HC_DECISION", "RBA_CB_HC_DECISION_CD", "RBA_CB_HC_RULE", "SRB_CB_ELIGIBILITY", "SRB_CB_ELIGIBILITY_DECISION", "SRB_CB_ELIGIBILITY_DECISION_CD", "SRB_CB_ELIGIBILITY_RULE", "SRB_CB_HC", "SRB_CB_HC_DECISION", "SRB_CB_HC_DECISION_CD", "SRB_CB_HC_RULE", "MAS_CB_ELIGIBILITY", "MAS_CB_ELIGIBILITY_DECISION", "MAS_CB_ELIGIBILITY_DECISION_CD", "MAS_CB_ELIGIBILITY_RULE", "MAS_CB_HC", "MAS_CB_HC_DECISION", "MAS_CB_HC_DECISION_CD", "MAS_CB_HC_RULE", "BCH_CB_ELIGIBILITY", "BCH_CB_ELIGIBILITY_DECISION", "BCH_CB_ELIGIBILITY_DECISION_CD", "BCH_CB_ELIGIBILITY_RULE", "BCH_CB_HC", "BCH_CB_HC_DECISION", "BCH_CB_HC_DECISION_CD", "BCH_CB_HC_RULE", "ECB_CB_ELIGIBILITY", "ECB_CB_ELIGIBILITY_DECISION", "ECB_CB_ELIGIBILITY_DECISION_CD", "ECB_CB_ELIGIBILITY_RULE", "ECB_CB_HC", "ECB_CB_HC_DECISION", "ECB_CB_HC_DECISION_CD", "ECB_CB_HC_RULE", "BOE_CB_ELIGIBILITY", "BOE_CB_ELIGIBILITY_DECISION", "BOE_CB_ELIGIBILITY_DECISION_CD", "BOE_CB_ELIGIBILITY_RULE", "BOE_CB_HC", "BOE_CB_HC_DECISION", "BOE_CB_HC_DECISION_CD", "BOE_CB_HC_RULE").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("CBEUltrabond");
		doObjectListComparisonNoSort(receivedList, expected, "CBEUltrabond Attributes");

		receivedList = mds.getAttributeIdsForDataset("CBEBond");
		doObjectListComparisonNoSort(receivedList, expected, "CBEBond Attributes");

		receivedList = mds.getAttributeIdsForDataset("CBEEquity");
		doObjectListComparisonNoSort(receivedList, expected, "CBEEquity Attributes");

		receivedList = mds.getAttributeIdsForDataset("CBEFI");
		doObjectListComparisonNoSort(receivedList, expected, "CBEFI Attributes");
	}

	@Test
	public void testTreasuryBondIssueDatasets()
	{
		Object[] expected = Arrays.asList("issuer.ubsPartyId","issue.ubsId","issue.issueName","issue.issueDate","issue.isin","issue.cusip","issue.valoren","issue.cins","issue.common","issue.wertpapier","issue.assetClass","issue.assetType","issue.securityType","issue.collateralType","mortgage.bbMtgeCollateralType","mortgage.countryOfCollateral","bond.stripType","issue.isoCfi","issue.ubsIsoCfi","bond.isCovered","issue.seniority","issue.nominalCurrency","bond.maturityDate","bond.callEffectiveDate","issue.amountOutstanding","issue.issueSize","party.guarantor","party.ubsGuarantorId","event.majorVersion","event.lastUpdatedTime","issue.active").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("BONDISSUE.TAR");
		doObjectListComparison(receivedList, expected, "BONDISSUE.TAR Attributes");
	}

	@Test
	public void testTreasuryBondTLDatasets()
	{
		Object[] expected = Arrays.asList("issue.ubsId","tL.ubsId","tL.tradingLineName","tL.sedol","tL.exchange","tL.currency","tL.countryOfRegistration","tL.opol","tL.opolInd","tL.lotSize","tL.lastUpdatedTime","tL.majorVersion","issue.majorVersion","event.majorVersion","event.lastUpdatedTime").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("BONDTL.TAR");
		doObjectListComparison(receivedList, expected, "BONDTL.TAR Attributes");
	}

	@Test
	public void testTreasuryEquityIssueDatasets()
	{
		Object[] expected = Arrays.asList("issue.ubsId","issue.isin","issue.cusip","issue.valoren","issue.cins","issue.common","issue.wertpapier","issue.assetClass","issue.assetType","issue.securityType","issue.securityFormType","issue.isoCfi","issue.issueName","issue.nominalCurrency","issue.nominalValueOfUnit","issue.bbPrimSecCompExchange","issue.bbPrimSecPrimExchange","issue.amountOutstanding","issue.amountOutstandingDate","issuer.cconsol","issuer.ubsPartyId","issue.majorVersion","equity.majorVersion","event.majorVersion","settle.majorVersion","issue.lastUpdatedTime","event.lastUpdatedTime","equity.lastUpdatedTime","settle.lastUpdatedTime").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("EQUITYISSUE.TAR");
		doObjectListComparison(receivedList, expected, "EQUITYISSUE.TAR Attributes");
	}

	@Test
	public void testTreasuryEquityTLDatasets()
	{
		Object[] expected = Arrays.asList("issue.ubsId","tL.ubsId","tL.sedol","tL.quotationType","tL.exchange","tL.currency","tL.tradeCountry","tL.countryOfRegistration","tL.opol","tL.opolInd","tL.ric","tL.ricOfIntInd","tL.tradingLineName","tL.bbPrimaryExchange","tL.bbCompositeExchange","tL.relativeIndex","issue.majorVersion","event.majorVersion","tL.majorVersion","issue.lastUpdatedTime","event.lastUpdatedTime","tL.lastUpdatedTime").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("EQUITYTL.TAR");
		doObjectListComparison(receivedList, expected, "EQUITYTL.TAR Attributes");
	}

	@Test
	public void testTreasuryIssuerDatasets()
	{
		Object[] expected = Arrays.asList("PARTY_ID","PARTY_NAME","PARTY_TYPE","CTRY_DOMICILE_ISO","IMED_PARENT_PARTY_ID","INDUSTRY_SECTOR","INDUSTRY_GROUP","INDUSTRY_SUBGROUP","ULT_PARENT_PARTY_ID","ULT_PARENT_PARTY_NAME","ULT_PARENT_CTRY_DOMICILE_ISO","ULTIMATE_BBG_ID","ULTIMATE_BBG_NAME","OBLIGOR_BBG_ID","OBLIGOR_PARTY_ID","OBLIGOR_PARTY_NAME").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("ISSUER.TAR");
		doObjectListComparison(receivedList, expected, "ISSUER.TAR Attributes");
	}

	@Test
	public void testTreasuryBondRatingDatasets()
	{
		Object[] expected = Arrays.asList("issueRating.ratingAgency","issueRating.ratingType","issueRating.ratingGroup","issueRating.currencyType","issueRating.code","issueRating.recordType","issue.ubsId","issueRating.endorsementInd","issueRating.lastUpdatedTime","issueRating.validDate").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("RATING.TAR");
		doObjectListComparison(receivedList, expected, "RATING.TAR Attributes");
	}

	@Test
	public void testBondPricingDatasets()
	{
		Object[] expected = Arrays.asList("INSTR_ID","PRICE_SRCE","PRICE_DATE","PRICE_TYPE","PRICE_GRP","CLEAN_PRICE","DIRTY_PRICE").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("BONDPRICING.TAR");
		doObjectListComparison(receivedList, expected, "BONDPRICING.TAR Attributes");

		assertEquals("TableId incorrect","BONDPRICING_RAW",mds.getTableIdForDataset("BONDPRICING"));
		assertEquals("TableId incorrect","BONDPRICING",mds.getTableIdForDataset("BONDPRICING.IDP"));
	}

	@Test
	public void testTreasuryLEMDatasets()
	{
		Object[] expected = Arrays.asList("PARTY_ID","STATUS","PARTY_NAME","CTRY_DOMICILE_ISO","CTRY_INCORP_ISO","PARTY_TYPE","IMED_PARENT_PARTY_ID","IMED_PARENT_PARTY_NAME","IMED_PARENT_CTRY_DOMICILE_ISO","IMED_PARENT_CTRY_INCORP_ISO","ULT_PARENT_PARTY_ID","ULT_PARENT_PARTY_NAME","ULT_PARENT_CTRY_DOMICILE_ISO","ULT_PARENT_CTRY_INCORP_ISO","INDUSTRY_SECTOR","INDUSTRY_GROUP","INDUSTRY_SUBGROUP","IMMEDIATE_BBG_ID","IMMEDIATE_BBG_NAME","ULTIMATE_BBG_ID","ULTIMATE_BBG_NAME", "OBLIGOR_BBG_ID", "OBLIGOR_PARTY_ID", "OBLIGOR_PARTY_NAME").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("LEGALENTITY.LEM");
		doObjectListComparison(receivedList, expected, "LEGALENTITY.LEM Attributes");

		assertNotNull("Delta query not specified for LEM", mds.getSQLDeltaQueryForDataset("LEGALENTITY.LEM") );
	}

	@Test
	public void testIndexCompDatasets()
	{
		Object[] expected = Arrays.asList("comp.tLUbsId","index.issue.ubsId","index.tL.ubsId","comp.issuerUbsId","index.issue.isoCfi","indexComps.majorVersion","index.issue.isin","index.tL.isdaRegion","index.tL.exchange","index.issue.status","indexComps.lastUpdatedTime","index.tL.majorVersion","index.tL.currency","index.tL.tradeCountry","index.tL.ric","index.tL.active","index.issue.majorVersion","index.issue.issueName","index.issue.active","index.tL.lastUpdatedTime","index.tL.ticker","event.majorVersion","event.lastUpdatedTime","comp.lastUpdatedTime","comp.tLActive","comp.majorVersion","comp.issueActive","comp.sedol","comp.ticker","comp.tLName","comp.issuerName","comp.active").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("INDEXCOMPOSITION.TAR");
		doObjectListComparison(receivedList, expected, "INDEXCOMPOSITION.TAR Attributes");
	}

	@Test
	public void testSecFunding()
	{
		Object[] expected = Arrays.asList("issue.assetClass","issue.assetClass","issue.assetClass","issue.assetType","issue.assetType","issue.assetType","issue.cusip","issue.cusip","issue.cusip","issue.cusip","issue.isin","issue.isin","issue.isin","issue.isin","issue.nominalCurrency","issue.nominalCurrency","issue.nominalCurrency","issue.nominalCurrency","issue.issueName","issue.issueName","issue.issueName","issue.issueName","issue.ubsId","issue.ubsId","issue.ubsId","issue.ubsId","issue.ubsId","issuer.cconsol","issuer.cconsol","issuer.cconsol","issuer.ubsPartyId","issuer.ubsPartyId","issuer.ubsPartyId","tL.countryUbsId","tL.countryUbsId","tL.countryUbsId","tL.countryUbsId","tL.sedol","tL.sedol","isoCode","description","currencyOffset","domain","issue.bbTicker","tL.bbTicker","issue.bbTicker","issuer.countryOfIncorporation","issuer.countryOfIncorporation","issuer.countryOfIncorporation","issue.ubsIsoCfi","issue.ubsIsoCfi","coupon.couponType","coupon.couponType","issue.issueDate","issue.issueDate","issue.issueDate","issue.issueDate","issue.nominalValueOfUnit","issue.nominalValueOfUnit","issue.nominalValueOfUnit","issue.issueSize","issue.issueSize","issue.issueSize","issuer.countryOfDomicile","issuer.countryOfDomicile","issuer.countryOfDomicile","issue.ubsUniqueDescription","issue.ubsUniqueDescription","issue.bondIssuerType","issue.bondIssuerType","issue.series","issue.series","bond.maturityDate","bond.maturityDate","bond.minimumTradeSize","bond.minimumTradeSize","issuer.countryOfRisk","issuer.countryOfRisk","issuer.countryOfRisk","tL.ticker","tL.ticker","issue.collateralType","issue.collateralType","bond.stripType","bond.stripType","bond.callOptionType","bond.callOptionType","coupon.currentCouponRate","coupon.currentCouponRate","coupon.currentCouponRate","issue.isin","derived.cusip","derived.sedol","derived.bondIssuerType","derived.issueFactor","derived.valueFactor","issue.issueSize","derived.minDenomination","derived.currentCouponRate","derived.assetClass","derived.assetClass","derived.PrimaryListing","derived.PrimaryListing","derived.assetType","derived.couponType","derived.FIAssetType","derived.Fitch_event.lastUpdatedTime","derived.Moodys_event.lastUpdatedTime","derived.SandP_event.lastUpdatedTime","derived.Fitch_issueRating.lastUpdatedTime","derived.Moodys_issueRating.lastUpdatedTime","derived.SandP_issueRating.lastUpdatedTime","issueRating.isProvisional","derived.Fitch_issueRating.code","derived.Fitch_issueRating.code","derived.Moodys_issueRating.code","derived.Moodys_issueRating.code","derived.SandP_issueRating.code","derived.SandP_issueRating.code","derived.Fitch_issueRating.rawCode","derived.Moodys_issueRating.rawCode","derived.SandP_issueRating.rawCode","issueRating.structuredFinanceInd","derived.DMSI_SandP_issueRating.endorsementInd","issueRating.recordType","derived.Fitch_issueRating.validDate","derived.Moodys_issueRating.validDate","derived.SandP_issueRating.validDate","derived.Fitch_issueRating.ratingGroup","derived.Moodys_issueRating.ratingGroup","derived.SandP_issueRating.ratingGroup","issueRating.ratingType","issueRating.currencyType","derived.Fitch_event.majorVersion","derived.Moodys_event.majorVersion","derived.SandP_event.majorVersion","derived.issue.majorVersion","derived.issue.active","derived.issue.isoCfi","derived.issue.assetClass","derived.issue.assetType","derived.issue.nominalCurrency","derived.issue.ubsTradable","derived.issue.ubsIsoCfi","derived.issue.ubsId","derived.isCallable","derived.SecFunding.issuerName","derived.SecFunding.issuerName","derived.SecFunding.issuerName","derived.SecFunding.issuerName","derived.SecFunding.issuerName","derived.SandP_issueRating.endorsementInd","derived.DMSI_Moodys_issueRating.endorsementInd","derived.Moodys_issueRating.endorsementInd","derived.DMSI_Fitch_issueRating.endorsementInd","derived.Fitch_issueRating.endorsementInd", "HQLA_UBSID", "HQLA_UBSID", "HQLA_UBSID", "HQLA_ISIN", "HQLA_ISIN", "HQLA_ISIN", "HQLA_CUSIP", "HQLA_CUSIP", "HQLA_CUSIP", "HQLA_VALOREN", "HQLA_VALOREN", "HQLA_VALOREN", "HQLA_CINS", "HQLA_CINS", "HQLA_CINS", "HQLA_COMMON", "HQLA_COMMON", "HQLA_COMMON", "HQLA_WERTPAPIER", "HQLA_WERTPAPIER", "HQLA_WERTPAPIER", "HQLA_SEDOL", "HQLA_SEDOL", "HQLA_SEDOL", "HQLA_TL_UBSID", "HQLA_TL_UBSID", "HQLA_TL_UBSID", "AR_ISSUER_TYPE_CD", "AR_ISSUER_TYPE_CD", "AR_ISSUER_TYPE_CD", "AR_SEC_CAT_CD", "AR_SEC_CAT_CD", "AR_SEC_CAT_CD", "AR_ISSUE_GUARANTOR", "AR_ISSUE_GUARANTOR", "AR_ISSUE_GUARANTOR", "AR_ISSUER_DOM_CCY", "AR_ISSUER_DOM_CCY", "AR_ISSUER_DOM_CCY", "AR_ISSUER_DOM", "AR_ISSUER_DOM", "AR_ISSUER_DOM", "AR_ISSUER_NAME", "AR_ISSUER_NAME", "AR_ISSUER_NAME", "AR_NOMINAL_CCY", "AR_NOMINAL_CCY", "AR_NOMINAL_CCY", "GRP_RISK_WEIGHT", "GRP_RISK_WEIGHT", "GRP_RISK_WEIGHT", "GRP_NORM_RATING_LT", "GRP_NORM_RATING_LT", "GRP_NORM_RATING_LT", "GRP_NORM_RATING_ST", "GRP_NORM_RATING_ST", "GRP_NORM_RATING_ST", "GRP_SEC_CLASS", "GRP_SEC_CLASS", "GRP_SEC_CLASS", "GRP_SEC_CLASS_DECISION", "GRP_SEC_CLASS_DECISION", "GRP_SEC_CLASS_DECISION", "GRP_SEC_CLASS_DECISION_CD", "GRP_SEC_CLASS_DECISION_CD", "GRP_SEC_CLASS_DECISION_CD", "GRP_SEC_CLASS_RULE", "GRP_SEC_CLASS_RULE", "GRP_SEC_CLASS_RULE", "GRP_SEC_CLASS_VLD_UNT_DT", "GRP_SEC_CLASS_VLD_UNT_DT", "GRP_SEC_CLASS_VLD_UNT_DT", "US_RISK_WEIGHT", "US_RISK_WEIGHT", "US_RISK_WEIGHT", "US_NORM_RATING_LT", "US_NORM_RATING_LT", "US_NORM_RATING_LT", "US_NORM_RATING_ST", "US_NORM_RATING_ST", "US_NORM_RATING_ST", "US_SEC_CLASS", "US_SEC_CLASS", "US_SEC_CLASS", "US_SEC_CLASS_DECISION", "US_SEC_CLASS_DECISION", "US_SEC_CLASS_DECISION", "US_SEC_CLASS_DECISION_CD", "US_SEC_CLASS_DECISION_CD", "US_SEC_CLASS_DECISION_CD", "US_SEC_CLASS_RULE", "US_SEC_CLASS_RULE", "US_SEC_CLASS_RULE", "US_SEC_CLASS_VLD_UNT_DT", "US_SEC_CLASS_VLD_UNT_DT", "US_SEC_CLASS_VLD_UNT_DT", "EU_RISK_WEIGHT", "EU_RISK_WEIGHT", "EU_RISK_WEIGHT", "EU_NORM_RATING_LT", "EU_NORM_RATING_LT", "EU_NORM_RATING_LT", "EU_NORM_RATING_ST", "EU_NORM_RATING_ST", "EU_NORM_RATING_ST", "EU_SEC_CLASS", "EU_SEC_CLASS", "EU_SEC_CLASS", "EU_SEC_CLASS_DECISION", "EU_SEC_CLASS_DECISION", "EU_SEC_CLASS_DECISION", "EU_SEC_CLASS_DECISION_CD", "EU_SEC_CLASS_DECISION_CD", "EU_SEC_CLASS_DECISION_CD", "EU_SEC_CLASS_RULE", "EU_SEC_CLASS_RULE", "EU_SEC_CLASS_RULE", "EU_SEC_CLASS_VLD_UNT_DT", "EU_SEC_CLASS_VLD_UNT_DT", "EU_SEC_CLASS_VLD_UNT_DT", "SG_RISK_WEIGHT", "SG_RISK_WEIGHT", "SG_RISK_WEIGHT", "SG_NORM_RATING_LT", "SG_NORM_RATING_LT", "SG_NORM_RATING_LT", "SG_NORM_RATING_ST", "SG_NORM_RATING_ST", "SG_NORM_RATING_ST", "SG_SEC_CLASS", "SG_SEC_CLASS", "SG_SEC_CLASS", "SG_SEC_CLASS_DECISION", "SG_SEC_CLASS_DECISION", "SG_SEC_CLASS_DECISION", "SG_SEC_CLASS_DECISION_CD", "SG_SEC_CLASS_DECISION_CD", "SG_SEC_CLASS_DECISION_CD", "SG_SEC_CLASS_RULE", "SG_SEC_CLASS_RULE", "SG_SEC_CLASS_RULE", "SG_SEC_CLASS_VLD_UNT_DT", "SG_SEC_CLASS_VLD_UNT_DT", "SG_SEC_CLASS_VLD_UNT_DT", "CH_RISK_WEIGHT", "CH_RISK_WEIGHT", "CH_RISK_WEIGHT", "CH_NORM_RATING_LT", "CH_NORM_RATING_LT", "CH_NORM_RATING_LT", "CH_NORM_RATING_ST", "CH_NORM_RATING_ST", "CH_NORM_RATING_ST", "CH_SEC_CLASS", "CH_SEC_CLASS", "CH_SEC_CLASS", "CH_SEC_CLASS_DECISION", "CH_SEC_CLASS_DECISION", "CH_SEC_CLASS_DECISION", "CH_SEC_CLASS_DECISION_CD", "CH_SEC_CLASS_DECISION_CD", "CH_SEC_CLASS_DECISION_CD", "CH_SEC_CLASS_RULE", "CH_SEC_CLASS_RULE", "CH_SEC_CLASS_RULE", "CH_SEC_CLASS_VLD_UNT_DT", "CH_SEC_CLASS_VLD_UNT_DT", "CH_SEC_CLASS_VLD_UNT_DT", "AU_RISK_WEIGHT", "AU_RISK_WEIGHT", "AU_RISK_WEIGHT", "AU_NORM_RATING_LT", "AU_NORM_RATING_LT", "AU_NORM_RATING_LT", "AU_NORM_RATING_ST", "AU_NORM_RATING_ST", "AU_NORM_RATING_ST", "AU_SEC_CLASS", "AU_SEC_CLASS", "AU_SEC_CLASS", "AU_SEC_CLASS_DECISION", "AU_SEC_CLASS_DECISION", "AU_SEC_CLASS_DECISION", "AU_SEC_CLASS_DECISION_CD", "AU_SEC_CLASS_DECISION_CD", "AU_SEC_CLASS_DECISION_CD", "AU_SEC_CLASS_RULE", "AU_SEC_CLASS_RULE", "AU_SEC_CLASS_RULE", "AU_SEC_CLASS_VLD_UNT_DT", "AU_SEC_CLASS_VLD_UNT_DT", "AU_SEC_CLASS_VLD_UNT_DT", "UBSID", "UBSID", "UBSID", "ISIN", "ISIN", "ISIN", "CUSIP", "CUSIP", "CUSIP", "VALOREN", "VALOREN", "VALOREN", "CINS", "CINS", "CINS", "COMMON", "COMMON", "COMMON", "WERTPAPIER", "WERTPAPIER", "WERTPAPIER", "SEDOL", "SEDOL", "SEDOL", "TL_UBSID", "TL_UBSID", "TL_UBSID", "ALL_CB_ELIGIBILITY", "ALL_CB_ELIGIBILITY", "ALL_CB_ELIGIBILITY", "ALL_CB_ELIGIBILITY_DECISION", "ALL_CB_ELIGIBILITY_DECISION", "ALL_CB_ELIGIBILITY_DECISION", "ALL_CB_ELIGIBILITY_DECISION_CD", "ALL_CB_ELIGIBILITY_DECISION_CD", "ALL_CB_ELIGIBILITY_DECISION_CD", "ALL_CB_ELIGIBILITY_RULE", "ALL_CB_ELIGIBILITY_RULE", "ALL_CB_ELIGIBILITY_RULE", "ALL_CB_HC", "ALL_CB_HC", "ALL_CB_HC", "ALL_CB_HC_DECISION", "ALL_CB_HC_DECISION", "ALL_CB_HC_DECISION", "ALL_CB_HC_DECISION_CD", "ALL_CB_HC_DECISION_CD", "ALL_CB_HC_DECISION_CD", "ALL_CB_HC_RULE", "ALL_CB_HC_RULE", "ALL_CB_HC_RULE", "SNB_CB_ELIGIBILITY", "SNB_CB_ELIGIBILITY", "SNB_CB_ELIGIBILITY", "SNB_CB_ELIGIBILITY_DECISION", "SNB_CB_ELIGIBILITY_DECISION", "SNB_CB_ELIGIBILITY_DECISION", "SNB_CB_ELIGIBILITY_DECISION_CD", "SNB_CB_ELIGIBILITY_DECISION_CD", "SNB_CB_ELIGIBILITY_DECISION_CD", "SNB_CB_ELIGIBILITY_RULE", "SNB_CB_ELIGIBILITY_RULE", "SNB_CB_ELIGIBILITY_RULE", "SNB_CB_HC", "SNB_CB_HC", "SNB_CB_HC", "SNB_CB_HC_DECISION", "SNB_CB_HC_DECISION", "SNB_CB_HC_DECISION", "SNB_CB_HC_DECISION_CD", "SNB_CB_HC_DECISION_CD", "SNB_CB_HC_DECISION_CD", "SNB_CB_HC_RULE", "SNB_CB_HC_RULE", "SNB_CB_HC_RULE", "FRB_CB_ELIGIBILITY", "FRB_CB_ELIGIBILITY", "FRB_CB_ELIGIBILITY", "FRB_CB_ELIGIBILITY_DECISION", "FRB_CB_ELIGIBILITY_DECISION", "FRB_CB_ELIGIBILITY_DECISION", "FRB_CB_ELIGIBILITY_DECISION_CD", "FRB_CB_ELIGIBILITY_DECISION_CD", "FRB_CB_ELIGIBILITY_DECISION_CD", "FRB_CB_ELIGIBILITY_RULE", "FRB_CB_ELIGIBILITY_RULE", "FRB_CB_ELIGIBILITY_RULE", "FRB_CB_HC", "FRB_CB_HC", "FRB_CB_HC", "FRB_CB_HC_DECISION", "FRB_CB_HC_DECISION", "FRB_CB_HC_DECISION", "FRB_CB_HC_DECISION_CD", "FRB_CB_HC_DECISION_CD", "FRB_CB_HC_DECISION_CD", "FRB_CB_HC_RULE", "FRB_CB_HC_RULE", "FRB_CB_HC_RULE", "BOJ_CB_ELIGIBILITY", "BOJ_CB_ELIGIBILITY", "BOJ_CB_ELIGIBILITY", "BOJ_CB_ELIGIBILITY_DECISION", "BOJ_CB_ELIGIBILITY_DECISION", "BOJ_CB_ELIGIBILITY_DECISION", "BOJ_CB_ELIGIBILITY_DECISION_CD", "BOJ_CB_ELIGIBILITY_DECISION_CD", "BOJ_CB_ELIGIBILITY_DECISION_CD", "BOJ_CB_ELIGIBILITY_RULE", "BOJ_CB_ELIGIBILITY_RULE", "BOJ_CB_ELIGIBILITY_RULE", "BOJ_CB_HC", "BOJ_CB_HC", "BOJ_CB_HC", "BOJ_CB_HC_DECISION", "BOJ_CB_HC_DECISION", "BOJ_CB_HC_DECISION", "BOJ_CB_HC_DECISION_CD", "BOJ_CB_HC_DECISION_CD", "BOJ_CB_HC_DECISION_CD", "BOJ_CB_HC_RULE", "BOJ_CB_HC_RULE", "BOJ_CB_HC_RULE", "HKM_CB_ELIGIBILITY", "HKM_CB_ELIGIBILITY", "HKM_CB_ELIGIBILITY", "HKM_CB_ELIGIBILITY_DECISION", "HKM_CB_ELIGIBILITY_DECISION", "HKM_CB_ELIGIBILITY_DECISION", "HKM_CB_ELIGIBILITY_DECISION_CD", "HKM_CB_ELIGIBILITY_DECISION_CD", "HKM_CB_ELIGIBILITY_DECISION_CD", "HKM_CB_ELIGIBILITY_RULE", "HKM_CB_ELIGIBILITY_RULE", "HKM_CB_ELIGIBILITY_RULE", "HKM_CB_HC", "HKM_CB_HC", "HKM_CB_HC", "HKM_CB_HC_DECISION", "HKM_CB_HC_DECISION", "HKM_CB_HC_DECISION", "HKM_CB_HC_DECISION_CD", "HKM_CB_HC_DECISION_CD", "HKM_CB_HC_DECISION_CD", "HKM_CB_HC_RULE", "HKM_CB_HC_RULE", "HKM_CB_HC_RULE", "BOK_CB_ELIGIBILITY", "BOK_CB_ELIGIBILITY", "BOK_CB_ELIGIBILITY", "BOK_CB_ELIGIBILITY_DECISION", "BOK_CB_ELIGIBILITY_DECISION", "BOK_CB_ELIGIBILITY_DECISION", "BOK_CB_ELIGIBILITY_DECISION_CD", "BOK_CB_ELIGIBILITY_DECISION_CD", "BOK_CB_ELIGIBILITY_DECISION_CD", "BOK_CB_ELIGIBILITY_RULE", "BOK_CB_ELIGIBILITY_RULE", "BOK_CB_ELIGIBILITY_RULE", "BOK_CB_HC", "BOK_CB_HC", "BOK_CB_HC", "BOK_CB_HC_DECISION", "BOK_CB_HC_DECISION", "BOK_CB_HC_DECISION", "BOK_CB_HC_DECISION_CD", "BOK_CB_HC_DECISION_CD", "BOK_CB_HC_DECISION_CD", "BOK_CB_HC_RULE", "BOK_CB_HC_RULE", "BOK_CB_HC_RULE", "BCA_CB_ELIGIBILITY", "BCA_CB_ELIGIBILITY", "BCA_CB_ELIGIBILITY", "BCA_CB_ELIGIBILITY_DECISION", "BCA_CB_ELIGIBILITY_DECISION", "BCA_CB_ELIGIBILITY_DECISION", "BCA_CB_ELIGIBILITY_DECISION_CD", "BCA_CB_ELIGIBILITY_DECISION_CD", "BCA_CB_ELIGIBILITY_DECISION_CD", "BCA_CB_ELIGIBILITY_RULE", "BCA_CB_ELIGIBILITY_RULE", "BCA_CB_ELIGIBILITY_RULE", "BCA_CB_HC", "BCA_CB_HC", "BCA_CB_HC", "BCA_CB_HC_DECISION", "BCA_CB_HC_DECISION", "BCA_CB_HC_DECISION", "BCA_CB_HC_DECISION_CD", "BCA_CB_HC_DECISION_CD", "BCA_CB_HC_DECISION_CD", "BCA_CB_HC_RULE", "BCA_CB_HC_RULE", "BCA_CB_HC_RULE", "RBA_CB_ELIGIBILITY", "RBA_CB_ELIGIBILITY", "RBA_CB_ELIGIBILITY", "RBA_CB_ELIGIBILITY_DECISION", "RBA_CB_ELIGIBILITY_DECISION", "RBA_CB_ELIGIBILITY_DECISION", "RBA_CB_ELIGIBILITY_DECISION_CD", "RBA_CB_ELIGIBILITY_DECISION_CD", "RBA_CB_ELIGIBILITY_DECISION_CD", "RBA_CB_ELIGIBILITY_RULE", "RBA_CB_ELIGIBILITY_RULE", "RBA_CB_ELIGIBILITY_RULE", "RBA_CB_HC", "RBA_CB_HC", "RBA_CB_HC", "RBA_CB_HC_DECISION", "RBA_CB_HC_DECISION", "RBA_CB_HC_DECISION", "RBA_CB_HC_DECISION_CD", "RBA_CB_HC_DECISION_CD", "RBA_CB_HC_DECISION_CD", "RBA_CB_HC_RULE", "RBA_CB_HC_RULE", "RBA_CB_HC_RULE", "SRB_CB_ELIGIBILITY", "SRB_CB_ELIGIBILITY", "SRB_CB_ELIGIBILITY", "SRB_CB_ELIGIBILITY_DECISION", "SRB_CB_ELIGIBILITY_DECISION", "SRB_CB_ELIGIBILITY_DECISION", "SRB_CB_ELIGIBILITY_DECISION_CD", "SRB_CB_ELIGIBILITY_DECISION_CD", "SRB_CB_ELIGIBILITY_DECISION_CD", "SRB_CB_ELIGIBILITY_RULE", "SRB_CB_ELIGIBILITY_RULE", "SRB_CB_ELIGIBILITY_RULE", "SRB_CB_HC", "SRB_CB_HC", "SRB_CB_HC", "SRB_CB_HC_DECISION", "SRB_CB_HC_DECISION", "SRB_CB_HC_DECISION", "SRB_CB_HC_DECISION_CD", "SRB_CB_HC_DECISION_CD", "SRB_CB_HC_DECISION_CD", "SRB_CB_HC_RULE", "SRB_CB_HC_RULE", "SRB_CB_HC_RULE", "MAS_CB_ELIGIBILITY", "MAS_CB_ELIGIBILITY", "MAS_CB_ELIGIBILITY", "MAS_CB_ELIGIBILITY_DECISION", "MAS_CB_ELIGIBILITY_DECISION", "MAS_CB_ELIGIBILITY_DECISION", "MAS_CB_ELIGIBILITY_DECISION_CD", "MAS_CB_ELIGIBILITY_DECISION_CD", "MAS_CB_ELIGIBILITY_DECISION_CD", "MAS_CB_ELIGIBILITY_RULE", "MAS_CB_ELIGIBILITY_RULE", "MAS_CB_ELIGIBILITY_RULE", "MAS_CB_HC", "MAS_CB_HC", "MAS_CB_HC", "MAS_CB_HC_DECISION", "MAS_CB_HC_DECISION", "MAS_CB_HC_DECISION", "MAS_CB_HC_DECISION_CD", "MAS_CB_HC_DECISION_CD", "MAS_CB_HC_DECISION_CD", "MAS_CB_HC_RULE", "MAS_CB_HC_RULE", "MAS_CB_HC_RULE", "BCH_CB_ELIGIBILITY", "BCH_CB_ELIGIBILITY", "BCH_CB_ELIGIBILITY", "BCH_CB_ELIGIBILITY_DECISION", "BCH_CB_ELIGIBILITY_DECISION", "BCH_CB_ELIGIBILITY_DECISION", "BCH_CB_ELIGIBILITY_DECISION_CD", "BCH_CB_ELIGIBILITY_DECISION_CD", "BCH_CB_ELIGIBILITY_DECISION_CD", "BCH_CB_ELIGIBILITY_RULE", "BCH_CB_ELIGIBILITY_RULE", "BCH_CB_ELIGIBILITY_RULE", "BCH_CB_HC", "BCH_CB_HC", "BCH_CB_HC", "BCH_CB_HC_DECISION", "BCH_CB_HC_DECISION", "BCH_CB_HC_DECISION", "BCH_CB_HC_DECISION_CD", "BCH_CB_HC_DECISION_CD", "BCH_CB_HC_DECISION_CD", "BCH_CB_HC_RULE", "BCH_CB_HC_RULE", "BCH_CB_HC_RULE", "ECB_CB_ELIGIBILITY", "ECB_CB_ELIGIBILITY", "ECB_CB_ELIGIBILITY", "ECB_CB_ELIGIBILITY_DECISION", "ECB_CB_ELIGIBILITY_DECISION", "ECB_CB_ELIGIBILITY_DECISION", "ECB_CB_ELIGIBILITY_DECISION_CD", "ECB_CB_ELIGIBILITY_DECISION_CD", "ECB_CB_ELIGIBILITY_DECISION_CD", "ECB_CB_ELIGIBILITY_RULE", "ECB_CB_ELIGIBILITY_RULE", "ECB_CB_ELIGIBILITY_RULE", "ECB_CB_HC", "ECB_CB_HC", "ECB_CB_HC", "ECB_CB_HC_DECISION", "ECB_CB_HC_DECISION", "ECB_CB_HC_DECISION", "ECB_CB_HC_DECISION_CD", "ECB_CB_HC_DECISION_CD", "ECB_CB_HC_DECISION_CD", "ECB_CB_HC_RULE", "ECB_CB_HC_RULE", "ECB_CB_HC_RULE", "BOE_CB_ELIGIBILITY", "BOE_CB_ELIGIBILITY", "BOE_CB_ELIGIBILITY", "BOE_CB_ELIGIBILITY_DECISION", "BOE_CB_ELIGIBILITY_DECISION", "BOE_CB_ELIGIBILITY_DECISION", "BOE_CB_ELIGIBILITY_DECISION_CD", "BOE_CB_ELIGIBILITY_DECISION_CD", "BOE_CB_ELIGIBILITY_DECISION_CD", "BOE_CB_ELIGIBILITY_RULE", "BOE_CB_ELIGIBILITY_RULE", "BOE_CB_ELIGIBILITY_RULE", "BOE_CB_HC", "BOE_CB_HC", "BOE_CB_HC", "BOE_CB_HC_DECISION", "BOE_CB_HC_DECISION", "BOE_CB_HC_DECISION", "BOE_CB_HC_DECISION_CD", "BOE_CB_HC_DECISION_CD", "BOE_CB_HC_DECISION_CD", "BOE_CB_HC_RULE", "BOE_CB_HC_RULE", "BOE_CB_HC_RULE").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("SecFunding");
		doObjectListComparisonNoSort(receivedList, expected, "SecFunding View Attributes");

		List<JoinRelation> joinRelations = mds.getJoinRelationsForDataset("SecFunding");
		assertTrue( joinRelations.size() > 0 );
	}

	@Test
	public void testTreasuryEQPricingEODView()
	{
		Object[] expected = Arrays.asList("eod.tlUbsId","eod.exchange","eod.assetClass","eod.tradeIndicator","eod.quoteIndicator","ask.price","ask.currency","bid.price","bid.currency","close.price","close.currency","volume.value","open.price","open.currency","marketCapitalization.price","marketCapitalization.currency","priceSource","issue.ubsId","issue.assetType","priceDate").toArray();
		List<String> receivedList = mds.getAttributeIdsForDataset("EQPRICINGEODVIEW.AR");
		doObjectListComparison(receivedList, expected, "EQPRICINGEODVIEW.AR Attributes");
	}

	@Test
	@Ignore // Until we're ready to move to 1.2.X version of metadata-client
	public void testTreasuryTransformations()
	{
		/*
		Object[] expected = Arrays.asList("com.ubs.idp.orchestrator.processor.rules.treasuryar.IssueActiveRecordFilterRule").toArray();
		List<String> receivedList = mds.getTransformerRulesetsForDatasets("EQUITY.IDP","EQUITYISSUE.TAR");
		doObjectListComparison(receivedList, expected, "EQUITY ISSUE Ruleset Attributes");

		expected = Arrays.asList("com.ubs.idp.orchestrator.processor.rules.treasuryar.TradingLineActiveRecordFilterRule").toArray();
		receivedList = mds.getTransformerRulesetsForDatasets("EQUITY.IDP","EQUITYTL.TAR");
		doObjectListComparison(receivedList, expected, "EQUITY TL Ruleset Attributes");

		expected = Arrays.asList("com.ubs.idp.orchestrator.processor.rules.treasuryar.IssueActiveRecordFilterRule").toArray();
		receivedList = mds.getTransformerRulesetsForDatasets("BONDISSUE.IDP","BONDISSUE.TAR");
		doObjectListComparison(receivedList, expected, "BONDISSUE Ruleset Attributes");

		expected = Arrays.asList("com.ubs.idp.orchestrator.processor.rules.treasuryar.TradingLineActiveRecordFilterRule").toArray();
		receivedList = mds.getTransformerRulesetsForDatasets("BONDTL","BONDTL.TAR");
		doObjectListComparison(receivedList, expected, "BONDTL Ruleset Attributes");

		expected = Arrays.asList("com.ubs.idp.orchestrator.processor.rules.treasuryar.IssueActiveRecordFilterRule").toArray();
		receivedList = mds.getTransformerRulesetsForDatasets("RATING","RATING.TAR");
		doObjectListComparison(receivedList, expected, "RATING Ruleset Attributes");
		*/
	}
}
