# Metadata Migration

Tool to migrate the existing data in the Excel meta data spreadsheet into a Neo4j database. 

Note: The spreadsheet is embedded within this project under ```src/main/resources```. Make sure it is up to date before performing the build.

## Usage

- Build the source by running:

```mvn clean package```

- Copy the ```metadata-migration-1.0.0-SNAPSHOT.jar``` package onto the target machine that is hosting the neo4j database.

- Initialise the migration by running the following:

```java -jar metadata-migration-1.0.0-SNAPSHOT.jar <path_to_neo4j_db>```
