import org.linkedin.glu.agent.api.ShellExecException

/**
 * This is a glu script for installing and linking neo client artifacts.  Basic monitoring is provided.  If
 * the artifact installation directory disappears or is linked to another version, this will be flagged as
 * an error.
 * <p>
 * Required configuration:
 * <pre>
 *     "initParameters": {
 *       "project": {              // the nexus artifact details
 *         "a": "core-server-entitlements",
 *         "g": "com.ubs.f35.core",
 *         "v": "3.1.2-SNAPSHOT"
 *       }
 *     }
 * </pre>
 */
class NeoClientGluScript extends BaseNeoScript {

    def install = {
        baseInstall()
        
        // Now check artifact is actually present in the expected place.
        // A weakness in the core script's FileSystemApi can result in a non-dev host being detected as a dev 
        // host or vice versa, resulting in the artifact being installed in the wrong location (shared/local).
        // The weakness is that the presence of /sbclocal/apps/f35/install/com.ubs.f35.core/scripts is used as the 
        // differentiator, but this directory is not absolutely guaranteed to exist on all non-dev hosts.  
        def deploymentError = isArtifactDeployed()
        if(deploymentError != null) {
            log.warn "Artifact not deployed to the expected location. Check the core scripts are present in the correct location on this host."
            shell.fail("Artifact was not deployed to the expected location: " + deploymentError)
        }
    }

    def configure = {
        baseConfigure('10m')
    }

    def start = {
        // Fail if a different version of the artifact is deployed or not deployed at all
        String artifactDeployed = isArtifactDeployed()
        
        if (artifactDeployed != null) {
            shell.fail(artifactDeployed)
        }
    }

    def stop = {
        // nothing
    }

    private String isArtifactDeployed()
    {
        String runningVersion = getDeployedArtifactVersion()
        
        if (runningVersion == null) {
            return "Artifact not found."
        } else if (!runningVersion.equals(projectVersion)) {
            log.info("readLink found wrong version of artifact [${runningVersion}]")
            return "Version '${runningVersion}' is deployed" 
        }
        
        return null
    }

    /**
     * Defines the timer that will check for the server to be up and running and will act
     * according if not (change state)
     */
    def processMonitor = {
        try
        {
            def clientError = isArtifactDeployed()
            def up = (clientError == null)

            def currentState = stateManager.state.currentState

            def newState = null
            def newError = null

            // case when current state is running
            if(currentState == 'running')
            {
                if(!up)
                {
                    newState = 'stopped'
                    newError = clientError
                    log.warn "${newError} => forcing new state ${newState}"
                }
            }
            else
            {
                if(up)
                {
                    newState = 'running'
                    log.info "Client artifact found again"
                }
            }

            // If the client artifact is detected again, do not move it to the running state if there is no error set.  
            // If there is no error set, then a user explicitly stopped the process. This may be part of an undeploy, which
            // will fail if the artifact is moved back to a 'running' state before the unconfigure transition is executed. 
            if (newState && 
                (newState != 'running' || stateManager.state.error)) {
                stateManager.forceChangeState(newState, newError)
            }

            log.debug "Server Monitor: ${stateManager.state.currentState} / ${up}"
        }
        catch(Throwable th)
        {
            log.warn "Exception while running serverMonitor: ${th.message}"
            log.debug("Exception while running serverMonitor (ignored)", th)
        }
    }
}