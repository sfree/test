login
=====
resourceful login view for Neo javascript projects

![](https://github.ldn.swissbank.com/NeoHTML/login/raw/master/thumbnail.png)

## Usage
 - Add `"github:NeoHTML/login"` in your resource.json:

```json
{
	"dependencies": [
		"github:NeoHTML/login"
	]
}
```
 - navigate to `/login` in your app

## auto-redirect
After the user successfully logged in, the login module auto-redirects the user to `/`

You can change the redirection url by adding `?origin=/yourPage` to the url, eg.:
```
yourUrl/login?origin=/neotalk
```

To disable auto-redirection, use `?noredirect`.



