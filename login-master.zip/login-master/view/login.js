define(
   [ "jquery"
   , "./login-util"
   , "q"
   ],
   function($, loginUtils, q) {
      
      return function(username, password) {

         var defer = q.defer()

         if (!username || !password){
           defer.reject("Please enter your username and password")
           return defer.promise
         } 
        
         $.ajax(
            {
               type: "POST",
               url: "/login-service",
               data: loginUtils.createSOAPEnvelopeForLWSService(username, password),
               headers: {
                  "Content-Type": "text/xml",
                  "SOAPAction": "null"
               },
               dataType: "xml",
               crossDomain: true
            }
         )
         .fail(
            function(error){
              defer.reject("Error connecting to login service")
            }
          )
         .success(
            function(data) {
               var token = $(data).find("getSecurityTokenReturn").text().split("!")[2].substr(9);
               // lws returned a "null" token or something else which isn't long enough to be valid.
               if (!token || token.length <= 4) { 
                 defer.reject("Incorrect username or password")
               } else {
                 var today = new Date();
                 today.setDate(today.getDate() + 1);
                 var exp = today.toUTCString()
                 document.cookie = 'LWSTOKEN="' + token + '";expires=' + exp + ';domain='+document.domain+';path=/;'
  
                 $.getJSON('/api/auth/user')
                   .done(function(data){
                     document.cookie = 'UBSGUID="' + data.userName + '";expires=' + exp + ';domain='+document.domain+';path=/;'
                     defer.resolve()
                   })
                   .fail(function(error) {
                     defer.reject("Error validating token")
                   })
                }
            }
         )

         return defer.promise   
      }
   }
)
