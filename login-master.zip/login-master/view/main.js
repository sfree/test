define(
   [ "jquery"
   , "./login"
   , "./url"
   , "token-expiry/monitor"
   , "css!./style.css"
   ], 
   function($, login, urlhandler, monitor) {

      function loginModule(node) {
         var url = urlhandler()

         if (monitor.isValid() 
            && !/^\/login/.test(window.location.pathname)) {
            redirect()
            return;
         }

         function redirect() {
            var origin = url.params.origin && decodeURIComponent(url.params.origin) || '/swift'
            url.redirect(origin)
         }

         function submit() {
               var name = $(".login-username").val()
               var password = $(".login-password").val()
               $(".login-error").addClass("is-hidden");
               $(".login-button").attr("disabled", "disabled");
               login(name, password)
                  .then(
                     function() {
                        $(".login-box").addClass("login-slide-down");
                        setTimeout(function(){
                            $(".login-success").removeClass("is-hidden");
                        },1000);
                        
                        if (!url.params.hasOwnProperty("noredirect")) {
                           setTimeout(function(){
                              redirect()
                           },2000);
                        }
                     }
                  )
                  .fail(
                     function(e){
                        $(".login-error").removeClass("is-hidden").text(e);
                     }
                  )
                  .fin(
                     function(){
                        $(".login-button").removeAttr("disabled");
                     }
               )
            }

         $('.login-form input').keypress(
            function (e) {
               if(e.which == 13) { submit(); }
            }
         )
         $(".login-button").click(submit)
      }
      return loginModule
   }
)
