define(
   function() {
      
      var instance = function() {

      }

      function escapeXml(string) {
         return string && string.replace(/&/g, '&amp;')
               .replace(/</g, '&lt;')
               .replace(/>/g, '&gt;')
               .replace(/"/g, '&quot;')
               .replace(/'/g, '&apos;');
      }

      instance.createSOAPEnvelopeForLWSService = function (username, password) {
         var request = '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
         request += 'xmlns:xsd="http://www.w3.org/2001/XMLSchema" '
         request += 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
         request += '<soap:Body>'
         request += '<getSecurityToken xmlns="http://logon.logonws.directory.ubs.com">'
         request += '<username>' + escapeXml(username) + '</username>'
         request += '<password>' + escapeXml(password) + '</password>'
         request += '<targetInfo></targetInfo>'
         request += '<versionInfo></versionInfo>'
         request += '</getSecurityToken>'
         request += '</soap:Body>'
         request += '</soap:Envelope>'

         return request
      }

      instance.createSOAPEnvelopeForEMIDASService = function (uniqueId, token, clientId) {
         var request = '<soapenv:Envelope xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" '
         request += 'xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" '
         request += 'xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
         request += '<soapenv:Header>'
         request += '<wsse:Security soapenv:mustUnderstand="1" '
         request += 'xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" '
         request += 'xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wsswssecurity-utility-1.0.xsd">'
         request += '<wsse:BinarySecurityToken wsu:Id="' + uniqueId
         request += '" ValueType="http://ubs.com/emidas/webservice/authn/service/v1#LWS">' + token 
         request += '</wsse:BinarySecurityToken>'
         request += '</wsse:Security>'
         request += '</soapenv:Header>'
         request += '<soapenv:Body>'
         request += '<wst:RequestSecurityToken xmlns:authn="http://ubs.com/emidas/webservice/authn/type/v1" '
         request += 'xmlns:wst="http://docs.oasis-open.org/ws-sx/ws-trust/200512">'
         request += '<authn:ClientId>' + clientId + '</authn:ClientId>'
         request += '<wst:TokenType>'
         request += 'http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.1#SAMLV1.1</wst:TokenType>'
         request += '<wst:RequestType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/Issue</wst:RequestType>'
         request += '</wst:RequestSecurityToken>' + '</soapenv:Body>' + '</soapenv:Envelope>'

         return request
      }

      return instance
   }
)