
-- deployments by release and time
create index deploy_release_time_idx on deployments(release_id, deploytime, id);

-- deployments by release
create index deploy_release_idx on deployments(release_id);

-- release by org (indirect by team) and release date
create index release_team_date_idx on release_definition(team_id, releasedate);

-- activity by objectid (used to find if there is an existing activity to merge with)
create index activity_by_objectid on activity(object_id, activity_time);

-- activity by organisation and date
create index activity_by_org on activity(organisation_id, activity_time);

-- activity by date
create index activity_by_date on activity(activity_time);

-- env deployments by status and deployment id
create index envdep_by_depid_status on ENV_DEPLOYMENT(DEPLOYMENT_ID, DEPLOYSTATUS);

-- env deployments by status and deployment id and env
create index envdep_by_depid_status_env ON ENV_DEPLOYMENT (DEPLOYMENT_ID, DEPLOYSTATUS, ENVIRONMENT_ID)                              

commit;


--queries for testing
/*
select deployment0_.id as id0_0_ , envdeploym1_.environment_id as environm2_17_1_, envdeploym1_.deployment_id as deployment3_17_1_, deployment0_.CREATEDTIME as CREATEDT2_0_0_, deployment0_.DEPLOYTIME as DEPLOYTIME0_0_, deployment0_.DEPLOYSTATUS as DEPLOYST5_0_0_, deployment0_.DEPLOYMENT_TYPE as DEPLOYMENT6_0_0_, deployment0_.RELEASE_ID as RELEASE8_0_0_, deployment0_.RELEASE_REV as RELEASE9_0_0_, deployment0_.DEPLOY_USER as DEPLOY10_0_0_, envdeploym1_.DEPLOYSTATUS as DEPLOYST1_17_1_, envdeploym1_.deployment_id as deployment3_0_0__, envdeploym1_.environment_id as environm2_17_0__, envdeploym1_.deployment_id as deployment3_17_0__ 
from DEPLOYMENTS deployment0_ inner join ENV_DEPLOYMENT envdeploym1_ on deployment0_.id=envdeploym1_.deployment_id 
where
deployment0_.RELEASE_ID < 200
and ((envdeploym1_.environment_id , deployment0_.DEPLOYTIME) in 
  (select envdeploym2_.environment_id, max(deployment3_.DEPLOYTIME) 
  from ENV_DEPLOYMENT envdeploym2_ inner join DEPLOYMENTS deployment3_ on envdeploym2_.deployment_id=deployment3_.id
  where deployment3_.RELEASE_ID=deployment0_.RELEASE_ID and envdeploym2_.DEPLOYSTATUS<> 'PLAN' 
  group by envdeploym2_.environment_id)) 
  
  
select * from deployments where release_id = 5 and deploytime > '2013-09-05'  
*/