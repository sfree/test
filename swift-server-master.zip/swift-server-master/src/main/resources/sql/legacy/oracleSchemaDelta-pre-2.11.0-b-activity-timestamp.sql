-- This script is run before the swift server upgrade.  There should be no outage to swift during the upgrade.

ALTER TABLE ACTIVITY ADD (LASTUPDATEDTIME TIMESTAMP NULL);

UPDATE ACTIVITY SET LASTUPDATEDTIME = ACTIVITY_TIME;

-- Make mandatory now seeded with data
ALTER TABLE ACTIVITY MODIFY(LASTUPDATEDTIME TIMESTAMP NOT NULL);
    
COMMIT;    