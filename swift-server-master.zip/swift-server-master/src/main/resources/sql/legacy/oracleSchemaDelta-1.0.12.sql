------- LAST UPDATED BY -------

ALTER TABLE release_definition ADD 
(
	LASTUPDATEDBY VARCHAR(128) NULL
);

update release_definition rda1 set lastupdatedby = (
select audit_user from RELEASE_DEFINITION_AUD rda, SWIFTREVENTRY swe where rda.rev = swe.id and rda.id=rda1.id and rda.rev = (select max(rev) from RELEASE_DEFINITION_AUD where id=rda1.id)
);
--update release_definition rda1 set lastupdatedby='PSI43357588' where lastupdatedby is NULL

ALTER TABLE release_definition MODIFY 
(
	LASTUPDATEDBY VARCHAR(128) NOT NULL
);