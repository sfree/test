-- This script is run before the swift server upgrade.  There should be no outage to swift during the upgrade.

ALTER TABLE ARTIFACT_CONFIG ADD (COLDSTANDBY NUMBER(1) DEFAULT 0 NOT NULL);

ALTER TABLE ARTIFACT_CONFIG_AUD ADD (COLDSTANDBY NUMBER(1));

COMMIT