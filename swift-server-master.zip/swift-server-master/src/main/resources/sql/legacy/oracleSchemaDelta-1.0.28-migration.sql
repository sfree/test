delete from teams;

insert into teams(name) values ('Other'); 
insert into teams(name) values ('Swift');
insert into teams(name) values ('Blue');
insert into teams(name) values ('Aqua'); 
insert into teams(name) values ('Yellow'); 
insert into teams(name) values ('Pink'); 
insert into teams(name) values ('Graphite'); 
insert into teams(name) values ('Purple'); 
insert into teams(name) values ('P360'); 
insert into teams(name) values ('FX Cash'); 
insert into teams(name) values ('FX Derivs'); 
insert into teams(name) values ('FX Flightdeck'); 
insert into teams(name) values ('FX Algo'); 
insert into teams(name) values ('Equities'); 
insert into teams(name) values ('Prime Services'); 

update RELEASE_DEFINITION
set team_id = 1
where team_id is null and (
    lower(name) like '%demo%' or lower(name) like '%gemfire%' or lower(name) like '%test%' or lower(name) like '%deleted%' or lower(name) like '%luke%'
);

update RELEASE_DEFINITION
set team_id = 2
where TEAM = 'NeoSwift' and team_id is null;

update RELEASE_DEFINITION
set team_id = 3
where lower(name) like '%blue %' and team_id is null;

update RELEASE_DEFINITION
set team_id = 4
where lower(name) like '%aqua %' and team_id is null;

update RELEASE_DEFINITION
set team_id = 5
where lower(name) like '%yellow %' and team_id is null;

update RELEASE_DEFINITION
set team_id = 6
where lower(name) like '%pink %' and team_id is null;

update RELEASE_DEFINITION
set team_id = 7
where lower(name) like '%graphite %' and team_id is null;

update RELEASE_DEFINITION
set team_id = 8
where lower(name) like '%purple %' and team_id is null;

update RELEASE_DEFINITION
set team_id = 9
where team = 'FedCRM' and team_id is null;

update RELEASE_DEFINITION
set team_id = 14
where team = 'EQ' and team_id is null;

-- everything else can be assigned to other
update RELEASE_DEFINITION
set team_id = 1
where team_id is null;

ALTER TABLE release_definition MODIFY 
(
    TEAM VARCHAR(128) NULL
);


ALTER TABLE release_definition MODIFY 
(
    TEAM_ID INT NOT NULL
);

