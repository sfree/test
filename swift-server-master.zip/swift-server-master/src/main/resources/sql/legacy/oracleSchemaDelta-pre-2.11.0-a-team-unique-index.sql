-- This script is run before the swift server upgrade.  There should be no outage to swift during the upgrade.

ALTER TABLE TEAMS DROP CONSTRAINT unique_team;
DROP INDEX UNIQUE_TEAM;

ALTER TABLE TEAMS ADD CONSTRAINT unique_team UNIQUE (ORGANISATION_ID, NAME);    
    
COMMIT;    