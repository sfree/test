ALTER TABLE HOSTS ADD 
(
	LASTAUTORESTARTTIME timestamp null
);

update artifact_config
set script = '2.0.6/NeoServerGluScript'
where script like '%NeoServerGluScript%';

update artifact_config
set script = '2.0.6/NeoNodeGluScript'
where script like '%NeoNodeGluScript%';