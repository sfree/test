-- This script is run after the swift server upgrade.  There should be no outage to swift during the upgrade.

-- RELEASE_DEFINITION changes

UPDATE RELEASE_DEFINITION SET DEPLOYMENTPROCESS = 'RollingUpgrade' WHERE DEPLOYMENTPROCESS IS NULL;

-- make column not null now swift is upgrade all values initialised.
ALTER TABLE RELEASE_DEFINITION MODIFY(DEPLOYMENTPROCESS VARCHAR(128) NOT NULL);

COMMIT
