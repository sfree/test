update artifact_config
set script = '1.0.3/NeoClientGluScript.groovy'
where script like '%NeoClientGluScript.groovy';

update artifact_config
set script = '1.0.3/NeoServerGluScript.groovy'
where script like '%NeoServerGluScript.groovy' or script like'%NeoGluScript.groovy';

-- This should show only 1.0.3 scripts are in use.
-- Note that old scripts can not be removed.  Processes which are currently deployed will not be upgraded to the new script until 
-- they are redeployed.
select script, count(*) from artifact_config
group by script;

ALTER TABLE ARTIFACT_CONFIG_TAGS RENAME COLUMN GROUP_ID to NAME1;
ALTER TABLE ARTIFACT_CONFIG_TAGS RENAME COLUMN ARTIFACT_ID to GROUP_ID;
ALTER TABLE ARTIFACT_CONFIG_TAGS RENAME COLUMN NAME to ARTIFACT_ID;
ALTER TABLE ARTIFACT_CONFIG_TAGS RENAME COLUMN NAME1 to NAME;

ALTER TABLE ARTIFACT_CONFIG_TAGS ADD CONSTRAINT unique_artifact_config_tag UNIQUE (GROUP_ID, ARTIFACT_ID, NAME, ENVIRONMENT, TAG);
ALTER TABLE ARTIFACT_CONFIG_DEPLOY_TAGS ADD CONSTRAINT unique_art_config_deploy_tag UNIQUE (GROUP_ID, ARTIFACT_ID, NAME, ENVIRONMENT, TAG, TAG_ENVIRONMENT);
ALTER TABLE HOST_DEPLOY_TAGS ADD CONSTRAINT unique_host_deploy_tag UNIQUE (HOSTNAME, ENVIRONMENT, TAG);


-- If duplicates already exist in ARTIFACT_CONFIG_TAGS join table
/*
-- Check for any duplicates
select GROUP_ID, ARTIFACT_ID, NAME, ENVIRONMENT, TAG
from ARTIFACT_CONFIG_TAGS a 
where 
   rowid > 
     (select min(rowid) from ARTIFACT_CONFIG_TAGS b 
      where b.GROUP_ID = a.GROUP_ID and b.ARTIFACT_ID = a.ARTIFACT_ID and b.NAME = a.NAME and b.ENVIRONMENT = a.ENVIRONMENT and b.TAG = a.TAG );

-- Remove any duplicates
delete from ARTIFACT_CONFIG_TAGS a 
where 
   a.rowid > 
     any (select b.rowid from ARTIFACT_CONFIG_TAGS b 
     where b.GROUP_ID = a.GROUP_ID and  b.ARTIFACT_ID = a.ARTIFACT_ID and b.NAME = a.NAME and b.ENVIRONMENT = a.ENVIRONMENT and  b.TAG = a.TAG );
*/


-- If duplicates already exist in ARTIFACT_CONFIG_TAGS join table
/*
-- Check for any duplicates 
select GROUP_ID, ARTIFACT_ID, NAME, ENVIRONMENT, TAG, TAG_ENVIRONMENT
from ARTIFACT_CONFIG_DEPLOY_TAGS a 
where 
   rowid > 
     (select min(rowid) from ARTIFACT_CONFIG_DEPLOY_TAGS b 
      where b.GROUP_ID = a.GROUP_ID and b.ARTIFACT_ID = a.ARTIFACT_ID and b.NAME = a.NAME and b.ENVIRONMENT = a.ENVIRONMENT and b.TAG = a.TAG and b.TAG_ENVIRONMENT = a.TAG_ENVIRONMENT );

-- Remove any duplicates
delete from ARTIFACT_CONFIG_DEPLOY_TAGS a 
where 
   a.rowid > 
     any (select b.rowid from ARTIFACT_CONFIG_DEPLOY_TAGS b 
     where b.GROUP_ID = a.GROUP_ID and b.ARTIFACT_ID = a.ARTIFACT_ID and b.NAME = a.NAME and b.ENVIRONMENT = a.ENVIRONMENT and b.TAG = a.TAG and b.TAG_ENVIRONMENT = a.TAG_ENVIRONMENT );
*/ 


 
