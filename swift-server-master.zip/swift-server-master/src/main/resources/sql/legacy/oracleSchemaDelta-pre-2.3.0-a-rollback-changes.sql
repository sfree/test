-- This script is run before the swift server upgrade.  There should be no outage to swift during the upgrade.

ALTER TABLE DEPLOYMENTS ADD (GENERATION_CONTEXT CLOB NULL);

UPDATE DEPLOYMENTS SET DEPLOYMENT_TYPE = 'Release', DEPLOYSTATUS = 'MANUAL' WHERE DEPLOYMENT_TYPE = 'Manual';

COMMIT