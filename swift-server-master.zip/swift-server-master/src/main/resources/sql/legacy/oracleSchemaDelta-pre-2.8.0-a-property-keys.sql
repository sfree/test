-- This script is run before the swift server upgrade.  There should be no outage to swift during the upgrade.

ALTER TABLE ARTIFACT_PROPERTY_KEYS ADD (SUGGESTED_VALUE CLOB NULL, DOCUMENTATION CLOB NULL);
  
COMMIT