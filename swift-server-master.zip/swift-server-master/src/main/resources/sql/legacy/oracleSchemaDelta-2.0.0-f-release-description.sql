/* Backup existing properties tables */

CREATE TABLE RELEASE_DEFINITION_backup1
  AS (SELECT * FROM RELEASE_DEFINITION);
  
CREATE TABLE RELEASE_DEFINITION_AUD_backup1
  AS (SELECT * FROM RELEASE_DEFINITION_AUD);

  
/* Alter properties table */

ALTER TABLE RELEASE_DEFINITION
 ADD (tmpvalue CLOB);

UPDATE RELEASE_DEFINITION SET tmpvalue=description;
COMMIT;

ALTER TABLE RELEASE_DEFINITION DROP COLUMN description;

ALTER TABLE RELEASE_DEFINITION
RENAME COLUMN tmpvalue TO description;  
  
/* Alter properties audit table */

ALTER TABLE RELEASE_DEFINITION_AUD
 ADD (tmpvalue CLOB);

UPDATE RELEASE_DEFINITION_AUD SET tmpvalue=description;
COMMIT;

ALTER TABLE RELEASE_DEFINITION_AUD DROP COLUMN description;

ALTER TABLE RELEASE_DEFINITION_AUD
RENAME COLUMN tmpvalue TO description;

COMMIT;

/* Try saving a release using the swift client. 
 * If successful, drop the backup tables:

DROP TABLE RELEASE_DEFINITION_backup1;
DROP TABLE RELEASE_DEFINITION_AUD_backup1;

*/
  

