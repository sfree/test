-- Hello and thanks for running this script.
-- Please be sure to change SWIFTADMIN and SWIFTSERVICE to the correct schema/account name in other environments

-- PERMISSIONS 
GRANT SELECT, UPDATE, DELETE, INSERT ON SWIFTADMIN.ORGANISATIONS TO SWIFTSERVICE;
GRANT SELECT ON SWIFTADMIN.seq_env_id TO SWIFTSERVICE;
GRANT SELECT ON SWIFTADMIN.seq_org_id TO SWIFTSERVICE;

COMMIT
