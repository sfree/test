update artifact_config
set script = '2.0.1/NeoClientGluScript'
where script like '%NeoClientGluScript%';

update artifact_config
set script = '2.0.1/NeoServerGluScript'
where script like '%NeoServerGluScript%';

-- This should show only 2.0.0 scripts are in use.
-- Note that old scripts can not be removed.  Processes which are currently deployed will not be upgraded to the new script until 
-- they are redeployed.
select script, count(*) from artifact_config
group by script;
