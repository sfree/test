package com.ubs.f35.swift.web.client;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import org.linkedin.util.clock.Timespan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.util.Assert;
import org.springframework.web.client.HttpMessageConverterExtractor;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;
import org.springframework.web.util.UriUtils;

import com.ubs.f35.swift.executors.SwiftExecutors;

/**
 * An extension of {@link RestTemplate} which allows REST calls to be cancelled after a given timeout.
 * <p>
 * The template may be configured with a default timeout which applies to all operations performed on the base
 * {@link RestTemplate}. Alternatively, invocation specific timeouts may also be provided for each rest call.
 * <p>
 * Note that this approach closes the stream to terminate a long running connection. Interrupting a thread does not have
 * any affect on blocking socket IO and the thread will continue
 * <p>
 * This implementation unfortunately has more copy paste than desirable because of scoping of functionality within the
 * spring RestTemplate.
 */
public class TimeLimitedRestTemplate extends RestTemplate {
    private static final Logger LOG = LoggerFactory.getLogger(TimeLimitedRestTemplate.class);

    private static final ThreadFactory THREAD_FACTORY = SwiftExecutors.namedThreadFactory("io-timeout", true);
    private static final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor(THREAD_FACTORY);

    private long defaultTimeout = 1;
    private TimeUnit defaultTimeoutTimeUnit = TimeUnit.MINUTES;

    public TimeLimitedRestTemplate() {
    }

    public TimeLimitedRestTemplate(final ClientHttpRequestFactory requestFactory) {
        super(requestFactory);
    }

    /**
     * Execute the given method on the provided URI. The {@link ClientHttpRequest} is processed using the
     * {@link RequestCallback}; the response with the {@link ResponseExtractor}.
     * 
     * @param url
     *            the fully-expanded URL to connect to
     * @param method
     *            the HTTP method to execute (GET, POST, etc.)
     * @param requestCallback
     *            object that prepares the request (can be <code>null</code>)
     * @param responseExtractor
     *            object that extracts the return value from the response (can be <code>null</code>)
     * @return an arbitrary object, as returned by the {@link ResponseExtractor}
     */
    @Override
    protected <T> T doExecute(final URI url, final HttpMethod method, final RequestCallback requestCallback,
            final ResponseExtractor<T> responseExtractor) throws RestClientException {
        return doExecute(url, method, requestCallback, responseExtractor, defaultTimeout, defaultTimeoutTimeUnit);
    }

    /**
     * Execute the given method on the provided URI. The {@link ClientHttpRequest} is processed using the
     * {@link RequestCallback}; the response with the {@link ResponseExtractor}.
     * 
     * @param url
     *            the fully-expanded URL to connect to
     * @param method
     *            the HTTP method to execute (GET, POST, etc.)
     * @param requestCallback
     *            object that prepares the request (can be <code>null</code>)
     * @param responseExtractor
     *            object that extracts the return value from the response (can be <code>null</code>)
     * @param timeout
     *            The maximum amount of time this request will be allowed to execute before being cancelled.
     * @param timeoutTimeUnit
     *            The time unit of the timeout
     * @return an arbitrary object, as returned by the {@link ResponseExtractor}
     */
    protected <T> T doExecute(final URI url, final HttpMethod method, final RequestCallback requestCallback,
            final ResponseExtractor<T> responseExtractor, final long timeout, final TimeUnit timeoutTimeUnit)
            throws RestClientException {

        Assert.notNull(url, "'url' must not be null");
        Assert.notNull(method, "'method' must not be null");
        ClientHttpResponse response = null;

        final AtomicReference<ClientHttpResponse> responseRef = new AtomicReference<ClientHttpResponse>();
        final AtomicBoolean timeoutInterrupted = new AtomicBoolean(false);
        Future<?> future = null;
        try {
            ClientHttpRequest request = createRequest(url, method);
            if (requestCallback != null) {
                requestCallback.doWithRequest(request);
            }
            response = request.execute();

            responseRef.set(response);

            Runnable interruptHungIOJob = new Runnable() {
                @Override
                public void run() {
                    try {
                        ClientHttpResponse response = responseRef.get();
                        if (response != null) {
                            LOG.info("Request has timed out {}.  Closing response.", url);
                            timeoutInterrupted.set(true);
                            response.close();
                        }
                    } catch (Exception ex) {
                        LOG.warn("exception ", ex);
                    }
                }
            };

            future = executor.schedule(interruptHungIOJob, timeout, timeoutTimeUnit);

            if (!getErrorHandler().hasError(response)) {
                logResponseStatus(method, url, response);
            }
            else {
                handleResponseError(method, url, response);
            }
            if (responseExtractor != null) {
                return responseExtractor.extractData(response);
            }
            else {
                return null;
            }
        } catch (IOException ex) {
            if (timeoutInterrupted.get()) {
                throw new ResourceAccessException("Request timed out", ex);
            }
            throw new ResourceAccessException("I/O error: " + ex.getMessage(), ex);
        } finally {
            responseRef.set(null);
            if (response != null && !timeoutInterrupted.get()) {
                response.close();
            }
            if (future != null) {
                future.cancel(false);
            }
        }
    }

    /**
     * Copy paste from {@link RestTemplate}
     * 
     * @param method
     * @param url
     * @param response
     */
    private void logResponseStatus(final HttpMethod method, final URI url, final ClientHttpResponse response) {
        if (logger.isDebugEnabled()) {
            try {
                logger.debug(
                        method.name() + " request for \"" + url + "\" resulted in " + response.getStatusCode() + " (" +
                                response.getStatusText() + ")");
            } catch (IOException e) {
                // ignore
            }
        }
    }

    /**
     * Copy paste from {@link RestTemplate}
     * 
     * @param method
     * @param url
     * @param response
     */
    private void handleResponseError(final HttpMethod method, final URI url, final ClientHttpResponse response)
            throws IOException {
        if (logger.isWarnEnabled()) {
            try {
                logger.warn(
                        method.name() + " request for \"" + url + "\" resulted in " + response.getStatusCode() + " (" +
                                response.getStatusText() + "); invoking error handler");
            } catch (IOException e) {
                // ignore
            }
        }
        getErrorHandler().handleError(response);
    }

    /**
     * As per {@link #getForObject(String, Class, Object...)} but with the ability to specify a timeout for the call.
     */
    public <T> T getForObject(final String url, final Timespan ioTimeout, final Class<T> responseType,
            final Object... urlVariables) throws RestClientException {
        AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType);
        // default implementation also passed 'logger' to HttpMessageConverterExtractor constructor
        HttpMessageConverterExtractor<T> responseExtractor =
                new HttpMessageConverterExtractor<T>(responseType, getMessageConverters());
        return execute(url, ioTimeout, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
    }

    private <T> T execute(final String url, final Timespan ioTimeout, final HttpMethod method,
            final RequestCallback requestCallback,
            final ResponseExtractor<T> responseExtractor, final Object... urlVariables) throws RestClientException {

        UriTemplate uriTemplate = new HttpUrlTemplate(url);
        URI expanded = uriTemplate.expand(urlVariables);
        return doExecute(expanded, method, requestCallback, responseExtractor, ioTimeout.getDurationInMilliseconds(),
                TimeUnit.MILLISECONDS);
    }

    public void setDefaultTimeout(final long defaultTimeout) {
        this.defaultTimeout = defaultTimeout;
    }

    public void setDefaultTimeoutTimeUnit(final TimeUnit defaultTimeoutTimeUnit) {
        this.defaultTimeoutTimeUnit = defaultTimeoutTimeUnit;
    }

    /**
     * COPY PASTE WARNING
     * 
     * Request callback implementation that prepares the request's accept headers.
     */
    private class AcceptHeaderRequestCallback implements RequestCallback {

        private final Class<?> responseType;

        private AcceptHeaderRequestCallback(final Class<?> responseType) {
            this.responseType = responseType;
        }

        @Override
        @SuppressWarnings("unchecked")
        public void doWithRequest(final ClientHttpRequest request) throws IOException {
            if (responseType != null) {
                List<MediaType> allSupportedMediaTypes = new ArrayList<MediaType>();
                for (HttpMessageConverter<?> messageConverter : getMessageConverters()) {
                    if (messageConverter.canRead(responseType, null)) {
                        List<MediaType> supportedMediaTypes = messageConverter.getSupportedMediaTypes();
                        for (MediaType supportedMediaType : supportedMediaTypes) {
                            if (supportedMediaType.getCharSet() != null) {
                                supportedMediaType =
                                        new MediaType(supportedMediaType.getType(), supportedMediaType.getSubtype());
                            }
                            allSupportedMediaTypes.add(supportedMediaType);
                        }
                    }
                }
                if (!allSupportedMediaTypes.isEmpty()) {
                    MediaType.sortBySpecificity(allSupportedMediaTypes);
                    if (logger.isDebugEnabled()) {
                        logger.debug("Setting request Accept header to " + allSupportedMediaTypes);
                    }
                    request.getHeaders().setAccept(allSupportedMediaTypes);
                }
            }
        }
    }

    /**
     * COPY PASTE WARNING
     * 
     * HTTP-specific subclass of UriTemplate, overriding the encode method.
     */
    private static class HttpUrlTemplate extends UriTemplate {

        public HttpUrlTemplate(final String uriTemplate) {
            super(uriTemplate);
        }

        @Override
        protected URI encodeUri(final String uri) {
            try {
                String encoded = UriUtils.encodeHttpUrl(uri, "UTF-8");
                return new URI(encoded);
            } catch (UnsupportedEncodingException ex) {
                // should not happen, UTF-8 is always supported
                throw new IllegalStateException(ex);
            } catch (URISyntaxException ex) {
                throw new IllegalArgumentException("Could not create HTTP URL from [" + uri + "]: " + ex, ex);
            }
        }
    }

}
