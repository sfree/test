package com.ubs.f35.swift.model;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Environment;

/**
 * This starts to separate out the natural identifying components of {@link Environment}. This has been done as using
 * the {@link Environment} object as both an id of an environment and also in a persistence context is causing a few
 * bugs where the {@link Environment#getId()} returns null because only the natural identifier components have been set.
 * <p>
 * TODO it's going to be a huge refactor to switch across to this outside of persistence contexts.
 */
public class EnvironmentId {
    private final String environmentName;
    private final String organisationName;

    public EnvironmentId(final String organisationName, final String environmentName) {
        this.environmentName = environmentName;
        this.organisationName = organisationName;
    }

    public String getEnvironmentName() {
        return environmentName;
    }

    public String getOrganisationName() {
        return organisationName;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(environmentName, organisationName);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof EnvironmentId) {
            EnvironmentId that = (EnvironmentId) object;
            return Objects.equal(this.environmentName, that.environmentName)
                    && Objects.equal(this.organisationName, that.organisationName);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("environmentName", environmentName)
                .add("organisationName", organisationName)
                .toString();
    }
}
