package com.ubs.f35.swift.deploy.glu.plan;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.action.Action;
import com.ubs.f35.swift.deploy.glu.action.BaseGroupedAction;
import com.ubs.f35.swift.deploy.glu.action.ParallelAction;
import com.ubs.f35.swift.deploy.glu.action.SequentialAction;
import com.ubs.f35.swift.environment.model.glu.Entry;

public class DeploymentPlanBuilder {
    private static final Logger LOG = LoggerFactory.getLogger(DeploymentPlanBuilder.class);
    private final Deque<DeploymentPlanBuilderGroup> builderStack = new ArrayDeque<DeploymentPlanBuilderGroup>();
    private final Set<Warning> warnings = Sets.newLinkedHashSet();
    private Action action;
    private final Set<Entry> entries = Sets.newHashSet();

    public DeploymentPlanBuilder() {

    }

    /**
     * Adds a steps which can occur in parallel. Also includes the entry that the steps relate to.
     * 
     * @param action
     * @return
     */
    public DeploymentPlanBuilder addStep(final Action action, final Entry entry) {
        entries.add(entry);

        return addStep(action);
    }

    public DeploymentPlanBuilder addStep(final Action action) {
        if (builderStack.isEmpty()) {
            throw new IllegalStateException("Can't add actions outside of a group.");
        } else {
            builderStack.peekLast().actions.add(action);
        }
        return this;
    }

    public DeploymentPlanBuilder startGroupedAction(final String id, final String name) {
        builderStack.add(new DeploymentPlanBuilderGroup(id, name));
        return this;
    }

    public DeploymentPlanBuilder completeGroupedAction(final boolean parallel) {
        return completeGroupedAction(parallel, true);
    }

    public DeploymentPlanBuilder completeGroupedAction(final boolean parallel, final boolean execute) {
        DeploymentPlanBuilderGroup group = builderStack.removeLast();

        // Don't worry about appending to the deployment plan if no actions were added.
        if (!group.actions.build().isEmpty()) {
            Action action = group.buildAction(parallel, execute);
            if (builderStack.isEmpty()) {
                Assert.isNull(this.action, "Action has already been set");
                this.action = action;
            } else {
                addStep(action);
            }
        }
        return this;
    }

    private Action buildAction() {
        Assert.isTrue(builderStack.isEmpty(), "Unclosed operations in plan");
        if (action == null) {
            String message = "Empty deployment plan.";
            // Empty deployment plans are invalid. But this may occur if the agent was down and warnings were added. If
            // there are warnings, propagate them here.
            if (!warnings.isEmpty()) {
                message += " May have been caused by:\n"
                        + Iterables.toString(Iterables.transform(warnings, new Function<Warning, String>() {
                            @Override
                            public String apply(final Warning input) {
                                return input.getMessage();
                            }
                        }));
            }
            LOG.info(message);
            throw new IllegalArgumentException(message);
        }

        return action;
    }

    public DeploymentPlan build() {
        DeploymentPlan plan = new DeploymentPlan(UUID.randomUUID(), Arrays.asList(buildAction()));
        plan.setWarnings(getWarnings());

        return plan;
    }

    private static class DeploymentPlanBuilderGroup {
        private final Builder<Action> actions = ImmutableList.builder();
        private final String id;
        private final String name;
        private Environment environment;

        public DeploymentPlanBuilderGroup(final String id, final String name) {
            this.id = id;
            this.name = name;
        }

        public Action buildAction(final boolean parallel, final boolean execute) {
            // TODO if actions support dependencies, then this will become pointless.
            // List<Action> childActions = actions.build();
            //
            // if (childActions.size() ==1 && childActions.get(0) instanceof BaseGroupedAction){
            // // No point wrapping a grouped action in another one.
            // }
            BaseGroupedAction action = parallel ?
                    new ParallelAction(id, name, actions.build()) :
                    new SequentialAction(id, name, actions.build());

            action.setExecute(execute);
            action.setEnvironment(environment);
            return action;
        }

    }

    public void addWarning(final String warning) {
        warnings.add(new Warning(warning));
    }

    public void addWarning(final Warning warning) {
        warnings.add(warning);
    }

    public List<Warning> getWarnings() {
        return Lists.newArrayList(warnings);
    }

    public Set<Entry> getEntries() {
        return entries;
    }

    public Set<String> getHosts() {
        Set<String> hosts = Sets.newHashSet();
        for (Entry entry : entries) {
            hosts.add(entry.getAgent());
        }
        return hosts;
    }

    public DeploymentPlanBuilder forEnvironment(final Environment environment) {
        if (builderStack.isEmpty()) {
            throw new IllegalStateException("Can't set environment outside of a group.");
        } else {
            builderStack.peekLast().environment = environment;
        }
        return this;
    }

}
