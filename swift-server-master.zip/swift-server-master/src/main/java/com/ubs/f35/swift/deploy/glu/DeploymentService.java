package com.ubs.f35.swift.deploy.glu;

import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.google.common.base.Function;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimaps;
import com.google.common.collect.SetMultimap;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;
import com.ubs.f35.swift.dao.DeploymentDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.action.Action;
import com.ubs.f35.swift.deploy.glu.action.BaseAction;
import com.ubs.f35.swift.deploy.glu.action.BaseGroupedAction;
import com.ubs.f35.swift.deploy.glu.action.TransitionAction;
import com.ubs.f35.swift.deploy.glu.plan.BaseActionVisitor;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlan;
import com.ubs.f35.swift.deploy.glu.state.Transition.TransitionStep;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.model.ArtifactInstanceId;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.security.Permission;
import com.ubs.f35.swift.service.ArtifactConfigurationService;
import com.ubs.f35.swift.service.ArtifactConfigurationService.EnvironmentEntryPair;

public class DeploymentService {
    private static final Logger LOG = LoggerFactory.getLogger(DeploymentService.class);

    private DeploymentDao deploymentDao;
    private AuthorisationController authorisationController;
    private ArtifactConfigurationService artifactConfigurationService;
    private ArtifactDeploymentHistoryService artifactDeploymentHistoryService;

    public Deployment loadDeployment(final UUID deploymentId) {
        final Deployment deployment = deploymentDao.loadDeployment(deploymentId);
        if (deployment == null) {
            LOG.warn("Could not find deployment plan with id {}", deploymentId);
            throw new IllegalStateException("Deployment plan could not be found.");
        }
        return deployment;
    }

    /**
     * Loads a deployment and ensures the current user has the correct permissions to deploy it.
     * 
     * @param deploymentId
     * @return
     */
    public Deployment loadDeploymentToDeploy(final UUID deploymentId, final boolean expireIfNotFresh) {
        final Deployment deployment = loadDeployment(deploymentId);

        if (deployment.getDeploymentStatus() != DeploymentStatus.PLAN
                && deployment.getDeploymentStatus() != DeploymentStatus.EXECUTING) {
            throw new IllegalStateException("Deployment plan has already been executed. Status is "
                    + deployment.getDeploymentStatus());
        }

        if (expireIfNotFresh) {
            DateTime createdTime = new DateTime(deployment.getCreatedTime());
            if (createdTime.isBefore(DateTime.now().minusMinutes(5))) {
                throw new IllegalStateException("Deployment plan has expired. Please regenerate the deployment plan.");
            }
            if (deployment.getDeploymentStatus() != DeploymentStatus.PLAN) {
                throw new IllegalStateException("Deployment plan is already executing.");
            }
        }

        // Ensure the user is entitled to perform all actions in the plan, even those which are not selected. Have
        // decided to go the safe path and ensure a user can't perform any part of a release unless they can do the lot.
        // This can be relaxed if required, but better to start secure.
        AffectedEntitiesActionVisitor affectedVisitor = new AffectedEntitiesActionVisitor();
        affectedVisitor.visitActions(deployment.getDeploymentPlan().getActions());

        for (Environment env : affectedVisitor.allHosts.keySet()) {
            authorisationController.checkEnvironmentAccess(env);
            authorisationController.checkAccess(env,
                    Lists.newArrayList(affectedVisitor.allHosts.get(env)),
                    Lists.newArrayList(affectedVisitor.allArtifacts.get(env)),
                    Permission.ManageProcesses);
        }

        return deployment;
    }

    public SetMultimap<Environment, NexusArtifact> updateSelectedPlanItems(final Deployment deployment,
            final List<String> execute) {
        UUID deploymentId = deployment.getId();
        LOG.debug("Updating deployment plan {} to reflect selected actions {}", deploymentId, execute);
        DeploymentPlan plan = deployment.getDeploymentPlan();
        updateSelectedActions(plan.getActions(), execute);

        // Update the deployment plan (the plan is not a hibernate persistent object as it's stored as a DB clob)
        deployment.setDeploymentPlan(plan);

        // Remove any environments from the deployment plan which do not have any plan items included
        SetMultimap<Environment, NexusArtifact> selectedArtifacts = getSelectedArtifacts(deployment);
        Iterator<EnvDeployment> envIterator = deployment.getEnvDeployments().iterator();
        while (envIterator.hasNext()) {
            EnvDeployment envDeployment = envIterator.next();
            if (selectedArtifacts.get(envDeployment.getEnvironment()).isEmpty()) {
                envIterator.remove();
            }
        }

        createArtifactDeploymentHistory(deployment);

        return selectedArtifacts;
    }

    public void createArtifactDeploymentHistory(final Deployment deployment) {
        SelectedEntriesActionVisitor selectedEntriesVisitor = getSelectedEntries(deployment);
        artifactDeploymentHistoryService.updateDeploymentWithArtifactHistory(deployment,
                selectedEntriesVisitor.selectedEntries, selectedEntriesVisitor.entryTransitions);
    }

    /**
     * Returns the unique set of artifacts which have been selected for deployment.
     * 
     * @param deployment
     * @return
     */
    @Transactional(readOnly = true)
    public SetMultimap<Environment, NexusArtifact> getSelectedArtifacts(final Deployment deployment) {
        SelectedEntriesActionVisitor selectedEntries = getSelectedEntries(deployment);

        return HashMultimap.create(Multimaps.transformValues(selectedEntries.selectedEntries,
                new Function<Entry, NexusArtifact>() {
                    @Override
                    public NexusArtifact apply(final Entry entry) {
                        return new NexusArtifact(entry.getGroupId(), entry.getArtifactId());
                    }
                }));
    }

    public List<Deployment> getRunningDeployments(final String organisation) {
        return deploymentDao.getRunningDeployments(organisation);
    }

    private SelectedEntriesActionVisitor getSelectedEntries(final Deployment deployment) {
        SelectedEntriesActionVisitor visitor = new SelectedEntriesActionVisitor();
        visitor.visitActions(deployment.getDeploymentPlan().getActions());

        return visitor;
    }

    private class AffectedEntitiesActionVisitor extends EntryExposingActionVisitor {

        private final SetMultimap<Environment, String> allHosts = HashMultimap.create();
        private final SetMultimap<Environment, NexusArtifact> allArtifacts = HashMultimap.create();

        @Override
        void visitTransitionAction(final TransitionAction action, final Environment environment, final Entry entry) {
            allHosts.put(environment, entry.getAgent());
            allArtifacts.put(environment, new NexusArtifact(entry.getGroupId(), entry.getArtifactId()));
        }
    }

    private static class SelectedActionsVisitor extends BaseActionVisitor {
        private final List<String> execute;
        boolean anyChildrenIncluded = false;

        public SelectedActionsVisitor(final List<String> execute) {
            this.execute = execute;
        }

        @Override
        public void visitAction(final Action action) {
            if (action instanceof BaseAction) {
                visitBaseAction((BaseAction) action);
            }
        }

        private void visitBaseAction(final BaseAction action) {
            boolean childIncluded = false;
            if (action instanceof BaseGroupedAction) {
                childIncluded = updateSelectedActions(((BaseGroupedAction) action).getIncluded(), execute);
            }
            if (childIncluded || execute.contains(action.getId())) {
                action.setExecute(true);
                anyChildrenIncluded = true;
            } else {
                action.setExecute(false);
            }
        }
    }

    private static boolean updateSelectedActions(final List<Action> actions, final List<String> execute) {
        SelectedActionsVisitor selectedVisitor = new SelectedActionsVisitor(execute);
        selectedVisitor.visitActions(actions);
        return selectedVisitor.anyChildrenIncluded;
    }

    private class SelectedEntriesActionVisitor extends EntryExposingActionVisitor {

        private final SetMultimap<Environment, Entry> selectedEntries = HashMultimap.create();
        private final ListMultimap<Entry, TransitionStep> entryTransitions = ArrayListMultimap.create();

        private boolean isExecuted;

        @Override
        public void visitAction(final BaseGroupedAction action) {
            isExecuted = action.isExecute();
            super.visitAction(action);
        }

        @Override
        public void visitTransitionAction(final TransitionAction action, final Environment environment,
                final Entry entry) {
            if (isExecuted) {
                selectedEntries.put(environment, entry);
                entryTransitions.put(entry, TransitionStep.valueOf(action.getName()));
            }
        }

    }

    private abstract class EntryExposingActionVisitor extends BaseActionVisitor {
        @Override
        public void visitAction(final TransitionAction action) {
            ArtifactInstanceId id = action.getArtifactInstanceId();

            Assert.notNull(id, "Action without an ArtifactInstanceId");

            EnvironmentEntryPair entryDetails = artifactConfigurationService.resolveArtifactInstanceId(id);

            visitTransitionAction(action, entryDetails.getEnvironment(), entryDetails.getEntry());
        }

        abstract void visitTransitionAction(final TransitionAction action, Environment environment, Entry entry);
    }

    @Required
    public void setDeploymentDao(final DeploymentDao deploymentDao) {
        this.deploymentDao = deploymentDao;
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }

    @Required
    public void setArtifactDeploymentHistoryService(
            final ArtifactDeploymentHistoryService artifactDeploymentHistoryService) {
        this.artifactDeploymentHistoryService = artifactDeploymentHistoryService;
    }

}
