package com.ubs.f35.swift.model;

import java.util.List;

import com.google.common.base.Objects;
import com.google.common.collect.Lists;

public class State {
    private StateLevel state;
    private String status;
    private final List<String> statusInfos;
    private long stateLastModified;

    public State(final StateLevel state, final String status, final String statusInfo) {
        this(state, status, Lists.newArrayList(statusInfo));
    }

    public State(final StateLevel state, final String status, final List<String> statusInfos) {
        this.state = state;
        this.status = status;
        this.statusInfos = statusInfos;
    }

    public StateLevel getState() {
        return state;
    }

    public String getStatus() {
        return status;
    }

    public List<String> getStatusInfos() {
        return statusInfos;
    }

    public long getStateLastModified() {
        return stateLastModified;
    }

    public void setState(final StateLevel state) {
        this.state = state;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public void setStateLastModified(final long stateLastModified) {
        this.stateLastModified = stateLastModified;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(state, status, statusInfos);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof State) {
            State that = (State) object;
            return Objects.equal(this.state, that.state)
                    && Objects.equal(this.status, that.status)
                    && Objects.equal(this.statusInfos, that.statusInfos)
                    && Objects.equal(this.stateLastModified, that.stateLastModified);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("state", state)
                .add("status", status)
                .add("statusInfos", statusInfos)
                .add("stateLastModified", stateLastModified)
                .toString();
    }

    /**
     * The states a process may be in. These are flagged as RED, AMBER, GREEN on the client.
     */
    public enum StateLevel {
        ERROR, WARNING, OK
    }

}
