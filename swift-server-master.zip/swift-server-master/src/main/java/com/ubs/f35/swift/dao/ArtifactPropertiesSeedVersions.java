package com.ubs.f35.swift.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Environment;

/**
 * Each set of artifact properties saved using Swift is associated with a seed version which indicates which previous
 * artifact version of properties was used to seed the values for the new version. This allows the client to show
 * differences clearly between one version and the next.
 * 
 * @author levyjo
 * 
 */
@Entity
@Table(name = "PROPERTIES_SEED_VERSIONS")
public class ArtifactPropertiesSeedVersions implements Serializable {

    private static final long serialVersionUID = 344052199756390793L;

    @Id
    @OneToOne
    @JoinColumn(name = "artifact_id", referencedColumnName = "id")
    private Artifact artifact;

    @Id
    @ManyToOne(fetch = FetchType.EAGER)
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private Environment environment;

    @Column(name = "seed_version")
    private String seedVersion;

    public ArtifactPropertiesSeedVersions() {

    }

    public ArtifactPropertiesSeedVersions(final Artifact artifact, final Environment environment,
            final String seedVersion) {
        this.artifact = artifact;
        this.environment = environment;
        this.seedVersion = seedVersion;
    }

    public Artifact getArtifact() {
        return artifact;
    }

    public void setArtifact(final Artifact artifact) {
        this.artifact = artifact;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }

    public String getSeedVersion() {
        return seedVersion;
    }

    public void setSeedVersion(final String seedVersion) {
        this.seedVersion = seedVersion;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(artifact, environment, seedVersion);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ArtifactPropertiesSeedVersions) {
            ArtifactPropertiesSeedVersions that = (ArtifactPropertiesSeedVersions) object;
            return Objects.equal(this.artifact, that.artifact)
                    && Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.seedVersion, that.seedVersion);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("artifact", artifact)
                .add("environment", environment)
                .add("seedVersion", seedVersion)
                .toString();
    }

}
