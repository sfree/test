package com.ubs.f35.swift.properties.model;

import static com.ubs.f35.swift.util.ErrorUtils.buildErrorLink;

import com.ubs.f35.swift.dao.Artifact;

public class PropertyKeysExtractionException extends RuntimeException {

    public PropertyKeysExtractionException(final Artifact artifact, final Throwable throwable) {
        super(getArtifactMessage(artifact) + ": " + throwable.getMessage(), throwable);
    }

    public PropertyKeysExtractionException(final String message, final Artifact artifact) {
        super(getArtifactMessage(artifact) + ": " + message);
    }

    public static String getArtifactMessage(final Artifact artifact) {
        return "Unable to discover property keys for artifact " + artifact.getArtifactId() + ":"
                + artifact.getVersion();
    }

    // TODO: devise a better way of passing client-side links as part of exceptions
    public static String getArtifactConfigLink(final String organistation, final Artifact artifact) {
        return buildErrorLink(
                "/swift/" + organistation + "/config/artifact/"
                        + artifact.getGroupId() + "/" + artifact.getArtifactId(), "artifact configuration");
    }

}
