package com.ubs.f35.swift.model;

import java.util.List;
import java.util.UUID;

public class ManualDeploymentRequest implements ReleaseDeploymentConfirmationMessage {
    private UUID planId;
    private List<String> execute;
    private String confirmedReleaseId;

    public UUID getPlanId() {
        return planId;
    }

    public void setPlanId(final UUID planId) {
        this.planId = planId;
    }

    public List<String> getExecute() {
        return execute;
    }

    public void setExecute(final List<String> execute) {
        this.execute = execute;
    }

    @Override
    public String getConfirmedReleaseId() {
        return confirmedReleaseId;
    }

    public void setConfirmedReleaseId(final String confirmedReleaseId) {
        this.confirmedReleaseId = confirmedReleaseId;
    }
}
