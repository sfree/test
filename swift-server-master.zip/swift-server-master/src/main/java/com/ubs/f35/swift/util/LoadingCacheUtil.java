package com.ubs.f35.swift.util;

import com.google.common.cache.LoadingCache;
import com.google.common.util.concurrent.UncheckedExecutionException;

public class LoadingCacheUtil {
    private LoadingCacheUtil() {
    }

    /**
     * Utility method to get a cache value from a guava LoadingCache and propogate any RuntimeException raised directly,
     * rather than the exception guava wraps it in.
     * 
     * @param cache
     * @param key
     * @return
     */
    public static <K, V> V getUnchecked(final LoadingCache<K, V> cache, final K key) {
        try {
            return cache.getUnchecked(key);
        } catch (UncheckedExecutionException e) {
            if (e.getCause() instanceof RuntimeException) {
                throw (RuntimeException) e.getCause();
            } else {
                throw e;
            }
        }
    }
}
