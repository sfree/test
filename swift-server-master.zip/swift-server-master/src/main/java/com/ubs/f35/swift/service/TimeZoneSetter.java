package com.ubs.f35.swift.service;

import java.util.TimeZone;

import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Ensures the app runs with UTC time zone. Should occur before messing with the DB where all dates are stored in UTC
 * without a timezone.
 * 
 * @author stephelu
 * 
 */
public class TimeZoneSetter {
    private static final Logger LOG = LoggerFactory.getLogger(TimeZoneSetter.class);

    public TimeZoneSetter() {
        LOG.info("Setting default timezone to UTC");
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        DateTimeZone.setDefault(DateTimeZone.UTC);
        LOG.info("Default timezone is now {}", TimeZone.getDefault());
    }
}
