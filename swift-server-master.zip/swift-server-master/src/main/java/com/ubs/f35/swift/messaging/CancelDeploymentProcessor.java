package com.ubs.f35.swift.messaging;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.ubs.f35.core.AuthenticationPrincipal;
import com.ubs.f35.messaging.MessageHandle;
import com.ubs.f35.messaging.MessageProcessor;
import com.ubs.f35.swift.deploy.glu.DeploymentExecutor;

/**
 * A deployment is only executed on a single swift-server host. The request to cancel that deployment using the rest API
 * may be handled by a different server. A message is broadcast to all nodes requesting the deployment be cancelled.
 * Only the node which is responsible for the deployment will process that request successfully. The caller is
 * responsible for timing out if no node sends a response.
 */
public class CancelDeploymentProcessor implements MessageProcessor<String> {
    private static final Logger LOG = LoggerFactory.getLogger(CancelDeploymentProcessor.class);
    private DeploymentExecutor deploymentExecutor;

    @Override
    public void invoke(final AuthenticationPrincipal principal, final MessageHandle<String> handle, final Object message) {
        CancelDeploymentMessage cancelMessage = (CancelDeploymentMessage) message;
        boolean cancelled = deploymentExecutor.cancelDeployment(UUID.fromString(cancelMessage.getDeploymentId()));

        if (cancelled) {
            handle.onMessage("Deployment cancelled");
            LOG.info("Deployment {} was cancelled on this swift instance", cancelMessage.getDeploymentId());
        } else {
            LOG.info("Deployment {} was not running on this swift instance", cancelMessage.getDeploymentId());
        }

    }

    @Required
    public void setDeploymentExecutor(final DeploymentExecutor deploymentExecutor) {
        this.deploymentExecutor = deploymentExecutor;
    }
}
