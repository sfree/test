package com.ubs.f35.swift.config.model;

public class CommandBuilderConfig {
    private String defaultScriptsDir = "com.ubs.f35.swift/swift-scripts";
    private String baseInstallDir = "/sbclocal/apps/f35/install";
    private String defaultSymlink;

    public String getDefaultScriptsDir() {
        return defaultScriptsDir;
    }

    public void setDefaultScriptsDir(final String defaultScriptsDir) {
        this.defaultScriptsDir = defaultScriptsDir;
    }

    public String getBaseInstallDir() {
        return baseInstallDir;
    }

    public void setBaseInstallDir(final String baseInstallDir) {
        this.baseInstallDir = baseInstallDir;
    }

    public String getDefaultSymlink() {
        return defaultSymlink;
    }

    public void setDefaultSymlink(final String defaultSymlink) {
        this.defaultSymlink = defaultSymlink;
    }

}
