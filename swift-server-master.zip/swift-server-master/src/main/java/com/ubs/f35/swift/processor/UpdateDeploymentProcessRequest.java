package com.ubs.f35.swift.processor;

import com.ubs.f35.swift.dao.model.DeploymentProcess;
import com.ubs.f35.swift.deploy.template.model.DeploymentTemplate;

public class UpdateDeploymentProcessRequest {
    private DeploymentProcess deploymentProcess;
    private DeploymentTemplate deploymentTemplate;

    public DeploymentProcess getDeploymentProcess() {
        return deploymentProcess;
    }

    public void setDeploymentProcess(final DeploymentProcess deploymentProcess) {
        this.deploymentProcess = deploymentProcess;
    }

    public DeploymentTemplate getDeploymentTemplate() {
        return deploymentTemplate;
    }

    public void setDeploymentTemplate(final DeploymentTemplate deploymentTemplate) {
        this.deploymentTemplate = deploymentTemplate;
    }

}
