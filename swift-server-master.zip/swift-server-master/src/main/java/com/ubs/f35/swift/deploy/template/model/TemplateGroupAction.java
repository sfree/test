package com.ubs.f35.swift.deploy.template.model;

import java.util.List;

import com.google.common.base.Objects;
import com.google.common.collect.Lists;

public class TemplateGroupAction implements TemplateAction {
    private Mode mode;
    private List<TemplateAction> actions = Lists.newArrayList();

    public Mode getMode() {
        return mode;
    }

    public void setMode(final Mode mode) {
        this.mode = mode;
    }

    public List<TemplateAction> getActions() {
        return actions;
    }

    public void setActions(final List<TemplateAction> actions) {
        this.actions = actions;
    }

    public enum Mode {
        SEQUENTIAL, PARALLEL
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("mode", mode)
                .add("actions", actions)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(mode, actions);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof TemplateGroupAction) {
            TemplateGroupAction that = (TemplateGroupAction) object;
            return Objects.equal(this.mode, that.mode)
                    && Objects.equal(this.actions, that.actions);
        }
        return false;
    }

}
