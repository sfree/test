package com.ubs.f35.swift.service;

import java.io.IOException;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.google.common.annotations.VisibleForTesting;
import com.ubs.f35.swift.config.GluScriptFinder;

/**
 * Upgrades glu agents using the command execution service.
 * <p>
 * Expects swift-scripts to be deployed and linked in the standard location using envget / envlink
 * <p>
 * It’s also worth pointing out that glu supports upgrading an agent already, but it doesn’t fit into the model of how
 * we deploy with envget / envlink etc.
 * 
 * http://linkedin.github.com/glu/docs/latest/html/agent.html#auto-upgrade
 */
@ManagedResource
public class SwiftServerGluScriptDeployer extends AbstractJmxProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(SwiftServerGluScriptDeployer.class);

    private GluScriptFinder gluScriptFinder;
    private ProcessExecutor processExecutor = new ProcessExecutor();

    @ManagedOperation
    @ManagedOperationParameters(value = {
            @ManagedOperationParameter(name = "group", description = "group id of the script package"),
            @ManagedOperationParameter(name = "artfiact", description = "artifact id of the script package"),
            @ManagedOperationParameter(name = "version", description = "version of the script package") })
    public String deployScripts(final String group, final String artfiact, final String version) {
        return executeOperation(new Callable<String>() {
            @Override
            public String call() throws Exception {
                return deployScriptsInternal(group, artfiact, version);
            }
        });
    }

    private String deployScriptsInternal(final String group, final String artfiact, final String version)
            throws InterruptedException, IOException {

        String deployCommand = "envget " + group + " " + artfiact + " " + version;

        LOG.info("Deploying scripts to swift server with command {}", deployCommand);

        processExecutor.executeProcess("envget", group, artfiact, version);

        gluScriptFinder.scanScripts();

        return "Scripts deployed to THIS swift server instance";
    }

    @Required
    public void setGluScriptFinder(final GluScriptFinder gluScriptFinder) {
        this.gluScriptFinder = gluScriptFinder;
    }

    @VisibleForTesting
    void setProcessExecutor(final ProcessExecutor processExecutor) {
        this.processExecutor = processExecutor;
    }
}
