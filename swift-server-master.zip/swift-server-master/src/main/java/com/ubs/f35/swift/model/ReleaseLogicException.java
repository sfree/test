package com.ubs.f35.swift.model;

/**
 * Exception throw which could be resolved by fixing a business condition.
 * 
 * @author stephelu
 * 
 */
public class ReleaseLogicException extends RuntimeException {

    public ReleaseLogicException(final String message) {
        super(message);
    }

}
