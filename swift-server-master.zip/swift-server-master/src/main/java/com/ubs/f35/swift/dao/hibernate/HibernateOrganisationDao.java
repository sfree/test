package com.ubs.f35.swift.dao.hibernate;

import java.util.List;

import org.hibernate.criterion.Order;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.swift.dao.OrganisationDao;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.model.Organisation;

public class HibernateOrganisationDao extends HibernateDaoSupport implements OrganisationDao {
    private static final Logger LOG = LoggerFactory.getLogger(HibernateOrganisationDao.class);

    @SuppressWarnings("unchecked")
    @Override
    public List<Organisation> loadAll() {
        return getSession().createCriteria(Organisation.class).addOrder(Order.asc("name")).list();
    }

    @Override
    public Organisation load(final String organisationName) {
        return (Organisation) getSession().bySimpleNaturalId(Organisation.class).load(organisationName);
    }

    @Override
    public void save(final Organisation organisation) {
        getSession().save(organisation);
    }
}
