package com.ubs.f35.swift.deploy.validator;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Iterables;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlanBuilder;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlanStrategy;
import com.ubs.f35.swift.deploy.glu.plan.Warning;
import com.ubs.f35.swift.deploy.glu.rest.ProcessDetails;
import com.ubs.f35.swift.deploy.glu.state.GluState;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.service.RuntimeArtifactDependencyExplorer;

public class DeploymentArtifactDependencyValidator implements DeploymentPlanValidator {
    private static final Logger LOG = LoggerFactory.getLogger(DeploymentArtifactDependencyValidator.class);

    static final Warning DEPLOYMENT_HAS_DEPENDENCIES = new Warning(Warning.Code.DeploymentHasDependencies,
            "Artifacts in deployment have dependencies on artifacts which are not currently running");

    static final Warning DEPLOYMENT_BREAKS_DEPENDENCIES = new Warning(Warning.Code.DeploymentBreaksDependencies,
            "Running artifacts are dependant on artifacts that will be stopped by this deployment");

    private RuntimeArtifactDependencyExplorer runtimeArtifactDependencyExplorer;

    @Override
    public void validate(final DeploymentPlanBuilder builder, final Environment environment,
            final DeploymentAction deploymentAction, final DeploymentPlanStrategy strategy) {
        // Don't validate that dependencies are affected if they will be included in the plan.
        if (!strategy.isIncludeDependencies()) {
            final Set<NexusArtifact> deploymentArtifacts = getDeploymentArtifacts(builder.getEntries());

            // if the action is a start warn if any dependencies are down.
            if (deploymentAction == DeploymentAction.Start) {
                Map<NexusArtifact, List<ProcessDetails>> dependencyState = runtimeArtifactDependencyExplorer
                        .getArtifactDependenciesAndStatus(environment, deploymentArtifacts);
                if (anyDependencyMatches(dependencyState, Predicates.not(IsRunningPredicate.INSTANCE))) {
                    builder.addWarning(DEPLOYMENT_HAS_DEPENDENCIES);
                }
            } else if (deploymentAction == DeploymentAction.Stop || deploymentAction == DeploymentAction.Undeploy) {
                Map<NexusArtifact, List<ProcessDetails>> dependencyState = runtimeArtifactDependencyExplorer
                        .getDependantArtifactsAndStatus(environment, deploymentArtifacts);
                if (anyDependencyMatches(dependencyState, IsRunningPredicate.INSTANCE)) {
                    builder.addWarning(DEPLOYMENT_BREAKS_DEPENDENCIES);
                }
            } else if (deploymentAction == DeploymentAction.Bounce || deploymentAction == DeploymentAction.Redeploy) {
                // Don't bother checking anything for these deployment actions as the processes shutdown and restart
                // again
                // sequentially so there should be no impact.
            } else {
                LOG.warn("Unexpected deployment action {}", deploymentAction);
            }
        }
    }

    private Set<NexusArtifact> getDeploymentArtifacts(final Set<Entry> entries) {
        Set<NexusArtifact> artifacts = Sets.newHashSet();
        for (Entry entry : entries) {
            artifacts.add(EntryToNexusArtifactConvertor.INSTANCE.apply(entry));
        }
        return artifacts;
    }

    private static boolean anyDependencyMatches(final Map<NexusArtifact, List<ProcessDetails>> dependencyState,
            final Predicate<ProcessDetails> predicate) {
        return Iterables.any(dependencyState.values(), new Predicate<List<ProcessDetails>>() {
            @Override
            public boolean apply(final List<ProcessDetails> input) {
                return Iterables.any(input, predicate);
            }
        });
    }

    private static class IsRunningPredicate implements Predicate<ProcessDetails> {
        static IsRunningPredicate INSTANCE = new IsRunningPredicate();

        @Override
        public boolean apply(final ProcessDetails input) {
            return input.getGluState() == GluState.running;
        }
    }

    public static class EntryToNexusArtifactConvertor implements Function<Entry, NexusArtifact> {
        public static final EntryToNexusArtifactConvertor INSTANCE = new EntryToNexusArtifactConvertor();

        @Override
        public NexusArtifact apply(final Entry entry) {
            return new NexusArtifact(entry.getGroupId(), entry.getArtifactId());
        }
    }

    @Required
    public void setRuntimeArtifactDependencyExplorer(
            final RuntimeArtifactDependencyExplorer runtimeArtifactDependencyExplorer) {
        this.runtimeArtifactDependencyExplorer = runtimeArtifactDependencyExplorer;
    }

}
