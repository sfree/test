package com.ubs.f35.swift.security;

import java.security.AccessControlException;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.collect.Maps;
import com.google.common.collect.Maps.EntryTransformer;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;

/**
 * Enforces SOD (segregation of duties) as ARP does not provide any functionality to ensure that one user can not
 * perform deployments to multiple different swift environments.
 * 
 * @author stephelu
 * 
 */
public class SODEnforcingUserGroupsLookup implements UserGroupsLookup {
    private UserGroupsLookup delegate;
    private Map<String, Set<String>> orgSodRights;

    @Override
    public List<String> findUserSwiftGroups(final String guid) {
        List<String> groups = delegate.findUserSwiftGroups(guid);

        for (Entry<String, Set<String>> orgSodRight : orgSodRights.entrySet()) {
            Set<String> sodGroups = Sets.intersection(Sets.newHashSet(groups), orgSodRight.getValue());

            if (sodGroups.size() > 1) {
                throw new AccessControlException("Segregation of duties requires that you may not have access to both "
                        + StringUtils.join(sodGroups, ", ") + " within " + orgSodRight.getKey()
                        + ". Please revoke access in "
                        + AuthorisationController.SWIFT_ARP_TUTORIAL_HTML);
            }
        }
        return groups;
    }

    @Required
    public void setDelegate(final UserGroupsLookup delegate) {
        this.delegate = delegate;
    }

    @Required
    public void setSodAccessRightsFactory(final OrganisationBeanFactory<List<String>> sodAccessRightsFactory) {
        sodAccessRightsFactory.registerUpdateListener(new Runnable() {
            @Override
            public void run() {
                orgSodRights = Maps.transformEntries(sodAccessRightsFactory.getAll(),
                        new EntryTransformer<String, List<String>, Set<String>>() {
                            @Override
                            public HashSet<String> transformEntry(final String org, final List<String> sodAccessRights) {
                                return Sets.newHashSet(sodAccessRights);
                            }
                        });
            }
        });
    }

}
