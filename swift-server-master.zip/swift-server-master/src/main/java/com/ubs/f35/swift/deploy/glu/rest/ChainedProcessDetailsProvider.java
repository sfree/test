package com.ubs.f35.swift.deploy.glu.rest;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.Assert;

import com.ubs.f35.swift.environment.model.glu.Entry;

/**
 * Attempts to provide details about a process from various sources. The process details from the first available source
 * will be returned. The intention being that faster / less reliable providers will be attempted first and slower more
 * reliable providers will be attempted second. This gives a nice balance between performance and resilience.
 * 
 * @author stephelu
 * 
 */
public class ChainedProcessDetailsProvider implements ProcessDetailsProvider {
    private static final Logger LOG = LoggerFactory.getLogger(ChainedProcessDetailsProvider.class);

    private List<ProcessDetailsProvider> processDetailsProviders;

    @Override
    public ProcessDetails getCurrentProcessState(final Entry entry) throws ProcessDetailsUnavailableException {
        RuntimeException lastException = null;
        for (ProcessDetailsProvider processDetailsProvider : processDetailsProviders) {
            try {
                return processDetailsProvider.getCurrentProcessState(entry);
            } catch (RuntimeException ex) {
                LOG.warn("Process details could not be retrieved from provider {} error is {}", processDetailsProvider,
                        ex.toString());
                lastException = ex;
            }
        }
        throw lastException;
    }

    @Required
    public void setProcessDetailsProviders(final List<ProcessDetailsProvider> processDetailsProviders) {
        Assert.notEmpty(processDetailsProviders, "Must provide at least one processDetailsProvider");
        this.processDetailsProviders = processDetailsProviders;
    }
}
