package com.ubs.f35.swift.config.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.google.common.base.Function;
import com.ubs.f35.swift.processor.ProcessorUtil;
import com.ubs.f35.swift.properties.PropertyKeysDiscoverer.Packaging;

public class OrganisationConfig {
    /**
     * ARP access right required to lock a release
     */
    private List<String> releaseLockDownAccessRights;
    /**
     * ARP access right required to create/modify a release
     */
    private List<String> releaseModifyAccessRights;
    /**
     * A list of glu scripts used by this organisation.
     */
    private List<GluScriptMetadata> gluScriptsConfig;
    /**
     * A list of access rights which are mutually exclusive for segregation of duties. Users may not have more than one
     * of any of these specified rights.
     */
    private List<String> sodAccessRights = Collections.emptyList();

    /**
     * For convenience, many organisations may use the same nexus instance.
     */
    private NexusConfig nexusConfig;

    /**
     * How the artifacts for this organisation are package. Used to know how to extract and discover property keys.
     */
    private Packaging artifactPackaging = Packaging.DIST_TAR_GZ;

    /**
     * Targeted deployments allow the user to deploy a release to a subset of artifact instances. This is disabled by
     * default as it's not practice we wish to encourage, but may be required by some teams which have multiple versions
     * of the same component running in one environment. It also helps prevent confusion by giving the end user one less
     * option to handle if it is not required.
     */
    private boolean enableTargetedDeployments = false;
    /**
     * A list of plugin classes for this organisation.
     */
    private List<String> plugins = Collections.emptyList();

    public List<String> getReleaseLockDownAccessRights() {
        return releaseLockDownAccessRights;
    }

    public void setReleaseLockDownAccessRights(final List<String> releaseLockDownAccessRights) {
        this.releaseLockDownAccessRights = releaseLockDownAccessRights;
    }

    /**
     * @deprecated Remains to support legacy organisation configurations.
     */
    @Deprecated
    public void setReleaseLockDownAccessRight(final String releaseLockDownAccessRight) {
        setReleaseLockDownAccessRights(Collections.singletonList(releaseLockDownAccessRight));
    }

    public List<String> getReleaseModifyAccessRights() {
        return releaseModifyAccessRights;
    }

    public void setReleaseModifyAccessRights(final List<String> releaseModifyAccessRights) {
        this.releaseModifyAccessRights = releaseModifyAccessRights;
    }

    /**
     * @deprecated Remains to support legacy organisation configurations.
     */
    @Deprecated
    public void setReleaseModifyAccessRight(final String releaseModifyAccessRight) {
        setReleaseModifyAccessRights(Collections.singletonList(releaseModifyAccessRight));
    }

    public void setGluScriptsConfig(final List<GluScriptMetadata> gluScriptsConfig) {
        this.gluScriptsConfig = gluScriptsConfig;
    }

    public List<GluScriptMetadata> getGluScriptsConfig() {
        return gluScriptsConfig;
    }

    /**
     * @deprecated legacy way to set glu scripts. Contains some one off migration logic.
     */
    @Deprecated
    public void setGluScripts(final List<String> gluScripts) {
        List<GluScriptMetadata> scriptsWithMetadata = ProcessorUtil.transform(gluScripts,
                new Function<String, GluScriptMetadata>() {
                    @Override
                    public GluScriptMetadata apply(final String input) {
                        String scriptName = input.toLowerCase();
                        String color;
                        String category;
                        boolean parallelDeploy = false;
                        List<String> tags = Arrays.asList("server");
                        if (scriptName.contains("server")) {
                            category = "Java";
                            color = "dimgray";
                        } else if (scriptName.contains("client")) {
                            category = "Web";
                            color = "chocolate";
                            parallelDeploy = true;
                            tags = Arrays.asList("client");
                        } else if (scriptName.contains("node")) {
                            category = "Node";
                            color = "#690";
                        } else {
                            category = "Infr";
                            color = "lightslategray";
                        }

                        GluScriptMetadata script = new GluScriptMetadata(input, category, color, parallelDeploy, tags);
                        return script;
                    }

                });

        setGluScriptsConfig(scriptsWithMetadata);
    }

    public NexusConfig getNexusConfig() {
        return nexusConfig;
    }

    public void setNexusConfig(final NexusConfig nexusConfig) {
        this.nexusConfig = nexusConfig;
    }

    public Packaging getArtifactPackaging() {
        return artifactPackaging;
    }

    public void setArtifactPackaging(final Packaging artifactPackaging) {
        this.artifactPackaging = artifactPackaging;
    }

    public List<String> getSodAccessRights() {
        return sodAccessRights;
    }

    public void setSodAccessRights(final List<String> sodAccessRights) {
        this.sodAccessRights = sodAccessRights;
    }

    public boolean isEnableTargetedDeployments() {
        return enableTargetedDeployments;
    }

    public void setEnableTargetedDeployments(final boolean enableTargetedDeployments) {
        this.enableTargetedDeployments = enableTargetedDeployments;
    }

    public List<String> getPlugins() {
        return plugins;
    }

    public void setPlugins(final List<String> plugins) {
        this.plugins = plugins;
    }
}
