package com.ubs.f35.swift.properties;

import com.ubs.f35.swift.dao.Artifact;

public interface PropertyKeysPrefetcher {

    void prefetchPropertyKeys(String organisation, Artifact artifact);

}
