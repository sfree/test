package com.ubs.f35.swift.server;

import java.security.AccessControlException;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.DefaultHandlerExceptionResolver;

import com.ubs.f35.swift.model.ReleaseLogicException;

public class SwiftExceptionResolver extends DefaultHandlerExceptionResolver {
    private static final Logger LOG = LoggerFactory.getLogger(SwiftExceptionResolver.class);

    private Properties dbContraintMappings;

    @Override
    protected ModelAndView doResolveException(final HttpServletRequest request, final HttpServletResponse response,
            final Object handler,
            Exception ex) {

        ex = translateException(ex);

        ModelAndView defaultHandling = super.doResolveException(request, response, handler, ex);
        if (defaultHandling != null) {
            return defaultHandling;
        }
        if (ex instanceof AccessControlException) {
            response.setStatus(HttpStatus.FORBIDDEN.value());
        } else {
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        }

        logException(ex);

        ClientError error = new ClientError(ex);

        ModelAndView mav = new ModelAndView();
        mav.addObject(error);

        return mav;
    }

    /**
     * Maps the exception before returning to the client.
     */
    private Exception translateException(final Exception ex) {
        if (ex instanceof ConstraintViolationException) {
            return mapDbConstraintViolation((ConstraintViolationException) ex);
        }
        return ex;
    }

    /**
     * Note that I decided to implement the exception translation here (rather than in the db calls where the exception
     * could occur) so that this concern is kept in only one place and user friendly error messages can be controlled
     * through a properties file easily.
     */
    private Exception mapDbConstraintViolation(final ConstraintViolationException ex) {
        String constraintName = ex.getConstraintName();
        // Converts a constraint name like 'SWIFTADMIN.UNIQUE_RELEASE_DEF' to 'UNIQUE_RELEASE_DEF'
        if (StringUtils.hasText(constraintName)) {
            int index = constraintName.indexOf('.');
            if (index != -1) {
                constraintName = constraintName.substring(index + 1);
            }
        }
        String friendlyError = dbContraintMappings.getProperty(constraintName);
        if (friendlyError != null) {
            return new IllegalArgumentException(friendlyError, ex);
        }
        return ex;
    }

    private void logException(final Exception ex) {
        if (shouldLogException(ex)) {
            LOG.error("Exception processing request", ex);
        } else {
            LOG.trace("Exception processing request {} : {}", ex.getClass().getSimpleName(), ex.getMessage());
        }
    }

    private boolean shouldLogException(final Exception ex) {
        // Don't log validation errors or business logic errors an error.
        return !(ex instanceof IllegalArgumentException
                || ex instanceof ReleaseLogicException
                || ex instanceof AccessControlException);
    }

    @Required
    public void setDbContraintMappings(final Properties dbContraintMappings) {
        this.dbContraintMappings = dbContraintMappings;
    }
}
