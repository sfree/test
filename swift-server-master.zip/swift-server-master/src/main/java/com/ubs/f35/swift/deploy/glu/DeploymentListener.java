package com.ubs.f35.swift.deploy.glu;

import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;
import com.ubs.f35.swift.deploy.glu.action.Action;

public interface DeploymentListener {
    void deploymentActionChanged(Action action);

    void deploymentComplete(DeploymentStatus status);
}
