package com.ubs.f35.swift.deploy.glu;

import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.SetMultimap;
import com.ubs.f35.swift.activity.ActivityFeedWriter;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;
import com.ubs.f35.swift.dao.Deployment.DeploymentType;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.client.rollback.RollbackRequest;
import com.ubs.f35.swift.deploy.glu.plan.Warning;
import com.ubs.f35.swift.model.JsonObjectMapper;
import com.ubs.f35.swift.model.ReleaseDeploymentConfirmationMessage;
import com.ubs.f35.swift.model.ReleaseLogicException;
import com.ubs.f35.swift.service.EnvironmentDefinitionService;

/**
 * Handles deployments of a release to an environment using glu.
 */
public class GluReleaseManager {
    private static final Logger LOG = LoggerFactory.getLogger(GluReleaseManager.class);
    private DeploymentExecutor deploymentExecutor;
    private EnvironmentDefinitionService environmentDefinitionService;
    private ActivityFeedWriter activityFeedWriter;
    private DeploymentService deploymentService;

    /**
     * Updates the environment configuration and deploys a release. Supports both release and rollback deployments.
     * 
     * @param deployment
     * @param deploymentListener
     */
    public void deployRelease(final Deployment deployment, final DeploymentListener deploymentListener) {
        SetMultimap<Environment, NexusArtifact> selectedArtifacts = deploymentService.getSelectedArtifacts(deployment);

        applyReleaseAndUpdateDeploymentEnvironments(deployment, selectedArtifacts);

        deploymentExecutor.executeDeployment(deployment, deploymentListener);
    }

    /**
     * Flags that a release deployment has been performed manually. The plan is still saved so that any warnings the
     * user may have acknowledged are audited. The plan also reflects which actions the user selected which determines
     * the artifacts whose configuration version was updated by the manual deployment. For all deployments, the
     * deployment record is still required to highlight the deployment to an environment was completed manually. For
     * release deployments, the rollback information can also be used to revert a deployment performed manually.
     * 
     * @param deployment
     * @param includedArtifacts
     */
    public void manualRelease(final Deployment deployment,
            final SetMultimap<Environment, NexusArtifact> includedArtifacts) {
        applyReleaseAndUpdateDeploymentEnvironments(deployment, includedArtifacts);

        deployment.setDeployTime(new Timestamp(System.currentTimeMillis()));
        deployment.setDeploymentStatus(DeploymentStatus.MANUAL);

        activityFeedWriter.deploy(deployment);
    }

    /**
     * A release to production requires confirmation of any deployment plan warnings flagged with
     * {@link Warning#isRequiresProductionConfirmation()}. The confirmation required is that the user enters the id of
     * the release.
     */
    public void verifyProductionWarningsAcknowledged(final Deployment deployment,
            final ReleaseDeploymentConfirmationMessage deploymentMessage) {
        verifyProductionWarningsAcknowledged(deployment.getReleaseId(), deployment.getDeploymentPlan().getWarnings(),
                deploymentMessage);
    }

    public void verifyProductionWarningsAcknowledged(final Integer releaseId, final List<Warning> deploymentWarnings,
            final ReleaseDeploymentConfirmationMessage deploymentMessage) {
        if (Iterables.tryFind(deploymentWarnings, new Predicate<Warning>() {
            @Override
            public boolean apply(final Warning input) {
                return input.isRequiresProductionConfirmation();
            }
        }).isPresent()) {
            LOG.info("Deployment of release {} requires production confirmation", releaseId);
            // requires confirmation
            if (!String.valueOf(releaseId).equals(deploymentMessage.getConfirmedReleaseId())) {
                throw new ReleaseLogicException("Deployment of release requires confirmation of warnings from user");
            }
        }
    }

    private void applyReleaseAndUpdateDeploymentEnvironments(final Deployment deployment,
            final SetMultimap<Environment, NexusArtifact> includedArtifacts) {

        Iterator<EnvDeployment> envDepsIter = deployment.getEnvDeployments().iterator();
        while (envDepsIter.hasNext()) {
            EnvDeployment envDeployment = envDepsIter.next();

            if (includedArtifacts.containsKey(envDeployment.getEnvironment())) {
                if (deployment.getDeploymentType() == DeploymentType.Release) {
                    applyRelease(deployment, includedArtifacts, envDeployment);
                } else if (deployment.getDeploymentType() == DeploymentType.Rollback) {
                    applyReleaseRollback(deployment, includedArtifacts, envDeployment);
                } else {
                    throw new IllegalStateException("Unexpected deployment type " + deployment.getDeploymentType());
                }

                envDeployment.setDeploymentStatus(DeploymentStatus.COMPLETED);
            } else {
                envDepsIter.remove();
            }
        }

    }

    private void applyReleaseRollback(final Deployment deployment,
            final SetMultimap<Environment, NexusArtifact> includedArtifacts,
            final EnvDeployment envDeployment) {
        String generationContext = deployment.getGenerationContext();

        RollbackRequest rollbackRequest = JsonObjectMapper.getInstance().readValue(generationContext,
                RollbackRequest.class);

        Environment environment = envDeployment.getEnvironment();
        // Only rollback those artifact selected on the deployment plan!
        environmentDefinitionService.applyRollback(rollbackRequest.getArtifacts(), includedArtifacts.get(environment),
                environment);
    }

    private void applyRelease(final Deployment deployment,
            final SetMultimap<Environment, NexusArtifact> includedArtifacts,
            final EnvDeployment envDeploy) {
        Environment environment = envDeploy.getEnvironment();

        List<Artifact> rollback = environmentDefinitionService.applyRelease(deployment.getReleaseId(),
                deployment.getReleaseRev(), includedArtifacts.get(environment), environment);

        envDeploy.setRollbackVersions(rollback);
    }

    @Required
    public void setActivityFeedWriter(final ActivityFeedWriter activityFeedWriter) {
        this.activityFeedWriter = activityFeedWriter;
    }

    @Required
    public void setEnvironmentDefinitionService(final EnvironmentDefinitionService environmentDefinitionService) {
        this.environmentDefinitionService = environmentDefinitionService;
    }

    @Required
    public void setDeploymentExecutor(final DeploymentExecutor deploymentExecutor) {
        this.deploymentExecutor = deploymentExecutor;
    }

    @Required
    public void setDeploymentService(final DeploymentService deploymentService) {
        this.deploymentService = deploymentService;
    }

}
