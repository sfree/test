package com.ubs.f35.swift.dao.hibernate;

import org.hibernate.Hibernate;
import org.hibernate.envers.RevisionType;

import com.ubs.f35.swift.dao.SwiftRevEntry;

public class AuditEntry<T> {
    private final T entity;
    private final SwiftRevEntry revision;
    private final RevisionType revisionType;

    public AuditEntry(final T entity, final SwiftRevEntry revision, final RevisionType revisionType) {
        // Cloning the revision entry as hibernate is passing a proxy which json marshalling does not like. I'll invest
        // more time fixing the marshalling once we know envers (and not cassandra auditing) is the way forward.
        SwiftRevEntry clone = revision.clone();

        this.entity = entity;
        this.revision = clone;
        this.revisionType = revisionType;

        Hibernate.initialize(revision);
    }

    public T getEntity() {
        return entity;
    }

    public SwiftRevEntry getRevision() {
        return revision;
    }

    public RevisionType getRevisionType() {
        return revisionType;
    }
}
