package com.ubs.f35.swift.service.glu;

import com.google.common.base.Predicate;
import com.ubs.f35.swift.environment.model.glu.Entry;

/**
 * Returns deployment model entries which match the mount point
 * 
 * @author stephelu
 * 
 */
public class EntryMatchesMountPointPredicate implements Predicate<Entry> {

    private final String mountPoint;

    public EntryMatchesMountPointPredicate(final String mountPoint) {
        this.mountPoint = mountPoint;
    }

    @Override
    public boolean apply(final Entry entry) {
        return mountPoint.equals(entry.getMountPoint());
    }

}
