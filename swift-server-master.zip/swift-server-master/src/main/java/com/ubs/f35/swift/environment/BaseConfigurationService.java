package com.ubs.f35.swift.environment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionOperations;

import com.ubs.f35.swift.dao.model.Configurable;
import com.ubs.f35.swift.model.JsonObjectMapper;
import com.ubs.f35.swift.model.JsonUnmarshallingException;

/**
 * Wires up environment specific configuration.
 * <p>
 * Note that this class is not unit tested. We don't verify that spring wiring xml has worked as expected, and just
 * because this has been migrated to java (because it didn't fit the traditional spring model) doesn't mean that it
 * should be unit tested.
 * 
 */
public abstract class BaseConfigurationService<T extends Configurable, C> implements InitializingBean {
    private final Logger LOG = LoggerFactory.getLogger(getClass());

    private TransactionOperations transactionTemplate;
    private final Class<C> configClass;

    public BaseConfigurationService(final Class<C> configClass) {
        this.configClass = configClass;
    }

    /**
     * @Transactional does not work on afterPropertiesSet. Work around
     */
    @Override
    public final void afterPropertiesSet() throws Exception {
        transactionTemplate.execute(new TransactionCallback<Void>() {
            @Override
            public Void doInTransaction(final TransactionStatus status) {
                try {
                    init();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                return null;
            }
        });
    }

    public void update(final T object) throws Exception {
        C config = loadConfig(object);

        if (config != null) {
            update(object, config);
        }
    }

    protected C loadConfig(final T object) {
        String configJson = object.getConfiguration();

        try {
            return JsonObjectMapper.getInstance().readValue(configJson, configClass);
        } catch (JsonUnmarshallingException e) {
            throw new JsonUnmarshallingException("Unable to load " + configClass.getSimpleName() + " for: "
                    + object, e);
        }
    }

    abstract void update(final T object, final C config) throws Exception;

    abstract void init() throws Exception;

    @Required
    public void setTransactionTemplate(final TransactionOperations transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }

}
