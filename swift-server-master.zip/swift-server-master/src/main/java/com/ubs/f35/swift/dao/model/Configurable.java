package com.ubs.f35.swift.dao.model;

public interface Configurable {
    String getConfiguration();

    void setConfiguration(String configuration);
}
