package com.ubs.f35.swift.dao.hibernate;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseWatchDao;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.model.ReleaseWatch;
import com.ubs.f35.swift.dao.model.ReleaseWatch.WatchType;

public class HibernateReleaseWatchDao extends HibernateDaoSupport implements ReleaseWatchDao {
    private static final Logger LOG = LoggerFactory.getLogger(HibernateReleaseWatchDao.class);

    @SuppressWarnings("unchecked")
    @Override
    public List<WatchType> loadWatches(final Integer releaseId, final String user) {
        return getSession()
                .createQuery("select watchType from ReleaseWatch where release.id = :releaseId and user = :user")
                .setInteger("releaseId", releaseId)
                .setString("user", user)
                .list();
    }

    @Override
    public void addWatch(final ReleaseDefinition releaseDefinition, final WatchType watchType, final String user) {
        getSession().save(releaseWatch(releaseDefinition, watchType, user));
    }

    @Override
    public void addWatch(final Integer releaseId, final WatchType watchType, final String user) {
        getSession().save(releaseWatch(releaseId, watchType, user));
    }

    @Override
    public void removeWatch(final Integer releaseId, final WatchType watchType, final String user) {
        getSession().delete(releaseWatch(releaseId, watchType, user));
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<String> loadWatchers(final Integer releaseId, final WatchType watchType) {
        return getSession()
                .createQuery("select user from ReleaseWatch where release.id = :releaseId and watchType = :watchType")
                .setInteger("releaseId", releaseId)
                .setString("watchType", watchType.name())
                .list();
    }

    private ReleaseWatch releaseWatch(final Integer releaseId, final WatchType watchType, final String user) {
        // no DB hit, just a proxy
        ReleaseDefinition releaseDefinition = (ReleaseDefinition) getSession().load(ReleaseDefinition.class, releaseId);

        return releaseWatch(releaseDefinition, watchType, user);
    }

    private ReleaseWatch releaseWatch(final ReleaseDefinition releaseDefinition, final WatchType watchType,
            final String user) {
        ReleaseWatch watch = new ReleaseWatch();
        watch.setRelease(releaseDefinition);
        watch.setUser(user);
        watch.setWatchType(watchType);
        return watch;
    }
}
