package com.ubs.f35.swift.dao.hibernate;

import java.util.Collections;
import java.util.List;

import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.SwiftGroupDao;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.SwiftGroup;
import com.ubs.f35.swift.security.Permission;
import com.ubs.f35.swift.util.HostNameFunction;

public class HibernateSwiftGroupDao extends
        HibernateAuditableEntityDao<String, SwiftGroup> implements SwiftGroupDao {

    private EnvironmentDao environmentDao;

    @Override
    public SwiftGroup save(final SwiftGroup group) {

        group.setHosts(mergeCollection(Host.class, group.getHosts(), HostNameFunction.INSTANCE));

        SwiftGroup updated = group;
        if (loadGroup(group.getName()) == null) {
            getSession().save(group);
        } else {
            updated = (SwiftGroup) getSession().merge(group);
        }
        getSession().flush();

        return updated;
    }

    @Override
    public SwiftGroup loadGroup(final String groupName) {
        return super.load(SwiftGroup.class, groupName);
    }

    @Transactional(readOnly = true)
    @Override
    public Multimap<String, String> findGroupsByHost(final Environment environment, final List<String> hostNames,
            final Permission permission) {
        return findGroupsByHost(Collections.singletonList(environment), hostNames,
                Collections.singletonList(permission.name()));
    }

    @Override
    public Multimap<String, String> findGroupsByHost(final List<Environment> environments,
            final List<String> hostNames,
            final List<String> permissions) {
        Multimap<String, String> uniqueGroups = HashMultimap.create(hostNames.size(), 2);

        List<Environment> persistentEnvs = environmentDao.loadEnvironments(environments);

        if (!hostNames.isEmpty()) {
            // TODO more optimal query available if environment id present.
            Query hostQuery = getSession()
                    .createQuery(
                            "select distinct g.name, h.hostname from SwiftGroup g join g.permissions p join g.hosts h join g.environments e where h.hostname IN (:hostNames) AND e IN (:environment) AND p IN (:permission)");
            hostQuery.setParameterList("environment", persistentEnvs);
            hostQuery.setParameterList("permission", permissions);
            hostQuery.setParameterList("hostNames", hostNames);
            List<Object[]> results = hostQuery.list();

            for (Object[] result : results) {
                uniqueGroups.put((String) result[1], (String) result[0]);
            }
        }

        return uniqueGroups;
    }

    @Transactional(readOnly = true)
    @Override
    public Multimap<NexusArtifact, String> findGroupsByArtifact(final Environment environment,
            final List<NexusArtifact> artifacts,
            final Permission permission) {
        return findGroupsByArtifact(Collections.singletonList(environment), artifacts,
                Collections.singletonList(permission.name()));
    }

    @Override
    public Multimap<NexusArtifact, String> findGroupsByArtifact(final List<Environment> environments,
            final List<NexusArtifact> artifacts,
            final List<String> permissions) {
        Multimap<NexusArtifact, String> uniqueGroups = HashMultimap.create(artifacts.size(), 2);

        List<Environment> persistentEnvs = environmentDao.loadEnvironments(environments);

        if (!artifacts.isEmpty()) {
            Query artifactQuery = getSession()
                    .createQuery(
                            "select distinct g.name, a from SwiftGroup g join g.permissions p join g.artifacts a join g.environments e where a IN (:artifacts) AND e IN (:environment) AND p IN (:permission)");
            artifactQuery.setParameterList("environment", persistentEnvs);
            artifactQuery.setParameterList("permission", permissions);
            artifactQuery.setParameterList("artifacts", artifacts);
            List<Object[]> results = artifactQuery.list();

            for (Object[] result : results) {
                uniqueGroups.put((NexusArtifact) result[1], (String) result[0]);
            }
        }

        return uniqueGroups;
    }

    @Override
    Class<SwiftGroup> getValueClass() {
        return SwiftGroup.class;
    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }
}
