package com.ubs.f35.swift.deploy.client.rollback;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.artifact.MavenVersionNumberComparator;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.deploy.glu.plan.Warning;

/**
 * This class is used to present the available artifact versions to the client in preparation for a release rollback.
 * 
 * @author levyjo
 * 
 */
public class RollbackPrep {

    private final ReleaseDefinition releaseDefinition;
    private final String environment;
    private final List<ArtifactVersionChooser> artifactVersions;
    private List<Warning> warnings;

    public RollbackPrep(final ReleaseDefinition releaseDefinition, final String environment) {
        this.releaseDefinition = releaseDefinition;
        this.environment = environment;
        artifactVersions = new ArrayList<RollbackPrep.ArtifactVersionChooser>();
    }

    public void addArtifactToChoose(final Artifact artifact, final String liveVersion,
            final List<Artifact> rollbackArtifacts) {
        List<String> rollbackVersions = Lists.newArrayListWithCapacity(rollbackArtifacts.size());
        for (Artifact a : rollbackArtifacts) {
            rollbackVersions.add(a.getVersion());
        }
        Collections.sort(rollbackVersions, new MavenVersionNumberComparator());
        artifactVersions.add(new ArtifactVersionChooser(artifact, liveVersion, rollbackVersions));
    }

    public ReleaseDefinition getReleaseDefinition() {
        return releaseDefinition;
    }

    public String getEnvironment() {
        return environment;
    }

    public List<ArtifactVersionChooser> getArtifactVersions() {
        return artifactVersions;
    }

    public List<Warning> getWarnings() {
        return warnings;
    }

    public void setWarnings(final List<Warning> warnings) {
        this.warnings = warnings;
    }

    static class ArtifactVersionChooser {

        final Artifact artifact;
        final String liveVersion;
        final List<String> rollbackVersions;

        public ArtifactVersionChooser(final Artifact artifact, final String liveVersion,
                final List<String> rollbackVersions) {
            this.artifact = artifact;
            this.liveVersion = liveVersion;
            this.rollbackVersions = rollbackVersions;
        }

        public Artifact getArtifact() {
            return artifact;
        }

        public String getLiveVersion() {
            return liveVersion;
        }

        public List<String> getRollbackVersions() {
            return rollbackVersions;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(artifact, liveVersion, rollbackVersions);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof ArtifactVersionChooser) {
                ArtifactVersionChooser that = (ArtifactVersionChooser) object;
                return Objects.equal(this.artifact, that.artifact)
                        && Objects.equal(this.liveVersion, that.liveVersion)
                        && Objects.equal(this.rollbackVersions, that.rollbackVersions);
            }
            return false;

        }

        @Override
        public String toString() {
            return "ArtifactVersionChooser [artifact=" + artifact + ", liveVersion=" + liveVersion
                    + ", rollbackVersions=" + rollbackVersions + "]";
        }

    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("releaseDefinition", releaseDefinition)
                .add("environment", environment)
                .add("artifactVersions", artifactVersions)
                .add("warnings", warnings)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(releaseDefinition, environment, artifactVersions);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof RollbackPrep) {
            RollbackPrep that = (RollbackPrep) object;
            return Objects.equal(this.releaseDefinition, that.releaseDefinition)
                    && Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.artifactVersions, that.artifactVersions)
                    && Objects.equal(this.warnings, that.warnings);
        }
        return false;
    }

}
