package com.ubs.f35.swift.deploy.glu;

public class DeploymentTimeoutException extends DeploymentException {

    public DeploymentTimeoutException(final String message) {
        super(message);
    }

}
