package com.ubs.f35.swift.activity.data;

import java.util.HashSet;
import java.util.Set;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.ubs.f35.swift.dao.Activity;
import com.ubs.f35.swift.dao.Activity.ActivityType;

/**
 * Data object format for an {@link Activity} of type {@link ActivityType#PROPERTY_DEFAULTS}
 * 
 * @author levyjo
 * 
 */
public class DefaultPropertiesActivityData implements ActivityData {

    private Set<String> propertiesAdded = new HashSet<String>();
    private Set<String> propertiesModified = new HashSet<String>();
    private Set<String> propertiesRemoved = new HashSet<String>();

    public DefaultPropertiesActivityData() {

    }

    public DefaultPropertiesActivityData(final Set<String> newProperties) {
        propertiesAdded = newProperties;
    }

    public DefaultPropertiesActivityData(final Set<String> newProperties,
            final Set<String> modifiedProperties, final Set<String> removedProperties) {
        propertiesAdded = newProperties;
        propertiesModified = modifiedProperties;
        propertiesRemoved = removedProperties;
    }

    public Set<String> getPropertiesAdded() {
        return propertiesAdded;
    }

    public void setPropertiesAdded(final Set<String> propertiesAdded) {
        this.propertiesAdded = propertiesAdded;
    }

    public Set<String> getPropertiesModified() {
        return propertiesModified;
    }

    public void setPropertiesModified(final Set<String> propertiesModified) {
        this.propertiesModified = propertiesModified;
    }

    public Set<String> getPropertiesRemoved() {
        return propertiesRemoved;
    }

    public void setPropertiesRemoved(final Set<String> propertiesRemoved) {
        this.propertiesRemoved = propertiesRemoved;
    }

    @Override
    public DefaultPropertiesActivityData merge(final ActivityData newDataI) {

        DefaultPropertiesActivityData newData = (DefaultPropertiesActivityData) newDataI;

        for (String s : newData.getPropertiesRemoved()) {
            if (!propertiesAdded.remove(s)) {
                propertiesRemoved.add(s);
            }
            propertiesModified.remove(s);
        }

        for (String s : newData.getPropertiesModified()) {
            if (!propertiesAdded.contains(s)) {
                propertiesModified.add(s);
            }
        }

        for (String s : newData.getPropertiesAdded()) {
            if (propertiesRemoved.remove(s)) {
                propertiesModified.add(s);
            } else {
                propertiesAdded.add(s);
            }
        }

        return this;

    }

    @JsonIgnore
    @Override
    public boolean isEmpty() {
        return propertiesAdded.isEmpty() && propertiesModified.isEmpty() && propertiesRemoved.isEmpty();
    }

    public static DefaultPropertiesActivityData modifyProperty(final String property) {
        DefaultPropertiesActivityData data = new DefaultPropertiesActivityData();
        data.propertiesModified.add(property);
        return data;
    }

    public static DefaultPropertiesActivityData removeProperty(final String property) {
        DefaultPropertiesActivityData data = new DefaultPropertiesActivityData();
        data.propertiesRemoved.add(property);
        return data;
    }

}
