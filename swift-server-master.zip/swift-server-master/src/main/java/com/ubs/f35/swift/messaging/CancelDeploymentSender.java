package com.ubs.f35.swift.messaging;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.common.transport.processor.blocking.BlockingRequestReplySenderProcessorAdaptor;
import com.ubs.f35.common.transport.processor.blocking.DefaultResponseStoringMessageHandle;
import com.ubs.f35.common.transport.processor.blocking.RequestTimeoutException;
import com.ubs.f35.core.AuthenticationPrincipal;
import com.ubs.f35.swift.model.ReleaseLogicException;
import com.ubs.f35.swift.security.UserConstants;

public class CancelDeploymentSender {
    private static final Logger LOG = LoggerFactory.getLogger(CancelDeploymentSender.class);

    private final BlockingRequestReplySenderProcessorAdaptor<String> messageProcessor;
    private final AuthenticationPrincipal authenticationPrincipal = UserConstants.SWIFT_PRINCIPAL;

    public CancelDeploymentSender(final BlockingRequestReplySenderProcessorAdaptor<String> messageProcessor) {
        this.messageProcessor = messageProcessor;
    }

    public void cancelDeployment(final UUID deploymentId) {
        CancelDeploymentMessage message = new CancelDeploymentMessage();
        message.setDeploymentId(deploymentId.toString());

        DefaultResponseStoringMessageHandle<String> handle = new DefaultResponseStoringMessageHandle<>();

        try {
            String response = messageProcessor.invoke(authenticationPrincipal, message, handle);
            LOG.info("Response from cancel request {}", response);
        } catch (RequestTimeoutException ex) {
            throw new ReleaseLogicException("No servers acknowledged request to cancel deployment");
        }
    }
}
