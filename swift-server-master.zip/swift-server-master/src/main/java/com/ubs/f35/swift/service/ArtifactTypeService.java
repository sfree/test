package com.ubs.f35.swift.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Required;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.client.model.ArtifactType;
import com.ubs.f35.swift.config.model.GluScriptMetadata;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.environment.model.glu.Script;

/**
 * Artifacts can be automatically grouped into logical types depending on the glu script used to deploy that artifact.
 * <p>
 * The artifact type is used for:
 * <ul>
 * <li>Presenting an icon beside the artifact so the user can quickly recognise what type of artifact it is.
 * <li>For displaying a summary of the types of artifacts in a release. This can be used to make a quick assessment of
 * the complexity of the release.
 * <li>For quick filtering on the status screen
 * </ul>
 * <p>
 * This service needs to be fast. It's called frequently.
 */
public class ArtifactTypeService {
    // Represents an artifact which has not yet been configured in any environment.
    public static final ArtifactType UNKNOWN = new ArtifactType("New", "grey");

    private EnvironmentDocumentStore environmentDocumentStore;
    private Map<ScriptMetadataKey, GluScriptMetadata> scriptMetadataMap;

    private volatile Set<Environment> environments;

    /**
     * The artifact may be deployed to many environments, in which case the glu script used will generally be the same
     * across all environments and a random instance will be used.
     */
    public ArtifactType getArtifactType(final NexusArtifact artifact) {
        ArtifactType artifactType = UNKNOWN;
        for (Environment environment : environments) {
            artifactType = getArtifactType(artifact, environment);
            if (artifactType != UNKNOWN) {
                break;
            }
        }
        return artifactType;
    }

    public ArtifactType getArtifactType(final NexusArtifact artifact, final Environment environment) {
        GluScriptMetadata scriptMetadata = getArtifactMetadata(artifact, environment);

        if (scriptMetadata != null) {
            return new ArtifactType(scriptMetadata.getCategory(), scriptMetadata.getColor());
        }
        return UNKNOWN;
    }

    public GluScriptMetadata getArtifactMetadata(final Script script, final Environment environment) {
        String scriptPackage = script.getPckage();

        return scriptMetadataMap.get(new ScriptMetadataKey(environment.getOrganisation().getName(),
                scriptPackage));
    }

    public GluScriptMetadata getArtifactMetadata(final NexusArtifact artifact, final String organisation) {
        GluScriptMetadata scriptMetadata = null;
        for (Environment environment : environments) {
            if (environment.getOrganisation().getName().equals(organisation)) {
                scriptMetadata = getArtifactMetadata(artifact, environment);
            }
            if (scriptMetadata != null) {
                break;
            }
        }
        return scriptMetadata;
    }

    private GluScriptMetadata getArtifactMetadata(final NexusArtifact artifact, final Environment environment) {
        GluScriptMetadata scriptMetadata = null;

        Collection<Entry> entries = environmentDocumentStore.filterEntriesByArtifact(environment, artifact);
        Entry entry = Iterables.getFirst(entries, null);

        if (entry != null) {
            scriptMetadata = getArtifactMetadata(entry.getScript(), environment);
        }
        return scriptMetadata;
    }

    private static class ScriptMetadataKey {
        private final String organisation;
        private final String scriptPackage;

        public ScriptMetadataKey(final String organisation, final String scriptPackage) {
            this.organisation = organisation;
            this.scriptPackage = scriptPackage;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(organisation, scriptPackage);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof ScriptMetadataKey) {
                ScriptMetadataKey that = (ScriptMetadataKey) object;
                return Objects.equal(this.organisation, that.organisation)
                        && Objects.equal(this.scriptPackage, that.scriptPackage);
            }
            return false;
        }

    }

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

    @Required
    public void setOrgScriptsMetadataMap(final OrganisationBeanFactory<List<GluScriptMetadata>> orgScriptsMetadataMap) {
        orgScriptsMetadataMap.registerUpdateListener(new Runnable() {
            @Override
            public void run() {
                Map<ScriptMetadataKey, GluScriptMetadata> updated = Maps.newHashMap();
                for (java.util.Map.Entry<String, List<GluScriptMetadata>> orgScripts : orgScriptsMetadataMap.getAll()
                        .entrySet()) {
                    String org = orgScripts.getKey();
                    for (GluScriptMetadata script : orgScripts.getValue()) {
                        String scriptPackage = script.getName();
                        updated.put(new ScriptMetadataKey(org, scriptPackage), script);
                    }
                }
                scriptMetadataMap = updated;
            }
        });
    }

    // TODO duplicates EnvDocStore
    @Required
    public void setOrgEnvironmentsMap(final OrganisationBeanFactory<List<String>> orgEnvironmentsMap) {
        orgEnvironmentsMap.registerUpdateListener(new Runnable() {
            @Override
            public void run() {
                Set<Environment> updatedEnvs = Sets.newHashSet();
                for (Map.Entry<String, List<String>> orgEnvs : orgEnvironmentsMap.getAll().entrySet()) {
                    for (String env : orgEnvs.getValue()) {
                        updatedEnvs.add(new Environment(env, orgEnvs.getKey()));
                    }
                }
                environments = updatedEnvs;
            }
        });
    }

}
