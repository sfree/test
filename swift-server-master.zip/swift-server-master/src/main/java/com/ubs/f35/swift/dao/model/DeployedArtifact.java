package com.ubs.f35.swift.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.google.common.base.Objects;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;

/** Links a deployment of an artifact instance on a specific host to deployment plan for later auditing and retrieval */
@Entity
@Table(name = "DEPLOYED_ARTIFACT")
public class DeployedArtifact implements Serializable {
    /**
     * Note that the key of DeployedArtifact doesn't reference {@link ArtifactConfig} so that the artifact config does
     * not have any foreign key references that would prevent it from being deleted. The alternative would have been to
     * have a deleted flag on the config.
     */
    @Id
    @Column(name = "GROUP_ID")
    private String groupId;
    @Id
    @Column(name = "ARTIFACT_ID")
    private String artifactId;
    @Id
    private String name;
    @Id
    @ManyToOne
    @JoinColumns({ @JoinColumn(name = "deployment_id", referencedColumnName = "deployment_id"),
            @JoinColumn(name = "environment_id", referencedColumnName = "environment_id") })
    private EnvDeployment envDeployment;
    @Id
    private String hostname;
    private String version;
    @Enumerated(EnumType.STRING)
    private DeploymentAction deploymentAction;
    private boolean versionChanged;

    public DeployedArtifact() {
    }

    public DeployedArtifact(final ArtifactConfig config, final EnvDeployment envDeploy, final String hostname) {
        this.groupId = config.getGroupId();
        this.artifactId = config.getArtifactId();
        this.name = config.getName();
        this.envDeployment = envDeploy;
        this.hostname = hostname;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(final String groupId) {
        this.groupId = groupId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(final String artifactId) {
        this.artifactId = artifactId;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getHostname() {
        return hostname;
    }

    public void setHostname(final String hostname) {
        this.hostname = hostname;
    }

    public boolean isVersionChanged() {
        return versionChanged;
    }

    public void setVersionChanged(final boolean versionChanged) {
        this.versionChanged = versionChanged;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(final String version) {
        this.version = version;
    }

    public DeploymentAction getDeploymentAction() {
        return deploymentAction;
    }

    public void setDeploymentAction(final DeploymentAction deploymentAction) {
        this.deploymentAction = deploymentAction;
    }

    public EnvDeployment getEnvDeployment() {
        return envDeployment;
    }

    public void setEnvDeployment(final EnvDeployment envDeployment) {
        this.envDeployment = envDeployment;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(groupId, artifactId, name, envDeployment, hostname, version,
                deploymentAction, versionChanged);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DeployedArtifact) {
            DeployedArtifact that = (DeployedArtifact) object;
            return Objects.equal(this.groupId, that.groupId)
                    && Objects.equal(this.artifactId, that.artifactId)
                    && Objects.equal(this.name, that.name)
                    && Objects.equal(this.envDeployment, that.envDeployment)
                    && Objects.equal(this.hostname, that.hostname)
                    && Objects.equal(this.version, that.version)
                    && Objects.equal(this.deploymentAction, that.deploymentAction)
                    && Objects.equal(this.versionChanged, that.versionChanged);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("groupId", groupId)
                .add("artifactId", artifactId)
                .add("name", name)
                .add("envDeployment", envDeployment)
                .add("hostname", hostname)
                .add("version", version)
                .add("deploymentAction", deploymentAction)
                .add("versionChanged", versionChanged)
                .toString();
    }

}
