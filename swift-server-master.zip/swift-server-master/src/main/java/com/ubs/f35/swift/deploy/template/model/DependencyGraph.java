package com.ubs.f35.swift.deploy.template.model;

import java.util.List;

import com.google.common.base.Objects;

public class DependencyGraph<T> {
    private final List<List<T>> graph;

    public DependencyGraph(final List<List<T>> graph) {
        this.graph = graph;
    }

    public void walkDependencies(final DependencyGraphWalkerCallback<T> callback) {
        for (int i = 0; i < graph.size() - 1; i++) {
            List<T> groupedItems = graph.get(i);

            WalkPosition position = i == graph.size() - 1 ? WalkPosition.ROOT : WalkPosition.TOWARDS_CHILDREN;
            callbackForTreeLevel(groupedItems, callback, position);
        }

        for (int i = graph.size() - 1; i >= 0; i--) {
            List<T> groupedItems = graph.get(i);

            WalkPosition position = i == graph.size() - 1 ? WalkPosition.ROOT : WalkPosition.TOWARDS_PARENTS;
            // All actions at the same level can be deployed in parallel as they have no interdependencies.
            callbackForTreeLevel(groupedItems, callback, position);
        }
    }

    private void callbackForTreeLevel(final List<T> groupedItems, final DependencyGraphWalkerCallback<T> callback,
            final WalkPosition position) {
        callback.appendActions(groupedItems, position);
    }

    public interface DependencyGraphWalkerCallback<T> {
        void appendActions(List<T> groupedItems, WalkPosition position);
    }

    public enum WalkPosition {
        TOWARDS_CHILDREN, ROOT, TOWARDS_PARENTS
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(graph);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DependencyGraph) {
            DependencyGraph<?> that = (DependencyGraph<?>) object;
            return Objects.equal(this.graph, that.graph);
        }
        return false;
    }

}
