package com.ubs.f35.swift.dao;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.util.Assert;

import com.google.common.base.Objects;

public class DailyReleaseStats {
    private final Date date;
    private final Long newReleases;

    public DailyReleaseStats(final Date date, final Long newReleases) {
        // hibernate needs the Date contructor, but needs to be a timestamp for the equals method.
        Assert.isInstanceOf(Timestamp.class, date);
        this.date = date;
        this.newReleases = newReleases;
    }

    public Date getDate() {
        return date;
    }

    public Long getNewReleases() {
        return newReleases;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(date, newReleases);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DailyReleaseStats) {
            DailyReleaseStats that = (DailyReleaseStats) object;
            return Objects.equal(this.date, that.date)
                    && Objects.equal(this.newReleases, that.newReleases);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("date", date)
                .add("newReleases", newReleases)
                .toString();
    }

}