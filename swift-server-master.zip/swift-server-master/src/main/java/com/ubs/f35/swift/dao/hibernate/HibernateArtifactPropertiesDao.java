package com.ubs.f35.swift.dao.hibernate;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.RevisionType;
import org.hibernate.envers.query.AuditEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.StringUtils;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.activity.ActivityFeedWriter;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ArtifactDao;
import com.ubs.f35.swift.dao.ArtifactPropertiesCount;
import com.ubs.f35.swift.dao.ArtifactPropertiesDao;
import com.ubs.f35.swift.dao.ArtifactPropertiesSeedVersions;
import com.ubs.f35.swift.dao.ArtifactProperty;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.SwiftRevEntry;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.model.ArtifactPropertyKeyHistory;
import com.ubs.f35.swift.processor.ProcessorUtil;
import com.ubs.f35.swift.properties.bulk.PropertyUpdate;
import com.ubs.f35.swift.properties.model.ArtifactProperties;
import com.ubs.f35.swift.properties.model.Property;
import com.ubs.f35.swift.properties.model.PropertyList;

/**
 * 
 * DAO for saving and retrieving artifact properties. <br>
 * Any properties saved in the Swift database should also be saved in ZooKeeper, but the Swift database is used as the
 * golden source of properties as ZooKeeper cannot guarantee persistence.
 * 
 * @author levyjo
 * 
 */
public class HibernateArtifactPropertiesDao extends HibernateDaoSupport implements ArtifactPropertiesDao {

    private static final Logger LOG = LoggerFactory.getLogger(HibernateArtifactPropertiesDao.class);

    private ArtifactDao artifactDao;
    private ActivityFeedWriter activityFeedWriter;

    @Override
    public PropertyList getProperties(final Artifact artifact, final Environment environment) {

        PropertyList result = new PropertyList();
        List<ArtifactProperty> artifactProperties = loadProperties(artifact, environment);

        if (artifactProperties != null) {
            for (ArtifactProperty ap : artifactProperties) {
                if (ap.getValue() == null) {
                    ap.setValue(""); // Oracle stores empty strings as null but we need empty strings for correct
                                     // comparisons with data returned from client
                }
                result.add(new Property(ap.getKey(), ap.getValue()));
            }
        }

        return result;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ArtifactPropertiesCount> loadSavedPropertiesCount(final List<Artifact> artifacts,
            final List<Environment> environments) {
        List<Artifact> artifactIds = ProcessorUtil.transform(artifacts, new Function<Artifact, Artifact>() {
            @Override
            public Artifact apply(final Artifact artifact) {
                return artifactDao.resolvePersistentArtifact(artifact);
            }
        });

        Query query = getSession()
                .createQuery(
                        "select new com.ubs.f35.swift.dao.ArtifactPropertiesCount(p.environment.id, p.artifact.id, count(*)) from ArtifactProperty p where p.artifact in :artifactId and p.environment in :env group by p.artifact.id, p.environment.id");
        query.setParameterList("artifactId", artifactIds);
        query.setParameterList("env", environments);

        return query.list();
    }

    @SuppressWarnings("unchecked")
    private List<ArtifactProperty> loadProperties(final Artifact artifact, final Environment environment) {

        Artifact persistentArtifact = artifactDao.resolveOrCreatePersistentArtifact(artifact);

        Query query = getSession().createQuery(
                "from ArtifactProperty where artifact.id = :artifactId and environment = :env order by key");
        query.setParameter("artifactId", persistentArtifact.getId());
        query.setParameter("env", environment);

        return query.list();

    }

    @Override
    public Property getProperty(final Artifact artifact, final Environment environment, final String key) {

        ArtifactProperty ap = loadProperty(artifact, environment, key);
        return new Property(ap.getKey(), ap.getValue());

    }

    private ArtifactProperty loadProperty(final Artifact artifact, final Environment environment, final String key) {

        Artifact persistentArtifact = artifactDao.resolveOrCreatePersistentArtifact(artifact);
        return loadExpected(ArtifactProperty.class, new ArtifactProperty(persistentArtifact, environment,
                key, null));

    }

    /**
     * Returns null if properties have never been saved for the given artifact.<br>
     * Returns an empty string if properties have been saved with no seed version.
     * 
     * @param artifact
     * @param environment
     * @return
     */
    @Override
    public String getSeedVersion(final Artifact artifact, final Environment environment) {

        Artifact persistentArtifact = artifactDao.resolveOrCreatePersistentArtifact(artifact);
        ArtifactPropertiesSeedVersions result = load(ArtifactPropertiesSeedVersions.class,
                new ArtifactPropertiesSeedVersions(persistentArtifact, environment, null));

        if (result != null) {
            String seed = result.getSeedVersion();
            if (seed == null) {
                return "";
            } else {
                return seed;
            }
        }

        return null;
    }

    @Override
    public void saveUpdates(final Artifact artifact, final Environment environment,
            final List<PropertyUpdate> propertyUpdates) {
        Artifact persistentArtifact = artifactDao.resolveOrCreatePersistentArtifact(artifact);
        for (PropertyUpdate update : propertyUpdates) {
            ArtifactProperty artifactProperty = new ArtifactProperty(persistentArtifact, environment, update.getKey(),
                    update.getValue());
            if (update.isRemoved()) {
                deleteProperty(artifactProperty);
            } else {
                getSession().saveOrUpdate(artifactProperty);
            }
        }
    }

    @Override
    public void saveProperties(final ArtifactProperties artifactProperties, final Environment environment) {
        Artifact persistentArtifact = artifactDao.resolveOrCreatePersistentArtifact(artifactProperties.getArtifact());

        saveSeedVersion(persistentArtifact, environment, artifactProperties.getSeedVersion());

        PropertyList previousProperties = getProperties(persistentArtifact, environment);
        PropertyList newProperties = artifactProperties.getProperties();

        if (!previousProperties.equals(newProperties)) {

            // Diffs for activity feed
            Set<String> addedProperties = new HashSet<String>();
            Set<String> modifiedProperties = new HashSet<String>();
            Set<String> removedProperties = new HashSet<String>();

            Map<String, String> previousPropsMap = previousProperties.toMap();
            Set<String> previousKeys = previousPropsMap.keySet();

            // Save new, update pre-existing
            for (Property property : newProperties) {
                ArtifactProperty artifactProperty = new ArtifactProperty(persistentArtifact, environment,
                        property.getKey(),
                        property.getValue());
                if (previousKeys.contains(property.getKey())) {
                    // Need to merge (not save or update) since the instances loaded in the Hibernate session
                    // are not the same as those passed in from the client.
                    getSession().merge(artifactProperty);
                    if (!property.getValue().equals(previousPropsMap.get(property.getKey()))) {
                        modifiedProperties.add(property.getKey());
                    }
                } else {
                    getSession().save(artifactProperty);
                    addedProperties.add(property.getKey());
                }
            }

            // remove deleted properties
            List<ArtifactProperty> previousArtifactProperties = loadProperties(persistentArtifact, environment);
            for (ArtifactProperty ap : previousArtifactProperties) {
                if (!newProperties.contains(new Property(ap.getKey(), ap.getValue()))) {
                    getSession().delete(ap);
                    removedProperties.add(ap.getKey());
                }
            }

            if (previousProperties.isEmpty()) {
                activityFeedWriter.createProperties(persistentArtifact, environment);
            } else {
                activityFeedWriter.modifyProperties(persistentArtifact, environment, addedProperties,
                        modifiedProperties, removedProperties);
            }
        }

    }

    private void saveSeedVersion(final Artifact artifact, final Environment environment, final String seedVersion) {
        if (getSeedVersion(artifact, environment) == null) {
            // Only save seed version the first time properties are saved for an artifact version.
            ArtifactPropertiesSeedVersions seed = new ArtifactPropertiesSeedVersions(artifact, environment,
                    seedVersion);
            getSession().save(seed);
        }
    }

    @Override
    public void saveProperty(final Artifact artifact, final Environment environment, final Property property) {
        Artifact persistentArtifact = artifactDao.resolveOrCreatePersistentArtifact(artifact);
        ArtifactProperty artifactProperty = new ArtifactProperty(persistentArtifact, environment,
                property.getKey(),
                property.getValue());
        saveProperty(artifactProperty);
        activityFeedWriter.modifyOrCreateProperty(persistentArtifact, environment, property.getKey());
    }

    private void saveProperty(final ArtifactProperty artifactProperty) {

        getSession().saveOrUpdate(artifactProperty);

    }

    @Override
    public void deleteProperty(final Artifact artifact, final Environment environment, final Property property) {

        Artifact persistentArtifact = artifactDao.resolvePersistentArtifact(artifact);
        ArtifactProperty artifactProperty = new ArtifactProperty(persistentArtifact, environment,
                property.getKey(),
                property.getValue());
        deleteProperty(artifactProperty);
        activityFeedWriter.removeProperty(persistentArtifact, environment, property.getKey());

    }

    private void deleteProperty(final ArtifactProperty artifactProperty) {

        getSession().delete(artifactProperty);

    }

    @SuppressWarnings("unchecked")
    @Override
    public List<AuditEntry<Property>> getAuditHistory(final Environment environment, final Artifact artifact,
            final PagingFilter daoFilter) {
        AuditReader reader = AuditReaderFactory.get(getSession());

        List<Object[]> auditHistory = reader.createQuery()
                .forRevisionsOfEntity(ArtifactProperty.class, ArtifactProperty.class.getName(), false, true)
                .addOrder(AuditEntity.revisionNumber().desc())
                .add(AuditEntity.property("id.artifact").eq(artifactDao.resolvePersistentArtifact(artifact)))
                .add(AuditEntity.property("id.environment").eq(environment))
                .setFirstResult(daoFilter.getStart())
                .setMaxResults(daoFilter.getRecords())
                .getResultList();

        LOG.debug("audit history {}", auditHistory);

        List<AuditEntry<Property>> auditEntries = Lists.newArrayListWithExpectedSize(auditHistory.size());
        for (Object[] audit : auditHistory) {
            ArtifactProperty daoModel = (ArtifactProperty) audit[0];
            Property property = new Property(daoModel.getKey(), daoModel.getValue());
            AuditEntry<Property> entry = new AuditEntry<Property>(property,
                    (SwiftRevEntry) audit[1], (RevisionType) audit[2]);

            auditEntries.add(entry);
        }
        return auditEntries;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ArtifactPropertyKeyHistory> getAuditHistory(final Environment environment,
            final NexusArtifact artifact, final String key, final PagingFilter daoFilter) {

        // TODO Some indexes may be required for this query to perform optimally. It's only audit data, so access
        // doesn't need to be lightning fast.
        Query query = getSession()
                .createQuery(
                        " from com.ubs.f35.swift.dao.ArtifactProperty_AUD pa, Artifact a, SwiftRevEntry r "
                                + "where pa.originalId.environment.id = :environmentId "
                                + "and a.groupId = :groupId and a.artifactId = :artifactId and pa.originalId.artifact = a "
                                + "and pa.originalId.key = :key and pa.originalId.REV = r order by pa.originalId.REV.timestamp desc")
                .setInteger("environmentId", environment.getId())
                .setString("artifactId", artifact.getArtifactId())
                .setString("groupId", artifact.getGroupId())
                .setString("key", key);

        setPagingFilters(daoFilter, query);

        List<Object[]> result = query.list();

        LOG.debug("Result {}", result);
        List<ArtifactPropertyKeyHistory> mapped = ProcessorUtil.transform(result,
                new Function<Object[], ArtifactPropertyKeyHistory>() {
                    @SuppressWarnings("rawtypes")
                    @Override
                    public ArtifactPropertyKeyHistory apply(final Object[] input) {
                        Map audit = (Map) input[0];
                        String value = (String) audit.get("value");
                        SwiftRevEntry revEntry = (SwiftRevEntry) input[2];
                        revEntry = revEntry.clone();

                        String version = ((Artifact) input[1]).getVersion();
                        return new ArtifactPropertyKeyHistory(revEntry, value, version);
                    }
                });
        LOG.debug("mapped {}", mapped);
        return mapped;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ArtifactProperty> getConfiguredArtifactsUsingProperty(final Environment environment, final String key,
            final String value) {
        // This query results in duplicate results (due to multiple configurations of one artifact). Kept for reference
        // Query query = getSession()
        // .createQuery(
        // "select ap from ArtifactConfig ac, ArtifactProperty ap join ap.artifact a where "
        // + "ap.environment.id = :environmentId and ap.key = :key "
        // + "and a.artifactId = ac.artifactId and a.groupId = ac.groupId and a.version = ac.artifactVersion "
        // + "and ac.environment = ap.environment")

        String searchKey = StringUtils.hasText(key) ? key.toLowerCase() : null;
        String searchValue = StringUtils.hasText(value) ? "%" + value.toLowerCase() + "%" : null;
        Query query = getSession()
                .createQuery(
                        "select ap from ArtifactProperty ap join ap.artifact a where "
                                + "ap.environment.id = :environmentId "
                                + "and (:key is null or lower(ap.key) = :key)"
                                + "and (:value is null or lower(ap.value) like :value)"
                                + "and exists (from ArtifactConfig ac where "
                                + "a.artifactId = ac.artifactId and a.groupId = ac.groupId and a.version = ac.artifactVersion "
                                + "and ac.environment = ap.environment)")
                .setInteger("environmentId", environment.getId())
                .setString("key", searchKey)
                .setString("value", searchValue);
        return query.list();
    }

    @Required
    public void setArtifactDao(final ArtifactDao artifactDao) {
        this.artifactDao = artifactDao;
    }

    @Required
    public void setActivityFeedWriter(final ActivityFeedWriter activityFeedWriter) {
        this.activityFeedWriter = activityFeedWriter;
    }

}
