package com.ubs.f35.swift.security;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.simple.ParameterizedContextMapper;
import org.springframework.ldap.core.simple.SimpleLdapTemplate;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.ubs.f35.swift.util.LoadingCacheUtil;

/**
 * Looks up which Swift ARP groups a user is a member of using the OID LDAP directory.
 * 
 * @author levyjo
 * 
 */
public class UserGroupsLdapLookup implements InitializingBean, UserGroupsLookup {

    private SimpleLdapTemplate ldapTemplate;
    private static final String BASE_DN = "o=groups,dc=ubsw,dc=com";
    // Staff accounts will come from "o=staff,dc=ubsw,dc=com" and technical accounts "o=generic,dc=ubsw,dc=com"
    private static final String FILTER_DN = "o=*";
    private static final String GROUP_CN_PREFIX = "SWIFT-";
    private static final String ATTR_GUID = "ubswGuid";
    private LoadingCache<String, List<String>> cache;
    private final long cacheSize = 100;
    private long cacheExpiryMinutes = 15;

    protected final ParameterizedContextMapper<String> mapper = new ParameterizedContextMapper<String>() {
        @Override
        public String mapFromContext(final Object ctx) {
            DirContextAdapter context = (DirContextAdapter) ctx;
            return context.getStringAttribute("cn");
        }
    };

    /**
     * Returns list of Swift ARP groups that the given user is a member of. <br>
     * Results are cached for the number of minutes specified by the cacheExpiryMinutes property.
     * 
     * @param guid
     *            the ubswguid of the user to lookup (ubswguids start with PSI...)
     * @return List of group common names
     */
    @Override
    public List<String> findUserSwiftGroups(final String guid) {
        return LoadingCacheUtil.getUnchecked(cache, guid);
    }

    private List<String> findUserSwiftGroupsInternal(final String guid) {
        String filter = "(&(uniquemember=" + ATTR_GUID + "=" + guid + "," + FILTER_DN + ")(cn=" + GROUP_CN_PREFIX
                + "*))";
        return ldapTemplate.search(BASE_DN, filter, mapper);
    }

    @Override
    public void afterPropertiesSet() {
        cache = CacheBuilder.newBuilder().maximumSize(cacheSize)
                .expireAfterWrite(cacheExpiryMinutes, TimeUnit.MINUTES).build(
                        new CacheLoader<String, List<String>>() {
                            @Override
                            public List<String> load(final String guid) {
                                return findUserSwiftGroupsInternal(guid);
                            }
                        }
                );
    }

    @Required
    public void setLdapTemplate(final SimpleLdapTemplate ldapTemplate) {
        this.ldapTemplate = ldapTemplate;
    }

    public void setCacheExpiryMinutes(final long cacheExpiryMinutes) {
        this.cacheExpiryMinutes = cacheExpiryMinutes;
    }

}
