package com.ubs.f35.swift.properties;

import static com.ubs.f35.swift.service.ArtifactConfigurationService.isSnapshot;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.maven.artifact.versioning.DefaultArtifactVersion;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.config.model.EnvironmentConfig;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ArtifactPropertiesDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.hibernate.AuditEntry;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.executors.SwiftExecutors;
import com.ubs.f35.swift.model.ArtifactPropertyKeyHistory;
import com.ubs.f35.swift.properties.bulk.PropertyUpdate;
import com.ubs.f35.swift.properties.model.ArtifactProperties;
import com.ubs.f35.swift.properties.model.DifferencedProperty;
import com.ubs.f35.swift.properties.model.DifferencedProperty.DifferenceType;
import com.ubs.f35.swift.properties.model.Property;
import com.ubs.f35.swift.properties.model.Property.DefaultType;
import com.ubs.f35.swift.properties.model.PropertyKey;
import com.ubs.f35.swift.properties.model.PropertyKeysExtractionException;
import com.ubs.f35.swift.properties.model.PropertyList;
import com.ubs.f35.swift.properties.model.SuggestedProperty;
import com.ubs.f35.swift.properties.model.SuggestedProperty.SuggestionType;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.security.Permission;
import com.ubs.f35.swift.service.NexusArtifactService;

/**
 * <p>
 * Manages the retrieval and storage of properties (keys/values) for an artifact in a given environment.
 * </p>
 * 
 * <p>
 * Properties are returned in an {@link ArtifactProperties} wrapper which contains a {@link PropertyList} of
 * {@link Property}. For new artifact versions, properties are suggested based on automatically discovered keys and
 * previously saved versions. For properties already saved, metadata is included which indicates how properties have
 * changed from one version to the next. Additionally, default properties for an environment can also be included
 * allowing the client to suggest a default or indicate that a stored value differs from the default.
 * </p>
 * 
 * <p>
 * Properties are stored in the Swift database and in ZooKeeper, with the Swift database being the golden source.
 * </p>
 * 
 * @author levyjo
 * 
 */
public class PropertiesManager {

    private static final Logger LOG = LoggerFactory.getLogger(PropertiesManager.class);

    private final ExecutorService nativeZkRetrieveExecutor = Executors.newCachedThreadPool(
            SwiftExecutors.namedThreadFactory("zk-properties-retrieve", true));

    private PropertyKeysProvider propertyKeysProvider;
    private DefaultPropertiesProvider defaultPropertiesProvider;
    private ArtifactPropertiesDao artifactPropertiesDao;
    private EnvironmentBeanFactory<ZooKeeperConnector> zooKeeperConnectorFactory;
    private NexusArtifactService nexusArtifactService;
    private AuthorisationController authorisationController;
    private Set<Environment> enforceTemplateEnvironments;
    private int nativePropertiesRetrieveTimeoutSeconds = 20;

    private static final int PREV_VERSION_SEARCH_TIMEOUT_SECONDS = 2;

    /**
     * @see #getArtifactPropertiesWithSuggestions(String, Artifact, String)
     */
    public ArtifactProperties getArtifactPropertiesWithSuggestions(final Environment environment,
            final Artifact artifact) {

        return getArtifactPropertiesWithSuggestions(environment, artifact, null);

    }

    /**
     * <p>
     * Returns the properties and suggested properties for the given artifact. Property values are either actual (if
     * they exist for the given artifact in the given environment), or suggested (if no value has previously been
     * saved).
     * </p>
     * <p>
     * The returned {@link ArtifactProperties} object contains a {@link PropertyList} composed of one or both of the
     * following types:
     * </p>
     * <ul>
     * <li>A {@link SuggestedProperty} represents a property that has not yet been saved for this artifact version, but
     * is suggested based on the keys discovered in the artifact bundle and the properties that were saved for a
     * previous version of this artifact. A suggested property contains a {@link SuggestionType} flag which indicates
     * where the suggestion comes from.</li>
     * <li>A {@link DifferencedProperty} represents a property that has already been saved in this version. It contains
     * a {@link DifferenceType} flag which indicates where this property originated from. See
     * {@link #getArtifactPropertiesWithComparison(String, Artifact)} for more details.</li>
     * </ul>
     * <p>
     * Properties are sourced primarily from the Swift database, and secondarily from ZooKeeper if they do not exist in
     * the Swift database.<br>
     * Property keys are discovered from the properties files in the artifact's Nexus package.
     * </p>
     * 
     * @param environment
     *            Environment to use for looking up property values
     * @param artifact
     *            Artifact
     * @param previousVersion
     *            Previous artifact version to use for looking up previous property values. Defaults to the last version
     *            where properties exist. Ignored if properties already saved for this artifact.
     * @return {@link ArtifactProperties} containing a {@link PropertyList} of {@link SuggestedProperty}s and
     *         {@link DifferencedProperty}s
     */
    public ArtifactProperties getArtifactPropertiesWithSuggestions(final Environment environment,
            final Artifact artifact,
            final String previousVersion) {

        authorisationController.checkAccess(environment, artifact.getNexusArtifact(), Permission.ViewProperties);

        Map<String, String> defaultProperties = defaultPropertiesProvider.getDefaultPropertiesAsMap(environment);
        ArtifactProperties artifactProperties = getArtifactPropertiesWithComparisonNoAuth(environment, artifact);

        Set<PropertyKey> discoveredKeyDetails = fetchPropertiesKeysAndSetWarnings(artifactProperties, artifact,
                environment);
        Map<String, PropertyKey> propIndex = Maps.uniqueIndex(discoveredKeyDetails, PropertyKeyToNameFunction.INSTANCE);
        Set<String> discoveredKeys = propIndex.keySet();

        if (artifactProperties.isSaved()) {

            // Properties were already saved
            if (isSnapshot(artifact)) {
                // Add any new keys discovered since properties were last saved
                PropertyList propertyList = artifactProperties.getProperties();
                Set<String> newKeys = Sets.difference(discoveredKeys, propertyList.toMap().keySet());

                createNewPropertiesWithSuggestions(newKeys, defaultProperties, propIndex, propertyList);
            }

        } else {
            // Properties not saved yet for this artifact version

            VersionedPropertiesMap previousProperties = getSpecifiedVersionPropertiesOrMostRecent(artifact,
                    environment, previousVersion, false);
            Map<String, String> prevVersionProperties = previousProperties.getProperties();
            String seedVersion = previousProperties.getVersion();

            artifactProperties.setSeedVersion(seedVersion);

            PropertyList properties = artifactProperties.getProperties();

            Set<String> prevVersionKeys = prevVersionProperties.keySet();

            createNewPropertiesWithSuggestions(Sets.difference(discoveredKeys, prevVersionKeys), defaultProperties,
                    propIndex, properties);

            Set<String> removedKeys = Collections.emptySet();
            // In the case where a property template is not configured or configured incorrectly, we don't want to
            // mark all these properties as REMOVED, which would result in the client not saving them.
            if (!discoveredKeys.isEmpty()) {
                // Only suggest to remove properties which have been removed from the template. Do not suggest to remove
                // properties which were explicitly added in the previous version and may be environment specific.
                Artifact previousVersionArtifact = buildPreviousArtifact(artifact, previousProperties.getVersion());
                try {
                    Set<PropertyKey> previousTemplateKeys = fetchPropertyKeys(environment, previousVersionArtifact);
                    if (!previousTemplateKeys.isEmpty()) {
                        Set<String> previousTemplateKeyNames = Sets.newHashSet(
                                Collections2.transform(previousTemplateKeys, PropertyKeyToNameFunction.INSTANCE));
                        removedKeys = Sets.difference(previousTemplateKeyNames, discoveredKeys);
                    }
                } catch (RuntimeException e) {
                    LOG.info("Exception retrieving previous {} property keys. Assuming no keys have been removed",
                            previousVersionArtifact, e);
                }
            }

            for (String key : prevVersionKeys) {
                SuggestionType suggestion = removedKeys.contains(key) ?
                        SuggestionType.REMOVED : SuggestionType.PREVIOUS;
                properties.add(new SuggestedProperty(key, prevVersionProperties.get(key), defaultProperties.get(key),
                        suggestion));
            }

        }

        enrichPropertiesWithDocumentation(artifactProperties, discoveredKeyDetails);

        return artifactProperties;
    }

    protected void createNewPropertiesWithSuggestions(final Set<String> newPropKeys,
            final Map<String, String> defaultProperties,
            final Map<String, PropertyKey> propIndex, final PropertyList properties) {
        for (String key : newPropKeys) {
            String defaultValue = defaultProperties.get(key);
            DefaultType defaultType = DefaultType.ENVIRONMENT;
            PropertyKey propertyKey = propIndex.get(key);
            String initialSuggestedValue = null;
            if (defaultValue == null && propertyKey != null) {
                defaultValue = propertyKey.getSuggestedValue();
                defaultType = DefaultType.TEMPLATE;
            }
            properties.add(new SuggestedProperty(key, initialSuggestedValue, defaultValue, defaultType,
                    SuggestionType.NEW));
        }
    }

    private void enrichPropertiesWithDocumentation(final ArtifactProperties artifactProperties,
            final Set<PropertyKey> discoveredKeyDetails) {
        ImmutableMap<String, PropertyKey> propIndex = Maps.uniqueIndex(discoveredKeyDetails,
                PropertyKeyToNameFunction.INSTANCE);

        for (Property property : artifactProperties.getProperties()) {
            PropertyKey key = propIndex.get(property.getKey());
            if (key != null) {
                property.setDocumentation(key.getDocumentation());
            }
        }
    }

    /**
     * Returns artifact properties as a list of {@link DifferencedProperty}. Each property has a {@link DifferenceType}
     * flag indicating whether it is new, modified or unmodified as compared to the version of properties of the given
     * artifact that these properties were seeded from originally.
     * 
     * @param environment
     * @param artifact
     * @return {@link ArtifactProperties} containing a {@link PropertyList} of {@link DifferencedProperty}s
     */
    public ArtifactProperties getArtifactPropertiesWithComparison(final Environment environment, final Artifact artifact) {

        authorisationController.checkAccess(environment, artifact.getNexusArtifact(), Permission.ViewProperties);

        return getArtifactPropertiesWithComparisonNoAuth(environment, artifact);

    }

    /**
     * As per {@link #getArtifactPropertiesWithComparison(String, Artifact)} but skips the auth checks if already
     * performed.
     * 
     * @param environment
     * @param artifact
     * @return
     */
    private ArtifactProperties getArtifactPropertiesWithComparisonNoAuth(final Environment environment,
            final Artifact artifact) {
        Map<String, String> thisVersionProperties = fetchPropertyValues(environment, artifact);
        String seedVersion = artifactPropertiesDao.getSeedVersion(artifact, environment);

        if (thisVersionProperties.isEmpty() && seedVersion == null) {
            LOG.info("Properties have not yet been saved for {} in {}", artifact, environment);
            return new ArtifactProperties(artifact, false, new PropertyList(), null);
        }

        VersionedPropertiesMap previousProperties = getSpecifiedVersionPropertiesOrMostRecent(artifact, environment,
                seedVersion, true);
        Map<String, String> prevVersionProperties = previousProperties.getProperties();
        seedVersion = previousProperties.getVersion();

        PropertyList properties = new PropertyList();

        for (String key : Sets.difference(thisVersionProperties.keySet(), prevVersionProperties.keySet())) {
            properties.add(new DifferencedProperty(key, thisVersionProperties.get(key), DifferenceType.ADDED));
        }

        for (String key : Sets.intersection(thisVersionProperties.keySet(), prevVersionProperties.keySet())) {
            String newValue = thisVersionProperties.get(key);
            String oldValue = prevVersionProperties.get(key);
            DifferenceType diff;
            if (newValue.equals(oldValue)) {
                diff = DifferenceType.UNMODIFIED;
            } else {
                diff = DifferenceType.MODIFIED;
            }
            properties.add(new DifferencedProperty(key, newValue, diff, oldValue));
        }

        for (String key : Sets.difference(prevVersionProperties.keySet(), thisVersionProperties.keySet())) {
            properties.add(new DifferencedProperty(key, null, DifferenceType.REMOVED, prevVersionProperties.get(key)));
        }

        populatePropertyDefaults(environment, properties);

        return new ArtifactProperties(artifact, true, properties, seedVersion);
    }

    /**
     * Saves properties in ZooKeeper and in the Swift database
     * 
     * @param environment
     *            The environment to save properties to (determines which ZooKeeper cluster)
     * @param artifactProperties
     * @return {@link PropertyList} the saved properties
     */
    public ArtifactProperties saveArtifactProperties(final Environment environment,
            final ArtifactProperties artifactProperties) {

        authorisationController
                .checkAccess(environment, artifactProperties.getArtifact().getNexusArtifact(),
                        Permission.ModifyProperties);
        validateSeedVersion(artifactProperties);

        // Sanitise - remove properties with blank keys
        Iterator<Property> it = artifactProperties.getProperties().iterator();
        while (it.hasNext()) {
            Property p = it.next();
            if (!StringUtils.hasText(p.getKey())) {
                it.remove();
            }
        }

        zooKeeperConnectorFactory.get(environment).saveProperties(artifactProperties);
        artifactPropertiesDao.saveProperties(artifactProperties, environment);

        return getArtifactPropertiesWithComparisonNoAuth(environment, artifactProperties.getArtifact());

    }

    public Set<PropertyKey> fetchPropertyKeys(final String organisation, final Artifact artifact) {
        return propertyKeysProvider.getPropertyKeys(organisation, artifact);
    }

    private Set<PropertyKey> fetchPropertyKeys(final Environment environment, final Artifact artifact) {
        return fetchPropertyKeys(environment.getOrganisation().getName(), artifact);
    }

    /**
     * This method wraps the {@link #fetchPropertyKeys(Artifact)} method but also catches exceptions thrown by the
     * {@link PropertyKeysDiscoverer} and decides whether to throw them or convert them to warnings, depending on
     * whether the environment is one where the use of property key templates is to be enforced. A missing properties
     * template will only generate an exception for artifacts being saved for the first time, to prevent anything new
     * from being deployed without a template file, but still allowing management of legacy versions in all
     * environments. (Properties for snapshots are still allowed to be updated in case the snapshot has been purged from
     * nexus and property keys cannot be retrieved).
     * 
     * @param artifactProperties
     *            The response object to set warnings on
     * @param artifact
     *            The artifact to discover keys in
     * @param environment
     * @return
     */
    private Set<PropertyKey> fetchPropertiesKeysAndSetWarnings(final ArtifactProperties artifactProperties,
            final Artifact artifact, final Environment environment) {

        try {

            Set<PropertyKey> discoveredKeys = fetchPropertyKeys(environment, artifact);
            if (discoveredKeys.isEmpty()) {
                artifactProperties.setWarning("No keys found in the propeties template file");
            }
            return discoveredKeys;

        } catch (PropertyKeysExtractionException ex) {
            if (enforceTemplateEnvironments.contains(environment) && !artifactProperties.isSaved()) {
                throw ex;
            } else {
                artifactProperties.setWarning(ex.getMessage());
            }
        }

        return Sets.<PropertyKey>newHashSet();

    }

    private Map<String, String> fetchPropertyValues(final Environment environment, final Artifact artifact) {
        PropertyList propertiesFromDB = artifactPropertiesDao.getProperties(artifact, environment);
        if (propertiesFromDB.isEmpty() && artifactPropertiesDao.getSeedVersion(artifact, environment) == null) {
            LOG.info("No properties found for {} in {} in the Swift DB. Looking in ZooKeeper.", artifact, environment);
            return fetchNativeProperties(environment, artifact);
        }
        return propertiesFromDB.toMap();
    }

    private Map<String, String> fetchPropertyValuesWithTimeout(final Environment environment, final Artifact artifact)
            throws TimeoutException {
        PropertyList propertiesFromDB = artifactPropertiesDao.getProperties(artifact, environment);
        if (propertiesFromDB.isEmpty() && artifactPropertiesDao.getSeedVersion(artifact, environment) == null) {
            LOG.info("No properties found for {} in {} in the Swift DB. Looking in ZooKeeper.", artifact, environment);
            return fetchNativePropertyValuesWithTimeout(environment, artifact);
        }
        return propertiesFromDB.toMap();
    }

    private Map<String, String> fetchNativeProperties(final Environment environment, final Artifact artifact) {
        StopWatch timer = new StopWatch();
        timer.start();

        ZooKeeperConnector zooKeeperConnector = zooKeeperConnectorFactory.get(environment);
        Map<String, String> result = zooKeeperConnector.getProperties(artifact);

        timer.stop();
        LOG.info("Time to retrieve zookeeper properties {}", timer.shortSummary());

        return result;
    }

    private Map<String, String> fetchNativePropertyValuesWithTimeout(final Environment environment,
            final Artifact artifact) throws TimeoutException {

        Callable<Map<String, String>> task = new Callable<Map<String, String>>() {
            @Override
            public Map<String, String> call() {
                return fetchNativeProperties(environment, artifact);
            }
        };

        Future<Map<String, String>> future = nativeZkRetrieveExecutor.submit(task);

        try {
            return future.get(nativePropertiesRetrieveTimeoutSeconds, TimeUnit.SECONDS);
        } catch (InterruptedException | ExecutionException e) {
            LOG.warn("Exception retrieving properties", e);
            throw new RuntimeException(e);
        } catch (TimeoutException e) {
            LOG.info("Timed out after waiting {} seconds for zookeeper properties to be retrieved.",
                    nativePropertiesRetrieveTimeoutSeconds);
            // Interrupt and cancel the future. No point attempting to continue retrieving from ZK.
            future.cancel(true);
            throw e;
        }
    }

    /**
     * Populates the default values in the given {@link PropertyList} from the environment defaults.
     * 
     * @param environment
     * @param propertyList
     */
    private void populatePropertyDefaults(final Environment environment, final PropertyList propertyList) {

        Map<String, String> defaults = defaultPropertiesProvider.getDefaultPropertiesAsMap(environment);

        for (Property p : propertyList) {
            p.setDefaultValue(defaults.get(p.getKey()));
        }

    }

    /**
     * Returns the properties for the specified previous version of an artifact, or if no previous version is specified,
     * returns the most recent previous properties that exist by calling
     * {@link #getMostRecentProperties(String, Artifact, boolean)} <br>
     * Note: will not return properties of the current artifact version even if the previous version specified is the
     * same as the current version of the artifact. <br>
     * Also note: will only scan for previous versions with properties if no previous version is specified. If a
     * previous version is specified which has no properties, an empty properties map will be returned.
     * 
     * @see #getMostRecentProperties(String, Artifact, boolean)
     * 
     * @param artifact
     * @param environment
     * @param prevVersion
     * @param useOlderVersionsOnly
     * @return {@link VersionedPropertiesMap}
     */
    private VersionedPropertiesMap getSpecifiedVersionPropertiesOrMostRecent(final Artifact artifact,
            final Environment environment, final String prevVersion, final boolean useOlderVersionsOnly) {

        if (StringUtils.hasText(prevVersion)) {
            // If specific previous version has been specified:
            if (!artifact.getVersion().equals(prevVersion)) {
                LOG.info("Using {} version {} as seed version for property values", artifact.getArtifactId(),
                        prevVersion);
                Artifact prevVersionArtifact = buildPreviousArtifact(artifact, prevVersion);
                return new VersionedPropertiesMap(fetchPropertyValues(environment, prevVersionArtifact), prevVersion);
            } else {
                LOG.info("Not using previous version {} specified as it is the same as current version.", prevVersion);
            }

        } else {
            // If specific previous version is not defined, get any previous version we can find.
            VersionedPropertiesMap vpm = getMostRecentProperties(environment, artifact, useOlderVersionsOnly);
            if (vpm != null) {
                LOG.info("Suggesting {} version {} as previous version for property values", artifact.getArtifactId(),
                        vpm.getVersion());
                return vpm;
            }
        }

        return new VersionedPropertiesMap(Collections.<String, String>emptyMap(), null);
    }

    private Artifact buildPreviousArtifact(final Artifact artifact, final String prevVersion) {
        return new Artifact(artifact.getGroupId(), artifact.getArtifactId(), prevVersion);
    }

    /**
     * Returns properties of the most recent version of an artifact where properties exist.<br>
     * If there are no properties for any version of this artifact, or time runs out, returns null. <br>
     * Note: Will never return properties for the current version of the artifact.
     * 
     * @param environment
     * @param artifact
     * @param useOlderVersionsOnly
     *            Only return properties for an artifact version older than the one given
     * @return {@link VersionedPropertiesMap} or null if no properties found
     */
    private VersionedPropertiesMap getMostRecentProperties(final Environment environment, final Artifact artifact,
            final boolean useOlderVersionsOnly) {
        String groupId = artifact.getGroupId();
        String artifactId = artifact.getArtifactId();
        DefaultArtifactVersion thisVersion = new DefaultArtifactVersion(artifact.getVersion());

        List<String> versions = nexusArtifactService.getVersionsForArtifact(new NexusArtifact(groupId, artifactId),
                false);
        if (versions.isEmpty()) {
            throw new RuntimeException("No versions of artifact found in Nexus");
        }

        int times = 0;
        long stopTime = System.nanoTime() + TimeUnit.SECONDS.toNanos(PREV_VERSION_SEARCH_TIMEOUT_SECONDS);
        for (String version : versions) {
            if (!version.equals(artifact.getVersion()) &&
                    (!useOlderVersionsOnly
                    || (new DefaultArtifactVersion(version)).compareTo(thisVersion) < 0)) {

                Artifact otherArtifact = new Artifact(groupId, artifactId, version);
                Map<String, String> properties;
                try {
                    properties = fetchPropertyValuesWithTimeout(environment, otherArtifact);
                } catch (TimeoutException e) {
                    return null;
                }
                if (!properties.isEmpty()) {
                    return new VersionedPropertiesMap(properties, version);
                }

                if (++times >= 2 && System.nanoTime() > stopTime) {
                    LOG.debug("Exceeded time limit looking for a version of {} with properties in ZooKeeper in {}",
                            artifactId, environment);
                    return null;
                    // Give up searching if it's taking to long, as long as we've checked the two most recent versions.
                    // Connecting to ZooKeeper across regions can be slow, so while ideally we would perform an
                    // exhaustive
                    // search back through the versions of an artifact to find one with properties, we do not want to
                    // delay
                    // the response for too long. The likelihood is that if properties do exist for an artifact in
                    // ZooKeeper, they will exist for the most recent versions of the artifact.
                }
            }
        }
        LOG.debug("No previous version of properties found for {} in {}", artifactId, environment);
        return null;
    }

    private void validateSeedVersion(final ArtifactProperties artifactProperties) {
        String seedVersion = artifactProperties.getSeedVersion();
        if (StringUtils.hasText(seedVersion)) {
            Artifact artifact = artifactProperties.getArtifact();
            nexusArtifactService
                    .validateArtifactVersion(new Artifact(artifact.getGroupId(), artifact.getArtifactId(), seedVersion));
        }
    }

    public List<AuditEntry<Property>> getAuditHistory(final Environment environment, final Artifact artifact,
            final PagingFilter daoFilter) {
        authorisationController.checkAccess(environment, artifact.getNexusArtifact(), Permission.ViewProperties);

        return artifactPropertiesDao.getAuditHistory(environment, artifact, daoFilter);

    }

    public List<ArtifactPropertyKeyHistory> getAuditHistory(final Environment environment,
            final NexusArtifact artifact, final String key, final PagingFilter daoFilter) {
        authorisationController.checkAccess(environment, artifact, Permission.ViewProperties);

        return artifactPropertiesDao.getAuditHistory(environment, artifact, key, daoFilter);
    }

    public List<ArtifactProperties> getAllArtifactProperties(final Environment environment,
            final Set<Artifact> artifacts) {
        List<ArtifactProperties> allArtifactProperties = Lists.newArrayList();
        for (Artifact artifact : artifacts) {
            authorisationController.checkAccess(environment, artifact.getNexusArtifact(), Permission.ViewProperties);
            // TODO performance of individual selects?
            PropertyList props = artifactPropertiesDao.getProperties(artifact, environment);
            allArtifactProperties.add(new ArtifactProperties(artifact, props));
        }

        return allArtifactProperties;
    }

    /**
     * The bulk update to each artifact is processed as a separate transaction. This keeps the risk low should something
     * fail, as there is a window betweem updating zookeeper and the db where the two can get out of sync.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateAllArtifactProperties(final Environment environment, final Artifact artifact,
            final List<PropertyUpdate> propertyUpdates) {

        ZooKeeperConnector zookeeperConnector = zooKeeperConnectorFactory.get(environment);

        // update the db first. If the zookeeper update fails, then the db change will be rolled back. But the other way
        // round there is no zookeeper rollback.
        artifactPropertiesDao.saveUpdates(artifact, environment, propertyUpdates);
        zookeeperConnector.saveUpdates(artifact, propertyUpdates);
    }

    @Required
    public void setPropertyKeysProvider(final PropertyKeysProvider propertyKeysProvider) {
        this.propertyKeysProvider = propertyKeysProvider;
    }

    @Required
    public void setZooKeeperConnectorFactory(final EnvironmentBeanFactory<ZooKeeperConnector> zooKeeperConnectorFactory) {
        this.zooKeeperConnectorFactory = zooKeeperConnectorFactory;
    }

    @Required
    public void setDefaultPropertiesProvider(final DefaultPropertiesProvider defaultPropertiesProvider) {
        this.defaultPropertiesProvider = defaultPropertiesProvider;
    }

    @Required
    public void setNexusArtifactService(final NexusArtifactService nexusArtifactService) {
        this.nexusArtifactService = nexusArtifactService;
    }

    @Required
    public void setArtifactPropertiesDao(final ArtifactPropertiesDao artifactPropertiesDao) {
        this.artifactPropertiesDao = artifactPropertiesDao;
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

    @Required
    public void setEnvConfigFactory(final EnvironmentBeanFactory<EnvironmentConfig> envConfigFactory) {
        envConfigFactory.registerUpdateListener(new Runnable() {
            @Override
            public void run() {
                Set<Environment> enforceTemplateEnvironments = new HashSet<>();
                for (Entry<Environment, EnvironmentConfig> entry : envConfigFactory.getAll().entrySet()) {
                    if (entry.getValue().isEnforcePropertyTemplate()) {
                        enforceTemplateEnvironments.add(entry.getKey());
                    }
                }
                PropertiesManager.this.enforceTemplateEnvironments = enforceTemplateEnvironments;
            }
        });
    }

    public void setNativePropertiesRetrieveTimeoutSeconds(final int nativePropertiesRetrieveTimeoutSeconds) {
        this.nativePropertiesRetrieveTimeoutSeconds = nativePropertiesRetrieveTimeoutSeconds;
    }

    /**
     * Wrapper class for a properties map associated with an artifact version.
     * 
     * @author levyjo
     * 
     */
    private class VersionedPropertiesMap {

        private final Map<String, String> properties;
        private final String version;

        public VersionedPropertiesMap(final Map<String, String> properties, final String version) {
            this.properties = properties;
            this.version = version;
        }

        public Map<String, String> getProperties() {
            return properties;
        }

        public String getVersion() {
            return version;
        }

    }

    private static class PropertyKeyToNameFunction implements Function<PropertyKey, String> {
        static PropertyKeyToNameFunction INSTANCE = new PropertyKeyToNameFunction();

        @Override
        public String apply(final PropertyKey input) {
            return input.getName();
        }
    }
}
