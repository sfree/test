package com.ubs.f35.swift.properties.bulk;

import java.util.List;

import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.properties.model.Property;

/**
 * Response from the server to the client with details of the artifacts selected for bulk update and the unique
 * properties across those artifacts.
 */
public class BulkPropertyUpdate {
    // TODO property includes a 'defaultValue' which doesn't make sense in this context. Yet another model object
    // (which shouldn't matter, but java makes is so verbose)
    private final List<Property> properties;
    private final List<Artifact> artifacts;
    private final Environment environment;
    private final BulkUpdateSelection selection;

    public BulkPropertyUpdate(final Environment environment, final List<Property> properties,
            final List<Artifact> artifacts, final BulkUpdateSelection selection) {
        this.properties = properties;
        this.artifacts = artifacts;
        this.environment = environment;
        this.selection = selection;
    }

    public List<Property> getProperties() {
        return properties;
    }

    public List<Artifact> getArtifacts() {
        return artifacts;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public BulkUpdateSelection getSelection() {
        return selection;
    }
}
