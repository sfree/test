package com.ubs.f35.swift.dao.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.config.model.Objects2;

@Entity
@Table(name = "users")
public class SwiftUser {
    @Id
    private String id;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "USER_TEAMS",
            joinColumns = { @JoinColumn(name = "user_id", referencedColumnName = "id") },
            inverseJoinColumns = { @JoinColumn(name = "team_id", referencedColumnName = "id") })
    private List<Team> teams = Lists.newArrayList();

    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public List<Team> getTeams() {
        return teams;
    }

    public void setTeams(final List<Team> teams) {
        this.teams = teams;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof SwiftUser) {
            SwiftUser that = (SwiftUser) object;
            return Objects2.equal(this.id, that.id)
                    && Objects2.equal(this.teams, that.teams);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("teams", teams)
                .toString();
    }
}
