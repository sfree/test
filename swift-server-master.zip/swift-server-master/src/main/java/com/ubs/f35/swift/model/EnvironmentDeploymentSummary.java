package com.ubs.f35.swift.model;

import java.sql.Timestamp;
import java.util.List;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.dao.model.Environment;

/**
 * This object encapsulates the latest deployment status of a release in a given environment along with associated
 * metadata.
 * 
 * @author levyjo
 * 
 */
public class EnvironmentDeploymentSummary {

    private final String environment;
    private final EnvironmentDeploymentStatus status;
    private final String user;
    private final Timestamp deployTime;
    private final List<StaleArtifact> staleArtifacts;

    public enum EnvironmentDeploymentStatus {
        COMPLETED, FAILED, CANCELLED, STALE, ROLLBACK
    }

    public EnvironmentDeploymentSummary(final EnvironmentDeploymentStatus status,
            final EnvDeployment envDeployment,
            final List<StaleArtifact> staleArtifacts) {
        this(envDeployment.getEnvironment(),
                status,
                envDeployment.getDeployment().getUser(),
                envDeployment.getDeployment().getDeployTime(),
                staleArtifacts);
    }

    private EnvironmentDeploymentSummary(final Environment environment, final EnvironmentDeploymentStatus status,
            final String user, final Timestamp deployTime, final List<StaleArtifact> staleArtifacts) {
        this.environment = environment.getName();
        this.status = status;
        this.user = user;
        this.deployTime = deployTime;
        this.staleArtifacts = staleArtifacts;
    }

    public String getEnvironment() {
        return environment;
    }

    public EnvironmentDeploymentStatus getStatus() {
        return status;
    }

    public String getUser() {
        return user;
    }

    public Timestamp getDeployTime() {
        return deployTime;
    }

    public List<StaleArtifact> getStaleArtifacts() {
        return staleArtifacts;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(environment, status, user, deployTime, staleArtifacts);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof EnvironmentDeploymentSummary) {
            EnvironmentDeploymentSummary that = (EnvironmentDeploymentSummary) object;
            return Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.status, that.status)
                    && Objects.equal(this.user, that.user)
                    && Objects.equal(this.deployTime, that.deployTime)
                    && Objects.equal(this.staleArtifacts, that.staleArtifacts);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("environment", environment)
                .add("status", status)
                .add("user", user)
                .add("deployTime", deployTime)
                .add("staleArtifacts", staleArtifacts)
                .toString();
    }

    public static class StaleArtifact {
        private final String groupId;
        private final String artifactId;
        private final String deployedVersion;
        private final String releaseVersion;

        public StaleArtifact(final String groupId, final String artifactId, final String deployedVersion,
                final String releaseVersion) {
            this.groupId = groupId;
            this.artifactId = artifactId;
            this.deployedVersion = deployedVersion;
            this.releaseVersion = releaseVersion;
        }

        public String getGroupId() {
            return groupId;
        }

        public String getArtifactId() {
            return artifactId;
        }

        public String getDeployedVersion() {
            return deployedVersion;
        }

        public String getReleaseVersion() {
            return releaseVersion;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(groupId);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof StaleArtifact) {
                StaleArtifact that = (StaleArtifact) object;
                return Objects.equal(this.groupId, that.groupId)
                        && Objects.equal(this.artifactId, that.artifactId)
                        && Objects.equal(this.deployedVersion, that.deployedVersion)
                        && Objects.equal(this.releaseVersion, that.releaseVersion);
            }
            return false;
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this)
                    .add("groupId", groupId)
                    .add("artifactId", artifactId)
                    .add("deployedVersion", deployedVersion)
                    .add("releaseVersion", releaseVersion)
                    .toString();
        }
    }
}
