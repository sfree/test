package com.ubs.f35.swift.environment;

import java.util.Map;

import com.ubs.f35.swift.dao.model.Environment;

/**
 * Swift manages releases to multiple environments. Implementors provide access to environment specific functionality.
 * 
 * @param <T>
 *            The manager for the environment
 */
public interface EnvironmentBeanFactory<T> {
    T get(Environment environment);

    Map<Environment, T> getAll();

    void registerUpdateListener(Runnable runnable);
}
