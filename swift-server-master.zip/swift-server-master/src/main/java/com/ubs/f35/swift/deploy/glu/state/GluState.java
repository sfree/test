package com.ubs.f35.swift.deploy.glu.state;

import java.util.Arrays;
import java.util.List;

import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.deploy.glu.state.Transition.TransitionStep;

public enum GluState {
    // Note that the order is important and defines the order to go from nothing to running.
    // And the reverse applies to remove.
    nomountpoint(new Transition("NONE", TransitionStep.deploy_script)),
    // The mount point is in a NONE state when the mount point is installed, but the install phase has not yet been run
    // (ie, the mount point has been created with a valid groovy script)
    NONE(new Transition("installed", TransitionStep.install), new Transition("nomountpoint",
            TransitionStep.remove_script)),
    installed(new Transition("stopped", TransitionStep.configure), new Transition("NONE", TransitionStep.uninstall)),
    stopped(new Transition("running", TransitionStep.start), new Transition("installed", TransitionStep.unconfigure)),
    running(new Transition("stopped", TransitionStep.stop));

    private static final List<GluState> STATES = Lists.newArrayList();
    private List<Transition> transitions;

    static {
        STATES.addAll(Arrays.asList(GluState.values()));
    }

    GluState(final Transition... transitions) {
        this.transitions = ImmutableList.copyOf(transitions);
    }

    Transition getTransition(final GluState targetState) {
        for (Transition transition : transitions) {
            if (transition.getTargetState() == targetState) {
                return transition;
            }
        }
        throw new IllegalArgumentException("No transition from " + this + " to " + targetState);
    }

    /**
     * Returns a list of transitions which must be taken to arrive at the target state.
     * 
     * @param targetState
     * @return
     */
    public List<Transition> getTransitionsForTargetState(final GluState targetState) {
        int currentStateIndex = this.ordinal();
        GluState currentState = this;
        int targetStateIndex = targetState.ordinal();

        List<Transition> transitions = Lists.newArrayList();

        if (currentStateIndex != targetStateIndex) {
            int increment = currentStateIndex < targetStateIndex ? 1 : -1;

            while (currentStateIndex != targetStateIndex) {
                int nextStateIndex = currentStateIndex + increment;
                GluState nextState = GluState.values()[nextStateIndex];

                transitions.add(currentState.getTransition(nextState));

                currentStateIndex = nextStateIndex;
                currentState = nextState;
            }
        }
        return transitions;
    }

    public GluState getEndState(final TransitionStep transitionStep) {
        return Iterables.find(transitions, new TransitionPredicate(transitionStep)).getTargetState();
    }

    public static GluState getStartStateForTransition(final TransitionStep transitionStep) {
        return Iterables.find(STATES, new Predicate<GluState>() {
            @Override
            public boolean apply(final GluState input) {
                return Iterables.any(input.transitions, new TransitionPredicate(transitionStep));
            }
        });
    }

    private static class TransitionPredicate implements Predicate<Transition>
    {
        private final TransitionStep transitionStep;

        TransitionPredicate(final TransitionStep transitionStep) {
            this.transitionStep = transitionStep;
        }

        @Override
        public boolean apply(final Transition input) {
            return input.getAction() == transitionStep;
        }
    }
}
