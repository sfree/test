package com.ubs.f35.swift.artifact;

import com.ubs.f35.swift.dao.NexusArtifact;

interface NexusFeedNotificationListener {
    void handleArtifactDeployed(String organisation, NexusArtifact artifact);
}