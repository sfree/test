package com.ubs.f35.swift.dao.hibernate.framework;

import org.hibernate.Criteria;

public interface PagingCriteriaBuilder {
    void appendCriteria(Criteria criteria, boolean count);
}
