package com.ubs.f35.swift.deploy.glu;

import com.ubs.f35.swift.deploy.glu.state.Transition.TransitionStep;
import com.ubs.f35.swift.environment.model.glu.Entry;

public interface DeploymentInvoker {

    void executeTransition(Entry entry, TransitionStep transitionAction);

}
