package com.ubs.f35.swift.config.model;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

import com.google.common.base.Objects;

public class GluScriptMetadata {
    /** The glu script package name */
    private final String name;
    /** A short (max 4 character) type (eg Web, Java, node) */
    private final String category;
    /** A CSS compatible color to represent this type */
    private final String color;
    /**
     * Should multiple instances of this artifact in an environment be deployed in parallel. True will allow for faster
     * deployments. False will provide greater resiliency by ensuring an instance remains up during the deployment.
     */
    private boolean parallelDeploy = false;
    /** Tags to apply to artifacts using this script */
    private final List<String> tags;

    public GluScriptMetadata(@JsonProperty("name") final String name, @JsonProperty("category") final String category,
            @JsonProperty("color") final String color, @JsonProperty("parallelDeploy") final boolean parallelDeploy,
            @JsonProperty("tags") final List<String> tags) {
        this.name = name;
        this.category = category;
        this.color = color;
        this.parallelDeploy = parallelDeploy;
        this.tags = tags;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public String getColor() {
        return color;
    }

    public boolean isParallelDeploy() {
        return parallelDeploy;
    }

    public List<String> getTags() {
        return tags;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof GluScriptMetadata) {
            GluScriptMetadata that = (GluScriptMetadata) object;
            return Objects.equal(this.name, that.name)
                    && Objects.equal(this.category, that.category)
                    && Objects.equal(this.color, that.color)
                    && Objects.equal(this.parallelDeploy, that.parallelDeploy)
                    && Objects.equal(this.tags, that.tags);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("name", name)
                .add("category", category)
                .add("color", color)
                .add("parallelDeploy", parallelDeploy)
                .add("tags", tags)
                .toString();
    }

}
