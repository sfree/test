package com.ubs.f35.swift.model;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonRawValue;

import com.google.common.base.Objects;

public class GluScriptConfig {

    // the script package (but package is a reserved word.
    private final String pckage;
    private final String script;
    private final String config;

    public GluScriptConfig(final String pckage, final String script, final String config) {
        this.pckage = pckage;
        this.script = script;
        this.config = config;
    }

    @JsonIgnore
    public String getPackage() {
        return pckage;
    }

    public String getScript() {
        return script;
    }

    @JsonRawValue
    public String getConfig() {
        return config;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(script, config);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof GluScriptConfig) {
            GluScriptConfig that = (GluScriptConfig) object;
            return Objects.equal(this.pckage, that.pckage)
                    && Objects.equal(this.script, that.script)
                    && Objects.equal(this.config, that.config);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("pckage", pckage)
                .add("script", script)
                .add("config", config)
                .toString();
    }

}
