package com.ubs.f35.swift.properties.model;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/**
 * {@link TreeSet} of {@link Property}. <br>
 * There are two reasons for using this class to encapsulate a collection of {@link Property}s rather than choosing a
 * generic container:
 * <ol>
 * <li>Using this class provides a work around for a problem whereby the Spring Rest Template does not correctly marshal
 * a generic (typed) container such as {@link List}&lt;{@link Property}&gt; when it is passed as a JSON request body.</li>
 * <li>This class extends {@link TreeSet} which means properties will always be rendered in the correct order
 * (case-insensitive by key) as defined by the natural ordering of the {@link Property} model class.</li>
 * </ol>
 * 
 * @author levyjo
 * 
 */
public class PropertyList extends TreeSet<Property> {

    private static final long serialVersionUID = -3123736012940927269L;

    public PropertyList() {

    }

    public PropertyList(final Map<String, String> propertyMap) {

        for (String key : propertyMap.keySet()) {
            super.add(new Property(key, propertyMap.get(key)));
        }

    }

    public Map<String, String> toMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        for (Property p : this) {
            map.put(p.getKey(), p.getValue());
        }
        return map;
    }

}
