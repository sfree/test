package com.ubs.f35.swift.activity.data;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.ubs.f35.swift.dao.Activity;
import com.ubs.f35.swift.dao.Activity.ActivityType;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;
import com.ubs.f35.swift.dao.ReleaseDefinition;

/**
 * Data object format for an {@link Activity} of deploymentType {@link ActivityType#DEPLOYMENT}
 * 
 * @author levyjo
 * 
 */
public class DeploymentActivityData implements ActivityData {

    private String releaseName;
    private String planId;
    private String status;
    private String deploymentType;

    public DeploymentActivityData() {

    }

    public DeploymentActivityData(final String deploymentType, final String status, final String releaseName,
            final String planId) {
        this.deploymentType = deploymentType;
        this.status = status;
        this.releaseName = releaseName;
        this.planId = planId;
    }

    @Override
    public DeploymentActivityData merge(final ActivityData newData) {
        // Deployment activities not aggregatable
        return null;
    }

    @JsonIgnore
    @Override
    public boolean isEmpty() {
        // Cannot undo a deployment event once it's been created
        return false;
    }

    public String getType() {
        return deploymentType;
    }

    public void setDeploymentType(final String deploymentType) {
        this.deploymentType = deploymentType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public String getReleaseName() {
        return releaseName;
    }

    public void setReleaseName(final String releaseName) {
        this.releaseName = releaseName;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(final String planId) {
        this.planId = planId;
    }

    public static DeploymentActivityData newDeployment(final Deployment deployment,
            final DeploymentStatus deploymentStatus, final ReleaseDefinition releaseDefinition) {
        DeploymentActivityData data = new DeploymentActivityData();
        data.setDeploymentType(deployment.getDeploymentType().toString());
        data.setStatus(deploymentStatus.toString());
        data.setReleaseName(releaseDefinition.getName());
        data.setPlanId(deployment.getId().toString());
        return data;
    }

}
