package com.ubs.f35.swift.artifact;

import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.UsernamePasswordCredentials;

import com.sun.syndication.fetcher.FeedFetcher;
import com.sun.syndication.fetcher.impl.FeedFetcherCache;
import com.sun.syndication.fetcher.impl.HashMapFeedInfoCache;
import com.sun.syndication.fetcher.impl.HttpClientFeedFetcher;
import com.sun.syndication.fetcher.impl.HttpClientFeedFetcher.CredentialSupplier;

public class NexusFeedFetcherFactory {

    public FeedFetcher createInstance(final String username, final String password) {
        FeedFetcherCache feedInfoCache = HashMapFeedInfoCache.getInstance();
        return new HttpClientFeedFetcher(feedInfoCache, new CredentialSupplier() {
            @Override
            public Credentials getCredentials(final String realm, final String host) {
                return new UsernamePasswordCredentials(username, password);
            }
        });
    }

}
