package com.ubs.f35.swift.environment;

import java.util.Map;
import java.util.Properties;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClientException;
import com.ubs.f35.core.zookeeper.client.config.api.ZooKeeperPropertiesService;

/**
 * The {@link NeoZookeeperFactory} provides instances of the UBS developed {@link ZooKeeperClient}. This is used by the
 * {@link ZooKeeperPropertiesService} to load and persist artifact properties to zookeeper.
 */
public class NeoZookeeperFactory extends ZookeeperFactory<ZooKeeperClient> {

    @Override
    public ZooKeeperClient load(final Map<String, String> zooKeeperClientProperties) {
        Properties props = new Properties();
        props.putAll(zooKeeperClientProperties);
        try {
            return ZooKeeperClient.newFromZooKeeperClientProperties(props, false);
        } catch (ZooKeeperClientException e) {
            throw new RuntimeException("Unable to create UBS zookeeper client", e);
        }
    }

    @Override
    void close(final ZooKeeperClient zookeeper) {
        zookeeper.stop();
    }

}
