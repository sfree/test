package com.ubs.f35.swift.artifact;

import java.util.List;

import com.ubs.f35.swift.dao.Artifact;

public interface ArtifactResolver extends NexusInstanceSpecific {

    List<String> getVersions(String group, String artifact, boolean showSnapshotsLast);

    List<String> getSnapshotVersions(String group, String artifact);

    void validateArtifact(Artifact artifact) throws ArtifactNotFoundInRepoException;

}
