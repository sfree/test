package com.ubs.f35.swift.io.processor;


public class CancelDeploymentMessage implements DeploymentConversationMessage {

    @Override
    public int hashCode() {
        return 1;
    }

    @Override
    public boolean equals(final Object object) {
        return object instanceof CancelDeploymentMessage;
    }

}
