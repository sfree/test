package com.ubs.f35.swift.deploy.glu.plan;

import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.Deployment.DeploymentType;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.model.TargetedInstanceDeployment;

public class ReleaseDeploymentBuildingContext {
    final DeploymentPlanBuilder builder;
    final Map<NexusArtifact, Artifact> releaseArtifacts;
    final Environment environment;
    final DeploymentType deploymentType;
    final AtomicInteger uniqueId;
    final TargetedInstanceDeployment targetedInstanceDeployment;

    public ReleaseDeploymentBuildingContext(final DeploymentPlanBuilder builder,
            final Map<NexusArtifact, Artifact> releaseArtifacts, final Environment environment,
            final DeploymentType deploymentType,
            final AtomicInteger uniqueId, final TargetedInstanceDeployment targetedInstanceDeployment) {
        this.builder = builder;
        this.releaseArtifacts = releaseArtifacts;
        this.environment = environment;
        this.deploymentType = deploymentType;
        this.uniqueId = uniqueId;
        this.targetedInstanceDeployment = targetedInstanceDeployment;
    }

    public DeploymentPlanBuilder getBuilder() {
        return builder;
    }

    public Map<NexusArtifact, Artifact> getReleaseArtifacts() {
        return releaseArtifacts;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public DeploymentType getDeploymentType() {
        return deploymentType;
    }

    public AtomicInteger getUniqueId() {
        return uniqueId;
    }

    public TargetedInstanceDeployment getTargetedInstanceDeployment() {
        return targetedInstanceDeployment;
    }

}