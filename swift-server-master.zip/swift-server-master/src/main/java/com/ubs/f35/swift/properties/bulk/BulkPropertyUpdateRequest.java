package com.ubs.f35.swift.properties.bulk;

import java.util.List;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 * A request from the client to perform a bulk update.
 */
public class BulkPropertyUpdateRequest {
    final BulkUpdateSelection selection;
    List<PropertyUpdate> propertyUpdates;

    @JsonCreator
    public BulkPropertyUpdateRequest(@JsonProperty("selection") final BulkUpdateSelection selection,
            @JsonProperty("propertyUpdates") final List<PropertyUpdate> propertyUpdates) {
        this.selection = selection;
        this.propertyUpdates = propertyUpdates;
    }

    public BulkUpdateSelection getSelection() {
        return selection;
    }

    public List<PropertyUpdate> getPropertyUpdates() {
        return propertyUpdates;
    }

}
