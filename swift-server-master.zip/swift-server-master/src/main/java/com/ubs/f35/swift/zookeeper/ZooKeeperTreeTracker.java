package com.ubs.f35.swift.zookeeper;

import java.util.concurrent.Executor;

import org.apache.zookeeper.KeeperException;
import org.linkedin.zookeeper.client.IZKClient;
import org.linkedin.zookeeper.tracker.NodeEventsListener;
import org.linkedin.zookeeper.tracker.TrackedNode;
import org.linkedin.zookeeper.tracker.ZKDataReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Exposes functionality provided by the GLU orchestration engine.
 * 
 * @author stephelu
 * 
 */
public class ZooKeeperTreeTracker<T> {

    private static final Logger LOG = LoggerFactory.getLogger(ZooKeeperTreeTracker.class);

    private volatile ZKState state = ZKState.Disconnected;

    public enum ZKState {
        Disconnected,
        Connecting,
        Connected
    }

    private final org.linkedin.zookeeper.tracker.FastZooKeeperTreeTracker<T> delegate;
    private final Executor executor;

    ZooKeeperTreeTracker(final IZKClient zk, final ZKDataReader<T> zkDataReader, final String root,
            final Executor executor) {
        // Getting the max depth right improves performance as it prevents the tracker from attempting to retrieve
        // children at a depth which swift isn't interested in (and most likely nothing will exist at that depth.
        int maxDepth = 2;
        delegate = new org.linkedin.zookeeper.tracker.FastZooKeeperTreeTracker<T>(zk, zkDataReader, root, maxDepth);
        this.executor = executor;
    }

    public ZKState getState() {
        return state;
    }

    void setState(final ZKState state) {
        this.state = state;
    }

    public TrackedNode<T> get(final String path) {
        String fullPath = delegate.getRoot() + path;
        return delegate.getTree().get(fullPath);
    }

    public String getRoot() {
        return delegate.getRoot();
    }

    void track() throws InterruptedException, KeeperException {
        delegate.track();
    }

    void destroy() {
        delegate.destroy();
    }

    public void registerListenerInBackground(final NodeEventsListener<T> eventsListener)
    {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                delegate.registerListener(eventsListener);
            }
        });
    }
}
