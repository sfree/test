package com.ubs.f35.swift.artifact;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Maps;
import com.sun.syndication.feed.synd.SyndEntryImpl;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.fetcher.FeedFetcher;
import com.sun.syndication.fetcher.FetcherException;
import com.sun.syndication.io.FeedException;
import com.ubs.f35.swift.dao.NexusArtifact;

/**
 * Currently supports Neo and GED (Global Equity Derivs) artifacts in cft-nexus.
 * 
 * @author stephelu
 * 
 */
public class NexusArtifactRssFeedWatcher {
    private static final Logger LOG = LoggerFactory.getLogger(NexusArtifactRssFeedWatcher.class);

    private static final Pattern REPO_PATTERN = Pattern.compile("nexus/content/repositories/(.*?)/");

    private FeedFetcher feedFetcher;
    private URL feedUrl;
    private NexusFeedNotificationListener nexusFeedNotificationListener;
    private final Map<String, String> repoToOrgMap = Maps.newHashMap();

    public void runChecks() throws IllegalArgumentException, IOException, FeedException, FetcherException {
        SyndFeed feed = feedFetcher.retrieveFeed(feedUrl);

        processFeed(feed);
    }

    public void addRepoToOrgMappings(final List<String> repos, final String organisation) {
        for (String repo : repos) {
            repoToOrgMap.put(repo, organisation);
        }
    }

    @SuppressWarnings("unchecked")
    private void processFeed(final SyndFeed feed) {
        List<SyndEntryImpl> entries = feed.getEntries();
        LOG.info("feed retrieved with {} entries", entries.size());
        for (SyndEntryImpl entry : entries) {
            String title = entry.getTitle();
            if (title != null && title.endsWith("dist")) {
                String link = entry.getLink();
                String repo = extractRepo(link);

                if (repo != null) {
                    String organisation = repoToOrgMap.get(repo);
                    if (organisation != null) {

                        // ingest
                        String[] parts = title.split(":");
                        if (parts.length >= 2) {
                            NexusArtifact artifact = new NexusArtifact(parts[0], parts[1]);
                            LOG.debug("Artifact deployed {}", artifact);

                            nexusFeedNotificationListener.handleArtifactDeployed(organisation, artifact);
                        }
                    }
                }
            }
        }
    }

    private String extractRepo(final String link) {
        if (link != null) {
            Matcher matcher = REPO_PATTERN.matcher(link);
            if (matcher.find()) {
                return matcher.group(1);
            }
        }
        return null;
    }

    public void setFeedFetcher(final FeedFetcher feedFetcher) {
        this.feedFetcher = feedFetcher;
    }

    public void setFeedUrl(final URL feedUrl) {
        this.feedUrl = feedUrl;
    }

    public void setNexusFeedNotificationListener(final NexusFeedNotificationListener nexusFeedNotificationListener) {
        this.nexusFeedNotificationListener = nexusFeedNotificationListener;
    }

}
