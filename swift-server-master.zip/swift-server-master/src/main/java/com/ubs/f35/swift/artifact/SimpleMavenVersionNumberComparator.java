package com.ubs.f35.swift.artifact;

import java.util.Comparator;

import org.apache.maven.artifact.versioning.DefaultArtifactVersion;

/**
 * Sorts a list of version numbers so that the most recent are returned first.
 * 
 * @author stephelu
 * 
 */
public class SimpleMavenVersionNumberComparator implements Comparator<String> {
    public static final SimpleMavenVersionNumberComparator INSTANCE = new SimpleMavenVersionNumberComparator();

    @Override
    public int compare(final String o1, final String o2) {
        DefaultArtifactVersion version1 = new DefaultArtifactVersion(o1);
        DefaultArtifactVersion version2 = new DefaultArtifactVersion(o2);
        return -version1.compareTo(version2);
    }

}
