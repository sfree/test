package com.ubs.f35.swift.io.processor;

import org.codehaus.jackson.annotate.JsonSubTypes;
import org.codehaus.jackson.annotate.JsonSubTypes.Type;
import org.codehaus.jackson.annotate.JsonTypeInfo;
import org.codehaus.jackson.annotate.JsonTypeInfo.As;
import org.codehaus.jackson.annotate.JsonTypeInfo.Id;

@JsonTypeInfo(use = Id.NAME, include = As.PROPERTY, property = "action")
@JsonSubTypes(value = {
        @Type(value = StartDeploymentMessage.class, name = "DEPLOY"),
        @Type(value = CancelDeploymentMessage.class, name = "CANCEL"),
        @Type(value = ManualDeploymentInstructionMessage.class, name = "MANUAL") })
public interface DeploymentConversationMessage {

}
