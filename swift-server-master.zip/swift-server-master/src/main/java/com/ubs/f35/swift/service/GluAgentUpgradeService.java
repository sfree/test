package com.ubs.f35.swift.service;

import java.util.List;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.HostDao;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.GluDeploymentInvoker;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;

/**
 * Upgrades glu agents using the command execution service.
 * 
 * http://pongasoft.github.io/glu/docs/latest/html/agent.html#auto-upgrade
 */
@ManagedResource
public class GluAgentUpgradeService extends AbstractJmxProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(GluAgentUpgradeService.class);

    private HostDao hostDao;
    private EnvironmentBeanFactory<GluDeploymentInvoker> gluAgentClientFactory;

    @Required
    public void setHostDao(final HostDao hostDao) {
        this.hostDao = hostDao;
    }

    @Required
    public void setGluAgentClientFactory(final EnvironmentBeanFactory<GluDeploymentInvoker> gluAgentClientFactory) {
        this.gluAgentClientFactory = gluAgentClientFactory;
    }

    @Transactional(readOnly = true)
    @ManagedOperation
    @ManagedOperationParameters(value = {
            @ManagedOperationParameter(name = "organisation", description = "organisation which environment belongs to"),
            @ManagedOperationParameter(name = "environment", description = "environment to upgrade all agents"),
            @ManagedOperationParameter(name = "version", description = "The version of the agent to upgrade to"),
            @ManagedOperationParameter(name = "upgradeUrlPackage", description = "The remote location of the upgrade package for download"),
            @ManagedOperationParameter(name = "upgradeFilePackage", description = "The local location of the upgrade package for installation") })
    public String upgradeAgents(final String organisation, final String environment, final String version,
            final String url, final String file) {
        return executeOperation(new Callable<String>() {
            @Override
            public String call() {
                final Environment env = new Environment(environment, organisation);
                LOG.info("Upgrading all agents in environment {}", env);
                List<Host> hosts = hostDao.loadByEnvironment(env);

                List<AgentCallable> operations = Lists.transform(hosts, new Function<Host, AgentCallable>() {
                    @Override
                    public AgentCallable apply(final Host host) {
                        return new AgentCallable(host.getHostname()) {
                            @Override
                            public String call() throws Exception {
                                upgradeAgentInternal(env, host.getHostname(), version, url, file);
                                return "Upgrade triggered.  Will continue in background.";
                            }
                        };
                    }
                });

                String result = executeOperations(operations);

                return "Agent upgrade triggered for " + hosts.size() + " hosts.\n" + result;
            }
        });
    }

    @Transactional(readOnly = true)
    @ManagedOperation
    @ManagedOperationParameters(value = {
            @ManagedOperationParameter(name = "organisation", description = "organisation which environment belongs to"),
            @ManagedOperationParameter(name = "environment", description = "environment to upgrade"),
            @ManagedOperationParameter(name = "agent", description = "agent to upgrade"),
            @ManagedOperationParameter(name = "version", description = "The version of the agent to upgrade to"),
            @ManagedOperationParameter(name = "upgradeUrlPackage", description = "The remote location of the upgrade package for download"),
            @ManagedOperationParameter(name = "upgradeFilePackage", description = "The local location of the upgrade package for installation") })
    public String upgradeAgent(final String organisation, final String environment, final String agent,
            final String version, final String url, final String file) {
        return executeOperation(new Callable<String>() {
            @Override
            public String call() {
                return upgradeAgentInternal(new Environment(environment, organisation), agent, version, url, file);
            }
        });
    }

    private String upgradeAgentInternal(final Environment environment, final String agent,
            final String version, final String url, final String file) {
        GluDeploymentInvoker gluAgentInvoker = gluAgentClientFactory.get(environment);

        // From the current version of the agent which is running, the upgrade scripts are up one directory.
        String command = "../bin/upgradeagent -v " + version;
        if (StringUtils.hasText(url)) {
            command += " -u \"" + url + "\"";
        }
        if (StringUtils.hasText(file)) {
            command += " -f \"" + file + "\"";
        }

        LOG.info("Upgrading agent {}", agent);
        gluAgentInvoker.executeShellCommand(agent, command);

        return "Upgraded agent " + agent + ". Upgrade will continue in the background";
    }
}
