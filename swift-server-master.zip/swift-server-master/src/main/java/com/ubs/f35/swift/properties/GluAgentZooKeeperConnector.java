package com.ubs.f35.swift.properties;

import java.io.IOException;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.CommandExecutionException;
import com.ubs.f35.swift.deploy.glu.rest.GluDeploymentInvoker;
import com.ubs.f35.swift.properties.bulk.PropertyUpdate;
import com.ubs.f35.swift.properties.model.ArtifactProperties;
import com.ubs.f35.swift.service.CommandBuilderService;

public class GluAgentZooKeeperConnector implements ZooKeeperConnector {

    private static final Logger LOG = LoggerFactory.getLogger(GluAgentZooKeeperConnector.class);

    private final Environment environment;
    private final GluDeploymentInvoker gluAgentInvoker;
    private final CommandBuilderService commandBuilderService;
    private final Properties zooKeeperClientProperties;
    private final ZooKeeperConnector nativeZooKeeperConnector;
    private final HealthyAgentProvider healthyAgentProvider;

    GluAgentZooKeeperConnector(final Environment environment, final GluDeploymentInvoker gluAgentInvoker,
            final CommandBuilderService commandBuilderService, final Properties zooKeeperClientProperties,
            final ZooKeeperConnector nativeZooKeeperConnector, final HealthyAgentProvider healthyAgentProvider) {
        this.environment = environment;
        this.gluAgentInvoker = gluAgentInvoker;
        this.commandBuilderService = commandBuilderService;
        this.zooKeeperClientProperties = zooKeeperClientProperties;
        this.nativeZooKeeperConnector = nativeZooKeeperConnector;
        this.healthyAgentProvider = healthyAgentProvider;
    }

    @Override
    public void saveProperties(final ArtifactProperties artifactProperties) {
        // The command framework for Neo deployments. It's a bit crap having to deploy something to
        // all agents to support saving zookeeper properties, plus the agents deployed to windows can't use the same
        // command. Need a single consistent solution. Non neo zookeeper props save never hits this implementation

        String agent = healthyAgentProvider.provideAgent(environment);
        if (agent == null) {
            LOG.warn(
                    "No alive agents found in environment {} for saving properties. Connecting to ZooKeeper directly.",
                    environment);
            nativeZooKeeperConnector.saveProperties(artifactProperties);
        } else {
            savePropertiesUsingAgent(artifactProperties, agent);
        }
    }

    @Override
    public void saveUpdates(final Artifact artifact, final List<PropertyUpdate> propertyUpdates) {
        // No Neo specific magic for processing specific updates to properties
        nativeZooKeeperConnector.saveUpdates(artifact, propertyUpdates);
    }

    @Override
    public Map<String, String> getProperties(final Artifact artifact) {
        // No Neo specific magic for retrieving properties
        return nativeZooKeeperConnector.getProperties(artifact);
    }

    private void savePropertiesUsingAgent(final ArtifactProperties artifactProperties, final String agent) {
        Properties properties = new Properties();
        properties.putAll(artifactProperties.getProperties().toMap());

        StringWriter writer = new StringWriter();

        try {
            properties.store(writer, null);
        } catch (IOException e) {
            throw new RuntimeException("Error writing properties", e);
        }

        String wrapperCommand = commandBuilderService.buildCommand("saveproperties");
        Artifact artifact = artifactProperties.getArtifact();
        String command = new StringBuilder(wrapperCommand).append(" ")
                .append(artifact.getGroupId()).append(" ")
                .append(artifact.getArtifactId()).append(" ")
                .append(artifact.getVersion()).append(" ")
                .append(environment.getName()).append(" ")
                .append(zooKeeperClientProperties.getProperty("zookeeper.client.host.ports")).append(" ")
                .append(zooKeeperClientProperties.getProperty("zookeeper.client.username")).append(" ")
                .append(zooKeeperClientProperties.getProperty("zookeeper.client.password"))
                .toString();

        LOG.info("Using remote agent {} to save ZooKeeper properties in {}", agent, environment);

        try {
            gluAgentInvoker.executeShellCommand(agent, command, writer.toString());
        } catch (CommandExecutionException ex) {
            throw new RuntimeException("Error saving properties for " + artifact.getArtifactId() + " "
                    + artifact.getVersion() + ": " + ex.getMessage(), ex);
        } catch (RuntimeException ex) {
            // This catches a rare edge case where there is an exception communicating with the agent, but the agent is
            // still reported as up in ZooKeeper (gluProcessManager.isAgentDown(agent) returned true). We have seen this
            // in the case where an agent gets into a bad state. In this case, we provide some level of resilience by
            // making a call to findNewAgent() which will set a different agent ready for the next attempt. However we
            // do not automatically try again, because if there is some wider problem with the agents or there is some
            // completely different cause of the RuntimeException, we do not want to keep trying indefinitely, but
            // rather we need human intervention.
            healthyAgentProvider.flagDodgyAgent(environment, agent);
            throw new RuntimeException("Error communicating with agent on " + agent + " to save properties: "
                    + ex.getMessage() + ". Please try again.", ex);
        }
    }

}
