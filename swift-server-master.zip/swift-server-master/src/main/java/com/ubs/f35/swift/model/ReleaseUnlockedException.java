package com.ubs.f35.swift.model;

import com.ubs.f35.swift.dao.ReleaseDefinition;

public class ReleaseUnlockedException extends ReleaseLogicException {

    private final ReleaseDefinition releaseDef;

    public ReleaseUnlockedException(final ReleaseDefinition releaseDef) {
        super("Release '" + releaseDef.getName() + "' needs to be locked to perform this operation.");
        this.releaseDef = releaseDef;
    }

    public ReleaseDefinition getReleaseDefinition() {
        return releaseDef;
    }

}
