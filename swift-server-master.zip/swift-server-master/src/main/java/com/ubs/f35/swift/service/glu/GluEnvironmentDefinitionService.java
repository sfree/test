package com.ubs.f35.swift.service.glu;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.EnvironmentConfig;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ArtifactConfigurationDao;
import com.ubs.f35.swift.dao.ArtifactDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseDefinitionDao;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.validator.ProductionDeploymentValidator;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.model.ArtifactNotDefinedInEnvException;
import com.ubs.f35.swift.service.EnvironmentDefinitionService;

public class GluEnvironmentDefinitionService implements EnvironmentDefinitionService {
    private static final Logger LOG = LoggerFactory.getLogger(GluEnvironmentDefinitionService.class);

    private ArtifactConfigurationDao artifactConfigurationDao;
    private ReleaseDefinitionDao releaseDefinitionDao;
    private ArtifactDao artifactDao;
    private ProductionDeploymentValidator productionDeploymentValidator;
    private EnvironmentBeanFactory<EnvironmentConfig> envConfigFactory;

    /**
     * This occurs in a new transaction as the updates to the environment should occur before the deployment starts
     * which is potentially a very long operation and should not keep the database transaction open.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @Override
    public List<Artifact> applyRelease(final Integer releaseId, final Integer revision,
            final Set<NexusArtifact> selectedArtifacts, final Environment environment) {
        // Changes to releaseDefRevision will not be persisted as it is obtained from an audit entry
        ReleaseDefinition releaseDefRevision = releaseDefinitionDao.loadRevision(releaseId, revision);

        productionDeploymentValidator.validateProductionReleaseChecks(releaseDefRevision, environment, false);

        if (envConfigFactory.get(environment).isAutoLockOnDeploy()) {
            LOG.info("Automatically locking release {} on deployment to {}", releaseId, environment.getName());
            // Intentionally no activity feed for this as there will already be deployment activity noise
            ReleaseDefinition releaseDefLatest = releaseDefinitionDao.load(releaseId);
            Integer latestRevision = releaseDefLatest.getRevision();
            Integer workingRevision = releaseDefRevision.getRevision();
            if (workingRevision.equals(latestRevision)) {
                LOG.info("Autolocking the release {} because the working revision {} is the latest revision",
                        releaseId,
                        workingRevision);
                releaseDefLatest.setLocked(true);
            } else {
                LOG.info(
                        "Skipping autolocking the release {} because the working revision {} is not the latest revision {}",
                        new Object[] { releaseId, workingRevision, latestRevision });
            }
        }

        List<Artifact> prevVersions = new ArrayList<Artifact>();
        for (Artifact artifact : releaseDefRevision.getArtifacts()) {
            if (selectedArtifacts.contains(artifact.getNexusArtifact())) {
                prevVersions.add(updateEnvironmentDefinitionForArtifact(environment, artifact));
            }
        }

        return prevVersions;
    }

    /**
     * This occurs in a new transaction as the updates to the environment should occur before the deployment starts
     * which is potentially a very long operation and should not keep the database transaction open.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @Override
    public void applyRollback(final List<Artifact> artifacts, final Set<NexusArtifact> selectedArtifacts,
            final Environment env) {
        for (Artifact artifact : artifacts) {
            if (selectedArtifacts.contains(artifact.getNexusArtifact())) {
                updateEnvironmentDefinitionForArtifact(env, artifact);
            }
        }
    }

    /**
     * Updates the environment definition to bring entries associated with the artifact up to date with the latest
     * version.
     * 
     * @param envDef
     * @param artifact
     * @return {@link Artifact} Previous artifact version defined in environment, to be used for rollback
     */
    private Artifact updateEnvironmentDefinitionForArtifact(final Environment environment, final Artifact artifact) {
        // No support for targetted releases yet, all instances in environment are updated!
        List<ArtifactConfig> instances = artifactConfigurationDao.load(environment, artifact.getGroupId(),
                artifact.getArtifactId());

        if (instances.isEmpty()) {
            throw new ArtifactNotDefinedInEnvException(artifact);
        }

        // Must be done before the versions are updated
        Artifact prevVersion = getPreviousVersionToRecord(instances);

        for (ArtifactConfig instance : instances) {
            LOG.info("Updating instance {} {} in environment {} to {}",
                    new Object[] { instance.getName(), instance.getArtifactVersion(), environment,
                            artifact });

            instance.setArtifactVersion(artifact.getVersion());
        }

        return prevVersion;
    }

    private Artifact getPreviousVersionToRecord(final List<ArtifactConfig> instances) {
        final ArtifactConfig instance = instances.get(0);
        Artifact artifact = new Artifact(instance.getGroupId(), instance.getArtifactId(), instance.getArtifactVersion());
        return artifactDao.resolveOrCreatePersistentArtifact(artifact);
    }

    @Required
    public void setArtifactConfigurationDao(final ArtifactConfigurationDao artifactConfigurationDao) {
        this.artifactConfigurationDao = artifactConfigurationDao;
    }

    @Required
    public void setArtifactDao(final ArtifactDao artifactDao) {
        this.artifactDao = artifactDao;
    }

    @Required
    public void setReleaseDefinitionDao(final ReleaseDefinitionDao releaseDefinitionDao) {
        this.releaseDefinitionDao = releaseDefinitionDao;
    }

    @Required
    public void setProductionDeploymentValidator(final ProductionDeploymentValidator productionDeploymentValidator) {
        this.productionDeploymentValidator = productionDeploymentValidator;
    }

    @Required
    public void setEnvConfigFactory(final EnvironmentBeanFactory<EnvironmentConfig> envConfigFactory) {
        this.envConfigFactory = envConfigFactory;
    }
}
