package com.ubs.f35.swift.dao.hibernate;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.RevisionType;
import org.hibernate.envers.query.AuditEntity;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.collect.Lists;
import com.ubs.f35.swift.activity.ActivityFeedWriter;
import com.ubs.f35.swift.dao.DefaultPropertiesDao;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.PropertiesDefault;
import com.ubs.f35.swift.dao.SwiftRevEntry;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.model.Environment;

/**
 * DAO for environment default properties.
 * 
 * @author levyjo
 * 
 */
public class HibernateDefaultPropertiesDao extends HibernateDaoSupport implements DefaultPropertiesDao {

    private ActivityFeedWriter activityFeedWriter;

    @Override
    public List<PropertiesDefault> loadDefaultProperties(final Environment environment) {
        Query query = getSession().createQuery("from PropertiesDefault where environment = :env order by key");
        query.setParameter("env", environment);
        return query.list();
    }

    @Override
    public void setDefaultProperties(final List<PropertiesDefault> properties, final Environment environment) {

        List<PropertiesDefault> current = loadDefaultProperties(environment);

        if (!current.equals(properties)) {

            // Diffs for activity feed
            Set<String> addedProperties = new HashSet<String>();
            Set<String> modifiedProperties = new HashSet<String>();
            Set<String> removedProperties = new HashSet<String>();

            Map<String, String> currentPropsMap = new HashMap<String, String>();
            for (PropertiesDefault pd : current) {
                currentPropsMap.put(pd.getKey(), pd.getValue());
            }
            Set<String> currentKeys = currentPropsMap.keySet();

            // Save new, update pre-existing
            for (PropertiesDefault property : properties) {
                if (currentKeys.contains(property.getKey())) {
                    // Need to merge (not save or update) since the instances loaded in the Hibernate session
                    // are not the same as those passed in from the client.
                    getSession().merge(property);
                    if (!property.getValue().equals(currentPropsMap.get(property.getKey()))) {
                        modifiedProperties.add(property.getKey());
                    }
                } else {
                    getSession().save(property);
                    addedProperties.add(property.getKey());
                }
            }

            // remove deleted properties
            for (PropertiesDefault pd : current) {
                if (!properties.contains(pd)) {
                    getSession().delete(pd);
                    removedProperties.add(pd.getKey());
                }
            }

            activityFeedWriter.modifyPropertyDefaults(environment, addedProperties, modifiedProperties,
                    removedProperties);

        }

    }

    @Override
    public void saveOrUpdateDefaultProperty(final PropertiesDefault property) {
        getSession().saveOrUpdate(property);
        activityFeedWriter.modifyOrCreatePropertyDefault(property.getEnvironment(), property.getKey());
    }

    @Override
    public void removeDefaultProperty(final Environment environment, final String propertykey) {
        removeDefaultProperty(loadDefaultProperty(environment, propertykey));
        activityFeedWriter.removePropertyDefault(environment, propertykey);
    }

    private void removeDefaultProperty(final PropertiesDefault propertiesDefault) {
        getSession().delete(propertiesDefault);
    }

    @Override
    public PropertiesDefault loadDefaultProperty(final Environment environment, final String propertykey) {
        Query query = getSession().createQuery("from PropertiesDefault where environment = :env and key = :key");
        query.setParameter("env", environment);
        query.setParameter("key", propertykey);

        List<PropertiesDefault> result = query.list();
        if (result.size() > 0) {
            return result.get(0);
        } else {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<AuditEntry<PropertiesDefault>> getAuditHistory(final Environment environment,
            final PagingFilter daoFilter) {
        AuditReader reader = AuditReaderFactory.get(getSession());

        List<Object[]> auditHistory = reader.createQuery()
                .forRevisionsOfEntity(PropertiesDefault.class, PropertiesDefault.class.getName(), false, true)
                .addOrder(AuditEntity.revisionNumber().desc())
                .add(AuditEntity.property("id.environment").eq(environment))
                .setFirstResult(daoFilter.getStart())
                .setMaxResults(daoFilter.getRecords())
                .getResultList();

        List<AuditEntry<PropertiesDefault>> auditEntries = Lists.newArrayListWithExpectedSize(auditHistory.size());
        for (Object[] audit : auditHistory) {
            AuditEntry<PropertiesDefault> entry = new AuditEntry<PropertiesDefault>((PropertiesDefault) audit[0],
                    (SwiftRevEntry) audit[1], (RevisionType) audit[2]);

            auditEntries.add(entry);
        }
        return auditEntries;
    }

    @Required
    public void setActivityFeedWriter(final ActivityFeedWriter activityFeedWriter) {
        this.activityFeedWriter = activityFeedWriter;
    }

}
