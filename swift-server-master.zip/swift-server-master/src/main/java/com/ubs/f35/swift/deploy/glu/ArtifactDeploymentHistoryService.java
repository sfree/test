package com.ubs.f35.swift.deploy.glu;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.base.Function;
import com.google.common.base.Optional;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.SetMultimap;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseDefinitionDao;
import com.ubs.f35.swift.dao.model.DeployedArtifact;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.ProcessDetails;
import com.ubs.f35.swift.deploy.glu.rest.ProcessDetailsProvider;
import com.ubs.f35.swift.deploy.glu.state.GluState;
import com.ubs.f35.swift.deploy.glu.state.Transition.TransitionStep;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.service.ArtifactConfigurationService;

public class ArtifactDeploymentHistoryService {
    private static final Logger LOG = LoggerFactory.getLogger(ArtifactDeploymentHistoryService.class);

    private ArtifactConfigurationService artifactConfigurationService;
    private ReleaseDefinitionDao releaseDefinitionDao;
    private EnvironmentBeanFactory<ProcessDetailsProvider> processDetailsProviderFactory;

    /**
     * Updates the deployment with the action performed on each artifact.
     * 
     * @param deployment
     * @param selectedEntries
     * @param entryTransitions
     */
    public void updateDeploymentWithArtifactHistory(final Deployment deployment,
            final SetMultimap<Environment, Entry> selectedEntries,
            final ListMultimap<Entry, TransitionStep> entryTransitions) {

        ReleaseDefinition releaseDef = null;

        if (deployment.getReleaseId() != null) {
            releaseDef = releaseDefinitionDao.loadRevision(deployment.getReleaseId(), deployment.getReleaseRev());
        }

        Map<Environment, EnvDeployment> envDeployIndex = Maps.uniqueIndex(deployment.getEnvDeployments(),
                new Function<EnvDeployment, Environment>() {
                    @Override
                    public Environment apply(final EnvDeployment input) {
                        return input.getEnvironment();
                    }
                });

        for (java.util.Map.Entry<Environment, Entry> envEntry : selectedEntries.entries()) {
            Entry entry = envEntry.getValue();

            Environment environment = envEntry.getKey();
            final ArtifactConfig config = artifactConfigurationService
                    .loadArtifactConfigurationForEntry(environment, entry);

            EnvDeployment envDeploy = envDeployIndex.get(environment);
            if (envDeploy.getDeployedArtifacts() == null) {
                envDeploy.setDeployedArtifacts(Lists.<DeployedArtifact>newArrayList());
            }

            DeployedArtifact deployedArtifact = new DeployedArtifact(config, envDeploy, entry.getAgent());

            DeploymentAction performedAction = derivePerformedAction(entryTransitions.get(entry));
            deployedArtifact.setDeploymentAction(performedAction);

            String artifactVersion = null;
            if (releaseDef != null) {
                // TODO handle rollback deployments (pending merging of pull request for rollback deployments work)
                Optional<Artifact> artifact = Iterables.tryFind(releaseDef.getArtifacts(), new Predicate<Artifact>() {
                    @Override
                    public boolean apply(final Artifact input) {
                        return input.getNexusArtifact().equals(config.getArtifact());
                    }
                });
                if (artifact.isPresent()) {
                    // this artifact is part of the release. The deployment will upgrade it to the new version.
                    artifactVersion = artifact.get().getVersion();
                    if (!artifactVersion.equals(config.getArtifactVersion())) {
                        deployedArtifact.setVersionChanged(true);
                    }
                }
            }

            if (!deployedArtifact.isVersionChanged() && deployment.getDeploymentStatus() == DeploymentStatus.MANUAL) {
                LOG.debug("Not adding artifact {} to deployment history as version is unchanged by manual deployment",
                        deployedArtifact);
                continue;
            }

            if (artifactVersion == null && !isReinstalled(entry, entryTransitions)) {
                // artifact is not being redeployed. Will remain on the same version that is currently deployed.
                artifactVersion = getCurrentState(environment, entry).getVersion();
            }

            if (artifactVersion == null) {
                // for non release artifacts, the artifact will remain on the configured version unless it passes
                // through the deploy_script transition (or is a new artifact being deployed for the first time.
                artifactVersion = config.getArtifactVersion();
            }
            deployedArtifact.setVersion(artifactVersion);

            envDeploy.getDeployedArtifacts().add(deployedArtifact);
        }
    }

    /**
     * Derives the performed action on an artifact. The user may request a bounce, but if the artifact was already
     * stopped, in the history the action performed should be recorded as start. Likewise, a user may request a bounce,
     * deselect the start action which should be reported as a stop. TODO Is there someway to calculate this using the
     * {@link TransitionStep} / {@link GluState} and {@link DeploymentAction} without hard coding this logic?
     */
    private DeploymentAction derivePerformedAction(final List<TransitionStep> transitionsPerformed) {
        if (transitionsPerformed.equals(Arrays.asList(TransitionStep.start))) {
            return DeploymentAction.StartOnly;
        } else if (transitionsPerformed.equals(Arrays.asList(TransitionStep.stop))) {
            return DeploymentAction.Stop;
        } else if (Iterables.getLast(transitionsPerformed) == TransitionStep.remove_script) {
            return DeploymentAction.Undeploy;
        } else if (transitionsPerformed.contains(TransitionStep.remove_script)) {
            return DeploymentAction.Redeploy;
        } else if (transitionsPerformed.equals(Arrays.asList(TransitionStep.stop, TransitionStep.start))) {
            return DeploymentAction.Bounce;
        } else if (Iterables.getLast(transitionsPerformed) == TransitionStep.start) {
            return DeploymentAction.Start;
        }

        LOG.warn("Failed to calculate deployment action for sequence of transitions {}", transitionsPerformed);
        return DeploymentAction.Start;
    }

    /**
     * If the script is being deployed, then it's a fresh installation. If it doesn't pass through this step, then we
     * are still working with the previous version of the artifact.
     */
    private boolean isReinstalled(final Entry entry, final ListMultimap<Entry, TransitionStep> entryTransitions) {
        return entryTransitions.get(entry).contains(TransitionStep.deploy_script);
    }

    private ProcessDetails getCurrentState(final Environment environment, final Entry entry) {
        ProcessDetailsProvider processDetailsProvider = processDetailsProviderFactory.get(environment);

        return processDetailsProvider.getCurrentProcessState(entry);
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }

    @Required
    public void setReleaseDefinitionDao(final ReleaseDefinitionDao releaseDefinitionDao) {
        this.releaseDefinitionDao = releaseDefinitionDao;
    }

    @Required
    public void setProcessDetailsProviderFactory(
            final EnvironmentBeanFactory<ProcessDetailsProvider> processDetailsProviderFactory) {
        this.processDetailsProviderFactory = processDetailsProviderFactory;
    }

}
