package com.ubs.f35.swift.dao.hibernate;

import java.util.Calendar;
import java.util.UUID;

import org.hibernate.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.f35.swift.dao.StateDao;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.model.StateModel;

public class HibernateStateDao extends HibernateDaoSupport implements StateDao {
    private static final Logger LOG = LoggerFactory.getLogger(HibernateStateDao.class);

    @Override
    public StateModel load(final UUID stateId) {
        return loadExpected(StateModel.class, stateId);
    }

    @Override
    public void save(final StateModel stateModel) {
        getSession().save(stateModel);
    }

    /**
     * Scheduled job runs every hour
     */
    @Transactional
    public void purgeOldState() {
        int deleteCount = executeDeleteQuery(
                "delete from StateModel where expiry < :currentTime)",
                Calendar.getInstance());

        LOG.info("Purged {} old state data records", deleteCount);
    }

    private int executeDeleteQuery(final String deleteStatement, final Calendar cal) {
        Query query = getSession().createQuery(deleteStatement);
        query.setCalendarDate("currentTime", cal);
        return query.executeUpdate();
    }

}