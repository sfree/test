package com.ubs.f35.swift.deploy.glu.action;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

/**
 * Groups a set of actions which can be included or excluded from a deployment plan. These actions can be executed in
 * parallel.
 */
public class ParallelAction extends BaseGroupedAction {

    public ParallelAction(@JsonProperty(value = "id") final String id,
            @JsonProperty(value = "name") final String name,
            @JsonProperty(value = "included") final List<Action> includedActions) {
        super(id, name, includedActions);
    }

}
