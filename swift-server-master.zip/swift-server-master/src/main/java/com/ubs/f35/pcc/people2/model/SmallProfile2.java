package com.ubs.f35.pcc.people2.model;

/**
 * @author krestieg
 */
public class SmallProfile2 {

    private boolean employee;
    private String guid;

    private String businessName;
    private String firstName;
    private String lastName;
    private String businessTitle;
    /**
     * Country code (employees) or Legal jurisdiction (clients)
     */
    private String countryCode;
    private String workPhone;
    private String mobilePhone;
    private String assistantPhone;
    private String email;

    // Employee specific properties
    private String gpn;

    // Client specific properties
    private String clientId;
    private String companyName;

    public SmallProfile2() {
    }

    public SmallProfile2(final String guid) {
        this.guid = guid;
    }

    public boolean isEmployee() {
        return employee;
    }

    public void setEmployee(final boolean employee) {
        this.employee = employee;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(final String guid) {
        this.guid = guid;
    }

    public String getGpn() {
        return gpn;
    }

    public void setGpn(final String gpn) {
        this.gpn = gpn;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(final String businessName) {
        this.businessName = businessName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(final String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }

    public String getBusinessTitle() {
        return businessTitle;
    }

    public void setBusinessTitle(final String businessTitle) {
        this.businessTitle = businessTitle;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(final String countryCode) {
        this.countryCode = countryCode;
    }

    public String getWorkPhone() {
        return workPhone;
    }

    public void setWorkPhone(final String workPhone) {
        this.workPhone = workPhone;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(final String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getAssistantPhone() {
        return assistantPhone;
    }

    public void setAssistantPhone(final String assistantPhone) {
        this.assistantPhone = assistantPhone;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(final String clientId) {
        this.clientId = clientId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(final String companyName) {
        this.companyName = companyName;
    }

    @Override
    public String toString() {
        return "SmallProfile2 [employee=" + employee + ", guid=" + guid + ", businessName=" + businessName
                + ", firstName=" + firstName + ", lastName=" + lastName + ", businessTitle=" + businessTitle
                + ", countryCode=" + countryCode + ", workPhone=" + workPhone + ", mobilePhone=" + mobilePhone
                + ", assistantPhone=" + assistantPhone + ", gpn=" + gpn + ", clientId=" + clientId + ", companyName="
                + companyName + "]";
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(final String email) {
        this.email = email;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SmallProfile2 that = (SmallProfile2) o;

        if (employee != that.employee) {
            return false;
        }
        if (assistantPhone != null ? !assistantPhone.equals(that.assistantPhone) : that.assistantPhone != null) {
            return false;
        }
        if (businessName != null ? !businessName.equals(that.businessName) : that.businessName != null) {
            return false;
        }
        if (businessTitle != null ? !businessTitle.equals(that.businessTitle) : that.businessTitle != null) {
            return false;
        }
        if (clientId != null ? !clientId.equals(that.clientId) : that.clientId != null) {
            return false;
        }
        if (companyName != null ? !companyName.equals(that.companyName) : that.companyName != null) {
            return false;
        }
        if (countryCode != null ? !countryCode.equals(that.countryCode) : that.countryCode != null) {
            return false;
        }
        if (email != null ? !email.equals(that.email) : that.email != null) {
            return false;
        }
        if (firstName != null ? !firstName.equals(that.firstName) : that.firstName != null) {
            return false;
        }
        if (gpn != null ? !gpn.equals(that.gpn) : that.gpn != null) {
            return false;
        }
        if (guid != null ? !guid.equals(that.guid) : that.guid != null) {
            return false;
        }
        if (lastName != null ? !lastName.equals(that.lastName) : that.lastName != null) {
            return false;
        }
        if (mobilePhone != null ? !mobilePhone.equals(that.mobilePhone) : that.mobilePhone != null) {
            return false;
        }
        if (workPhone != null ? !workPhone.equals(that.workPhone) : that.workPhone != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = (employee ? 1 : 0);
        result = 31 * result + (guid != null ? guid.hashCode() : 0);
        result = 31 * result + (businessName != null ? businessName.hashCode() : 0);
        result = 31 * result + (firstName != null ? firstName.hashCode() : 0);
        result = 31 * result + (lastName != null ? lastName.hashCode() : 0);
        result = 31 * result + (businessTitle != null ? businessTitle.hashCode() : 0);
        result = 31 * result + (countryCode != null ? countryCode.hashCode() : 0);
        result = 31 * result + (workPhone != null ? workPhone.hashCode() : 0);
        result = 31 * result + (mobilePhone != null ? mobilePhone.hashCode() : 0);
        result = 31 * result + (assistantPhone != null ? assistantPhone.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (gpn != null ? gpn.hashCode() : 0);
        result = 31 * result + (clientId != null ? clientId.hashCode() : 0);
        result = 31 * result + (companyName != null ? companyName.hashCode() : 0);
        return result;
    }
}
