package com.ubs.f35.swift.processor;

import static com.ubs.f35.swift.processor.ProcessorUtil.resolveEnvironments;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Objects;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.OrganisationConfig;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ArtifactPropertiesCount;
import com.ubs.f35.swift.dao.ArtifactPropertiesDao;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseDefinitionDao;
import com.ubs.f35.swift.dao.StateStore;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.model.TargetedInstanceDeployment;
import com.ubs.f35.swift.model.TargetedInstanceDeployment.ArtifactId;
import com.ubs.f35.swift.model.TargetedInstanceDeployment.TargetedArtifactDeployment;
import com.ubs.f35.swift.processor.ReleaseDeploymentPreparationProcessor.EnvironmentPropertiesConfigured.PropertiesSet;
import com.ubs.f35.swift.processor.ReleaseDeploymentStep.Step;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.service.ArtifactConfigurationService;

/**
 * Creating a deployment follows this pattern for each target environment.
 * <ul>
 * <li>Update environment model to reflect desired target state</li>
 * <li>Commit updated environment model back to store</li>
 * <li>Execute actions to resolve the delta of differences between the current state and new desired state</li>
 * </ul>
 * 
 * @author stephelu
 * 
 */

@Transactional
@Controller
@RequestMapping(value = "/api/releaseprep")
public class ReleaseDeploymentPreparationProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(ReleaseDeploymentPreparationProcessor.class);

    private ReleaseDefinitionDao releaseDefinitionDao;
    private AuthorisationController authorisationController;
    private ArtifactConfigurationService artifactConfigurationService;
    private EnvironmentDao environmentDao;
    private ArtifactPropertiesDao artifactPropertiesDao;
    private StateStore stateStore;

    private OrganisationBeanFactory<List<String>> orgEnvironmentsMap;
    private OrganisationBeanFactory<OrganisationConfig> orgConfigFactory;

    @RequestMapping(value = "/prepare/{releaseId}", method = RequestMethod.GET)
    public ReleaseDeploymentStep prepareRelease(@PathVariable final Integer releaseId,
            @RequestParam(value = "environment", required = true) final List<String> environments,
            @RequestParam(value = "skipPropertiesCheck", defaultValue = "false") final boolean skipPropertiesCheck,
            @RequestParam(value = "revision", required = false) final Integer revision,
            @RequestParam(value = "deploymentContextId", required = false) final UUID deploymentContextId) {

        ReleaseDefinition release = loadLatestReleaseOrRevision(releaseId, revision);

        if (CollectionUtils.isEmpty(release.getArtifacts())) {
            throw new IllegalStateException("Artifacts must be added to release before it can be deployed");
        }

        List<Environment> envs = resolveEnvironments(environmentDao, environments, release);

        for (final Environment env : envs) {
            authorisationController.checkEnvironmentAccess(env);

            if (orgConfigFactory.get(env.getOrganisation().getName()).isEnableTargetedDeployments()) {

                LOG.debug("Targeted deployments are enabled.");

                TargetedInstanceDeployment envTargets = null;
                if (deploymentContextId != null) {
                    ReleaseDeloymentRequest releaseDeploymentRequest = stateStore.load(deploymentContextId,
                            ReleaseDeloymentRequest.class);

                    envTargets = Iterables.tryFind(releaseDeploymentRequest.getDeploymentTargets(),
                            new Predicate<TargetedInstanceDeployment>() {
                                @Override
                                public boolean apply(final TargetedInstanceDeployment input) {
                                    return input.getEnvironment().equals(env.getName());
                                }
                            }).orNull();
                }

                if (envTargets == null) {
                    LOG.debug("No deployment targets present on request. Setting step to SelectTargets.");

                    List<TargetedArtifactDeployment> targetInstances = new ArrayList<>();
                    // Populate the selected deployment targets for each artifact.
                    for (Artifact releaseArtifact : release.getArtifacts()) {
                        List<ArtifactConfig> configuredArtifacts = artifactConfigurationService.load(env,
                                releaseArtifact);
                        List<String> suggestedInstances;
                        // if nothing configured, suggest the DEFAULT instance (unless the artifact has been flagged as
                        // do not deploy).
                        if (CollectionUtils.isEmpty(configuredArtifacts)) {
                            suggestedInstances = Arrays.asList(ArtifactConfig.DEFAULT_INSTANCE_NAME);
                        } else {
                            suggestedInstances = new ArrayList<>();
                            for (ArtifactConfig configuredInstance : configuredArtifacts) {
                                suggestedInstances.add(configuredInstance.getName());
                            }
                        }
                        ArtifactId artifactId = new ArtifactId();
                        artifactId.setGroupId(releaseArtifact.getGroupId());
                        artifactId.setArtifactId(releaseArtifact.getArtifactId());

                        TargetedArtifactDeployment targetDeployment = new TargetedArtifactDeployment();
                        targetDeployment.setArtifact(artifactId);
                        targetDeployment.setInstanceNames(suggestedInstances);

                        targetInstances.add(targetDeployment);
                    }

                    envTargets = new TargetedInstanceDeployment();
                    envTargets.setEnvironment(env.getName());
                    envTargets.setTargetedArtifactDeployments(targetInstances);

                    // Prompt for deployment targets of one environment.
                    return new ReleaseDeploymentStep(Step.SelectTargets, envTargets);
                }

                // If targets have been specified, only get unconfigured targets.
                Map<Artifact, List<String>> requiredArtifactInstances = new HashMap<>();
                for (final Artifact artifact : release.getArtifacts()) {
                    TargetedArtifactDeployment artifactInstances = Iterables.find(
                            envTargets.getTargetedArtifactDeployments(),
                            new Predicate<TargetedArtifactDeployment>() {
                                @Override
                                public boolean apply(final TargetedArtifactDeployment input) {
                                    return input.getArtifact().getGroupId().equals(artifact.getGroupId()) &&
                                            input.getArtifact().getArtifactId().equals(artifact.getArtifactId());
                                }
                            });
                    requiredArtifactInstances.put(artifact, artifactInstances.getInstanceNames());
                }

                List<ArtifactConfig> suggestedArtifactConfigs =
                        artifactConfigurationService.getUnconfiguredArtifacts(env, requiredArtifactInstances);
                if (!suggestedArtifactConfigs.isEmpty()) {
                    return new ReleaseDeploymentStep(Step.Configure, suggestedArtifactConfigs);
                }
            }
            else {
                // For non targeted deployment organisations,
                List<ArtifactConfig> suggestedArtifactConfigs = artifactConfigurationService.getUnconfiguredArtifacts(
                        env, release.getArtifacts());
                if (!suggestedArtifactConfigs.isEmpty()) {
                    return new ReleaseDeploymentStep(Step.Configure, suggestedArtifactConfigs);
                }
            }
        }

        if (!skipPropertiesCheck) {
            List<ArtifactPropertiesConfigured> releaseArtifactsStatus = getReleaseArtifactPropertyStatus(releaseId,
                    environments, revision);
            boolean missingProps = Iterables.any(releaseArtifactsStatus, new Predicate<ArtifactPropertiesConfigured>() {
                @Override
                public boolean apply(final ArtifactPropertiesConfigured input) {
                    for (EnvironmentPropertiesConfigured envProps : input.getEnvironmentPropertiesConfigured()) {
                        if (envProps.getPropertiesSet() == PropertiesSet.None) {
                            return true;
                        }
                    }
                    return false;
                }
            });

            if (missingProps) {
                return new ReleaseDeploymentStep(Step.Properties);
            }
        }

        return new ReleaseDeploymentStep(Step.Deploy);
    }

    /**
     * Updates the artifact instance targets for a release deployment in an environment. If not provided a
     * {@code deploymentContextId} will be generated.
     * 
     * @param releaseId
     * @param deploymentContextId
     * @param targetedInstanceDeployment
     * @return
     */
    @RequestMapping(value = "/prepare/{releaseId}", method = RequestMethod.POST)
    public UUID updateReleaseDeploymentTargets(@PathVariable final Integer releaseId,
            @RequestParam(value = "deploymentContextId", required = false) final UUID deploymentContextId,
            @RequestBody final TargetedInstanceDeployment targetedInstanceDeployment) {
        // TODO validate releaseId against the request? If so would also need the revision to verify targeted artifacts
        // are correct for the release revision specified
        ReleaseDeloymentRequest request;
        if (deploymentContextId == null) {
            request = new ReleaseDeloymentRequest();
            request.setDeploymentTargets(new ArrayList<TargetedInstanceDeployment>());
        } else {
            request = stateStore.load(deploymentContextId, ReleaseDeloymentRequest.class);
        }

        request.getDeploymentTargets().add(targetedInstanceDeployment);

        return stateStore.createOrUpdate(deploymentContextId, request);
    }

    @RequestMapping(value = "/propertystatus/{releaseId}/artifact", method = RequestMethod.GET)
    @ResponseBody
    public List<ArtifactPropertiesConfigured> getReleaseArtifactPropertyStatus(@PathVariable final Integer releaseId,
            @RequestParam(value = "environment", required = false) final List<String> environments,
            @RequestParam(value = "revision", required = false) final Integer revision) {

        DaoConvertor<List<ArtifactPropertiesConfigured>> daoConvertor = new DaoConvertor<List<ArtifactPropertiesConfigured>>() {
            @Override
            public List<ArtifactPropertiesConfigured> convert(final List<Artifact> artifactsWithProperties,
                    final List<ArtifactPropertiesCount> savedProperties, final List<Environment> envs) {
                List<ArtifactPropertiesConfigured> artifactPropertiesConfigured = Lists.newArrayList();
                for (final Artifact artifactWithProperties : artifactsWithProperties) {
                    List<EnvironmentPropertiesConfigured> configuredEnvs = Lists.newArrayList();
                    for (final Environment env : envs) {
                        PropertiesSet propertiesSet;
                        if (artifactConfigurationService.isArtifactDeployedToEnvironment(
                                artifactWithProperties.getNexusArtifact(), env)) {
                            boolean propsConfigured = artifactExists(savedProperties, env, artifactWithProperties);

                            propertiesSet = propsConfigured ? PropertiesSet.Ready : PropertiesSet.None;
                        } else {
                            propertiesSet = PropertiesSet.NotRequired;
                        }
                        configuredEnvs.add(new EnvironmentPropertiesConfigured(env, propertiesSet));
                    }
                    artifactPropertiesConfigured.add(new ArtifactPropertiesConfigured(artifactWithProperties,
                            configuredEnvs));
                }
                return artifactPropertiesConfigured;
            }
        };

        return loadReleasePropertyStatus(releaseId, revision, environments, daoConvertor);
    }

    private ReleaseDefinition loadLatestReleaseOrRevision(final Integer releaseId, final Integer revision) {
        if (revision == null) {
            return releaseDefinitionDao.load(releaseId);
        } else {
            return releaseDefinitionDao.loadRevision(releaseId, revision);
        }
    }

    private <T> T loadReleasePropertyStatus(final Integer releaseId, final Integer revision, List<String> environments,
            final DaoConvertor<T> daoConvertor) {

        ReleaseDefinition release = loadLatestReleaseOrRevision(releaseId, revision);
        if (CollectionUtils.isEmpty(environments)) {
            environments = orgEnvironmentsMap.get(release.getTeam().getOrganisation().getName());
        }
        final List<Environment> envs = resolveEnvironments(environmentDao, environments, release);

        List<Artifact> artifactsWithProperties = Lists.newArrayList();
        for (Artifact releaseArtifact : release.getArtifacts()) {
            if (artifactConfigurationService.hasZooKeeperProperties(releaseArtifact)) {
                artifactsWithProperties.add(releaseArtifact);
            }
        }

        List<ArtifactPropertiesCount> savedProperties = Collections.emptyList();
        if (!artifactsWithProperties.isEmpty()) {
            savedProperties = artifactPropertiesDao.loadSavedPropertiesCount(artifactsWithProperties, envs);
        }

        return daoConvertor.convert(artifactsWithProperties, savedProperties, envs);
    }

    interface DaoConvertor<T> {
        /**
         * Call back to convert the dao representation of artifact saved properties per environment to a more client
         * friendly format for the current request
         * 
         * @param artifactsWithProperties
         *            All artifacts requiring zookeeper properties
         * @param savedProperties
         *            Artifacts with saved zookeeper properties
         * @param envs
         *            Filter environments.
         * @return
         */
        T convert(List<Artifact> artifactsWithProperties, List<ArtifactPropertiesCount> savedProperties,
                List<Environment> envs);
    }

    private static boolean artifactExists(final List<ArtifactPropertiesCount> savedProperties, final Environment env,
            final Artifact artifactWithProperties) {
        return Iterables.tryFind(savedProperties, new Predicate<ArtifactPropertiesCount>() {
            @Override
            public boolean apply(final ArtifactPropertiesCount input) {
                return input.getEnvironmentId().equals(env.getId())
                        && input.getArtifactId().equals(artifactWithProperties.getId());
            }
        }).isPresent();
    }

    public static class ArtifactPropertiesConfigured {
        private final Artifact artifact;
        private final List<EnvironmentPropertiesConfigured> environmentPropertiesConfigured;

        public ArtifactPropertiesConfigured(final Artifact artifact,
                final List<EnvironmentPropertiesConfigured> environmentPropertiesConfigured) {
            this.artifact = artifact;
            this.environmentPropertiesConfigured = environmentPropertiesConfigured;
        }

        public Artifact getArtifact() {
            return artifact;
        }

        public List<EnvironmentPropertiesConfigured> getEnvironmentPropertiesConfigured() {
            return environmentPropertiesConfigured;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(artifact, environmentPropertiesConfigured);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof ArtifactPropertiesConfigured) {
                ArtifactPropertiesConfigured that = (ArtifactPropertiesConfigured) object;
                return Objects.equal(this.artifact, that.artifact)
                        && Objects.equal(this.environmentPropertiesConfigured, that.environmentPropertiesConfigured);
            }
            return false;
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this)
                    .add("artifact", artifact)
                    .add("environmentPropertiesConfigured", environmentPropertiesConfigured)
                    .toString();
        }
    }

    public static class EnvironmentPropertiesConfigured {
        enum PropertiesSet {
            None, Ready, NotRequired
        }

        private final Environment environment;
        private final PropertiesSet propertiesSet;

        public EnvironmentPropertiesConfigured(final Environment environment, final PropertiesSet propertiesSet) {
            this.environment = environment;
            this.propertiesSet = propertiesSet;
        }

        public String getEnvironment() {
            return environment.getName();
        }

        public PropertiesSet getPropertiesSet() {
            return propertiesSet;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(environment, propertiesSet);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof EnvironmentPropertiesConfigured) {
                EnvironmentPropertiesConfigured that = (EnvironmentPropertiesConfigured) object;
                return Objects.equal(this.environment, that.environment)
                        && Objects.equal(this.propertiesSet, that.propertiesSet);
            }
            return false;
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this)
                    .add("environment", environment)
                    .add("propertiesSet", propertiesSet)
                    .toString();
        }
    }

    @Required
    public void setReleaseDefinitionDao(final ReleaseDefinitionDao releaseDefinitionDao) {
        this.releaseDefinitionDao = releaseDefinitionDao;
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }

    @Required
    public void setArtifactPropertiesDao(final ArtifactPropertiesDao artifactPropertiesDao) {
        this.artifactPropertiesDao = artifactPropertiesDao;
    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }

    @Required
    public void setOrgEnvironmentsMap(final OrganisationBeanFactory<List<String>> orgEnvironmentsMap) {
        this.orgEnvironmentsMap = orgEnvironmentsMap;
    }

    @Required
    public void setOrgConfigFactory(final OrganisationBeanFactory<OrganisationConfig> orgConfigFactory) {
        this.orgConfigFactory = orgConfigFactory;
    }

    @Required
    public void setStateStore(final StateStore stateStore) {
        this.stateStore = stateStore;
    }
}
