package com.ubs.f35.swift.deploy.glu.rest;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.ResponseErrorHandler;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

/**
 * Map errors returned by the glu agent onto exceptions.
 * 
 */
public class GluResponseErrorHandler implements ResponseErrorHandler {
    private static final Logger LOG = LoggerFactory.getLogger(GluResponseErrorHandler.class);

    private static final String NO_SUCH_MOUNT_POINT = "org.linkedin.glu.agent.api.NoSuchMountPointException";

    private final MappingJacksonHttpMessageConverter convertor = new MappingJacksonHttpMessageConverter();

    private ResponseErrorHandler defaultHandler = new DefaultResponseErrorHandler();

    @Override
    public boolean hasError(final ClientHttpResponse response) throws IOException {
        return defaultHandler.hasError(response);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public void handleError(final ClientHttpResponse response) throws IOException {
        HttpHeaders headers = response.getHeaders();

        MediaType contentType = headers.getContentType();

        if (MediaType.APPLICATION_JSON.includes(contentType)) {
            Map<String, Object> errorResponse = (Map) convertor.read(Map.class, response);

            List<ExceptionDetails> errorDetails = extractErrorDetailsFromResponse(errorResponse);

            String singleMessage = singleError(errorDetails);

            if (Iterables.any(errorDetails, new ExceptionTypePredicate(NO_SUCH_MOUNT_POINT))) {
                throw new NoSuchMountPointException("No mountpoint found: " + singleMessage);
            }

            throw new GluHttpClientErrorException(singleMessage, errorDetails, response.getStatusCode(),
                    errorResponse);
        }
        else {
            defaultHandler.handleError(response);
        }
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    private List<ExceptionDetails> extractErrorDetailsFromResponse(final Map errorResponse) {
        try {
            List<ExceptionDetails> errorDetails = Lists.newArrayList();
            List<Map<String, Object>> exceptions = (List) errorResponse.get("exception");
            if (!CollectionUtils.isEmpty(exceptions)) {
                for (Map<String, Object> exceptionDetails : exceptions) {
                    String type = Objects.firstNonNull((String) exceptionDetails.get("name"), "Unknown Exception");
                    String message = Objects.firstNonNull((String) exceptionDetails.get("message"), "no details");
                    errorDetails.add(new ExceptionDetails(type, message));
                }
            }
            return errorDetails;
        } catch (RuntimeException ex) {
            LOG.info("Unable to extract error message from response", ex);
            return Collections.singletonList(new ExceptionDetails("unknown error", "check the logs"));
        }
    }

    public static class ExceptionDetails {
        String type;
        String message;

        public ExceptionDetails(final String type, final String message) {
            this.type = type;
            this.message = message;
        }

        @Override
        public String toString() {
            return type + " : " + message;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(type, message);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof ExceptionDetails) {
                ExceptionDetails that = (ExceptionDetails) object;
                return Objects.equal(this.type, that.type)
                        && Objects.equal(this.message, that.message);
            }
            return false;
        }
    }

    private static String singleError(final List<ExceptionDetails> errorDetails) {
        return StringUtils.collectionToDelimitedString(errorDetails, ", ");
    }

    @VisibleForTesting
    void setDefaultHandler(final ResponseErrorHandler defaultHandler) {
        this.defaultHandler = defaultHandler;
    }

}
