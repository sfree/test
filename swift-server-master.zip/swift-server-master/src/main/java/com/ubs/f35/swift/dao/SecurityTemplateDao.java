package com.ubs.f35.swift.dao;

import java.util.List;

import com.ubs.f35.swift.dao.model.SecurityTemplate;

public interface SecurityTemplateDao {

    void createOrUpdate(SecurityTemplate template);

    SecurityTemplate load(String securityTemplateId);

    List<String> getIds();

}
