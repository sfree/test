package com.ubs.f35.swift.dao.model;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.NaturalId;
import org.hibernate.envers.Audited;

import com.google.common.base.Objects;

/**
 * Represents a single environment which deployments can be made to.
 * <p>
 * Note that it is extremely likely that different organisations will have environments with the same names.
 * <p>
 * Note that id is intentionally not used in {@link #equals(Object)} and {@link #hashCode()} so that instances of this
 * object can be used as the keys of Maps.
 * <p>
 * Ideally the properties of this class would have been marked final, but this class is deserialised by 29west magic
 * which requires the setters as constructor injection is not supported (without writing a custom serialiser).
 * 
 * @author stephelu
 * 
 */
@Entity
@Table(name = "environments")
@SequenceGenerator(name = "oracle_seq", sequenceName = "seq_env_id")
@Audited
@BatchSize(size = 25)
public class Environment implements Configurable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "oracle_seq")
    private Integer id;
    @NaturalId
    private String name;
    @NaturalId
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn
    private Organisation organisation;
    // Do not reference this property in hashcode, equals, etc. Doing so will initialise it.
    // Note that this requires bytecode instrumentation which is applied to this class by maven.
    @Column
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonIgnore
    private String configuration;

    /**
     * For hibernate deserialization. Do NOT USE
     */
    @Deprecated
    public Environment() {
        this(null, null, (Organisation) null);
    }

    public Environment(@JsonProperty("id") final Integer id,
            @JsonProperty("name") final String name,
            @JsonProperty("organisation") final Organisation organisation) {
        this.id = id;
        this.name = name;
        this.organisation = organisation;
    }

    public Environment(final String name, final Organisation organisation) {
        this(null, name, organisation);
    }

    public Environment(final String envName, final String organisationName) {
        this(null, envName, createOrg(organisationName));
    }

    private static Organisation createOrg(final String organisationName) {
        Organisation org = new Organisation();
        org.setName(organisationName);
        return org;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Organisation getOrganisation() {
        return organisation;
    }

    @Deprecated
    public void setId(final Integer id) {
        this.id = id;
    }

    @Deprecated
    public void setName(final String name) {
        this.name = name;
    }

    @Deprecated
    public void setOrganisation(final Organisation organisation) {
        this.organisation = organisation;
    }

    @Override
    public String getConfiguration() {
        return configuration;
    }

    @Override
    public void setConfiguration(final String configuration) {
        this.configuration = configuration;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, organisation);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof Environment) {
            Environment that = (Environment) object;
            return Objects.equal(this.name, that.getName()) &&
                    Objects.equal(this.organisation, that.getOrganisation());
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("name", name)
                .add("organisation", organisation)
                .toString();
    }

}
