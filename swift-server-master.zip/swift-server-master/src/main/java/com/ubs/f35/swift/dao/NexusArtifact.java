package com.ubs.f35.swift.dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Organisation;

@Entity
@Table(name = "NEXUS_ARTIFACTS")
public class NexusArtifact implements Serializable {
    @Id
    @Column(name = "group_id", updatable = false)
    private final String groupId;
    @Id
    @Column(name = "artifact_id", updatable = false)
    private final String artifactId;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "NEXUS_ARTIFACTS_ORGANISATIONS",
            joinColumns = { @JoinColumn(name = "group_id", referencedColumnName = "group_id"),
                    @JoinColumn(name = "artifact_id", referencedColumnName = "artifact_id") },
            inverseJoinColumns = { @JoinColumn(name = "organisation_id", referencedColumnName = "id") })
    @JsonIgnore
    private List<Organisation> organisations;

    /**
     * The nexus instance is persisted so that when versions of this artifact need to be retrieved, we know which nexus
     * instance to source them from.
     */
    @Column(name = "nexus_instance", nullable = false)
    private String nexusInstance;

    /**
     * For hibernate deserialization. Do NOT USE
     */
    @Deprecated
    public NexusArtifact() {
        this(null, null);
    }

    public NexusArtifact(final String groupId, final String artifactId) {
        this.groupId = groupId;
        this.artifactId = artifactId;
    }

    public String getGroupId() {
        return groupId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    public List<Organisation> getOrganisations() {
        return organisations;
    }

    public void setOrganisations(final List<Organisation> organisations) {
        this.organisations = organisations;
    }

    public String getNexusInstance() {
        return nexusInstance;
    }

    public void setNexusInstance(final String nexusInstance) {
        this.nexusInstance = nexusInstance;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("groupId", groupId)
                .add("artifactId", artifactId)
                .add("nexusInstance", nexusInstance)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(groupId, artifactId);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof NexusArtifact) {
            NexusArtifact that = (NexusArtifact) object;
            return Objects.equal(this.groupId, that.groupId)
                    && Objects.equal(this.artifactId, that.artifactId);
        }
        return false;
    }

}
