package com.ubs.f35.swift.document;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionOperations;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.DeployTag;
import com.ubs.f35.swift.config.model.EnvironmentConfig;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.ArtifactConfigurationDao;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.HostDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.event.ArtifactConfigurationChangeListener;
import com.ubs.f35.swift.dao.event.HostChangeListener;
import com.ubs.f35.swift.dao.event.OrganisationChangeListener;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.Organisation;
import com.ubs.f35.swift.deploy.glu.rest.ProcessStateChangeListener;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.model.IndexEntry.EntryType;
import com.ubs.f35.swift.model.State.StateLevel;
import com.ubs.f35.swift.service.glu.EntryMatchesAgentsPredicate;
import com.ubs.f35.swift.service.glu.EntryMatchesGroupArtifactPredicate;
import com.ubs.f35.swift.service.glu.EntryMatchesMountPointPredicate;

/**
 * Provides quick access to environment configuration details.
 * 
 * @author stephelu
 * 
 */
@ManagedResource
public class EnvironmentDocumentStore implements ArtifactConfigurationChangeListener, HostChangeListener,
        OrganisationChangeListener {
    private static final Logger LOG = LoggerFactory.getLogger(EnvironmentDocumentStore.class);

    private ArtifactConfigurationDao artifactConfigurationDao;
    private HostDao hostDao;
    private EnvironmentDao environmentDao;
    private ArtifactEntryConvertor artifactEntryConvertor;
    private List<ProcessStateChangeListener> processStateChangeListeners;
    private TransactionOperations transactionTemplate;
    private OrganisationIndex organisationIndex;
    private EnvironmentBeanFactory<EnvironmentConfig> envConfigFactory;

    private volatile Set<Environment> environments = Collections.emptySet();
    private volatile Map<Environment, EnvironmentDefinition> envDefs;
    private volatile Map<DeployTag, Collection<Host>> hostsMap;

    public boolean isProdEnvironment(final Environment environment) {
        return envConfigFactory.get(environment).isProductionEnvironment();
    }

    public List<Environment> getProductionEnvironments() {
        ensureInitialised();
        return Lists.newArrayList(Iterables.filter(envDefs.keySet(), new Predicate<Environment>() {
            @Override
            public boolean apply(final Environment input) {
                return isProdEnvironment(input);
            }
        }));
    }

    /**
     * Allows the env defs to be explicitly recalculated after external db changes.
     */
    @ManagedOperation(description = "Refreshes the environment definitions")
    @Transactional(readOnly = true)
    public void refresh() {
        initialise();
    }

    private void ensureInitialised() {
        if (envDefs == null) {
            synchronized (this) {
                if (envDefs == null) {
                    transactionTemplate.execute(new TransactionCallbackWithoutResult() {
                        @Override
                        protected void doInTransactionWithoutResult(final TransactionStatus status) {
                            initialise();
                        }
                    });
                }
            }
        }
    }

    private synchronized void initialise() {
        initialiseHostsMap();

        List<ArtifactConfig> artifacts = artifactConfigurationDao.loadAll();

        HashMultimap<Environment, Entry> envEntriesMap = HashMultimap.create();

        for (ArtifactConfig instance : artifacts) {
            List<Entry> entries = artifactEntryConvertor.convert(instance, hostsMap);
            envEntriesMap.putAll(instance.getEnvironment(), entries);
            addArtifactToIndex(instance, entries);
        }

        Map<Environment, Collection<Entry>> envMap = envEntriesMap.asMap();

        Map<Environment, EnvironmentDefinition> envBuilder = Maps.newHashMap();
        for (java.util.Map.Entry<Environment, Collection<Entry>> envEntries : envMap.entrySet()) {
            Environment environment = envEntries.getKey();
            EnvironmentDefinition envDef = new EnvironmentDefinition(environment, Lists.newArrayList(envEntries
                    .getValue()));
            envBuilder.put(environment, envDef);
        }

        this.envDefs = envBuilder;

        for (StateLevel state : StateLevel.values()) {
            organisationIndex.add(state.name(), EntryType.state);
        }
    }

    private void initialiseHostsMap() {
        List<Host> hosts = hostDao.loadAll();
        HashMultimap<DeployTag, Host> tagHostMap = HashMultimap.create();

        for (Host host : hosts) {
            if (!environments.contains(host.getEnvironment())) {
                LOG.info("Ignoring host {} as not in list of managed environments", host);
                continue;
            }
            for (DeployTag tag : host.getDeployTags()) {
                tagHostMap.put(tag, host);
            }
            organisationIndex.add(host.getEnvironment(), host.getHostname(), EntryType.host);
        }

        this.hostsMap = tagHostMap.asMap();
    }

    @VisibleForTesting
    EnvironmentDefinition readFromStore(final Environment environment) {
        ensureInitialised();

        EnvironmentDefinition envDef = envDefs.get(environment);
        if (envDef == null) {
            envDef = new EnvironmentDefinition(environment, Lists.<Entry>newArrayList());
        }
        return envDef;
    }

    /**
     * Handles an update to an {@link ArtifactConfig}. Some mount points may be removed as a result of this operation.
     * 
     * @param config
     */
    @Override
    public synchronized void afterUpdate(final ArtifactConfig config) {
        ensureInitialised();

        Environment environment = config.getEnvironment();
        EnvironmentDefinition existingDef = readFromStore(environment);

        // Work on a copy of the list
        List<Entry> existingEntries = Lists.newArrayList(existingDef.getEntries());

        List<Entry> updatedEntries = artifactEntryConvertor.convert(config, hostsMap);
        addArtifactToIndex(config, updatedEntries);

        Map<String, Entry> updatedEntryMap = Maps.uniqueIndex(updatedEntries, new Function<Entry, String>() {
            @Override
            public String apply(final Entry input) {
                return input.getMountPoint();
            }
        });

        final List<ChangedMountPoint> changedMountPoints = Lists.newArrayList();

        // reverse iteration order so items can be removed from the list
        for (int i = existingEntries.size() - 1; i >= 0; i--) {
            Entry existingEntry = existingEntries.get(i);
            if (sameInstance(config, existingEntry)) {
                // Found an entry which matches the passed in artifact.
                String mountPoint = existingEntry.getMountPoint();
                Entry updatedEntry = updatedEntryMap.get(mountPoint);
                if (updatedEntry == null) {
                    // this entry no longer exists.
                    Entry removedEntry = existingEntries.remove(i);
                    changedMountPoints.add(new ChangedMountPoint(mountPoint, removedEntry));
                }
                else {
                    if (!updatedEntry.equals(existingEntry)) {
                        // this entry has changed
                        existingEntries.set(i, updatedEntry);
                        changedMountPoints.add(new ChangedMountPoint(mountPoint, null));
                    }
                    // no need to add
                    updatedEntries.remove(updatedEntry);
                }
            }
        }

        // anything left in the updated entry list is new.
        for (Entry newEntry : updatedEntries) {
            String mountPoint = newEntry.getMountPoint();

            changedMountPoints.add(new ChangedMountPoint(mountPoint, null));

            existingEntries.add(newEntry);
        }

        EnvironmentDefinition updatedEnvDef = new EnvironmentDefinition(environment, existingEntries);

        this.envDefs.put(environment, updatedEnvDef);

        // Can only notify of changes once the env def is updated incase the listeners attempt to read the Entry.
        for (ChangedMountPoint mountPoint : changedMountPoints) {
            notifyListeners(environment, mountPoint.mountPoint, mountPoint.removedEntry);
        }
    }

    private static class ChangedMountPoint {
        final String mountPoint;
        final Entry removedEntry;

        public ChangedMountPoint(final String mountPoint, final Entry removedEntry) {
            this.mountPoint = mountPoint;
            this.removedEntry = removedEntry;
        }
    }

    private boolean sameInstance(final ArtifactConfig config, final Entry entry) {
        // looking for same group, artfiact and instance name
        return entry.getGroupId().equals(config.getGroupId()) &&
                entry.getArtifactId().equals(config.getArtifactId()) &&
                entry.getName().equals(config.getName());
    }

    @Transactional
    @Override
    public void afterUpdate(final Host host) {
        // Is it worth trying to determine the before and after set of deployment tags to limit the number of changes?
        // Probably not as hosts will be infrequently modified, and this only requires a single DB call to load all
        // artifacts, so it would be a very premature optimisation.
        LOG.info("Processing changes after update to host {}", host);

        initialiseHostsMap();

        List<ArtifactConfig> configs = artifactConfigurationDao.loadAll(host.getEnvironment());
        for (ArtifactConfig artifactConfig : configs) {
            afterUpdate(artifactConfig);
        }

        LOG.info("Completed processing changes after update to host {}", host);
    }

    /**
     * A change to an organisation may affect the metadata for artifact tags. As such, all the environments need to be
     * recalculated.
     * 
     * @param host
     */
    @Transactional
    @Override
    public void afterUpdate(final Organisation organisation) {
        ensureInitialised();
        LOG.info("Processing changes after update to organisation {}", organisation);

        for (Environment environment : environments) {
            if (environment.getOrganisation().equals(organisation)) {
                environment = environmentDao.loadEnvironment(environment);
                List<ArtifactConfig> configs = artifactConfigurationDao.loadAll(environment);
                for (ArtifactConfig artifactConfig : configs) {
                    afterUpdate(artifactConfig);
                }
            }
        }

        LOG.info("Completed processing changes after update to organisation {}", organisation);
    }

    private void notifyListeners(final Environment environment, final String mountPoint, final Entry removedEntry) {
        for (ProcessStateChangeListener processStateChangeListener : processStateChangeListeners) {
            processStateChangeListener.processStateChanged(environment, mountPoint, removedEntry);
        }
    }

    @Deprecated
    public List<Entry> filterByEnvironment(final Environment env) {
        return readFromStore(env).getEntries();
    }

    private void addArtifactToIndex(final ArtifactConfig config, final List<Entry> entries) {

        organisationIndex.add(config.getEnvironment(), config.getEnvironment().getName(), EntryType.environment);
        organisationIndex.add(config.getEnvironment(), config.getGroupId(), EntryType.group);
        organisationIndex.add(config.getEnvironment(), config.getArtifactId(), EntryType.artifact);

        // For the tags, use the Entry which may have been enriched with additional automatic tags.
        for (Entry entry : entries) {
            for (String tag : entry.getTags()) {
                organisationIndex.add(config.getEnvironment(), tag, EntryType.tag);
            }
        }
    }

    public Entry tryFilterByMountPoint(final Environment environment, final String mountPoint) {
        EnvironmentDefinition envDef = readFromStore(environment);
        return Iterables.find(envDef.getEntries(), new EntryMatchesMountPointPredicate(mountPoint), null);
    }

    public Entry filterByMountPoint(final Environment environment, final String mountPoint) {
        Entry entry = tryFilterByMountPoint(environment, mountPoint);
        if (entry == null) {
            throw new EntityNotFoundException("No mountpoint " + mountPoint + " in enviroment definition "
                    + environment);
        }
        return entry;
    }

    public Set<Entry> filterByMountPoints(final Environment environment, final List<String> mountPoints) {
        Set<Entry> entries = Sets.newHashSetWithExpectedSize(mountPoints.size());
        for (String mountPoint : mountPoints) {
            entries.add(filterByMountPoint(environment, mountPoint));
        }
        return entries;
    }

    public List<Entry> filterByAgent(final Environment environment, final String agent) {
        EnvironmentDefinition envDef = readFromStore(environment);
        return Lists.newArrayList(Iterables.filter(envDef.getEntries(), new EntryMatchesAgentsPredicate(agent)));
    }

    public Collection<Entry> filterEntriesByArtifact(final Environment environment, final NexusArtifact artifact) {
        EnvironmentDefinition envDef = readFromStore(environment);
        return Collections2.filter(envDef.getEntries(), new EntryMatchesGroupArtifactPredicate(artifact));
    }

    @Required
    public void setArtifactConfigurationDao(final ArtifactConfigurationDao artifactConfigurationDao) {
        this.artifactConfigurationDao = artifactConfigurationDao;
    }

    @Required
    public void setHostDao(final HostDao hostDao) {
        this.hostDao = hostDao;
    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }

    @Required
    public void setArtifactEntryConvertor(final ArtifactEntryConvertor artifactEntryConvertor) {
        this.artifactEntryConvertor = artifactEntryConvertor;
    }

    @Required
    public void setProcessStateChangeListeners(final List<ProcessStateChangeListener> processStateChangeListeners) {
        this.processStateChangeListeners = processStateChangeListeners;
    }

    @Required
    public void setTransactionTemplate(final TransactionOperations transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }

    @Required
    public void setOrganisationIndex(final OrganisationIndex organisationIndex) {
        this.organisationIndex = organisationIndex;
    }

    @Required
    public void setEnvConfigFactory(final EnvironmentBeanFactory<EnvironmentConfig> envConfigFactory) {
        this.envConfigFactory = envConfigFactory;
    }

    @Required
    public void setOrgEnvironmentsMap(final OrganisationBeanFactory<List<String>> orgEnvironmentsMap) {
        orgEnvironmentsMap.registerUpdateListener(new Runnable() {
            @Override
            public void run() {
                Set<Environment> updatedEnvs = Sets.newHashSet();
                for (Map.Entry<String, List<String>> orgEnvs : orgEnvironmentsMap.getAll().entrySet()) {
                    for (String env : orgEnvs.getValue()) {
                        updatedEnvs.add(new Environment(env, orgEnvs.getKey()));
                    }
                }
                environments = updatedEnvs;
            }
        });
    }
}
