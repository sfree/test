package com.ubs.f35.swift.messaging;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.ubs.f35.core.AuthenticationPrincipal;
import com.ubs.f35.messaging.MessageHandle;
import com.ubs.f35.messaging.MessageProcessor;
import com.ubs.f35.swift.config.model.ArtifactCommonConfig;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.event.ArtifactCommonConfigurationChangeListener;
import com.ubs.f35.swift.dao.event.ArtifactConfigurationChangeListener;
import com.ubs.f35.swift.dao.event.EnvironmentChangeListener;
import com.ubs.f35.swift.dao.event.HostChangeListener;
import com.ubs.f35.swift.dao.event.OrganisationChangeListener;
import com.ubs.f35.swift.dao.event.SecurityTemplateChangeListener;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.Organisation;
import com.ubs.f35.swift.dao.model.SecurityTemplate;

public class ConfigurationUpdateReceiver implements MessageProcessor<Void> {

    private static final Logger LOG = LoggerFactory.getLogger(ConfigurationUpdateReceiver.class);

    private ArtifactConfigurationChangeListener artifactConfigurationChangeListener;
    private HostChangeListener hostChangeListener;
    private ArtifactCommonConfigurationChangeListener artifactCommonConfigurationChangeListener;
    private List<OrganisationChangeListener> organisationChangeListeners;
    private List<EnvironmentChangeListener> environmentChangeListeners;
    private SecurityTemplateChangeListener securityTemplateChangeListener;

    @Required
    public void setArtifactConfigurationChangeListener(
            final ArtifactConfigurationChangeListener artifactConfigurationChangeListener) {
        this.artifactConfigurationChangeListener = artifactConfigurationChangeListener;
    }

    @Required
    public void setHostChangeListener(final HostChangeListener hostChangeListener) {
        this.hostChangeListener = hostChangeListener;
    }

    @Required
    public void setArtifactCommonConfigurationChangeListener(
            final ArtifactCommonConfigurationChangeListener artifactCommonConfigurationChangeListener) {
        this.artifactCommonConfigurationChangeListener = artifactCommonConfigurationChangeListener;
    }

    @Required
    public void setEnvironmentChangeListeners(final List<EnvironmentChangeListener> environmentChangeListeners) {
        this.environmentChangeListeners = environmentChangeListeners;
    }

    @Required
    public void setOrganisationChangeListeners(final List<OrganisationChangeListener> organisationChangeListeners) {
        this.organisationChangeListeners = organisationChangeListeners;
    }

    @Required
    public void setSecurityTemplateChangeListener(final SecurityTemplateChangeListener securityTemplateChangeListener) {
        this.securityTemplateChangeListener = securityTemplateChangeListener;
    }

    @Override
    public void invoke(final AuthenticationPrincipal principal, final MessageHandle<Void> handle, final Object message) {

        LOG.debug("Received configuration update message {}", message);

        if (message instanceof ArtifactConfig) {
            artifactConfigurationChangeListener.afterUpdate((ArtifactConfig) message);
        } else if (message instanceof Host) {
            hostChangeListener.afterUpdate((Host) message);
        } else if (message instanceof ArtifactCommonConfig) {
            artifactCommonConfigurationChangeListener.afterUpdate((ArtifactCommonConfig) message);
        } else if (message instanceof Organisation) {
            for (OrganisationChangeListener organisationChangeListener : organisationChangeListeners) {
                organisationChangeListener.afterUpdate((Organisation) message);
            }
        } else if (message instanceof Environment) {
            for (EnvironmentChangeListener environmentChangeListener : environmentChangeListeners) {
                environmentChangeListener.afterUpdate((Environment) message);
            }
        } else if (message instanceof SecurityTemplate) {
            securityTemplateChangeListener.afterUpdate((SecurityTemplate) message);
        } else {
            LOG.warn("Configuration update message received with unknown object type");
        }

    }

}
