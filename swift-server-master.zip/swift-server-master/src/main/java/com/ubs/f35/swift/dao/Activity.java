package com.ubs.f35.swift.dao;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

import com.google.common.base.Objects;
import com.ubs.f35.swift.activity.data.ActivityData;
import com.ubs.f35.swift.activity.data.DefaultPropertiesActivityData;
import com.ubs.f35.swift.activity.data.DeploymentActivityData;
import com.ubs.f35.swift.activity.data.PropertiesActivityData;
import com.ubs.f35.swift.activity.data.ReleaseActivityData;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.Organisation;
import com.ubs.f35.swift.model.JsonObjectMapper;

/**
 * Model class for an Activity on the activity feed
 * 
 * @author levyjo
 * 
 */
@SequenceGenerator(name = "oracle_seq", sequenceName = "seq_activity_id")
@Entity
@Table(name = "ACTIVITY")
public class Activity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "oracle_seq")
    @Column(name = "ID")
    private Integer id;

    @Column(name = "ACTIVITY_USER")
    private String user;

    @Enumerated(EnumType.STRING)
    @Column(name = "ACTIVITY_TYPE")
    private ActivityType type;

    /**
     * The ID of the object in the database that was created or modified by this activity (where applicable). Can be
     * null where not applicable.
     */
    @Column(name = "OBJECT_ID")
    private Integer objectId;

    /**
     * All activities must have an organistaion
     */
    @ManyToOne
    private Organisation organisation;

    /**
     * Can be null where not applicable (eg creating a release doesn't apply to a single environment)
     */
    @ManyToOne
    private Environment environment;

    /**
     * Can be null where not applicable
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "VERB")
    private Verb verb;

    /**
     * Stores a JSON encoded String of an {@link ActivityData} object
     */
    @Column(name = "DATA")
    private String data;
    public static final int MAX_DATA_SIZE = 4000;

    @Column(name = "ACTIVITY_TIME", insertable = false, updatable = false)
    @Generated(GenerationTime.INSERT)
    private Date timestamp;

    @Version
    private Date lastUpdatedTime;

    public enum ActivityType {
        DEPLOYMENT(DeploymentActivityData.class),
        PROPERTIES(PropertiesActivityData.class),
        PROPERTY_DEFAULTS(DefaultPropertiesActivityData.class),
        RELEASE(ReleaseActivityData.class);

        private final Class<? extends ActivityData> dataType;

        private ActivityType(final Class<? extends ActivityData> dataType) {
            this.dataType = dataType;
        }

        public Class<? extends ActivityData> getDataType() {
            return dataType;
        }
    }

    public enum Verb {
        CREATE, MODIFY, DELETE
    }

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public String getUser() {
        return user;
    }

    public void setUser(final String user) {
        this.user = user;
    }

    public ActivityType getType() {
        return type;
    }

    public void setType(final ActivityType type) {
        this.type = type;
    }

    public Integer getObjectId() {
        return objectId;
    }

    public void setObjectId(final Integer objectId) {
        this.objectId = objectId;
    }

    public Organisation getOrganisation() {
        return organisation;
    }

    public void setOrganisation(final Organisation organisation) {
        this.organisation = organisation;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }

    public Verb getVerb() {
        return verb;
    }

    public void setVerb(final Verb verb) {
        this.verb = verb;
    }

    public Object getData() {
        return JsonObjectMapper.getInstance().readValue(data, Object.class);
    }

    /**
     * Returns the activity data field as an {@link ActivityData} type so it can be merged with an activity for
     * amalgamation.
     * 
     * @param activityType
     * @return
     */
    @JsonIgnore
    public <T extends ActivityData> T getTypedData(final Class<T> activityType) {
        return JsonObjectMapper.getInstance().readValue(data, activityType);
    }

    public void setData(final Object data) {
        String jsonData = JsonObjectMapper.getInstance().writeValueAsString(data);
        if (jsonData.length() < MAX_DATA_SIZE) {
            this.data = jsonData;
        }
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(final Date timestamp) {
        this.timestamp = timestamp;
    }

    public Date getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    public void setLastUpdatedTime(final Date lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

    @JsonIgnore
    public ActivityAggregationKey getAggregationKey() {
        return new ActivityAggregationKey(user, type, objectId, environment, verb);
    }

    @JsonIgnore
    public boolean isAggregatable() {
        return verb.equals(Verb.MODIFY) && !type.equals(ActivityType.DEPLOYMENT);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, user, type, objectId, organisation, environment, verb, data, timestamp);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof Activity) {
            Activity that = (Activity) object;
            return Objects.equal(this.id, that.id)
                    && Objects.equal(this.user, that.user)
                    && Objects.equal(this.type, that.type)
                    && Objects.equal(this.objectId, that.objectId)
                    && Objects.equal(this.organisation, that.organisation)
                    && Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.verb, that.verb)
                    && Objects.equal(this.data, that.data)
                    && Objects.equal(this.timestamp, that.timestamp)
                    && Objects.equal(this.lastUpdatedTime, that.lastUpdatedTime);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("user", user)
                .add("type", type)
                .add("objectId", objectId)
                .add("organisation", organisation)
                .add("environment", environment)
                .add("verb", verb)
                .add("data", data)
                .add("timestamp", timestamp)
                .add("lastUpdatedTime", lastUpdatedTime)
                .toString();
    }

}
