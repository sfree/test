package com.ubs.f35.swift.artifact;

import java.io.StringReader;
import java.util.Collections;
import java.util.List;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.web.client.RestTemplate;

import com.google.common.collect.Lists;
import com.ubs.f35.swift.dao.Artifact;

public class NexusArtifactResolver implements ArtifactResolver {

    private RestTemplate template;
    private String nexusSearchUrl;
    private String repositoryId;
    private String classifier;
    private String packaging;
    private String resolverId;

    @Override
    public String getResolverId() {
        return resolverId;
    }

    @Override
    public List<String> getVersions(final String group, final String artifact, final boolean showSnapshotsLast) {
        String xmlResponse = template.getForObject(nexusSearchUrl
                + "?g={group}&a={artifact}&c={c}&p={p}&repositoryId={repo}",
                String.class, group, artifact, classifier, packaging, repositoryId);

        List<String> versions = getVersionList(xmlResponse);
        if (showSnapshotsLast) {
            Collections.sort(versions, MavenVersionNumberComparator.INSTANCE);
        } else {
            Collections.sort(versions, SimpleMavenVersionNumberComparator.INSTANCE);
        }

        return versions;

    }

    @Override
    public List<String> getSnapshotVersions(final String group, final String artifact) {
        List<String> versions = getVersions(group, artifact, false);
        List<String> snapshotVersions = Lists.newArrayList();

        for (String version : versions) {
            if (version.endsWith("-SNAPSHOT")) {
                snapshotVersions.add(version);
            }
        }

        return snapshotVersions;
    }

    @Override
    public void validateArtifact(final Artifact artifact) {
        String xmlResponse = template.getForObject(nexusSearchUrl
                + "?g={group}&a={artifact}&v={version}&c={c}&p={p}&repositoryId={repo}",
                String.class, artifact.getGroupId(), artifact.getArtifactId(), artifact.getVersion(), classifier,
                packaging, repositoryId);

        List<String> versionNodes = getVersionList(xmlResponse);
        if (versionNodes.isEmpty()) {
            throw new ArtifactNotFoundInRepoException(artifact);
        }

    }

    private List<String> getVersionList(final String xmlResponse) {
        List<String> versions = Lists.newArrayList();
        try {
            XMLEventReader eventReader = XMLInputFactory.newInstance().createXMLEventReader(
                    new StringReader(xmlResponse));
            while (eventReader.hasNext()) {
                XMLEvent event = eventReader.nextEvent();
                if (event.isStartElement()) {
                    StartElement startEle = event.asStartElement();
                    if (startEle.getName().getLocalPart().equals("version")) {
                        versions.add(eventReader.nextEvent().asCharacters().getData());
                    }
                }
            }
        } catch (Exception ex) {
            // TODO exception handling strategy
            throw new RuntimeException(ex);
        }
        return versions;
    }

    @Required
    public void setResolverId(final String resolverId) {
        this.resolverId = resolverId;
    }

    @Required
    public void setTemplate(final RestTemplate template) {
        this.template = template;
    }

    @Required
    public void setNexusSearchUrl(final String nexusSearchUrl) {
        this.nexusSearchUrl = nexusSearchUrl;
    }

    @Required
    public void setRepositoryId(final String repositoryId) {
        this.repositoryId = repositoryId;
    }

    public void setClassifier(final String classifier) {
        this.classifier = classifier;
    }

    public void setPackaging(final String packaging) {
        this.packaging = packaging;
    }

}
