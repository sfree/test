package com.ubs.f35.swift.properties.model;

import com.ubs.f35.swift.dao.Artifact;

public class PropertyKeysTemplateFileNotConfiguredException extends PropertyKeysExtractionException {

    public PropertyKeysTemplateFileNotConfiguredException(final String organisation, final Artifact artifact) {
        super(
                "No template file configured. Please provide a properties template filename in the "
                        + PropertyKeysExtractionException.getArtifactConfigLink(organisation, artifact) + ".",
                artifact);
    }

}
