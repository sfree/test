package com.ubs.f35.swift.model;

import com.ubs.f35.swift.dao.ReleaseDefinition;

public class NoStagingDeploymentException extends ReleaseLogicException {

    private final ReleaseDefinition releaseDef;

    public NoStagingDeploymentException(final ReleaseDefinition releaseDef) {
        super(
                "Release '"
                        + releaseDef.getName()
                        + "' must be successfully deployed to a staging environment before a production deployment can proceed.");
        this.releaseDef = releaseDef;
    }

    public ReleaseDefinition getReleaseDefinition() {
        return releaseDef;
    }

}
