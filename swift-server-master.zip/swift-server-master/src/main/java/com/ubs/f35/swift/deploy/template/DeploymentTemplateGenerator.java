package com.ubs.f35.swift.deploy.template;

import java.util.List;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.Assert;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.DeploymentProcess;
import com.ubs.f35.swift.deploy.glu.plan.GluDeploymentPlanGenerator;
import com.ubs.f35.swift.deploy.template.model.DependencyGraph;
import com.ubs.f35.swift.deploy.template.model.DependencyGraph.DependencyGraphWalkerCallback;
import com.ubs.f35.swift.deploy.template.model.DependencyGraph.WalkPosition;
import com.ubs.f35.swift.deploy.template.model.DeploymentTemplate;
import com.ubs.f35.swift.deploy.template.model.TemplateAction;
import com.ubs.f35.swift.deploy.template.model.TemplateArtifactAction;
import com.ubs.f35.swift.deploy.template.model.TemplateGroupAction;
import com.ubs.f35.swift.deploy.template.model.TemplateGroupAction.Mode;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;
import com.ubs.f35.swift.service.ArtifactConfigurationService;

public class DeploymentTemplateGenerator {

    private ArtifactConfigurationService artifactConfigurationService;

    public DeploymentTemplate generateDeploymentTemplate(final String organisation, final List<Artifact> artifacts,
            final DeploymentProcess deploymentProcess) {

        Assert.isTrue(deploymentProcess == DeploymentProcess.RollingUpgrade
                || deploymentProcess == DeploymentProcess.SequentialUpgrade,
                "Can't generate a deployment template for type " + deploymentProcess);

        ImmutableMap<NexusArtifact, Artifact> artifactsIndex = GluDeploymentPlanGenerator.artifactsIndex(artifacts);

        DependencyGraph<NexusArtifact> dependencyGraph = artifactConfigurationService
                .orderDependenciesGraph(artifactsIndex.keySet());

        final List<TemplateAction> actionLevels = Lists.newArrayList();

        dependencyGraph.walkDependencies(new DependencyGraphWalkerCallback<NexusArtifact>() {
            @Override
            public void appendActions(final List<NexusArtifact> groupedItems, final WalkPosition position) {

                if (deploymentProcess == DeploymentProcess.RollingUpgrade && position == WalkPosition.ROOT) {
                    TemplateAction redeployAction = appendArtifacts(organisation, deploymentProcess, groupedItems,
                            DeploymentAction.Redeploy);
                    actionLevels.add(redeployAction);
                } else {
                    TemplateGroupAction sequentialUndeployThenRedeploy = new TemplateGroupAction();
                    sequentialUndeployThenRedeploy.setMode(Mode.SEQUENTIAL);
                    TemplateAction undeployAction = null;
                    if (position == WalkPosition.TOWARDS_CHILDREN || position == WalkPosition.ROOT) {
                        undeployAction = appendArtifacts(organisation, deploymentProcess, groupedItems,
                                DeploymentAction.Undeploy);

                        actionLevels.add(undeployAction);
                    }

                    TemplateAction deployAction = null;
                    if (position == WalkPosition.TOWARDS_PARENTS || position == WalkPosition.ROOT) {
                        deployAction = appendArtifacts(organisation, deploymentProcess, Lists.reverse(groupedItems),
                                DeploymentAction.Start);

                        actionLevels.add(deployAction);
                    }

                }
            }

        });

        // Each level of dependency tree to be executed sequentially.
        TemplateAction rootAction = sequentialRootAction(actionLevels);

        DeploymentTemplate template = new DeploymentTemplate();
        template.setAction(rootAction);

        return template;
    }

    private TemplateAction appendArtifacts(final String organisation, final DeploymentProcess deploymentProcess,
            final List<NexusArtifact> artifacts, final DeploymentAction deploymentAction) {
        List<TemplateAction> actions = Lists.newArrayList();
        for (NexusArtifact artifact : artifacts) {
            // Server artifacts are deployed sequentially for RollingUpgrade, for SequentialUpgrade it can be done in
            // parallel as there is an outage anyway if an undeploy is done before starting again.
            Mode mode = deploymentProcess == DeploymentProcess.RollingUpgrade
                    && !artifactConfigurationService.isParallelDeployed(artifact, organisation) ? Mode.SEQUENTIAL
                    : Mode.PARALLEL;

            TemplateArtifactAction artifactAction = new TemplateArtifactAction();
            artifactAction.setAction(deploymentAction);
            artifactAction.setGroupId(artifact.getGroupId());
            artifactAction.setArtifactId(artifact.getArtifactId());
            artifactAction.setMode(mode);

            actions.add(artifactAction);
        }
        return parallelAction(actions);
    }

    /**
     * Wrap multiple actions to be executed in parallel. If only a single action then return that action.
     * 
     * @param actions
     * @return
     */
    private TemplateAction parallelAction(final List<TemplateAction> actions) {
        return groupActions(actions, Mode.PARALLEL, true);
    }

    /**
     * Wrap multiple actions to be executed sequentially. The root sequential action will not be flattened. A root
     * action is especially important at the moment, as the client UI doesn't support the addition of group actions, so
     * at least one group is required. Once supported this flatten logic can be removed.
     * 
     * @param actions
     * @return
     */
    private TemplateAction sequentialRootAction(final List<TemplateAction> actions) {
        return groupActions(actions, Mode.SEQUENTIAL, false);
    }

    private TemplateAction groupActions(final List<TemplateAction> actions, final Mode mode, final boolean flatten) {
        if (actions.size() == 1 && (flatten || actions.get(0) instanceof TemplateGroupAction)) {
            return actions.get(0);
        }

        TemplateGroupAction groupAction = new TemplateGroupAction();
        groupAction.setMode(mode);

        for (TemplateAction childAction : actions) {
            // if the child action is a group action of the same mode as this action, flatten it out.
            if (childAction instanceof TemplateGroupAction) {
                TemplateGroupAction groupChild = (TemplateGroupAction) childAction;
                if (groupChild.getMode() == mode) {
                    groupAction.getActions().addAll(groupChild.getActions());
                } else {
                    groupAction.getActions().add(groupChild);
                }
            } else {
                groupAction.getActions().add(childAction);
            }
        }
        groupAction.setActions(actions);
        return groupAction;
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }
}
