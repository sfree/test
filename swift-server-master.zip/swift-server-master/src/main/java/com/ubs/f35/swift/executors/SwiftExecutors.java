package com.ubs.f35.swift.executors;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy;
import java.util.concurrent.TimeUnit;

import com.google.common.util.concurrent.ThreadFactoryBuilder;

public class SwiftExecutors {

    private static final CallerRunsPolicy CALLER_RUNS = new ThreadPoolExecutor.CallerRunsPolicy();

    private static ExecutorService zookeeperExecutor;
    private static ExecutorService zookeeperPropertiesWalkExecutor;
    private static ExecutorService hibernateBackgroundExecutor;
    private static ScheduledExecutorService processRestart;

    public static synchronized ExecutorService getZookeeperExecutor() {
        if (zookeeperExecutor == null) {
            zookeeperExecutor = Executors.newCachedThreadPool(namedThreadFactory("zookeeper-background", true));
        }
        return zookeeperExecutor;
    }

    public static synchronized ExecutorService getHibernateBackgroundExecutor() {
        if (hibernateBackgroundExecutor == null) {
            hibernateBackgroundExecutor = Executors
                    .newCachedThreadPool(namedThreadFactory("hibernate-background", true));
        }
        return hibernateBackgroundExecutor;
    }

    public static synchronized ExecutorService getZookeeperPropertiesWalkExecutor() {
        if (zookeeperPropertiesWalkExecutor == null) {
            zookeeperPropertiesWalkExecutor = newReeentantFixedThreadPoolExecutor(10, 10, "zookeeper-properties");
        }
        return zookeeperPropertiesWalkExecutor;
    }

    public static synchronized ScheduledExecutorService getProcessRestartScheduledExecutor() {
        if (processRestart == null) {
            processRestart = Executors
                    .newSingleThreadScheduledExecutor(namedThreadFactory("process-restart", true));
        }
        return processRestart;
    }

    /**
     * Creates a ThreadPoolExecutor for managing deployment actions with a maximum number of threads.
     * 
     * @param nThreads
     *            the number of threads in the pool
     * @return the newly created thread pool
     * @throws IllegalArgumentException
     *             if <tt>nThreads &lt;= 0</tt>
     */
    public static ExecutorService newDeploymentExecutor(final int nThreads) {
        return newReeentantFixedThreadPoolExecutor(Math.min(5, nThreads), nThreads, "deployment-manager");
    }

    private static ExecutorService newReeentantFixedThreadPoolExecutor(final int minThreads, final int maxThreads,
            final String threadFactoryName) {
        final Semaphore runningCommands = new Semaphore(maxThreads);

        return new ThreadPoolExecutor(minThreads, maxThreads,
                1L, TimeUnit.MINUTES,
                new ArrayBlockingQueue<Runnable>(maxThreads),
                namedThreadFactory(threadFactoryName, true),
                CALLER_RUNS) {

            /**
             * execute is overriden due to the potential for the base ThreadPoolExecutor to deadlock, the sequences goes
             * like this.
             * <ol>
             * <li>An executor with 1 thread and a queue size of 1 receives a task to be executed
             * <li>The executor pulls this task from the queue and executes it
             * <li>The task submits another task back to the same executor and waits for that task to complete.
             * </ol>
             * This is where the problem lies. In this state the queue has 0 outstanding tasks so accepts the task is
             * offered. However the thread is already blocked waiting for the current task to submit, so the newly
             * submitted task will never be executed while the current task waits for it. DEADLOCK!
             * <p>
             * This workaround keeps track of the number of commands which are still outstanding. If all threads are
             * currently engaged in processing, additional requests will be executed on the current thread rather than
             * offered to the queue.
             */
            @Override
            public void execute(final Runnable command) {
                if (runningCommands.tryAcquire()) {
                    super.execute(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                command.run();
                            } finally {
                                runningCommands.release();
                            }
                        }
                    });
                } else {
                    // All threads are currently in use, do not attempt to run any more commands.
                    CALLER_RUNS.rejectedExecution(command, this);
                }

            }
        };
    }

    public static ThreadFactory namedThreadFactory(final String namePrefix, final boolean daemon) {
        return new ThreadFactoryBuilder().setDaemon(daemon).setNameFormat(namePrefix + "-%d").build();
    }

}
