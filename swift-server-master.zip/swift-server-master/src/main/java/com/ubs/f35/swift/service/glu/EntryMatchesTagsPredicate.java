package com.ubs.f35.swift.service.glu;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.google.common.base.Predicate;
import com.ubs.f35.swift.environment.model.glu.Entry;

/**
 * Returns deployment model entries which match the agent
 * 
 * @author levyjo
 * 
 */
public class EntryMatchesTagsPredicate implements Predicate<Entry> {

    private final List<String> tags;

    public EntryMatchesTagsPredicate(final List<String> tags) {
        this.tags = tags;
    }

    @Override
    public boolean apply(final Entry entry) {
        if (CollectionUtils.isEmpty(tags)) {
            return true;
        }
        List<String> entryTags = entry.getTags();
        if (CollectionUtils.isEmpty(entryTags)) {
            return false;
        }
        return CollectionUtils.containsAny(entryTags, tags);
    }

}
