package com.ubs.f35.swift.properties;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.core.zookeeper.client.ZNode;
import com.ubs.f35.core.zookeeper.client.ZNodeProcessor;
import com.ubs.f35.core.zookeeper.client.common.StringValueTransformer;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper.ConfigTagScheme;
import com.ubs.f35.core.zookeeper.utils.ConfigUtils;

/**
 * Class processes the znodes which represent properties. Converts between the zookeeper representation of encrypted and
 * leased properties and the original source format as entered by the user.
 */
public class SwiftPropertyExposingNodeProcessor implements ZNodeProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(SwiftPropertyExposingNodeProcessor.class);
    private static final StringValueTransformer valueTransformer = new StringValueTransformer();

    private final String rootPath;
    private final Map<String, String> properties;

    public SwiftPropertyExposingNodeProcessor(final String rootPath, final Map<String, String> properties) {
        this.rootPath = rootPath;
        this.properties = properties;
    }

    @Override
    public void process(final ZNode zNode) {

        byte[] value = zNode.value();

        // skip null value nodes
        if (value == null) {
            LOG.info("skipping null value node: {}", zNode.path());
            return;
        }

        String valueString = valueTransformer.fromInput(value);
        ConfigTagScheme scheme = ConfigTagSchemeHelper.parse(zNode.name());

        String relativePath;
        String propertyKey;
        String encrypted = (scheme.isEncrypted() ? "encrypted:, " : "");

        if (scheme.isLease()) {
            if (scheme.isLeaseGroup()) { // Ignore individual lease entity nodes
                relativePath = ConfigUtils.erase(rootPath, zNode.parent().path());
                propertyKey = ConfigUtils.convertPathToProperty(relativePath);
                valueString = valueString.replaceAll(propertyKey + ".", "");
                valueString = valueString.substring(1, valueString.length() - 1);
                properties.put(propertyKey, "expression: { " + encrypted + "leased:, " + valueString + " }");
            }
        } else if (scheme.isEncrypted()) {
            relativePath = ConfigUtils.erase(rootPath, zNode.parent().path());
            propertyKey = ConfigUtils.convertPathToProperty(relativePath);
            properties.put(propertyKey, "expression: { " + encrypted + "value: " + valueString + " }");

        } else {
            relativePath = ConfigUtils.erase(rootPath, zNode.path());
            propertyKey = ConfigUtils.convertPathToProperty(relativePath);
            properties.put(propertyKey, valueString);
        }

    }

}