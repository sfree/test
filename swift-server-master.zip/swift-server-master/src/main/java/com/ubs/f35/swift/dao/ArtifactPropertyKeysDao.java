package com.ubs.f35.swift.dao;

import java.util.List;

import com.ubs.f35.swift.properties.model.PropertyKey;

public interface ArtifactPropertyKeysDao {

    List<PropertyKey> getPropertyKeys(Artifact artifact);

    void savePropertyKeys(Artifact artifact, List<PropertyKey> arrayList);

    /**
     * Delete property keys for <strong>all</strong> versions of the given artifact.
     * 
     * @param artifact
     */
    void deletePropertyKeys(NexusArtifact artifact);

}
