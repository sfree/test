package com.ubs.f35.swift.properties.model;

import com.google.common.base.Objects;

/**
 * Basic model of a single property.<br>
 * An ordering has been defined which treats Keys as case-insensitive but Values as case-sensitive. Each property may
 * have a default value as defined in the environment defaults store or the artifact's template file.
 * <p>
 * Beware that this model is used for many different purposes:
 * <ul>
 * <li>Returning property values and suggestions.
 * <li>Returing default properties (in which case documentation, defaultValue and defaultType are not used)
 * <li>Client saving properties (in which case documentation, defaultValue and defaultType are not used)
 * </ul>
 * 
 * @author levyjo
 */
public class Property implements Comparable<Property> {

    private String key;
    private String value;
    private String documentation;
    private String defaultValue;
    private final DefaultType defaultType;

    /**
     * DefaultType flag:
     * <ul>
     * <li>ENVIRONMENT: Default value comes from environment defaults.</li>
     * <li>TEMPLATE: Default value comes from artifact template properties.</li>
     * </ul>
     */
    public static enum DefaultType {
        ENVIRONMENT, TEMPLATE
    }

    // Required for JSON unmarshalling
    public Property() {
        this(null, null);
    }

    public Property(final String key, final String value) {
        this(key, value, null, null);
    }

    public Property(final String key, final String value, final String defaultValue, final DefaultType defaultType) {
        this.key = key;
        this.value = value;
        this.defaultValue = defaultValue;
        this.defaultType = defaultType;
    }

    public String getKey() {
        return key;
    }

    public void setKey(final String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(final String value) {
        this.value = value;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(final String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public String getDocumentation() {
        return documentation;
    }

    public void setDocumentation(final String documentation) {
        this.documentation = documentation;
    }

    public DefaultType getDefaultType() {
        return defaultType;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(key, value, defaultValue);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof Property) {
            Property that = (Property) object;
            return Objects.equal(this.key, that.key)
                    && Objects.equal(this.value, that.value)
                    && Objects.equal(this.documentation, that.documentation)
                    && Objects.equal(this.defaultValue, that.defaultValue)
                    && Objects.equal(this.defaultType, that.defaultType);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("key", key)
                .add("value", value)
                .add("documentation", documentation)
                .add("defaultValue", defaultValue)
                .toString();
    }

    /**
     * Property keys are compared in a case-insensitive fashion.
     */
    @Override
    public int compareTo(final Property o) {
        int keyComparison = this.key.compareToIgnoreCase(o.key);
        if (keyComparison == 0) {
            int comparison;
            if (this.value == o.value) {
            } else if (this.value == null) {
                return -1;
            } else if (o.value == null) {
                return 1;
            } else {
                comparison = this.value.compareTo(o.value);
                if (comparison != 0) {
                    return comparison;
                }
            }

            if (!Objects.equal(this.defaultValue, o.defaultValue)) {
                return -2;
            }
        }
        return keyComparison;
    }
}