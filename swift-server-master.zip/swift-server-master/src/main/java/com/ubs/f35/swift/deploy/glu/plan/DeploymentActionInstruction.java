package com.ubs.f35.swift.deploy.glu.plan;

import java.util.List;

import com.google.common.base.Objects;
import com.ubs.f35.swift.deploy.glu.state.GluState;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;

/**
 * Represents a instruction to perform a deployment action. If no {@link #validStartStates} are present, this indicates
 * that there are no preceeding actions in the deployment plan. If {@link #validStartStates} are present this indicates
 * there is an earlier deployment plan actions which will affect the start state of this {@link DeploymentAction}. In
 * that case, this {@link DeploymentAction} can be assumed to execute if the current process state is within
 * {@link #validStartStates}, and that if that is the case, the first of the {@link #validStartStates} will be assumed
 * to be the state this {@link DeploymentAction} will be initiated from.
 * 
 * @author stephelu
 * 
 */
public class DeploymentActionInstruction {

    private final DeploymentAction action;
    private final List<GluState> validStartStates;

    public DeploymentActionInstruction(final DeploymentAction action) {
        this(action, null);
    }

    public DeploymentActionInstruction(final DeploymentAction action, final List<GluState> validStartStates) {
        this.action = action;
        this.validStartStates = validStartStates;
    }

    public DeploymentAction getAction() {
        return action;
    }

    public List<GluState> getValidStartStates() {
        return validStartStates;
    }

    public GluState getStartState() {
        return validStartStates == null ? null : validStartStates.get(0);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("action", action)
                .add("validStartStates", validStartStates)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(action, validStartStates);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DeploymentActionInstruction) {
            DeploymentActionInstruction that = (DeploymentActionInstruction) object;
            return Objects.equal(this.action, that.action)
                    && Objects.equal(this.validStartStates, that.validStartStates);
        }
        return false;
    }

}