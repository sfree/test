package com.ubs.f35.swift.processor;

import static com.ubs.f35.swift.processor.ProcessorUtil.daoFilter;
import static com.ubs.f35.swift.processor.ProcessorUtil.transform;

import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Pattern;

import org.hibernate.StaleObjectStateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.ubs.f35.swift.artifact.ArtifactNotFoundInRepoException;
import com.ubs.f35.swift.artifact.MavenVersionNumberComparator;
import com.ubs.f35.swift.client.model.ArtifactCommonConfigWithType;
import com.ubs.f35.swift.client.model.ArtifactType;
import com.ubs.f35.swift.config.ArtifactConfigBulkUploadParser;
import com.ubs.f35.swift.config.GluScriptFinder;
import com.ubs.f35.swift.config.model.ArtifactCommonConfig;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.DeployTag;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.config.model.Tag;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ArtifactCommonConfigDao;
import com.ubs.f35.swift.dao.ArtifactConfigurationDao;
import com.ubs.f35.swift.dao.DeployTagDao;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.HostDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.TagDao;
import com.ubs.f35.swift.dao.hibernate.AuditEntry;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.GluProcessManager;
import com.ubs.f35.swift.document.ArtifactEntryConvertor;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.model.ClientPagingFilter;
import com.ubs.f35.swift.model.GluScriptConfig;
import com.ubs.f35.swift.processor.ArtifactConfigComparison.ArtifactConfigId;
import com.ubs.f35.swift.processor.UpdateArtifactConfigurationsRequest.NotDeployedArtifact;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.security.Permission;
import com.ubs.f35.swift.service.ArtifactConfigurationService;
import com.ubs.f35.swift.service.ArtifactTypeService;
import com.ubs.f35.swift.service.NexusArtifactService;
import com.ubs.f35.swift.util.EnvironmentCloneFunction;

// TODO This is getting too large / has too many dependencies and should be split into smaller components.

@Controller
@RequestMapping(value = "/api/config")
@Transactional
public class ArtifactConfigurationProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(ArtifactConfigurationProcessor.class);

    private static final Pattern VALID_DEPLOY_TAG_PATTERN = Pattern.compile("[A-Za-z0-9\\-]+");
    private static final Pattern VALID_ARTIFACT_NAME_PATTERN = VALID_DEPLOY_TAG_PATTERN;

    private GluScriptFinder gluScriptFinder;
    private ArtifactConfigurationDao artifactConfigurationDao;
    private HostDao hostDao;
    private DeployTagDao deployTagDao;
    private TagDao tagDao;
    private ArtifactCommonConfigDao commonConfigDao;
    private ArtifactConfigurationService artifactConfigurationService;
    private NexusArtifactService nexusArtifactService;
    private EnvironmentDocumentStore environmentDocumentStore;
    private EnvironmentBeanFactory<GluProcessManager> gluProcessManagerFactory;
    private OrganisationBeanFactory<List<String>> orgEnvironmentsMap;
    private ArtifactConfigBulkUploadParser artifactConfigBulkUploadParser;
    private AuthorisationController authorisationController;
    private EnvironmentDao environmentDao;
    private ArtifactTypeService artifactTypeService;

    @RequestMapping(value = "/{organisation}/scripts", method = RequestMethod.GET)
    public List<GluScriptConfig> getScripts(@PathVariable final String organisation) {
        return gluScriptFinder.getScripts(organisation);
    }

    @RequestMapping(value = "/{organisation}/environments", method = RequestMethod.GET)
    public List<String> getEnvironments(@PathVariable final String organisation) {
        List<String> envs = orgEnvironmentsMap.get(organisation);
        Assert.notEmpty(envs, "No environments for organisation " + organisation);
        return envs;
    }

    @RequestMapping(value = "/{organisation}/host/{environment}", method = RequestMethod.GET)
    public List<Host> getHosts(@PathVariable final String organisation, @PathVariable final String environment) {
        List<Host> hosts = hostDao.loadByEnvironment(environment(organisation, environment));
        List<Host> init = Lists.newArrayListWithExpectedSize(hosts.size());

        for (Host host : hosts) {
            init.add(initialise(host));
        }
        return init;
    }

    @RequestMapping(value = "/{organisation}/deploytag/{environment}", method = RequestMethod.GET)
    public List<DeployTag> getDeployTags(@PathVariable final String organisation, @PathVariable final String environment) {
        return deployTagDao.loadByEnvironment(environment(organisation, environment));
    }

    @RequestMapping(value = "/tag/{organisation}", method = RequestMethod.GET)
    public List<Tag> getTags(@PathVariable final String organisation) {
        return tagDao.loadAll(organisation);
    }

    @RequestMapping(value = "/artifact/{organisation}/{environment}/{group}/{artifact}/{name}", method = RequestMethod.GET)
    public ArtifactConfig getArtifactConfiguration(@PathVariable final String organisation,
            @PathVariable final String environment, @PathVariable final String group,
            @PathVariable final String artifact, @PathVariable final String name) {
        return initialise(artifactConfigurationDao.load(environment(organisation, environment), group, artifact,
                name));
    }

    @RequestMapping(value = "/artifact/{organisation}/{environment}/{group}/{artifact}", method = RequestMethod.GET)
    public List<ArtifactConfig> getArtifactConfiguration(@PathVariable final String organisation,
            @PathVariable final String environment,
            @PathVariable final String group, @PathVariable final String artifact) {
        List<ArtifactConfig> configs = artifactConfigurationDao.load(environment(organisation, environment), group,
                artifact);
        List<ArtifactConfig> init = Lists.newArrayListWithExpectedSize(configs.size());

        for (ArtifactConfig artifactConfig : configs) {
            init.add(initialise(artifactConfig));
        }
        return init;
    }

    @RequestMapping(value = "/artifact/common/{group}/{artifact}", method = RequestMethod.GET)
    public ArtifactCommonConfig getArtifactCommonConfiguration(@PathVariable final String group,
            @PathVariable final String artifact) {

        ArtifactCommonConfig config = artifactConfigurationService.loadOrDefaultCommonConfig(new NexusArtifact(group,
                artifact));
        return initialise(config, true);
    }

    @RequestMapping(value = "/artifact/clear-not-deployed/{organisation}/{environment}/{group}/{artifact}", method = RequestMethod.DELETE)
    public void clearNotDeployedEnvironmentFlag(@PathVariable final String organisation,
            @PathVariable final String environment, @PathVariable final String group,
            @PathVariable final String artifact) {

        Environment env = environment(organisation, environment);
        authorisationController.checkAccess(env, new NexusArtifact(group, artifact),
                Permission.Configure);

        ArtifactCommonConfig commonConfig = artifactConfigurationService
                .loadOrDefaultCommonConfig(new NexusArtifact(group, artifact));

        boolean removed = Iterables.removeIf(commonConfig.getNotDeployedEnvironments(), new Predicate<Environment>() {
            @Override
            public boolean apply(final Environment input) {
                return input.getName().equals(environment) &&
                        input.getOrganisation().getName().equals(organisation);
            }
        });

        LOG.info("Not deployed flag cleared = {}", removed);
    }

    @RequestMapping(value = "/artifact/{organisation}/{environment}/{group}/{artifact}/{name}", method = RequestMethod.DELETE)
    public void deleteArtifactConfiguration(@PathVariable final String organisation,
            @PathVariable final String environment, @PathVariable final String group,
            @PathVariable final String artifact, @PathVariable final String name) {
        LOG.debug("Delete artifact configuration request for instance {}", name);

        Environment env = environment(organisation, environment);
        authorisationController.checkAccess(env, new NexusArtifact(group, artifact),
                Permission.Configure);

        ArtifactConfig artifactConfig = artifactConfigurationDao.load(env, group, artifact, name);

        String deployedTo = getHostsArtifactWouldNoLongerBeDeployedTo(artifactConfig, Collections.<DeployTag>emptySet());
        if (deployedTo != null) {
            throw new IllegalArgumentException("Cannot delete as currently deployed to " + deployedTo);
        }

        artifactConfigurationDao.delete(env, group, artifact, name);
    }

    @RequestMapping(value = "/artifact/{organisation}/{environment}/{group}/{artifact}/history", method = RequestMethod.GET)
    public List<AuditEntry<ArtifactConfig>> getArtifactConfigurationHistory(@PathVariable final String organisation,
            @PathVariable final String environment,
            @PathVariable final String group, @PathVariable final String artifact,
            final ClientPagingFilter filter) {
        ArtifactConfig artifactId = createId(environment(organisation, environment), group, artifact);

        List<AuditEntry<ArtifactConfig>> auditHistory = artifactConfigurationDao.getAuditHistory(artifactId,
                daoFilter(filter));

        return ProcessorUtil.transformAuditEntries(auditHistory, FULL_MAPPER);
    }

    @RequestMapping(value = "/artifact", method = RequestMethod.PUT)
    public ArtifactConfig saveArtifactConfiguration(@RequestBody final ArtifactConfig artifactConfig) {
        LOG.debug("Save artifact configuration request {}", artifactConfig);

        // Ensure a full initialised environment object.
        Environment environment = environmentDao.loadEnvironment(artifactConfig.getEnvironment());
        artifactConfig.setEnvironment(environment);

        authorisationController.checkAccess(environment, artifactConfig.getArtifact(),
                Permission.Configure);

        validate(artifactConfig);
        // If artifact is flagged as not deployed to this environment, remove that flag.
        ArtifactCommonConfig commonConfig = commonConfigDao.load(artifactConfig.getArtifact());
        if (commonConfig != null) {
            commonConfig.getNotDeployedEnvironments().remove(environment);
        }

        if (artifactConfig.getScriptArgumentsMap() != null) {
            Map<String, String> scriptArgs = artifactConfig.getScriptArgumentsMap();
            Iterables.removeIf(scriptArgs.entrySet(), new Predicate<Entry<String, String>>() {
                @Override
                public boolean apply(final Entry<String, String> input) {
                    return StringUtils.isEmpty(input.getValue());
                }
            });
            artifactConfig.setScriptArgumentsMap(scriptArgs);
        }

        ArtifactConfig updated = artifactConfigurationDao.save(artifactConfig);

        return initialise(updated);
    }

    @RequestMapping(value = "/artifacts", method = RequestMethod.PUT)
    public void saveArtifactConfigurations(@RequestBody final UpdateArtifactConfigurationsRequest updateRequest) {
        LOG.debug("Save artifact configurations request {}", updateRequest);

        for (ArtifactConfig artifactConfig : updateRequest.getConfigured()) {
            saveArtifactConfiguration(artifactConfig);
        }

        for (NotDeployedArtifact notDeployed : updateRequest.getNotDeployed()) {
            NexusArtifact artifact = new NexusArtifact(notDeployed.getGroupId(), notDeployed.getArtifactId());
            Environment environment = environmentDao.loadEnvironment(notDeployed.getEnvironmentId());

            authorisationController.checkAccess(environment, artifact, Permission.Configure);

            ArtifactCommonConfig commonConfig = artifactConfigurationService.loadOrDefaultCommonConfig(artifact);
            commonConfig.getNotDeployedEnvironments().add(environment);
            commonConfigDao.save(commonConfig);
        }
    }

    @RequestMapping(value = "/artifact/common", method = RequestMethod.PUT)
    public ArtifactCommonConfig saveArtifactCommonConfiguration(
            @RequestBody final ArtifactCommonConfig artifactCommonConfig) {

        authorisationController.checkAccess();

        validate(artifactCommonConfig);

        ArtifactCommonConfig updated = commonConfigDao.save(artifactCommonConfig);

        return initialise(updated, true);
    }

    @RequestMapping(value = "/host", method = RequestMethod.PUT)
    public Host saveHostConfiguration(@RequestBody final Host host) {
        LOG.debug("Save host request {}", host);

        authorisationController.checkAccess(host.getEnvironment(), host.getHostname(), Permission.Configure);

        Host existing = hostDao.load(host.getHostname());

        validate(existing, host);

        Host updated = hostDao.save(host);

        return initialise(updated);
    }

    @RequestMapping(value = "/bulkUpload/{organisation}", method = RequestMethod.POST)
    @ResponseBody
    public String bulkUpload(@PathVariable final String organisation, final Reader bulkUploadReaer) {
        List<ArtifactConfig> records = artifactConfigBulkUploadParser.parse(organisation, bulkUploadReaer);

        int uploadedRecords = 0;
        int uploadLineNum = 1;
        for (ArtifactConfig record : records) {
            uploadLineNum++;
            try {
                if (nexusArtifactService.registerArtifact(organisation, record.getArtifact()) == null) {
                    throw new ArtifactNotFoundInRepoException(extractArtifact(record));
                }
                saveArtifactConfiguration(record);
                uploadedRecords++;
            } catch (RuntimeException ex) {
                if (ex instanceof StaleObjectStateException && record.getLastUpdatedTime() == null) {
                    LOG.debug("Skipping save of record as it already exists");
                } else {
                    throw new IllegalArgumentException("Error in bulk upload on line " + uploadLineNum + ": "
                            + ex.getMessage(), ex);
                }
            }
        }
        return uploadedRecords + " records successfully uploaded." + (records.size() - uploadedRecords)
                + " existing records skipped";
    }

    @RequestMapping(value = "/bulkExport/{organisation}/{environment}", method = RequestMethod.GET)
    public void bulkExport(@PathVariable final String organisation, @PathVariable final String environment,
            final Writer bulkExportWriter) {
        List<ArtifactConfig> records = artifactConfigurationDao.loadAll(
                environmentDao.loadEnvironment(environment, organisation));

        artifactConfigBulkUploadParser.exportRecords(records, bulkExportWriter);
    }

    @RequestMapping(value = "/comparisonReport/{organisation}", method = RequestMethod.GET)
    @ResponseBody
    public List<ArtifactConfigComparison> generateComparisonReport(@PathVariable final String organisation,
            @RequestParam(value = "baseLineEnv", required = true) final String baseLineEnv,
            @RequestParam(value = "targetEnv", required = true) final String targetEnv) {

        Environment base = environmentDao.loadEnvironment(baseLineEnv, organisation);
        Environment target = environmentDao.loadEnvironment(targetEnv, organisation);

        List<Object[]> daoResults = artifactConfigurationDao
                .loadArtifactsWhichDifferentVersions(base, target);

        List<ArtifactConfigComparison> comparisons = Lists.newArrayList();
        for (Object[] result : daoResults) {
            ArtifactConfig left = (ArtifactConfig) result[0];
            ArtifactConfig right = (ArtifactConfig) result[1];

            String leftEnv = null;
            String rightEnv = null;
            ArtifactConfigId comparisonId = null;
            if (left != null) {
                leftEnv = left.getArtifactVersion();
                comparisonId = new ArtifactConfigId(left.getGroupId(), left.getArtifactId(), left.getName());
            }
            if (right != null) {
                rightEnv = right.getArtifactVersion();
                comparisonId = new ArtifactConfigId(right.getGroupId(), right.getArtifactId(), right.getName());
            }

            boolean targetAhead = false;
            if (rightEnv != null &&
                    (leftEnv == null || MavenVersionNumberComparator.isLaterVersion(rightEnv, leftEnv))) {
                targetAhead = true;
            }

            comparisons.add(new ArtifactConfigComparison(comparisonId, leftEnv, rightEnv, targetAhead));
        }
        return comparisons;
    }

    /**
     * Ensure that the changes are valid and that removing this deployment tag does not affect any artifacts which are
     * currently running on this host.
     * 
     * @param existing
     * @param host
     */
    private void validate(final Host existing, final Host updated) {
        Assert.notNull(existing, "Host can not be created.  Start a glu agent on the host for it to be discovered");
        Assert.notNull(updated.getEnvironment(), "Environment must be specified");
        Assert.isTrue(existing.getEnvironment().equals(updated.getEnvironment()), "Environment may not be modified");

        validateDeployTags(updated);

        Set<DeployTag> tagsBefore = set(existing.getDeployTags());
        Set<DeployTag> tagsAfter = set(updated.getDeployTags());

        SetView<DeployTag> removedTags = Sets.difference(tagsBefore, tagsAfter);

        if (!removedTags.isEmpty()) {
            // Find the list of artifacts which have one of the removed tags, but none of the remaining tags. Those
            // artifacts
            // will no longer be deployed to this host.
            List<ArtifactConfig> artifacts = artifactConfigurationDao.loadWithDeployTags(tagsAfter, removedTags);
            LOG.info(
                    "Deployment tags {} have been removed.  Checking if any of these artifacts are currently deployed to this server {}",
                    removedTags, artifacts);
            for (ArtifactConfig artifact : artifacts) {
                String deployedTo = ensureArtifactNotDeployedToHosts(artifact, Collections.singleton(existing));
                if (deployedTo != null) {
                    throw new IllegalArgumentException("Cannot remove deployment tag as "
                            + artifact.getArtifactId()
                            + " is currently deployed to " + deployedTo);
                }
            }
        }
    }

    private void validate(final ArtifactConfig artifactConfig) {
        LOG.info("Validating save artifact request {}", artifactConfig);

        Assert.hasText(artifactConfig.getName(), "Name must be specified");
        Assert.hasText(artifactConfig.getGroupId(), "Group must be specified");
        Assert.hasText(artifactConfig.getArtifactId(), "Artifact must be specified");
        Assert.hasText(artifactConfig.getArtifactVersion(), "Version must be specified");
        Assert.notNull(artifactConfig.getEnvironment(), "Environment must be specified");

        Assert.isTrue(VALID_ARTIFACT_NAME_PATTERN.matcher(artifactConfig.getName()).matches(),
                "Invalid characters in name '" + artifactConfig.getName() + "'");

        Artifact artifact = extractArtifact(artifactConfig);

        nexusArtifactService.validateArtifactVersion(artifact);

        if (environmentDocumentStore.isProdEnvironment(artifactConfig.getEnvironment())) {
            Assert.isTrue(!artifactConfigurationService.isNonProdArtifact(artifact.getNexusArtifact()),
                    "This artifact is flagged as a non-production artifact");
        }

        Assert.isTrue(!CollectionUtils.isEmpty(artifactConfig.getDeployTags()),
                "Configuration must have at least one deployment tag");

        validateDeployTags(artifactConfig);
        gluScriptFinder.validate(artifactConfig);

        // Check that if any deployment tags have been removed, that it doesn't affect the list of servers the artifact
        // is deployed to.
        ArtifactConfig existing = artifactConfigurationDao.load(artifactConfig.getEnvironment(),
                artifactConfig.getGroupId(), artifactConfig.getArtifactId(), artifactConfig.getName());

        if (existing == null) {
            Assert.isTrue(artifactConfig.getName().length() <= 10, "Name is limited to 10 characters");
        }

        Set<DeployTag> tagsAfter = set(artifactConfig.getDeployTags());

        String host = getHostsArtifactWouldNoLongerBeDeployedTo(existing, tagsAfter);
        if (host != null) {
            throw new IllegalArgumentException("Cannot remove deployment tag as "
                    + artifactConfig.getArtifactId()
                    + " is currently deployed to " + host);
        }

        validateAccessToNewHosts(existing, artifactConfig);

        sanitiseTags(artifactConfig);

    }

    private Artifact extractArtifact(final ArtifactConfig artifactConfig) {
        return new Artifact(artifactConfig.getGroupId(), artifactConfig.getArtifactId(),
                artifactConfig.getArtifactVersion());
    }

    private void validate(final ArtifactCommonConfig config) {
        // Check the configuration does not introduce any circular dependencies
        validateNoCircularDeps(Collections.<NexusArtifact>emptySet(), config.getArtifactId(), config);

        // Check non-prod artifact doesn't have any production instances configured
        if (config.isNonProd()) {
            List<ArtifactConfig> artifactProdConfigs = artifactConfigurationDao.load(
                    environmentDocumentStore.getProductionEnvironments(),
                    config.getGroupId(),
                    config.getArtifactId());
            for (ArtifactConfig instance : artifactProdConfigs) {

                if (environmentDocumentStore.isProdEnvironment(instance.getEnvironment())) {

                    throw new IllegalArgumentException(
                            "Cannot be a non-prod artifact as currently configured for " + instance.getEnvironment());

                }
            }
        }
    }

    private void validateNoCircularDeps(Set<NexusArtifact> visited, final String path,
            final ArtifactCommonConfig config) {
        if (visited.contains(config.getArtifact())) {
            throw new IllegalArgumentException("Cannot save circular dependency from " + path);
        }

        visited = setWith(visited, config.getArtifact());

        if (!CollectionUtils.isEmpty(config.getDependencies())) {
            for (ArtifactCommonConfig child : config.getDependencies()) {
                ArtifactCommonConfig dbChild = commonConfigDao.load(child.getArtifact());
                if (dbChild != null) {
                    validateNoCircularDeps(visited, path + " - " + child.getArtifactId(), dbChild);
                }
            }
        }
    }

    private static <T> Set<T> setWith(final Set<T> old, final T item) {
        return new ImmutableSet.Builder<T>().addAll(old).add(item).build();
    }

    private String getHostsArtifactWouldNoLongerBeDeployedTo(final ArtifactConfig existing,
            final Set<DeployTag> tagsAfter) {
        if (existing != null) {
            Set<DeployTag> tagsBefore = set(existing.getDeployTags());
            SetView<DeployTag> removedTags = Sets.difference(tagsBefore, tagsAfter);
            if (!removedTags.isEmpty()) {
                LOG.info("Deployment tags have been removed from artifact configuration.  Checking if the list of deployed hosts is affected");
                Set<Host> hostsBefore = artifactConfigurationService.getHosts(tagsBefore);
                Set<Host> hostsAfter = artifactConfigurationService.getHosts(tagsAfter);
                Set<Host> hostsRemoved = Sets.difference(hostsBefore, hostsAfter);

                if (!hostsRemoved.isEmpty()) {
                    LOG.info("Artifact is no longer mapped to hosts {}, checking not deployed first", hostsRemoved);
                    String deployedTo = ensureArtifactNotDeployedToHosts(existing, hostsRemoved);
                    if (deployedTo != null) {
                        return deployedTo;
                    }
                }
            }
        }
        return null;
    }

    private void validateAccessToNewHosts(final ArtifactConfig existing, final ArtifactConfig updated) {
        Set<DeployTag> tagsBefore = existing != null ? set(existing.getDeployTags())
                : Collections.<DeployTag>emptySet();
        Set<DeployTag> tagsAfter = set(updated.getDeployTags());

        SetView<DeployTag> tagsAdded = Sets.difference(tagsAfter, tagsBefore);
        if (!tagsAdded.isEmpty()) {
            LOG.info("Deployment tags have been added to artifact configuration.  Checking if the user has access to mapped hosts");
            Set<Host> hostsBefore = artifactConfigurationService.getHosts(tagsBefore);
            Set<Host> hostsAfter = artifactConfigurationService.getHosts(tagsAfter);
            Set<Host> hostsAdded = Sets.difference(hostsAfter, hostsBefore);

            for (Host host : hostsAdded) {
                authorisationController.checkAccess(updated.getEnvironment(), host.getHostname(),
                        Permission.Configure);
            }
        }
    }

    /**
     * Artifact may only use {@link DeployTag}s already defined on hosts in this environment.
     * 
     * @param host
     */
    private void validateDeployTags(final ArtifactConfig artifactConfig) {
        if (!CollectionUtils.isEmpty(artifactConfig.getDeployTags())) {
            for (DeployTag tag : artifactConfig.getDeployTags()) {
                Assert.isTrue(tag.getEnvironment().equals(artifactConfig.getEnvironment()),
                        "Deploy tags for wrong environment added");

                // Die if deployment tag not found
                Assert.notNull(deployTagDao.load(tag), "Deployment tag '" + tag.getTag()
                        + "' not associated with any host in " + tag.getEnvironment().getName());
            }
        }
    }

    private void validateDeployTags(final Host host) {
        if (!CollectionUtils.isEmpty(host.getDeployTags())) {
            for (DeployTag tag : host.getDeployTags()) {

                Assert.isTrue(VALID_DEPLOY_TAG_PATTERN.matcher(tag.getTag()).matches(),
                        "Invalid characters in deployment tag '" + tag.getTag() + "'");

                Assert.isTrue(tag.getEnvironment().equals(host.getEnvironment()),
                        "Deploy tags for wrong environment added");
            }
        }
    }

    private void sanitiseTags(final ArtifactConfig artifactConfig) {

        if (!CollectionUtils.isEmpty(artifactConfig.getTags())) {
            List<Tag> tags = Lists.newArrayListWithExpectedSize(artifactConfig.getTags().size());

            for (Tag tag : artifactConfig.getTags()) {
                tags.add(new Tag(tag.getTag().trim()));
            }

            artifactConfig.setTags(tags);
        }
    }

    private String ensureArtifactNotDeployedToHosts(final ArtifactConfig artifactConfig, final Set<Host> hostsRemoved) {
        GluProcessManager gluProcessManager = gluProcessManagerFactory.get(artifactConfig.getEnvironment());
        for (Host host : hostsRemoved) {
            String mountPoint = ArtifactEntryConvertor.buildMountPoint(host.getHostname(), artifactConfig);

            boolean deployed = gluProcessManager.isProcessDeployed(host.getHostname(), mountPoint);
            if (deployed) {
                return host.getHostname();
            }
        }
        return null;
    }

    private static <T> Set<T> set(final List<T> list) {
        if (CollectionUtils.isEmpty(list)) {
            return Collections.emptySet();
        }
        return Sets.newHashSet(list);
    }

    private ArtifactConfig createId(final Environment environment, final String groupId, final String artifactId) {
        ArtifactConfig id = new ArtifactConfig();
        id.setGroupId(groupId);
        id.setArtifactId(artifactId);
        id.setEnvironment(environment);
        return id;
    }

    private ArtifactConfig initialise(final ArtifactConfig artifactConfig) {
        if (artifactConfig == null) {
            return null;
        }
        return FULL_MAPPER.apply(artifactConfig);
    }

    private ArtifactCommonConfig initialise(final ArtifactCommonConfig config, final boolean followDependencies) {
        ArtifactCommonConfig copy = new ArtifactCommonConfig(config.getGroupId(), config.getArtifactId(),
                config.isNonProd(), config.hasProperties(), config.getPropertyTemplates(), config.getLastUpdatedTime());
        return copyOnto(config, followDependencies, copy);
    }

    protected ArtifactCommonConfig copyOnto(final ArtifactCommonConfig config, final boolean followDependencies,
            final ArtifactCommonConfig copy) {
        copy.setNotDeployedEnvironments(transform(config.getNotDeployedEnvironments(),
                EnvironmentCloneFunction.INSTANCE));

        // the dependency tree is potentially a recursive structure.
        if (followDependencies && config.getDependencies() != null) {
            List<ArtifactCommonConfig> deps = Lists.newArrayList(Lists.transform(config.getDependencies(),
                    new Function<ArtifactCommonConfig, ArtifactCommonConfig>() {
                        @Override
                        public ArtifactCommonConfig apply(final ArtifactCommonConfig input) {
                            ArtifactType artifactType = artifactTypeService.getArtifactType(input.getArtifact());
                            ArtifactCommonConfig dependencyCopy = new ArtifactCommonConfigWithType(input, artifactType);
                            return copyOnto(input, false, dependencyCopy);
                        }
                    }));

            copy.setDependencies(deps);
        }
        return copy;
    }

    private Host initialise(final Host input) {
        Host result = new Host();
        if (input.getDeployTags() != null) {
            result.setDeployTags(new ArrayList<DeployTag>(input.getDeployTags()));
        }
        result.setEnvironment(input.getEnvironment());
        result.setHostname(input.getHostname());
        result.setLastUpdatedTime(input.getLastUpdatedTime());

        return result;
    }

    // TODO The only reason this object is being cloned is to stop hibernate proxies from getting in the way
    // during serialisation. Consider improving.
    public static final Function<ArtifactConfig, ArtifactConfig> FULL_MAPPER = new Function<ArtifactConfig, ArtifactConfig>() {
        @Override
        public ArtifactConfig apply(final ArtifactConfig input) {
            ArtifactConfig result = new ArtifactConfig();
            result.setArtifactId(input.getArtifactId());
            result.setArtifactVersion(input.getArtifactVersion());
            if (input.getDeployTags() != null) {
                result.setDeployTags(new ArrayList<DeployTag>(input.getDeployTags()));
            }
            result.setColdStandby(input.isColdStandby());
            result.setEnvironment(input.getEnvironment());
            result.setGroupId(input.getGroupId());
            result.setLastUpdatedTime(input.getLastUpdatedTime());
            result.setMountPointScheme(input.getMountPointScheme());
            result.setName(input.getName());
            result.setScript(input.getScript());
            result.setScriptArguments(input.getScriptArguments());
            if (input.getTags() != null) {
                result.setTags(new ArrayList<Tag>(input.getTags()));
            }
            return result;
        }
    };

    private Environment environment(final String organisation, final String environment) {
        return environmentDao.loadEnvironment(environment, organisation);
    }

    @Required
    public void setGluScriptFinder(final GluScriptFinder gluScriptFinder) {
        this.gluScriptFinder = gluScriptFinder;
    }

    @Required
    public void setArtifactConfigurationDao(final ArtifactConfigurationDao artifactConfigurationDao) {
        this.artifactConfigurationDao = artifactConfigurationDao;
    }

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

    @Required
    public void setGluProcessManagerFactory(final EnvironmentBeanFactory<GluProcessManager> gluProcessManagerFactory) {
        this.gluProcessManagerFactory = gluProcessManagerFactory;
    }

    @Required
    public void setOrgEnvironmentsMap(final OrganisationBeanFactory<List<String>> orgEnvironmentsMap) {
        this.orgEnvironmentsMap = orgEnvironmentsMap;
    }

    @Required
    public void setHostDao(final HostDao hostDao) {
        this.hostDao = hostDao;
    }

    @Required
    public void setDeployTagDao(final DeployTagDao deployTagDao) {
        this.deployTagDao = deployTagDao;
    }

    @Required
    public void setTagDao(final TagDao tagDao) {
        this.tagDao = tagDao;
    }

    @Required
    public void setCommonConfigDao(final ArtifactCommonConfigDao commonConfigDao) {
        this.commonConfigDao = commonConfigDao;
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }

    @Required
    public void setNexusArtifactService(final NexusArtifactService nexusArtifactService) {
        this.nexusArtifactService = nexusArtifactService;
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

    @Required
    public void setArtifactConfigBulkUploadParser(final ArtifactConfigBulkUploadParser artifactConfigBulkUploadParser) {
        this.artifactConfigBulkUploadParser = artifactConfigBulkUploadParser;
    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }

    @Required
    public void setArtifactTypeService(final ArtifactTypeService artifactTypeService) {
        this.artifactTypeService = artifactTypeService;
    }
}
