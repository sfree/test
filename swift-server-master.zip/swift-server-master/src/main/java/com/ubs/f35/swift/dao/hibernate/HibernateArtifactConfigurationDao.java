package com.ubs.f35.swift.dao.hibernate;

import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.DeployTag;
import com.ubs.f35.swift.config.model.Tag;
import com.ubs.f35.swift.dao.ArtifactConfigurationDao;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.model.Environment;

public class HibernateArtifactConfigurationDao extends HibernateAuditableEntityDao<ArtifactConfig, ArtifactConfig>
        implements ArtifactConfigurationDao {

    private static final Logger LOG = LoggerFactory.getLogger(HibernateArtifactConfigurationDao.class);

    private HibernateDeployTagDao deployTagDao;
    private EnvironmentDao environmentDao;

    @Required
    public void setDeployTagDao(final HibernateDeployTagDao deployTagDao) {
        this.deployTagDao = deployTagDao;
    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }

    @Override
    public ArtifactConfig save(final ArtifactConfig artifact) {
        LOG.debug("saving artifact configuration {}", artifact);

        deployTagDao.mergeDeployTags(artifact);
        final List<Tag> persistentTags = mergeCollection(Tag.class, artifact.getTags(), new Function<Tag, String>() {
            @Override
            public String apply(final Tag input) {
                return input.getTag();
            }
        });
        artifact.setTags(persistentTags);

        // Again, this shouldn't be required, but hibernate is killing properties on new objects in a merge.
        // This may not be required if a single id field was used.
        ArtifactConfig existing = load(ArtifactConfig.class, artifact);
        ArtifactConfig updated = artifact;
        if (existing != null) {
            updated = (ArtifactConfig) getSession().merge(artifact);
        } else {
            getSession().save(artifact);
        }

        getSession().flush();

        return updated;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ArtifactConfig> load(final Environment environment, final String groupId, final String artifactId) {
        Environment persistentEnv = environmentDao.loadEnvironment(environment);

        return getSession().createCriteria(ArtifactConfig.class)
                .add(Restrictions.eq("environment", persistentEnv))
                .add(Restrictions.eq("groupId", groupId))
                .add(Restrictions.eq("artifactId", artifactId))
                .list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ArtifactConfig> load(final List<Environment> environments, final String groupId, final String artifactId) {
        if (environments.isEmpty()) {
            return Lists.newArrayList();
        }
        return getSession().createCriteria(ArtifactConfig.class)
                .add(Restrictions.in("environment", environments))
                .add(Restrictions.eq("groupId", groupId))
                .add(Restrictions.eq("artifactId", artifactId))
                .list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ArtifactConfig> load(final String groupId, final String artifactId) {
        return getSession().createCriteria(ArtifactConfig.class)
                .add(Restrictions.eq("groupId", groupId))
                .add(Restrictions.eq("artifactId", artifactId))
                .list();
    }

    @Override
    public ArtifactConfig load(final Environment environment, final String groupId, final String artifactId,
            final String name) {
        ArtifactConfig id = createId(environment, groupId, artifactId, name);

        return load(ArtifactConfig.class, id);
    }

    @Override
    public void delete(final Environment environment, final String groupId, final String artifactId, final String name) {
        ArtifactConfig id = createId(environment, groupId, artifactId, name);
        getSession().delete(load(ArtifactConfig.class, id));
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ArtifactConfig> loadAll() {
        return getSession().createCriteria(ArtifactConfig.class).list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ArtifactConfig> loadAll(final Environment environment) {
        return getSession().createCriteria(ArtifactConfig.class).add(Restrictions.eq("environment", environment))
                .list();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<ArtifactConfig> loadWithDeployTags(final Set<DeployTag> exclusionList,
            final Set<DeployTag> inclusionList) {
        Assert.notEmpty(inclusionList);

        Criteria criteria = getSession().createCriteria(ArtifactConfig.class, "a").createCriteria("deployTags", "dt");

        // Find any artifact with one or more of the inclusion tags
        Disjunction inclusionFilter = Restrictions.disjunction();
        for (DeployTag include : inclusionList) {
            // Note that Hibernate Example criteria can not be used as they ignore id properties
            inclusionFilter.add(Restrictions.and(
                    Restrictions.eq("dt.environment", include.getEnvironment()),
                    Restrictions.eq("dt.tag", include.getTag())));

        }
        criteria.add(inclusionFilter);

        // Exclude from the results if the artifact has any of the excluded deploy tags
        if (!CollectionUtils.isEmpty(exclusionList)) {
            for (DeployTag exclude : exclusionList) {
                DetachedCriteria excludeCriteria = DetachedCriteria.forClass(ArtifactConfig.class, "a2")
                        .createCriteria("deployTags", "dt2");

                excludeCriteria.add(Restrictions.eq("dt2.environment", exclude.getEnvironment()));
                excludeCriteria.add(Restrictions.eq("dt2.tag", exclude.getTag()));
                excludeCriteria.add(Restrictions.eqProperty("a.groupId", "a2.groupId"));
                excludeCriteria.add(Restrictions.eqProperty("a.artifactId", "a2.artifactId"));
                excludeCriteria.add(Restrictions.eqProperty("a.environment", "a2.environment"));
                excludeCriteria.add(Restrictions.eqProperty("a.name", "a2.name"));
                excludeCriteria.setProjection(Projections.property("a2.environment"));

                criteria.add(Subqueries.notExists(excludeCriteria));
            }
        }
        criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        return criteria.list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Object[]> loadArtifactsWhichDifferentVersions(final Environment env1, final Environment env2) {
        // Run this against oracle

        // SELECT * FROM (SELECT * from ARTIFACT_CONFIG WHERE ENVIRONMENT = 'dev0') A
        // FULL OUTER JOIN (SELECT * from ARTIFACT_CONFIG WHERE ENVIRONMENT = 'dev2') B
        // ON A.GROUP_ID = B.GROUP_ID
        // AND A.ARTIFACT_ID = B.ARTIFACT_ID
        // AND A.NAME = B.NAME
        // WHERE (A.ARTIFACTVERSION IS NULL OR B.ARTIFACTVERSION IS NULL OR A.ARTIFACTVERSION <> B.ARTIFACTVERSION)

        // This query is not possible in HQL as we are NOT expanding on a relationship between the 2 tables.
        Query query = getSession()
                .createSQLQuery(
                        "SELECT {A.*}, {B.*} "
                                + "FROM (SELECT C.* from {h-schema}ARTIFACT_CONFIG C WHERE C.ENVIRONMENT_ID = :env1) A "
                                + "FULL OUTER JOIN (SELECT C.* from {h-schema}ARTIFACT_CONFIG C WHERE C.ENVIRONMENT_ID = :env2) B "
                                + "ON A.GROUP_ID = B.GROUP_ID "
                                + "AND A.ARTIFACT_ID = B.ARTIFACT_ID "
                                + "AND A.NAME = B.NAME "
                                + "WHERE (A.ARTIFACTVERSION IS NULL OR B.ARTIFACTVERSION IS NULL OR A.ARTIFACTVERSION <> B.ARTIFACTVERSION)")
                .addEntity("A", ArtifactConfig.class)
                .addEntity("B", ArtifactConfig.class)
                .setInteger("env1", env1.getId())
                .setInteger("env2", env2.getId());

        return query.list();
    }

    private ArtifactConfig createId(final Environment environment, final String groupId, final String artifactId,
            final String name) {
        ArtifactConfig id = new ArtifactConfig();
        id.setGroupId(groupId);
        id.setArtifactId(artifactId);
        id.setEnvironment(environment);
        id.setName(name);
        return id;
    }

    @Override
    Class<ArtifactConfig> getValueClass() {
        return ArtifactConfig.class;
    }

}
