package com.ubs.f35.swift.dao;

import java.util.UUID;

/**
 * A store of short term state. The state is tied to a single user.
 */
public interface StateStore {

    <T> T load(UUID stateId, Class<T> type);

    UUID create(Object state);

    <T> UUID createOrUpdate(UUID stateId, T state);

}
