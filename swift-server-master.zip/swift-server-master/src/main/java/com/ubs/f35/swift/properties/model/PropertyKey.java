package com.ubs.f35.swift.properties.model;

import org.codehaus.jackson.annotate.JsonProperty;

import com.google.common.base.Objects;

public class PropertyKey implements Comparable<PropertyKey> {
    /**
     * The property name.
     */
    private final String name;
    /**
     * If the properties template has a specified value, this will be used as a default suggestion when configuring for
     * the first time.
     */
    private final String suggestedValue;
    /**
     * Any comments stored in the properties template will be used as documentation for configuring that property.
     */
    private final String documentation;

    public PropertyKey(@JsonProperty("name") final String name,
            @JsonProperty("suggestedValue") final String suggestedValue,
            @JsonProperty("documentation") final String documentation) {
        this.name = name;
        this.suggestedValue = suggestedValue;
        this.documentation = documentation;
    }

    public String getName() {
        return name;
    }

    public String getSuggestedValue() {
        return suggestedValue;
    }

    public String getDocumentation() {
        return documentation;
    }

    @Override
    public int compareTo(final PropertyKey o) {
        return this.name.compareToIgnoreCase(o.name);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, suggestedValue, documentation);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof PropertyKey) {
            PropertyKey that = (PropertyKey) object;
            return Objects.equal(this.name, that.name)
                    && Objects.equal(this.suggestedValue, that.suggestedValue)
                    && Objects.equal(this.documentation, that.documentation);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("name", name)
                .add("suggestedValue", suggestedValue)
                .add("documentation", documentation)
                .toString();
    }

}
