package com.ubs.f35.swift.properties;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.google.common.base.Predicate;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.config.model.DeployTag;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.HostDao;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.GluHostStatusManager;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.model.HostStatus;
import com.ubs.f35.swift.processor.ProcessorUtil;
import com.ubs.f35.swift.util.HostNameFunction;
import com.ubs.f35.swift.util.LoadingCacheUtil;

/**
 * Returns an agent running on a host which is considered healthy. Client of this service can flag an agent as dodgy if
 * they aren't convinced that it is working and request another agent.
 * <p>
 * This implementation performs some caching of the returned agent to avoid constant recomputation of the most healthy
 * agent.
 * 
 * @author stephelu
 * 
 */
@ManagedResource
public class HealthyAgentProvider {
    private static final Logger LOG = LoggerFactory.getLogger(HealthyAgentProvider.class);

    static final String ZK_AGENT_TAG = "ZK-REMOTE-AGENT";

    private EnvironmentBeanFactory<GluHostStatusManager> hostStatusManagerFactory;
    private HostDao hostDao;

    private final Cache<String, Boolean> dodgyAgents = CacheBuilder.newBuilder().expireAfterWrite(10, TimeUnit.MINUTES)
            .build();

    private final LoadingCache<Environment, String> healthyAgentCache = CacheBuilder.newBuilder()
            .expireAfterWrite(10, TimeUnit.MINUTES).build(new CacheLoader<Environment, String>() {
                @Override
                public String load(final Environment environment) throws Exception {
                    List<Host> hosts = findCandidateHosts(environment);
                    List<String> hostNames = ProcessorUtil.transform(hosts, HostNameFunction.INSTANCE);

                    GluHostStatusManager hostStatusManager = hostStatusManagerFactory.get(environment);
                    List<HostStatus> hostStatuses = hostStatusManager.getHostHealth(hostNames);

                    Collections.sort(hostStatuses, HealthAgentComparator.INSTANCE);

                    // Never return an agent which is down.
                    HostStatus bestMatch = Iterables.find(hostStatuses, new Predicate<HostStatus>() {
                        @Override
                        public boolean apply(final HostStatus hostStatus) {
                            return hostStatus.isAgentUp() && !isDodgyAgent(hostStatus);
                        }
                    }, null);

                    if (bestMatch == null) {
                        LOG.warn("Could not find a healthy agent in environment {}", environment);
                        throw new NoHealthyAgentException();
                    }

                    LOG.info("Healthy host for {} is {}", environment, bestMatch);

                    return bestMatch.getHost();
                }

            });

    /**
     * JMX friendly equivalent of {@link #provideAgent(Environment)}
     * 
     * @param environment
     * @return
     */
    @Transactional(readOnly = true)
    @ManagedOperation
    @ManagedOperationParameters(value = {
            @ManagedOperationParameter(name = "organisation", description = "The organisation the environment belongs to"),
            @ManagedOperationParameter(name = "environment", description = "The environment to find a healthy agent for") })
    public String provideAgent(final String organisation, final String environment) {
        try {
            return LoadingCacheUtil.getUnchecked(healthyAgentCache, new Environment(environment, organisation));
        } catch (NoHealthyAgentException ex) {
            return null;
        }
    }

    /**
     * Returns the most healthy agent for this environment.
     * 
     * @return the most healthy agent or null if there are no healthy agents
     */
    public String provideAgent(final Environment environment) {
        try {
            return LoadingCacheUtil.getUnchecked(healthyAgentCache, environment);
        } catch (NoHealthyAgentException ex) {
            return null;
        }
    }

    /**
     * JMX friendly version of {@link #flagDodgyAgent(Environment, String)}
     * 
     * @param environment
     * @param agent
     */
    @Transactional(readOnly = true)
    @ManagedOperation
    @ManagedOperationParameters(value = {
            @ManagedOperationParameter(name = "organisation", description = "The organisation the environment belongs to"),
            @ManagedOperationParameter(name = "environment", description = "The environment to use"),
            @ManagedOperationParameter(name = "agent", description = "The agent to flag as unhealthy") })
    public void flagDodgyAgent(final String organisation, final String environment, final String agent) {
        flagDodgyAgent(new Environment(environment, organisation), agent);
    }

    public void flagDodgyAgent(final Environment environment, final String agent) {
        LOG.warn("Agent {} in environment {} has been flagged as not responsive", agent, environment);

        dodgyAgents.put(agent, true);
        if (agent.equals(provideAgent(environment))) {
            // Force recomputation of the healthy agents
            healthyAgentCache.invalidate(environment);
        }
    }

    /**
     * Finds hosts which have been tagged as used for zookeeper. If no hosts are tagged, returns all hosts for the
     * environment.
     * 
     * @param environment
     * @return
     */
    private List<Host> findCandidateHosts(final Environment environment) {
        List<Host> hosts = hostDao.loadByEnvironment(environment);

        List<Host> taggedCandidateHosts = Lists.newArrayList();

        for (Host host : hosts) {
            if (!CollectionUtils.isEmpty(host.getDeployTags())
                    && Iterables.any(host.getDeployTags(), CandiateAgent.INSTANCE)) {
                taggedCandidateHosts.add(host);
            }
        }

        if (!CollectionUtils.isEmpty(taggedCandidateHosts)) {
            return taggedCandidateHosts;
        }
        return hosts;
    }

    private boolean isDodgyAgent(final HostStatus hostStatus) {
        return dodgyAgents.getIfPresent(hostStatus.getHost()) != null;
    }

    private static class HealthAgentComparator implements Comparator<HostStatus> {
        static final HealthAgentComparator INSTANCE = new HealthAgentComparator();

        @Override
        public int compare(final HostStatus o1, final HostStatus o2) {
            return ComparisonChain.start()
                    .compareTrueFirst(o1.isAgentUp(), o2.isAgentUp())
                    .compareTrueFirst(o1.isMonitorUp(), o2.isMonitorUp())
                    .compare(safeGetLoadAverage(o1), safeGetLoadAverage(o2)).result();

        }

        private static Double safeGetLoadAverage(final HostStatus host) {
            // assume a high load average if none found
            if (CollectionUtils.isEmpty(host.getLoadAverages())) {
                return 2.0;
            }
            return host.getLoadAverages().get(0);
        }
    }

    private static class NoHealthyAgentException extends RuntimeException {
    }

    private static class CandiateAgent implements Predicate<DeployTag> {
        static final CandiateAgent INSTANCE = new CandiateAgent();

        @Override
        public boolean apply(final DeployTag input) {
            return ZK_AGENT_TAG.equals(input.getTag());
        }
    }

    @Required
    public void setHostStatusManagerFactory(final EnvironmentBeanFactory<GluHostStatusManager> hostStatusManagerFactory) {
        this.hostStatusManagerFactory = hostStatusManagerFactory;
    }

    @Required
    public void setHostDao(final HostDao hostDao) {
        this.hostDao = hostDao;
    }

}
