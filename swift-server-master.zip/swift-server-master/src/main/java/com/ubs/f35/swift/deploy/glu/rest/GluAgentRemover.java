package com.ubs.f35.swift.deploy.glu.rest;

import java.util.List;
import java.util.concurrent.Callable;

import org.apache.zookeeper.KeeperException;
import org.linkedin.zookeeper.client.ZKClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.HostDao;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.service.AbstractJmxProcessor;

@ManagedResource
@Transactional
public class GluAgentRemover extends AbstractJmxProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(GluAgentRemover.class);
    private EnvironmentBeanFactory<GluProcessManager> gluProcessManagerFactory;
    private EnvironmentBeanFactory<ZKClient> zkClientFactory;
    private EnvironmentDocumentStore environmentDocumentStore;
    private GluAgentDiscoverer gluAgentDiscoverer;
    private EnvironmentBeanFactory<String> zookeeperRootFactory;
    private HostDao hostDao;

    @ManagedOperation(description = "Removes an agent from an environment.  Note that to migrate the agent to a new environment it must be manually be reassigned to the correct environment in it's startup script after removing it using this operation")
    @ManagedOperationParameters(value = {
            @ManagedOperationParameter(name = "agent", description = "The agent to migrate"),
            @ManagedOperationParameter(name = "organisation", description = "The organisation the environment belongs to"),
            @ManagedOperationParameter(name = "currentEnvironment", description = "The environment the agent is currently assigned to") })
    public String removeAgent(final String agent, final String organisation, final String currentEnvironment) {
        return executeOperation(new Callable<String>() {
            @Override
            public String call() throws Exception {
                return removeAgentInternal(agent, new Environment(currentEnvironment, organisation), false);
            }
        });
    }

    /**
     * An agent may need to be removed even if artifacts are still mapped to it. The host may have had a catastrophic
     * hardware failure preventing the agent from being restarted.
     */
    @ManagedOperation(description = "Force removes an agent from an environment even if artifacts are still mapped to run on it.  Note that to migrate the agent to a new environment it must be manually be reassigned to the correct environment in it's startup script after removing it using this operation")
    @ManagedOperationParameters(value = {
            @ManagedOperationParameter(name = "agent", description = "The agent to migrate"),
            @ManagedOperationParameter(name = "organisation", description = "The organisation the environment belongs to"),
            @ManagedOperationParameter(name = "currentEnvironment", description = "The environment the agent is currently assigned to"),
            @ManagedOperationParameter(name = "force", description = "Enter 'force' to confirm your intention") })
    public String forceRemoveAgent(final String agent, final String organisation, final String currentEnvironment,
            final String force) {
        return executeOperation(new Callable<String>() {
            @Override
            public String call() throws Exception {
                Assert.isTrue("force".equalsIgnoreCase(force),
                        "force parameter must be given a value of 'force' to confirm your intention");
                return removeAgentInternal(agent, new Environment(currentEnvironment, organisation), true);
            }
        });
    }

    private String removeAgentInternal(final String agent, final Environment environment, final boolean force)
            throws InterruptedException,
            KeeperException {
        Host host = hostDao.loadExpected(agent);
        if (!host.getEnvironment().equals(environment)) {
            throw new IllegalStateException("Host is currently assigned to environment "
                    + host.getEnvironment().getOrganisation().getName() + ":" + host.getEnvironment().getName());
        }

        // 1. Agent cannot be migrated if any processes are currently mapped to it via swift.
        if (!force) {
            List<Entry> entries = environmentDocumentStore.filterByAgent(environment, agent);
            for (Entry entry : entries) {
                throw new IllegalStateException("Cannot remove while " + entry.getArtifactId()
                        + " is mapped to this agent.  Please undeploy first.");
            }
        }

        // 2. Agent cannot be migrated if currently running against currentEnvironment
        if (!gluProcessManagerFactory.get(environment).isAgentDown(agent)) {
            throw new IllegalStateException("Agent is still running against environment " + environment.getName()
                    + ". Please stop the agent first.");
        }
        LOG.info("Agent is not running or is running against new environment.");

        // 3. Good to go.

        String zookeeperRoot = zookeeperRootFactory.get(environment);
        // 3a. Remove all mention of the agent from zookeeper.
        deletePath(environment, zookeeperRoot + "/agents/fabrics/" + environment.getName() + "/state/" + agent);
        deletePath(environment, zookeeperRoot + "/agents/names/" + agent);

        // 3b. Remove agent from host configuration tables.
        hostDao.deleteHost(host);

        // 3c. Remove agent from known agents cache
        gluAgentDiscoverer.removeAgent(environment, agent);

        return "Host removed from environment. Note that to migrate the agent to a new environment it must be manually be reassigned to the correct environment in it's startup script";
    }

    private void deletePath(final Environment currentEnvironment, final String agentPath) throws InterruptedException,
            KeeperException {
        if (zkClientFactory.get(currentEnvironment).exists(agentPath) != null) {
            zkClientFactory.get(currentEnvironment).deleteWithChildren(agentPath);
        }
    }

    @Required
    public void setGluProcessManagerFactory(final EnvironmentBeanFactory<GluProcessManager> gluProcessManagerFactory) {
        this.gluProcessManagerFactory = gluProcessManagerFactory;
    }

    @Required
    public void setZkClientFactory(final EnvironmentBeanFactory<ZKClient> zkClientFactory) {
        this.zkClientFactory = zkClientFactory;
    }

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

    @Required
    public void setGluAgentDiscoverer(final GluAgentDiscoverer gluAgentDiscoverer) {
        this.gluAgentDiscoverer = gluAgentDiscoverer;
    }

    @Required
    public void setHostDao(final HostDao hostDao) {
        this.hostDao = hostDao;
    }

    @Required
    public void setZookeeperRootFactory(final EnvironmentBeanFactory<String> zookeeperRootFactory) {
        this.zookeeperRootFactory = zookeeperRootFactory;
    }
}
