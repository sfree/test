package com.ubs.f35.swift.processor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubs.f35.swift.dao.ReleaseWatchDao;
import com.ubs.f35.swift.dao.model.ReleaseWatch.WatchType;
import com.ubs.f35.swift.state.OperationContextProvider;

/**
 * Rest APIs for managing release watches
 */
@Controller
@RequestMapping(value = "/api/watch")
@Transactional
public class WatchProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(WatchProcessor.class);

    private OperationContextProvider opContextProvider;
    private ReleaseWatchDao releaseWatchDao;

    @RequestMapping(value = "/release/{releaseId}", method = RequestMethod.GET)
    @ResponseBody
    public List<WatchType> getReleaseWatches(@PathVariable final Integer releaseId) {
        return releaseWatchDao.loadWatches(releaseId, opContextProvider.getCurrentUser());
    }

    @RequestMapping(value = "/release/{releaseId}/{watchType}", method = RequestMethod.PUT)
    public void addReleaseWatch(@PathVariable final Integer releaseId, @PathVariable final WatchType watchType) {
        releaseWatchDao.addWatch(releaseId, watchType, opContextProvider.getCurrentUser());
    }

    @RequestMapping(value = "/release/{releaseId}/{watchType}", method = RequestMethod.DELETE)
    public void deleteReleaseWatch(@PathVariable final Integer releaseId, @PathVariable final WatchType watchType) {
        releaseWatchDao.removeWatch(releaseId, watchType, opContextProvider.getCurrentUser());
    }

    @Required
    public void setOpContextProvider(final OperationContextProvider contextProvider) {
        this.opContextProvider = contextProvider;
    }

    @Required
    public void setReleaseWatchDao(final ReleaseWatchDao releaseWatchDao) {
        this.releaseWatchDao = releaseWatchDao;
    }
}
