package com.ubs.f35.swift.io.processor;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.CollectionUtils;

import com.google.common.base.Predicate;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.AgentStateChangeListener;
import com.ubs.f35.swift.deploy.glu.rest.GluProcessManager;
import com.ubs.f35.swift.deploy.glu.rest.ProcessStateChangeListener;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.model.ArtifactDeploymentStatus;
import com.ubs.f35.swift.model.ArtifactInstanceId;
import com.ubs.f35.swift.model.JsonObjectMapper;
import com.ubs.f35.swift.model.State;
import com.ubs.f35.swift.model.StatusFilter;
import com.ubs.f35.swift.processor.StatusProcessor;
import com.ubs.f35.swift.service.glu.EntryFilterPredicateFactory;
import com.ubs.sapi.service.StreamingAdaptor;
import com.ubs.sapi.service.context.StreamingInboundContext;
import com.ubs.stomp.model.client.SubscribeFrame;
import com.ubs.stomp.model.client.UnsubscribeFrame;
import com.ubs.stomp.model.server.MessageFrame;

/**
 * Subscription to post back to the client changes to the status of an entries on the status dashboard.
 * <p>
 * Note that the subcription criteria does not include the fields which are expected to dynamically change, status and
 * state. This is because even if the client only wants to see items in an error state, it still needs to receive a
 * notification of when those items move from a error to happy state so the item could be removed from the list.
 * <p>
 * The subscription documentation advises against using topic identifiers which are too long, as they are communicated
 * with each message. This is somewhat mitigated by the fact that the longer the filter, the less messages that will be
 * sent for that topic id. This only holds true if longer filters are more restrictive, and this approach may need to be
 * reconsidered if that changes.
 * <p>
 * The client should always sort the fields used to build the filter in the same order so that duplicate subscriptions
 * are not created for the same effective criteria.
 * 
 * @author stephelu
 * 
 */
public class SubscriptionStatusProcessor extends StreamingAdaptor implements ProcessStateChangeListener,
        AgentStateChangeListener {
    private static final Logger LOG = LoggerFactory.getLogger(SubscriptionStatusProcessor.class);

    private final ConcurrentHashMap<String, FilterPair> subscriptionHandles = new ConcurrentHashMap<String, FilterPair>();
    private final JsonObjectMapper mapper = new JsonObjectMapper();

    private EntryFilterPredicateFactory entryFilterPredicateFactory;
    private EnvironmentDocumentStore environmentDocumentStore;
    private EnvironmentBeanFactory<GluProcessManager> gluProcessManagerFactory;

    private final AtomicLong numUpdates = new AtomicLong();

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

    @Required
    public void setGluProcessManagerFactory(final EnvironmentBeanFactory<GluProcessManager> gluProcessManagerFactory) {
        this.gluProcessManagerFactory = gluProcessManagerFactory;
    }

    @Required
    public void setEntryFilterPredicateFactory(final EntryFilterPredicateFactory entryFilterPredicateFactory) {
        this.entryFilterPredicateFactory = entryFilterPredicateFactory;
    }

    @Override
    public boolean subscribe(final StreamingInboundContext<SubscribeFrame> context) {
        String dest = context.frame().getDestination();
        if (firstSubscription(dest)) {
            subscribe(dest);
        }
        return super.subscribe(context);
    }

    @Override
    public boolean unsubscribe(final StreamingInboundContext<UnsubscribeFrame> context) {
        String dest = context.service().destination(context.connection(), context.frame().getId());
        if (lastSubscription(dest)) {
            unsubscribe(dest);
        }
        return super.unsubscribe(context);
    }

    private boolean firstSubscription(final String dest) {
        return dest != null && service().subscriptionCount(dest) == 0;
    }

    private boolean lastSubscription(final String dest) {
        return dest != null && service().subscriptionCount(dest) == 1;
    }

    public void unsubscribe(final String destination) {
        LOG.debug("Removing subscription for {}", destination);
        subscriptionHandles.remove(destination);
    }

    public void subscribe(final String destination) {
        LOG.debug("Creating subscription for {}", destination);
        subscriptionHandles.put(destination, getFilterPair(destination));
    }

    @Override
    public void processStateChanged(final Environment env, final String mountPoint, final Entry removedEntry) {
        Entry entry = environmentDocumentStore.tryFilterByMountPoint(env, mountPoint);

        if (entry != null) {
            notifyChangesToEntry(env, entry);
        } else if (removedEntry != null) {
            LOG.debug("Entry has been removed.  Sending hide notification.", mountPoint, env);
            // Send a hide notification.
            String id = ArtifactInstanceId.buildId(env, mountPoint);
            ArtifactDeploymentStatus status = new ArtifactDeploymentStatus(removedEntry, null, env);
            for (FilterPair filterPair : subscriptionHandles.values()) {
                if (matchesEnvFilter(filterPair, status) && matchesEntryFilter(filterPair, status)) {
                    sendMessageTo(filterPair, new HideRecordMessage(env.getName(), id));
                }
            }
        } else {
            // This could occur if dev1 swift is receiving notifications from artifacts deployed by another instance of
            // swift.
            LOG.debug(
                    "Received notification for status change to mount {} in environment {} which is unknown. Ignoring.",
                    mountPoint, env);
        }
    }

    @Override
    public void agentStateChanged(final Environment environment, final String agent, final boolean alive) {
        List<Entry> agentEntries = environmentDocumentStore.filterByAgent(environment, agent);
        for (Entry entry : agentEntries) {
            notifyChangesToEntry(environment, entry);
        }
    }

    private void notifyChangesToEntry(final Environment env, final Entry entry) {
        GluProcessManager gluProcessManager = gluProcessManagerFactory.get(env);

        State state = gluProcessManager.getProcessState(entry);

        ArtifactDeploymentStatus artifactDeploymentStatus = new ArtifactDeploymentStatus(entry, state, env);

        notifySubscriptionsOfChange(artifactDeploymentStatus);
    }

    private void notifySubscriptionsOfChange(final ArtifactDeploymentStatus status) {
        LOG.debug("Checking for subscriptions to notify of change to {}", status);

        LOG.debug("Number of updates sent to client {}", numUpdates.incrementAndGet());

        for (FilterPair filterPair : subscriptionHandles.values()) {
            if (matchesEnvFilter(filterPair, status) && matchesEntryFilter(filterPair, status)) {
                String topicId = filterPair.destination;

                List<String> stateFilter = filterPair.filter.getStates();
                List<String> statusFilter = filterPair.filter.getStatuses();

                boolean show = StatusProcessor.matchesStateAndStatusFilters(stateFilter, statusFilter,
                        status.getState());

                Object message;
                if (show) {
                    LOG.info("Notifying handle {} of visible changes to entry {}", topicId, status.getId());
                    message = status;
                } else {
                    LOG.info("Notifying handle {} to hide entry {}", topicId, status.getId());
                    message = new HideRecordMessage(status.getEnvironment(), status.getId());
                }
                sendMessageTo(filterPair, message);

            }
        }
    }

    private void sendMessageTo(final FilterPair filterPair, final Object message) {
        MessageFrame messageFrame = MessageFrame.builder().setDestination(filterPair.destination)
                .setBody(JsonObjectMapper.getInstance().writeValueAsString(message)).build();

        service().send(messageFrame);
    }

    private boolean matchesEntryFilter(final FilterPair FilterPair, final ArtifactDeploymentStatus status) {
        return FilterPair.filterPredicate.apply(status.getEntry());
    }

    private boolean matchesEnvFilter(final FilterPair FilterPair, final ArtifactDeploymentStatus status) {
        List<String> envFilter = FilterPair.filter.getEnvironments();

        return status.getEnvironmentObj().getOrganisation().getName().equals(FilterPair.filter.getOrganisation())
                && (CollectionUtils.isEmpty(envFilter) || envFilter.contains(status.getEnvironment()));
    }

    private FilterPair getFilterPair(final String destination) {

        String topic = destination.substring("/status/".length());
        StatusFilter filter;
        try {
            filter = mapper.readValue(topic, StatusFilter.class);
        } catch (RuntimeException ex) {
            LOG.error("Unable to create subscription for topic {}", topic);
            throw ex;
        }

        Predicate<Entry> filterPredicate = entryFilterPredicateFactory.buildFilterForCriteria(filter);
        return new FilterPair(destination, filter, filterPredicate);
    }

    private static class FilterPair {
        private final String destination;
        private final StatusFilter filter;
        private final Predicate<Entry> filterPredicate;

        public FilterPair(final String destination, final StatusFilter filter, final Predicate<Entry> filterPredicate) {
            this.destination = destination;
            this.filter = filter;
            this.filterPredicate = filterPredicate;
        }

    }

}
