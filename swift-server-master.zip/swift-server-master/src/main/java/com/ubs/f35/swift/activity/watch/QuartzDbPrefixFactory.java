package com.ubs.f35.swift.activity.watch;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.config.AbstractFactoryBean;
import org.springframework.util.StringUtils;

/**
 * Small Factory to determine the table prefix for quartz which differs between hsql and oracle.
 */
public class QuartzDbPrefixFactory extends AbstractFactoryBean<String> {
    private static final String TABLE_PREFIX = org.quartz.impl.jdbcjobstore.Constants.DEFAULT_TABLE_PREFIX;

    private String dbSchema;

    @Override
    public Class<?> getObjectType() {
        return String.class;
    }

    @Override
    protected String createInstance() throws Exception {
        if (StringUtils.hasText(dbSchema)) {
            return dbSchema + '.' + TABLE_PREFIX;
        }
        return TABLE_PREFIX;
    }

    @Required
    public void setDbSchema(final String dbSchema) {
        this.dbSchema = dbSchema;
    }
}
