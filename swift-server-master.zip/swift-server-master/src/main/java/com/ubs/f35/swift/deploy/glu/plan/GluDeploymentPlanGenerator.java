package com.ubs.f35.swift.deploy.glu.plan;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.CollectionUtils;

import com.google.common.base.Function;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentType;
import com.ubs.f35.swift.dao.DeploymentDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.client.rollback.RollbackPrepBuilder;
import com.ubs.f35.swift.deploy.client.rollback.RollbackRequest;
import com.ubs.f35.swift.deploy.glu.state.GluState;
import com.ubs.f35.swift.deploy.template.model.DependencyGraph;
import com.ubs.f35.swift.deploy.template.model.DependencyGraph.DependencyGraphWalkerCallback;
import com.ubs.f35.swift.deploy.template.model.DependencyGraph.WalkPosition;
import com.ubs.f35.swift.deploy.template.model.DeploymentTemplate;
import com.ubs.f35.swift.deploy.validator.DeploymentPlanValidator;
import com.ubs.f35.swift.deploy.validator.ReleaseDeploymentPlanValidator;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.model.TargetedInstanceDeployment;
import com.ubs.f35.swift.service.ArtifactConfigurationService;
import com.ubs.f35.swift.state.OperationContextProvider;

public class GluDeploymentPlanGenerator {
    // be very careful chaning this value - it's used to hide actions from the client. Don't forget it may be persisted
    // in many historical plans as well.
    public static final String ACTION_NAME_PERFORM_RELEASE = "Perform Release";
    private static final DeploymentAction RELEASE_DEPLOY_ACTION = DeploymentAction.Redeploy;

    private EnvironmentDocumentStore environmentDocumentStore;
    private ComponentDeploymentPlanBuilder componentDeploymentPlanBuilder;
    private DeploymentDao deploymentDao;
    private RollbackPrepBuilder rollbackPrepBuilder;
    private OperationContextProvider contextProvider;
    private ArtifactConfigurationService artifactConfigurationService;
    private List<DeploymentPlanValidator> deploymentPlanValidators;
    private List<ReleaseDeploymentPlanValidator> releaseDeploymentPlanValidators;
    private DeploymentPlanFromTemplateGenerator deploymentPlanFromTemplateGenerator;

    public Deployment generateReleaseDeploymentPlan(final ReleaseDefinition release,
            final List<Environment> environments,
            final DeploymentTemplate deploymentTemplate, final List<TargetedInstanceDeployment> deploymentTargets) {

        DeploymentPlan deploymentPlan = generateReleaseDeploymentPlan(release, release.getArtifacts(), environments,
                DeploymentType.Release, deploymentTemplate, deploymentTargets);

        Deployment deployment = Deployment.newReleaseDeployment(
                deploymentPlan,
                environments,
                contextProvider.getCurrentUser(),
                release);

        deploymentDao.create(deployment);

        return deployment;
    }

    public DeploymentPlan generateReleaseRollbackPlan(final ReleaseDefinition release,
            final RollbackRequest rollbackRequest, final Environment environment,
            final DeploymentTemplate deploymentTemplate) {

        List<Artifact> rollbackArtifacts = rollbackRequest.getArtifacts();

        rollbackPrepBuilder.validate(release, environment.getName(), rollbackArtifacts);

        DeploymentPlan deploymentPlan = generateReleaseDeploymentPlan(release, rollbackArtifacts,
                Collections.singletonList(environment),
                DeploymentType.Rollback, deploymentTemplate, null);

        Deployment deployment = Deployment.newReleaseRollbackDeployment(
                deploymentPlan,
                environment,
                contextProvider.getCurrentUser(),
                release,
                rollbackRequest);

        deploymentDao.create(deployment);

        return deploymentPlan;
    }

    /**
     * Generates a deployment plan for a process instance to move into a different state. If this process has
     * dependencies on other processes to be running, those dependencies will be suggested in the deployment plan.
     * 
     * @param mountPoints
     * @param deploymentAction
     * @param environment
     * @return
     */
    public Deployment generateAdhocDeploymentPlan(final List<String> mountPoints,
            final DeploymentAction deploymentAction, final Environment environment,
            final DeploymentPlanStrategy deploymentPlanStrategy) {

        final Set<Entry> entries = environmentDocumentStore.filterByMountPoints(environment, mountPoints);

        final Multimap<NexusArtifact, Entry> entryMap = HashMultimap.create();
        for (Entry entry : entries) {
            NexusArtifact artifact = new NexusArtifact(entry.getGroupId(), entry.getArtifactId());
            entryMap.put(artifact, entry);
        }

        DeploymentPlanBuilder builder = new DeploymentPlanBuilder();

        BaseDependencyPlanWalkerCallBack adhocDeploymentDependencyCallbackWalker = new BaseDependencyPlanWalkerCallBack(
                deploymentAction, environment, deploymentPlanStrategy) {
            @Override
            protected boolean appendComponentActions(final DeploymentPlanBuilder builder, final NexusArtifact artifact,
                    final WalkPosition position) {
                if (entryMap.containsKey(artifact)) {
                    DeploymentActionInstruction componentAction = getComponentAction(deploymentAction, position);
                    if (componentAction != null) {
                        componentDeploymentPlanBuilder.addToDeploymentPlan(builder, environment,
                                entryMap.get(artifact), componentAction);
                    }
                    return true;
                }
                return false;
            }
        };

        // TODO - this logic requires further consideration. For any deployment it's probably not a clear cut black and
        // white only consider one side of the dependency tree.
        // If starting, ensure all dependencies are started.
        boolean includeDependantOnRequested = deploymentAction != DeploymentAction.Start
                && deploymentAction != DeploymentAction.StartOnly;

        generateDeploymentPlan(builder, environment, entryMap.keySet(), adhocDeploymentDependencyCallbackWalker,
                deploymentPlanStrategy, includeDependantOnRequested);

        // Run the validators over the generated plan
        for (DeploymentPlanValidator validator : deploymentPlanValidators) {
            validator.validate(builder, environment, deploymentAction, deploymentPlanStrategy);
        }

        DeploymentPlan deploymentPlan = builder.build();

        Deployment deployment = Deployment.newAdhocDeployment(
                deploymentPlan.getId(),
                environment,
                contextProvider.getCurrentUser(),
                deploymentPlan);
        deploymentDao.create(deployment);

        return deployment;
    }

    private DeploymentPlan generateReleaseDeploymentPlan(final ReleaseDefinition release,
            final List<Artifact> artifacts, final List<Environment> environments, final DeploymentType deploymentType,
            final DeploymentTemplate deploymentTemplate, final List<TargetedInstanceDeployment> deploymentTargets) {

        DeploymentPlanBuilder builder = new DeploymentPlanBuilder();

        builder.startGroupedAction("release", release.getName());

        for (Environment environment : environments) {
            // Find the targets for this environment if specified. If not specified, all instances are targeted.
            TargetedInstanceDeployment envDeploymentTargets = null;
            if (!CollectionUtils.isEmpty(deploymentTargets)) {
                for (TargetedInstanceDeployment deploymentTarget : deploymentTargets) {
                    if (deploymentTarget.getEnvironment().equals(environment.getName())) {
                        envDeploymentTargets = deploymentTarget;
                        break;
                    }
                }
            }

            appendReleaseEnvironmentDeploymentPlan(builder, release, artifacts, environment, deploymentType,
                    deploymentTemplate, envDeploymentTargets);
        }
        builder.completeGroupedAction(true); // Execute the deployment to all environments in parallel.

        return builder.build();
    }

    private void appendReleaseEnvironmentDeploymentPlan(final DeploymentPlanBuilder builder,
            final ReleaseDefinition release, final List<Artifact> artifacts, final Environment environment,
            final DeploymentType deploymentType, final DeploymentTemplate deploymentTemplate,
            final TargetedInstanceDeployment targetedInstanceDeployment) {

        final ImmutableMap<NexusArtifact, Artifact> releaseArtifacts = artifactsIndex(artifacts);

        for (ReleaseDeploymentPlanValidator validator : releaseDeploymentPlanValidators) {
            validator.validate(builder, release, environment, deploymentType == DeploymentType.Rollback);
        }

        builder.startGroupedAction(environment.getName(), environment.getName().toUpperCase());

        ReleaseDeploymentBuildingContext context = new ReleaseDeploymentBuildingContext(builder, releaseArtifacts,
                environment, deploymentType, new AtomicInteger(0), targetedInstanceDeployment);
        deploymentPlanFromTemplateGenerator.visitDeploymentTemplateActions(context, deploymentTemplate);

        builder.forEnvironment(environment);
        // All the grouped dependency levels are added to execute sequentially.
        builder.completeGroupedAction(false);

        // Run the validators over the generated plan
        for (DeploymentPlanValidator validator : deploymentPlanValidators) {
            validator.validate(builder, environment, RELEASE_DEPLOY_ACTION, DeploymentPlanStrategy.NO_DEPS);
        }
    }

    private void generateDeploymentPlan(final DeploymentPlanBuilder builder, final Environment environment,
            final Collection<NexusArtifact> requestedDeploymentArtifacts,
            final DependencyWalkerCallback dependencyWalker, final DeploymentPlanStrategy planStrategy,
            final boolean includeDependantOnRequested) {

        DependencyGraph<NexusArtifact> deploymentArtifacts;
        if (planStrategy.isIncludeDependencies()) {
            if (includeDependantOnRequested) {
                deploymentArtifacts = artifactConfigurationService
                        .getOrderedArtifactsDependentOn(requestedDeploymentArtifacts);
            } else {
                deploymentArtifacts = artifactConfigurationService
                        .getOrderedArtifactsThisDependsOn(requestedDeploymentArtifacts);
            }
        } else {
            deploymentArtifacts = artifactConfigurationService.orderDependencies(requestedDeploymentArtifacts);
        }

        builder.startGroupedAction(environment.getName(), environment.getName().toUpperCase());

        deploymentArtifacts.walkDependencies(new DependencyGraphWalkerCallback<NexusArtifact>() {
            int uniqueId = 0;

            @Override
            public void appendActions(List<NexusArtifact> groupedItems, final WalkPosition position) {
                // Process in reverse order on the way back out.
                if (position == WalkPosition.TOWARDS_PARENTS) {
                    groupedItems = Lists.reverse(groupedItems);
                }
                addActionsAtSameLevelOfTree(builder, groupedItems, dependencyWalker, uniqueId++, position);
            }
        });

        builder.forEnvironment(environment);
        // All the grouped dependency levels are added to execute sequentially.
        builder.completeGroupedAction(false);
    }

    public static ImmutableMap<NexusArtifact, Artifact> artifactsIndex(final List<Artifact> artifacts) {
        ImmutableMap<NexusArtifact, Artifact> releaseArtifacts = Maps.uniqueIndex(artifacts,
                new Function<Artifact, NexusArtifact>() {
                    @Override
                    public NexusArtifact apply(final Artifact input) {
                        return input.getNexusArtifact();
                    }
                });
        return releaseArtifacts;
    }

    private void addActionsAtSameLevelOfTree(final DeploymentPlanBuilder builder,
            final List<NexusArtifact> groupedArtifacts, final DependencyWalkerCallback callback, final int uniqueId,
            final WalkPosition walkPosition) {
        builder.startGroupedAction("parallel-deploy-" + uniqueId, ACTION_NAME_PERFORM_RELEASE);
        for (NexusArtifact artifact : groupedArtifacts) {
            callback.appendActions(builder, artifact, walkPosition);
        }
        builder.completeGroupedAction(true);
    }

    private interface DependencyWalkerCallback {
        void appendActions(DeploymentPlanBuilder builder, NexusArtifact artifact, WalkPosition position);
    }

    abstract class BaseDependencyPlanWalkerCallBack implements DependencyWalkerCallback {

        protected DeploymentAction deploymentAction;
        protected Environment environment;
        private final boolean includeDependencies;

        public BaseDependencyPlanWalkerCallBack(final DeploymentAction deploymentAction, final Environment environment,
                final DeploymentPlanStrategy deploymentPlanStrategy) {
            this.deploymentAction = deploymentAction;
            this.environment = environment;
            this.includeDependencies = deploymentPlanStrategy.isIncludeDependencies();
        }

        @Override
        public final void appendActions(final DeploymentPlanBuilder builder, final NexusArtifact artifact,
                final WalkPosition position) {
            if (!appendComponentActions(builder, artifact, position)) {
                if (includeDependencies) {
                    DeploymentActionInstruction dependencyAction = getDependencyAction(deploymentAction, position);
                    if (dependencyAction != null) {
                        componentDeploymentPlanBuilder.appendDependencyToDeploymentPlan(builder, artifact, environment,
                                dependencyAction);
                    }
                }
            }
        }

        protected abstract boolean appendComponentActions(DeploymentPlanBuilder builder, NexusArtifact artifact,
                WalkPosition position);
    }

    private static DeploymentActionInstruction getComponentAction(final DeploymentAction deploymentAction,
            final WalkPosition position)
    {
        DeploymentAction preExecuteComponentAction = null;
        DeploymentAction postExecuteComponentAction = null;
        List<GluState> postExecuteValidStartState = null;

        switch (deploymentAction) {
        case StartOnly:
            postExecuteComponentAction = DeploymentAction.StartOnly;
            break;
        case Start:
            postExecuteComponentAction = DeploymentAction.Start;
            break;
        case Stop:
            preExecuteComponentAction = DeploymentAction.Stop;
            break;
        case Bounce:
            preExecuteComponentAction = DeploymentAction.Stop;
            postExecuteComponentAction = DeploymentAction.Start;
            postExecuteValidStartState = Arrays.asList(GluState.stopped, GluState.running);
            break;
        case Undeploy:
            preExecuteComponentAction = DeploymentAction.Undeploy;
            break;
        case Redeploy:
            preExecuteComponentAction = DeploymentAction.Undeploy;
            postExecuteComponentAction = DeploymentAction.Start;
            postExecuteValidStartState =
                    Arrays.asList(GluState.nomountpoint, GluState.installed, GluState.stopped, GluState.running);
            break;
        default:
            throw new IllegalArgumentException("Unexpected deployment action " + deploymentAction);
        }
        // If we are at the lowest level, there are no dependencies to work with and release artifacts can be
        // redeployed. If we are at a higher level, the artifact may be a dependency or release artifact which needs to
        // be undeployed.
        if (position == WalkPosition.ROOT) {
            return new DeploymentActionInstruction(deploymentAction);
        } else if (position == WalkPosition.TOWARDS_CHILDREN && preExecuteComponentAction != null) {
            return new DeploymentActionInstruction(preExecuteComponentAction);
        } else if (position == WalkPosition.TOWARDS_PARENTS && postExecuteComponentAction != null) {
            return new DeploymentActionInstruction(postExecuteComponentAction, postExecuteValidStartState);
        } else {
            return null;
        }
    }

    /**
     * Dependencies are only ever started / stopped (i.e. bounced)
     * 
     * @param deploymentAction
     * @param position
     * @return
     */
    private static DeploymentActionInstruction getDependencyAction(final DeploymentAction deploymentAction,
            final WalkPosition position)
    {
        boolean performPreActions = false;
        boolean performPostActions = false;

        switch (deploymentAction) {
        case Start:
        case StartOnly:
            performPostActions = true;
            break;
        case Undeploy:
        case Stop:
            performPreActions = true;
            break;
        case Redeploy:
        case Bounce:
            performPreActions = true;
            performPostActions = true;
            break;
        default:
            throw new IllegalArgumentException("Unexpected deployment action " + deploymentAction);
        }

        if (position == WalkPosition.ROOT) {
            // dependency at the bottom of the tree. Start it back up if stopped
            return new DeploymentActionInstruction(DeploymentAction.Start, Arrays.asList(GluState.stopped));
        } else if (position == WalkPosition.TOWARDS_CHILDREN && performPreActions) {
            return new DeploymentActionInstruction(DeploymentAction.Stop);
        } else if (position == WalkPosition.TOWARDS_PARENTS && performPostActions) {
            // if it's a dependency not at the root, we may need to start it back up on the way back out.
            return new DeploymentActionInstruction(DeploymentAction.Start, Arrays.asList(GluState.stopped,
                    GluState.running));
        } else {
            return null;
        }
    }

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

    @Required
    public void setDeploymentPlanBuilder(final ComponentDeploymentPlanBuilder componentDeploymentPlanBuilder) {
        this.componentDeploymentPlanBuilder = componentDeploymentPlanBuilder;
    }

    @Required
    public void setDeploymentDao(final DeploymentDao deploymentDao) {
        this.deploymentDao = deploymentDao;
    }

    @Required
    public void setRollbackPrepBuilder(final RollbackPrepBuilder rollbackPrepBuilder) {
        this.rollbackPrepBuilder = rollbackPrepBuilder;
    }

    @Required
    public void setContextProvider(final OperationContextProvider contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }

    @Required
    public void setDeploymentPlanValidators(final List<DeploymentPlanValidator> deploymentPlanValidators) {
        this.deploymentPlanValidators = deploymentPlanValidators;
    }

    @Required
    public void setReleaseDeploymentPlanValidators(
            final List<ReleaseDeploymentPlanValidator> releaseDeploymentPlanValidators) {
        this.releaseDeploymentPlanValidators = releaseDeploymentPlanValidators;
    }

    @Required
    public void setDeploymentPlanFromTemplateGenerator(
            final DeploymentPlanFromTemplateGenerator deploymentPlanFromTemplateGenerator) {
        this.deploymentPlanFromTemplateGenerator = deploymentPlanFromTemplateGenerator;
    }

}
