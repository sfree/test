package com.ubs.f35.pcc.people2.model;

/**
 * This package contains the only model class that has been reused from PCC (rather than having a dependency on PCC) 
 */
