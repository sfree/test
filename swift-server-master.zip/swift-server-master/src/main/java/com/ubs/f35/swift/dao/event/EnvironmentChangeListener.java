package com.ubs.f35.swift.dao.event;

import com.ubs.f35.swift.dao.model.Environment;

public interface EnvironmentChangeListener {
    void afterUpdate(Environment environment);
}
