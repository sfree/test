package com.ubs.f35.swift.plugin.neo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.document.ArtifactEntryConvertorPostProcessor;
import com.ubs.f35.swift.environment.model.glu.Entry;

/**
 * Plugin which automatically tags Neo artifacts as client or server.
 * 
 * @deprecated No longer required now that tags can be associated with a glu script. Leaving in case organisation config
 *             still references this plugin.
 */
@Deprecated
public class NeoArtifactAutoTagger implements ArtifactEntryConvertorPostProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(NeoArtifactAutoTagger.class);

    @Override
    public void enrich(final ArtifactConfig artifact, final Entry entry) {
        LOG.warn("Plugin no longer required and should be removed from organisation config: {}",
                artifact.getEnvironment());
    }

}
