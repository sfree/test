package com.ubs.f35.swift.environment;

import org.springframework.beans.factory.BeanNameAware;

import com.ubs.f35.swift.dao.model.Environment;

public class ConfigurableEnvironmentBeanProvider<T> extends ConfigurableBeanProvider<Environment, T> implements
        EnvironmentBeanFactory<T>, BeanNameAware {

    @Override
    protected String getSourceType() {
        return "environment";
    }

    @Override
    protected String getMBeanPrefix(final Environment environment) {
        return environment.getOrganisation().getName() + "." + environment.getName();
    }

}
