package com.ubs.f35.swift.service.glu;

import com.google.common.base.Predicate;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.environment.model.glu.Entry;

/**
 * Returns deployment model entries which match the release model artifacts.
 * 
 * @author stephelu
 * 
 */
public class EntryMatchesGroupArtifactPredicate implements Predicate<Entry> {

    private final NexusArtifact artifact;

    public EntryMatchesGroupArtifactPredicate(final NexusArtifact artifact) {
        this.artifact = artifact;
    }

    @Override
    public boolean apply(final Entry entry) {
        return artifact.getGroupId().equals(entry.getGroupId()) &&
                artifact.getArtifactId().equals(entry.getArtifactId());
    }

}
