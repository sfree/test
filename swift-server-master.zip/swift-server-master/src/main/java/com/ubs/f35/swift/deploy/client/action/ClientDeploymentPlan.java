package com.ubs.f35.swift.deploy.client.action;

import java.util.List;

import com.google.common.base.Objects;
import com.ubs.f35.swift.deploy.glu.plan.Warning;

/**
 * Client side representation of a deployment plan. Ideally this would only have a single Action, unfortunately due to
 * historically persisted plans it needs to take a list of actions to remain backwards compatible.
 * 
 * @author stephelu
 * 
 */
public class ClientDeploymentPlan {
    private final String planId;
    private final List<? extends ClientAction> actions;
    private final List<Warning> warnings;

    public ClientDeploymentPlan(final String planId, final List<? extends ClientAction> list,
            final List<Warning> warnings) {
        this.planId = planId;
        this.actions = list;
        this.warnings = warnings;
    }

    public String getPlanId() {
        return planId;
    }

    public List<? extends ClientAction> getActions() {
        return actions;
    }

    public List<Warning> getWarnings() {
        return warnings;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(planId, actions, warnings);
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }

        ClientDeploymentPlan that = (ClientDeploymentPlan) obj;
        return Objects.equal(this.planId, that.planId)
                && Objects.equal(this.actions, that.actions)
                && Objects.equal(this.warnings, that.warnings);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("planId", planId)
                .add("actions", actions)
                .add("warnings", warnings)
                .toString();
    }

}
