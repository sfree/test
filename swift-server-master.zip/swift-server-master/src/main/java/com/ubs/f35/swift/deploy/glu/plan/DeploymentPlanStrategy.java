package com.ubs.f35.swift.deploy.glu.plan;

import com.google.common.base.Objects;

public class DeploymentPlanStrategy {
    enum DeploymentExecution {
        ROLLING_UPGRADE // Strategy which attempts to update all components with no downtime by performing a rolling
                        // upgrade of server components.
    }

    // Deployment plan generation strategy which will not bring in additional dependencies.
    public static final DeploymentPlanStrategy NO_DEPS = new DeploymentPlanStrategy();

    private final boolean includeDependencies;
    private final DeploymentExecution executionStrategy;

    private DeploymentPlanStrategy() {
        this(false, DeploymentExecution.ROLLING_UPGRADE);
    }

    public DeploymentPlanStrategy(final boolean includeDependencies) {
        this(includeDependencies, DeploymentExecution.ROLLING_UPGRADE);
    }

    /** Not exposed outside of tests yet */
    DeploymentPlanStrategy(final boolean includeDependencies, final DeploymentExecution executionStrategy) {
        this.includeDependencies = includeDependencies;
        this.executionStrategy = executionStrategy;
    }

    public boolean isIncludeDependencies() {
        return includeDependencies;
    }

    public DeploymentExecution getExecutionStrategy() {
        return executionStrategy;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(includeDependencies, executionStrategy);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DeploymentPlanStrategy) {
            DeploymentPlanStrategy that = (DeploymentPlanStrategy) object;
            return Objects.equal(this.includeDependencies, that.includeDependencies)
                    && Objects.equal(this.executionStrategy, that.executionStrategy);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("includeDependencies", includeDependencies)
                .add("executionStrategy", executionStrategy)
                .toString();
    }

}
