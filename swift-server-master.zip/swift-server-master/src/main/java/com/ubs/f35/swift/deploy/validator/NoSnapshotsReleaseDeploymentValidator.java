package com.ubs.f35.swift.deploy.validator;

import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlanBuilder;
import com.ubs.f35.swift.service.ArtifactConfigurationService;

public class NoSnapshotsReleaseDeploymentValidator implements ReleaseDeploymentPlanValidator {

    @Override
    public void validate(final DeploymentPlanBuilder builder, final ReleaseDefinition release,
            final Environment environment, final boolean rollback) {
        // Don't warn about snapshots in dev environments
        if (!environment.getName().toLowerCase().startsWith("dev")) {
            for (Artifact artifact : release.getArtifacts()) {
                if (ArtifactConfigurationService.isSnapshot(artifact)) {
                    builder.addWarning("SNAPSHOT artifact in release: " + artifact.getArtifactId());
                }
            }
        }
    }

}
