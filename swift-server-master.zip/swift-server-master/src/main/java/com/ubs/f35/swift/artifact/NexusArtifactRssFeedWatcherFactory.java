package com.ubs.f35.swift.artifact;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Maps;

/**
 * Configures the {@link NexusArtifactRssFeedWatcher} for different organisations. Organisations may not configure a
 * feed watched (in which case new artifacts will need to be registered manually). Multiple organisations may share the
 * name nexus instance, but have their artifacts in different repositories. The nexus RSS feed is not repo specific, so
 * this implementation makes a single call per nexus instance and then determines the appropriate organisation based on
 * the repository the changed occurred in.
 * <p>
 * Developed to support Neo and GED (Global Equity Derivs) artifacts in cft-nexus.
 * 
 */
public class NexusArtifactRssFeedWatcherFactory {
    private static final Logger LOG = LoggerFactory.getLogger(NexusArtifactRssFeedWatcherFactory.class);

    private NexusFeedFetcherFactory nexusFeedFetcherFactory;
    private NexusFeedNotificationListener nexusFeedNotificationListener;
    private TaskScheduler taskScheduler;
    private String cronScheduleExpression = "1 * * * * ?";

    private final Map<String, NexusArtifactRssFeedWatcher> configuredFeedWatchers = Maps.newHashMap();

    public void configurePollingForOrganisation(final String organisation, final String feedUrl,
            final String username, final String password, final List<String> repositoryIds)
            throws MalformedURLException {
        if (StringUtils.isEmpty(feedUrl)) {
            LOG.info("No nexus feed configured for organisation {}", organisation);
            return;
        }

        LOG.info("Setting up polling for organisation {} using feed {}", organisation, feedUrl);

        String key = feedUrl + username + password;

        // Reuse the same nexus poller if another organisation makes use of the same nexus instance.
        NexusArtifactRssFeedWatcher watcher = configuredFeedWatchers.get(key);
        if (watcher == null) {
            watcher = createWatcherInstance();
            watcher.setFeedFetcher(nexusFeedFetcherFactory.createInstance(username, password));
            watcher.setFeedUrl(new URL(feedUrl));
            watcher.setNexusFeedNotificationListener(nexusFeedNotificationListener);

            configuredFeedWatchers.put(key, watcher);

            schedulePolling(watcher);
        }

        watcher.addRepoToOrgMappings(repositoryIds, organisation);
    }

    @VisibleForTesting
    protected NexusArtifactRssFeedWatcher createWatcherInstance() {
        return new NexusArtifactRssFeedWatcher();
    }

    private void schedulePolling(final NexusArtifactRssFeedWatcher watcher) {
        taskScheduler.schedule(new Runnable() {
            @Override
            public void run() {
                try {
                    watcher.runChecks();
                } catch (Exception e) {
                    LOG.warn("Exception polling nexus", e);
                }
            }
        }, new CronTrigger(cronScheduleExpression));
    }

    @Required
    public void setNexusFeedNotificationListener(final NexusFeedNotificationListener nexusFeedNotificationListener) {
        this.nexusFeedNotificationListener = nexusFeedNotificationListener;
    }

    @Required
    public void setNexusFeedFetcherFactory(final NexusFeedFetcherFactory nexusFeedFetcherFactory) {
        this.nexusFeedFetcherFactory = nexusFeedFetcherFactory;
    }

    @Required
    public void setTaskScheduler(final TaskScheduler taskScheduler) {
        this.taskScheduler = taskScheduler;
    }

    public void setCronScheduleExpression(final String cronScheduleExpression) {
        this.cronScheduleExpression = cronScheduleExpression;
    }
}
