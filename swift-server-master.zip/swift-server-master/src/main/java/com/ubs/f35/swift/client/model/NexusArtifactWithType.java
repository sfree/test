package com.ubs.f35.swift.client.model;

import com.ubs.f35.swift.dao.NexusArtifact;

public class NexusArtifactWithType extends NexusArtifact implements WithArtifactType {
    private final ArtifactType artifactType;

    public NexusArtifactWithType(final NexusArtifact artifact, final ArtifactType artifactType) {
        super(artifact.getGroupId(), artifact.getArtifactId());
        this.artifactType = artifactType;
    }

    @Override
    public ArtifactType getArtifactType() {
        return artifactType;
    }
}
