package com.ubs.f35.swift.artifact;

import com.ubs.f35.swift.dao.Artifact;

public class ArtifactNotFoundInRepoException extends RuntimeException {

    private final Artifact artifact;

    public ArtifactNotFoundInRepoException(final Artifact artifact) {
        super("Artifact " + artifact.getArtifactId() + " : " + artifact.getVersion()
                + " not found in Nexus");
        this.artifact = artifact;
    }

    public Artifact getArtifact() {
        return artifact;
    }

}
