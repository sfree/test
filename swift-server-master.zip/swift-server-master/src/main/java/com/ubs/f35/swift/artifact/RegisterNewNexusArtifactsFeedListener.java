package com.ubs.f35.swift.artifact;

import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.service.NexusArtifactService;
import com.ubs.f35.swift.util.LoadingCacheUtil;

/**
 * Registers new nexus artifacts if they are being discovered for the first time. Because the nexus RSS feed does not
 * honour the 'Last Modified' header, it is necessary to cache which artifacts have previously been checked.
 * 
 * @author stephelu
 * 
 */
public class RegisterNewNexusArtifactsFeedListener implements NexusFeedNotificationListener {
    private static final Logger LOG = LoggerFactory.getLogger(RegisterNewNexusArtifactsFeedListener.class);

    private NexusArtifactService nexusArtifactService;

    private final LoadingCache<Pair<String, NexusArtifact>, Boolean> processedCache = CacheBuilder.newBuilder()
            .maximumSize(10000)
            .build(new CacheLoader<Pair<String, NexusArtifact>, Boolean>() {
                @Override
                public Boolean load(final Pair<String, NexusArtifact> artifactCacheKey) throws Exception {
                    LOG.info("Checking if artifact needs to be registered");
                    // logic here retrieves the artifact and creates it if it does not exist.
                    nexusArtifactService.registerArtifact(artifactCacheKey.getLeft(), artifactCacheKey.getRight());

                    return true;
                }
            });

    @Transactional
    @Override
    public void handleArtifactDeployed(final String organisation, final NexusArtifact artifact) {
        LoadingCacheUtil.getUnchecked(processedCache, Pair.of(organisation, artifact));
    }

    @Required
    public void setNexusArtifactService(final NexusArtifactService nexusArtifactService) {
        this.nexusArtifactService = nexusArtifactService;
    }

}
