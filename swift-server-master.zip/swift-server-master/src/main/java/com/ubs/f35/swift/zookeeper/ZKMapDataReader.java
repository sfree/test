package com.ubs.f35.swift.zookeeper;

import java.util.Map;

import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.Watcher;
import org.linkedin.zookeeper.client.IZKClient;
import org.linkedin.zookeeper.client.ZKData;
import org.linkedin.zookeeper.tracker.ZKDataReader;

import com.google.common.base.Objects;
import com.ubs.f35.swift.model.JsonObjectMapper;

public class ZKMapDataReader implements ZKDataReader<Map> {
    public static final ZKMapDataReader INSTANCE = new ZKMapDataReader();

    private ZKMapDataReader() {
    }

    @Override
    public ZKData<Map> readData(final IZKClient zkClient, final String paramString, final Watcher paramWatcher)
            throws InterruptedException, KeeperException {
        ZKData<String> data = zkClient.getZKStringData(paramString, paramWatcher);
        if (data == null) {
            return null;
        }
        return new ZKData<Map>(extractMap(data.getData()), data.getStat());
    }

    @Override
    public boolean isEqual(final Map map1, final Map map2) {
        return Objects.equal(map1, map2);
    }

    private Map extractMap(final String agentDetails) {
        return JsonObjectMapper.getInstance().readValue(agentDetails, Map.class);
    }
}
