package com.ubs.f35.swift.model;

import com.ubs.f35.swift.dao.ReleaseDefinition;

public class ReleaseLockedException extends ReleaseLogicException {

    private final ReleaseDefinition releaseDef;

    public ReleaseLockedException(final ReleaseDefinition releaseDef) {
        super("Release '" + releaseDef.getName() + "' is locked down for production deployment and cannot be modified.");
        this.releaseDef = releaseDef;
    }

    public ReleaseDefinition getReleaseDefinition() {
        return releaseDef;
    }

}
