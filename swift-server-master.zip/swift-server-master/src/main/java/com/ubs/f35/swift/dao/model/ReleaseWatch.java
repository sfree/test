package com.ubs.f35.swift.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.ubs.f35.swift.dao.ReleaseDefinition;

@Entity
@Table(name = "RELEASE_WATCHES")
public class ReleaseWatch implements Serializable {
    /**
     * The release being watched. Haven't linked to an explicit release because the processing of a release update
     * requires loading of historical versions of the release.
     */
    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "RELEASE_ID", nullable = false)
    private ReleaseDefinition release;
    @Id
    @Column(name = "WATCH_USER")
    private String user;
    @Id
    @Column(name = "WATCH_TYPE")
    @Enumerated(EnumType.STRING)
    private WatchType watchType;

    public enum WatchType {
        RELEASE_UPDATE,
        RELEASE_DEPLOYMENT
    }

    public ReleaseDefinition getRelease() {
        return release;
    }

    public void setRelease(final ReleaseDefinition release) {
        this.release = release;
    }

    public String getUser() {
        return user;
    }

    public void setUser(final String user) {
        this.user = user;
    }

    public WatchType getWatchType() {
        return watchType;
    }

    public void setWatchType(final WatchType watchType) {
        this.watchType = watchType;
    }

}
