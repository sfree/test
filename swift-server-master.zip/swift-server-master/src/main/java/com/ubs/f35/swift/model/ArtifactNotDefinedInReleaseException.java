package com.ubs.f35.swift.model;

import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ReleaseDefinition;

public class ArtifactNotDefinedInReleaseException extends RuntimeException {

    private final Artifact artifact;

    private final ReleaseDefinition releaseDef;

    public ArtifactNotDefinedInReleaseException(final Artifact artifact, final ReleaseDefinition releaseDef) {
        super("Artifact " + artifact.getArtifactId() + " : " + artifact.getVersion()
                + " is not defined in release " + releaseDef.getName());
        this.artifact = artifact;
        this.releaseDef = releaseDef;
    }

    public Artifact getArtifact() {
        return artifact;
    }

    public ReleaseDefinition getReleaseDefinition() {
        return releaseDef;
    }

}
