package com.ubs.f35.swift.security;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.util.concurrent.UncheckedExecutionException;
import com.ubs.f35.core.AuthenticationPrincipal;
import com.ubs.f35.core.auth.UserValidationException;
import com.ubs.f35.core.auth.dsws.DSWSPrincipalGenerator;

/**
 * Provides an {@link AuthenticationPrincipal} from an LWS token
 * 
 */
public class WebSsoAuthProvider {
    private static final Logger LOG = LoggerFactory.getLogger(WebSsoAuthProvider.class);

    private DSWSPrincipalGenerator dswsPrincipalGenerator;
    private final LoadingCache<String, AuthenticationPrincipal> principalCache = CacheBuilder.newBuilder()
            .maximumSize(1000).expireAfterWrite(1, TimeUnit.HOURS)
            .build(new CacheLoader<String, AuthenticationPrincipal>() {
                @Override
                public AuthenticationPrincipal load(final String key) throws UserValidationException {
                    LOG.info("Cache miss. Loading principal");
                    return dswsPrincipalGenerator.getPrincipal(key);
                }
            });

    public AuthenticationPrincipal getPrincipal(final String authToken) throws UserValidationException {
        LOG.info("validate");

        AuthenticationPrincipal principal;
        try {
            principal = principalCache.get(authToken);
        } catch (ExecutionException e) {
            throw (UserValidationException) e.getCause();
        } catch (UncheckedExecutionException e) {
            if (e.getCause() instanceof RuntimeException) {
                throw (RuntimeException) e.getCause();
            } else {
                throw e;
            }
        }

        return principal;
    }

    @Required
    public void setDswsPrincipalGenerator(final DSWSPrincipalGenerator dswsPrincipalGenerator) {
        this.dswsPrincipalGenerator = dswsPrincipalGenerator;
    }

}
