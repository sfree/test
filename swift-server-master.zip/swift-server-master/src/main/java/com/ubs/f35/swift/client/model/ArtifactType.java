package com.ubs.f35.swift.client.model;

import com.google.common.base.Objects;

/**
 * Additional client information for rendering an artifact
 */
public class ArtifactType {
    // A short (max 4 character) type (eg Web, Java, node)
    private final String shortName;
    // A CSS compatible color to represent this type
    private final String color;

    public ArtifactType(final String shortName, final String color) {
        this.shortName = shortName;
        this.color = color;
    }

    public String getShortName() {
        return shortName;
    }

    public String getColor() {
        return color;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(shortName, color);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ArtifactType) {
            ArtifactType that = (ArtifactType) object;
            return Objects.equal(this.shortName, that.shortName)
                    && Objects.equal(this.color, that.color);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("shortName", shortName)
                .add("color", color)
                .toString();
    }

}