package com.ubs.f35.swift.dao.hibernate.framework;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.PagingResult;

/**
 * Provides base functionality for the hibernate daos.
 * 
 * @author stephelu
 * 
 */
public abstract class HibernateDaoSupport {
    private SessionFactory sessionFactory;

    @Required
    public final void setSessionFactory(final SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    protected final Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    /**
     * Generic wrapper around Hibernate get.
     * <p>
     * This method expects the id to be found and throws an exception if it is not.
     * 
     * @param <T>
     * @param theClass
     * @param id
     * @return
     */
    protected final <T> T loadExpected(final Class<T> theClass, final Serializable id) {
        T entity = load(theClass, id);
        if (entity == null) {
            throw new EntityNotFoundException("Entity not found:" + theClass.getSimpleName() + "[id=" + id + "]");
        }
        return entity;
    }

    /**
     * Generic wrapper around get.
     * <p>
     * This method returns null if the specified id was null. Use {@link #loadExpected(Class, Serializable)} if you want
     * it to fail in this case.
     * 
     * @param <T>
     * @param theClass
     * @param id
     * @return
     */
    @SuppressWarnings("unchecked")
    protected final <T> T load(final Class<T> theClass, final Serializable id) {
        return (T) getSession().get(theClass, id);
    }

    /**
     * As per {@link Session#merge(Object)}
     * 
     * @param object
     * @return The updated object
     */
    @SuppressWarnings("unchecked")
    protected final <T> T merge(final T object) {
        return (T) getSession().merge(object);
    }

    /**
     * Executes a query for a paged list of results.
     * 
     * @param <T>
     * @param pagingFilter
     * @param type
     * @param pagingCriteriaBuilder
     * @return
     */
    protected <T> PagingResult<T> executeCriteriaWithPaging(final PagingFilter pagingFilter,
            final Class<T> type, final PagingCriteriaBuilder pagingCriteriaBuilder) {

        Criteria resultsCriteria = getSession().createCriteria(type)
                .setFirstResult(pagingFilter.getStart())
                .setMaxResults(pagingFilter.getRecords());
        pagingCriteriaBuilder.appendCriteria(resultsCriteria, false);

        @SuppressWarnings("unchecked")
        List<T> results = resultsCriteria.list();

        int totalResults;
        if (results.size() > 0 && results.size() < pagingFilter.getRecords()) {
            totalResults = pagingFilter.getStart() + results.size();
        } else {
            // Get the total number of results, only if it's more than what was requested
            Criteria countCriteria = getSession().createCriteria(type)
                    .setProjection(Projections.rowCount());
            pagingCriteriaBuilder.appendCriteria(countCriteria, true);

            totalResults = ((Long) countCriteria.uniqueResult()).intValue();
        }

        return new PagingResult<T>(pagingFilter, totalResults, results);
    }

    /**
     * Executes a query for a paged list of results.
     * 
     * @param <T>
     * @param pagingFilter
     * @param type
     * @param pagingQueryBuilder
     * @return
     */
    protected <T> PagingResult<T> executeQueryWithPaging(final PagingFilter pagingFilter,
            final Class<T> type, final PagingQueryBuilder pagingQueryBuilder) {

        Query resultsQuery = getSession().createQuery(pagingQueryBuilder.getQuery());

        pagingQueryBuilder.bindArguments(resultsQuery);

        setPagingFilters(pagingFilter, resultsQuery);

        @SuppressWarnings("unchecked")
        List<T> results = resultsQuery.list();
        int totalResults;
        if (results.size() > 0 && results.size() < pagingFilter.getRecords()) {
            totalResults = pagingFilter.getStart() + results.size();
        } else {
            // Get the total number of results, only if it's more than what was requested
            String countQueryStr = "select count(*) " + pagingQueryBuilder.getCountQuery();

            Query countQuery = getSession().createQuery(countQueryStr);
            pagingQueryBuilder.bindArguments(countQuery);

            totalResults = ((Long) countQuery.uniqueResult()).intValue();
        }

        return new PagingResult<T>(pagingFilter, totalResults, results);
    }

    protected void setPagingFilters(final PagingFilter pagingFilter, final Query query) {
        query.setFirstResult(pagingFilter.getStart())
                .setMaxResults(pagingFilter.getRecords());
    }

    protected static String contains(final String string) {
        return "%" + string + "%";
    }

    protected static void addNotEmptyIn(final Criteria criteria, final Collection<String> values,
            final String propertyName) {
        if (values != null) {
            Collection<String> nonEmptyValues = Lists.newArrayList(Iterables.filter(values, new Predicate<String>() {
                @Override
                public boolean apply(final String input) {
                    return StringUtils.hasText(input);
                }
            }));

            if (!nonEmptyValues.isEmpty()) {
                criteria.add(Restrictions.in(propertyName, nonEmptyValues));
            }
        }
    }

    protected static void addNotEmpty(final Criteria criteria, final Enum value, final Criterion expression) {
        if (value != null) {
            addNotEmpty(criteria, value.toString(), expression);
        }
    }

    protected static void addNotEmpty(final Criteria criteria, final String value, final Criterion expression) {
        if (StringUtils.hasText(value)) {
            criteria.add(expression);
        }
    }

    protected static void addNotEmpty(final Criteria criteria, final Date value, final Criterion expression) {
        if (value != null) {
            criteria.add(expression);
        }
    }

    /**
     * It may not be immediately apparent why it's fine to not have any custom handling of the Tag collection, but it is
     * required for the DeployTag collection. Before this code was in place, hibernate attempted to insert a new
     * DeployTag with null property fields in the merge of the ArtifactConfig. I believe this is because of a bug in
     * DefaultMergeEventListener.entityIsTransient. If the object being persisted doesn't have a single id column, the
     * fields get destroyed by these calls
     * 
     * <pre>
     * final Serializable id = persister.hasIdentifierProperty() ? persister.getIdentifier(entity, source) : null;
     * final Object copy = copyCache.get(entity);
     * </pre>
     * 
     * @param entityClass
     * @param collection
     * @param idFunction
     * @return
     */
    protected <T, I extends Serializable> List<T> mergeCollection(final Class<T> entityClass, final List<T> collection,
            final Function<T, I> idFunction) {

        List<T> persistentItems = Lists.newArrayList();
        if (!CollectionUtils.isEmpty(collection)) {
            for (T item : collection) {
                T persistentItem = load(entityClass, idFunction.apply(item));
                if (persistentItem == null) {
                    getSession().save(item);
                    persistentItem = item;
                }
                persistentItems.add(persistentItem);
            }
        }

        return persistentItems;
    }
}
