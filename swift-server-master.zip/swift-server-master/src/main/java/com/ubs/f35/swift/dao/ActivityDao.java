package com.ubs.f35.swift.dao;

import com.ubs.f35.swift.model.ActivityFilters;

public interface ActivityDao {

    void create(Activity activity);

    Activity load(Integer id);

    void removeEmptyActivity(Activity activity);

    Activity getAggregatableActivity(Activity newActivity);

    PagingResult<Activity> list(ActivityFilters activityFilters, PagingFilter pagingFilter);

}
