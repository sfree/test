package com.ubs.f35.swift.dao;

import java.util.List;
import java.util.UUID;

import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.dao.model.DeployedArtifact;
import com.ubs.f35.swift.dao.model.EnvDeployment;

/**
 * DAO for Deployments
 * 
 * @author levyjo
 * 
 */
public interface DeploymentDao {

    void create(Deployment deployment);

    /**
     * Load a deployment record.
     * 
     * @param id
     * @return
     */
    Deployment loadDeployment(UUID id);

    /**
     * Persist deployment record
     * 
     * @param deployment
     */
    void saveDeployment(Deployment deployment);

    /**
     * Returns deployment history records for the given release ID
     * 
     * @param releaseId
     * @param pagingFilter
     * @return
     */
    PagingResult<Deployment> getDeploymentHistoryForRelease(Integer releaseId, PagingFilter pagingFilter);

    /**
     * Returns a list of deployments for an artifact on a specific host.
     * 
     * @param artifact
     * @param host
     * @param pagingFilter
     * @return
     */
    PagingResult<DeployedArtifact> getDeploymentHistoryForArtifact(ArtifactConfig artifact, String host,
            PagingFilter pagingFilter);

    /**
     * Returns the latest deployment record for the given release in the given environment
     * 
     * @param releaseId
     * @param environment
     * @return
     */
    EnvDeployment getLatestDeploymentForReleaseInEnv(Integer releaseId, String environment);

    /**
     * Returns the latest deployment record for the given release in each environment where deployment has been
     * attempted. Returns only the latest record for each environment.
     * 
     * @param releaseId
     * @return
     */
    List<EnvDeployment> getLatestDeploymentsForReleaseByEnv(Integer releaseId);

    /**
     * Returns the latest deployment record for each release in each environment where deployment has been attempted.
     * Returns only the latest record for each environment.
     * 
     * @param releaseIds
     * @return
     */
    List<EnvDeployment> getLatestDeploymentsForReleasesByEnv(List<Integer> releaseIds);

    /**
     * Returns the number of deployments in each environment per day.
     * 
     * @return
     */
    List<DailyDeploymentStats> getDailyDeploymentStats(String organisation);

    /**
     * Returns all deployment records for the given release in the given environment
     * 
     * @param releaseId
     * @param environment
     * @return
     */
    List<EnvDeployment> getAllDeploymentsForReleaseInEnv(Integer releaseId, String environment);

    /**
     * Returns a list of currently executing deployments for the organisation.
     * 
     * @param organisation
     * @return
     */
    List<Deployment> getRunningDeployments(String organisation);

}
