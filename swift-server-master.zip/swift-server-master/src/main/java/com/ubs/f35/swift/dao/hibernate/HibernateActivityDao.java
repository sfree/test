package com.ubs.f35.swift.dao.hibernate;

import java.util.Calendar;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.google.common.collect.Lists;
import com.ubs.f35.swift.dao.Activity;
import com.ubs.f35.swift.dao.Activity.ActivityType;
import com.ubs.f35.swift.dao.ActivityAggregationKey;
import com.ubs.f35.swift.dao.ActivityDao;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.PagingResult;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.hibernate.framework.PagingCriteriaBuilder;
import com.ubs.f35.swift.model.ActivityFilters;

/**
 * DAO for activity feed
 * 
 * @author levyjo
 * 
 */
public class HibernateActivityDao extends HibernateDaoSupport implements ActivityDao {

    private static final Logger LOG = LoggerFactory.getLogger(HibernateActivityDao.class);

    @Override
    public void create(final Activity activity) {
        getSession().save(activity);
    }

    @Override
    public Activity load(final Integer id) {
        return load(Activity.class, id);
    }

    /**
     * Returns the previous activity which the given new activity can be amalgamated with, or null if there isn't a
     * suitable previous activity. A previous activity is suitable only if:
     * <ol>
     * <li>It has the same {@link ActivityAggregationKey} as the new activity</li>
     * <li>It occurred less than 30 minutes before the new activity</li>
     * <li>No other activity has occurred in the meantime.</li>
     * </ol>
     * 
     */
    @Override
    public Activity getAggregatableActivity(final Activity newActivity) {

        ActivityAggregationKey key = newActivity.getAggregationKey();
        DetachedCriteria maxQuery = DetachedCriteria.forClass(Activity.class).setProjection(Projections.max("id"));

        Calendar invalidBefore = Calendar.getInstance();
        invalidBefore.add(Calendar.MINUTE, -30);

        Criteria query = getSession().createCriteria(Activity.class)
                .add(Property.forName("id").eq(maxQuery))
                .add(Restrictions.eq("user", key.getUser()))
                .add(Restrictions.eq("type", key.getType()))
                .add(eqOrNull("objectId", key.getObjectId()))
                .add(eqOrNull("environment", key.getEnvironment()))
                .add(eqOrNull("verb", key.getVerb()))
                .add(Restrictions.gt("timestamp", invalidBefore.getTime()));
        return (Activity) query.uniqueResult();
    }

    @Override
    public PagingResult<Activity> list(final ActivityFilters activityFilters, final PagingFilter pagingFilter) {
        return executeCriteriaWithPaging(pagingFilter, Activity.class, new PagingCriteriaBuilder() {

            @Override
            public void appendCriteria(final Criteria criteria, final boolean count) {

                if (activityFilters.getReleaseId() != null) {

                    ReleaseDefinition releaseDef = loadExpected(ReleaseDefinition.class, activityFilters.getReleaseId());
                    List<Integer> artifactIds = Lists.newArrayListWithExpectedSize(releaseDef.getArtifacts().size());
                    for (Artifact a : releaseDef.getArtifacts()) {
                        artifactIds.add(a.getId());
                    }

                    if (artifactIds.isEmpty()) {
                        artifactIds.add(0);
                    }

                    criteria.add(Restrictions.ge("timestamp", releaseDef.getCreatedTime()));
                    criteria.add(
                            Restrictions.or(
                                    Restrictions.and(
                                            Restrictions.eq("objectId", activityFilters.getReleaseId()),
                                            Restrictions.or(
                                                    Restrictions.eq("type", ActivityType.DEPLOYMENT),
                                                    Restrictions.eq("type", ActivityType.RELEASE)
                                                    )
                                            ),
                                    Restrictions.and(Restrictions.eq("type", ActivityType.PROPERTIES),
                                            Restrictions.in("objectId", artifactIds.toArray()))
                                    )
                            );
                }

                addNotEmpty(criteria, activityFilters.getUser(), Restrictions.eq("user", activityFilters.getUser()));

                // TODO: Filtering by team - waiting till we have Github API for relationships between
                // users/teams/artifacts
                // addNotEmpty(criteria, activityFilters.getTeam(), Restrictions.eq("", activityFilters.getTeam()));

                if (StringUtils.hasText(activityFilters.getEnvironment())) {
                    criteria.createAlias("environment", "e");
                    criteria.add(Restrictions.eq("e.name", activityFilters.getEnvironment()));
                }
                if (StringUtils.hasText(activityFilters.getOrganisation())) {
                    criteria.createAlias("organisation", "o");
                    criteria.add(Restrictions.eq("o.name", activityFilters.getOrganisation()));
                }
                addNotEmpty(criteria, activityFilters.getType(),
                        Restrictions.eq("type", activityFilters.getType()));

                if (!count) {
                    criteria.addOrder(Order.desc("timestamp"));
                }
            }
        });
    }

    @Override
    public void removeEmptyActivity(final Activity activity) {
        getSession().delete(activity);

    }

    private static Criterion eqOrNull(final String property, final Object value) {
        if (value == null) {
            return Restrictions.isNull(property);
        }
        return Restrictions.eq(property, value);
    }

}
