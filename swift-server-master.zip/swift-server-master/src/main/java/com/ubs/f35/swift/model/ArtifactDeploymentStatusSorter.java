package com.ubs.f35.swift.model;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.google.common.collect.ComparisonChain;
import com.ubs.f35.swift.artifact.MavenVersionNumberComparator;
import com.ubs.f35.swift.config.model.ArtifactConfig;

/**
 * Sort a {@link List} of {@link ArtifactDeploymentStatus}es by the requested column.
 * 
 * @author stephelu
 * 
 */
public class ArtifactDeploymentStatusSorter {

    public static final void sort(final List<ArtifactDeploymentStatus> statuses, final String column,
            final boolean descending) {

        Comparator<ArtifactDeploymentStatus> comparator = new Comparator<ArtifactDeploymentStatus>() {

            @Override
            public int compare(final ArtifactDeploymentStatus o1, final ArtifactDeploymentStatus o2) {
                ComparisonChain chain = ComparisonChain.start();

                if (column != null) {
                    if (column.equals("group")) {
                        chain = chain.compare(o1.getEntry().getGroupId(), o2.getEntry().getGroupId());
                    } else if (column.equals("artifact")) {
                        chain = chain.compare(o1.getEntry().getArtifactId(), o2.getEntry().getArtifactId());
                    } else if (column.equals("version")) {
                        chain = chain.compare(o2.getEntry().getVersion(), o1.getEntry().getVersion(),
                                MavenVersionNumberComparator.INSTANCE);
                    } else if (column.equals("host")) {
                        chain = chain.compare(o1.getEntry().getAgent(), o2.getEntry().getAgent());
                    } else if (column.equals("state")) {
                        chain = chain.compare(o1.getState().getState(), o2.getState().getState());
                    } else if (column.equals("status")) {
                        chain = chain.compare(o1.getState().getStatus(), o2.getState().getStatus());
                    } else if (column.equals("name")) {
                        chain = compareNames(chain, o1, o2);
                    }
                }

                // Add defaults
                chain = chain.compare(o1.getEntry().getGroupId(), o2.getEntry().getGroupId())
                        .compare(o1.getEntry().getArtifactId(), o2.getEntry().getArtifactId());
                chain = compareNames(chain, o1, o2);

                if (descending) {
                    return -1 * chain.result();
                }
                return chain.result();

            }

        };

        Collections.sort(statuses, comparator);
    }

    private static ComparisonChain compareNames(final ComparisonChain chain, final ArtifactDeploymentStatus o1,
            final ArtifactDeploymentStatus o2) {
        return chain.compare(defaultFirst(o1.getEntry().getName()), defaultFirst(o2.getEntry().getName()));
    }

    private static String defaultFirst(final String string) {
        return ArtifactConfig.DEFAULT_INSTANCE_NAME.equals(string) ? "" : string;
    }
}
