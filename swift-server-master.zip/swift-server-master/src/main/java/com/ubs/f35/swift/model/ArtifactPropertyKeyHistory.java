package com.ubs.f35.swift.model;

import com.ubs.f35.swift.dao.SwiftRevEntry;

public class ArtifactPropertyKeyHistory {
    private final String value;
    private final String version;
    private final SwiftRevEntry swiftRevEntry;

    public ArtifactPropertyKeyHistory(final SwiftRevEntry swiftRevEntry, final String value, final String version) {
        this.value = value;
        this.version = version;
        this.swiftRevEntry = swiftRevEntry;
    }

    public String getValue() {
        return value;
    }

    public String getVersion() {
        return version;
    }

    public SwiftRevEntry getSwiftRevEntry() {
        return swiftRevEntry;
    }

}