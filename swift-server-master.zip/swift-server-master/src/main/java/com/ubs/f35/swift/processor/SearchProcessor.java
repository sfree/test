package com.ubs.f35.swift.processor;

import static com.ubs.f35.swift.processor.ProcessorUtil.daoFilter;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.NexusArtifactDao;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.PagingResult;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.model.Team;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.model.ClientPagingFilter;
import com.ubs.f35.swift.model.ReleaseFilters;

@Controller
@RequestMapping(value = "/api/search")
@Transactional(readOnly = true)
public class SearchProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(SearchProcessor.class);

    private NexusArtifactDao nexusArtifactDao;
    private ReleaseQueryProcessor releaseQueryProcessor;
    private TeamsProcessor teamsProcessor;
    private OrganisationBeanFactory<List<String>> orgEnvironmentsMap;

    @RequestMapping(method = RequestMethod.GET)
    @ResponseBody
    public Map<String, PagingResult<?>> search(@RequestParam final String organisation,
            @RequestParam final String searchStr, final ClientPagingFilter filter) {

        Map<String, PagingResult<?>> results = new LinkedHashMap<String, PagingResult<?>>();

        PagingFilter daoFilter = daoFilter(filter);

        // Artifacts
        PagingResult<NexusArtifact> artifacts = nexusArtifactDao.getArtifacts(organisation, searchStr, daoFilter);
        results.put("Artifacts", artifacts);

        // Teams
        List<Team> teamsList = teamsProcessor.getTeams(organisation, searchStr);

        List<String> teamStringList = Lists.transform(teamsList, TeamsProcessor.TEAM_NAME_FUNCTION);

        PagingResult<String> teams = ProcessorUtil.getPagedList(daoFilter, teamStringList);
        results.put("Teams", teams);

        // Releases
        ReleaseFilters releaseFilters = new ReleaseFilters();
        releaseFilters.setOrganisation(organisation);
        releaseFilters.setName(searchStr);
        PagingResult<ReleaseDefinition> releases = releaseQueryProcessor.getReleases(releaseFilters, filter);
        results.put("Releases", releases);

        // Environments
        List<String> filteredEnvs = ProcessorUtil.filterList(searchStr, orgEnvironmentsMap.get(organisation));
        results.put("Environments", ProcessorUtil.getPagedList(daoFilter, filteredEnvs));

        return results;
    }

    @Required
    public void setReleaseQueryProcessor(final ReleaseQueryProcessor releaseQueryProcessor) {
        this.releaseQueryProcessor = releaseQueryProcessor;
    }

    @Required
    public void setNexusArtifactDao(final NexusArtifactDao nexusArtifactDao) {
        this.nexusArtifactDao = nexusArtifactDao;
    }

    @Required
    public void setTeamsProcessor(final TeamsProcessor teamsProcessor) {
        this.teamsProcessor = teamsProcessor;
    }

    @Required
    public void setOrgEnvironmentsMap(final OrganisationBeanFactory<List<String>> orgEnvironmentsMap) {
        this.orgEnvironmentsMap = orgEnvironmentsMap;
    }
}
