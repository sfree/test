package com.ubs.f35.swift.deploy.glu.plan;

import com.google.common.base.Objects;

/**
 * Represents a warning returned from the server to the client. Warnings may optionally have unique code if the client
 * needs some extra handling around that warning.
 * 
 * @author stephelu
 * 
 */
public class Warning {
    private String code;
    private String message;
    private boolean requiresProductionConfirmation;

    // json deserialization only
    @Deprecated
    public Warning() {
    }

    public Warning(final Warning.Code code, final String message) {
        this(message);
        this.code = code.name();
    }

    public Warning(final String message) {
        this.message = message;
    }

    public Warning(final String message, final boolean requiresProductionConfirmation) {
        this(message);
        this.requiresProductionConfirmation = requiresProductionConfirmation;
    }

    public void setCode(final String code) {
        this.code = code;
    }

    public void setMessage(final String message) {
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public boolean isRequiresProductionConfirmation() {
        return requiresProductionConfirmation;
    }

    public void setRequiresProductionConfirmation(final boolean requiresProductionConfirmation) {
        this.requiresProductionConfirmation = requiresProductionConfirmation;
    }

    public enum Code {
        DeploymentBreaksDependencies,
        DeploymentHasDependencies,
        NoSuccessfulStagingDeployment;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(code, message);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof Warning) {
            Warning that = (Warning) object;
            return Objects.equal(this.code, that.code)
                    && Objects.equal(this.message, that.message)
                    && Objects.equal(this.requiresProductionConfirmation, that.requiresProductionConfirmation);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("code", code)
                .add("message", message)
                .add("requiresProductionConfirmation", requiresProductionConfirmation)
                .toString();
    }
}