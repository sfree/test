package com.ubs.f35.swift.deploy.client.action;

import com.google.common.base.Objects;

/**
 * Client side representation of a deployment plan. Ideally this would only have a single Action, unfortunately due to
 * historically persisted plans it needs to take a list of actions to remain backwards compatible.
 * 
 * @author stephelu
 * 
 */
public class ClientDeployment {
    private final Integer releaseId;
    private final ClientDeploymentPlan plan;

    public ClientDeployment(final Integer releaseId, final ClientDeploymentPlan plan) {

        this.releaseId = releaseId;
        this.plan = plan;
    }

    public Integer getReleaseId() {
        return releaseId;
    }

    public ClientDeploymentPlan getPlan() {
        return plan;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(releaseId, plan);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ClientDeployment) {
            ClientDeployment that = (ClientDeployment) object;
            return Objects.equal(this.releaseId, that.releaseId)
                    && Objects.equal(this.plan, that.plan);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("releaseId", releaseId)
                .add("plan", plan)
                .toString();
    }

}
