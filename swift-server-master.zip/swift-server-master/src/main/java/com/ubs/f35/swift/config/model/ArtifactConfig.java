package com.ubs.f35.swift.config.model;

import static com.ubs.f35.swift.config.model.Objects2.toStringSafe;

import java.io.Serializable;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;
import org.springframework.util.StringUtils;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.model.JsonObjectMapper;

@Table(name = "ARTIFACT_CONFIG")
@Audited
@Entity
public class ArtifactConfig implements Serializable, DeployTagable {
    public static final String DEFAULT_INSTANCE_NAME = "DEFAULT";

    private static final JsonObjectMapper JSON_MAPPER = new JsonObjectMapper();

    @Id
    @Column(name = "GROUP_ID")
    private String groupId;
    @Id
    @Column(name = "ARTIFACT_ID")
    private String artifactId;
    @Id
    @ManyToOne(fetch = FetchType.EAGER)
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private Environment environment;
    @Id
    private String name = DEFAULT_INSTANCE_NAME;
    private String script;
    private String artifactVersion;
    private String scriptArguments;
    @Column(name = "MOUNT_POINT_SCHEME", updatable = false)
    @NotAudited
    private int mountPointScheme = MountPointScheme.GROUP_ARTIFACT_INSTANCE_NAME;
    /**
     * Cold backups are managed by swift, and during release deployments they are deployed and upgraded. However they
     * are not started automatically. They sit dormant incase the primary fails at which point production support will
     * manually start.
     */
    private boolean coldStandby = false;

    @ManyToMany(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH }, targetEntity = Tag.class)
    @JoinTable(name = "ARTIFACT_CONFIG_TAGS",
            joinColumns = {
                    @JoinColumn(name = "group_id", referencedColumnName = "group_id"),
                    @JoinColumn(name = "artifact_id", referencedColumnName = "artifact_id"),
                    @JoinColumn(name = "environment_id", referencedColumnName = "environment_id"),
                    @JoinColumn(name = "name", referencedColumnName = "name") },
            inverseJoinColumns = { @JoinColumn(name = "tag") })
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @AuditJoinTable(name = "ARTIFACT_CONFIG_TAGS_AUD")
    private List<Tag> tags;

    @ManyToMany(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH }, targetEntity = DeployTag.class)
    @JoinTable(name = "ARTIFACT_CONFIG_DEPLOY_TAGS",
            joinColumns = {
                    @JoinColumn(name = "group_id", referencedColumnName = "group_id"),
                    @JoinColumn(name = "artifact_id", referencedColumnName = "artifact_id"),
                    @JoinColumn(name = "environment_id", referencedColumnName = "environment_id"),
                    @JoinColumn(name = "name", referencedColumnName = "name") },
            inverseJoinColumns = { @JoinColumn(name = "tag", referencedColumnName = "tag"),
                    @JoinColumn(name = "tag_environment", referencedColumnName = "environment_id") })
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @AuditJoinTable(name = "ARTFCT_CONF_DEPLOY_TAGS_AUD")
    private List<DeployTag> deployTags;

    @Version
    private Date lastUpdatedTime;

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    @Override
    public Environment getEnvironment() {
        return environment;
    }

    @Override
    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }

    public String getScript() {
        return script;
    }

    public void setScript(final String script) {
        this.script = script;
    }

    @JsonIgnore
    public String getScriptArguments() {
        return scriptArguments;
    }

    public void setScriptArguments(final String scriptArguments) {
        this.scriptArguments = scriptArguments;
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> getScriptArgumentsMap() {
        if (!StringUtils.hasText(scriptArguments)) {
            return Collections.emptyMap();
        }
        return JSON_MAPPER.readValue(scriptArguments, Map.class);
    }

    public void setScriptArgumentsMap(final Map<String, String> scriptArguments) {
        // Note that the map of script arguments is intentionally sorted so that the keys are always serialised in a
        // consistent order. This avoids unnecessary updates where the object has not really changed and limits noise in
        // the audit tables because the map was serialised in a different order.
        SortedMap<String, String> sortedArgs = scriptArguments instanceof SortedMap ? (SortedMap<String, String>) scriptArguments
                : new TreeMap<String, String>(scriptArguments);

        setScriptArguments(JSON_MAPPER.writeValueAsString(sortedArgs));
    }

    @Override
    public List<DeployTag> getDeployTags() {
        return deployTags;
    }

    @Override
    public void setDeployTags(final List<DeployTag> deployTags) {
        this.deployTags = deployTags;
    }

    public String getArtifactVersion() {
        return artifactVersion;
    }

    public void setArtifactVersion(final String artifactVersion) {
        this.artifactVersion = artifactVersion;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(final String groupId) {
        this.groupId = groupId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(final String artifactId) {
        this.artifactId = artifactId;
    }

    public int getMountPointScheme() {
        return mountPointScheme;
    }

    public void setMountPointScheme(final int mountPointScheme) {
        this.mountPointScheme = mountPointScheme;
    }

    public List<Tag> getTags() {
        return tags;
    }

    public void setTags(final List<Tag> tags) {
        this.tags = tags;
    }

    @JsonIgnore
    public boolean isDefaultInstance() {
        return DEFAULT_INSTANCE_NAME.equals(name);
    }

    public boolean isColdStandby() {
        return coldStandby;
    }

    public void setColdStandby(final boolean coldStandby) {
        this.coldStandby = coldStandby;
    }

    public Date getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    public void setLastUpdatedTime(final Date lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

    @JsonIgnore
    public NexusArtifact getArtifact() {
        return new NexusArtifact(groupId, artifactId);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(groupId, artifactId, environment, name);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ArtifactConfig) {
            ArtifactConfig that = (ArtifactConfig) object;
            return Objects.equal(this.groupId, that.groupId)
                    && Objects2.equal(this.artifactId, that.artifactId)
                    && Objects2.equal(this.environment, that.environment)
                    && Objects2.equal(this.name, that.name)
                    && Objects2.equal(this.script, that.script)
                    && Objects2.equal(this.artifactVersion, that.artifactVersion)
                    && Objects2.equal(this.scriptArguments, that.scriptArguments)
                    && Objects2.equal(this.mountPointScheme, that.mountPointScheme)
                    && Objects2.equal(this.tags, that.tags)
                    && Objects2.equal(this.deployTags, that.deployTags)
                    && Objects2.equal(this.coldStandby, that.coldStandby)
                    && Objects2.equal(this.lastUpdatedTime, that.lastUpdatedTime);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("groupId", groupId)
                .add("artifactId", artifactId)
                .add("environment", environment)
                .add("name", name)
                .add("script", script)
                .add("artifactVersion", artifactVersion)
                .add("scriptArguments", scriptArguments)
                .add("mountPointScheme", mountPointScheme)
                .add("tags", toStringSafe(tags))
                .add("deployTags", toStringSafe(deployTags))
                .add("coldStandby", coldStandby)
                .add("lastUpdatedTime", lastUpdatedTime)
                .toString();
    }

}
