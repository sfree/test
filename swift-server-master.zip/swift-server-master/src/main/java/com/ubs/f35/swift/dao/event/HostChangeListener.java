package com.ubs.f35.swift.dao.event;

import com.ubs.f35.swift.config.model.Host;

public interface HostChangeListener {
    void afterUpdate(Host host);
}
