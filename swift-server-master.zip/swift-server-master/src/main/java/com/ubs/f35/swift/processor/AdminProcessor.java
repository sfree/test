package com.ubs.f35.swift.processor;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.regex.Pattern;

import javax.persistence.EntityNotFoundException;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooDefs.Ids;
import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig.Feature;
import org.linkedin.zookeeper.client.ZKClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.ubs.f35.core.zookeeper.client.common.StringValueTransformer;
import com.ubs.f35.swift.config.model.EnvironmentConfig;
import com.ubs.f35.swift.config.model.GluScriptMetadata;
import com.ubs.f35.swift.config.model.OrganisationConfig;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.OrganisationDao;
import com.ubs.f35.swift.dao.SecurityTemplateDao;
import com.ubs.f35.swift.dao.model.Configurable;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.Organisation;
import com.ubs.f35.swift.dao.model.SecurityTemplate;
import com.ubs.f35.swift.deploy.glu.rest.SwiftSecureClientHttpRequestFactoryBuilder;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.model.JsonObjectMapper;
import com.ubs.f35.swift.model.JsonUnmarshallingException;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.service.AbstractJmxProcessor;

import freemarker.template.Template;

@Controller
@RequestMapping(value = "/api/admin")
@Transactional
@ManagedResource
public class AdminProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(AdminProcessor.class);
    public static final String ADMINISTRATION_ACCESS_RIGHT = "SWIFT-ADMINISTRATION";
    private static final Pattern VALID_NAME_PATTERN = Pattern.compile("[A-Za-z0-9\\-]+");
    private static final ObjectMapper PRETTY_JSON = new ObjectMapper();
    private static final StringValueTransformer ZK_STRING_TRANSFORMER = new StringValueTransformer();

    static {
        PRETTY_JSON.enable(Feature.INDENT_OUTPUT);
    }

    private AuthorisationController authorisationController;
    private SecurityTemplateDao securityTemplateDao;
    private SwiftSecureClientHttpRequestFactoryBuilder swiftSecureClientHttpRequestFactoryBuilder;
    private OrganisationDao organisationDao;
    private EnvironmentDao environmentDao;
    /**
     * Using the LinkedIn zookeeper client as the Neo one is coded to save nodes with permissions which the agent will
     * not be able to read.
     */
    private EnvironmentBeanFactory<ZKClient> zkClientFactory;
    private EnvironmentBeanFactory<String> zookeeperRootFactory;
    private Template suggestedAgentConfigTemplate;

    @RequestMapping(value = "/security", method = RequestMethod.GET)
    public List<String> getSecurityTemplates() {
        authorisationController.checkAccess(ADMINISTRATION_ACCESS_RIGHT);

        return securityTemplateDao.getIds();
    }

    @RequestMapping(value = "/security", method = RequestMethod.POST)
    public void saveSecurityTemplate(@RequestParam final String name, @RequestParam final String keystorePassword,
            @RequestParam final String keyPassword, @RequestParam final String truststorePassword,
            @RequestParam final MultipartFile keystore, @RequestParam final MultipartFile truststore,
            @RequestParam final MultipartFile agentKeystore, @RequestParam final String agentKeystoreChecksum,
            @RequestParam final String agentKeystorePassword, @RequestParam final String agentKeyPassword,
            @RequestParam final MultipartFile agentTruststore, @RequestParam final String agentTruststoreChecksum,
            @RequestParam final String agentTruststorePassword) throws IOException {
        authorisationController.checkAccess(ADMINISTRATION_ACCESS_RIGHT);

        Assert.isTrue(VALID_NAME_PATTERN.matcher(name).matches(),
                "Invalid characters in security template name '" + name + "'");

        SecurityTemplate template = new SecurityTemplate(name,
                bytes(keystore), keystorePassword, keyPassword,
                bytes(truststore), truststorePassword,
                bytes(agentKeystore), agentKeystoreChecksum, agentKeystorePassword, agentKeyPassword,
                bytes(agentTruststore), agentTruststoreChecksum, agentTruststorePassword);

        // verify that the config is valid.
        try {
            swiftSecureClientHttpRequestFactoryBuilder.buildForConfig(template);
        } catch (Throwable ex) {
            // Note the Throwables here are often instance of Error which does not extend Exception.
            throw new IllegalArgumentException("Invalid configuration: " + ex.getMessage(), ex);
        }

        securityTemplateDao.createOrUpdate(template);
    }

    private byte[] bytes(final MultipartFile upload) throws IOException {
        return upload.getBytes();
    }

    @RequestMapping(value = "/organisation/{organisation}", method = RequestMethod.GET)
    public ClientConfigurable getOrganisation(@PathVariable final String organisation) throws Exception {
        authorisationController.checkAccess(ADMINISTRATION_ACCESS_RIGHT);

        Organisation organisationObj = organisationDao.load(organisation);

        return new ClientConfigurable(organisationObj.getName(), pretty(organisationObj, OrganisationConfig.class));
    }

    @RequestMapping(value = "/organisation", method = RequestMethod.POST)
    public void saveOrganisation(@RequestBody final ClientConfigurable saveRequest) {
        authorisationController.checkAccess(ADMINISTRATION_ACCESS_RIGHT);

        String name = saveRequest.name;
        String configuration = saveRequest.configuration;

        Assert.hasText(name, "Organisation name is mandatory");
        Assert.isTrue(VALID_NAME_PATTERN.matcher(name).matches(),
                "Invalid characters in organisation name '" + name + "'");
        Assert.hasText(configuration, "Configuration is mandatory");
        OrganisationConfig orgConfig;
        try {
            orgConfig = JsonObjectMapper.getInstance().readValue(configuration, OrganisationConfig.class);
        } catch (JsonUnmarshallingException ex) {
            throw new IllegalArgumentException("Invalid configuration: " + ex.getMessage(), ex);
        }

        Organisation organisation = organisationDao.load(name);
        if (organisation == null) {
            Assert.isTrue(name.length() <= 15, "Organisation name is limited to 15 characters");

            organisation = new Organisation();
        }
        organisation.setName(name);
        organisation.setConfiguration(configuration);

        for (GluScriptMetadata scriptMeta : orgConfig.getGluScriptsConfig()) {
            String category = scriptMeta.getCategory();
            Assert.isTrue(category.length() <= 4, "Category limited to 4 characters. '" + category + "' is too long.");
        }

        if (organisation.getId() == null) {
            organisationDao.save(organisation);
        }
    }

    @RequestMapping(value = "/organisation/{organisation}/environment/{environment}", method = RequestMethod.GET)
    public ClientConfigurable getEnvironment(@PathVariable final String organisation,
            @PathVariable final String environment) throws Exception {
        authorisationController.checkAccess(ADMINISTRATION_ACCESS_RIGHT);

        Environment envObj = environmentDao.loadEnvironment(environment, organisation);

        return new ClientConfigurable(envObj.getName(), pretty(envObj, EnvironmentConfig.class));
    }

    private <T> String pretty(final Configurable configurable, final Class<T> configType) throws Exception {
        return PRETTY_JSON.writeValueAsString(
                PRETTY_JSON.readValue(configurable.getConfiguration(), configType));
    }

    @RequestMapping(value = "/organisation/{organisation}/environment", method = RequestMethod.POST)
    public void saveEnvironment(@PathVariable final String organisation,
            @RequestBody final ClientConfigurable saveRequest) {
        authorisationController.checkAccess(ADMINISTRATION_ACCESS_RIGHT);

        String name = saveRequest.name;
        String configuration = saveRequest.configuration;

        Assert.hasText(name, "Environment name is mandatory");
        Assert.isTrue(VALID_NAME_PATTERN.matcher(name).matches(),
                "Invalid characters in environment name '" + name + "'");
        Assert.hasText(configuration, "Configuration is mandatory");

        EnvironmentConfig conf;
        try {
            conf = JsonObjectMapper.getInstance().readValue(configuration, EnvironmentConfig.class);
        } catch (JsonUnmarshallingException ex) {
            throw new IllegalArgumentException("Invalid configuration: " + ex.getMessage(), ex);
        }

        Assert.hasText(conf.getAccessRight(), "'accessRight' for environment is mandatory");
        Assert.hasText(conf.getSecurityConfigTemplate(), "'securityConfigTemplate' for environment is mandatory");
        Assert.hasText(conf.getZookeeperRoot(), "'zookeeperRoot' for environment is mandatory");
        Assert.hasText(conf.getZookeeperPropertiesRoot(), "'zookeeperPropertiesRoot' for environment is mandatory");

        Map<String, String> zooKeeperClientProperties = conf.getZookeeperConnectionDetails();
        Assert.notEmpty(zooKeeperClientProperties, "'zookeeperConnectionDetails' for environment is mandatory");

        Assert.hasText(zooKeeperClientProperties.get("zookeeper.client.host.ports"),
                "zookeeper.client.host.ports is required");

        assertTimeout(zooKeeperClientProperties, "zookeeper.client.connection.timeout");
        assertTimeout(zooKeeperClientProperties, "zookeeper.client.session.timeout");
        assertTimeout(zooKeeperClientProperties, "zookeeper.client.reconnectInterval");

        Assert.notNull(securityTemplateDao.load(conf.getSecurityConfigTemplate()),
                "'securityConfigTemplate' " + conf.getSecurityConfigTemplate() + " does not exist");

        Environment environment;
        try {
            environment = environmentDao.loadEnvironment(name, organisation);
        } catch (EntityNotFoundException ex) {
            // inconsistent that this api does not return null.
            Assert.isTrue(name.length() <= 7, "Environment name is limited to 7 characters");
            environment = new Environment(name, organisationDao.load(organisation));
        }
        environment.setConfiguration(configuration);

        if (environment.getId() == null) {
            environmentDao.save(environment);
        }
    }

    @RequestMapping(value = "/organisation/{organisation}/environment/{environment}/agent", method = RequestMethod.GET)
    @ResponseBody
    public String getEnvironmentAgentConfig(@PathVariable final String organisation,
            @PathVariable final String environment) throws Exception {
        authorisationController.checkAccess(ADMINISTRATION_ACCESS_RIGHT);

        Environment envObj = environmentDao.loadEnvironment(environment, organisation);

        ZKClient zkClient = zkClientFactory.get(envObj);

        String path = getZkConfigPath(envObj);

        LOG.info("Retrieving agent configuration for {} from path {}", envObj, path);

        if (zkClient.exists(path) == null) {
            return null;
        }
        return ZK_STRING_TRANSFORMER.fromInput(zkClient.getData(path));
    }

    @RequestMapping(value = "/organisation/{organisation}/environment/{environment}/agent/suggest", method = RequestMethod.GET)
    @ResponseBody
    public String suggestEnvironmentAgentConfig(@PathVariable final String organisation,
            @PathVariable final String environment) throws Exception {
        authorisationController.checkAccess(ADMINISTRATION_ACCESS_RIGHT);

        Environment envObj = environmentDao.loadEnvironment(environment, organisation);

        EnvironmentConfig envConfig = PRETTY_JSON.readValue(envObj.getConfiguration(), EnvironmentConfig.class);

        SecurityTemplate secTemplate = securityTemplateDao.load(envConfig.getSecurityConfigTemplate());

        Map<String, String> args = new HashMap<>();
        args.put("environment", environment);
        args.put("securityname", secTemplate.getName());

        // Not exposing the full security template to freemarker to avoid accidently exposing the server private keys!
        args.put("agentKeystoreChecksum", secTemplate.getAgentKeystoreChecksum());
        args.put("agentKeystorePassword", secTemplate.getAgentKeystorePassword());
        args.put("agentKeyPassword", secTemplate.getAgentKeyPassword());

        args.put("agentTruststoreChecksum", secTemplate.getAgentTruststoreChecksum());
        args.put("agentTruststorePassword", secTemplate.getAgentTruststorePassword());

        args.put("zookeeperClientUsername", envConfig.getZookeeperConnectionDetails().get("zookeeper.client.username"));
        args.put("zookeeperClientPassword", envConfig.getZookeeperConnectionDetails().get("zookeeper.client.password"));
        args.put("zookeeperPropertiesRoot", envConfig.getZookeeperPropertiesRoot());

        StringWriter out = new StringWriter();
        suggestedAgentConfigTemplate.process(args, out);

        return out.toString();
    }

    @RequestMapping(value = "/organisation/{organisation}/environment/{environment}/agent", method = RequestMethod.POST)
    @ResponseBody
    public void saveEnvironmentAgentConfig(@PathVariable final String organisation,
            @PathVariable final String environment, @RequestBody final String configuration) throws Exception {
        authorisationController.checkAccess(ADMINISTRATION_ACCESS_RIGHT);

        Environment envObj = environmentDao.loadEnvironment(environment, organisation);

        EnvironmentConfig envConfig = PRETTY_JSON.readValue(envObj.getConfiguration(), EnvironmentConfig.class);
        SecurityTemplate securityTemplate = securityTemplateDao.load(envConfig.getSecurityConfigTemplate());

        String path = getZkConfigPath(envObj);
        LOG.info("Saving agent configuration for {} to path {}", envObj, path);

        ZKClient client = zkClientFactory.get(envObj);

        createZkNode(client, path, configuration);

        LOG.info("Updating agent security information", envObj, path);

        writeCerificate(envObj, "agent.keystore", securityTemplate.getAgentKeystore());
        writeCerificate(envObj, "console.truststore", securityTemplate.getAgentTruststore());
    }

    /**
     * @return
     * @deprecated One off migration for 2.13 release.
     */
    @Deprecated
    @ManagedOperation(description = "Initialises the agent security template info from existing zookeeper configuration")
    public String initialiseAgentSecurityTemplateFromZookeeper(final String organisation, final String environment,
            final String securityTemplateName) {
        return AbstractJmxProcessor.executeOperation(new Callable<String>() {
            @Override
            public String call() throws Exception {
                Environment envObj = environmentDao.loadEnvironment(environment, organisation);

                ZKClient zkClient = zkClientFactory.get(envObj);

                EnvironmentConfig envConfig = PRETTY_JSON.readValue(envObj.getConfiguration(), EnvironmentConfig.class);

                Assert.isTrue(envConfig.getSecurityConfigTemplate().equals(securityTemplateName),
                        "Mismatching security template for environment");

                String agentZookeeperConfig = getEnvironmentAgentConfig(organisation, environment);
                Properties agentProps = new Properties();
                agentProps.load(new StringReader(agentZookeeperConfig));

                // retrieve the existing security template and update it.
                SecurityTemplate securityTemplate = securityTemplateDao.load(securityTemplateName);

                securityTemplate.setAgentKeyPassword(agentProps.getProperty("glu.agent.keyPassword"));
                securityTemplate.setAgentKeystoreChecksum(agentProps.getProperty("glu.agent.keystoreChecksum"));
                securityTemplate.setAgentKeystorePassword(agentProps.getProperty("glu.agent.keystorePassword"));

                securityTemplate.setAgentTruststoreChecksum(agentProps.getProperty("glu.agent.truststoreChecksum"));
                securityTemplate.setAgentTruststorePassword(agentProps.getProperty("glu.agent.truststorePassword"));

                byte[] agentKeystore = zkClient.getData(getZkConfigPath(envObj, "agent.keystore"));
                securityTemplate.setAgentKeystore(agentKeystore);

                byte[] agentTruststore = zkClient.getData(getZkConfigPath(envObj, "console.truststore"));
                securityTemplate.setAgentTruststore(agentTruststore);

                return "Agent config for security template " + securityTemplateName + " initialised.";
            }
        }, LOG);
    }

    protected String getZkConfigPath(final Environment envObj) {
        return getZkConfigPath(envObj, "config.properties");
    }

    protected String getZkConfigPath(final Environment envObj, final String node) {
        String zkRoot = zookeeperRootFactory.get(envObj);

        return zkRoot + "/agents/fabrics/" + envObj.getName() + "/config/" + node;
    }

    private void assertTimeout(final Map<String, String> zooKeeperClientProperties, final String property) {
        Assert.isTrue(NumberUtils.isDigits(zooKeeperClientProperties.get(property)),
                property + " must be specified in milliseconds");
    }

    private void createZkNode(final ZKClient zkClient, final String path, final String data)
            throws InterruptedException, KeeperException {
        zkClient.createOrSetWithParents(path, data, Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
    }

    private void createZkNode(final ZKClient zkClient, final String path, final byte[] data)
            throws InterruptedException, KeeperException {
        if (zkClient.exists(path) != null) {
            zkClient.delete(path);
        }
        zkClient.create(path, data, Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
    }

    private void writeCerificate(final Environment envObj, final String configNode, final byte[] certData)
            throws Exception {
        ZKClient zkClient = zkClientFactory.get(envObj);
        String path = getZkConfigPath(envObj, configNode);

        createZkNode(zkClient, path, certData);
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

    @Required
    public void setSecurityTemplateDao(final SecurityTemplateDao securityTemplateDao) {
        this.securityTemplateDao = securityTemplateDao;
    }

    @Required
    public void setSwiftSecureClientHttpRequestFactoryBuilder(
            final SwiftSecureClientHttpRequestFactoryBuilder swiftSecureClientHttpRequestFactoryBuilder) {
        this.swiftSecureClientHttpRequestFactoryBuilder = swiftSecureClientHttpRequestFactoryBuilder;
    }

    @Required
    public void setOrganisationDao(final OrganisationDao organisationDao) {
        this.organisationDao = organisationDao;
    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }

    @Required
    public void setZkClientFactory(final EnvironmentBeanFactory<ZKClient> zkClientFactory) {
        this.zkClientFactory = zkClientFactory;
    }

    @Required
    public void setZookeeperRootFactory(final EnvironmentBeanFactory<String> zookeeperRootFactory) {
        this.zookeeperRootFactory = zookeeperRootFactory;
    }

    @Required
    public void setSuggestedAgentConfigTemplate(final Template suggestedAgentConfigTemplate) {
        this.suggestedAgentConfigTemplate = suggestedAgentConfigTemplate;
    }

    /**
     * Simple client representation of organisation / environment (as Organisation does not serialize the Configuration
     * blob).
     */
    static class ClientConfigurable {
        private final String name;
        private final String configuration;

        @JsonCreator
        public ClientConfigurable(@JsonProperty("name") final String name,
                @JsonProperty("configuration") final String configuration) {
            this.name = name;
            this.configuration = configuration;
        }

        public String getName() {
            return name;
        }

        public String getConfiguration() {
            return configuration;
        }
    }

}
