package com.ubs.f35.swift.util;

import java.io.Closeable;
import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

public class CSVUtil {

    /**
     * Reads CSV content from {@code reader} into List of String[], closes {@code reader} after reading.
     * 
     * @param reader
     * @return
     */
    public static List<String[]> readCSV(final Reader reader) {
        CSVReader csvReader = null;
        try {
            csvReader = new CSVReader(reader);
            return csvReader.readAll();
        } catch (IOException ex) {
            throw new IllegalStateException(ex);
        } finally {
            closeQuietly(csvReader);
        }
    }

    /**
     * Writes List of String[] into {@code writer} in CSV format, closes {@code writer} after writing.
     * 
     * @param lines
     * @param writer
     */
    public static void writeCSV(final List<String[]> lines, final Writer writer) {
        CSVWriter csvWriter = null;
        try {
            csvWriter = new CSVWriter(writer);
            csvWriter.writeAll(lines);
        } finally {
            closeQuietly(csvWriter);
        }
    }

    private static void closeQuietly(final Closeable closable) {
        if (closable != null) {
            try {
                closable.close();
            } catch (IOException e) {
            }
        }
    }

    /**
     * Converts List of String[] info CSV formatted string.
     * 
     * @param lines
     * @return
     */
    public static String writeCSV(final List<String[]> lines) {
        StringWriter stringWriter = new StringWriter();
        writeCSV(lines, stringWriter);
        return stringWriter.toString();
    }
}
