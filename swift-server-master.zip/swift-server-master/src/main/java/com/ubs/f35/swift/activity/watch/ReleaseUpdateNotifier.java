package com.ubs.f35.swift.activity.watch;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.f35.onboarding.mail.Attachment;
import com.ubs.f35.onboarding.mail.MailSender;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseDefinitionDao;
import com.ubs.f35.swift.dao.ReleaseWatchDao;
import com.ubs.f35.swift.dao.model.ReleaseWatch.WatchType;
import com.ubs.f35.swift.security.UserDetailsLookup;

public class ReleaseUpdateNotifier {
    private static final Logger LOG = LoggerFactory.getLogger(ReleaseUpdateNotifier.class);

    private ReleaseWatchDao releaseWatchDao;
    private ReleaseDefinitionDao releaseDefinitionDao;
    private UserDetailsLookup userDetailsLookup;
    private MailSender mailSender;

    static final String TEMPLATE_NAME = "release-notify-template";

    public static final String LOGO_NAME = "ubs-deploy-logo.gif";
    public static final String LOGO_PATH = "/properties/email/" + LOGO_NAME;
    public static final byte[] LOGO_BYTES;

    static {
        try {
            LOGO_BYTES = IOUtils.toByteArray(ReleaseUpdateNotifier.class.getResourceAsStream(LOGO_PATH));
        } catch (IOException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    @Transactional
    public void publishReleaseNotifications(final Integer releaseId) {
        List<String> watchers = releaseWatchDao.loadWatchers(releaseId, WatchType.RELEASE_UPDATE);
        if (!watchers.isEmpty()) {
            ReleaseDefinition release = releaseDefinitionDao.load(releaseId);

            String subject = "Release update notification - " + release.getName();
            Attachment attachment = Attachment.create(LOGO_NAME, LOGO_BYTES);

            // TODO Include further details in the email like a diff of changes made
            Map<String, Object> emailArgs = new HashMap<>();
            emailArgs.put("releaseId", releaseId);
            emailArgs.put("releaseName", release.getName());
            emailArgs.put("releaseOrganisation", release.getTeam().getOrganisation().getName());
            emailArgs.put("releaseTeam", release.getTeam().getName());

            for (String watcher : watchers) {
                if (watcher.equals(release.getLastUpdatedBy())) {
                    LOG.debug("Not notifying user {} of update to release {} as they made the change");
                } else {
                    Map<String, Object> userDetails = userDetailsLookup.getUserDetails(watcher);

                    String recipient = String.valueOf(userDetails.get("mail"));
                    try {
                        mailSender.send(TEMPLATE_NAME, subject, emailArgs, attachment, recipient);
                    } catch (Exception e) {
                        LOG.error("Failed to publish release update to recipient {}", recipient, e);
                    }
                }
            }
        }
    }

    @Required
    public void setReleaseWatchDao(final ReleaseWatchDao releaseWatchDao) {
        this.releaseWatchDao = releaseWatchDao;
    }

    @Required
    public void setUserDetailsLookup(final UserDetailsLookup userDetailsLookup) {
        this.userDetailsLookup = userDetailsLookup;
    }

    @Required
    public void setMailSender(final MailSender mailSender) {
        this.mailSender = mailSender;
    }

    @Required
    public void setReleaseDefinitionDao(final ReleaseDefinitionDao releaseDefinitionDao) {
        this.releaseDefinitionDao = releaseDefinitionDao;
    }
}
