package com.ubs.f35.swift.dao;

import java.util.List;

public interface NexusArtifactDao {
    List<String> getGroups(String group, String artifact);

    List<String> getArtifacts(String organisation, String group, String artifact);

    List<NexusArtifact> loadAll();

    List<NexusArtifact> getArtifacts(String organisation, String artifact);

    PagingResult<NexusArtifact> getArtifacts(String organisation, String artifact, PagingFilter pagingFilter);

    void createIfNotExists(NexusArtifact artifact);

    void create(NexusArtifact artifact);

    NexusArtifact load(NexusArtifact artifact);
}
