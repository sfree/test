package com.ubs.f35.swift.processor;

import com.google.common.base.Objects;

public class ReleaseDeploymentStep {
    private final Step step;
    private final Object stepData;

    public ReleaseDeploymentStep(final Step step) {
        this(step, null);
    }

    public ReleaseDeploymentStep(final Step step, final Object stepData) {
        this.step = step;
        this.stepData = stepData;
    }

    public Step getStep() {
        return step;
    }

    public Object getStepData() {
        return stepData;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(step, stepData);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ReleaseDeploymentStep) {
            ReleaseDeploymentStep that = (ReleaseDeploymentStep) object;
            return Objects.equal(this.step, that.step)
                    && Objects.equal(this.stepData, that.stepData);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("step", step)
                .add("stepData", stepData)
                .toString();
    }

    enum Step {
        SelectTargets, // For organisations with targeted deployments enabled, the user first needs to select the
                       // targets to deploy to.
        Configure, // Swift configuration of the selected targets
        Properties, // Properties entry for the artifacts
        Deploy // Deployment
    }
}
