package com.ubs.f35.swift.processor;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ubs.f35.core.AuthenticationPrincipal;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.state.OperationContextProvider;
import com.ubs.f35.swift.util.EnvironmentNameFunction;

@Controller
@RequestMapping(value = "/api/auth")
public class AuthorisationProcessor {

    private AuthorisationController authorisationController;
    private OperationContextProvider opContextProvider;

    @RequestMapping(value = "/global", method = RequestMethod.GET)
    public List<String> getGlobalAccessRights() {
        if (authorisationController.hasArpAccessRight(AdminProcessor.ADMINISTRATION_ACCESS_RIGHT)) {
            return Collections.singletonList(AdminProcessor.ADMINISTRATION_ACCESS_RIGHT);
        }

        return Collections.emptyList();
    }

    @RequestMapping(method = RequestMethod.GET)
    public List<String> getAccessRights(@RequestParam final String organisation) {
        List<String> accessRights = ProcessorUtil.transform(authorisationController.getUserEnvironments(organisation),
                EnvironmentNameFunction.INSTANCE);

        accessRights.addAll(authorisationController.getUserAccessRights(organisation));

        return accessRights;
    }

    @RequestMapping(value = "/environments", method = RequestMethod.GET)
    public List<Environment> getEnvironmentAccessRights(@RequestParam final String organisation) {
        return authorisationController.getUserEnvironments(organisation);
    }

    @RequestMapping(value = "/user", method = RequestMethod.GET)
    public AuthenticationPrincipal getCurrentUserDetails() {
        return opContextProvider.getCurrentPrincipal();
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

    @Required
    public void setOpContextProvider(final OperationContextProvider opContextProvider) {
        this.opContextProvider = opContextProvider;
    }

}
