package com.ubs.f35.swift.properties;

import static com.ubs.f35.swift.service.ArtifactConfigurationService.isSnapshot;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.base.Objects;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimaps;
import com.google.common.collect.SetMultimap;
import com.ubs.f35.swift.config.model.ArtifactCommonConfig;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ArtifactPropertyKeysDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.event.ArtifactCommonConfigurationChangeListener;
import com.ubs.f35.swift.executors.SwiftExecutors;
import com.ubs.f35.swift.properties.model.PropertyKey;
import com.ubs.f35.swift.util.LoadingCacheUtil;

/**
 * Attempts to extract cached property keys from the datastore, otherwise delegates to another
 * {@link PropertyKeysProvider} which pulls the artifact property keys from the repository.
 * <p>
 * Note that this class implements two levels of caching for a set of property keys.
 * <ol>
 * <li>Database cache of keys for release versions of artifacts</li>
 * <li>Temporary in-memory cache for both release and snapshot versions of artifacts</li>
 * </ol>
 * Fetching the set of keys directly from the artifact distribution package in the Nexus repository is time-consuming
 * and delays the Swift GUI. For release versions of an artifact, keys should not change, so once we've obtained them
 * once, we permanently cache them in our database. Properties in snapshot versions may change, so we fetch them almost
 * every time - we only cache them in memory for a short amount of time (5 mins default) to improve usability of the
 * Properties screen in the GUI for snapshot versions.
 * </p>
 * 
 * @author levyjo
 * 
 */
public class CachedPropertyKeysProvider implements PropertyKeysProvider, PropertyKeysPrefetcher,
        ArtifactCommonConfigurationChangeListener,
        InitializingBean {

    private static final Logger LOG = LoggerFactory.getLogger(CachedPropertyKeysProvider.class);

    private PropertyKeysProvider delegatePropertyKeysProvider;
    private ArtifactPropertyKeysDao artifactPropertyKeysDao;
    private LoadingCache<PropertiesCacheKey, Set<PropertyKey>> cache;
    private SetMultimap<NexusArtifact, PropertiesCacheKey> cacheInvalidationMap;
    private long memoryCacheSize = 500;
    private long memoryCacheExpiryMinutes = 5;
    private int prefetcherMaxThreads = 5;

    private final ThreadFactory threadFactory = SwiftExecutors.namedThreadFactory("property-key-prefetcher", true);
    private ThreadPoolExecutor prefetcherExecutor;

    public CachedPropertyKeysProvider() {

    }

    @Override
    public void afterPropertiesSet() {

        // cacheInvalidationMap is required so that when the the property template files in the ArtifactConfig is
        // changed, we can invalidate ALL artifact versions of the NexusArtifact whose config has changed
        cacheInvalidationMap = Multimaps.synchronizedSetMultimap(HashMultimap
                .<NexusArtifact, PropertiesCacheKey>create());

        cache = CacheBuilder.newBuilder().maximumSize(memoryCacheSize)
                .expireAfterWrite(memoryCacheExpiryMinutes, TimeUnit.MINUTES)
                .removalListener(
                        new RemovalListener<PropertiesCacheKey, Set<PropertyKey>>() {
                            // Entries are removed either on expiry or on afterUpdate
                            @Override
                            public void onRemoval(
                                    final RemovalNotification<PropertiesCacheKey, Set<PropertyKey>> removal) {
                                cacheInvalidationMap.remove(removal.getKey().artifact.getNexusArtifact(),
                                        removal.getKey());
                            }
                        }
                )
                .build(
                        new CacheLoader<PropertiesCacheKey, Set<PropertyKey>>() {
                            @Override
                            public Set<PropertyKey> load(final PropertiesCacheKey cacheKey) {
                                cacheInvalidationMap.put(cacheKey.artifact.getNexusArtifact(), cacheKey);
                                return fetchPropertyKeysFromDatabaseOrDelegate(cacheKey);
                            }
                        }
                );

        prefetcherExecutor = new ThreadPoolExecutor(1, prefetcherMaxThreads, 5L, TimeUnit.MINUTES,
                new LinkedBlockingQueue<Runnable>(), threadFactory);
    }

    @Override
    public Set<PropertyKey> getPropertyKeys(final String organisation, final Artifact artifact) {
        return LoadingCacheUtil.getUnchecked(cache, new PropertiesCacheKey(organisation, artifact.toSimpleArtifact()));
    }

    @Override
    public void prefetchPropertyKeys(final String organisation, final Artifact artifact) {
        Artifact simpleArtifact = artifact.toSimpleArtifact();
        LOG.debug("Prefetching property keys for {}", artifact);
        prefetcherExecutor.submit(new PropertyDiscoveryCallable(organisation, simpleArtifact));
    }

    @Override
    public void afterUpdate(final ArtifactCommonConfig config) {
        NexusArtifact nexusArtifact = config.getArtifact();
        cache.invalidateAll(cacheInvalidationMap.removeAll(nexusArtifact));
        artifactPropertyKeysDao.deletePropertyKeys(nexusArtifact);
    }

    private Set<PropertyKey> fetchPropertyKeysFromDatabaseOrDelegate(final PropertiesCacheKey cacheKey) {

        Artifact artifact = cacheKey.artifact;
        Set<PropertyKey> propertyKeys;

        if (isSnapshot(artifact)) {

            LOG.debug("Getting property keys for {} from Nexus repository for snapshot version {}",
                    artifact.getArtifactId(), artifact.getVersion());
            propertyKeys = delegatePropertyKeysProvider.getPropertyKeys(cacheKey.organisation, artifact);

        } else {

            LOG.debug("Looking for property keys for {} {} in Swift database.", artifact.getArtifactId(),
                    artifact.getVersion());
            propertyKeys = fetchPropertyKeysFromDatabase(artifact);

            if (propertyKeys.isEmpty()) {
                LOG.debug("Property keys for {} {} not found in Swift database. Fetching from Nexus...",
                        artifact.getArtifactId(), artifact.getVersion());
                propertyKeys = delegatePropertyKeysProvider.getPropertyKeys(cacheKey.organisation, artifact);
                if (propertyKeys != null && !propertyKeys.isEmpty()) {
                    storePropertyKeys(artifact, propertyKeys);
                }
            }
        }

        return propertyKeys;
    }

    private Set<PropertyKey> fetchPropertyKeysFromDatabase(final Artifact artifact) {

        List<PropertyKey> listOfKeys = artifactPropertyKeysDao.getPropertyKeys(artifact);
        return new HashSet<PropertyKey>(listOfKeys);

    }

    private void storePropertyKeys(final Artifact artifact, final Set<PropertyKey> propertyKeys) {

        artifactPropertyKeysDao.savePropertyKeys(artifact, new ArrayList<PropertyKey>(propertyKeys));

    }

    @Required
    public void setDelegatePropertyKeysProvider(
            final PropertyKeysProvider delegateArtifactPropertyKeysExtractor) {
        this.delegatePropertyKeysProvider = delegateArtifactPropertyKeysExtractor;
    }

    @Required
    public void setArtifactPropertyKeysDao(final ArtifactPropertyKeysDao artifactPropertyKeysDao) {
        this.artifactPropertyKeysDao = artifactPropertyKeysDao;
    }

    public void setMemoryCacheSize(final long memoryCacheSize) {
        this.memoryCacheSize = memoryCacheSize;
    }

    public void setMemoryCacheExpiryMinutes(final long memoryCacheExpiryMinutes) {
        this.memoryCacheExpiryMinutes = memoryCacheExpiryMinutes;
    }

    public void setPrefetcherMaxThreads(final int prefetcherMaxThreads) {
        this.prefetcherMaxThreads = prefetcherMaxThreads;
    }

    private static class PropertiesCacheKey {
        private final String organisation;
        private final Artifact artifact;

        public PropertiesCacheKey(final String organisation, final Artifact artifact) {
            this.organisation = organisation;
            this.artifact = artifact;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(organisation, artifact);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof PropertiesCacheKey) {

                PropertiesCacheKey that = (PropertiesCacheKey) object;
                return Objects.equal(this.organisation, that.organisation)
                        && Objects.equal(this.artifact, that.artifact);
            }
            return false;
        }
    }

    class PropertyDiscoveryCallable implements Callable<Set<PropertyKey>> {
        private final PropertiesCacheKey propertiesCacheKey;

        public PropertyDiscoveryCallable(final String organisation, final Artifact artifact) {
            this.propertiesCacheKey = new PropertiesCacheKey(organisation, artifact);
        }

        @Override
        public Set<PropertyKey> call() {
            Set<PropertyKey> result = LoadingCacheUtil.getUnchecked(cache, propertiesCacheKey);
            LOG.debug("Prefetch of keys for {} successful", propertiesCacheKey.artifact);
            return result;
        }
    }
}
