package com.ubs.f35.swift.dao;

import javax.persistence.EntityNotFoundException;

public interface ArtifactDao {

    Artifact resolvePersistentArtifact(final Artifact artifact) throws EntityNotFoundException;

    Artifact resolveOrCreatePersistentArtifact(final Artifact artifact);

}
