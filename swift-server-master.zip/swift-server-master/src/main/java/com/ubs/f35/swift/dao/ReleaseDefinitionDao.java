package com.ubs.f35.swift.dao;

import java.util.List;

import com.ubs.f35.swift.dao.hibernate.AuditEntry;
import com.ubs.f35.swift.model.ReleaseFilters;

public interface ReleaseDefinitionDao {

    ReleaseDefinition load(Integer id);

    void create(ReleaseDefinition releaseDefinition);

    PagingResult<ReleaseDefinition> list(ReleaseFilters releaseFilters, PagingFilter pagingFilter);

    List<AuditEntry<ReleaseDefinition>> getAuditHistory(Integer releaseId, PagingFilter daoFilter);

    Integer getLatestRevisionId(Integer releaseId);

    ReleaseDefinition loadRevision(Integer releaseId, Integer revision);

    Integer getRevisionAtDate(Integer releaseId, Long timestamp);

    List<DailyReleaseStats> getDailyReleaseStats(String organisation);

}
