package com.ubs.f35.swift.state;

import com.ubs.f35.core.AuthenticationPrincipal;

/**
 * Retrieves state
 */
public interface OperationContextProvider {
    String getCurrentUser();

    AuthenticationPrincipal getCurrentPrincipal();

    void setCurrentUser(AuthenticationPrincipal principal);

    void reset();

}