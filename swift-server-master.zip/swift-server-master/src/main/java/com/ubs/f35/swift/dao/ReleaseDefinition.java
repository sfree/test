package com.ubs.f35.swift.dao;

import static com.ubs.f35.swift.config.model.Objects2.toStringSafe;

import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.codehaus.jackson.annotate.JsonRawValue;
import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.hibernate.annotations.NaturalId;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Team;

@SequenceGenerator(name = "oracle_seq", sequenceName = "seq_release_definition_id")
@Entity
@Table(name = "release_definition")
@Audited
public class ReleaseDefinition {
    private static final Logger LOG = LoggerFactory.getLogger(ReleaseDefinition.class);

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "oracle_seq")
    private Integer id;
    @NaturalId(mutable = true)
    private String name;

    @Lob
    @Basic(fetch = FetchType.LAZY)
    private String description;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "team_id")
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private Team team;

    @Column(updatable = false)
    private String createdBy;
    @Column(insertable = false, updatable = false)
    @Generated(GenerationTime.INSERT)
    private Date createdTime;
    @NotAudited
    private String lastUpdatedBy;
    @Version
    private Date lastUpdatedTime;
    private Date releaseDate;

    @Column(name = "IS_LOCKED")
    private boolean locked;

    private String deploymentProcess;

    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonRawValue
    // TODO do we need to audit every change to the deploymentTemplate?
    private String deploymentTemplate;

    // A list of artifacts which will be deployed for this release.
    @ManyToMany(cascade = { CascadeType.DETACH }, fetch = FetchType.LAZY)
    @JoinTable(name = "RELEASE_DEFINITION_ARTIFACTS",
            joinColumns = { @JoinColumn(name = "RELEASE_DEFINITION_ID") },
            inverseJoinColumns = { @JoinColumn(name = "ARTIFACT_ID") })
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @AuditJoinTable(name = "RELEASE_DEF_ARTIFACTS_AUD")
    private List<Artifact> artifacts;

    @OneToMany(mappedBy = "releaseDefinition", cascade = CascadeType.ALL, orphanRemoval = true)
    @LazyCollection(LazyCollectionOption.TRUE)
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private List<ReleaseLink> releaseLinks;

    @Transient
    private Integer revision;
    @Transient
    private Integer latestRevision;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(final Team team) {
        this.team = team;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(final String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(final Date createdTime) {
        this.createdTime = createdTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(final String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Date getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    public void setLastUpdatedTime(final Date lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(final Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(final boolean locked) {
        this.locked = locked;
    }

    public List<Artifact> getArtifacts() {
        return artifacts;
    }

    public void setArtifacts(final List<Artifact> artifacts) {
        this.artifacts = artifacts;
    }

    public List<ReleaseLink> getReleaseLinks() {
        return releaseLinks;
    }

    public void setReleaseLinks(final List<ReleaseLink> releaseLinks) {
        this.releaseLinks = releaseLinks;
    }

    public Integer getRevision() {
        return revision;
    }

    public void setRevision(final Integer revision) {
        this.revision = revision;
    }

    public Integer getLatestRevision() {
        return latestRevision;
    }

    public void setLatestRevision(final Integer latestRevision) {
        this.latestRevision = latestRevision;
    }

    public String getDeploymentProcess() {
        return deploymentProcess;
    }

    public void setDeploymentProcess(final String deploymentProcess) {
        this.deploymentProcess = deploymentProcess;
    }

    public String getDeploymentTemplate() {
        return deploymentTemplate;
    }

    public void setDeploymentTemplate(final String deploymentTemplate) {
        this.deploymentTemplate = deploymentTemplate;
    }

    public boolean compareArtifacts(final ReleaseDefinition other) {
        List<Artifact> otherArtifacts = other.getArtifacts();
        return getArtifacts().containsAll(otherArtifacts) && otherArtifacts.containsAll(getArtifacts());
    }

    /**
     * So that hibernate doesn't barf on updating the release. As per this suggestion
     * http://stackoverflow.com/questions/12285089/why-does-hibernate-do-areequal-when-updatable-false-on-the-field
     */
    @PreUpdate
    private void loadLazyFields() {
        LOG.debug("Loading release description before update");
        getDescription();
        getDeploymentTemplate();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ReleaseDefinition) {
            ReleaseDefinition that = (ReleaseDefinition) object;
            return Objects.equal(this.id, that.id)
                    && Objects.equal(this.name, that.name)
                    && Objects.equal(this.description, that.description)
                    && Objects.equal(this.team, that.team)
                    && Objects.equal(this.createdBy, that.createdBy)
                    && Objects.equal(this.createdTime, that.createdTime)
                    && Objects.equal(this.lastUpdatedBy, that.lastUpdatedBy)
                    && Objects.equal(this.lastUpdatedTime, that.lastUpdatedTime)
                    && Objects.equal(this.releaseDate, that.releaseDate)
                    && Objects.equal(this.locked, that.locked)
                    && Objects.equal(this.deploymentProcess, that.deploymentProcess)
                    && Objects.equal(this.releaseLinks, that.releaseLinks)
                    && Objects.equal(this.artifacts, that.artifacts);
        }
        return false;
    }

    @Override
    public String toString() {
        // description not included in to string as lazily loaded
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("name", name)
                .add("team", team)
                .add("createdBy", createdBy)
                .add("createdTime", createdTime)
                .add("lastUpdatedBy", lastUpdatedBy)
                .add("lastUpdatedTime", lastUpdatedTime)
                .add("releaseDate", releaseDate)
                .add("locked", locked)
                .add("deploymentProcess", deploymentProcess)
                .add("releaseLinks", toStringSafe(releaseLinks))
                .add("artifacts", toStringSafe(artifacts))
                .toString();
    }
}
