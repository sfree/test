package com.ubs.f35.swift.executors;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

public class RetryExecutor implements InitializingBean {
    private static final Logger LOG = LoggerFactory.getLogger(RetryExecutor.class);

    private ScheduledExecutorService executorService = SwiftExecutors.getProcessRestartScheduledExecutor();

    private long retryDelaySeconds = 30;
    private long maxRetryDelaySeconds = TimeUnit.MINUTES.toSeconds(5);

    // calculated
    private int maxRetries;

    /**
     * Executes a job that may need retrying. If a retry is required, the job should throw a {@link RetryableException}.
     * 
     * @param job
     */
    public void execute(final Runnable job) {
        executorService.execute(new RetryJob(job));
    }

    class RetryJob implements Runnable {
        final Runnable actualJob;
        int attempts = 0;

        public RetryJob(final Runnable actualJob) {
            this.actualJob = actualJob;
        }

        @Override
        public void run() {
            attempts++;

            try {
                actualJob.run();
            } catch (RetryableException ex) {
                if (attempts <= maxRetries) {
                    LOG.info("Job {} failed.  Will retry", actualJob);

                    executorService.schedule(this, retryDelaySeconds, TimeUnit.SECONDS);
                } else {
                    LOG.error("Job failed {} after {} attempts.  No more retries.", actualJob, attempts);
                    LOG.info("Agent not responding.", ex.getCause());
                }
                return;
            } catch (Throwable ex) {
                LOG.error("Exception running job", ex);
            }
        }
    }

    @Override
    public void afterPropertiesSet() {
        maxRetries = (int) Math.ceil((double) maxRetryDelaySeconds / retryDelaySeconds);
    }

    public void setRetryDelaySeconds(final long retryDelaySeconds) {
        this.retryDelaySeconds = retryDelaySeconds;
    }

    public void setMaxRetryDelaySeconds(final long maxRetryDelaySeconds) {
        this.maxRetryDelaySeconds = maxRetryDelaySeconds;
    }

    public void setExecutorService(final ScheduledExecutorService executorService) {
        this.executorService = executorService;
    }
}
