package com.ubs.f35.swift.processor;

import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.common.base.Function;
import com.google.common.base.Functions;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.HostDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.SwiftGroupDao;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.SwiftGroup;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.util.EnvironmentCloneFunction;
import com.ubs.f35.swift.util.HostNameFunction;

@Controller
@RequestMapping(value = "/api/groups")
@Transactional
public class SwiftGroupsProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(SwiftGroupsProcessor.class);

    private SwiftGroupDao swiftGroupDao;
    private HostDao hostDao;
    private AuthorisationController authorisationController;

    @RequestMapping(value = "/admin", method = RequestMethod.GET)
    public List<String> getUserAdminGroups() {
        return Lists.newArrayList(Collections2.transform(authorisationController.getUserAdminGroups(),
                new Function<String, String>() {
                    @Override
                    public String apply(final String input) {
                        return input.substring(0,
                                input.length() - AuthorisationController.ARP_GROUP_ADMIN_SUFFIX.length());
                    }
                }));
    }

    @RequestMapping(value = "/{groupName}", method = RequestMethod.GET)
    public SwiftGroup load(@PathVariable final String groupName) {
        return initialise(swiftGroupDao.loadGroup(groupName));
    }

    /**
     * TODO this belongs in {@link ArtifactConfigurationProcessor}. Perhaps
     * {@link ArtifactConfigurationProcessor#getHosts(String)} would have sufficed
     */
    @Deprecated
    @RequestMapping(value = "/hosts", method = RequestMethod.GET)
    public List<String> getHosts(@RequestParam(value = "environment") final List<Integer> environmentIds) {
        return Lists.transform(hostDao.loadByEnvironments(environmentIds), HostNameFunction.INSTANCE);
    }

    @RequestMapping(method = RequestMethod.PUT)
    public SwiftGroup save(@RequestBody final SwiftGroup group) {
        validate(group);

        return initialise(swiftGroupDao.save(group));
    }

    private void validate(final SwiftGroup group) {

        Assert.hasText(group.getName(), "Group name must be specified");
        Assert.notEmpty(group.getEnvironments(), "Environments must be specified");
        Assert.notEmpty(group.getPermissions(), "At least one entitlement must be specified");

        validateEnvironmentsAndHosts(group);

        authorisationController.checkAdminAccess(group.getName());
    }

    private void validateEnvironmentsAndHosts(final SwiftGroup group) {

        for (Environment env : group.getEnvironments()) {
            authorisationController.checkEnvironmentAccess(env);
        }

        List<String> hosts = Lists.newArrayList();
        if (!CollectionUtils.isEmpty(group.getHosts())) {
            for (Host host : group.getHosts()) {
                Host persistentHost = hostDao.loadExpected(host.getHostname());
                if (!group.getEnvironments().contains(persistentHost.getEnvironment())) {
                    throw new IllegalArgumentException("Host " + host.getHostname()
                            + " may not be added to this group as it is from a different environment");
                }
                hosts.add(host.getHostname());
            }
        }

        // for each host / artifact added, only allow it to be saved to this group if the current user also has ADMIN
        // permissions to all other groups the artifact is already in.
        Multimap<NexusArtifact, String> artifactMap = swiftGroupDao.findGroupsByArtifact(group.getEnvironments(),
                group.getArtifacts(),
                group.getPermissions());
        Multimap<String, String> hostsMap = swiftGroupDao.findGroupsByHost(group.getEnvironments(), hosts,
                group.getPermissions());

        Set<String> requiredGroups = Sets.newHashSet();
        requiredGroups.addAll(artifactMap.values());
        requiredGroups.addAll(hostsMap.values());
        requiredGroups.remove(group.getName());

        for (String requredGroup : requiredGroups) {
            authorisationController.checkAdminAccess(requredGroup);
        }
    }

    private SwiftGroup initialise(final SwiftGroup group) {

        if (group == null) {
            return null;
        }

        SwiftGroup result = new SwiftGroup();
        result.setName(group.getName());
        result.setArtifacts(ProcessorUtil.transform(group.getArtifacts(), new Function<NexusArtifact, NexusArtifact>() {
            @Override
            public NexusArtifact apply(final NexusArtifact input) {
                return new NexusArtifact(input.getGroupId(), input.getArtifactId());
            }
        }));
        result.setEnvironments(ProcessorUtil.transform(group.getEnvironments(), EnvironmentCloneFunction.INSTANCE));

        result.setHosts(ProcessorUtil.transform(group.getHosts(), new Function<Host, Host>() {
            @Override
            public Host apply(final Host input) {
                Host host = new Host();
                host.setHostname(input.getHostname());
                return host;
            }
        }));
        result.setPermissions(ProcessorUtil.transform(group.getPermissions(), Functions.<String>identity()));
        result.setLastUpdatedTime(group.getLastUpdatedTime());

        return result;
    }

    @Required
    public void setSwiftGroupDao(final SwiftGroupDao swiftGroupDao) {
        this.swiftGroupDao = swiftGroupDao;
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

    @Required
    public void setHostDao(final HostDao hostDao) {
        this.hostDao = hostDao;
    }
}
