package com.ubs.f35.swift.webhook;

import java.util.List;

import com.google.common.base.Function;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.processor.ProcessorUtil;
import com.ubs.swift.webhook.model.DeploymentNotification;
import com.ubs.swift.webhook.model.ReleaseDataGroup;

public class DeploymentNotificationBuilder {

    public static DeploymentNotification newNotification(final Deployment deployment,
            final ReleaseDefinition releaseDefinition, final String user, final List<String> watchingUsers) {

        List<String> environments = ProcessorUtil.transform(deployment.getEnvDeployments(),
                new Function<EnvDeployment, String>() {
                    @Override
                    public String apply(final EnvDeployment input) {
                        return input.getEnvironment().getName();
                    }
                });

        DeploymentNotification notification = new DeploymentNotification();

        // deployment related
        notification.setDeploymentType(deployment.getDeploymentType().toString());
        notification.setStatus(deployment.getDeploymentStatus().toString());
        notification.setPlanId(deployment.getId().toString());
        notification.setDeployTime(deployment.getDeployTime());
        notification.setEnvironments(environments);
        notification.setObjectId(deployment.getReleaseId());
        notification.setUser(user);

        // release related
        ReleaseDataGroup releaseDataGroup = notification.getRelease();
        releaseDataGroup.setName(releaseDefinition.getName());
        releaseDataGroup.setDescription(releaseDefinition.getDescription());
        releaseDataGroup.setOrganisation(releaseDefinition.getTeam().getOrganisation().getName());
        releaseDataGroup.setTeam(releaseDefinition.getTeam().getName());
        releaseDataGroup.setLastUpdatedBy(releaseDefinition.getLastUpdatedBy());
        releaseDataGroup.setCreatedBy(releaseDefinition.getCreatedBy());

        releaseDataGroup.setWatchingUsers(watchingUsers);

        return notification;
    }

}
