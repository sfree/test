package com.ubs.f35.swift.service.glu;

import java.util.Collections;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.google.common.base.Predicate;
import com.ubs.f35.swift.environment.model.glu.Entry;

/**
 * Returns deployment model entries which match the agent
 * 
 * @author levyjo
 * 
 */
public class EntryMatchesAgentsPredicate implements Predicate<Entry> {

    private final List<String> agents;

    public EntryMatchesAgentsPredicate(final List<String> agents) {
        this.agents = agents;
    }

    public EntryMatchesAgentsPredicate(final String agent) {
        this.agents = Collections.singletonList(agent);
    }

    @Override
    public boolean apply(final Entry entry) {
        if (CollectionUtils.isEmpty(agents)) {
            return true;
        }
        return agents.contains(entry.getAgent());
    }

}
