package com.ubs.f35.swift.properties;

import java.util.List;
import java.util.Map;

import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.properties.bulk.PropertyUpdate;
import com.ubs.f35.swift.properties.model.ArtifactProperties;

/**
 * {@link ZooKeeperConnector} looks after managing zookeeper properties in a single environment.
 */
public interface ZooKeeperConnector {

    Map<String, String> getProperties(final Artifact artifact);

    void saveProperties(ArtifactProperties artifactProperties);

    void saveUpdates(Artifact artifact, List<PropertyUpdate> propertyUpdates);

}
