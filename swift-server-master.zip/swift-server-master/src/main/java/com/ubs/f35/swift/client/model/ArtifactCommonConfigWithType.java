package com.ubs.f35.swift.client.model;

import com.ubs.f35.swift.config.model.ArtifactCommonConfig;

public class ArtifactCommonConfigWithType extends ArtifactCommonConfig implements WithArtifactType {
    private final ArtifactType artifactType;

    public ArtifactCommonConfigWithType(final ArtifactCommonConfig commonConfig, final ArtifactType artifactType) {
        super(commonConfig.getGroupId(), commonConfig.getArtifactId(), commonConfig.isNonProd(), commonConfig
                .hasProperties(), commonConfig.getPropertyTemplates(), commonConfig.getLastUpdatedTime());

        this.artifactType = artifactType;
    }

    @Override
    public ArtifactType getArtifactType() {
        return artifactType;
    }

}
