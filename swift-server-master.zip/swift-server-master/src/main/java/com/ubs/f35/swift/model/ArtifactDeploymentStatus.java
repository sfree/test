package com.ubs.f35.swift.model;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.google.common.base.Objects;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.processor.StatusProcessor.EntryToArtifactConvertor;

public class ArtifactDeploymentStatus {

    private final Artifact artifact;
    private transient final Entry entry;
    private final State state;
    private transient final Environment environment;

    public ArtifactDeploymentStatus(final Entry entry, final State state,
            final Environment environment) {
        this(EntryToArtifactConvertor.INSTANCE.apply(entry), entry, state, environment);
    }

    public ArtifactDeploymentStatus(final Artifact artifact, final Entry entry, final State state,
            final Environment environment) {
        this.artifact = artifact;
        this.entry = entry;
        this.state = state;
        this.environment = environment;
    }

    public Artifact getArtifact() {
        return artifact;
    }

    public String getName() {
        return ArtifactConfig.DEFAULT_INSTANCE_NAME.equals(entry.getName()) ? null : entry.getName();
    }

    public String getAgent() {
        return entry.getAgent();
    }

    public List<String> getTags() {
        return entry.getTags();
    }

    public State getState() {
        return state;
    }

    public String getEnvironment() {
        return environment.getName();
    }

    /**
     * legacy {@link #getEnvironment()} required by client.
     * 
     * @return
     */
    @JsonIgnore
    public Environment getEnvironmentObj() {
        return environment;
    }

    @JsonIgnore
    public Entry getEntry() {
        return entry;
    }

    /**
     * Returns a unique id for this record for client matching.
     * 
     * @return
     */
    public String getId() {
        return ArtifactInstanceId.buildId(getEnvironmentObj(), entry.getMountPoint());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(artifact, entry, state, environment);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ArtifactDeploymentStatus) {
            ArtifactDeploymentStatus that = (ArtifactDeploymentStatus) object;
            return Objects.equal(this.artifact, that.artifact)
                    && Objects.equal(this.entry, that.entry)
                    && Objects.equal(this.state, that.state)
                    && Objects.equal(this.environment, that.environment);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("artifact", artifact)
                .add("entry", entry)
                .add("state", state)
                .toString();
    }

}
