package com.ubs.f35.swift.service;

import org.joda.time.Duration;
import org.springframework.beans.factory.annotation.Required;

import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.GluDeploymentInvoker;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;

/**
 * Returns how long a host as been up using the information in /proc/uptime
 * 
 * @author stephelu
 * 
 */
public class HostUptimeService {

    private EnvironmentBeanFactory<GluDeploymentInvoker> gluAgentClientFactory;

    public Duration getHostUptime(final Environment environment, final String agent) {
        String uptime = gluAgentClientFactory.get(environment).executeShellCommand(agent, "cat /proc/uptime");
        // comes back in the format 2919150.94 2703492.01. First part is seconds since startup, second is load related.
        String[] parts = uptime.split("\\.");

        long uptimeSeconds = Long.parseLong(parts[0]);

        return Duration.standardSeconds(uptimeSeconds);
    }

    @Required
    public void setGluAgentClientFactory(final EnvironmentBeanFactory<GluDeploymentInvoker> gluAgentClientFactory) {
        this.gluAgentClientFactory = gluAgentClientFactory;
    }
}
