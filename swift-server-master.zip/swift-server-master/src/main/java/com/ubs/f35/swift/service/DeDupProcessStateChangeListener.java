package com.ubs.f35.swift.service;

import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.vertx.java.core.impl.ConcurrentHashSet;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.ProcessStateChangeListener;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.executors.SwiftExecutors;

/**
 * Glu creates lots of micro updates to zookeeper as processes change state and monitors are created. Also, some
 * transitions between states occur in a fraction of a second (eg a client artifact can go through all the deployment
 * transitions in less than a second). There is no need to send all of these updates back to client, so this listener
 * buffers events for a short interval and sends back only a single notification for a change to a process within this
 * time.
 * 
 * @author stephelu
 * 
 */
public class DeDupProcessStateChangeListener implements ProcessStateChangeListener {
    private static final Logger LOG = LoggerFactory.getLogger(DeDupProcessStateChangeListener.class);

    private long bufferDelayMillis = 1000L;
    private ProcessStateChangeListener target;

    // The worklog provides quick access to check if a particular notification is already pending. The DelayQueue
    // provides a contains operation, however this is iteration based so does not scale well.
    private final ConcurrentHashSet<Notification> workLog = new ConcurrentHashSet<Notification>();
    private final DelayQueue<DelayedNotification> workQueue = new DelayQueue<DelayedNotification>();
    // A single thread is used to consume notifications and act upon them.
    private final Executor executor = Executors.newSingleThreadExecutor(
            SwiftExecutors.namedThreadFactory("process-change-dedup", true));

    @Required
    public void setTarget(final ProcessStateChangeListener target) {
        this.target = target;
    }

    public void setBufferDelayMillis(final long bufferDelayMillis) {
        this.bufferDelayMillis = bufferDelayMillis;
    }

    public DeDupProcessStateChangeListener() {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    DelayedNotification job = null;
                    try {
                        job = workQueue.take();
                    } catch (InterruptedException e) {
                        LOG.info("I've been interrupted.  Exiting");
                        break;
                    }

                    if (job != null) {
                        Notification notification = job.notification;
                        workLog.remove(notification);
                        try {
                            target.processStateChanged(notification.environment, notification.mountPoint,
                                    notification.removedEntry);
                        }
                        catch (Throwable t) {
                            // Exceptions should not cause processing to terminate.
                            LOG.error("Exception processing notification {}", notification, t);
                        }
                    }
                }
            }
        });
    }

    @Override
    public void processStateChanged(final Environment environment, final String mountPoint, final Entry removedEntry) {
        Notification jobKey = new Notification(environment, mountPoint, removedEntry);
        boolean jobAppended = workLog.add(jobKey);

        if (jobAppended) {
            LOG.trace("Adding job {}", jobKey);
            workQueue.add(new DelayedNotification(jobKey, System.currentTimeMillis() + bufferDelayMillis));
        } else {
            LOG.trace("Skipping job {} as a already in queue", jobKey);
        }
    }

    static class DelayedNotification implements Delayed {
        private final Notification notification;
        private final long executionTime;

        DelayedNotification(final Notification notification, final long executionTime) {
            this.notification = notification;
            this.executionTime = executionTime;
        }

        @Override
        public int compareTo(final Delayed o) {
            return (int) (executionTime - ((DelayedNotification) o).executionTime);
        }

        @Override
        public long getDelay(final TimeUnit unit) {
            long remaining = Math.max(0, executionTime - System.currentTimeMillis());

            return unit.convert(remaining, TimeUnit.MILLISECONDS);
        }
    }

    static class Notification {
        private final Environment environment;
        private final String mountPoint;
        private final Entry removedEntry;

        public Notification(final Environment environment, final String mountPoint, final Entry removedEntry) {
            this.environment = environment;
            this.mountPoint = mountPoint;
            this.removedEntry = removedEntry;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(environment, mountPoint);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof Notification) {
                Notification that = (Notification) object;
                return Objects.equal(environment, that.environment) &&
                        Objects.equal(mountPoint, that.mountPoint) &&
                        Objects.equal(removedEntry, that.removedEntry);
            }
            return false;
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this.getClass())
                    .add("environment", environment)
                    .add("mountPoint", mountPoint)
                    .add("removedEntry", removedEntry).toString();
        }
    }

}
