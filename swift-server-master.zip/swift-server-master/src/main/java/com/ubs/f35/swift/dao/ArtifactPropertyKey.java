package com.ubs.f35.swift.dao;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;
import org.hibernate.annotations.NaturalId;

import com.google.common.base.Objects;

@SequenceGenerator(name = "oracle_seq", sequenceName = "seq_artifact_property_keys_id")
@Entity
@Table(name = "ARTIFACT_PROPERTY_KEYS")
public class ArtifactPropertyKey {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "oracle_seq")
    private Integer id;

    @NaturalId
    @ManyToOne
    @JoinColumn(name = "artifact_id", referencedColumnName = "id")
    private Artifact artifact;

    @NaturalId
    @Column(name = "property_key")
    private String key;

    /**
     * If the properties template has a specified value, this will be used as a default suggestion when configuring for
     * the first time.
     */
    @Column(name = "suggested_value")
    @Lob
    private String suggestedValue;
    /**
     * Any comments stored in the properties template will be used as documentation for configuring that property.
     */
    @Lob
    private String documentation;

    @Column(insertable = false, updatable = false)
    @Generated(GenerationTime.INSERT)
    private Date createdTime;

    public ArtifactPropertyKey() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public Artifact getArtifact() {
        return artifact;
    }

    public void setArtifact(final Artifact artifact) {
        this.artifact = artifact;
    }

    public String getKey() {
        return key;
    }

    public void setKey(final String key) {
        this.key = key;
    }

    public String getSuggestedValue() {
        return suggestedValue;
    }

    public void setSuggestedValue(final String suggestedValue) {
        this.suggestedValue = suggestedValue;
    }

    public String getDocumentation() {
        return documentation;
    }

    public void setDocumentation(final String documentation) {
        this.documentation = documentation;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(final Date createdTime) {
        this.createdTime = createdTime;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, artifact, key, createdTime);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ArtifactPropertyKey) {
            ArtifactPropertyKey that = (ArtifactPropertyKey) object;
            return Objects.equal(this.id, that.id)
                    && Objects.equal(this.artifact, that.artifact)
                    && Objects.equal(this.key, that.key)
                    && Objects.equal(this.suggestedValue, that.suggestedValue)
                    && Objects.equal(this.documentation, that.documentation)
                    && Objects.equal(this.createdTime, that.createdTime);
        }
        return false;
    }
}
