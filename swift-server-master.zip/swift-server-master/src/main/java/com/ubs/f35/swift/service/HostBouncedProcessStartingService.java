package com.ubs.f35.swift.service;

import java.util.Date;
import java.util.List;

import org.apache.curator.framework.recipes.leader.LeaderLatch;
import org.apache.curator.framework.recipes.leader.LeaderLatchListener;
import org.joda.time.Duration;
import org.joda.time.Interval;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionOperations;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.ResourceAccessException;

import com.google.common.collect.Lists;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;
import com.ubs.f35.swift.dao.HostDao;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.DeploymentExecutor;
import com.ubs.f35.swift.deploy.glu.DeploymentListener;
import com.ubs.f35.swift.deploy.glu.action.Action;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlanStrategy;
import com.ubs.f35.swift.deploy.glu.plan.GluDeploymentPlanGenerator;
import com.ubs.f35.swift.deploy.glu.rest.AgentStateChangeListener;
import com.ubs.f35.swift.deploy.glu.rest.ProcessDetails;
import com.ubs.f35.swift.deploy.glu.rest.ProcessDetailsProvider;
import com.ubs.f35.swift.deploy.glu.state.GluState;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.executors.RetryExecutor;
import com.ubs.f35.swift.executors.RetryableException;
import com.ubs.f35.swift.security.UserConstants;
import com.ubs.f35.swift.state.OperationContextProvider;

/**
 * Responsible for restarting processes after a host is bounced. This service listens for notifications of agents coming
 * back up from the {@link AgentStateChangeListener}. Note that the indication that the agent has come alive does not
 * necessarily mean that the host was restarted, it could just be that the agent was restarted or upgraded. Swift uses
 * the command invocation framework to execute 'uptime' to see if the host was really restarted.
 * <p>
 * As multiple instances of swift-server could be running, only one should take responsibility for restarting services
 * on the host which restarted.
 * <p>
 * A short summary of the process flow
 * <ul>
 * <li>Swift-server notices an agent has come back up
 * <li>Swift-server only attempts to restart the process if it is the owner of the {@link LeaderLatch}
 * <li>Swift server checks the host really has been restarted recently.
 * <li>Swift-server generates a deployment plan for all the artifacts on the host which are in a stopped state
 * <li>Swift-server executes the deployment plan and persists the results of the executed deployment to oracle (just
 * like any user initiated deployment, except the user is 'swift')
 * </ul>
 * 
 * @author stephelu
 * 
 */
public class HostBouncedProcessStartingService implements AgentStateChangeListener, InitializingBean {
    private static final Logger LOG = LoggerFactory.getLogger(HostBouncedProcessStartingService.class);

    // Maximum of 1 auto restart per host per day to avoid a restart crash loop.
    private static final Duration MAX_RESTART_INTERVAL = Duration.standardDays(1);
    // Only restart the host if it has come up recently
    private static final Duration MAX_UPTIME_FOR_RESTART = Duration.standardMinutes(30);

    private EnvironmentDocumentStore environmentDocumentStore;
    private EnvironmentBeanFactory<Boolean> autoRestartEnabledFactory;
    private GluDeploymentPlanGenerator deploymentPlanGenerator;
    private DeploymentExecutor deploymentExecutor;
    private OperationContextProvider opContextProvider;
    private EnvironmentBeanFactory<ProcessDetailsProvider> processDetailsProviderFactory;
    private HostDao hostDao;
    private HostUptimeService hostUptimeService;
    private TransactionOperations transactionTemplate;
    private RetryExecutor retryExecutor;
    private LeaderLatch swiftRestartLeaderLatch;

    @Override
    public void agentStateChanged(final Environment environment, final String agent, final boolean alive) {
        boolean lockOwner = swiftRestartLeaderLatch.hasLeadership();
        if (alive && lockOwner && autoRestartEnabledFactory.get(environment)) {
            // Execute the restart logic in the background so that zookeeper doesn't block on sending through any
            // further notifications.
            retryExecutor.execute(new WaitForAgentRestartJob(environment, agent));
        } else {
            LOG.debug(
                    "Agent {} changed state but not restarting stopped processes because alive [{}] or lockOwner [{}] or autoRestartEnabled [{}]",
                    new Object[] { agent, alive, lockOwner, autoRestartEnabledFactory.get(environment) });
        }
    }

    /**
     * The agent alive notification from zookeeper comes before the agent is usable. It may take several attempts before
     * the agents has registered the REST endpoints though.
     * <p>
     * TODO This is fixed in glu agent 5.2.0 so logic can be removed once all agents are upgraded.
     */
    private class WaitForAgentRestartJob implements Runnable {
        final Environment environment;
        final String agent;

        public WaitForAgentRestartJob(final Environment environment, final String agent) {
            this.environment = environment;
            this.agent = agent;
        }

        @Override
        public void run() {
            LOG.info("Attempting to call agent {}", agent);

            Duration hostUptime = null;
            try {
                hostUptime = hostUptimeService.getHostUptime(environment, agent);
            } catch (ResourceAccessException ex) {
                throw new RetryableException(ex);
            }

            handleAgentRestarted(environment, agent, hostUptime);
        }

    }

    private void handleAgentRestarted(final Environment environment, final String agent, final Duration hostUptime) {
        if (hostUptime.isShorterThan(MAX_UPTIME_FOR_RESTART)) {
            try {
                opContextProvider.setCurrentUser(UserConstants.SWIFT_PRINCIPAL);
                startStoppedProcessesOnAgent(environment, agent);
            } finally {
                opContextProvider.reset();
            }
        } else {
            // Skip the restart if the host has been up for an extended period of time. In this situation the host
            // has likely been temporarily showing as down because it is under too much load and not responsive.
            // Starting additional processes in this case would potentially conflict with someone manually trying to
            // shutdown processes to resolve the situation, or worse, cause the host to crash with the additional
            // load.
            LOG.debug("Skipping restart as host {} has been up for {} minutes", agent,
                    hostUptime.getStandardMinutes());
        }
    }

    private void startStoppedProcessesOnAgent(final Environment environment, final String agent) {
        LOG.info("Detected {} agent {} has come back up.  Looking for processes to restart.", environment, agent);

        List<Entry> entries = environmentDocumentStore.filterByAgent(environment, agent);

        List<String> mountPointsToStart = Lists.newArrayListWithExpectedSize(entries.size());

        for (Entry entry : entries) {
            ProcessDetails processDetails = processDetailsProviderFactory.get(environment)
                    .getCurrentProcessState(entry);

            // Swift should only start processes which are in a stopped state. In addition to this, swift should not
            // restart processes which were explicitly stopped by a user. To detect if a process was stopped by a user,
            // we can see if the statemachine has an error. If it was stopped by the user, then the statemachine will
            // not have an error set. If the process crashed, the glu script for that process should have set an error
            // describing what was wrong.
            if (processDetails.getGluState() == GluState.stopped && processDetails.isStateMachineInError()) {
                mountPointsToStart.add(entry.getMountPoint());
            }
        }

        LOG.info("Agent {} has {} mounts of which {} need restarting", new Object[] { agent, entries.size(),
                mountPointsToStart.size() });

        if (!CollectionUtils.isEmpty(mountPointsToStart)) {
            restartMountPointsInTransaction(environment, agent, mountPointsToStart);
        }
    }

    private void restartMountPointsInTransaction(final Environment environment, final String agent,
            final List<String> mountPointsToStart) {
        transactionTemplate.execute(new TransactionCallback<Void>() {
            @Override
            public Void doInTransaction(final TransactionStatus status) {
                restartMountPoints(environment, agent, mountPointsToStart);
                return null;
            }
        });
    }

    private void restartMountPoints(final Environment environment, final String agent,
            final List<String> mountPointsToStart) {
        Host host = hostDao.loadExpected(agent);
        if (host.getLastAutoRestartTime() != null) {
            Duration timeSinceLastAutoRestart = new Interval(host.getLastAutoRestartTime().getTime(),
                    System.currentTimeMillis()).toDuration();
            if (timeSinceLastAutoRestart.isShorterThan(MAX_RESTART_INTERVAL)) {
                LOG.info("Not automatically restarting processes on {} as last restart was {}", agent,
                        host.getLastAutoRestartTime());
                return;
            }
        }

        Deployment deployment = deploymentPlanGenerator.generateAdhocDeploymentPlan(mountPointsToStart,
                DeploymentAction.StartOnly, environment, DeploymentPlanStrategy.NO_DEPS);

        if (!deployment.getDeploymentPlan().getActions().isEmpty()) {
            // Execute the deployment. No need to handle any notifications about the deployment
            deploymentExecutor.executeDeployment(deployment, new DeploymentListener() {
                @Override
                public void deploymentComplete(final DeploymentStatus status) {
                    LOG.info("Host restart deployment completed {} : {}", agent, status);
                }

                @Override
                public void deploymentActionChanged(final Action action) {
                    LOG.info("Host restart update {} : {}", agent, action);
                }
            });

            host.setLastAutoRestartTime(new Date());
        }
    }

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

    @Required
    public void setAutoRestartEnabledFactory(final EnvironmentBeanFactory<Boolean> autoRestartEnabledFactory) {
        this.autoRestartEnabledFactory = autoRestartEnabledFactory;
    }

    @Required
    public void setDeploymentPlanGenerator(final GluDeploymentPlanGenerator deploymentPlanGenerator) {
        this.deploymentPlanGenerator = deploymentPlanGenerator;
    }

    @Required
    public void setDeploymentExecutor(final DeploymentExecutor deploymentExecutor) {
        this.deploymentExecutor = deploymentExecutor;
    }

    @Required
    public void setOpContextProvider(final OperationContextProvider opContextProvider) {
        this.opContextProvider = opContextProvider;
    }

    @Required
    public void setProcessDetailsProviderFactory(
            final EnvironmentBeanFactory<ProcessDetailsProvider> processDetailsProviderFactory) {
        this.processDetailsProviderFactory = processDetailsProviderFactory;
    }

    @Required
    public void setHostDao(final HostDao hostDao) {
        this.hostDao = hostDao;
    }

    @Required
    public void setHostUptimeService(final HostUptimeService hostUptimeService) {
        this.hostUptimeService = hostUptimeService;
    }

    @Required
    public void setTransactionTemplate(final TransactionOperations transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }

    @Required
    public void setRetryExecutor(final RetryExecutor retryExecutor) {
        this.retryExecutor = retryExecutor;
    }

    @Required
    public void setSwiftRestartLeaderLatch(final LeaderLatch swiftRestartLeaderLatch) {
        this.swiftRestartLeaderLatch = swiftRestartLeaderLatch;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        swiftRestartLeaderLatch.addListener(new LeaderLatchListener() {
            @Override
            public void notLeader() {
                LOG.info("Instance is NOT the leader");
            }

            @Override
            public void isLeader() {
                LOG.info("Instance is the leader");
            }
        });
    }
}
