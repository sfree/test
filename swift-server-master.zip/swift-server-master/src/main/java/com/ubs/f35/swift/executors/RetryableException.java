package com.ubs.f35.swift.executors;


/**
 * Thrown to highlight to the {@link RetryExecutor} that an operation should be retried.
 * 
 * @author stephelu
 * 
 */
public class RetryableException extends RuntimeException {

    public RetryableException(final Throwable ex) {
        super(ex);
    }

}