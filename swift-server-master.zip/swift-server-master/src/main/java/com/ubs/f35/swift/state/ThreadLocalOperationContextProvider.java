package com.ubs.f35.swift.state;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.util.StringUtils;

import com.ubs.f35.core.AuthenticationPrincipal;

public class ThreadLocalOperationContextProvider implements OperationContextProvider {
    private static final Logger LOG = LoggerFactory.getLogger(ThreadLocalOperationContextProvider.class);

    private static final ThreadLocalOperationContextProvider INSTANCE = new ThreadLocalOperationContextProvider();

    private final ThreadLocal<AuthenticationPrincipal> principalLocal = new ThreadLocal<AuthenticationPrincipal>();

    private ThreadLocalOperationContextProvider() {
    }

    public static ThreadLocalOperationContextProvider getInstance() {
        return INSTANCE;
    }

    @Override
    public String getCurrentUser() {
        return getCurrentPrincipal().getUserName();
    }

    @Override
    public void setCurrentUser(final AuthenticationPrincipal principal) {
        principalLocal.set(principal);

        // preference for login 'stephelu' over guid 'PSI43334782'
        String user = principal.getName();
        if (!StringUtils.hasText(user)) {
            user = principal.getUserName();
        }
        MDC.put("f35.user.name", user);
        LOG.info("Context executing as user {}", user);
    }

    @Override
    public void reset() {
        principalLocal.set(null);
        MDC.remove("f35.user.name");
    }

    @Override
    public AuthenticationPrincipal getCurrentPrincipal() {
        return principalLocal.get();
    }
}
