package com.ubs.f35.swift.model;

public class JsonMarshallingException extends RuntimeException {

    public JsonMarshallingException(final Throwable throwable) {
        super("Unable to marshall JSON data", throwable);
    }

    public JsonMarshallingException(final Class<?> c, final Throwable throwable) {
        super("Unable to marshall JSON data from class " + c.getName(), throwable);
    }

    public JsonMarshallingException(final String message, final Throwable throwable) {
        super(message, throwable);
    }

}
