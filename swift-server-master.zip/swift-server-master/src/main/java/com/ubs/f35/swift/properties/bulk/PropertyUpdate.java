package com.ubs.f35.swift.properties.bulk;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.springframework.util.StringUtils;

public class PropertyUpdate {
    private final String key;
    private final String value;
    private final boolean saveBlank;

    @JsonCreator
    public PropertyUpdate(@JsonProperty("key") final String key,
            @JsonProperty("value") final String value,
            @JsonProperty("saveBlank") final boolean saveBlank) {
        this.key = key;
        this.value = value;
        this.saveBlank = saveBlank;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public boolean isSaveBlank() {
        return saveBlank;
    }

    /**
     * In an update request, blank properties which are flagged as blank will be saved. Otherwise if the property value
     * is empty it will be removed.
     */
    @JsonIgnore
    public boolean isRemoved() {
        return !(StringUtils.hasText(value) || saveBlank);
    }
}