package com.ubs.f35.swift.model;

import java.util.List;

import com.google.common.base.Objects;

/**
 * Represents the filters the client may pass in to restrict the view of visible artifacts.
 * 
 * @author stephelu
 * 
 */
public class StatusFilter extends EntryFilter {

    private String organisation;
    private List<String> environments;
    private List<String> states;
    private List<String> statuses;

    public StatusFilter() {

    }

    public StatusFilter(final String organisation, final List<String> environments, final List<String> groups,
            final List<String> artifacts,
            final List<String> agents, final List<String> tags, final List<String> states, final List<String> statuses) {
        super(groups, artifacts, agents, tags);
        this.organisation = organisation;
        this.environments = environments;
        this.states = states;
        this.statuses = statuses;
    }

    public String getOrganisation() {
        return organisation;
    }

    public void setOrganisation(final String organisation) {
        this.organisation = organisation;
    }

    public final List<String> getEnvironments() {
        return environments;
    }

    public final void setEnvironments(final List<String> environments) {
        this.environments = environments;
    }

    public final List<String> getStates() {
        return states;
    }

    public final void setStates(final List<String> states) {
        this.states = states;
    }

    public final List<String> getStatuses() {
        return statuses;
    }

    public final void setStatuses(final List<String> statuses) {
        this.statuses = statuses;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(super.hashCode(), organisation, environments, states, statuses);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof StatusFilter) {
            if (!super.equals(object)) {
                return false;
            }
            StatusFilter that = (StatusFilter) object;
            return Objects.equal(this.organisation, that.organisation)
                    && Objects.equal(this.environments, that.environments)
                    && Objects.equal(this.states, that.states)
                    && Objects.equal(this.statuses, that.statuses);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("super", super.toString())
                .add("organisation", organisation)
                .add("environments", environments)
                .add("states", states)
                .add("statuses", statuses)
                .toString();
    }

}
