package com.ubs.f35.swift.dao;

import java.util.List;

import com.google.common.collect.Multimap;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.SwiftGroup;
import com.ubs.f35.swift.security.Permission;

public interface SwiftGroupDao {

    SwiftGroup save(SwiftGroup group);

    SwiftGroup loadGroup(String groupName);

    Multimap<String, String> findGroupsByHost(Environment environment, List<String> hostNames, Permission permission);

    Multimap<String, String> findGroupsByHost(List<Environment> environments, List<String> hosts,
            List<String> permissions);

    Multimap<NexusArtifact, String> findGroupsByArtifact(Environment environment, List<NexusArtifact> artifacts,
            Permission permission);

    Multimap<NexusArtifact, String> findGroupsByArtifact(List<Environment> environments, List<NexusArtifact> artifacts,
            List<String> permissions);

}
