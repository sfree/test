package com.ubs.f35.swift.processor;

import java.io.IOException;
import java.security.AccessControlException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpClientErrorException;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.GluDeploymentInvoker;
import com.ubs.f35.swift.deploy.glu.rest.GluProcessManager;
import com.ubs.f35.swift.deploy.glu.rest.NoSuchMountPointException;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.security.Permission;
import com.ubs.f35.swift.service.ArtifactConfigurationService;
import com.ubs.f35.swift.service.ArtifactConfigurationService.EnvironmentEntryPair;

@Controller
@RequestMapping(value = "/api/logs")
// Because of entitlement lookups.
@Transactional(readOnly = true)
public class LogsProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(LogsProcessor.class);

    private static final String DEFAULT_LOG_MAX_LINES = "500";
    private static final List<String> BINARY_LOG_FILE_EXTENSIONS = Arrays.asList(".gz", ".tar", ".zip", ".bz2");

    private EnvironmentBeanFactory<GluProcessManager> gluProcessManagerFactory;
    private EnvironmentBeanFactory<GluDeploymentInvoker> gluAgentClientFactory;
    private AuthorisationController authorisationController;
    private ArtifactConfigurationService artifactConfigurationService;

    @RequestMapping(value = "/{organisation}/{environment}/{agent}/dir", method = RequestMethod.GET)
    @ResponseBody
    public Map getAgentLogDirectory(@PathVariable final String organisation, @PathVariable final String environment,
            @PathVariable final String agent) {
        Environment env = new Environment(environment, organisation);

        authorisationController.checkAccess(env, agent, Permission.ViewLogs);

        Map<String, String> agentDetails = gluProcessManagerFactory.get(env).getAgentDetails(agent);

        String logDir = agentDetails.get("glu.agent.logDir");
        if (logDir == null) {
            return Collections.emptyMap();
        }
        return gluAgentClientFactory.get(env).getLogDirectoryContents(agent, logDir);

    }

    @RequestMapping(value = "/{organisation}/{environment}/{agent}/file", method = RequestMethod.GET)
    public void getAgentLogFile(@PathVariable final String organisation, @PathVariable final String environment,
            @PathVariable final String agent,
            @RequestParam(value = "logFile") final String logFile,
            @RequestParam(value = "maxLine", defaultValue = DEFAULT_LOG_MAX_LINES) final int maxLine,
            final HttpServletResponse response) throws IOException {
        Environment env = new Environment(environment, organisation);

        Map dirListing = getAgentLogDirectory(organisation, environment, agent);

        getLogFile(logFile, maxLine, response, env, agent, dirListing);
    }

    @RequestMapping(value = "/dir", method = RequestMethod.GET)
    @ResponseBody
    public Map getLogDirectory(@RequestParam(value = "id") final String id) {
        EnvironmentEntryPair resolvedDetails = artifactConfigurationService.resolveArtifactInstanceId(id);
        Environment environment = resolvedDetails.getEnvironment();
        Entry entry = resolvedDetails.getEntry();

        checkAccessToLogs(environment, entry);

        try {

            String logDir = gluProcessManagerFactory.get(environment).getLogDirectory(entry.getAgent(),
                    entry.getMountPoint());

            if (logDir == null) {
                return Collections.emptyMap();
            }
            return gluAgentClientFactory.get(environment).getLogDirectoryContents(entry.getAgent(), logDir);

        } catch (NoSuchMountPointException ex) {
            return Collections.emptyMap();
        } catch (HttpClientErrorException ex) {
            if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                // If the log directory does not exist, agent returns a 404.
                LOG.info("Unable to retrieve agent logs: " + ex.getMessage());
                return Collections.emptyMap();
            }
            throw ex;
        }
    }

    @RequestMapping(value = "/file", method = RequestMethod.GET)
    public void getLogFile(@RequestParam(value = "id") final String id,
            @RequestParam(value = "logFile") final String logFile,
            @RequestParam(value = "maxLine", defaultValue = DEFAULT_LOG_MAX_LINES) final int maxLine,
            final HttpServletResponse response) throws IOException {
        EnvironmentEntryPair resolvedDetails = artifactConfigurationService.resolveArtifactInstanceId(id);
        Environment environment = resolvedDetails.getEnvironment();
        Entry entry = resolvedDetails.getEntry();

        Map dirListing = getLogDirectory(id);

        getLogFile(logFile, maxLine, response, environment, entry.getAgent(), dirListing);
    }

    /**
     * Gets a log file from a list of available log files for the directory.
     */
    private void getLogFile(final String logFile, int maxLine, final HttpServletResponse response,
            final Environment environment, final String agent,
            final Map<String, Map<String, Map<String, Object>>> dirListing) throws IOException {
        // In addition to verifying access to the logs for the entry, verify that the requested log file is appropriate
        // for the entry and that the path has not been modified to retrieve any resource.

        boolean validLog = Iterables.any(dirListing.get("res").values(), new Predicate<Map<String, Object>>() {
            @Override
            public boolean apply(final Map<String, Object> input) {
                return logFile.equals(input.get("canonicalPath"));
            }
        });

        if (!validLog) {
            throw new AccessControlException("Access denied to specified file");
        }

        if (isBinaryLogFile(logFile)) {
            maxLine = -1;
            // binary files will be downloaded by the browser. Suggest a nice file name for the download.
            String fileName = agent + "-" + FilenameUtils.getName(logFile);
            response.addHeader("Content-Disposition", "inline; filename=\"" + fileName + "\"");
        }

        gluAgentClientFactory.get(environment).getLogFileContents(agent, logFile, maxLine, response.getOutputStream());
    }

    /**
     * Binary log files like compressed historical backups should be returned in their complete form. While the last 500
     * lines of a text file can be displayed, the last 500 lines of a gzip is not a valid file.
     */
    private boolean isBinaryLogFile(final String logFile) {
        return Iterables.any(BINARY_LOG_FILE_EXTENSIONS, new Predicate<String>() {
            @Override
            public boolean apply(final String extension) {
                return logFile.endsWith(extension);
            }
        });
    }

    private void checkAccessToLogs(final Environment environment, final Entry entry) {
        NexusArtifact artifact = new NexusArtifact(entry.getGroupId(), entry.getArtifactId());
        authorisationController.checkAccess(environment, entry.getAgent(), artifact, Permission.ViewLogs);
    }

    /**
     * Log calls are entitled for now as the glu agent will serve any file (not just logs). Also production logs may
     * have CID or other sensitive information so this needs to be considered carefully before removing these auth
     * checks
     * 
     * @param authorisationController
     */
    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

    @Required
    public void setGluProcessManagerFactory(final EnvironmentBeanFactory<GluProcessManager> gluProcessManagerFactory) {
        this.gluProcessManagerFactory = gluProcessManagerFactory;
    }

    @Required
    public void setGluAgentClientFactory(final EnvironmentBeanFactory<GluDeploymentInvoker> gluAgentClientFactory) {
        this.gluAgentClientFactory = gluAgentClientFactory;
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }
}
