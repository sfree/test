package com.ubs.f35.swift.dao.hibernate;

import static com.google.common.collect.ImmutableMap.of;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.hibernate.Query;
import org.springframework.util.StringUtils;

import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.NexusArtifactDao;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.PagingResult;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.hibernate.framework.PagingQueryBuilder;

public class HibernateNexusArtifactDao extends HibernateDaoSupport implements NexusArtifactDao {
    @Override
    public List<String> getGroups(final String group, final String artifact) {
        if (StringUtils.hasText(artifact)) {
            return query(
                    "select distinct groupId from NexusArtifact where groupId like :groupId and artifactId = :artifactId order by groupId",
                    of("groupId", contains(group), "artifactId", artifact));
        } else {
            return query("select distinct groupId from NexusArtifact where groupId like :groupId order by groupId",
                    of("groupId", contains(group)));
        }
    }

    @Override
    public List<NexusArtifact> loadAll() {
        return query("from NexusArtifact", Collections.<String, String>emptyMap());
    }

    @Override
    public List<String> getArtifacts(final String organisation, final String group, final String artifact) {
        Map<String, String> params = of("org", organisation, "groupId", group, "artifactId", contains(artifact));
        return query(
                "select distinct a.artifactId from NexusArtifact a join a.organisations o "
                        + "where a.groupId = :groupId and a.artifactId like :artifactId "
                        + "and o.name = :org "
                        + "order by a.artifactId",
                params);
    }

    @Override
    public List<NexusArtifact> getArtifacts(final String organisation, final String artifact) {
        Map<String, String> params = of("org", organisation, "artifactId", contains(artifact));
        return query("select distinct a from NexusArtifact a join a.organisations o "
                + "where a.artifactId like :artifactId "
                + "and o.name = :org "
                + "order by a.artifactId, a.groupId", params);
    }

    @Override
    public PagingResult<NexusArtifact> getArtifacts(final String organisation, final String artifact,
            final PagingFilter pagingFilter) {

        return executeQueryWithPaging(pagingFilter, NexusArtifact.class, new PagingQueryBuilder() {

            @Override
            public String getQuery() {
                return "select a "
                        + getCountQuery()
                        + "order by a.artifactId, a.groupId";
            }

            @Override
            public String getCountQuery() {
                return "from NexusArtifact a join a.organisations o "
                        + "where lower(a.artifactId) like :artifactId and o.name = :org ";
            }

            @Override
            public void bindArguments(final Query query) {
                query.setString("org", organisation);
                query.setString("artifactId", contains(artifact.toLowerCase()));
            }
        });

    }

    @SuppressWarnings("unchecked")
    private <T> List<T> query(final String queryStr, final Map<String, String> args) {
        Query query = getSession().createQuery(
                queryStr);
        for (Entry<String, String> arg : args.entrySet()) {
            query.setString(arg.getKey(), arg.getValue());
        }
        return query.list();
    }

    @Override
    public void create(final NexusArtifact artifact) {
        getSession().save(artifact);
    }

    @Override
    public void createIfNotExists(final NexusArtifact artifact) {
        // TODO this would benefit from hibernate caching.
        NexusArtifact existing = load(artifact);

        if (existing == null) {
            create(artifact);
        }
    }

    @Override
    public NexusArtifact load(final NexusArtifact artifact) {
        return load(NexusArtifact.class, artifact);
    }

}
