package com.ubs.f35.swift.security;
import java.io.IOException;
import java.util.StringTokenizer;

import javax.management.JMException;
import javax.management.MBeanServer;
import javax.xml.parsers.DocumentBuilder;

import mx4j.tools.adaptor.http.HttpInputStream;
import mx4j.tools.adaptor.http.InvokeOperationCommandProcessor;
import mx4j.util.Base64Codec;

import org.springframework.beans.factory.annotation.Required;
import org.w3c.dom.Document;

import com.ubs.f35.common.transport.transformer.TransportPrincipal;
import com.ubs.f35.jmx.MX4JInvokeOperationCommandProcessor;
import com.ubs.f35.sso.auth.UserDnFinder;
import com.ubs.f35.swift.state.OperationContextProvider;

public class SwiftJmxOperationCommandProcessor extends InvokeOperationCommandProcessor {
    private static final String AUTH_METHOD = "Basic";

    private UserDnFinder userDnFinder;
    private OperationContextProvider opContextProvider;
    private InvokeOperationCommandProcessor invokeOperationCommandProcessor = new MX4JInvokeOperationCommandProcessor();

    @Override
    public Document executeRequest(final HttpInputStream in) throws IOException, JMException {
        String authorizationString = in.getHeader("authorization");

        if (authorizationString != null && authorizationString.startsWith(AUTH_METHOD)) {
            authorizationString = authorizationString.substring(AUTH_METHOD.length(), authorizationString.length());
            String decodeString = new String(Base64Codec.decodeBase64(authorizationString.getBytes()));
            StringTokenizer tokens = new StringTokenizer(decodeString, ":");
            String username = tokens.nextToken();

            // userDnFinder does almost what we want, except it returns "ubswguid=PSI43334782,o=staff,dc=ubsw,dc=com"
            String userDn = userDnFinder.getUserDn(username);
            String userGuid = userDn.split(",")[0].split("=")[1];

            TransportPrincipal principal = new TransportPrincipal();
            principal.setUserName(userGuid);

            opContextProvider.setCurrentUser(principal);
        }
        try {
            return invokeOperationCommandProcessor.executeRequest(in);
        } finally {
            opContextProvider.reset();
        }
    }

    @Override
    public void setDocumentBuilder(final DocumentBuilder builder) {
        super.setDocumentBuilder(builder);
        invokeOperationCommandProcessor.setDocumentBuilder(builder);
    }

    @Override
    public void setMBeanServer(final MBeanServer server) {
        super.setMBeanServer(server);
        invokeOperationCommandProcessor.setMBeanServer(server);
    }

    @Required
    public void setOpContextProvider(final OperationContextProvider opContextProvider) {
        this.opContextProvider = opContextProvider;
    }

    @Required
    public void setUserDnFinder(final UserDnFinder userDnFinder) {
        this.userDnFinder = userDnFinder;
    }

    public void setInvokeOperationCommandProcessor(final InvokeOperationCommandProcessor invokeOperationCommandProcessor) {
        this.invokeOperationCommandProcessor = invokeOperationCommandProcessor;
    }
}
