package com.ubs.f35.swift.dao;

import java.util.List;

import com.ubs.f35.swift.config.model.Tag;

public interface TagDao {

    List<Tag> loadAll(String organisation);

}
