package com.ubs.f35.swift.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Required;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;
import com.ubs.f35.swift.artifact.ArtifactResolver;
import com.ubs.f35.swift.artifact.NexusInstanceSpecific;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ArtifactConfigurationDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.NexusArtifactDao;
import com.ubs.f35.swift.dao.OrganisationDao;
import com.ubs.f35.swift.dao.model.Organisation;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.properties.NexusURLBuilder;

/**
 * Returns details of the artifacts available to be added to a release.
 * 
 * @author stephelu
 * 
 */
public class NexusArtifactService {

    private OrganisationBeanFactory<ArtifactResolver> artifactResolverFactory;
    private NexusArtifactDao nexusArtifactDao;
    private OrganisationDao organisationDao;
    private ArtifactConfigurationDao artifactConfigurationDao;

    private Map<String, ArtifactResolver> nexusInstanceMap;
    private Map<String, NexusURLBuilder> nexusBuilderInstanceMap;

    /**
     * Registers an artifact if it exists in Nexus. If the artifact is created (or exists already), it will be mapped to
     * the organisation.
     * 
     * @return
     */
    public NexusArtifact registerArtifact(final String organisation, final NexusArtifact artifact) {
        NexusArtifact persistent = registerArtifactIfExists(organisation, artifact);
        if (persistent != null) {
            Organisation orgModel = organisationDao.load(organisation);

            if (persistent.getOrganisations() == null) {
                persistent.setOrganisations(new ArrayList<Organisation>());
            }
            if (!persistent.getOrganisations().contains(orgModel)) {
                persistent.getOrganisations().add(orgModel);
            }
        }
        return persistent;
    }

    /**
     * Registers an artifact if it exists in Nexus. If registered or existing, returns the persistent artifact
     */
    // TODO private
    protected NexusArtifact registerArtifactIfExists(final String organisation, final NexusArtifact artifact) {
        NexusArtifact existing = nexusArtifactDao.load(artifact);
        if (existing == null) {
            ArtifactResolver artifactResolver = artifactResolverFactory.get(organisation);
            List<String> versions = artifactResolver
                    .getVersions(artifact.getGroupId(), artifact.getArtifactId(), true);

            // Only register the artifact if found in Nexus.
            if (!versions.isEmpty()) {
                // Set which nexus instance this artifact was sourced from.
                artifact.setNexusInstance(artifactResolver.getResolverId());

                nexusArtifactDao.create(artifact);
                return artifact;
            }
        }
        return existing;
    }

    /**
     * Retrieves a list of all versions for a given artifact from Nexus.
     */
    public List<String> getVersionsForArtifact(final NexusArtifact artifact, final boolean showSnapshotsLast) {
        return getArtifactResolverForArtifact(artifact)
                .getVersions(artifact.getGroupId(), artifact.getArtifactId(), showSnapshotsLast);
    }

    public void validateArtifactVersion(final Artifact artifact) {
        getArtifactResolverForArtifact(artifact.getNexusArtifact()).validateArtifact(artifact);
    }

    public void validateArtifact(final NexusArtifact artifact) {
        if (nexusArtifactDao.load(artifact) == null) {
            throw new RuntimeException("Artifact not registered in swift.");
        }
    }

    public List<String> getSnapshotVersions(final String groupId, final String artifactId) {
        return getArtifactResolverForArtifact(new NexusArtifact(groupId, artifactId)).getSnapshotVersions(groupId,
                artifactId);
    }

    public NexusURLBuilder getNexusUrlBuilderForArtifact(final NexusArtifact artifact) {
        return getResolverForArtifact(artifact, nexusBuilderInstanceMap);
    }

    private ArtifactResolver getArtifactResolverForArtifact(final NexusArtifact artifact) {
        return getResolverForArtifact(artifact, nexusInstanceMap);
    }

    private <K> K getResolverForArtifact(NexusArtifact artifact, final Map<String, K> resolverMap) {
        if (artifact.getNexusInstance() == null) {
            artifact = nexusArtifactDao.load(artifact);
        }
        K artifactResolver = resolverMap.get(artifact.getNexusInstance());
        if (artifactResolver == null) {
            throw new IllegalStateException("No artifact resolver for nexus instance '" + artifact.getNexusInstance()
                    + "'");
        }
        return artifactResolver;
    }

    /**
     * Removes an artifact from the organisation (so that it does not show in the search results for that organisation)
     * only if it is not configured for deployment in any environment of that organisation.
     * 
     * @param organisation
     * @param group
     * @param artifact
     */
    public void deregisterArtifact(final String organisation, final NexusArtifact artifact) {
        NexusArtifact existing = nexusArtifactDao.load(artifact);
        if (existing == null) {
            throw new IllegalArgumentException("No artifact " + artifact);
        }

        List<ArtifactConfig> artifactConfigs = artifactConfigurationDao.load(artifact.getGroupId(),
                artifact.getArtifactId());

        for (ArtifactConfig configured : artifactConfigs) {
            if (configured.getEnvironment().getOrganisation().getName().equals(organisation)) {
                throw new IllegalArgumentException("Cannot delete as configuration still exists for environment "
                        + configured.getEnvironment().getName());
            }
        }

        Iterables.removeIf(existing.getOrganisations(), new Predicate<Organisation>() {
            @Override
            public boolean apply(final Organisation input) {
                return input.getName().equals(organisation);
            }
        });
    }

    private static <K extends NexusInstanceSpecific> Map<String, K> buildNexusInstanceMap(
            final OrganisationBeanFactory<K> resolverFactory) {
        Map<String, K> map = Maps.newHashMap();

        for (K resolver : resolverFactory.getAll().values()) {
            map.put(resolver.getResolverId(), resolver);
        }
        return map;
    }

    @Required
    public void setArtifactResolverFactory(final OrganisationBeanFactory<ArtifactResolver> artifactResolverFactory) {
        this.artifactResolverFactory = artifactResolverFactory;

        artifactResolverFactory.registerUpdateListener(new Runnable() {
            @Override
            public void run() {
                NexusArtifactService.this.nexusInstanceMap = buildNexusInstanceMap(artifactResolverFactory);
            }
        });
    }

    @Required
    public void setNexusURLBuilderFactory(final OrganisationBeanFactory<NexusURLBuilder> nexusURLBuilderFactory) {
        nexusURLBuilderFactory.registerUpdateListener(new Runnable() {
            @Override
            public void run() {
                NexusArtifactService.this.nexusBuilderInstanceMap = buildNexusInstanceMap(nexusURLBuilderFactory);
            }
        });
    }

    @Required
    public void setNexusArtifactDao(final NexusArtifactDao nexusArtifactDao) {
        this.nexusArtifactDao = nexusArtifactDao;
    }

    @Required
    public void setOrganisationDao(final OrganisationDao organisationDao) {
        this.organisationDao = organisationDao;
    }

    @Required
    public void setArtifactConfigurationDao(final ArtifactConfigurationDao artifactConfigurationDao) {
        this.artifactConfigurationDao = artifactConfigurationDao;
    }

}
