package com.ubs.f35.swift.environment.model;

import java.util.Map;

import org.codehaus.jackson.annotate.JsonAnyGetter;
import org.codehaus.jackson.annotate.JsonAnySetter;

import com.google.common.base.Objects;
import com.google.common.collect.Maps;

/**
 * Base class for Json deserialisation which supports having a model which the swift release tools understand, plus
 * support for additional content which the tool does not understand, but doesn't lose between versions.
 * 
 * @author stephelu
 * 
 */
public abstract class JsonModel {
    private final Map<String, Object> unknownProps = Maps.newHashMap();

    @JsonAnySetter
    public void handleUnkowns(final String k, final Object v)
    {
        unknownProps.put(k, v);
    }

    @JsonAnyGetter
    public Map<String, Object> getUnknowns() {
        return unknownProps;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(unknownProps);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof JsonModel) {
            JsonModel that = (JsonModel) object;
            return Objects.equal(this.unknownProps, that.unknownProps);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("unknownProps", unknownProps)
                .toString();
    }

}
