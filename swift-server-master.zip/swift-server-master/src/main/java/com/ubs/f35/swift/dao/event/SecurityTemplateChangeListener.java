package com.ubs.f35.swift.dao.event;

import com.ubs.f35.swift.dao.model.SecurityTemplate;

public interface SecurityTemplateChangeListener {
    void afterUpdate(SecurityTemplate securityTemplate);
}
