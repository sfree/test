package com.ubs.f35.swift.document;

import java.util.List;

import com.google.common.base.Objects;
import com.google.common.collect.ImmutableList;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.environment.model.glu.Entry;

/**
 * EnvironmentDefinition represents an environments entries from a glu perspective.
 * <p>
 * This object is immutable and should not be changed so that threads currently acting on an instance have a consistent
 * view of the environment.
 * <p>
 * Note that this class is intentionally package scope to avoid creating dependencies outside the
 * {@link EnvironmentDocumentStore} on having the full environment definition easily accessible.
 * 
 * @author stephelu
 */
class EnvironmentDefinition {
    private final Environment environment;
    private final List<Entry> entries;

    public EnvironmentDefinition(final Environment environment, final List<Entry> entries) {
        this.environment = environment;
        this.entries = ImmutableList.copyOf(entries);
    }

    public Environment getEnvironment() {
        return environment;
    }

    public List<Entry> getEntries() {
        return entries;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(environment, entries);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof EnvironmentDefinition) {
            EnvironmentDefinition that = (EnvironmentDefinition) object;
            return Objects.equal(this.environment, that.environment) &&
                    Objects.equal(this.entries, that.entries);
        }
        return false;
    }

}
