package com.ubs.f35.swift.dao;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.hibernate.annotations.NaturalId;
import org.hibernate.envers.Audited;

import com.google.common.base.Objects;

@SequenceGenerator(name = "oracle_seq", sequenceName = "seq_release_links_id")
@Entity
@Table(name = "RELEASE_LINKS")
@Audited
public class ReleaseLink implements Serializable {

    private static final long serialVersionUID = -1896239024844232983L;

    public static final String TYPE_RNOW = "RNOW";

    // This ID field is needed because Auditing would choke on the OneToMany relationship from ReleaseDefintion to
    // ReleaseLink when the join column is part of a composite key.
    // Bug ID: https://hibernate.atlassian.net/browse/HHH-7625
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "oracle_seq")
    private Integer id;

    // JsonIgnore is important. Without it, this results in a serialisation infinite loop
    @JsonIgnore
    @NaturalId
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "release_definition_id", referencedColumnName = "id")
    private ReleaseDefinition releaseDefinition;

    @NaturalId
    private String type;

    @NaturalId
    private String pointer;

    public ReleaseLink() {

    }

    public ReleaseLink(final ReleaseDefinition releaseDefinition, final String type, final String pointer) {
        this(null, releaseDefinition, type, pointer);
    }

    public ReleaseLink(final Integer id, final ReleaseDefinition releaseDefinition, final String type,
            final String pointer) {
        this.id = id;
        this.releaseDefinition = releaseDefinition;
        this.type = type;
        this.pointer = pointer;
    }

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public ReleaseDefinition getReleaseDefinition() {
        return releaseDefinition;
    }

    public void setReleaseDefinition(final ReleaseDefinition releaseDefinition) {
        this.releaseDefinition = releaseDefinition;
    }

    public String getType() {
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    public String getPointer() {
        return pointer;
    }

    public void setPointer(final String pointer) {
        this.pointer = pointer;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("releaseDefinitionId", safeReleaseDefinitionId(releaseDefinition))
                .add("type", type)
                .add("pointer", pointer)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(safeReleaseDefinitionId(releaseDefinition), type, pointer);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ReleaseLink) {
            ReleaseLink that = (ReleaseLink) object;
            return Objects.equal(safeReleaseDefinitionId(this.releaseDefinition),
                    safeReleaseDefinitionId(that.releaseDefinition))
                    && Objects.equal(this.type, that.type)
                    && Objects.equal(this.pointer, that.pointer);
        }
        return false;
    }

    private static Object safeReleaseDefinitionId(final ReleaseDefinition releaseDefinition) {
        return releaseDefinition == null ? null : releaseDefinition.getId();
    }

}
