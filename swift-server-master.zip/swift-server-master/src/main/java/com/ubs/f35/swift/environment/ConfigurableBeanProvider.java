package com.ubs.f35.swift.environment;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.jmx.export.MBeanExportOperations;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public abstract class ConfigurableBeanProvider<K, V> implements BeanNameAware {
    private static final Logger LOG = LoggerFactory.getLogger(ConfigurableBeanProvider.class);
    private final Map<K, V> beans = Maps.newConcurrentMap();
    private String name;
    private final List<Runnable> listeners = Lists.newCopyOnWriteArrayList();
    @Resource(name = "mbeanExporter")
    private MBeanExportOperations mbeanExporter;

    public void registerUpdateListener(final Runnable runnable) {
        listeners.add(runnable);

        if (!getAll().isEmpty()) {
            notifyListeners();
        }
    }

    public V get(final K key) {
        V bean = beans.get(key);
        if (bean == null) {
            throw new IllegalArgumentException("No " + name + " found for " + getSourceType() + " " + key);
        }
        return bean;
    }

    V tryGet(final K key) {
        return beans.get(key);
    }

    protected abstract String getSourceType();

    public Map<K, V> getAll() {
        return beans;
    }

    public void set(final K key, final V bean) {
        if (bean.getClass().isAnnotationPresent(ManagedResource.class)) {
            try {
                ObjectName mbeanName = new ObjectName("com.ubs.swift", "name",
                        getMBeanPrefix(key) + "." + bean.getClass().getSimpleName());
                mbeanExporter.unregisterManagedResource(mbeanName);
                mbeanExporter.registerManagedResource(bean, mbeanName);
            } catch (MalformedObjectNameException e) {
                LOG.error("Exception registering bean", e);
            }
        }
        beans.put(key, bean);

        notifyListeners();
    }

    protected abstract String getMBeanPrefix(K key);

    private void notifyListeners() {
        for (Runnable listener : listeners) {
            listener.run();
        }
    }

    @Override
    public void setBeanName(final String name) {
        this.name = name;
    }

    // @Required
    public void setMbeanExporter(final MBeanExportOperations mbeanExporter) {
        this.mbeanExporter = mbeanExporter;
    }
}
