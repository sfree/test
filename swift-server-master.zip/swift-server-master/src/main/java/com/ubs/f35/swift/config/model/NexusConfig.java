package com.ubs.f35.swift.config.model;

import java.util.List;

public class NexusConfig {
    /**
     * Unique id representing this nexus instance.
     */
    private String nexusId;
    private String contentUrl;
    private String searchUrl;
    private String repository;
    private String packaging;
    private String classifier;
    /**
     * The nexus RSS feed is optional. If specified, swift will monitor the RSS feed and automatically register
     * artifacts.
     */
    private String pollerUrl;
    private String pollerUsername;
    private String pollerPassword;
    private List<String> pollerRepositories;

    public String getContentUrl() {
        return contentUrl;
    }

    public void setContentUrl(final String contentUrl) {
        this.contentUrl = contentUrl;
    }

    public String getSearchUrl() {
        return searchUrl;
    }

    public void setSearchUrl(final String searchUrl) {
        this.searchUrl = searchUrl;
    }

    public String getRepository() {
        return repository;
    }

    public void setRepository(final String repository) {
        this.repository = repository;
    }

    public String getPackaging() {
        return packaging;
    }

    public void setPackaging(final String packaging) {
        this.packaging = packaging;
    }

    public String getClassifier() {
        return classifier;
    }

    public void setClassifier(final String classifier) {
        this.classifier = classifier;
    }

    public String getPollerUrl() {
        return pollerUrl;
    }

    public void setPollerUrl(final String pollerUrl) {
        this.pollerUrl = pollerUrl;
    }

    public String getPollerUsername() {
        return pollerUsername;
    }

    public void setPollerUsername(final String pollerUsername) {
        this.pollerUsername = pollerUsername;
    }

    public String getPollerPassword() {
        return pollerPassword;
    }

    public void setPollerPassword(final String pollerPassword) {
        this.pollerPassword = pollerPassword;
    }

    public List<String> getPollerRepositories() {
        return pollerRepositories;
    }

    public void setPollerRepositories(final List<String> pollerRepositories) {
        this.pollerRepositories = pollerRepositories;
    }

    public String getNexusId() {
        return nexusId;
    }

    public void setNexusId(final String nexusId) {
        this.nexusId = nexusId;
    }
}
