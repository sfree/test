package com.ubs.f35.swift.io.processor;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionOperations;

import com.google.common.annotations.VisibleForTesting;
import com.ubs.f35.core.AuthenticationPrincipal;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;
import com.ubs.f35.swift.dao.Deployment.DeploymentType;
import com.ubs.f35.swift.deploy.client.action.ClientAction;
import com.ubs.f35.swift.deploy.client.action.ClientActionConvertor;
import com.ubs.f35.swift.deploy.client.action.ClientPlanAction;
import com.ubs.f35.swift.deploy.glu.DeploymentExecutor;
import com.ubs.f35.swift.deploy.glu.DeploymentListener;
import com.ubs.f35.swift.deploy.glu.DeploymentService;
import com.ubs.f35.swift.deploy.glu.GluReleaseManager;
import com.ubs.f35.swift.deploy.glu.action.Action;
import com.ubs.f35.swift.deploy.glu.action.TransitionAction;
import com.ubs.f35.swift.io.processor.AsyncSendForwardingStreamingAdaptor.ConversationHandle;
import com.ubs.f35.swift.io.processor.AsyncSendForwardingStreamingAdaptor.ConverstationProcessor;
import com.ubs.f35.swift.model.JsonObjectMapper;

public class DeploymentProcessor implements ConverstationProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(DeploymentProcessor.class);

    private GluReleaseManager gluReleaseManager;
    private DeploymentExecutor deploymentExecutor;
    private TransactionOperations transactionTemplate;
    private DeploymentService deploymentService;

    @Required
    public void setDeploymentExecutor(final DeploymentExecutor deploymentExecutor) {
        this.deploymentExecutor = deploymentExecutor;
    }

    @Required
    public void setGluReleaseManager(final GluReleaseManager gluReleaseManager) {
        this.gluReleaseManager = gluReleaseManager;
    }

    @Required
    public void setTransactionTemplate(final TransactionOperations transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }

    @Required
    public void setDeploymentService(final DeploymentService deploymentService) {
        this.deploymentService = deploymentService;
    }

    @Override
    public void onMessage(final AuthenticationPrincipal principal, final ConversationHandle conversationHandle,
            final Object message) {
        final UUID deploymentId = UUID.fromString(getDeploymentKey(conversationHandle));

        LOG.info("Received message {} for deployment {}", message, deploymentId);
        final DeploymentConversationMessage deploymentMessage = JsonObjectMapper.getInstance().readValue(
                (String) message, DeploymentConversationMessage.class);

        // Loading and updating of selected deployment actions is done in a separate transaction. This is because the
        // deployment is potentially a very long running operation and this should commit regardless of if the
        // deployment succeeds or fails.
        Deployment deployment = transactionTemplate.execute(new TransactionCallback<Deployment>() {
            @Override
            public Deployment doInTransaction(final TransactionStatus status) {
                return loadDeploymentToDeployAndUpdateSelectedActions(deploymentId, deploymentMessage);
            }
        });

        if (deploymentMessage instanceof StartDeploymentMessage) {
            executeDeployment((StartDeploymentMessage) deploymentMessage, deployment, conversationHandle);
        } else if (deploymentMessage instanceof ManualDeploymentInstructionMessage) {
            deploymentExecutor.continueDeployment(deploymentId, (ManualDeploymentInstructionMessage) deploymentMessage);
        } else if (deploymentMessage instanceof CancelDeploymentMessage) {
            deploymentExecutor.cancelDeployment(deploymentId);
        } else {
            LOG.warn("unexpected message {}.  Cancelling deployment", deploymentMessage);
            deploymentExecutor.cancelDeployment(deploymentId);
        }
    }

    @VisibleForTesting
    Deployment loadDeploymentToDeployAndUpdateSelectedActions(final UUID deploymentId,
            final DeploymentConversationMessage deploymentMessage) {
        // Starting an deployment can only be done on a fresh deployment plan. Other actions need to be allowed
        // regardless of how old the plan is.
        boolean expireIfNotFresh = deploymentMessage instanceof StartDeploymentMessage;
        Deployment deployment = deploymentService.loadDeploymentToDeploy(deploymentId, expireIfNotFresh);

        if (deploymentMessage instanceof StartDeploymentMessage) {
            StartDeploymentMessage startMessage = (StartDeploymentMessage) deploymentMessage;
            if (startMessage.getExecute() != null) {
                deploymentService.updateSelectedPlanItems(deployment, startMessage.getExecute());
            }
        }

        return deployment;
    }

    private String getDeploymentKey(final ConversationHandle topicHandle) {
        String topicId = topicHandle.getDestinationId().substring("/deploy/".length());
        LOG.debug("Received topic call {}", topicId);
        return topicId;
    }

    private void executeDeployment(final StartDeploymentMessage deploymentMessage, final Deployment deployment,
            final ConversationHandle topicHandle) {
        DeploymentListener topicNotifyingListener = new DeploymentListener() {
            @Override
            public void deploymentActionChanged(final Action action) {
                if (action instanceof TransitionAction) {
                    ClientPlanAction clientAction = ClientActionConvertor.INSTANCE.apply((TransitionAction) action);
                    topicHandle.onMessage(clientAction);
                } else if (action instanceof ClientAction) {
                    topicHandle.onMessage(action);
                }
            }

            @Override
            public void deploymentComplete(final DeploymentStatus status) {
                topicHandle.onMessage(status);
            }
        };

        if (deployment.getDeploymentType() == DeploymentType.Release
                || deployment.getDeploymentType() == DeploymentType.Rollback) {
            deployRelease(deploymentMessage, deployment, topicNotifyingListener);
        }
        else {
            deployAdHoc(deployment, topicNotifyingListener);
        }
    }

    private void deployRelease(final StartDeploymentMessage deploymentMessage, final Deployment deployment,
            final DeploymentListener deploymentListener) {
        LOG.info("Deploying release {} to environments {}", deployment.getReleaseId(), deployment.getEnvDeployments());

        gluReleaseManager.verifyProductionWarningsAcknowledged(deployment, deploymentMessage);

        gluReleaseManager.deployRelease(deployment, deploymentListener);
    }

    private void deployAdHoc(final Deployment deployment, final DeploymentListener deploymentListener) {
        LOG.info("Deploying plan {} to environments {}", deployment.getId(), deployment.getEnvDeployments());

        deploymentExecutor.executeDeployment(deployment, deploymentListener);
    }

}
