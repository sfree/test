package com.ubs.f35.swift.deploy.validator;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.collect.Iterables;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlanBuilder;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlanStrategy;
import com.ubs.f35.swift.deploy.glu.rest.GluHostStatusManager;
import com.ubs.f35.swift.deploy.glu.state.GluState;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;
import com.ubs.f35.swift.model.HostStatus;

/**
 * {@link DeploymentPlanValidator} which checks if any hosts that will be affected by this deployment are already under
 * high load.
 * 
 * @author stephelu
 * 
 */
public class HostStatusDeploymentPlanValidator implements DeploymentPlanValidator {
    private static final Logger LOG = LoggerFactory.getLogger(HostStatusDeploymentPlanValidator.class);

    private EnvironmentBeanFactory<GluHostStatusManager> hostStatusManagerFactory;

    private int freeMemoryWarningThreshold = 2048;
    private double loadAverageWarningThreshold = 2.0;

    @Override
    public void validate(final DeploymentPlanBuilder builder, final Environment environment,
            final DeploymentAction action, final DeploymentPlanStrategy strategy) {
        if (action.getFinalTransitionState() == GluState.running) {
            List<HostStatus> hosts = hostStatusManagerFactory.get(environment).getHostHealth(builder.getHosts());

            for (HostStatus host : hosts) {
                if (host.isMonitorUp()) {
                    if (host.getMemFreeMb() < freeMemoryWarningThreshold) {
                        builder.addWarning("Host " + host.getHost() + " is running low on free memory ("
                                + host.getMemFreeMb() + "mb)");
                    }

                    Double loadAverage = Iterables.getFirst(host.getLoadAverages(), 0.0);
                    if (loadAverage > loadAverageWarningThreshold) {
                        builder.addWarning("Host " + host.getHost() + " has a high load average (" + loadAverage + ")");
                    }
                }
            }
        }
    }

    @Required
    public void setHostStatusManagerFactory(final EnvironmentBeanFactory<GluHostStatusManager> hostStatusManagerFactory) {
        this.hostStatusManagerFactory = hostStatusManagerFactory;
    }

    public void setFreeMemoryWarningThreshold(final int freeMemoryWarningThreshold) {
        this.freeMemoryWarningThreshold = freeMemoryWarningThreshold;
    }

    public void setLoadAverageWarningThreshold(final double loadAverageWarningThreshold) {
        this.loadAverageWarningThreshold = loadAverageWarningThreshold;
    }

}
