package com.ubs.f35.swift.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.joda.time.DateMidnight;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ubs.f35.swift.dao.DailyReleaseStats;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.PagingResult;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseDefinitionDao;
import com.ubs.f35.swift.dao.hibernate.framework.PagingCriteriaBuilder;
import com.ubs.f35.swift.model.ReleaseFilters;
import com.ubs.f35.swift.model.ReleaseFilters.Sort;

/**
 * DAO access to {@link ReleaseDefinition}
 * <p>
 * Note that {@link #create(ReleaseDefinition)} triggers a {@link Session#flush()} . This is done so that the returned
 * created / updated objects have properties set by hibernate / the db correctly initialised (eg
 * {@link ReleaseDefinition#getLastUpdatedTime()}.
 */
public class HibernateReleaseDefinitionDao extends HibernateAuditableEntityDao<Integer, ReleaseDefinition> implements
        ReleaseDefinitionDao {
    private static final Logger LOG = LoggerFactory.getLogger(HibernateReleaseDefinitionDao.class);

    @Override
    public PagingResult<ReleaseDefinition> list(final ReleaseFilters releaseFilters, final PagingFilter pagingFilter) {
        return executeCriteriaWithPaging(pagingFilter, ReleaseDefinition.class, new PagingCriteriaBuilder() {

            @Override
            public void appendCriteria(final Criteria criteria, final boolean count) {

                if (releaseFilters.isUpcoming()) {
                    criteria.add(Restrictions.ge("releaseDate", DateMidnight.now().toDate()));
                }

                // Release Name filter is fuzzy
                addNotEmpty(criteria, releaseFilters.getName(),
                        Restrictions.ilike("name", contains(releaseFilters.getName())));

                criteria.createAlias("team", "t");

                if (!CollectionUtils.isEmpty(releaseFilters.getTeam())) {
                    addNotEmptyIn(criteria, releaseFilters.getTeam(), "t.name");
                }

                if (anyPresent(releaseFilters.getGroup(), releaseFilters.getArtifact())) {
                    criteria.createAlias("artifacts", "a");
                    addNotEmptyIn(criteria, releaseFilters.getGroup(), "a.groupId");
                    addNotEmptyIn(criteria, releaseFilters.getArtifact(), "a.artifactId");
                }

                addNotEmpty(criteria, releaseFilters.getStartDate(),
                        Restrictions.ge("releaseDate", releaseFilters.getStartDate()));
                addNotEmpty(criteria, releaseFilters.getEndDate(),
                        Restrictions.le("releaseDate", releaseFilters.getEndDate()));

                if (StringUtils.hasText(releaseFilters.getOrganisation())) {
                    criteria.createAlias("t.organisation", "o");
                    criteria.add(Restrictions.eq("o.name", releaseFilters.getOrganisation()));
                }

                if (!count) {
                    Sort ordering = releaseFilters.getOrdering();
                    if (ordering == null) {
                        if (releaseFilters.isUpcoming()) {
                            ordering = Sort.RELEASE_DATE;
                        } else {
                            ordering = Sort.CREATED;
                        }
                    }

                    criteria.addOrder(ordering.descending() ?
                            Order.desc(ordering.columnName()) : Order.asc(ordering.columnName()));
                }

                criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
                // Would it be more efficient to use criteria.setProjection(Projections.distinct(Projections.id()))
                // instead of setResultTransformer? Would then need to make all criteria above part of a subquery
                // which returns the unique IDs, and the outer query would then fetch the actual release definitions.
            }
        });
    }

    @Override
    public ReleaseDefinition load(final Integer id) {
        ReleaseDefinition releaseDefinition = loadExpected(ReleaseDefinition.class, id);
        Integer revision = super.getLatestRevisionId(id);
        releaseDefinition.setRevision(revision);
        releaseDefinition.setLatestRevision(revision);
        return releaseDefinition;
    }

    @Override
    public ReleaseDefinition loadRevision(final Integer entityId, final Integer revision) {

        AuditEntry<ReleaseDefinition> entry = super.loadRevisionAuditEntry(entityId, revision);

        ReleaseDefinition releaseDefinition = entry.getEntity();
        releaseDefinition.setRevision(entry.getRevision().getId());
        releaseDefinition.setLatestRevision(super.getLatestRevisionId(entityId));
        releaseDefinition.setLastUpdatedTime(entry.getRevision().getRevisionDate());
        releaseDefinition.setLastUpdatedBy(entry.getRevision().getUser());

        return releaseDefinition;
    }

    @Override
    public void create(final ReleaseDefinition releaseDefinition) {
        getSession().save(releaseDefinition);

        // See class javadoc
        getSession().flush();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<DailyReleaseStats> getDailyReleaseStats(final String organisation) {
        return getSession()
                .createQuery(
                        "select new com.ubs.f35.swift.dao.DailyReleaseStats(trunc(r.createdTime), count(*)) from ReleaseDefinition r "
                                + "join r.team t join t.organisation o "
                                + "where o.name = :organisation "
                                + "group by trunc(createdTime) order by 1")
                .setString("organisation", organisation)
                .list();
    }

    @Override
    Class<ReleaseDefinition> getValueClass() {
        return ReleaseDefinition.class;
    }

    private static boolean anyPresent(final List<String> fields) {
        for (String field : fields) {
            if (StringUtils.hasText(field)) {
                return true;
            }
        }
        return false;
    }

    private static boolean anyPresent(final List<String>... fields) {
        for (List<String> field : fields) {
            if (!CollectionUtils.isEmpty(field)) {
                if (anyPresent(field)) {
                    return true;
                }
            }
        }
        return false;
    }

}
