package com.ubs.f35.swift.deploy.glu.action;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

import com.ubs.f35.swift.deploy.client.action.ClientAction;
import com.ubs.f35.swift.deploy.glu.DeploymentCancelledException;
import com.ubs.f35.swift.deploy.template.model.TemplateManualAction;

/**
 * Records the outcome of a deployment {@link ManualTask}.
 * 
 * TODO This currently is a small piece of experimental work. Additional tasks - cancel deployment to abort any
 * outstanding manual actions - max time limits on manual tasks before they are automatically aborted - consider
 * switching the deployment executor to be reactive rather than blocking, so that threads are not blocked by manual
 * actions (maybe look at akka)
 */
public class ManualAction extends BaseAction implements ClientAction {
    private TemplateManualAction spec;
    private String comment;
    @JsonIgnore
    private transient ManualActionFuture future = new ManualActionFuture();

    public ManualAction(@JsonProperty(value = "id") final String id,
            @JsonProperty(value = "name") final String name) {
        super(id, name);
    }

    public TemplateManualAction getSpec() {
        return spec;
    }

    public void setSpec(final TemplateManualAction spec) {
        this.spec = spec;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(final String comment) {
        this.comment = comment;
    }

    @JsonIgnore
    public ManualActionFuture getFuture() {
        return future;
    }

    public void markCompleted(final String comment) {
        this.comment = comment;
        this.future.latch.countDown();
    }

    public void markAborted(final String comment) {
        this.comment = comment;
        this.future.cancelled.set(true);
        this.future.latch.countDown();
    }

    public class ManualActionFuture {

        AtomicReference<Boolean> cancelled = new AtomicReference<Boolean>(false);
        CountDownLatch latch = new CountDownLatch(1);

        public Void get(final long timeout, final TimeUnit unit) throws InterruptedException, TimeoutException {
            if (!latch.await(timeout, unit)) {
                throw new TimeoutException("Manual action '" + spec.getTitle() + "' timed out");
            }
            return exitFromFuture();
        }

        private Void exitFromFuture() {
            if (cancelled.get()) {
                throw new DeploymentCancelledException();
            }
            return null;
        }
    }
}
