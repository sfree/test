package com.ubs.f35.swift.deploy.template.model;

import com.google.common.base.Objects;

public class DeploymentTemplate {

    private TemplateAction action;

    public TemplateAction getAction() {
        return action;
    }

    public void setAction(final TemplateAction action) {
        this.action = action;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(action);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DeploymentTemplate) {
            DeploymentTemplate that = (DeploymentTemplate) object;
            return Objects.equal(this.action, that.action);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("action", action)
                .toString();
    }

}
