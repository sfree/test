package com.ubs.f35.core.container.tomcat;

import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.apache.catalina.LifecycleException;
import org.apache.catalina.Pipeline;
import org.apache.catalina.Valve;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.core.StandardContext;
import org.apache.catalina.core.StandardHost;
import org.apache.catalina.core.StandardWrapper;
import org.apache.catalina.core.StandardWrapperFacade;
import org.apache.catalina.startup.Tomcat;
import org.apache.coyote.AbstractProtocol;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * Largely a copy paste of {@link SingleServletEmbeddedTomcat}. This implementation has a few differences.
 * <ol>
 * <li>start the servlets (rather than the tomcat default of waiting for the first request)
 * <li>Adds WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE to the {@link ServletContext} so that the
 * spring {@link DispatcherServlet}
 * </ol>
 * <p>
 * TODO Attempt to refactor into the SingleServletEmbeddedTomcat
 */
public class SwiftSingleServletEmbeddedTomcat implements ApplicationContextAware {

    private static final Logger LOGGER = LoggerFactory.getLogger(SwiftSingleServletEmbeddedTomcat.class);

    private final Tomcat tomcat;
    private List<Valve> valves;
    private int port;
    private InetAddress address;
    private String servletName;
    private String servletPath;
    private Servlet servlet;
    private int maxSize;

    private Connector connector;

    private ApplicationContext applicationContext;

    public SwiftSingleServletEmbeddedTomcat() throws Exception {
        this(new Tomcat());
    }

    SwiftSingleServletEmbeddedTomcat(final Tomcat tomcat) {
        this.tomcat = tomcat;
    }

    @Required
    public void setPort(final int port) {
        this.port = port;
    }

    @Required
    public void setAddress(final InetAddress address) {
        this.address = address;
    }

    @Required
    public void setServletName(final String servletName) {
        this.servletName = servletName;
    }

    public void setServletPath(final String servletPath) {
        this.servletPath = servletPath;
    }

    @Required
    public void setServlet(final Servlet servlet) {
        this.servlet = servlet;
    }

    @Required
    public void setConnector(final Connector connector) {
        this.connector = connector;
    }

    public void setValves(final List<Valve> valves) {
        this.valves = valves;
    }

    public void setMaxSize(final int maxSize) {
        if (maxSize <= 0) {
            throw new IllegalArgumentException("Request body max size must be a positive number");
        }
        this.maxSize = maxSize;
    }

    @Override
    public void setApplicationContext(final ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    public void start() throws LifecycleException, UnknownHostException {

        LOGGER.info("Preparing Tomcat instance {} on {}:{}", asArray(servletName, address, port));
        tomcat.setPort(port);
        addValves();
        addConnector(address);

        File docBase = new File(".");
        StandardContext context = (StandardContext) tomcat.addContext("", docBase.getAbsolutePath());

        WebApplicationContext appContextProxy = WebAppContextFactory.getWebApp(applicationContext);

        StandardWrapper wrapper = (StandardWrapper) tomcat.addServlet("", servletName, servlet);

        StandardWrapperFacade facade = new StandardWrapperFacade(wrapper);
        facade.getServletContext().setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE,
                appContextProxy);

        String servletPath = (this.servletPath != null) ? this.servletPath : "/" + servletName;

        LOGGER.info("Registering servlet {} to {} on instance {}", asArray(servletName, servletPath, servletName));
        context.addServletMapping(servletPath, servletName);

        tomcat.init();

        LOGGER.info("Initialising dispatcher servlet");

        // TODO Ideally this would be done on using wrapper.setLoadOnStartup(1). Unfortunately this results in tomcat
        // spawning a separate thread to start the servlet which calls back into the spring app context. This results in
        // a deadlock
        try {
            servlet.init(facade);
        } catch (ServletException ex) {
            throw new RuntimeException(ex);
        }

        LOGGER.info("Starting tomcat instance {}", servletName);
        tomcat.start();
    }

    private Object[] asArray(final Object... objects) {
        return objects;
    }

    private void addValves() {
        StandardHost standardHost = (StandardHost) tomcat.getHost();

        // register the standard valves
        standardHost.setErrorReportValveClass(SecureErrorReportValve.class.getCanonicalName());
        Pipeline pipeline = standardHost.getPipeline();
        if (maxSize > 0) {
            standardHost.getPipeline().addValve(new RequestBodyLimitValve(maxSize));
        }

        if (valves != null && !valves.isEmpty()) {
            for (Valve valve : valves) {
                pipeline.addValve(valve);
            }
        }
    }

    private void addConnector(final InetAddress address) {
        AbstractProtocol protocolHandler = (AbstractProtocol) connector.getProtocolHandler();
        protocolHandler.setAddress(address);
        tomcat.getService().addConnector(connector);
    }

}
