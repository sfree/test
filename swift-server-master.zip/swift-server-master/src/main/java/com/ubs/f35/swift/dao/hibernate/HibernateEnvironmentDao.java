package com.ubs.f35.swift.dao.hibernate;

import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Function;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.OrganisationDao;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.Organisation;
import com.ubs.f35.swift.processor.ProcessorUtil;

public class HibernateEnvironmentDao extends HibernateDaoSupport implements EnvironmentDao {

    private static final Logger LOG = LoggerFactory.getLogger(HibernateEnvironmentDao.class);

    private OrganisationDao organisationDao;

    @Override
    public Environment loadEnvironment(final String environment, final String organisation) {
        Organisation org = organisationDao.load(organisation);
        Environment env = (Environment) getSession().byNaturalId(Environment.class).using("name", environment)
                .using("organisation", org).load();

        if (env == null) {
            throw new EntityNotFoundException("Entity not found:" + Environment.class.getSimpleName() + "[name="
                    + environment + ",organisation=" + organisation + "]");
        }

        return env;
    }

    @Override
    public Environment loadEnvironment(final Environment environment) {
        return loadEnvironment(environment.getName(), environment.getOrganisation().getName());
    }

    @Override
    public Environment loadEnvironment(final Integer id) {
        return loadExpected(Environment.class, id);
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    @Override
    public List<Environment> loadEnvironments() {
        return getSession().createCriteria(Environment.class).list();
    }

    @Override
    public List<Environment> loadEnvironments(final List<Environment> environments) {
        return ProcessorUtil.transform(environments,
                new Function<Environment, Environment>() {
                    @Override
                    public Environment apply(final Environment input) {
                        return loadEnvironment(input);
                    }
                });
    }

    @Override
    public void save(final Environment environment) {
        getSession().save(environment);
    }

    @Required
    public void setOrganisationDao(final OrganisationDao organisationDao) {
        this.organisationDao = organisationDao;
    }
}
