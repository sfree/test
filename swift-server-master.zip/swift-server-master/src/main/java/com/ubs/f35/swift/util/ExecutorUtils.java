package com.ubs.f35.swift.util;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import com.google.common.base.Throwables;

public abstract class ExecutorUtils {
    public static <T> List<Future<T>> invokeAllAndPropagateFirstRuntimeException(final ExecutorService executor,
            final List<? extends Callable<T>> tasks) {
        try {
            return invokeAllAndPropagateFirstException(executor, tasks);
        } catch (Exception e) {
            throw Throwables.propagate(e);
        }
    }

    public static <T> List<Future<T>> invokeAllAndPropagateFirstException(final ExecutorService executor,
            final List<? extends Callable<T>> tasks) throws Exception {
        try {
            List<Future<T>> results = executor.invokeAll(tasks);
            for (Future<T> result : results) {
                waitForFuture(result);
            }
            return results;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException(e);
        } catch (ExecutionException e) {
            Throwables.propagateIfPossible(e.getCause(), Exception.class);
            throw Throwables.propagate(e.getCause());
        }
    }

    private static <T> void waitForFuture(final Future<T> result) throws InterruptedException, ExecutionException {
        result.get();
    }

}
