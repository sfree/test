package com.ubs.f35.swift.environment;

import java.util.Map;

import org.linkedin.util.clock.Timespan;
import org.linkedin.zookeeper.client.ZKClient;

import com.ubs.f35.swift.zookeeper.ZooKeeperTreeTracker;

/**
 * The {@link LinkedInZookeeperFactory} provides instances of the linkedin developed {@link ZKClient}. This is used by
 * the {@link ZooKeeperTreeTracker} to monitor changes to the zookeeper tree.
 */
public class LinkedInZookeeperFactory extends ZookeeperFactory<ZKClient> {

    @Override
    public ZKClient load(final Map<String, String> zooKeeperClientProperties) {
        String connectionString = zooKeeperClientProperties.get("zookeeper.client.host.ports");
        String timeout = zooKeeperClientProperties.get("zookeeper.client.connection.timeout");
        return new ZKClient(connectionString, Timespan.milliseconds(Long.parseLong(timeout, 10)), null);
    }

    @Override
    void close(final ZKClient zookeeper) {
        zookeeper.destroy();
    }

}
