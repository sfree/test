package com.ubs.f35.swift.deploy.glu;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.collect.Lists;
import com.ubs.f35.swift.deploy.glu.action.Action;
import com.ubs.f35.swift.deploy.glu.action.ActionExecutor;
import com.ubs.f35.swift.deploy.glu.action.BaseGroupedAction;
import com.ubs.f35.swift.deploy.glu.action.DeploymentContext;
import com.ubs.f35.swift.deploy.glu.action.ManualAction;
import com.ubs.f35.swift.deploy.glu.action.ParallelAction;
import com.ubs.f35.swift.deploy.glu.action.SequentialAction;
import com.ubs.f35.swift.deploy.glu.action.TransitionAction;
import com.ubs.f35.swift.util.ExecutorUtils;

public class DeploymentActionExecutor implements ActionExecutor {
    private static final Logger LOG = LoggerFactory.getLogger(DeploymentActionExecutor.class);

    private ExecutorService parallelExecutor;
    private long manualActionTimeout = 60;
    private TimeUnit manualActionTimeoutTimeUnit = TimeUnit.MINUTES;

    @Required
    public void setParallelExecutor(final ExecutorService parallelExecutor) {
        this.parallelExecutor = parallelExecutor;
    }

    @Override
    public void execute(final DeploymentContext context, final Action action) {
        if (action instanceof TransitionAction) {
            ((TransitionAction) action).execute(context);
        } else if (action instanceof SequentialAction) {
            executeSequenctialActions(context, ((BaseGroupedAction) action).getIncluded());
        } else if (action instanceof ParallelAction) {
            executeParallelActions(context, ((BaseGroupedAction) action).getIncluded());
        } else if (action instanceof ManualAction) {
            executeManualAction((ManualAction) action);
        } else {
            throw new IllegalArgumentException("Unable to execute action " + action);
        }
    }

    private void executeManualAction(final ManualAction action) {
        // block until the Manual action has completed.
        try {
            action.getFuture().get(manualActionTimeout, manualActionTimeoutTimeUnit);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException(e);
        } catch (TimeoutException e) {
            action.setComment("Manual action timed out");
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    protected void executeSequenctialActions(final DeploymentContext context, final List<Action> actions) {
        for (final Action action : actions) {
            invokeNestedAction(context, action);
        }
    }

    private void executeParallelActions(final DeploymentContext context, final List<Action> actions) {
        List<Callable<Void>> tasks = Lists.newArrayListWithCapacity(actions.size());
        for (final Action action : actions) {
            tasks.add(new Callable<Void>() {
                @Override
                public Void call() {
                    invokeNestedAction(context, action);
                    return null;
                }
            });
        }
        LOG.info("Scheduling {} deployment actions for execution", actions.size());
        // The cause can only be a RuntimeException as our callable doesn't throw any exceptions.
        ExecutorUtils.invokeAllAndPropagateFirstRuntimeException(parallelExecutor, tasks);
    }

    private void invokeNestedAction(final DeploymentContext context, final Action action) {
        context.getActionExecutor().execute(context, action);
    }

    public void setManualActionTimeout(final long manualActionTimeout) {
        this.manualActionTimeout = manualActionTimeout;
    }

    public void setManualActionTimeoutTimeUnit(final TimeUnit manualActionTimeoutTimeUnit) {
        this.manualActionTimeoutTimeUnit = manualActionTimeoutTimeUnit;
    }

}
