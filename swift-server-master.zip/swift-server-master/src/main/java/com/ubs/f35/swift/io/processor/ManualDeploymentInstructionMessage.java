package com.ubs.f35.swift.io.processor;

import org.apache.commons.lang.Validate;
import org.codehaus.jackson.annotate.JsonProperty;

import com.google.common.base.Objects;

public class ManualDeploymentInstructionMessage implements DeploymentConversationMessage {
    private final String manualActionId;
    private final String comment;
    private final boolean continueDeployment;

    public ManualDeploymentInstructionMessage(@JsonProperty(value = "manualActionId") final String manualActionId,
            @JsonProperty(value = "comment") final String comment,
            @JsonProperty(value = "continueDeployment") final boolean continueDeployment) {
        Validate.notNull(manualActionId, "manualActionId must not be null");
        Validate.notNull(comment, "comment must not be null");
        this.manualActionId = manualActionId;
        this.comment = comment;
        this.continueDeployment = continueDeployment;
    }

    public String getManualActionId() {
        return manualActionId;
    }

    public String getComment() {
        return comment;
    }

    public boolean isContinueDeployment() {
        return continueDeployment;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(manualActionId);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ManualDeploymentInstructionMessage) {
            ManualDeploymentInstructionMessage that = (ManualDeploymentInstructionMessage) object;
            return Objects.equal(this.manualActionId, that.manualActionId)
                    && Objects.equal(this.comment, that.comment)
                    && Objects.equal(this.continueDeployment, that.continueDeployment);
        }
        return false;
    }

}
