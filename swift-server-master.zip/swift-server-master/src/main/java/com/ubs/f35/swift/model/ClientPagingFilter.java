package com.ubs.f35.swift.model;

import com.google.common.base.Objects;

/**
 * Specifies the range of data a query request is for.
 * <p>
 * For the first record in the list, specify a start index of 0.
 * 
 * @author stephelu
 * 
 */
public class ClientPagingFilter {
    private Integer start;
    private Integer records;

    public ClientPagingFilter() {
    }

    public ClientPagingFilter(final int start, final int records) {
        this.start = start;
        this.records = records;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(final Integer start) {
        this.start = start;
    }

    public Integer getRecords() {
        return records;
    }

    public void setRecords(final Integer records) {
        this.records = records;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(start, records);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ClientPagingFilter) {
            ClientPagingFilter that = (ClientPagingFilter) object;
            return Objects.equal(this.start, that.start)
                    && Objects.equal(this.records, that.records);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("start", start)
                .add("records", records)
                .toString();
    }

}
