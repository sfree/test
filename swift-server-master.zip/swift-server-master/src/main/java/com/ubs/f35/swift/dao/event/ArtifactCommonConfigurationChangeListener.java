package com.ubs.f35.swift.dao.event;

import com.ubs.f35.swift.config.model.ArtifactCommonConfig;

public interface ArtifactCommonConfigurationChangeListener {
    void afterUpdate(ArtifactCommonConfig config);
}
