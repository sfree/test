package com.ubs.f35.swift.messaging;

import java.util.List;
import java.util.concurrent.Executor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionOperations;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import com.ubs.f35.common.transport.processor.DefaultSenderProcessor;
import com.ubs.f35.core.AuthenticationPrincipal;
import com.ubs.f35.messaging.MessageHandle;
import com.ubs.f35.swift.config.model.ArtifactCommonConfig;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.DeployTag;
import com.ubs.f35.swift.config.model.DeployTagable;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.OrganisationDao;
import com.ubs.f35.swift.dao.event.ArtifactCommonConfigurationChangeListener;
import com.ubs.f35.swift.dao.event.ArtifactConfigurationChangeListener;
import com.ubs.f35.swift.dao.event.EnvironmentChangeListener;
import com.ubs.f35.swift.dao.event.HostChangeListener;
import com.ubs.f35.swift.dao.event.OrganisationChangeListener;
import com.ubs.f35.swift.dao.event.SecurityTemplateChangeListener;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.Organisation;
import com.ubs.f35.swift.dao.model.SecurityTemplate;
import com.ubs.f35.swift.executors.SwiftExecutors;
import com.ubs.f35.swift.processor.ArtifactConfigurationProcessor;
import com.ubs.f35.swift.processor.ProcessorUtil;
import com.ubs.f35.swift.security.UserConstants;

public class ConfigurationUpdateSender implements ArtifactConfigurationChangeListener, HostChangeListener,
        ArtifactCommonConfigurationChangeListener, OrganisationChangeListener, EnvironmentChangeListener,
        SecurityTemplateChangeListener {

    private static final Logger LOG = LoggerFactory.getLogger(ConfigurationUpdateSender.class);

    private Executor hibernateBackgroundExecutor = SwiftExecutors.getHibernateBackgroundExecutor();

    private final DefaultSenderProcessor messageProcessor;
    private final OrganisationDao organisationDao;
    private final EnvironmentDao environmentDao;
    private final TransactionOperations transactionTemplate;
    private AuthenticationPrincipal authenticationPrincipal = UserConstants.SWIFT_PRINCIPAL;

    public ConfigurationUpdateSender(final DefaultSenderProcessor messageProcessor,
            final TransactionOperations transactionTemplate, final OrganisationDao organisationDao,
            final EnvironmentDao environmentDao) {
        this.messageProcessor = messageProcessor;
        this.transactionTemplate = transactionTemplate;
        this.organisationDao = organisationDao;
        this.environmentDao = environmentDao;
    }

    @Override
    public void afterUpdate(final Host host) {
        LOG.info("Broadcasting changes after update to host {}", host);
        Host copy = new Host();
        copy.setHostname(host.getHostname());

        copyDeployTags(host, copy);

        broadcast(copy);
    }

    @Override
    public void afterUpdate(final ArtifactConfig config) {
        LOG.info("Broadcasting changes after update to artifact config {}", config);
        ArtifactConfig copy = ArtifactConfigurationProcessor.FULL_MAPPER.apply(config);

        copyDeployTags(config, copy);

        broadcast(copy);
    }

    /**
     * Copies the deployment tags stripping off the environment configuration.
     * 
     * @param source
     * @param target
     */
    private void copyDeployTags(final DeployTagable source, final DeployTagable target) {
        target.setEnvironment(copy(source.getEnvironment(), false));

        List<DeployTag> tagCopies = ProcessorUtil.transform(source.getDeployTags(),
                new Function<DeployTag, DeployTag>() {
                    @Override
                    public DeployTag apply(final DeployTag input) {
                        return new DeployTag(copy(input.getEnvironment(), false), input.getTag());
                    }
                });

        target.setDeployTags(tagCopies);
    }

    @Override
    public void afterUpdate(final ArtifactCommonConfig config) {
        LOG.info("Broadcasting changes after update to artifact common config {}", config);
        // This is only used to invalidate the property key cache, so no need to copy dependencies.
        ArtifactCommonConfig copy = new ArtifactCommonConfig(config.getGroupId(), config.getArtifactId(),
                config.isNonProd(), config.hasProperties(), config.getPropertyTemplates(), config.getLastUpdatedTime());
        broadcast(copy);
    }

    @Override
    public void afterUpdate(final Organisation organisation) {
        LOG.info("Broadcasting changes after update to organisation {}", organisation);
        backgroundTransaction(new Runnable() {
            @Override
            public void run() {
                Organisation persistentOrg = organisationDao.load(organisation.getName());
                broadcast(copy(persistentOrg, true));
            }
        });
    }

    @Override
    public void afterUpdate(final Environment environment) {
        LOG.info("Broadcasting changes after update to environment {}", environment);
        backgroundTransaction(new Runnable() {
            @Override
            public void run() {
                Environment persistentEnv = environmentDao.loadEnvironment(environment);
                broadcast(copy(persistentEnv, true));
            }
        });
    }

    @Override
    public void afterUpdate(final SecurityTemplate securityTemplate) {
        LOG.info("Broadcasting changes after update to security template {}", securityTemplate);
        broadcast(securityTemplate);
    }

    /**
     * The hibernate Interceptor contract states "The <tt>Session</tt> may not be invoked from a callback". If access to
     * the model is required before publishing a notification, then this needs to be completed on a background thread.
     * 
     * @param runnable
     */
    private void backgroundTransaction(final Runnable job) {
        hibernateBackgroundExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    transactionTemplate.execute(new TransactionCallback<Void>() {
                        @Override
                        public Void doInTransaction(final TransactionStatus status) {
                            job.run();
                            return null;
                        }
                    });
                } catch (Throwable t) {
                    LOG.error("Exception on background thread", t);
                }
            }
        });
    }

    protected void broadcast(final Object object) {
        messageProcessor.invoke(authenticationPrincipal, new DefaultMessageHandle<Object>(), object);
    }

    private Environment copy(final Environment environment, final boolean copyConfig) {
        if (environment == null) {
            return environment;
        }
        Environment clone = new Environment(environment.getId(), environment.getName(),
                copy(environment.getOrganisation(), copyConfig));
        if (copyConfig) {
            clone.setConfiguration(environment.getConfiguration());
        }
        return clone;
    }

    private Organisation copy(final Organisation organisation, final boolean copyConfig) {
        if (organisation == null) {
            return organisation;
        }
        Organisation clone = new Organisation();
        clone.setId(organisation.getId());
        clone.setName(organisation.getName());
        if (copyConfig) {
            clone.setConfiguration(organisation.getConfiguration());
        }
        return clone;
    }

    @VisibleForTesting
    protected void setAuthenticationPrincipal(final AuthenticationPrincipal authenticationPrincipal) {
        this.authenticationPrincipal = authenticationPrincipal;
    }

    @VisibleForTesting
    protected void setHibernateBackgroundExecutor(final Executor hibernateBackgroundExecutor) {
        this.hibernateBackgroundExecutor = hibernateBackgroundExecutor;
    }

    private class DefaultMessageHandle<T> implements MessageHandle<T> {

        @Override
        public void onMessage(final T message) {
        }

        @Override
        public void onError(final Object errorObject) {
        }

        @Override
        public String getDestination() {
            return null;
        }

    }

}
