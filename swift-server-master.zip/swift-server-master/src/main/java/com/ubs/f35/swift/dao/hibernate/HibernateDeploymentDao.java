package com.ubs.f35.swift.dao.hibernate;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.internal.TypeLocatorImpl;
import org.hibernate.type.BinaryType;
import org.hibernate.type.EnumType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.hibernate.type.Type;
import org.hibernate.type.TypeResolver;
import org.hibernate.type.descriptor.java.UUIDTypeDescriptor.ToBytesTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.dao.DailyDeploymentStats;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;
import com.ubs.f35.swift.dao.Deployment.DeploymentType;
import com.ubs.f35.swift.dao.DeploymentDao;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.PagingResult;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.hibernate.framework.PagingQueryBuilder;
import com.ubs.f35.swift.dao.model.DeployedArtifact;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.dao.model.Environment;

public class HibernateDeploymentDao extends HibernateDaoSupport implements DeploymentDao {

    private static final Logger LOG = LoggerFactory.getLogger(HibernateDeploymentDao.class);
    private static final Collection<DeploymentStatus> OUTSTANDING_DEPLOYMENT_STATUSES =
            Arrays.asList(DeploymentStatus.PLAN, DeploymentStatus.EXECUTING);

    @Override
    public void create(final Deployment record) {
        getSession().save(record);
    }

    @Override
    public PagingResult<Deployment> getDeploymentHistoryForRelease(final Integer releaseId,
            final PagingFilter pagingFilter) {
        return executeQueryWithPaging(pagingFilter, Deployment.class, new PagingQueryBuilder() {

            @Override
            public String getQuery() {
                return "from Deployment d where d.releaseId = :releaseId and d.deploymentStatus not in (:deploymentStatus) order by d.deployTime desc";
            }

            @Override
            public String getCountQuery() {
                return "from Deployment where releaseId = :releaseId and deploymentStatus not in (:deploymentStatus)";
            }

            @Override
            public void bindArguments(final Query query) {
                query.setInteger("releaseId", releaseId);
                excludeOutstandingDeployments(query);
            }
        });
    }

    @Override
    public PagingResult<DeployedArtifact> getDeploymentHistoryForArtifact(final ArtifactConfig artifact,
            final String host,
            final PagingFilter pagingFilter) {
        return executeQueryWithPaging(pagingFilter, DeployedArtifact.class, new PagingQueryBuilder() {
            @Override
            public String getQuery() {
                return "select da from DeployedArtifact da join da.envDeployment ed join ed.deployment d where da.groupId = :groupId and da.artifactId = :artifactId and da.name = :name and da.hostname = :host and ed.environment = :environment and d.deploymentStatus not in (:deploymentStatus) order by d.deployTime desc";
            }

            @Override
            public String getCountQuery() {
                return "from DeployedArtifact da join da.envDeployment ed join ed.deployment d where da.groupId = :groupId and da.artifactId = :artifactId and da.name = :name and da.hostname = :host and ed.environment = :environment and d.deploymentStatus not in (:deploymentStatus)";
            }

            @Override
            public void bindArguments(final Query query) {
                query.setString("groupId", artifact.getGroupId());
                query.setString("artifactId", artifact.getArtifactId());
                query.setString("name", artifact.getName());
                query.setParameter("environment", artifact.getEnvironment());
                query.setString("host", host);
                excludeOutstandingDeployments(query);
            }
        });
    }

    /**
     * {@inheritDoc}
     * <p>
     * Note this implementation does not make use of hibernate as performance was poor, and attempted optimisations
     * resulted in the wrong data being returned.
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<EnvDeployment> getLatestDeploymentsForReleasesByEnv(final List<Integer> releaseIds) {

        if (releaseIds.isEmpty()) {
            return Collections.emptyList();
        }

        SQLQuery query = getSession()
                .createSQLQuery(
                        "select d.id, d.release_id, d.deploystatus, d.DEPLOYMENT_TYPE, e.deploystatus as envdeploystatus, en.name "
                                +
                                "from {h-schema}Env_Deployment e, {h-schema}Deployments d, {h-schema}Environments en  "
                                +
                                "where e.deployment_id = d.id " +
                                "and d.release_Id in (:releaseIds) " +
                                "and e.environment_id = en.id " +
                                "and (e.environment_id, d.deployTime) in " +
                                "  (select e2.environment_id, max(d2.deployTime) " +
                                "    from {h-schema}Env_Deployment e2, {h-schema}Deployments d2  " +
                                "    where e2.deployment_id = d2.id " +
                                "    and d2.release_Id = d.release_id " +
                                "    and e2.deployStatus not in (:deploymentStatus) " +
                                "    group by e2.environment_id " +
                                "   )" +
                                "order by en.name");

        query.addScalar("id", BinaryType.INSTANCE)
                .addScalar("release_id", IntegerType.INSTANCE)
                .addScalar("deploystatus", StringType.INSTANCE)
                .addScalar("DEPLOYMENT_TYPE", StringType.INSTANCE)
                .addScalar("envdeploystatus", StringType.INSTANCE)
                .addScalar("name", StringType.INSTANCE);

        query.setParameterList("releaseIds", releaseIds);
        excludeOutstandingDeployments(query);

        List<Object[]> results = query.list();
        List<EnvDeployment> envDeployments = new ArrayList<>();
        for (Object[] result : results) {
            UUID deploymentId = ToBytesTransformer.INSTANCE.parse(result[0]);

            Deployment deployment = new Deployment();
            deployment.setId(deploymentId);
            deployment.setReleaseId((Integer) result[1]);
            deployment.setDeploymentStatus(DeploymentStatus.valueOf((String) result[2]));
            deployment.setDeploymentType(DeploymentType.valueOf((String) result[3]));

            Environment env = new Environment();
            env.setName((String) result[5]);

            EnvDeployment envDeployment = new EnvDeployment(deployment, env,
                    DeploymentStatus.valueOf((String) result[4]));
            envDeployments.add(envDeployment);
        }
        return envDeployments;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<EnvDeployment> getLatestDeploymentsForReleaseByEnv(final Integer releaseId) {
        Query query = getSession()
                .createQuery(
                        "select e from EnvDeployment e join e.deployment d where d.releaseId = :releaseId and (e.environment, d.deployTime) in  "
                                + "(select e2.environment, max(d2.deployTime) from EnvDeployment e2 join e2.deployment d2 where d2.releaseId = d.releaseId and e2.deploymentStatus != :deploymentStatus group by e2.environment) "
                                + "order by e.environment");

        query.setInteger("releaseId", releaseId);
        query.setString("deploymentStatus", DeploymentStatus.PLAN.name());

        return query.list();
    }

    @Override
    public EnvDeployment getLatestDeploymentForReleaseInEnv(final Integer releaseId, final String environment) {
        Query query = getSession()
                .createQuery(
                        "select ed from EnvDeployment ed join ed.deployment d join ed.environment e where d.releaseId = :releaseId and e.name = :environment and d.deploymentStatus not in (:deploymentStatus) order by deployTime desc");
        query.setInteger("releaseId", releaseId);
        query.setString("environment", environment);
        excludeOutstandingDeployments(query);
        query.setMaxResults(1);

        return (EnvDeployment) query.uniqueResult();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<EnvDeployment> getAllDeploymentsForReleaseInEnv(final Integer releaseId, final String environment) {
        Query query = getSession()
                .createQuery(
                        "select ed from EnvDeployment ed join ed.deployment d join ed.environment e where d.releaseId = :releaseId and e.name = :environment and d.deploymentStatus not in (:deploymentStatus) order by deployTime");
        query.setInteger("releaseId", releaseId);
        query.setString("environment", environment);
        excludeOutstandingDeployments(query);

        return query.list();
    }

    @Override
    public Deployment loadDeployment(final UUID id) {
        return loadExpected(Deployment.class, id);
    }

    /**
     * Scheduled job runs every hour
     */
    @Transactional
    public void purgeOldUndeployedPlans() {
        final String oldDeploymentFilter = " d.createdTime < :createdTime and d.deploymentStatus = :deploymentStatus";

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR_OF_DAY, -24);

        executeDeleteQuery(
                "delete from DeployedArtifact a where exists (from EnvDeployment e join e.deployment d where a.envDeployment = e and "
                        + oldDeploymentFilter + ")", cal);

        executeDeleteQuery(
                "delete from EnvDeployment e where e.deployment in (select id from Deployment d where "
                        + oldDeploymentFilter + ")", cal);

        int deleteCount = executeDeleteQuery("delete from Deployment d where " + oldDeploymentFilter, cal);

        LOG.info("Purged {} undeployed deployment plan records", deleteCount);
    }

    private int executeDeleteQuery(final String deleteStatement, final Calendar cal) {
        Query query = getSession().createQuery(deleteStatement);
        query.setCalendarDate("createdTime", cal);
        query.setString("deploymentStatus", DeploymentStatus.PLAN.name());
        return query.executeUpdate();
    }

    @Override
    @Transactional
    public void saveDeployment(final Deployment deployment) {
        getSession().update(deployment);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<DailyDeploymentStats> getDailyDeploymentStats(final String organisation) {
        return getSession()
                .createQuery(
                        "select new com.ubs.f35.swift.dao.DailyDeploymentStats(trunc(d.deployTime), e.name, count(d.id)) from Deployment d join d.envDeployments ed join ed.environment e join e.organisation o "
                                + "where d.deployTime != null and d.deploymentType = 'Release' and d.deploymentStatus in ('MANUAL','COMPLETED') "
                                + "and o.name = :organisation "
                                + "group by e.name, trunc(d.deployTime) order by 1,2")
                .setString("organisation", organisation)
                .list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Deployment> getRunningDeployments(final String organisation) {
        return getSession()
                .createQuery(
                        "select d from Deployment d join d.envDeployments ed join ed.environment e join e.organisation o "
                                + "where o.name = :organisation and d.deploymentStatus = :deploymentStatus")
                .setString("organisation", organisation)
                .setString("deploymentStatus", DeploymentStatus.EXECUTING.name())
                .list();
    }

    private void excludeOutstandingDeployments(final Query query) {
        Properties params = new Properties();
        params.put(EnumType.ENUM, DeploymentStatus.class.getName());
        params.put(EnumType.TYPE, String.valueOf(Types.VARCHAR));
        params.put(EnumType.NAMED, String.valueOf(true));

        Type userEnumType = new TypeLocatorImpl(new TypeResolver()).custom(EnumType.class, params);

        query.setParameterList("deploymentStatus", OUTSTANDING_DEPLOYMENT_STATUSES, userEnumType);
    }
}
