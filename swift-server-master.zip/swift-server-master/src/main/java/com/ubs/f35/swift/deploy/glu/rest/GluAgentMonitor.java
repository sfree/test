package com.ubs.f35.swift.deploy.glu.rest;

import java.util.List;

import org.linkedin.zookeeper.tracker.NodeEvent;
import org.linkedin.zookeeper.tracker.NodeEventType;
import org.linkedin.zookeeper.tracker.NodeEventsListener;
import org.springframework.beans.factory.annotation.Required;

/**
 * Watches for updates to agents managed by glu.
 * 
 * @author stephelu
 * 
 */
public class GluAgentMonitor extends ZookeeperMonitor implements NodeEventsListener<Object> {
    private List<AgentStateChangeListener> agentStateChangeListeners;

    @Override
    void onEvent(final NodeEvent<Object> nodeEvent) {
        boolean alive = nodeEvent.getEventType() != NodeEventType.DELETED;

        notifyAgentChanged(nodeEvent.getName(), alive);
    }

    private void notifyAgentChanged(final String agent, final boolean alive) {
        for (AgentStateChangeListener agentStateChangeListener : agentStateChangeListeners) {
            agentStateChangeListener.agentStateChanged(environment, agent, alive);
        }
    }

    @Required
    public void setAgentStateChangeListeners(final List<AgentStateChangeListener> agentStateChangeListeners) {
        this.agentStateChangeListeners = agentStateChangeListeners;
    }

}
