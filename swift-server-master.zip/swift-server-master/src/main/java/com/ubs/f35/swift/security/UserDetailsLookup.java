package com.ubs.f35.swift.security;

import java.util.Map;

public interface UserDetailsLookup {

    Map<String, Object> getUserDetails(String guid);

}