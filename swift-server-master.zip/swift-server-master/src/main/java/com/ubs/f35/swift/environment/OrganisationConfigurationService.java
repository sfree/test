package com.ubs.f35.swift.environment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.web.client.RestTemplate;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.ComparisonChain;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ubs.f35.swift.artifact.ArtifactResolver;
import com.ubs.f35.swift.artifact.NexusArtifactResolver;
import com.ubs.f35.swift.artifact.NexusArtifactRssFeedWatcherFactory;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.EnvironmentConfig;
import com.ubs.f35.swift.config.model.GluScriptMetadata;
import com.ubs.f35.swift.config.model.NexusConfig;
import com.ubs.f35.swift.config.model.OrganisationConfig;
import com.ubs.f35.swift.dao.OrganisationDao;
import com.ubs.f35.swift.dao.event.EnvironmentChangeListener;
import com.ubs.f35.swift.dao.event.OrganisationChangeListener;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.Organisation;
import com.ubs.f35.swift.document.ArtifactEntryConvertorPostProcessor;
import com.ubs.f35.swift.plugin.SwiftPlugin;
import com.ubs.f35.swift.processor.ProcessorUtil;
import com.ubs.f35.swift.properties.NexusURLBuilder;
import com.ubs.f35.swift.properties.PropertyKeysDiscoverer.Packaging;

/**
 * Wires up environment specific configuration.
 * <p>
 * Note that this class is not unit tested. We don't verify that spring wiring xml has worked as expected, and just
 * because this has been migrated to java (because it didn't fit the traditional spring model) doesn't mean that it
 * should be unit tested.
 * 
 */
public class OrganisationConfigurationService extends BaseConfigurationService<Organisation, OrganisationConfig>
        implements OrganisationChangeListener, EnvironmentChangeListener, InitializingBean, ApplicationContextAware {

    private ConfigurableOrganisationBeanProvider<List<String>> orgReleaseLockdownRole;
    private ConfigurableOrganisationBeanProvider<List<String>> orgReleaseModifyRole;
    private ConfigurableOrganisationBeanProvider<List<String>> sodAccessRightsFactory;
    private ConfigurableOrganisationBeanProvider<Packaging> organisationPackaging;
    private ConfigurableOrganisationBeanProvider<List<String>> orgScriptsMap;
    private ConfigurableOrganisationBeanProvider<List<GluScriptMetadata>> orgScriptsMetadataMap;
    private ConfigurableOrganisationBeanProvider<List<String>> orgEnvironmentsMap;
    private ConfigurableOrganisationBeanProvider<ArtifactResolver> artifactResolverFactory;
    private ConfigurableOrganisationBeanProvider<NexusURLBuilder> nexusURLBuilderFactory;
    private ConfigurableOrganisationBeanProvider<OrganisationConfig> orgConfigFactory;
    private ConfigurableOrganisationBeanProvider<ArtifactEntryConvertorPostProcessor> artifactEntryConvertorPostProcessorFactory;

    private NexusArtifactRssFeedWatcherFactory nexusArtifactRssFeedWatcherFactory;
    private OrganisationDao organisationDao;
    private RestTemplate nexusRestTemplate;
    private ConfigurableEnvironmentBeanProvider<EnvironmentConfig> envConfigFactory;
    private ApplicationContext appContext;

    public OrganisationConfigurationService() {
        super(OrganisationConfig.class);
    }

    @Override
    public void afterUpdate(final Environment environment) {
        // If an environment is added to the organisation, then the orgEnvironmentsMap needs updating.
        afterUpdate(environment.getOrganisation());
    }

    @Override
    public void afterUpdate(final Organisation organisation) {
        try {
            update(organisation);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    void update(final Organisation organisationObj, final OrganisationConfig config) throws Exception {
        final String organisation = organisationObj.getName();

        orgConfigFactory.set(organisation, config);

        orgReleaseLockdownRole.set(organisation, config.getReleaseLockDownAccessRights());
        orgReleaseModifyRole.set(organisation, config.getReleaseModifyAccessRights());
        sodAccessRightsFactory.set(organisation, config.getSodAccessRights());
        organisationPackaging.set(organisation, config.getArtifactPackaging());

        orgScriptsMetadataMap.set(organisation, config.getGluScriptsConfig());
        List<String> scripts = ProcessorUtil.transform(config.getGluScriptsConfig(),
                new Function<GluScriptMetadata, String>() {
                    @Override
                    public String apply(final GluScriptMetadata input) {
                        return input.getName();
                    }
                });
        orgScriptsMap.set(organisation, scripts);

        setOrgEnvironmentNamesMap(organisation);

        NexusConfig nexusConfig = config.getNexusConfig();

        NexusArtifactResolver resolver = new NexusArtifactResolver();
        resolver.setClassifier(nexusConfig.getClassifier());
        resolver.setNexusSearchUrl(nexusConfig.getSearchUrl());
        resolver.setPackaging(nexusConfig.getPackaging());
        resolver.setRepositoryId(nexusConfig.getRepository());
        resolver.setResolverId(nexusConfig.getNexusId());
        resolver.setTemplate(nexusRestTemplate);

        artifactResolverFactory.set(organisation, resolver);

        NexusURLBuilder nexusURLBuilder = new NexusURLBuilder();
        nexusURLBuilder.setNexusContentUrl(nexusConfig.getContentUrl());
        nexusURLBuilder.setRepositoryId(nexusConfig.getRepository());
        nexusURLBuilder.setResolverId(nexusConfig.getNexusId());

        nexusURLBuilderFactory.set(organisation, nexusURLBuilder);

        nexusArtifactRssFeedWatcherFactory.configurePollingForOrganisation(organisation, nexusConfig.getPollerUrl(),
                nexusConfig.getPollerUsername(), nexusConfig.getPollerPassword(), nexusConfig.getPollerRepositories());

        registerOrganisationPlugins(organisation, config);
    }

    private void registerOrganisationPlugins(final String organisation, final OrganisationConfig config) {
        for (String pluginClassName : config.getPlugins()) {
            Class<?> pluginClass;
            try {
                pluginClass = Class.forName(pluginClassName);
                Object pluginInstance = pluginClass.newInstance();
                if (SwiftPlugin.class.isAssignableFrom(pluginClass)) {
                    ((SwiftPlugin) pluginInstance).initialise(appContext);
                }

                registerWithFactory(organisation, artifactEntryConvertorPostProcessorFactory,
                        ArtifactEntryConvertorPostProcessor.class, pluginInstance);
            } catch (Exception e) {
                throw new RuntimeException("Unable to wire up plugin " + pluginClassName, e);
            }
        }

        registerDefaultPlugin(organisation, artifactEntryConvertorPostProcessorFactory,
                new ArtifactEntryConvertorPostProcessor() {
                    @Override
                    public void enrich(final ArtifactConfig artifact,
                            final com.ubs.f35.swift.environment.model.glu.Entry entry) {
                    }
                });
    }

    private <T> void registerDefaultPlugin(final String organisation,
            final ConfigurableOrganisationBeanProvider<T> beanProvider, final T defaultPluginInstance) {
        if (beanProvider.getAll().get(organisation) == null) {
            beanProvider.set(organisation, defaultPluginInstance);
        }
    }

    @SuppressWarnings("unchecked")
    private <T> void registerWithFactory(final String organisation,
            final ConfigurableOrganisationBeanProvider<T> beanProvider, final Class<T> expectedPluginClass,
            final Object pluginInstance) {
        if (expectedPluginClass.isInstance(pluginInstance)) {
            beanProvider.set(organisation, (T) pluginInstance);
        }
    }

    protected void setOrgEnvironmentNamesMap(final String organisation) {
        Map<Environment, EnvironmentConfig> orgEnvironments = Maps.filterKeys(envConfigFactory.getAll(),
                new Predicate<Environment>() {
                    @Override
                    public boolean apply(final Environment input) {
                        return organisation.equals(input.getOrganisation().getName());
                    }
                });

        ArrayList<Entry<Environment, EnvironmentConfig>> envConfigList = Lists.newArrayList(orgEnvironments.entrySet());
        Collections.sort(envConfigList, new Comparator<Entry<Environment, EnvironmentConfig>>() {
            @Override
            public int compare(final Entry<Environment, EnvironmentConfig> o1,
                    final Entry<Environment, EnvironmentConfig> o2) {
                return ComparisonChain.start()
                        .compare(o1.getValue().getOrder(), o2.getValue().getOrder())
                        .compare(o1.getKey().getName(), o2.getKey().getName()).result();
            }
        });

        Iterable<String> orgEnvironmentNames = Iterables.transform(envConfigList,
                new Function<Entry<Environment, EnvironmentConfig>, String>() {
                    @Override
                    public String apply(final Entry<Environment, EnvironmentConfig> input) {
                        return input.getKey().getName();
                    }
                });

        orgEnvironmentsMap.set(organisation, ImmutableList.copyOf(orgEnvironmentNames));
    }

    @Override
    void init() throws Exception {
        List<Organisation> organisations = organisationDao.loadAll();
        for (Organisation organisation : organisations) {
            update(organisation);
        }
    }

    @Required
    public void setOrganisationDao(final OrganisationDao organisationDao) {
        this.organisationDao = organisationDao;
    }

    @Required
    public void setOrgReleaseLockdownRole(
            final ConfigurableOrganisationBeanProvider<List<String>> orgReleaseLockdownRole) {
        this.orgReleaseLockdownRole = orgReleaseLockdownRole;
    }

    @Required
    public void setOrgReleaseModifyRole(final ConfigurableOrganisationBeanProvider<List<String>> orgReleaseModifyRole) {
        this.orgReleaseModifyRole = orgReleaseModifyRole;
    }

    @Required
    public void setOrganisationPackaging(final ConfigurableOrganisationBeanProvider<Packaging> organisationPackaging) {
        this.organisationPackaging = organisationPackaging;
    }

    @Required
    public void setOrgScriptsMap(final ConfigurableOrganisationBeanProvider<List<String>> orgScriptsMap) {
        this.orgScriptsMap = orgScriptsMap;
    }

    @Required
    public void setOrgScriptsMetadataMap(
            final ConfigurableOrganisationBeanProvider<List<GluScriptMetadata>> orgScriptsMetadataMap) {
        this.orgScriptsMetadataMap = orgScriptsMetadataMap;
    }

    @Required
    public void setOrgEnvironmentsMap(final ConfigurableOrganisationBeanProvider<List<String>> orgEnvironmentsMap) {
        this.orgEnvironmentsMap = orgEnvironmentsMap;
    }

    @Required
    public void setSodAccessRightsFactory(
            final ConfigurableOrganisationBeanProvider<List<String>> sodAccessRightsFactory) {
        this.sodAccessRightsFactory = sodAccessRightsFactory;
    }

    @Required
    public void setArtifactResolverFactory(
            final ConfigurableOrganisationBeanProvider<ArtifactResolver> artifactResolverFactory) {
        this.artifactResolverFactory = artifactResolverFactory;
    }

    @Required
    public void setNexusURLBuilderFactory(
            final ConfigurableOrganisationBeanProvider<NexusURLBuilder> nexusURLBuilderFactory) {
        this.nexusURLBuilderFactory = nexusURLBuilderFactory;
    }

    @Required
    public void setNexusRestTemplate(final RestTemplate nexusRestTemplate) {
        this.nexusRestTemplate = nexusRestTemplate;
    }

    @Required
    public void setNexusArtifactRssFeedWatcherFactory(
            final NexusArtifactRssFeedWatcherFactory nexusArtifactRssFeedWatcherFactory) {
        this.nexusArtifactRssFeedWatcherFactory = nexusArtifactRssFeedWatcherFactory;
    }

    @Required
    public void setEnvConfigFactory(final ConfigurableEnvironmentBeanProvider<EnvironmentConfig> envConfigFactory) {
        this.envConfigFactory = envConfigFactory;
    }

    @Required
    public void setOrgConfigFactory(final ConfigurableOrganisationBeanProvider<OrganisationConfig> orgConfigFactory) {
        this.orgConfigFactory = orgConfigFactory;
    }

    @Required
    public void setArtifactEntryConvertorPostProcessorFactory(
            final ConfigurableOrganisationBeanProvider<ArtifactEntryConvertorPostProcessor> artifactEntryConvertorPostProcessorFactory) {
        this.artifactEntryConvertorPostProcessorFactory = artifactEntryConvertorPostProcessorFactory;
    }

    @Override
    public void setApplicationContext(final ApplicationContext appContext) throws BeansException {
        this.appContext = appContext;
    }
}
