package com.ubs.f35.swift.model;

import java.util.Date;
import java.util.List;

import com.google.common.base.Objects;

public class ReleaseFilters {
    private String organisation;
    private String name;
    private List<String> team;
    private List<String> group;
    private List<String> artifact;

    /**
     * Show only upcoming releases, soonest first (by default, unless a sort other than releaseDate is specified)
     */
    private boolean upcoming;

    private Date startDate;

    private Date endDate;

    private Sort ordering;

    public enum Sort {

        CREATED("createdTime", true),
        UPDATED("lastUpdatedTime", true),
        RELEASE_DATE("releaseDate", false);

        private final String columnName;
        private final boolean descending;

        Sort(final String columnName, final boolean descending) {
            this.columnName = columnName;
            this.descending = descending;
        }

        public String columnName() {
            return columnName;
        }

        public boolean descending() {
            return descending;
        }

    }

    public String getOrganisation() {
        return organisation;
    }

    public void setOrganisation(final String organisation) {
        this.organisation = organisation;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public List<String> getGroup() {
        return group;
    }

    public void setGroup(final List<String> group) {
        this.group = group;
    }

    public List<String> getArtifact() {
        return artifact;
    }

    public void setArtifact(final List<String> artifact) {
        this.artifact = artifact;
    }

    public List<String> getTeam() {
        return team;
    }

    public void setTeam(final List<String> team) {
        this.team = team;
    }

    public boolean isUpcoming() {
        return upcoming;
    }

    public void setUpcoming(final boolean upcoming) {
        this.upcoming = upcoming;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(final Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(final Date endDate) {
        this.endDate = endDate;
    }

    public Sort getOrdering() {
        return ordering;
    }

    public void setOrdering(final Sort ordering) {
        this.ordering = ordering;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(organisation, name, team, group, artifact, upcoming, startDate, endDate, ordering);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ReleaseFilters) {
            ReleaseFilters that = (ReleaseFilters) object;
            return Objects.equal(this.name, that.name)
                    && Objects.equal(this.organisation, that.organisation)
                    && Objects.equal(this.team, that.team)
                    && Objects.equal(this.group, that.group)
                    && Objects.equal(this.artifact, that.artifact)
                    && Objects.equal(this.upcoming, that.upcoming)
                    && Objects.equal(this.startDate, that.startDate)
                    && Objects.equal(this.endDate, that.endDate)
                    && Objects.equal(this.ordering, that.ordering);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("name", name)
                .add("organisation", organisation)
                .add("team", team)
                .add("group", group)
                .add("artifact", artifact)
                .add("upcoming", upcoming)
                .add("startDate", startDate)
                .add("endDate", endDate)
                .add("ordering", ordering)
                .toString();
    }

}
