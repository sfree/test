package com.ubs.f35.swift.dao;

import java.util.UUID;

import com.ubs.f35.swift.dao.model.StateModel;

public interface StateDao {
    StateModel load(final UUID stateId);

    void save(StateModel stateModel);
}
