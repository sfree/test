package com.ubs.f35.swift.deploy.validator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import javax.xml.ws.WebServiceException;
import javax.xml.ws.soap.SOAPFaultException;

import org.apache.commons.lang.StringUtils;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.linkedin.util.clock.Clock;
import org.linkedin.util.clock.SystemClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.config.model.EnvironmentConfig;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.Organisation;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlanBuilder;
import com.ubs.f35.swift.deploy.glu.plan.Warning;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.model.EnvironmentDeploymentSummary;
import com.ubs.f35.swift.model.EnvironmentDeploymentSummary.EnvironmentDeploymentStatus;
import com.ubs.f35.swift.model.ReleaseLogicException;
import com.ubs.f35.swift.model.ReleaseUnlockedException;
import com.ubs.f35.swift.processor.ReleaseQueryProcessor;
import com.ubs.f35.swift.service.EnvironmentDeploymentSummaryBuilder;
import com.ubs.swift.rnow.ChangeRequestDetails;
import com.ubs.swift.rnow.Link;
import com.ubs.swift.rnow.ServiceNowClient;

/**
 * Validates conditions necessary for a production deployment to take place.
 * 
 * @author levyjo
 * 
 */
public class ProductionDeploymentValidator implements ReleaseDeploymentPlanValidator {
    private static final Logger LOG = LoggerFactory.getLogger(ProductionDeploymentValidator.class);

    private static final String CHANGE_TYPE_STANDARD = "Standard";

    private static DateTimeFormatter DATE_TIME_FORMAT = DateTimeFormat.forPattern("d MMM yy hh:mm 'Z'");
    private static final Set<String> VALID_CHANGE_STATUSES = Sets.newHashSet("Approved");

    private EnvironmentDocumentStore environmentDocumentStore;
    private EnvironmentDeploymentSummaryBuilder environmentDeploymentSummaryBuilder;
    private EnvironmentBeanFactory<EnvironmentConfig> envConfigFactory;
    private ServiceNowClient serviceNowClient;
    private Clock clock = SystemClock.INSTANCE;

    /**
     * Checks that there has been a successful up-to-date deployment of the given release in a pre-production staging
     * environment. Otherwise, a warning is added to the Deployment Plan. This method also calls
     * {@link #validateReleaseLocked(ReleaseDefinition, String)} to make sure the release is locked (otherwise an
     * up-to-date deployment cannot be guaranteed). If the given environment is not a production environment, this
     * method does not do any checks and simply returns.
     * 
     * @param builder
     * @param releaseDefinition
     * @param environment
     *            The environment being deployed to
     * @param rollback
     */
    @Override
    public void validate(final DeploymentPlanBuilder builder, final ReleaseDefinition releaseDefinition,
            final Environment environment, final boolean rollback) {

        if (!environmentDocumentStore.isProdEnvironment(environment)) {
            return;
        }

        List<Warning> warnings = validateProductionReleaseChecks(releaseDefinition, environment, rollback);
        for (Warning warning : warnings) {
            builder.addWarning(warning);
        }

        List<String> stagingEnvironments = getStagingEnvironmentsForOrg(releaseDefinition.getTeam().getOrganisation());
        EnvironmentDeploymentSummary environmentDeploymentSummary;
        for (String preProdEnv : stagingEnvironments) {
            environmentDeploymentSummary = environmentDeploymentSummaryBuilder.getEnvironmentDeploymentSummary(
                    releaseDefinition.getId(), preProdEnv);
            if (environmentDeploymentSummary != null
                    && environmentDeploymentSummary.getStatus() == EnvironmentDeploymentStatus.COMPLETED) {
                return;
            }
        }

        String stagingEnvs = stagingEnvironments.isEmpty() ? "" : "(" + StringUtils.join(stagingEnvironments, ", ")
                + ") ";
        String warningMsg = "This release has not been successfully deployed to any staging environment! Please deploy to a staging environment "
                + stagingEnvs + "first.";

        builder.addWarning(new Warning(Warning.Code.NoSuccessfulStagingDeployment, warningMsg));
        // TODO: should we make this an exception rather than a warning?
        // throw new NoStagingDeploymentException(releaseDefinition);

    }

    /**
     * Performs production release checks if the deployment is to production.
     */
    public List<Warning> validateProductionReleaseChecks(final ReleaseDefinition releaseDefinition,
            final Environment environment, final boolean rollback) {

        if (!environmentDocumentStore.isProdEnvironment(environment)) {
            return Collections.emptyList();
        }

        List<Warning> warnings = Lists.newArrayList();

        validateReleaseLocked(releaseDefinition, environment);
        validateChangeRequest(warnings, releaseDefinition, false, rollback);

        return warnings;
    }

    /**
     * Checks if the release has all the required configuration for a production deployment. This means it must be
     * linked to a RNOW change request and the RNOW change request must correctly link back to this release. If not, the
     * user can be informed and rectify the situation.
     * 
     * @return
     */
    public List<Warning> validateReleaseSetupForProductionDeployment(final ReleaseDefinition releaseDefinition) {
        List<Warning> warnings = Lists.newArrayList();

        validateChangeRequest(warnings, releaseDefinition, true, false);

        return warnings;
    }

    private List<String> getStagingEnvironmentsForOrg(final Organisation organisation) {
        List<String> stagingEnvironments = new ArrayList<>();
        for (Entry<Environment, EnvironmentConfig> config : envConfigFactory.getAll().entrySet()) {
            if (organisation.equals(config.getKey().getOrganisation()) && config.getValue().isStagingEnvironment()) {
                stagingEnvironments.add(config.getKey().getName());
            }
        }
        return stagingEnvironments;
    }

    /**
     * Check that the release definition has been locked. Throws a {@link ReleaseUnlockedException} if not. If the
     * specified environment is not a production environment, this method does not check anything and simple returns.
     * 
     * @param releaseDefinition
     * @param environment
     */
    private void validateReleaseLocked(final ReleaseDefinition releaseDefinition, final Environment environment) {
        if (!releaseDefinition.isLocked()) {
            throw new ReleaseUnlockedException(releaseDefinition);
        }
    }

    /**
     * Validates the change request is in a healthy state to allow a production deployment.
     * <p>
     * For rollback, the implementation window and approval status checks are relaxed and the user may confirm a rnow
     * warning.
     * 
     * @param preDeploymentChecks
     *            Only perform the checks that can be done in advance of the deployment.
     * @param rollback
     *            if true then rnow checks are relaxed.
     */
    private void validateChangeRequest(final List<Warning> warnings, final ReleaseDefinition releaseDefinition,
            final boolean preDeploymentChecks, final boolean rollback) {

        String changeRequestId = ReleaseQueryProcessor.extractChangeRequest(releaseDefinition);

        if (changeRequestId == null) {
            addRnowWarning(warnings, "Release must be linked to a RNOW change request to be deployed to production");
            return;
        }

        ChangeRequestDetails changeDetails;
        try {
            changeDetails = serviceNowClient.retrieveEssentialDetails(changeRequestId);
        } catch (SOAPFaultException ex) {// If the user provides an invalid change request id, RNOW will return a
                                         // SOAPFaultException when we attempt to retrieve the details.
            LOG.warn("Exception returned from RNOW", ex);
            addRnowWarning(warnings, "Error returned from RNOW: " + ex.getMessage() + ".  Please check manaully.");
            return;
        } catch (WebServiceException ex) {
            LOG.error("Unable to call RNOW", ex);
            addRnowWarning(warnings, "Unable to check change request " + changeRequestId
                    + " in RNOW.  Please check manaully.");
            return;
        }

        if (changeDetails.getLinks() == null || !Iterables.any(changeDetails.getLinks(), new Predicate<Link>() {
            @Override
            public boolean apply(final Link input) {
                return input.getLinkUrl() != null
                        && input.getLinkUrl().endsWith("/release/" + releaseDefinition.getId());
            }
        })) {
            addRnowWarning(warnings, "Change request " + changeRequestId + " does not have a link to this release");
        }

        if (!preDeploymentChecks) {
            if (!VALID_CHANGE_STATUSES.contains(changeDetails.getChangeStatus())) {
                // Do not allow deployment of Standard changes unless Approved (or rollback). Allow emergency /
                // break-fix changes
                if (CHANGE_TYPE_STANDARD.equals(changeDetails.getChangeType())) {
                    String message = "Standard change request " + changeRequestId
                            + " is not in a valid state for production deployment. Current state "
                            + changeDetails.getChangeStatus();
                    addRnowWarning(warnings, message, !rollback);
                } else {
                    addRnowWarning(warnings, changeDetails.getChangeType() + " change request " + changeRequestId
                            + " is not approved in RNOW. Current state " + changeDetails.getChangeStatus());
                }
            }

            if (changeDetails.getStartDate() == null || changeDetails.getEndDate() == null) {
                throw new ReleaseLogicException("Change " + changeRequestId + " requires a start and end date");
            }

            if (changeDetails.getStartDate().isAfter(clock.currentTimeMillis())) {
                addImplementationDateWarning(warnings, "before", changeDetails, changeRequestId);
            } else if (changeDetails.getEndDate().isBefore(clock.currentTimeMillis())) {
                addImplementationDateWarning(warnings, "after", changeDetails, changeRequestId);
            }
        }
    }

    private void addImplementationDateWarning(final List<Warning> warnings, final String issue,
            final ChangeRequestDetails changeDetails, final String changeRequestId) {
        addRnowWarning(
                warnings,
                "Change " + changeRequestId + " is " + issue + " the implementation window "
                        + DATE_TIME_FORMAT.print(changeDetails.getStartDate()) + " to "
                        + DATE_TIME_FORMAT.print(changeDetails.getEndDate()));
    }

    private void addRnowWarning(final List<Warning> warnings, final String warning) {
        addRnowWarning(warnings, warning, false);
    }

    private void addRnowWarning(final List<Warning> warnings, final String warning, final boolean blockDeployment) {
        if (blockDeployment) {
            throw new ReleaseLogicException(warning);
        } else {
            warnings.add(new Warning(warning, true));
        }
    }

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

    @Required
    public void setEnvironmentDeploymentSummaryBuilder(
            final EnvironmentDeploymentSummaryBuilder environmentDeploymentSummaryBuilder) {
        this.environmentDeploymentSummaryBuilder = environmentDeploymentSummaryBuilder;
    }

    @Required
    public void setEnvConfigFactory(final EnvironmentBeanFactory<EnvironmentConfig> envConfigFactory) {
        this.envConfigFactory = envConfigFactory;
    }

    @Required
    public void setServiceNowClient(final ServiceNowClient serviceNowClient) {
        this.serviceNowClient = serviceNowClient;
    }

    @VisibleForTesting
    void setClock(final Clock clock) {
        this.clock = clock;
    }
}
