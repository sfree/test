package com.ubs.f35.swift.environment.model.glu;

import java.util.List;
import java.util.Map;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.google.common.base.Objects;

public class Entry {
    private Map<String, Object> initParameters;
    private String mountPoint;
    private String agent;
    private Script script;
    private List<String> tags;
    private boolean coldStandby;

    private transient String groupId;
    private transient String artifactId;
    private transient String version;
    private transient String name;

    public Entry() {
    }

    public Map<String, Object> getInitParameters() {
        return initParameters;
    }

    public void setInitParameters(final Map<String, Object> initParameters) {
        this.initParameters = initParameters;
    }

    public String getMountPoint() {
        return mountPoint;
    }

    public void setMountPoint(final String mountPoint) {
        this.mountPoint = mountPoint;
    }

    public String getAgent() {
        return agent;
    }

    public void setAgent(final String agent) {
        this.agent = agent;
    }

    @JsonIgnore
    public Script getScript() {
        return script;
    }

    public void setScript(final Script script) {
        this.script = script;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(final List<String> tags) {
        this.tags = tags;
    }

    public boolean isColdStandby() {
        return coldStandby;
    }

    public void setColdStandby(final boolean coldStandby) {
        this.coldStandby = coldStandby;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("initParameters", initParameters)
                .add("mountPoint", mountPoint)
                .add("agent", agent)
                .add("script", script)
                .add("tags", tags)
                .add("coldStandby", coldStandby)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(initParameters, mountPoint, agent, script, tags);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof Entry) {
            Entry that = (Entry) object;
            return Objects.equal(this.initParameters, that.initParameters)
                    && Objects.equal(this.mountPoint, that.mountPoint)
                    && Objects.equal(this.agent, that.agent)
                    && Objects.equal(this.script, that.script)
                    && Objects.equal(this.tags, that.tags)
                    && Objects.equal(this.coldStandby, that.coldStandby);
        }
        return false;
    }

    @JsonIgnore
    public String getGroupId() {
        if (groupId == null) {
            groupId = getProject().get("g");
        }
        return groupId;
    }

    @JsonIgnore
    public String getArtifactId() {
        if (artifactId == null) {
            artifactId = getProject().get("a");
        }
        return artifactId;
    }

    @JsonIgnore
    public String getVersion() {
        if (version == null) {
            version = getProject().get("v");
        }
        return version;
    }

    @JsonIgnore
    public String getName() {
        if (name == null) {
            name = getProject().get("name");
        }
        return name;
    }

    @SuppressWarnings("unchecked")
    private Map<String, String> getProject() {
        return (Map<String, String>) initParameters.get("project");
    }

}
