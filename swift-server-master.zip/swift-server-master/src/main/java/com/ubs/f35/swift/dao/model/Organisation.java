package com.ubs.f35.swift.dao.model;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.hibernate.annotations.NaturalId;
import org.hibernate.envers.Audited;

import com.google.common.base.Objects;

/**
 * Note that id is intentionally not used in {@link #equals(Object)} and {@link #hashCode()} so that instances of this
 * object can be used as the keys of Maps.
 */
@SequenceGenerator(name = "oracle_seq", sequenceName = "seq_org_id")
@Entity
@Table(name = "organisations")
@Audited
public class Organisation implements Configurable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "oracle_seq")
    private Integer id;
    @NaturalId
    private String name;
    // Do not reference this property in hashcode, equals, etc. Doing so will initialise it.
    // Note that this requires bytecode instrumentation which is applied to this class by maven.
    @Column
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonIgnore
    private String configuration;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    @Override
    public String getConfiguration() {
        return configuration;
    }

    @Override
    public void setConfiguration(final String configuration) {
        this.configuration = configuration;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof Organisation) {
            Organisation that = (Organisation) object;
            return Objects.equal(this.name, that.name);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("name", name)
                .toString();
    }
}
