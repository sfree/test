package com.ubs.f35.swift.deploy.glu.action;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.DeploymentInvoker;
import com.ubs.f35.swift.deploy.glu.DeploymentState;
import com.ubs.f35.swift.deploy.glu.state.Transition;
import com.ubs.f35.swift.deploy.glu.state.Transition.TransitionStep;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.model.ArtifactInstanceId;
import com.ubs.f35.swift.model.EnvironmentId;

public class TransitionAction implements Action {

    private final String transition;
    private final String artifactInstanceIdString;
    private DeploymentState deploymentState;
    private transient final ArtifactInstanceId artifactInstanceId;
    private transient final String mountPoint;

    public TransitionAction(final ArtifactInstanceId artifactInstanceId, final String transition) {
        this.artifactInstanceIdString = artifactInstanceId != null ? artifactInstanceId.toString() : null;
        this.artifactInstanceId = artifactInstanceId;
        this.transition = transition;
        this.mountPoint = artifactInstanceId != null ? artifactInstanceId.getMountPoint() : null;
    }

    public TransitionAction(final ArtifactInstanceId artifactInstanceId, final Transition.TransitionStep transition) {
        this(artifactInstanceId, transition.name());
    }

    /**
     * Constructor used for unmarshalling JSON from DB
     */
    public TransitionAction(
            @JsonProperty(value = "artifactInstanceId") final String artifactInstanceId,
            @JsonProperty(value = "entry") final Entry entry,
            @JsonProperty(value = "name") final String transition,
            @JsonProperty(value = "deploymentState") final DeploymentState deploymentState) {
        this.artifactInstanceIdString = artifactInstanceId;
        if (artifactInstanceId == null) {
            // legacy deployment plans saved with entry rather than ArtifactInstanceId
            this.artifactInstanceId = null;
            this.mountPoint = entry != null ? entry.getMountPoint() : null;
        } else {
            this.artifactInstanceId = ArtifactInstanceId.parse(artifactInstanceId);
            this.mountPoint = this.artifactInstanceId.getMountPoint();
        }
        this.transition = transition;
        this.deploymentState = deploymentState;
    }

    @Override
    public String getName() {
        return transition;
    }

    @JsonIgnore
    @Override
    public String getId() {
        return transition + "-" + mountPoint;
    }

    @Override
    public DeploymentState getDeploymentState() {
        return deploymentState;
    }

    @JsonProperty("artifactInstanceId")
    public String getArtifactInstanceIdString() {
        return artifactInstanceIdString;
    }

    @JsonIgnore
    public ArtifactInstanceId getArtifactInstanceId() {
        return artifactInstanceId;
    }

    @Override
    public void setDeploymentState(final DeploymentState deploymentState) {
        this.deploymentState = deploymentState;
    }

    public void execute(final DeploymentContext context) {
        // Note that we don't use the entry set on the action during the deployment plan generation as that
        // entry may have since been updated. This is the case when a release is performed and the artifact version
        // on the entry is updated. If the old entry is used, the old version of the artifact is deployed again.

        EnvironmentId envId = artifactInstanceId.getEnvironment();
        Environment env = new Environment(envId.getEnvironmentName(), envId.getOrganisationName());

        Entry liveEntry = context.getEnvironmentDocumentStore()
                .filterByMountPoint(env, artifactInstanceId.getMountPoint());

        execute(context.getDeploymentInvoker(env), liveEntry);
    }

    protected void execute(final DeploymentInvoker deploymentInvoker, final Entry liveEntry) {
        // Conversion to enum is delayed so that if just rendering a historical deployment plan the value can be
        // unmarshalled even if that transition step no longer exists in the enum.
        deploymentInvoker.executeTransition(liveEntry, TransitionStep.valueOf(transition));
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(super.hashCode(), transition);
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }

        TransitionAction that = (TransitionAction) obj;

        return Objects.equal(this.transition, that.transition)
                && Objects.equal(this.artifactInstanceIdString, that.artifactInstanceIdString);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("transition", transition)
                .add("artifactInstanceId", artifactInstanceIdString)
                .add("deploymentState", deploymentState)
                .toString();
    }

}
