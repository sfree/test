package com.ubs.f35.swift.deploy.client.action;

import org.codehaus.jackson.annotate.JsonTypeInfo;
import org.codehaus.jackson.annotate.JsonTypeInfo.As;
import org.codehaus.jackson.annotate.JsonTypeInfo.Id;

/**
 * Marks a deployment plan action as suitable for returning to the client. If not, needs to be mapped to a ClientAction.
 */
@JsonTypeInfo(use = Id.CLASS, include = As.PROPERTY, property = "@class")
public interface ClientAction {

    String getId();

}
