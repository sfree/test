package com.ubs.f35.swift.util;

import com.google.common.base.Function;
import com.ubs.f35.swift.dao.model.Environment;

public class EnvironmentNameFunction implements Function<Environment, String> {
    public static final EnvironmentNameFunction INSTANCE = new EnvironmentNameFunction();

    @Override
    public String apply(final Environment input) {
        return input.getName();
    }
}
