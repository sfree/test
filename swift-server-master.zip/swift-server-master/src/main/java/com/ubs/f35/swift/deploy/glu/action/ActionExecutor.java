package com.ubs.f35.swift.deploy.glu.action;


public interface ActionExecutor {
    void execute(DeploymentContext context, Action action);
}