package com.ubs.f35.swift.model;

public class JsonUnmarshallingException extends RuntimeException {

    public JsonUnmarshallingException(final Throwable throwable) {
        super("Unable to unmarshall JSON data", throwable);
    }

    public JsonUnmarshallingException(final Class<?> c, final Throwable throwable) {
        super("Unable to unmarshall JSON data to class " + c.getName(), throwable);
    }

    public JsonUnmarshallingException(final String message, final Throwable throwable) {
        super(message, throwable);
    }

}
