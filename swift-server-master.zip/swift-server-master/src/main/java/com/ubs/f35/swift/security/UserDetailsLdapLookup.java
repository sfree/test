package com.ubs.f35.swift.security;

import java.util.List;
import java.util.Map;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.simple.SimpleLdapTemplate;

import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;

/**
 * Implemented as swift will degrade to displaying guids if pcc is down. UBS doesn't have a simple service to lookup
 * user details for a guid, so have provided this as an alternative.
 */
public class UserDetailsLdapLookup implements UserDetailsLookup {

    private SimpleLdapTemplate ldapTemplate;
    private static final String ATTR_GUID = "ubswGuid";

    protected final AttributesMapper usermapper = new AttributesMapper() {
        @Override
        public Map<String, Object> mapFromAttributes(final Attributes attributes) throws NamingException {
            Map<String, Object> userDetails = Maps.newTreeMap(String.CASE_INSENSITIVE_ORDER);
            NamingEnumeration<? extends Attribute> enumValues = attributes.getAll();
            while (enumValues.hasMore()) {
                Attribute attribute = enumValues.next();
                userDetails.put(attribute.getID(), attribute.get());
            }
            return userDetails;
        }
    };

    @Override
    @SuppressWarnings("unchecked")
    public Map<String, Object> getUserDetails(final String guid) {
        List<Map<String, Object>> result = ldapTemplate.getLdapOperations().search("dc=ubsw,dc=com",
                ATTR_GUID + "=" + guid, usermapper);
        return Iterables.getOnlyElement(result, null);
    }

    @Required
    public void setLdapTemplate(final SimpleLdapTemplate ldapTemplate) {
        this.ldapTemplate = ldapTemplate;
    }

}
