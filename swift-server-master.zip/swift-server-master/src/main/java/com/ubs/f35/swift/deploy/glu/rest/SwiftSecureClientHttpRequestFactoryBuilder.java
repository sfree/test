package com.ubs.f35.swift.deploy.glu.rest;

import java.io.ByteArrayInputStream;

import org.apache.commons.httpclient.contrib.ssl.SwiftAuthSSLProtocolSocketFactory;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.NoopUserTokenHandler;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.linkedin.util.codec.Base64Codec;
import org.linkedin.util.codec.Codec.CannotDecodeException;
import org.linkedin.util.codec.CodecUtils;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.f35.swift.dao.SecurityTemplateDao;
import com.ubs.f35.swift.dao.model.SecurityTemplate;

/**
 * Builds a HTTP connection factory for connections between swift-server and the glu agents. Caching is employed to
 * avoid the slow SSL handshake to establish each connection.
 * <p>
 * Modifies HTTPS connections so that the client is identified to the server using it's key. Glu agents require this to
 * authenticate allowed clients. The identity of the target server is also verified as being known.
 * <p>
 * The SSL Factories are wired up during startup so that any configuration issues are noticed and resolve immediately
 * rather than on the first attempt to perform a deployment to that environment.
 */
public class SwiftSecureClientHttpRequestFactoryBuilder {

    // This is the same encryption key as glu uses. It's used so that passwords are not immediately obvious in
    // configuration files and zookeeper.
    private static final String PASSWORD_ENCRYPTION_KEY = "gluos2way";

    private static final int DEFAULT_MAX_TOTAL_CONNECTIONS = 100;
    private static final int DEFAULT_MAX_CONNECTIONS_PER_ROUTE = 5;

    // injected
    private SecurityTemplateDao securityTemplateDao;

    @Transactional
    public HttpComponentsClientHttpRequestFactory buildForConfig(final String securityTemplateId) throws Exception {
        SecurityTemplate securityTemplate = securityTemplateDao.load(securityTemplateId);

        return buildForConfig(securityTemplate);
    }

    public HttpComponentsClientHttpRequestFactory buildForConfig(final SecurityTemplate securityTemplate) {

        SwiftAuthSSLProtocolSocketFactory sslFactory = new SwiftAuthSSLProtocolSocketFactory(
                new ByteArrayInputStream(securityTemplate.getKeystore()),
                decodeStr(securityTemplate.getKeystorePassword()),
                decodeStr(securityTemplate.getKeyPassword()),
                new ByteArrayInputStream(securityTemplate.getTruststore()),
                decodeStr(securityTemplate.getTruststorePassword()));

        SSLConnectionSocketFactory sslConnectionSockFactory = new SSLConnectionSocketFactory(
                sslFactory.getSSLContext(), SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                .register("https", sslConnectionSockFactory).build();

        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(registry);
        connectionManager.setMaxTotal(DEFAULT_MAX_TOTAL_CONNECTIONS);
        connectionManager.setDefaultMaxPerRoute(DEFAULT_MAX_CONNECTIONS_PER_ROUTE);

        CloseableHttpClient httpClient = HttpClientBuilder.create()
                .setConnectionManager(connectionManager)
                .setUserTokenHandler(NoopUserTokenHandler.INSTANCE).build();

        // The default UserTokenHandler is very conservative and results in http connections with SSL client cert
        // context not being reused in case that state was specific to a user and should not be leaked across
        // connections. For swift, the context is not tied to any user and SSL connections to the same agent can always
        // be reused.

        return new HttpComponentsClientHttpRequestFactory(httpClient);
    }

    private static String decodeStr(final String password) {
        try {
            return CodecUtils.decodeString(new Base64Codec(PASSWORD_ENCRYPTION_KEY), password);
        } catch (CannotDecodeException e) {
            throw new RuntimeException(e);
        }
    }

    @Required
    public void setSecurityTemplateDao(final SecurityTemplateDao securityTemplateDao) {
        this.securityTemplateDao = securityTemplateDao;
    }
}