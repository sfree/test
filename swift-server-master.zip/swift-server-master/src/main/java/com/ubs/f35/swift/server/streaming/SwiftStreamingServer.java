package com.ubs.f35.swift.server.streaming;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.StringUtils;
import org.vertx.java.core.AsyncResult;

import com.google.common.base.Throwables;
import com.ubs.sapi.service.StreamingHandler;
import com.ubs.sapi.service.StreamingService;
import com.ubs.sapi.service.StreamingServiceBuilder;
import com.ubs.sapi.service.middleware.Endpoint;

public class SwiftStreamingServer implements InitializingBean {
    private static final Logger LOG = LoggerFactory.getLogger(SwiftStreamingServer.class);

    private String keyStorePath;
    private String keyStorePassword;
    private int port;
    private int loadBalancerPort;
    private int maxWebSocketFrameSize;

    private StreamingHandler deploymentProcessor;
    private StreamingHandler subscriptionStatusProcessor;

    @Override
    public void afterPropertiesSet() throws Exception {
        LOG.info("Wiring up SwiftStreamingServer");
        StreamingServiceBuilder builder = StreamingService.newBuilder(port)
                .withSockJS("/swiftsockjs")
                .setLoadBalancerPort(loadBalancerPort)
                .setMaxWebSocketFrameSize(maxWebSocketFrameSize)
                .use(new Endpoint("/deploy/.*", deploymentProcessor))
                .use(new Endpoint("/status/.*", subscriptionStatusProcessor));

        if (StringUtils.hasText(keyStorePath)) {
            LOG.info("SwiftStreamingServer is using SSL");
            builder.setSSL(true)
                    .setKeyStorePath(keyStorePath)
                    .setKeyStorePassword(keyStorePassword);
        } else {
            LOG.info("SwiftStreamingServer is NOT using SSL.  This is expected in UAT and PROD where SSL is handled by the LTM.");
        }

        StreamingService service = builder.build();
        AsyncResult<StreamingService> result = service.startSync();

        // halt startup if the streaming server failed to initialise
        if (result.failed()) {
            Throwables.propagateIfInstanceOf(result.cause(), Exception.class);
            Throwables.propagate(result.cause());
        }
    }

    @Required
    public void setPort(final int port) {
        this.port = port;
    }

    @Required
    public void setLoadBalancerPort(final int loadBalancerPort) {
        this.loadBalancerPort = loadBalancerPort;
    }

    @Required
    public void setDeploymentProcessor(final StreamingHandler deploymentProcessor) {
        this.deploymentProcessor = deploymentProcessor;
    }

    @Required
    public void setSubscriptionStatusProcessor(final StreamingHandler subscriptionStatusProcessor) {
        this.subscriptionStatusProcessor = subscriptionStatusProcessor;
    }

    @Required
    public void setMaxWebSocketFrameSize(final int maxWebSocketFrameSize) {
        this.maxWebSocketFrameSize = maxWebSocketFrameSize;
    }

    public void setKeyStorePath(final String keyStorePath) {
        this.keyStorePath = keyStorePath;
    }

    public void setKeyStorePassword(final String keyStorePassword) {
        this.keyStorePassword = keyStorePassword;
    }
}
