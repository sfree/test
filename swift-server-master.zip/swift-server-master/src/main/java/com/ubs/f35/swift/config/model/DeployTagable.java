package com.ubs.f35.swift.config.model;

import java.util.List;

import com.ubs.f35.swift.dao.model.Environment;

/**
 * Common interface for entities which can be tagged with {@link DeployTag}.
 * <p>
 * All deploy tags are specific to an environment, so any entity which has {@link DeployTag} must expose
 * {@link #getEnvironment()}
 */
public interface DeployTagable {
    Environment getEnvironment();

    void setEnvironment(Environment environment);

    List<DeployTag> getDeployTags();

    void setDeployTags(List<DeployTag> deployTags);
}
