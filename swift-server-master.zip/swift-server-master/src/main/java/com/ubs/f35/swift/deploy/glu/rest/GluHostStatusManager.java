package com.ubs.f35.swift.deploy.glu.rest;

import static com.ubs.f35.swift.deploy.glu.rest.GluJsonUtils.extractFromMap;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.linkedin.zookeeper.tracker.TrackedNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.StringUtils;

import com.google.common.collect.Lists;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.MountPointScheme;
import com.ubs.f35.swift.deploy.glu.state.GluState;
import com.ubs.f35.swift.document.ArtifactEntryConvertor;
import com.ubs.f35.swift.model.HostStatus;
import com.ubs.f35.swift.zookeeper.ZooKeeperTreeTracker;

/**
 * Exposes functionality provided by the GLU orchestration engine.
 * 
 * @author stephelu
 * 
 */
public class GluHostStatusManager {
    private static final Logger LOG = LoggerFactory.getLogger(GluHostStatusManager.class);

    private static final String MONITOR_GROUP_ID = "com.ubs.f35.swift";
    private static final String MONITOR_ARTIFACT_ID = "host-monitor";

    // Injected
    private ZooKeeperTreeTracker<Map> agentTracker;
    private ZooKeeperTreeTracker<Map> mountPointTracker;

    public List<HostStatus> getHostHealth(final Collection<String> hostNames) {
        List<HostStatus> statuses = Lists.newArrayListWithExpectedSize(hostNames.size());
        for (String host : hostNames) {
            try {
                statuses.add(getHostHealth(host));
            } catch (RuntimeException ex) {
                // Don't let an error extracting the status for a single host blow everything up.
                LOG.error("Exception extracting host status for {}", host, ex);
            }
        }
        return statuses;
    }

    private HostStatus getHostHealth(final String host) {
        HostStatus status = new HostStatus();
        status.setHost(host);

        TrackedNode<Map> agent = agentTracker.get(host);
        if (agent != null) {
            status.setAgentUp(true);
            status.setAgentVersion(String.valueOf(agent.getData().get("glu.agent.version")));
        }

        TrackedNode<Map> health = getHealthData(host);

        if (health != null) {
            Map scriptState = (Map) health.getData().get("scriptState");

            String currentState = extractFromMap(scriptState, "stateMachine", "currentState");
            status.setMonitorUp(GluState.running.name().equals(currentState));

            Map script = (Map) scriptState.get("script");

            status.setRunningUser(extractFromMap(script, "runningUser"));
            String numCpus = extractFromMap(script, "numCpus");
            if (StringUtils.hasText(numCpus)) {
                status.setNumberOfCpus(Integer.parseInt(numCpus));
            } else {
                LOG.warn("Assuming single CPU for {}", host);
                status.setNumberOfCpus(1);
            }
            addLoadInfo(status, script);
            addMemInfo(status, script);
        }
        return status;
    }

    private TrackedNode<Map> getHealthData(final String host) {
        ArtifactConfig config = new ArtifactConfig();
        config.setGroupId(MONITOR_GROUP_ID);
        config.setArtifactId(MONITOR_ARTIFACT_ID);
        config.setMountPointScheme(MountPointScheme.ARTIFACT_INSTANCE_NAME);

        TrackedNode<Map> health = getHealthData(host, config);
        if (health == null) {
            // try again with the new mount point scheme
            config.setMountPointScheme(MountPointScheme.GROUP_ARTIFACT_INSTANCE_NAME);

            return getHealthData(host, config);
        }

        return health;
    }

    private TrackedNode<Map> getHealthData(final String host, final ArtifactConfig config) {
        String mountPoint = ArtifactEntryConvertor.buildMountPoint(host, config);
        return mountPointTracker.get(GluProcessManager.getMountPointPath(host, mountPoint));
    }

    /**
     * Load averages are normalised by the number of cpus. This has a good explanation.
     * http://blog.scoutapp.com/articles/2009/07/31/understanding-load-averages
     * 
     * @param status
     * @param script
     */
    protected void addLoadInfo(final HostStatus status, final Map script) {
        String load = extractFromMap(script, "load");
        if (load != null) {
            List<Double> loadAverages = Lists.newArrayList();
            for (String average : load.split(" ")) {
                loadAverages.add(Double.parseDouble(average) / status.getNumberOfCpus());
            }
            status.setLoadAverages(loadAverages);
        }
    }

    protected void addMemInfo(final HostStatus status, final Map script) {
        String memory = extractFromMap(script, "memInfo");
        if (memory != null) {
            String[] fields = memory.split("\n");
            for (String field : fields) {
                String[] details = field.split(":", 2);
                if (details.length == 2) {
                    String key = details[0].trim();
                    String value = details[1].trim();
                    long memoryMb = Long.parseLong(value.split(" ")[0]) / 1024;

                    if ("MemFree".equals(key)) {
                        status.setMemFreeMb(memoryMb);
                    } else if ("MemTotal".equals(key)) {
                        status.setMemTotalMb(memoryMb);
                    } else if ("SwapFree".equals(key)) {
                        status.setSwapFreeMb(memoryMb);
                    } else if ("SwapTotal".equals(key)) {
                        status.setSwapTotalMb(memoryMb);
                    }
                }
            }
        }
    }

    @Required
    public void setAgentTracker(final ZooKeeperTreeTracker<Map> agentTracker) {
        this.agentTracker = agentTracker;
    }

    @Required
    public void setMountPointTracker(final ZooKeeperTreeTracker<Map> mountPointTracker) {
        this.mountPointTracker = mountPointTracker;
    }
}
