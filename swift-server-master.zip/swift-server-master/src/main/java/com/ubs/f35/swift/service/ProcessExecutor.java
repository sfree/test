package com.ubs.f35.swift.service;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;

/**
 * Quick abstraction around {@link ProcessBuilder} which is not unit test friendly (or at least not mockito friendly).
 * As a result this class is not tested.
 */
public class ProcessExecutor {
    public void executeProcess(final String... command) throws IOException, InterruptedException {
        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
        StreamGobbler processOutput = new StreamGobbler(process.getInputStream());
        processOutput.start();

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new RuntimeException("Process failed.  Exit code: " + exitCode +
                    "\nOutput:" + processOutput.getOutput());
        }
    }

    private static class StreamGobbler extends Thread {
        private final InputStream is;
        private String output;

        private StreamGobbler(final InputStream is) {
            this.is = is;
        }

        @Override
        public void run() {
            try {
                output = IOUtils.toString(is);
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }

        public String getOutput() {
            return output;
        }
    }
}
