package com.ubs.f35.swift.deploy.glu;

/**
 * Categories of exceptions thrown as a result of failed deployments
 */
public abstract class DeploymentException extends RuntimeException {

    public DeploymentException(final String message) {
        super(message);
    }

}
