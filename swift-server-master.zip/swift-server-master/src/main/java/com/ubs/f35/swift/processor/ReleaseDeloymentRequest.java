package com.ubs.f35.swift.processor;

import java.util.List;

import com.ubs.f35.swift.model.TargetedInstanceDeployment;

public class ReleaseDeloymentRequest {
    private List<TargetedInstanceDeployment> deploymentTargets;

    public List<TargetedInstanceDeployment> getDeploymentTargets() {
        return deploymentTargets;
    }

    public void setDeploymentTargets(final List<TargetedInstanceDeployment> deploymentTargets) {
        this.deploymentTargets = deploymentTargets;
    }

}
