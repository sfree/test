package com.ubs.f35.swift.dao;

import java.util.List;

import com.ubs.f35.swift.dao.model.ReleaseWatch.WatchType;

public interface ReleaseWatchDao {

    List<WatchType> loadWatches(Integer releaseId, String user);

    void addWatch(ReleaseDefinition release, WatchType watchType, String user);

    void addWatch(Integer releaseId, WatchType watchType, String user);

    void removeWatch(Integer releaseId, WatchType watchType, String user);

    List<String> loadWatchers(Integer releaseId, WatchType watchType);
}
