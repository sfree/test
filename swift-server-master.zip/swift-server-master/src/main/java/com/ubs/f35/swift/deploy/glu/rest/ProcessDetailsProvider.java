package com.ubs.f35.swift.deploy.glu.rest;

import com.ubs.f35.swift.environment.model.glu.Entry;

public interface ProcessDetailsProvider {
    /**
     * Returns the process details for an artifact. The process details will only be returned by this provider if the
     * provider believes that the details are accurate.
     * 
     * @param entry
     * @return
     */
    ProcessDetails getCurrentProcessState(final Entry entry) throws ProcessDetailsUnavailableException;
}
