package com.ubs.f35.swift.deploy.glu;

import java.sql.Timestamp;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.ubs.f35.swift.activity.ActivityFeedWriter;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;
import com.ubs.f35.swift.dao.Deployment.DeploymentType;
import com.ubs.f35.swift.dao.DeploymentDao;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.action.Action;
import com.ubs.f35.swift.deploy.glu.action.BaseGroupedAction;
import com.ubs.f35.swift.io.processor.ManualDeploymentInstructionMessage;
import com.ubs.f35.swift.webhook.WebhookNotifier;

public class AuditingDeploymentExecutor implements DeploymentExecutor {
    private static final Logger LOG = LoggerFactory.getLogger(AuditingDeploymentExecutor.class);

    private DeploymentExecutor delegateDeploymentExecutor;
    private DeploymentDao deploymentDao;
    private ActivityFeedWriter activityFeedWriter;
    private WebhookNotifier webhookNotifier;

    @Override
    public boolean cancelDeployment(final UUID deploymentId) {
        return delegateDeploymentExecutor.cancelDeployment(deploymentId);
    }

    @Override
    public void executeDeployment(final Deployment deployment, final DeploymentListener deploymentListener) {
        // Mark the deployment as executing. Save immediately to the db so this is visible.
        deployment.setDeploymentStatus(DeploymentStatus.EXECUTING);
        deploymentDao.saveDeployment(deployment);

        delegateDeploymentExecutor.executeDeployment(deployment, new DeploymentListener() {

            @Override
            public void deploymentComplete(final DeploymentStatus status) {
                deploymentListener.deploymentComplete(status);

                // Audit that a deployment was performed against this release.
                deployment.setDeploymentStatus(status);
                deployment.setDeployTime(new Timestamp(System.currentTimeMillis()));
                deploymentDao.saveDeployment(deployment);

                if (deployment.getDeploymentType() != DeploymentType.AdHoc) {
                    activityFeedWriter.deploy(deployment);
                    webhookNotifier.eventOccurred(deployment);
                }
            }

            @Override
            public void deploymentActionChanged(final Action action) {
                deploymentListener.deploymentActionChanged(action);

                // if this is an environment grouping action, record separately if the environment deployment
                // passed or failed.
                if (action instanceof BaseGroupedAction) {
                    BaseGroupedAction groupAction = (BaseGroupedAction) action;
                    Environment environment = groupAction.getEnvironment();
                    DeploymentState state = groupAction.getDeploymentState();
                    if (state != null
                            && state.getStatus() != com.ubs.f35.swift.deploy.glu.DeploymentState.DeploymentStatus.RUNNING
                            && environment != null) {

                        for (EnvDeployment envDeployment : deployment.getEnvDeployments()) {
                            if (envDeployment.getEnvironment().equals(environment)) {
                                DeploymentStatus status = getStatusFromState(state);

                                envDeployment.setDeploymentStatus(status);
                            }
                        }
                    }
                }
            }

        });
    }

    @Override
    public void continueDeployment(final UUID deploymentId, final ManualDeploymentInstructionMessage deploymentMessage) {
        delegateDeploymentExecutor.continueDeployment(deploymentId, deploymentMessage);
    }

    private DeploymentStatus getStatusFromState(final DeploymentState state) {
        if (state.getStatus() == com.ubs.f35.swift.deploy.glu.DeploymentState.DeploymentStatus.COMPLETED) {
            return DeploymentStatus.COMPLETED;
        } else if (state.getStatus() == com.ubs.f35.swift.deploy.glu.DeploymentState.DeploymentStatus.FAILED) {
            // Deployment actions which are cancelled come through as a failure with a cancelled cause.
            if (state.getClientError() != null
                    && DeploymentCancelledException.class.getName().equals(state.getClientError().getExceptionClass())) {
                return DeploymentStatus.CANCELLED;
            } else {
                return DeploymentStatus.FAILED;
            }
        }
        LOG.warn("Unexpected deployment state {}", state);
        return DeploymentStatus.FAILED;
    }

    @Required
    public void setActivityFeedWriter(final ActivityFeedWriter activityFeedWriter) {
        this.activityFeedWriter = activityFeedWriter;
    }

    @Required
    public void setWebhookNotifier(final WebhookNotifier webhookNotifier) {
        this.webhookNotifier = webhookNotifier;
    }

    @Required
    public void setDelegateDeploymentExecutor(final DeploymentExecutor delegateDeploymentExecutor) {
        this.delegateDeploymentExecutor = delegateDeploymentExecutor;
    }

    @Required
    public void setDeploymentDao(final DeploymentDao deploymentDao) {
        this.deploymentDao = deploymentDao;
    }

}
