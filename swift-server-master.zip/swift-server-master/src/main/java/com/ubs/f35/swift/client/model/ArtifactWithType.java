package com.ubs.f35.swift.client.model;

import com.ubs.f35.swift.dao.Artifact;

public class ArtifactWithType extends Artifact implements WithArtifactType {
    private final ArtifactType artifactType;

    public ArtifactWithType(final Artifact artifact, final ArtifactType artifactType) {
        super(artifact);
        this.artifactType = artifactType;
    }

    @Override
    public ArtifactType getArtifactType() {
        return artifactType;
    }

}
