package com.ubs.f35.swift.dao.hibernate;

import java.util.Collections;
import java.util.List;

import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.DuplicateHostException;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.HostDao;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.model.Environment;

public class HibernateHostDao extends HibernateDaoSupport implements HostDao {
    private static final Logger LOG = LoggerFactory.getLogger(HibernateHostDao.class);

    private HibernateDeployTagDao deployTagDao;
    private EnvironmentDao environmentDao;

    @Required
    public void setDeployTagDao(final HibernateDeployTagDao deployTagDao) {
        this.deployTagDao = deployTagDao;
    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }

    @Override
    public Host save(final Host host) {
        LOG.debug("saving host configuration {}", host);

        // resolve to persistent environment
        host.setEnvironment(environmentDao.loadEnvironment(host.getEnvironment()));
        deployTagDao.mergeDeployTags(host);

        Host updated = (Host) getSession().merge(host);
        getSession().flush();

        return updated;
    }

    /**
     * Used to record the presence of a new host.
     * 
     * @param host
     */
    @Override
    @Transactional
    public void saveIfNew(final Host host) throws DuplicateHostException {
        Host existing = load(host.getHostname());
        if (existing == null) {
            LOG.info("Recording new host {}", host);
            save(host);
        } else if (!host.getEnvironment().equals(existing.getEnvironment())) {
            throw new DuplicateHostException(existing.getEnvironment());
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Host> loadAll() {
        return getSession().createCriteria(Host.class).addOrder(Order.asc("hostname")).list();
    }

    @Override
    public List<Host> loadByEnvironment(final Environment environment) {
        Environment persistentEnv = environmentDao.loadEnvironment(environment);

        return loadByEnvironments(Collections.singletonList(persistentEnv.getId()));
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Host> loadByEnvironments(final List<Integer> environmentIds) {
        return getSession().createCriteria(Host.class)
                .createAlias("environment", "e")
                .add(Restrictions.in("e.id", environmentIds))
                .addOrder(Order.asc("hostname"))
                .list();
    }

    @Override
    public Host load(final String hostname) {
        return load(Host.class, hostname);
    }

    @Override
    public Host loadExpected(final String hostname) {
        return loadExpected(Host.class, hostname);
    }

    @Override
    public void deleteHost(final Host host) {
        getSession().delete(host);
    }

}
