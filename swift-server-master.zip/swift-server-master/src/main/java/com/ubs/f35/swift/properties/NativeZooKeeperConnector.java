package com.ubs.f35.swift.properties;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.VisibleForTesting;
import com.ubs.f35.core.zookeeper.client.ZNodeProcessor;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.common.PathBuilder;
import com.ubs.f35.core.zookeeper.client.common.ZookeeperRootPathResolver;
import com.ubs.f35.core.zookeeper.client.config.api.ZooKeeperConfigService;
import com.ubs.f35.core.zookeeper.client.config.api.ZooKeeperPropertiesService;
import com.ubs.f35.core.zookeeper.client.config.api.ZooKeeperPropertyFileImporter;
import com.ubs.f35.core.zookeeper.utils.ConfigUtils;
import com.ubs.f35.swift.config.model.EnvironmentConfig;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.properties.bulk.PropertyUpdate;
import com.ubs.f35.swift.properties.model.ArtifactProperties;

public class NativeZooKeeperConnector implements ZooKeeperConnector {

    private static final Logger LOG = LoggerFactory.getLogger(NativeZooKeeperConnector.class);

    protected static long WAIT_FOR_CLIENT_ALIVE = 5000;

    private final ZooKeeperService zooKeeperService;
    private final ZooKeeperPropertiesService zooKeeperPropertiesService;
    private final ZooKeeperConfigService zooKeeperConfigService;
    private final EnvironmentConfig envConfig;

    public NativeZooKeeperConnector(final ZooKeeperService zooKeeperService,
            final ZooKeeperPropertiesService zooKeeperPropertiesService,
            final ZooKeeperConfigService zooKeeperConfigService,
            final EnvironmentConfig envConfig) {
        this.zooKeeperService = zooKeeperService;
        this.zooKeeperPropertiesService = zooKeeperPropertiesService;
        this.zooKeeperConfigService = zooKeeperConfigService;
        this.envConfig = envConfig;
    }

    @Override
    public Map<String, String> getProperties(final Artifact artifact) {

        String groupId = artifact.getGroupId();
        String artifactId = artifact.getArtifactId();
        String version = artifact.getVersion();

        LOG.debug("ZooKeeperPropertiesService status: {}", zooKeeperPropertiesService.isEnabled());
        try {
            zooKeeperPropertiesService.waitForZooKeeperClientAlive(WAIT_FOR_CLIENT_ALIVE, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        return loadProperties(groupId, artifactId, version);
    }

    /**
     * Loads the {@link Properties} from ZooKeeper using the supplied groupId / artifactId / version. Also passes the
     * additionalProcessors when walking the tree, though they have no effect on the Properties returned. NB: the
     * {@link #init()} method must be called prior to calling this.
     * 
     * @return
     * @throws IOException
     *             if no properties are found for the specified groupId / artifactId / version
     */
    private Map<String, String> loadProperties(final String groupId, final String artifactId, final String version) {

        String rootConfigPath = envConfig.getZookeeperPropertiesRoot();

        String rootPath = new ZookeeperRootPathResolver(rootConfigPath, groupId, artifactId, version)
                .resolveApplicationRootPath();
        LOG.info("using root path: {}", rootPath);

        Map<String, String> zooKeeperProperties = new HashMap<String, String>();
        ZNodeProcessor propertyExposingProcessor = new SwiftPropertyExposingNodeProcessor(rootPath, zooKeeperProperties);

        try {
            zooKeeperConfigService.walk(rootPath, propertyExposingProcessor);
        } catch (Exception e) {
            throw new RuntimeException("Failed to retrieve data from ZooKeeper", e);
        }

        return zooKeeperProperties;
    }

    @Override
    public void saveProperties(final ArtifactProperties artifactProperties) {

        String rootConfigPath = envConfig.getZookeeperPropertiesRoot();

        Artifact artifact = artifactProperties.getArtifact();

        try {

            ZookeeperRootPathResolver zkPathResolver = new ZookeeperRootPathResolver(
                    rootConfigPath, artifact.getGroupId(), artifact.getArtifactId(), artifact.getVersion());
            ZooKeeperPropertyFileImporter importer = getZooKeeperPropertiesImporter(zooKeeperService, zkPathResolver);

            Properties properties = new Properties();
            properties.putAll(artifactProperties.getProperties().toMap());

            // This mirrors the behaviour of the methods which import properties from a file, or the command line
            // properties importer, which first delete the sub tree and then import everything. This behaviour is
            // necessary so that removed properties will actually be removed from ZooKeeper.
            zooKeeperService.deleteSubTree(zkPathResolver.resolveApplicationRootPath());
            importer.importProperties(properties);
        } catch (Exception e) {
            throw new RuntimeException("Failed to save properties to ZooKeeper", e);
        }

    }

    /**
     * Handles performing an update to just one of an artifacts properties. The bulk upload functionality may be used to
     * modify one property across many artifacts, so this implementation optimally updates only that property rather
     * than deleting all properties and reimporting from scratch.
     */
    @Override
    public void saveUpdates(final Artifact artifact, final List<PropertyUpdate> propertyUpdates) {

        String rootConfigPath = envConfig.getZookeeperPropertiesRoot();

        try {

            ZookeeperRootPathResolver zkPathResolver = new ZookeeperRootPathResolver(
                    rootConfigPath, artifact.getGroupId(), artifact.getArtifactId(), artifact.getVersion());
            ZooKeeperPropertyFileImporter importer = getZooKeeperPropertiesImporter(zooKeeperService, zkPathResolver);

            String rootPath = zkPathResolver.resolveApplicationRootPath();

            Properties properties = new Properties();

            // Deletes are processed before updates.
            for (PropertyUpdate update : propertyUpdates) {
                // For any property which is in the bulk upload. First remove it's children that are related to leased /
                // encrypted property tagging. And clear its data / delete it if it doesn't have any children. The
                // update may change the property from a leased to literal value, so important to clean up any
                // additional nodes.
                String propertyPath = ConfigUtils.convertPropertyToPath(update.getKey());
                String fullPath = new PathBuilder().verbatim(rootPath).appendNormalised(propertyPath).toString();

                ZooKeeperClient zkClient = zooKeeperService.getClient();

                if (zkClient.exists(fullPath)) {
                    List<String> children = zkClient.getChildren(fullPath);
                    int childrenRemoved = 0;
                    for (String childPath : zkClient.getChildren(fullPath)) {
                        if (childPath.startsWith("tag:")) { // TagSchemeHelper.TAG
                            // leased property or encrypted property that needs to be cleaned up.
                            String fullChildPath = new PathBuilder().verbatim(fullPath).appendAsIs(childPath)
                                    .toString();
                            zooKeeperService.deleteSubTree(fullChildPath);
                            childrenRemoved++;
                        }
                    }
                    // zkClient.hasChildren(fullPath) but without the remote call
                    if (children.size() - childrenRemoved == 0) {
                        zkClient.delete(fullPath);
                    } else {
                        // remove data only (eg property abc= but still has abc.xzy=hello under it).
                        zkClient.set(fullPath, (byte[]) null);
                    }
                }

                // Only import again if the property is not removed.
                if (!update.isRemoved()) {
                    properties.put(update.getKey(), update.getValue());
                }
            }

            importer.importProperties(properties);
        } catch (Exception e) {
            throw new RuntimeException("Failed to save property updates to ZooKeeper", e);
        }

    }

    @VisibleForTesting
    protected ZooKeeperPropertyFileImporter getZooKeeperPropertiesImporter(final ZooKeeperService zks,
            final ZookeeperRootPathResolver zkPathResolver) {
        return new ZooKeeperPropertyFileImporter(zks, zkPathResolver);
    }

}
