package com.ubs.f35.swift.deploy.glu.rest;

import com.google.common.base.Predicate;
import com.ubs.f35.swift.deploy.glu.rest.GluResponseErrorHandler.ExceptionDetails;

public class ExceptionTypePredicate implements Predicate<ExceptionDetails> {

    private final String exceptionType;

    public ExceptionTypePredicate(final String exceptionType) {
        this.exceptionType = exceptionType;
    }

    @Override
    public boolean apply(final ExceptionDetails input) {
        return exceptionType.equals(input.type);
    }

}
