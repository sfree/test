package com.ubs.f35.swift.deploy.glu.action;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.DeploymentInvoker;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;

public class DeploymentContext {

    private final ActionExecutor actionExecutor;
    private final EnvironmentDocumentStore environmentDocumentStore;
    private final EnvironmentBeanFactory<DeploymentInvoker> deploymentInvokerFactory;

    public DeploymentContext(final ActionExecutor actionExecutor,
            final EnvironmentBeanFactory<DeploymentInvoker> deploymentInvokerFactory,
            final EnvironmentDocumentStore environmentDocumentStore) {
        this.actionExecutor = actionExecutor;
        this.deploymentInvokerFactory = deploymentInvokerFactory;
        this.environmentDocumentStore = environmentDocumentStore;
    }

    public DeploymentInvoker getDeploymentInvoker(final Environment environment) {
        return deploymentInvokerFactory.get(environment);
    }

    public EnvironmentDocumentStore getEnvironmentDocumentStore() {
        return environmentDocumentStore;
    }

    public ActionExecutor getActionExecutor() {
        return actionExecutor;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(deploymentInvokerFactory, actionExecutor, environmentDocumentStore);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DeploymentContext) {
            DeploymentContext that = (DeploymentContext) object;
            return Objects.equal(this.deploymentInvokerFactory, that.deploymentInvokerFactory)
                    && Objects.equal(this.actionExecutor, that.actionExecutor)
                    && Objects.equal(this.environmentDocumentStore, that.environmentDocumentStore);
        }
        return false;
    }

}
