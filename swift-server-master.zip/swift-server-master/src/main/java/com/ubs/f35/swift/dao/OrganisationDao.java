package com.ubs.f35.swift.dao;

import java.util.List;

import com.ubs.f35.swift.dao.model.Organisation;

public interface OrganisationDao {

    List<Organisation> loadAll();

    Organisation load(String organisationName);

    void save(Organisation organisation);

}
