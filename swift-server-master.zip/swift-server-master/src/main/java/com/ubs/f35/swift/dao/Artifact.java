package com.ubs.f35.swift.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.hibernate.annotations.NaturalId;

import com.google.common.base.Objects;

@SequenceGenerator(name = "oracle_seq", sequenceName = "seq_artifacts_id")
@Entity
@Table(name = "artifacts")
public class Artifact {
    @JsonIgnore
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "oracle_seq")
    private final Integer id;

    @NaturalId(mutable = false)
    private final String groupId;
    @NaturalId(mutable = false)
    private final String artifactId;
    @NaturalId(mutable = false)
    private final String version;

    /**
     * For hibernate deserialization
     */
    public Artifact() {
        this(null, null, null, null);
    }

    public Artifact(final Integer id, final String groupId, final String artifactId, final String version) {
        this.id = id;
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.version = version;
    }

    public Artifact(final Artifact artifact) {
        this(artifact.getId(), artifact.getGroupId(), artifact.getArtifactId(), artifact.getVersion());
    }

    public Artifact(final String groupId, final String artifactId, final String version) {
        this(null, groupId, artifactId, version);
    }

    public String getGroupId() {
        return groupId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    public String getVersion() {
        return version;
    }

    public Integer getId() {
        return id;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(groupId, artifactId, version);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("groupId", groupId)
                .add("artifactId", artifactId)
                .add("version", version)
                .toString();
    }

    /**
     * Returns a new Artifact instance based on this artifact, with only the groupId, artifactId and version fields
     * populated. Useful for situations where Artifacts need to be compared only by these fields, ignoring any other
     * fields part of an Artifact subclass.
     * 
     * @return Artifact
     */
    public Artifact toSimpleArtifact() {
        return new Artifact(groupId, artifactId, version);
    }

    @JsonIgnore
    public NexusArtifact getNexusArtifact() {
        return new NexusArtifact(groupId, artifactId);
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Artifact that = (Artifact) obj;
        return Objects.equal(this.groupId, that.groupId)
                && Objects.equal(this.artifactId, that.artifactId)
                && Objects.equal(this.version, that.version);

    }

}
