package com.ubs.f35.swift.dao;

import java.util.List;

import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.model.Environment;

public interface HostDao {

    Host save(Host host);

    void saveIfNew(Host host) throws DuplicateHostException;

    List<Host> loadAll();

    List<Host> loadByEnvironment(Environment environment);

    List<Host> loadByEnvironments(List<Integer> environmentIds);

    Host load(String hostname);

    Host loadExpected(String hostname);

    void deleteHost(Host host);

}
