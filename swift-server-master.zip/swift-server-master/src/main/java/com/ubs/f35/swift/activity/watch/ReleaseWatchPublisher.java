package com.ubs.f35.swift.activity.watch;

import static org.quartz.DateBuilder.futureDate;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import org.quartz.DateBuilder.IntervalUnit;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.ObjectAlreadyExistsException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.annotations.VisibleForTesting;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.event.ReleaseChangeListener;

/**
 * Changes to a release definition are published to watchers. This occurs after a specified delay so that watchers are
 * not bombarded with micro updates if the user makes several small changes to a release in a short space of time.
 * <p>
 * This implementation makes use of Quartz for scheduling. Clustered scheduling is required as the release updates may
 * occur on different swift nodes and Quartz takes care of the complexity of replacing jobs and ensuring the jobs only
 * fire once.
 * 
 * @author stephelu
 * 
 */
public class ReleaseWatchPublisher implements ReleaseChangeListener {
    private static final Logger LOG = LoggerFactory.getLogger(ReleaseWatchPublisher.class);
    private Scheduler scheduler;
    private int releaseUpdateBufferMinutes = 10;
    private ReleaseUpdateNotifier releaseUpdateNotifier;
    @VisibleForTesting
    IntervalUnit releaseUpdateBufferUnit = IntervalUnit.MINUTE;

    // static reference for Jobs to obtain a handle back to spring injected deps
    private static ReleaseWatchPublisher SELF;

    public ReleaseWatchPublisher() {
        if (SELF != null) {
            LOG.warn("Multiple instances of this class is not supported");
        }
        SELF = this;
    }

    @Override
    public void afterUpdate(final ReleaseDefinition release) {
        Integer releaseId = release.getId();
        // Define job instance
        JobDetail job = newJob(ReleaseWatchJob.class)
                .withIdentity(String.valueOf(releaseId), "release-update")
                .build();

        // Define a Trigger that will fire "now", and not repeat
        Trigger trigger = newTrigger()
                .forJob(job)
                .startAt(futureDate(releaseUpdateBufferMinutes, releaseUpdateBufferUnit))
                .build();

        // Schedule the job with the trigger
        try {
            scheduler.scheduleJob(job, trigger);
        } catch (ObjectAlreadyExistsException e) {
            LOG.info("Already an outstanding job to publish updates for release {}", releaseId);
        } catch (SchedulerException e) {
            LOG.error("Unable to schedule release update notification job for release {}", releaseId, e);
        }
    }

    @Required
    public void setScheduler(final Scheduler scheduler) {
        this.scheduler = scheduler;
    }

    @Required
    public void setReleaseUpdateNotifier(final ReleaseUpdateNotifier releaseUpdateNotifier) {
        this.releaseUpdateNotifier = releaseUpdateNotifier;
    }

    public void setReleaseUpdateBufferMinutes(final int releaseUpdateBufferMinutes) {
        this.releaseUpdateBufferMinutes = releaseUpdateBufferMinutes;
    }

    public static class ReleaseWatchJob implements Job {
        @Override
        public void execute(final JobExecutionContext context) throws JobExecutionException {
            String releaseId = context.getJobDetail().getKey().getName();
            LOG.info("Notifying watchers of release {}", releaseId);
            SELF.releaseUpdateNotifier.publishReleaseNotifications(Integer.valueOf(releaseId));
        }
    }

}
