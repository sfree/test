package com.ubs.f35.swift.security;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Required;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

public class UserDetailsCachedLookup implements UserDetailsLookup {

    private static final Map<String, Object> NO_DETAILS = Collections.emptyMap();

    private UserDetailsLookup delegate;

    private final LoadingCache<String, Map<String, Object>> cache = CacheBuilder.newBuilder().maximumSize(10000)
            .expireAfterWrite(1, TimeUnit.DAYS).build(
                    new CacheLoader<String, Map<String, Object>>() {
                        @Override
                        public Map<String, Object> load(final String guid) {
                            Map<String, Object> userDetails = delegate.getUserDetails(guid);
                            if (userDetails != null) {
                                return userDetails;
                            } else {
                                // Cache misses as well. No point continually trying to find users who have left UBS.
                                return NO_DETAILS;
                            }
                        }
                    }
            );;

    @Override
    public Map<String, Object> getUserDetails(final String guid) {
        Map<String, Object> details = cache.getUnchecked(guid);
        if (details == NO_DETAILS) {
            return null;
        }
        return details;
    }

    @Required
    public void setDelegate(final UserDetailsLookup delegate) {
        this.delegate = delegate;
    }

}
