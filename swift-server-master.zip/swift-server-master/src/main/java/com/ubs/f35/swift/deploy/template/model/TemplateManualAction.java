package com.ubs.f35.swift.deploy.template.model;

import com.google.common.base.Objects;

public class TemplateManualAction implements TemplateAction {
    private String title;
    private String description;

    public String getTitle() {
        return title;
    }

    public void setTitle(final String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("title", title)
                .add("description", description)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(title, description);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof TemplateManualAction) {
            TemplateManualAction that = (TemplateManualAction) object;
            return Objects.equal(this.title, that.title)
                    && Objects.equal(this.description, that.description);
        }
        return false;
    }

}
