package com.ubs.f35.swift.dao;

import java.util.List;

import com.ubs.f35.swift.dao.model.Team;

public interface TeamDao {

    void create(Team team);

    Team load(Integer id);

    List<Team> loadAll(String organisation);

}
