package com.ubs.f35.swift.dao.hibernate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.swift.dao.SwiftUserDao;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.model.SwiftUser;

public class HibernateSwiftUserDao extends HibernateDaoSupport implements SwiftUserDao {

    private static final Logger LOG = LoggerFactory.getLogger(HibernateSwiftUserDao.class);

    @Override
    public SwiftUser load(final String id) {
        return load(SwiftUser.class, id);
    }

    @Override
    public SwiftUser loadOrCreate(final String userId) {
        SwiftUser user = load(userId);
        if (user == null) {
            user = new SwiftUser();
            user.setId(userId);

            getSession().save(user);
        }

        return user;
    }

}
