package com.ubs.f35.swift.dao;

import org.hibernate.envers.RevisionListener;

import com.ubs.f35.swift.state.OperationContextProvider;
import com.ubs.f35.swift.state.ThreadLocalOperationContextProvider;

public class SwiftRevisionListener implements RevisionListener {

    private final OperationContextProvider contextProvider = ThreadLocalOperationContextProvider.getInstance();

    @Override
    public void newRevision(final Object revisionEntity) {
        SwiftRevEntry entry = (SwiftRevEntry) revisionEntity;

        entry.setUser(contextProvider.getCurrentUser());
    }

}
