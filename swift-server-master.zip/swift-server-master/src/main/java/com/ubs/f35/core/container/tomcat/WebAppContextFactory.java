package com.ubs.f35.core.container.tomcat;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * Wraps a ApplicationContext so that it looks like a {@link WebApplicationContext}. This keeps the spring
 * {@link DispatcherServlet} happy.
 * 
 */
public class WebAppContextFactory {

    private static final Logger LOG = LoggerFactory.getLogger(WebAppContextFactory.class);

    private WebAppContextFactory() {
    }

    public static WebApplicationContext getWebApp(final ApplicationContext applicationContext) {
        LOG.info("Creating WebApplicationContext proxy");

        return (WebApplicationContext) Proxy.newProxyInstance(
                WebApplicationContext.class.getClassLoader(),
                new Class[] { WebApplicationContext.class }, new WebAppContextProxy(applicationContext));
    }

    static class WebAppContextProxy implements InvocationHandler {

        private final ApplicationContext delegate;

        public WebAppContextProxy(final ApplicationContext appContext) {
            this.delegate = appContext;
        }

        @Override
        public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
            LOG.debug("Invoking on parent context {} with args {}", method.getName(), args);

            if (method.getName().equals("getServletContext")) {
                throw new UnsupportedOperationException("getServletContext is not supported");
            } else {
                try {
                    return method.invoke(delegate, args);
                } catch (InvocationTargetException e) {
                    throw e.getTargetException();
                }
            }
        }
    }

}
