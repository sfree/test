package com.ubs.f35.swift.deploy.glu.state;

import com.google.common.base.Objects;

public class Transition {
    private final String target;
    private final TransitionStep action;

    Transition(final String target, final TransitionStep action) {
        this.target = target;
        this.action = action;
    }

    public GluState getTargetState() {
        return GluState.valueOf(target);
    }

    public TransitionStep getAction() {
        return action;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("action", action)
                .add("target", target)
                .toString();
    }

    // Be careful about changing these. They are persisted in save historical deployment plans and changing them may
    // prevent those plans from being unmarshalled.
    public enum TransitionStep {
        deploy_script,
        install,
        configure,
        start,
        stop,
        unconfigure,
        uninstall,
        remove_script;
    }
}