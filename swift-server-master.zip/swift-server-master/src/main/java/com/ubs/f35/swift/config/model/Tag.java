package com.ubs.f35.swift.config.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.util.Assert;

import com.google.common.base.Objects;

/**
 * Tags are not audited as they are immutable.
 * 
 * @author stephelu
 * 
 */
@Entity
@Table(name = "tags")
public class Tag implements Serializable {
    @Id
    private String tag;

    public Tag() {
    }

    public Tag(final String tag) {
        Assert.notNull(tag);
        this.tag = tag;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(final String tag) {
        this.tag = tag;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(tag);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof Tag) {
            Tag that = (Tag) object;
            return Objects.equal(this.tag, that.tag);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("tag", tag)
                .toString();
    }

}
