package com.ubs.f35.swift.deploy.client.action;

import java.util.List;

import com.google.common.base.Objects;

/**
 * Client representation of a deployment plan action.
 * 
 * @author stephelu
 * 
 */
public class ClientPlanGroupAction extends BaseClientAction {
    private final String name;
    /**
     * If this grouped action relates specifically to one process, include the artifactInstanceId so the client can make
     * requests for logs.
     */
    private final String artifactInstanceId;
    private final List<? extends ClientAction> included;
    private final boolean execute;
    private final String artifactId;

    public ClientPlanGroupAction(final String id, final String name, final List<? extends ClientAction> included,
            final boolean execute, final String artifactInstanceId, final String artifactId) {
        super(id);
        this.name = name;
        this.included = included;
        this.execute = execute;
        this.artifactInstanceId = artifactInstanceId;
        this.artifactId = artifactId;
    }

    public List<? extends ClientAction> getIncluded() {
        return included;
    }

    public String getArtifactInstanceId() {
        return artifactInstanceId;
    }

    public String getName() {
        return name;
    }

    public boolean isExecute() {
        return execute;
    }

    public String getArtifactId() {
        return artifactId;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ClientPlanGroupAction) {
            ClientPlanGroupAction that = (ClientPlanGroupAction) object;
            return Objects.equal(this.id, that.id)
                    && Objects.equal(this.name, that.name)
                    && Objects.equal(this.artifactInstanceId, that.artifactInstanceId)
                    && Objects.equal(this.artifactId, that.artifactId)
                    && Objects.equal(this.execute, that.execute)
                    && Objects.equal(this.included, that.included);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("name", name)
                .add("artifactInstanceId", artifactInstanceId)
                .add("artifactId", artifactId)
                .add("included", included)
                .add("execute", execute)
                .toString();
    }

}
