package com.ubs.f35.swift.dao;

import com.ubs.f35.swift.dao.model.SwiftUser;

public interface SwiftUserDao {

    SwiftUser load(String id);

    SwiftUser loadOrCreate(String userId);

}
