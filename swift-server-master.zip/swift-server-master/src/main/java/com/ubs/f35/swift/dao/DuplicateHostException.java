package com.ubs.f35.swift.dao;

import com.ubs.f35.swift.dao.model.Environment;

public class DuplicateHostException extends Exception {

    public DuplicateHostException(final Environment environment) {
        super("Host already exists in environment " + environment);
    }

}
