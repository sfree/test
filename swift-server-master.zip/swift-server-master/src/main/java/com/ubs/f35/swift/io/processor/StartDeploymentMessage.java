package com.ubs.f35.swift.io.processor;

import java.util.List;

import com.google.common.base.Objects;
import com.ubs.f35.swift.model.ReleaseDeploymentConfirmationMessage;

public class StartDeploymentMessage implements DeploymentConversationMessage, ReleaseDeploymentConfirmationMessage {
    // If present, this is a list of the actions to execute. If not present, execute all.
    private List<String> execute;
    // If the deployment plan required user confirmation
    private String confirmedReleaseId;

    public StartDeploymentMessage() {
    }

    public StartDeploymentMessage(final List<String> execute) {
        this.execute = execute;
    }

    public List<String> getExecute() {
        return execute;
    }

    public void setExecute(final List<String> execute) {
        this.execute = execute;
    }

    @Override
    public String getConfirmedReleaseId() {
        return confirmedReleaseId;
    }

    public void setConfirmedReleaseId(final String confirmedReleaseId) {
        this.confirmedReleaseId = confirmedReleaseId;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(execute);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof StartDeploymentMessage) {
            StartDeploymentMessage that = (StartDeploymentMessage) object;
            return Objects.equal(this.execute, that.execute)
                    && Objects.equal(this.confirmedReleaseId, that.confirmedReleaseId);
        }
        return false;
    }

}
