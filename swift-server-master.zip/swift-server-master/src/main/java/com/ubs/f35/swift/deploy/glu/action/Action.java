package com.ubs.f35.swift.deploy.glu.action;

import org.codehaus.jackson.annotate.JsonTypeInfo;
import org.codehaus.jackson.annotate.JsonTypeInfo.As;
import org.codehaus.jackson.annotate.JsonTypeInfo.Id;

import com.ubs.f35.swift.deploy.glu.DeploymentState;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlan;

@JsonTypeInfo(use = Id.CLASS, include = As.PROPERTY, property = "@class")
public interface Action {

    void setDeploymentState(DeploymentState deploymentState);

    DeploymentState getDeploymentState();

    /**
     * Returns a human friendly name for this action.
     * 
     * @return
     */
    String getName();

    /**
     * Returns a unique id for this action within a {@link DeploymentPlan}
     * 
     * @return
     */
    String getId();
}
