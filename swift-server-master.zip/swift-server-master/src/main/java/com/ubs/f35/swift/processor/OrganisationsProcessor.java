package com.ubs.f35.swift.processor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ubs.f35.swift.dao.OrganisationDao;
import com.ubs.f35.swift.dao.model.Organisation;

@Controller
@RequestMapping(value = "/api/organisations")
@Transactional
public class OrganisationsProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(OrganisationsProcessor.class);

    private OrganisationDao organisationDao;

    @RequestMapping(method = RequestMethod.GET)
    public List<Organisation> getOrganisations() {
        return organisationDao.loadAll();
    }

    @Required
    public void setOrganisationDao(final OrganisationDao organisationDao) {
        this.organisationDao = organisationDao;
    }
}
