package com.ubs.f35.swift.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.ImmutableMap;

/**
 * 
 * Handles miscellaneous requests that do not fit in other classes.
 */
@Controller
@RequestMapping(value = "/api/misc")
public class MiscProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(MiscProcessor.class);

    private String snowHost;
    private String serverVersion;
    private String serverHostname;

    @Required
    public void setSnowHost(final String snowHost) {
        this.snowHost = snowHost;
    }

    @Required
    public void setServerVersion(final String serverVersion) {
        this.serverVersion = serverVersion;
    }

    @Required
    public void setServerHostname(final String serverHostname) {
        this.serverHostname = serverHostname;
    }

    @RequestMapping(value = "/snow/host", method = RequestMethod.GET)
    @ResponseBody
    public String getSnowHost() {
        return snowHost;
    }

    @RequestMapping(value = "/server/info", method = RequestMethod.GET)
    @ResponseBody
    public Object getServerInfo() {
        Object response = ImmutableMap.of("server",
                ImmutableMap.of("hostname", serverHostname, "version", serverVersion));
        return response;
    }

}
