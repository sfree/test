package com.ubs.f35.swift.document;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.DeployTag;
import com.ubs.f35.swift.config.model.GluScriptMetadata;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.config.model.MountPointScheme;
import com.ubs.f35.swift.config.model.Tag;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.environment.model.glu.EntryBuilder;
import com.ubs.f35.swift.environment.model.glu.Script;
import com.ubs.f35.swift.model.JsonObjectMapper;
import com.ubs.f35.swift.service.ArtifactTypeService;

/**
 * Converts the persistent {@link ArtifactConfig} entities into {@link Entry} objects by evaluating the
 * {@link DeployTag} mappings of {@link ArtifactConfig} to {@link Host}. The converted Entry objects are expected to be
 * held as a cached in memory representation of the processes which are managed by swift.
 * 
 * @author stephelu
 * 
 */
public class ArtifactEntryConvertor {
    private static final Logger LOG = LoggerFactory.getLogger(ArtifactEntryConvertor.class);

    private final JsonObjectMapper mapper = JsonObjectMapper.getInstance();
    private OrganisationBeanFactory<ArtifactEntryConvertorPostProcessor> artifactEntryConvertorPostProcessorFactory;
    private ArtifactTypeService artifactTypeService;

    public List<Entry> convert(final ArtifactConfig artifact,
            final Map<DeployTag, Collection<Host>> hostsMap) {

        String organisation = artifact.getEnvironment().getOrganisation().getName();
        Set<String> hosts = getDeploymentHosts(artifact, hostsMap);

        List<Entry> entries = Lists.newArrayList();

        for (String host : hosts) {
            Entry entry = EntryBuilder.create(artifact.getGroupId(), artifact.getArtifactId(),
                    artifact.getArtifactVersion(), artifact.getName());

            entry.setAgent(host);
            entry.setMountPoint(buildMountPoint(host, artifact));
            entry.setScript(getScript(artifact));

            if (StringUtils.hasText(artifact.getScriptArguments())) {
                addScriptArguments(artifact.getScriptArguments(), entry);
            }
            entry.setTags(convertTags(artifact.getTags()));

            if (artifact.isColdStandby()) {
                entry.setColdStandby(true);
                entry.getTags().add("cold-standby");
            }

            artifactEntryConvertorPostProcessorFactory.get(organisation).enrich(artifact, entry);

            GluScriptMetadata metadata = artifactTypeService.getArtifactMetadata(entry.getScript(),
                    artifact.getEnvironment());
            if (metadata != null && !CollectionUtils.isEmpty(metadata.getTags())) {
                entry.getTags().addAll(metadata.getTags());
            }

            Collections.sort(entry.getTags());

            entries.add(entry);
        }

        return entries;
    }

    private Script getScript(final ArtifactConfig artifact) {
        String[] scriptParts = artifact.getScript().split("/", 3);
        String scriptPackage = scriptParts[0];
        String scriptVersion = scriptParts[1];
        String scriptClass = scriptParts[2];

        return new Script(scriptPackage, scriptClass, scriptVersion);
    }

    private Set<String> getDeploymentHosts(final ArtifactConfig artifact,
            final Map<DeployTag, Collection<Host>> hostsMap) {

        Set<String> hosts = Sets.newHashSet();
        for (DeployTag deployTag : artifact.getDeployTags()) {
            Collection<Host> hostDetails = hostsMap.get(deployTag);

            if (hostDetails == null) {
                LOG.warn("Artifact {} has deploytag {} which has no hosts", artifact, deployTag);
                continue;
            }

            for (Host host : hostDetails) {
                hosts.add(host.getHostname());
            }
        }
        return hosts;
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    private void addScriptArguments(final String scriptArguments, final Entry entry) {
        Map scriptArgsMap = mapper.readValue(scriptArguments, Map.class);
        entry.getInitParameters().putAll(scriptArgsMap);
    }

    public static String buildMountPoint(final String host, final ArtifactConfig artifact) {
        StringBuilder builder = new StringBuilder();
        builder.append('/').append(host).append('/');
        if (artifact.getMountPointScheme() == MountPointScheme.GROUP_ARTIFACT_INSTANCE_NAME) {
            builder.append(artifact.getGroupId()).append('/');
        }
        builder.append(artifact.getArtifactId());
        if (!artifact.isDefaultInstance()) {
            builder.append('-').append(artifact.getName());
        }
        return builder.toString();
    }

    private List<String> convertTags(final List<Tag> tags) {
        List<String> tagStrings = Lists.newArrayListWithExpectedSize(tags.size());
        for (Tag tag : tags) {
            tagStrings.add(tag.getTag());
        }

        return tagStrings;
    }

    public void setArtifactEntryConvertorPostProcessorFactory(
            final OrganisationBeanFactory<ArtifactEntryConvertorPostProcessor> artifactEntryConvertorPostProcessorFactory) {
        this.artifactEntryConvertorPostProcessorFactory = artifactEntryConvertorPostProcessorFactory;
    }

    @Required
    public void setArtifactTypeService(final ArtifactTypeService artifactTypeService) {
        this.artifactTypeService = artifactTypeService;
    }
}
