package com.ubs.f35.swift.dao.event;

import com.ubs.f35.swift.config.model.ArtifactConfig;

public interface ArtifactConfigurationChangeListener {
    void afterUpdate(ArtifactConfig config);
}
