package com.ubs.f35.swift.security;

public enum Permission {
    ViewLogs("View Logs", true),
    ManageProcesses("Manage", false),
    Configure("Configure", false),
    ViewProperties("View Properties", true),
    ModifyProperties("Modify Properties", false);

    private String friendlyName;
    private boolean readOnly;

    private Permission(final String friendlyName, final boolean readOnly) {
        this.friendlyName = friendlyName;
        this.readOnly = readOnly;
    }

    public String friendlyName() {
        return friendlyName;
    }

    public boolean isReadOnly() {
        return readOnly;
    }
}
