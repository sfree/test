package com.ubs.f35.swift.environment;

import java.util.List;
import java.util.Properties;

import javax.annotation.Nullable;

import org.linkedin.zookeeper.client.ZKClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.StringUtils;

import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.ubs.f35.core.zookeeper.client.SwiftZooKeeperConfigService;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.config.api.ZooKeeperPropertiesService;
import com.ubs.f35.swift.config.model.EnvironmentConfig;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.event.EnvironmentChangeListener;
import com.ubs.f35.swift.dao.event.SecurityTemplateChangeListener;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.SecurityTemplate;
import com.ubs.f35.swift.deploy.glu.rest.AgentStateChangeListener;
import com.ubs.f35.swift.deploy.glu.rest.ChainedProcessDetailsProvider;
import com.ubs.f35.swift.deploy.glu.rest.GluAgentMonitor;
import com.ubs.f35.swift.deploy.glu.rest.GluDeploymentInvoker;
import com.ubs.f35.swift.deploy.glu.rest.GluHostStatusManager;
import com.ubs.f35.swift.deploy.glu.rest.GluProcessManager;
import com.ubs.f35.swift.deploy.glu.rest.GluProcessMonitor;
import com.ubs.f35.swift.deploy.glu.rest.GluResponseErrorHandler;
import com.ubs.f35.swift.deploy.glu.rest.ProcessStateChangeListener;
import com.ubs.f35.swift.deploy.glu.rest.SwiftSecureClientHttpRequestFactoryBuilder;
import com.ubs.f35.swift.properties.GluAgentZooKeeperConnector;
import com.ubs.f35.swift.properties.GluAgentZooKeeperConnectorBuilder;
import com.ubs.f35.swift.properties.NativeZooKeeperConnector;
import com.ubs.f35.swift.properties.ZooKeeperConnector;
import com.ubs.f35.swift.service.CommandBuilderService;
import com.ubs.f35.swift.service.SwiftServerAgentScriptDeployer;
import com.ubs.f35.swift.web.client.TimeLimitedRestTemplate;
import com.ubs.f35.swift.zookeeper.ZooKeeperTreeTracker;
import com.ubs.f35.swift.zookeeper.ZooKeeperTreeTrackerFactory;

/**
 * Wires up environment specific configuration.
 * <p>
 * Note that this class is not unit tested. We don't verify that spring wiring xml has worked as expected, and just
 * because this has been migrated to java (because it didn't fit the traditional spring model) doesn't mean that it
 * should be unit tested.
 * 
 */
public class EnvironmentConfigurationService extends BaseConfigurationService<Environment, EnvironmentConfig> implements
        EnvironmentChangeListener, SecurityTemplateChangeListener, InitializingBean {
    private static final Logger LOG = LoggerFactory.getLogger(EnvironmentConfigurationService.class);

    private ConfigurableEnvironmentBeanProvider<EnvironmentConfig> envConfigFactory;
    private ConfigurableEnvironmentBeanProvider<String> environmentAccessRightLookup;
    private ConfigurableEnvironmentBeanProvider<String> zookeeperRootFactory;
    private ConfigurableEnvironmentBeanProvider<Boolean> autoRestartEnabledFactory;
    private ConfigurableEnvironmentBeanProvider<ZKClient> zkClientFactory;
    private ConfigurableEnvironmentBeanProvider<GluHostStatusManager> hostStatusManagerFactory;
    private ConfigurableEnvironmentBeanProvider<GluProcessManager> gluProcessManagerFactory;
    private ConfigurableEnvironmentBeanProvider<GluDeploymentInvoker> gluDeploymentInvokerFactory;
    private ConfigurableEnvironmentBeanProvider<ChainedProcessDetailsProvider> processDetailsProviderFactory;
    private ConfigurableEnvironmentBeanProvider<ZooKeeperConnector> zooKeeperConnectorFactory;
    private ConfigurableEnvironmentBeanProvider<ZooKeeperClient> zooKeeperClientFactory;

    private EnvironmentDao environmentDao;
    private ZookeeperFactory<ZKClient> zkClientFactoryBuilder;
    private ZookeeperFactory<ZooKeeperClient> zookeeperClientFactoryBuilder;
    private SwiftServerAgentScriptDeployer agentScriptDeployer;
    private SwiftSecureClientHttpRequestFactoryBuilder swiftSecureClientHttpRequestFactoryBuilder;
    private List<ProcessStateChangeListener> processStateChangeListeners;
    private List<AgentStateChangeListener> agentStateChangeListeners;
    private GluAgentZooKeeperConnectorBuilder gluAgentZooKeeperConnectorBuilder;

    private final Multimap<Environment, ZooKeeperTreeTrackerFactory> zookeeperTrackers = HashMultimap.create();

    public EnvironmentConfigurationService() {
        super(EnvironmentConfig.class);
    }

    @Override
    public void afterUpdate(final SecurityTemplate securityTemplate) {
        // reload all environments using this security template.
        List<Environment> allEnvs = environmentDao.loadEnvironments();
        for (Environment environment : allEnvs) {
            EnvironmentConfig config = loadConfig(environment);
            if (config != null) {
                String envSecTemplate = config.getSecurityConfigTemplate();
                if (securityTemplate.getName().equals(envSecTemplate)) {
                    LOG.info("Reconfiguring environment {} after security template {} update", environment,
                            envSecTemplate);
                    afterUpdate(environment);
                }
            }
        }
    }

    @Override
    public void afterUpdate(final Environment environment) {
        try {
            update(environment);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    synchronized void update(final Environment environment, final EnvironmentConfig config) throws Exception {
        envConfigFactory.set(environment, config);

        environmentAccessRightLookup.set(environment,
                checkNotNullOrEmpty(config.getAccessRight(), "accessRight is mandatory"));
        zookeeperRootFactory.set(environment, config.getZookeeperRoot());
        autoRestartEnabledFactory.set(environment, config.isAutoRestartEnabled());

        CommandBuilderService commandBuilderService = null;
        if (config.getCommandBuilderConfig() != null) {
            LOG.info("Wiring up a CommandBuilderService for environment {}", environment);
            commandBuilderService = new CommandBuilderService();
            commandBuilderService.setBaseInstallDir(config.getCommandBuilderConfig().getBaseInstallDir());
            commandBuilderService.setDefaultScriptsDir(config.getCommandBuilderConfig().getDefaultScriptsDir());
            commandBuilderService.setDefaultSymlink(Objects.firstNonNull(
                    config.getCommandBuilderConfig().getDefaultSymlink(), environment.getName()));
        }

        // Simple implementation. Assume the zookeeper configuration has changed and needs to be refreshed. Could be
        // optimised to check if it has changed, but this config is updated so infrequently that would be overkill.
        // Need to stop the old ZookeeperTreeTracker instances so they can be gc'ed
        for (ZooKeeperTreeTrackerFactory trackerFactory : zookeeperTrackers.get(environment)) {
            trackerFactory.destroy();
        }
        zookeeperTrackers.removeAll(environment);

        ZKClient linkedInZkClient = buildZookeeperConnection(environment, config, zkClientFactory,
                zkClientFactoryBuilder);

        String agentTrackPath = config.getZookeeperRoot() + "/agents/fabrics/" + environment.getName() + "/instances/";
        ZooKeeperTreeTracker agentTracker = createZooKeeperTreeTracker(environment, config, linkedInZkClient,
                agentTrackPath);

        String mountPointTrackPath = config.getZookeeperRoot() + "/agents/fabrics/" + environment.getName() + "/state/";
        ZooKeeperTreeTracker mountPointTracker = createZooKeeperTreeTracker(environment, config, linkedInZkClient,
                mountPointTrackPath);

        GluAgentMonitor gluAgentMonitor = new GluAgentMonitor();
        gluAgentMonitor.setAgentStateChangeListeners(agentStateChangeListeners);
        gluAgentMonitor.setEnvironment(environment);
        gluAgentMonitor.setTreeTracker(agentTracker);

        GluProcessMonitor gluProcessMonitor = new GluProcessMonitor();
        gluProcessMonitor.setProcessStateChangeListeners(processStateChangeListeners);
        gluProcessMonitor.setEnvironment(environment);
        gluProcessMonitor.setTreeTracker(mountPointTracker);

        GluHostStatusManager hostStatusManager = new GluHostStatusManager();
        hostStatusManager.setAgentTracker(agentTracker);
        hostStatusManager.setMountPointTracker(mountPointTracker);

        hostStatusManagerFactory.set(environment, hostStatusManager);

        GluProcessManager gluProcessManager = new GluProcessManager();
        gluProcessManager.setEnvironment(environment.getName());
        gluProcessManager.setAgentTracker(agentTracker);
        gluProcessManager.setMountPointTracker(mountPointTracker);

        gluProcessManagerFactory.set(environment, gluProcessManager);

        TimeLimitedRestTemplate agentRestTemplate = new TimeLimitedRestTemplate(
                swiftSecureClientHttpRequestFactoryBuilder.buildForConfig(config.getSecurityConfigTemplate()));
        agentRestTemplate.setErrorHandler(new GluResponseErrorHandler());

        // Register (or deregister) for jmx operations.
        GluDeploymentInvoker gluDeploymentInvoker = new GluDeploymentInvoker();
        gluDeploymentInvoker.setAgentScriptDeployer(agentScriptDeployer);
        gluDeploymentInvoker.setCommandBuilderService(commandBuilderService);
        gluDeploymentInvoker.setDefaultTransitionTimeout("30m");
        gluDeploymentInvoker.setGluProcessManager(gluProcessManager);
        gluDeploymentInvoker.setTemplate(agentRestTemplate);

        gluDeploymentInvokerFactory.set(environment, gluDeploymentInvoker);

        // A list of ordered process details providers, fastest first to slower / more reliable last
        ChainedProcessDetailsProvider chainedProcessDetailsProvider = new ChainedProcessDetailsProvider();
        chainedProcessDetailsProvider.setProcessDetailsProviders(Lists.newArrayList(gluProcessManager,
                gluDeploymentInvoker));

        processDetailsProviderFactory.set(environment, chainedProcessDetailsProvider);

        configureZookeeperPropertiesFunctionality(environment, config, commandBuilderService, gluDeploymentInvoker);
    }

    @SuppressWarnings("rawtypes")
    protected ZooKeeperTreeTracker createZooKeeperTreeTracker(final Environment environment,
            final EnvironmentConfig config, final ZKClient linkedInZkClient, final String trackPath) throws Exception {
        ZooKeeperTreeTrackerFactory trackerFactory = new ZooKeeperTreeTrackerFactory();
        trackerFactory.setEnvironment(environment);
        trackerFactory.setZkClient(linkedInZkClient);
        trackerFactory.setTrackPath(trackPath);

        ZooKeeperTreeTracker tracker = trackerFactory.getObject();
        trackerFactory.startTracking();

        // Remember the created trackers so they can be disposed of later.
        zookeeperTrackers.put(environment, trackerFactory);

        return tracker;
    }

    private void configureZookeeperPropertiesFunctionality(final Environment environment,
            final EnvironmentConfig config, final CommandBuilderService commandBuilderService,
            final GluDeploymentInvoker gluDeploymentInvoker) {
        ZooKeeperClient zooKeeperClient = buildZookeeperConnection(environment, config, zooKeeperClientFactory,
                zookeeperClientFactoryBuilder);

        ZooKeeperService zooKeeperService = new ZooKeeperService(zooKeeperClient);
        register(environment, zooKeeperService);

        SwiftZooKeeperConfigService zooKeeperConfigService = new SwiftZooKeeperConfigService(zooKeeperClient);
        register(environment, zooKeeperConfigService);

        ZooKeeperPropertiesService zooKeeperPropertiesService = new ZooKeeperPropertiesService();
        zooKeeperPropertiesService.setZooKeeperConfigService(zooKeeperConfigService);
        zooKeeperPropertiesService.setConfigRootPath(
                checkNotNullOrEmpty(config.getZookeeperPropertiesRoot(), "zookeeperPropertiesRoot root is mandatory"));
        register(environment, zooKeeperPropertiesService);

        Properties zooKeeperClientProperties = new Properties();
        zooKeeperClientProperties.putAll(config.getZookeeperConnectionDetails());

        // Only use the GluAgentZooKeeperConnector command framework for Neo deployments. It's a bit crap having to
        // deploy something to all agents to support saving zookeeper properties, plus the agents deployed to windows
        // can't use the same command. TODO Need a single consistent solution.
        ZooKeeperConnector zooKeeperConnector = new NativeZooKeeperConnector(zooKeeperService,
                zooKeeperPropertiesService, zooKeeperConfigService, config);
        if (environment.getOrganisation().getName().equals("Neo")) {
            LOG.info("Using GluAgentZooKeeperConnector for Neo environment {}", environment);
            GluAgentZooKeeperConnector gluAgentZooKeeperConnector = gluAgentZooKeeperConnectorBuilder.build(
                    environment, gluDeploymentInvoker, commandBuilderService, zooKeeperClientProperties,
                    zooKeeperConnector);
            zooKeeperConnectorFactory.set(environment, gluAgentZooKeeperConnector);
        } else {
            zooKeeperConnectorFactory.set(environment, zooKeeperConnector);
        }
    }

    protected synchronized <T> T buildZookeeperConnection(final Environment environment,
            final EnvironmentConfig config,
            final ConfigurableEnvironmentBeanProvider<T> envBeanFactory, final ZookeeperFactory<T> zookeeperFactory) {
        T existingZookeeperClient = envBeanFactory.tryGet(environment);

        T zooKeeperClient = zookeeperFactory.getZookeeperForConfig(config.getZookeeperConnectionDetails());
        envBeanFactory.set(environment, zooKeeperClient);

        // Return the old zookeeper connection after creating the new one (the new connection details may be the same
        // meaning the same instance will be returned as long as it already hasn't been discarded from the pool.
        if (existingZookeeperClient != null) {
            LOG.info("Releasing zookeeper connection {} for environment {}", existingZookeeperClient, environment);
            zookeeperFactory.returnZookeeper(existingZookeeperClient);
        }

        return zooKeeperClient;
    }

    private void register(final Environment environment, final Object service) {
        // no-op currently, but placeholder if functionality needs to be registered for JMX.
    }

    public static String checkNotNullOrEmpty(final String reference, @Nullable final Object errorMessage) {
        Preconditions.checkArgument(StringUtils.hasText(reference), errorMessage);
        return reference;
    }

    @Override
    void init() throws Exception {
        List<Environment> environments = environmentDao.loadEnvironments();
        for (Environment environment : environments) {
            update(environment);
        }
    }

    @Required
    public void setEnvironmentAccessRightLookup(
            final ConfigurableEnvironmentBeanProvider<String> environmentAccessRightLookup) {
        this.environmentAccessRightLookup = environmentAccessRightLookup;
    }

    @Required
    public void setZookeeperRootFactory(final ConfigurableEnvironmentBeanProvider<String> zookeeperRootFactory) {
        this.zookeeperRootFactory = zookeeperRootFactory;
    }

    @Required
    public void setAutoRestartEnabledFactory(
            final ConfigurableEnvironmentBeanProvider<Boolean> autoRestartEnabledFactory) {
        this.autoRestartEnabledFactory = autoRestartEnabledFactory;
    }

    @Required
    public void setZkClientFactory(final ConfigurableEnvironmentBeanProvider<ZKClient> zkClientFactory) {
        this.zkClientFactory = zkClientFactory;
    }

    @Required
    public void setHostStatusManagerFactory(
            final ConfigurableEnvironmentBeanProvider<GluHostStatusManager> hostStatusManagerFactory) {
        this.hostStatusManagerFactory = hostStatusManagerFactory;
    }

    @Required
    public void setGluProcessManagerFactory(
            final ConfigurableEnvironmentBeanProvider<GluProcessManager> gluProcessManagerFactory) {
        this.gluProcessManagerFactory = gluProcessManagerFactory;
    }

    @Required
    public void setGluDeploymentInvokerFactory(
            final ConfigurableEnvironmentBeanProvider<GluDeploymentInvoker> gluDeploymentInvokerFactory) {
        this.gluDeploymentInvokerFactory = gluDeploymentInvokerFactory;
    }

    @Required
    public void setZkClientFactoryBuilder(final ZookeeperFactory<ZKClient> zkClientFactoryBuilder) {
        this.zkClientFactoryBuilder = zkClientFactoryBuilder;
    }

    @Required
    public void setAgentScriptDeployer(final SwiftServerAgentScriptDeployer agentScriptDeployer) {
        this.agentScriptDeployer = agentScriptDeployer;
    }

    @Required
    public void setSwiftSecureClientHttpRequestFactoryBuilder(
            final SwiftSecureClientHttpRequestFactoryBuilder swiftSecureClientHttpRequestFactoryBuilder) {
        this.swiftSecureClientHttpRequestFactoryBuilder = swiftSecureClientHttpRequestFactoryBuilder;
    }

    @Required
    public void setProcessDetailsProviderFactory(
            final ConfigurableEnvironmentBeanProvider<ChainedProcessDetailsProvider> processDetailsProviderFactory) {
        this.processDetailsProviderFactory = processDetailsProviderFactory;
    }

    @Required
    public void setAgentStateChangeListeners(final List<AgentStateChangeListener> agentStateChangeListeners) {
        this.agentStateChangeListeners = agentStateChangeListeners;
    }

    @Required
    public void setProcessStateChangeListeners(final List<ProcessStateChangeListener> processStateChangeListeners) {
        this.processStateChangeListeners = processStateChangeListeners;
    }

    @Required
    public void setZookeeperClientFactoryBuilder(final ZookeeperFactory<ZooKeeperClient> zookeeperClientFactoryBuilder) {
        this.zookeeperClientFactoryBuilder = zookeeperClientFactoryBuilder;
    }

    @Required
    public void setGluAgentZooKeeperConnectorBuilder(
            final GluAgentZooKeeperConnectorBuilder gluAgentZooKeeperConnectorBuilder) {
        this.gluAgentZooKeeperConnectorBuilder = gluAgentZooKeeperConnectorBuilder;
    }

    /**
     * TODO make the GluAgentZooKeeperConnector non environment specific. Should implement the same interface as
     * {@link NativeZooKeeperConnector} and callers shouldn't care which implementation is doing the save.
     */
    @Required
    public void setZooKeeperConnectorFactory(
            final ConfigurableEnvironmentBeanProvider<ZooKeeperConnector> zooKeeperConnectorFactory) {
        this.zooKeeperConnectorFactory = zooKeeperConnectorFactory;
    }

    @Required
    public void setEnvConfigFactory(final ConfigurableEnvironmentBeanProvider<EnvironmentConfig> envConfigFactory) {
        this.envConfigFactory = envConfigFactory;
    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }

    @Required
    public void setZooKeeperClientFactory(
            final ConfigurableEnvironmentBeanProvider<ZooKeeperClient> zooKeeperClientFactory) {
        this.zooKeeperClientFactory = zooKeeperClientFactory;
    }

}
