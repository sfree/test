package com.ubs.f35.swift.util;

import com.google.common.base.Function;
import com.ubs.f35.swift.dao.model.Environment;

public class EnvironmentCloneFunction implements Function<Environment, Environment> {
    public static final EnvironmentCloneFunction INSTANCE = new EnvironmentCloneFunction();

    @Override
    public Environment apply(final Environment input) {
        return new Environment(input.getId(), input.getName(), input.getOrganisation());
    }
}
