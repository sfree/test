package com.ubs.f35.swift.deploy.client.action;

import com.google.common.base.Function;
import com.ubs.f35.swift.deploy.glu.action.TransitionAction;

public class ClientActionConvertor implements Function<TransitionAction, ClientPlanAction> {
    public static final ClientActionConvertor INSTANCE = new ClientActionConvertor();

    @Override
    public ClientPlanAction apply(final TransitionAction input) {
        return new ClientPlanAction(input.getName(), input.getDeploymentState(), input.getId());
    }

}
