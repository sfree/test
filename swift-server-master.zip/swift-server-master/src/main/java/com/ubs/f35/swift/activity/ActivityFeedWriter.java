package com.ubs.f35.swift.activity;

import java.util.List;
import java.util.Set;

import org.apache.commons.lang.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.f35.swift.activity.data.ActivityData;
import com.ubs.f35.swift.activity.data.DefaultPropertiesActivityData;
import com.ubs.f35.swift.activity.data.DeploymentActivityData;
import com.ubs.f35.swift.activity.data.PropertiesActivityData;
import com.ubs.f35.swift.activity.data.ReleaseActivityData;
import com.ubs.f35.swift.dao.Activity;
import com.ubs.f35.swift.dao.Activity.ActivityType;
import com.ubs.f35.swift.dao.Activity.Verb;
import com.ubs.f35.swift.dao.ActivityDao;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseDefinitionDao;
import com.ubs.f35.swift.dao.ReleaseLink;
import com.ubs.f35.swift.dao.TeamDao;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.Team;
import com.ubs.f35.swift.state.OperationContextProvider;

/**
 * Provides methods for adding events to the Activity Feed.
 * 
 * @author levyjo
 * 
 */
public class ActivityFeedWriter {

    private static final Logger LOG = LoggerFactory.getLogger(ActivityFeedWriter.class);

    private ActivityDao activityDao;
    private ReleaseDefinitionDao releaseDefinitionDao;
    private TeamDao teamDao;

    private OperationContextProvider contextProvider;

    @Transactional
    public void deploy(final Deployment deployment) {
        for (EnvDeployment envDeployment : deployment.getEnvDeployments()) {
            Environment environment = envDeployment.getEnvironment();

            Activity activity = new Activity();
            activity.setUser(contextProvider.getCurrentUser());
            activity.setEnvironment(environment);
            activity.setOrganisation(environment.getOrganisation());
            activity.setType(ActivityType.DEPLOYMENT);
            activity.setVerb(Verb.CREATE);
            activity.setObjectId(deployment.getReleaseId());
            ReleaseDefinition releaseDef = releaseDefinitionDao.load(deployment.getReleaseId());
            activity.setData(DeploymentActivityData.newDeployment(deployment, envDeployment.getDeploymentStatus(),
                    releaseDef));
            createOrUpdate(activity);
        }
    }

    public void createRelease(final ReleaseDefinition releaseDefinition) {
        ReleaseActivityData data = ReleaseActivityData.newRelease(releaseDefinition);
        createOrUpdate(releaseActivity(releaseDefinition, Verb.CREATE, data));
    }

    public void modifyReleaseDetails(final ReleaseDefinition oldReleaseDefinition,
            final ReleaseDefinition newReleaseDefinition) {

        ReleaseActivityData data = ReleaseActivityData.editDetails(newReleaseDefinition);
        if (oldReleaseDefinition.getDescription() == null)
        {
            oldReleaseDefinition.setDescription(""); // Correct comparison as Oracle will have stored empty description
                                                     // as null
        }

        if (!newReleaseDefinition.getName().equals(oldReleaseDefinition.getName())) {
            data.setOldReleaseName(oldReleaseDefinition.getName());
        }
        if (!ObjectUtils.defaultIfNull(newReleaseDefinition.getDescription(), "")
                .equals(oldReleaseDefinition.getDescription())) {
            data.setDescriptionChanged(true);
        }
        if (ObjectUtils.notEqual(newReleaseDefinition.getReleaseDate(), oldReleaseDefinition.getReleaseDate())) {
            data.setReleaseDateChanged(true);
            data.setOldReleaseDate(oldReleaseDefinition.getReleaseDate());
            data.setNewReleaseDate(newReleaseDefinition.getReleaseDate());
        }

        if (!data.isEmpty()) {
            createOrUpdate(releaseActivity(oldReleaseDefinition, Verb.MODIFY, data));
        }
    }

    public void modifyReleaseDescription(final ReleaseDefinition releaseDefinition) {
        ReleaseActivityData data = ReleaseActivityData.editDescription(releaseDefinition);
        createOrUpdate(releaseActivity(releaseDefinition, Verb.MODIFY, data));
    }

    public void addReleaseArtifact(final ReleaseDefinition releaseDefinition, final Artifact artifact) {
        ReleaseActivityData data = ReleaseActivityData.addArtifact(releaseDefinition, artifact);
        createOrUpdate(releaseActivity(releaseDefinition, Verb.MODIFY, data));
    }

    public void modifyReleaseArtifact(final ReleaseDefinition releaseDefinition, final Artifact oldArtifact,
            final Artifact newArtifact) {
        ReleaseActivityData data = ReleaseActivityData.modifyArtifact(releaseDefinition, oldArtifact, newArtifact);
        createOrUpdate(releaseActivity(releaseDefinition, Verb.MODIFY, data));
    }

    public void modifyReleaseArtifacts(final ReleaseDefinition releaseDefinition, final List<Artifact> oldArtifacts,
            final List<Artifact> newArtifacts) {
        ReleaseActivityData data = ReleaseActivityData.modifyArtifacts(releaseDefinition, oldArtifacts, newArtifacts);
        createOrUpdate(releaseActivity(releaseDefinition, Verb.MODIFY, data));
    }

    public void removeReleaseArtifact(final ReleaseDefinition releaseDefinition, final Artifact artifact) {
        ReleaseActivityData data = ReleaseActivityData.removeArtifact(releaseDefinition, artifact);
        createOrUpdate(releaseActivity(releaseDefinition, Verb.MODIFY, data));
    }

    public void addReleaseLink(final ReleaseDefinition releaseDefinition, final ReleaseLink releaseLink) {
        ReleaseActivityData data = ReleaseActivityData.addReleaseLink(releaseDefinition, releaseLink);
        createOrUpdate(releaseActivity(releaseDefinition, Verb.MODIFY, data));
    }

    public void removeReleaseLink(final ReleaseDefinition releaseDefinition, final ReleaseLink releaseLink) {
        ReleaseActivityData data = ReleaseActivityData.removeReleaseLink(releaseDefinition, releaseLink);
        createOrUpdate(releaseActivity(releaseDefinition, Verb.MODIFY, data));
    }

    public void lockUnlockRelease(final ReleaseDefinition releaseDefinition, final boolean lock) {
        ReleaseActivityData data = ReleaseActivityData.lockUnlock(releaseDefinition, lock);
        createOrUpdate(releaseActivity(releaseDefinition, Verb.MODIFY, data));
    }

    private Activity releaseActivity(final ReleaseDefinition releaseDefinition, final Verb verb,
            final ReleaseActivityData data) {
        Activity activity = new Activity();
        activity.setUser(contextProvider.getCurrentUser());
        activity.setType(ActivityType.RELEASE);
        activity.setVerb(verb);
        activity.setObjectId(releaseDefinition.getId());
        // fully initialised team may not have been passed in from the client.
        Team team = teamDao.load(releaseDefinition.getTeam().getId());
        activity.setOrganisation(team.getOrganisation());
        activity.setData(data);
        return activity;
    }

    public void createProperties(final Artifact artifact, final Environment environment) {
        Activity activity = new Activity();
        activity.setUser(contextProvider.getCurrentUser());
        activity.setEnvironment(environment);
        activity.setOrganisation(environment.getOrganisation());
        activity.setType(ActivityType.PROPERTIES);
        activity.setVerb(Verb.CREATE);
        activity.setObjectId(artifact.getId());
        activity.setData(new PropertiesActivityData(artifact));
        createOrUpdate(activity);
    }

    public void modifyProperties(final Artifact artifact, final Environment environment,
            final Set<String> newProperties,
            final Set<String> modifiedProperties, final Set<String> removedProperties) {
        Activity activity = new Activity();
        activity.setUser(contextProvider.getCurrentUser());
        activity.setEnvironment(environment);
        activity.setOrganisation(environment.getOrganisation());
        activity.setType(ActivityType.PROPERTIES);
        activity.setVerb(Verb.MODIFY);
        activity.setObjectId(artifact.getId());
        activity.setData(new PropertiesActivityData(artifact, newProperties, modifiedProperties, removedProperties));
        createOrUpdate(activity);
    }

    /*
     * Not current used by client
     */
    public void modifyOrCreateProperty(final Artifact artifact, final Environment environment, final String property) {
        Activity activity = new Activity();
        activity.setUser(contextProvider.getCurrentUser());
        activity.setEnvironment(environment);
        activity.setOrganisation(environment.getOrganisation());
        activity.setType(ActivityType.PROPERTIES);
        activity.setVerb(Verb.MODIFY);
        activity.setObjectId(artifact.getId());
        activity.setData(PropertiesActivityData.modifyProperty(artifact, property));
        createOrUpdate(activity);
    }

    /*
     * Not currently used by client
     */
    public void removeProperty(final Artifact artifact, final Environment environment, final String property) {
        Activity activity = new Activity();
        activity.setUser(contextProvider.getCurrentUser());
        activity.setEnvironment(environment);
        activity.setOrganisation(environment.getOrganisation());
        activity.setType(ActivityType.PROPERTIES);
        activity.setVerb(Verb.DELETE);
        activity.setData(PropertiesActivityData.removeProperty(artifact, property));
        createOrUpdate(activity);
    }

    public void modifyPropertyDefaults(final Environment environment, final Set<String> newProperties,
            final Set<String> modifiedProperties, final Set<String> removedProperties) {
        Activity activity = new Activity();
        activity.setUser(contextProvider.getCurrentUser());
        activity.setEnvironment(environment);
        activity.setOrganisation(environment.getOrganisation());
        activity.setType(ActivityType.PROPERTY_DEFAULTS);
        activity.setVerb(Verb.MODIFY);
        activity.setData(new DefaultPropertiesActivityData(newProperties, modifiedProperties, removedProperties));
        createOrUpdate(activity);
    }

    /*
     * Not currently used by client
     */
    public void modifyOrCreatePropertyDefault(final Environment environment, final String property) {
        Activity activity = new Activity();
        activity.setUser(contextProvider.getCurrentUser());
        activity.setEnvironment(environment);
        activity.setOrganisation(environment.getOrganisation());
        activity.setType(ActivityType.PROPERTY_DEFAULTS);
        activity.setVerb(Verb.MODIFY); // we can't distinguish between adding and editing a single default property
        activity.setData(DefaultPropertiesActivityData.modifyProperty(property));
        createOrUpdate(activity);
    }

    /*
     * Not currently used by client
     */
    public void removePropertyDefault(final Environment environment, final String property) {
        Activity activity = new Activity();
        activity.setUser(contextProvider.getCurrentUser());
        activity.setEnvironment(environment);
        activity.setOrganisation(environment.getOrganisation());
        activity.setType(ActivityType.PROPERTY_DEFAULTS);
        activity.setVerb(Verb.DELETE);
        activity.setData(DefaultPropertiesActivityData.removeProperty(property));
        createOrUpdate(activity);
    }

    /**
     * Saves the activity in the database.<br>
     * First checks whether the given activity can be amalgamated with a previous activity, and if so, merges it with
     * the previous activity and updates that activity. Otherwise, writes this as a new activity.
     * 
     * @param activity
     */
    private void createOrUpdate(final Activity activity) {

        if (activity.getData() != null && activity.isAggregatable()) {

            Activity previousActivity = activityDao.getAggregatableActivity(activity);

            if (previousActivity != null && previousActivity.getData() != null) {
                // Activity can be aggregated with a previous one

                Class<? extends ActivityData> activityTypeClass = activity.getType().getDataType();
                ActivityData newData = activity.getTypedData(activityTypeClass);
                ActivityData mergedData = previousActivity.getTypedData(activityTypeClass).merge(newData);
                if (mergedData.isEmpty()) {
                    // New activity has cancelled out the changes from previous activity
                    activityDao.removeEmptyActivity(previousActivity);
                } else {
                    // Update previous activity
                    previousActivity.setData(mergedData);
                }
                return;
            }
        }
        // Create new activity
        activityDao.create(activity);
    }

    @Required
    public void setContextProvider(final OperationContextProvider contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Required
    public void setActivityDao(final ActivityDao activityDao) {
        this.activityDao = activityDao;
    }

    @Required
    public void setReleaseDefinitionDao(final ReleaseDefinitionDao releaseDefinitionDao) {
        this.releaseDefinitionDao = releaseDefinitionDao;
    }

    @Required
    public void setTeamDao(final TeamDao teamDao) {
        this.teamDao = teamDao;
    }
}
