package com.ubs.f35.swift.dao.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Function;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ArtifactDao;
import com.ubs.f35.swift.dao.ArtifactPropertyKey;
import com.ubs.f35.swift.dao.ArtifactPropertyKeysDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.processor.ProcessorUtil;
import com.ubs.f35.swift.properties.model.PropertyKey;

/**
 * Data access object for property keys cache in data store.
 * 
 * @author levyjo
 * 
 */
public class HibernateArtifactPropertyKeysDao extends HibernateDaoSupport implements ArtifactPropertyKeysDao {

    private static final Logger LOG = LoggerFactory.getLogger(HibernateArtifactPropertyKeysDao.class);

    private ArtifactDao artifactDao;
    private final static int MAX_KEY_LENGTH = 1024;

    @SuppressWarnings("unchecked")
    @Override
    @Transactional
    public List<PropertyKey> getPropertyKeys(final Artifact artifact) {

        Artifact persistentArtifact = artifactDao.resolvePersistentArtifact(artifact);

        Query query = getSession().createQuery(
                "from ArtifactPropertyKey where artifact.id = :artifactId order by key");
        query.setParameter("artifactId", persistentArtifact.getId());

        List<ArtifactPropertyKey> artifactPropKeys = query.list();

        return ProcessorUtil.transform(artifactPropKeys, new Function<ArtifactPropertyKey, PropertyKey>() {
            @Override
            public PropertyKey apply(final ArtifactPropertyKey input) {
                return new PropertyKey(input.getKey(), input.getSuggestedValue(), input.getDocumentation());
            }
        });
    }

    @Override
    @Transactional
    public void savePropertyKeys(final Artifact artifact, final List<PropertyKey> listOfPropertyKeys) {

        Artifact persistentArtifact = artifactDao.resolvePersistentArtifact(artifact);

        for (PropertyKey propertyKey : listOfPropertyKeys) {
            if (checkLength("property key", propertyKey.getName())
                    && checkLength("property suggested value", propertyKey.getSuggestedValue())
                    && checkLength("property documentation", propertyKey.getDocumentation())) {
                ArtifactPropertyKey artifactPropertyKey = new ArtifactPropertyKey();
                artifactPropertyKey.setArtifact(persistentArtifact);
                artifactPropertyKey.setKey(propertyKey.getName());
                artifactPropertyKey.setSuggestedValue(propertyKey.getSuggestedValue());
                artifactPropertyKey.setDocumentation(propertyKey.getDocumentation());
                getSession().saveOrUpdate(artifactPropertyKey);
            }
        }

    }

    private boolean checkLength(final String field, final String value) {
        if (value != null && value.length() > MAX_KEY_LENGTH) {
            LOG.warn("Not saving  {} in cache as it is longer than {} characters", new Object[] { field, value,
                    MAX_KEY_LENGTH });
            return false;
        }
        return true;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    /*
     * A new transaction is required here because this method is called from within the
     * ArtifactCommonConfigurationChangeListener on saving ArtifactCommonConfig - Hibernate tries to flush the dirty
     * ArtifactCommonConfig before is runs this query to deletePropertyKeys. But that flush then invokes the interceptor
     * again which invokes the listener again, etc., resulting in a stack overflow. Note that acording to the Hibernate
     * docs for Interceptor (http://docs.jboss.org/hibernate/orm/3.6/javadocs/org/hibernate/Interceptor.html), we
     * shouldn't really be invoking the Session from the interceptor callback at all.
     */
    public void deletePropertyKeys(final NexusArtifact artifact) {

        Query query = getSession()
                .createQuery(
                        "delete from ArtifactPropertyKey where artifact.id in (select id from Artifact a where a.groupId = :groupId and a.artifactId = :artifactId)");
        query.setParameter("groupId", artifact.getGroupId());
        query.setParameter("artifactId", artifact.getArtifactId());
        query.executeUpdate();

    }

    public void setArtifactDao(final ArtifactDao artifactDao) {
        this.artifactDao = artifactDao;
    }

}
