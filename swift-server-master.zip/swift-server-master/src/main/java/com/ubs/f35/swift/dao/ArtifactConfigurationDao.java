package com.ubs.f35.swift.dao;

import java.util.List;
import java.util.Set;

import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.DeployTag;
import com.ubs.f35.swift.dao.hibernate.AuditEntry;
import com.ubs.f35.swift.dao.model.Environment;

public interface ArtifactConfigurationDao {

    ArtifactConfig save(ArtifactConfig artifact);

    List<ArtifactConfig> load(Environment environment, String groupId, String artifactId);

    List<ArtifactConfig> load(List<Environment> environments, String groupId, String artifactId);

    List<ArtifactConfig> load(String groupId, String artifactId);

    ArtifactConfig load(Environment environment, String groupId, String artifactId, String name);

    void delete(Environment environment, String groupId, String artifactId, String name);

    List<ArtifactConfig> loadAll();

    List<ArtifactConfig> loadAll(Environment environment);

    /**
     * Returns artifacts which have have one of the {@link DeployTag} specified in the inclusionList, UNLESS they have
     * one of the tags included in the exclusion list.
     * 
     * @param exclusionList
     *            Artifacts will NOT be included any of these {@link DeployTag}
     * @param inclusionList
     *            Artifacts will be returned if they include any of these {@link DeployTag}
     * @return
     */
    List<ArtifactConfig> loadWithDeployTags(Set<DeployTag> exclusionList, Set<DeployTag> inclusionList);

    List<AuditEntry<ArtifactConfig>> getAuditHistory(ArtifactConfig artifactId, PagingFilter daoFilter);

    List<Object[]> loadArtifactsWhichDifferentVersions(Environment base, Environment target);

}
