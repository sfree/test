package com.ubs.f35.swift.deploy.validator;

import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlanBuilder;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlanStrategy;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;

public interface DeploymentPlanValidator {
    void validate(DeploymentPlanBuilder builder, Environment environment,
            DeploymentAction action, DeploymentPlanStrategy strategy);
}
