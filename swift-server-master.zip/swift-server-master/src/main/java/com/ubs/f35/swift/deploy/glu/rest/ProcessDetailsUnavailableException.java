package com.ubs.f35.swift.deploy.glu.rest;

public class ProcessDetailsUnavailableException extends RuntimeException {
    public ProcessDetailsUnavailableException(final String message) {
        super(message);
    }
}
