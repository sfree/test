package com.ubs.f35.swift.service.glu;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.google.common.base.Predicate;
import com.ubs.f35.swift.environment.model.glu.Entry;

/**
 * Returns deployment model entries which match the agent
 * 
 * @author levyjo
 * 
 */
public class EntryMatchesGroupsPredicate implements Predicate<Entry> {

    private final List<String> groups;

    public EntryMatchesGroupsPredicate(final List<String> groups) {
        this.groups = groups;
    }

    @Override
    public boolean apply(final Entry entry) {
        if (CollectionUtils.isEmpty(groups)) {
            return true;
        }
        return groups.contains(entry.getGroupId());
    }

}
