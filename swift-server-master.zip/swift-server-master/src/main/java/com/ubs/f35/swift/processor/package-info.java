package com.ubs.f35.swift.processor;

/**
 * This package contains all of the endpoints which are exposed to the client. 
 */
