package com.ubs.f35.swift.deploy.glu.plan;

import java.util.List;

import com.ubs.f35.swift.deploy.glu.action.Action;
import com.ubs.f35.swift.deploy.glu.action.BaseGroupedAction;
import com.ubs.f35.swift.deploy.glu.action.ManualAction;
import com.ubs.f35.swift.deploy.glu.action.TransitionAction;

public abstract class BaseActionVisitor {

    public void visitActions(final List<Action> actions) {
        for (Action action : actions) {
            visitAction(action);
        }
    }

    protected void visitAction(final Action action) {
        if (action instanceof BaseGroupedAction) {
            visitAction((BaseGroupedAction) action);
        } else if (action instanceof TransitionAction) {
            visitAction((TransitionAction) action);
        } else if (action instanceof ManualAction) {
            // not required
        } else {
            throw new IllegalStateException("Unexpected action " + action);
        }
    }

    protected void visitAction(final BaseGroupedAction action) {
        // Visit all child actions by default
        visitActions(action.getIncluded());
    }

    protected void visitAction(final TransitionAction action) {
        // no default
    }

}
