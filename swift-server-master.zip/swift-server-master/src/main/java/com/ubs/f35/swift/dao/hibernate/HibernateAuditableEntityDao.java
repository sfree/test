package com.ubs.f35.swift.dao.hibernate;

import java.util.List;

import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.RevisionType;
import org.hibernate.envers.query.AuditEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.SwiftRevEntry;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;

/**
 * Common support for returning the audit history of auditable entities.
 */
public abstract class HibernateAuditableEntityDao<ID, VALUE> extends HibernateDaoSupport {
    private final Logger LOG = LoggerFactory.getLogger(this.getClass());

    @SuppressWarnings("unchecked")
    public List<AuditEntry<VALUE>> getAuditHistory(final ID entityId, final PagingFilter daoFilter) {
        AuditReader reader = AuditReaderFactory.get(getSession());

        List<Object[]> auditHistory = reader.createQuery()
                .forRevisionsOfEntity(getValueClass(), getValueClass().getName(), false, true)
                .addOrder(AuditEntity.revisionNumber().desc())
                .add(AuditEntity.id().eq(entityId))
                .setFirstResult(daoFilter.getStart())
                .setMaxResults(daoFilter.getRecords())
                .getResultList();

        LOG.debug("audit history {}", auditHistory);

        List<AuditEntry<VALUE>> auditEntries = Lists.newArrayListWithExpectedSize(auditHistory.size());
        for (Object[] audit : auditHistory) {
            AuditEntry<VALUE> entry = new AuditEntry<VALUE>((VALUE) audit[0],
                    (SwiftRevEntry) audit[1], (RevisionType) audit[2]);

            auditEntries.add(entry);
        }
        return auditEntries;
    }

    @SuppressWarnings("unchecked")
    public AuditEntry<VALUE> loadRevisionAuditEntry(final ID entityId, final Integer revision) {
        AuditReader reader = AuditReaderFactory.get(getSession());
        Object[] audit = (Object[]) reader.createQuery()
                .forRevisionsOfEntity(getValueClass(), getValueClass().getName(), false, true)
                .add(AuditEntity.revisionNumber().eq(revision))
                .add(AuditEntity.id().eq(entityId))
                .getSingleResult();
        return new AuditEntry<VALUE>((VALUE) audit[0],
                (SwiftRevEntry) audit[1], (RevisionType) audit[2]);
    }

    public Integer getRevisionAtDate(final ID entityId, final Long asAtDate) {
        AuditReader reader = AuditReaderFactory.get(getSession());
        return (Integer) reader.createQuery()
                .forRevisionsOfEntity(getValueClass(), getValueClass().getName(), false, true)
                .addProjection(AuditEntity.revisionNumber().min())
                .add(AuditEntity.revisionProperty("timestamp").ge(asAtDate))
                .add(AuditEntity.id().eq(entityId))
                .getSingleResult();
    }

    public Integer getLatestRevisionId(final ID entityId) {
        AuditReader reader = AuditReaderFactory.get(getSession());
        Integer revision = (Integer) reader.createQuery()
                .forRevisionsOfEntity(getValueClass(), true, false)
                .addProjection(AuditEntity.revisionNumber().max())
                .add(AuditEntity.id().eq(entityId))
                .getSingleResult();

        return revision;
    }

    @SuppressWarnings("unchecked")
    public VALUE loadRevision(final ID entityId, final Integer revision) {
        AuditReader reader = AuditReaderFactory.get(getSession());
        return (VALUE) reader.createQuery()
                .forEntitiesAtRevision(getValueClass(), revision)
                .add(AuditEntity.id().eq(entityId))
                .getSingleResult();
    }

    abstract Class<VALUE> getValueClass();

}
