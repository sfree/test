package com.ubs.f35.swift.deploy.client.rollback;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Required;

import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.SetMultimap;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.Deployment.DeploymentType;
import com.ubs.f35.swift.dao.DeploymentDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.plan.Warning;
import com.ubs.f35.swift.deploy.validator.ProductionDeploymentValidator;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.model.ArtifactNotDefinedInEnvException;
import com.ubs.f35.swift.environment.model.glu.Entry;

/**
 * Builds a RollbackPrep object which the client uses to choose artifacts for rollback.
 * 
 * @author levyjo
 * 
 */
public class RollbackPrepBuilder {

    private DeploymentDao deploymentDao;
    private EnvironmentDocumentStore environmentDocumentStore;
    private ProductionDeploymentValidator productionDeploymentValidator;

    /**
     * Generate the RollbackPrep object which contains the available rollback versions for each artifact that has been
     * deployed as part of the given release.
     * 
     * @param releaseDefinition
     * @param environment
     * @return
     */
    public RollbackPrep generateRollbackPrep(final ReleaseDefinition releaseDefinition, final String environmentName) {
        RollbackPrep rollbackPrep = new RollbackPrep(releaseDefinition, environmentName);

        // Using Linked collections so that the ordering of rollback artifact versions coming from the DB is retained.

        LinkedHashSet<Artifact> allRollbackArtifacts = getAllArtifactRollbackVersions(releaseDefinition,
                environmentName);

        SetMultimap<NexusArtifact, Artifact> multimap = LinkedHashMultimap.create();
        for (Artifact a : allRollbackArtifacts) {
            multimap.put(a.getNexusArtifact(), a);
        }

        Environment environment = new Environment(environmentName, releaseDefinition.getTeam().getOrganisation());

        for (Map.Entry<NexusArtifact, Collection<Artifact>> entry : multimap.asMap().entrySet()) {
            Artifact releaseVersion = getReleaseVersion(releaseDefinition, entry.getKey());
            String liveVersion = getLiveVersion(environment, entry.getKey());
            List<Artifact> artifacts = Lists.newArrayList(entry.getValue());
            artifacts.remove(releaseVersion);
            rollbackPrep.addArtifactToChoose(releaseVersion, liveVersion, artifacts);
        }

        // Add any warnings about the potential rollback.
        List<Warning> warnings = productionDeploymentValidator.validateProductionReleaseChecks(releaseDefinition,
                environment, true);
        rollbackPrep.setWarnings(warnings);

        return rollbackPrep;
    }

    /**
     * Validate that the given list of artifacts are valid rollback artifacts for the given release definition in the
     * given environment.
     * <p>
     * An artifact is considered valid for rollback of a particular release if this artifact version was ever recorded
     * as the current deployed version before a deployment of the release took place.
     * 
     * @param releaseDefinition
     * @param environment
     * @param artifacts
     */
    public void validate(final ReleaseDefinition releaseDefinition, final String environment,
            final List<Artifact> artifacts) {

        Set<Artifact> allRollbackArtifacts = getAllArtifactRollbackVersions(releaseDefinition, environment);
        if (!allRollbackArtifacts.containsAll(artifacts)) {
            throw new IllegalArgumentException("Release cannot be rolled back to the artifact versions specified");
        }

    }

    private String getLiveVersion(final Environment environment, final NexusArtifact nexusArtifact) {

        Collection<Entry> entries = environmentDocumentStore.filterEntriesByArtifact(environment, nexusArtifact);

        if (entries.isEmpty()) {
            throw new ArtifactNotDefinedInEnvException(nexusArtifact);
        }

        String liveVersion = entries.iterator().next().getVersion();
        // TODO: Get versions of each instance. Currently, we show the live version as being that of the first instance
        // that happens to be returned. Currently Swift only supports deploying the same version to all instances.
        // TODO: Do we want to show actual live version rather than that from environment definition?
        return liveVersion;
    }

    /**
     * Returns the given version-less artifact with the version of the artifact currently defined in the given release
     * definition. If the release definition does not contain this artifact, the version-less instance is returned.
     * 
     * @param releaseDefinition
     * @param versionlessArtifact
     * @return
     */
    private Artifact getReleaseVersion(final ReleaseDefinition releaseDefinition,
            final NexusArtifact versionlessArtifact) {
        for (Artifact releaseArtifact : releaseDefinition.getArtifacts()) {
            if (releaseArtifact.getNexusArtifact().equals(versionlessArtifact)) {
                return releaseArtifact;
            }
        }
        return new Artifact(versionlessArtifact.getGroupId(), versionlessArtifact.getArtifactId(), null);
    }

    private LinkedHashSet<Artifact> getAllArtifactRollbackVersions(final ReleaseDefinition releaseDefinition,
            final String environment) {

        LinkedHashSet<Artifact> artifacts = new LinkedHashSet<Artifact>();
        // Using LinkedhashSet so that so that the ordering of rollback artifact versions coming from the DB is
        // retained. This is so that in a case where multiple rollback versions are available for an artifact, they will
        // be shown in the order deployed.
        List<EnvDeployment> deployments = deploymentDao.getAllDeploymentsForReleaseInEnv(releaseDefinition.getId(),
                environment);
        for (EnvDeployment envDeploy : deployments) {
            DeploymentType deploymentType = envDeploy.getDeployment().getDeploymentType();
            if (deploymentType == DeploymentType.Release && envDeploy.getRollbackVersions() != null) {
                artifacts.addAll(envDeploy.getRollbackVersions());
            }
        }
        return artifacts;
    }

    @Required
    public void setDeploymentDao(final DeploymentDao deploymentDao) {
        this.deploymentDao = deploymentDao;
    }

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

    @Required
    public void setProductionDeploymentValidator(final ProductionDeploymentValidator productionDeploymentValidator) {
        this.productionDeploymentValidator = productionDeploymentValidator;
    }
}
