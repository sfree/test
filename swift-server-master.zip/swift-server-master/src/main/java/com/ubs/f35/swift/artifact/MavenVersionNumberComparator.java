package com.ubs.f35.swift.artifact;

import java.util.Comparator;

import org.apache.maven.artifact.versioning.DefaultArtifactVersion;

import com.ubs.f35.swift.service.ArtifactConfigurationService;

/**
 * Sorts a list of version numbers so that the most recent are returned first, and all snapshots are returned last.
 * 
 * @author stephelu
 * 
 */
public class MavenVersionNumberComparator implements Comparator<String> {
    public static final MavenVersionNumberComparator INSTANCE = new MavenVersionNumberComparator();

    @Override
    public int compare(final String o1, final String o2) {
        DefaultArtifactVersion version1 = new DefaultArtifactVersion(o1);
        DefaultArtifactVersion version2 = new DefaultArtifactVersion(o2);
        boolean snapshot1 = isSnapshot(version1);
        boolean snapshot2 = isSnapshot(version2);
        if (snapshot1 ^ snapshot2) {
            // only one of the artifacts is a snapshot. snapshots come last.
            return snapshot1 ? 1 : -1;
        }
        // neither or both are snapshot version. revert to standard sorting
        return -version1.compareTo(version2);
    }

    private static boolean isSnapshot(final DefaultArtifactVersion version) {
        return version.getQualifier() != null && ArtifactConfigurationService.isSnapshot(version.getQualifier());
    }

    public static boolean isLaterVersion(final String left, final String right) {
        DefaultArtifactVersion version1 = new DefaultArtifactVersion(left);
        DefaultArtifactVersion version2 = new DefaultArtifactVersion(right);

        return version1.compareTo(version2) > 0;
    }
}
