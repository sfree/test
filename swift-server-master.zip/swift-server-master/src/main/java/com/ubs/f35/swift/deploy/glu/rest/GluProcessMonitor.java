package com.ubs.f35.swift.deploy.glu.rest;

import java.util.List;

import org.linkedin.zookeeper.tracker.NodeEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

/**
 * Watches for updates to processes managed by glu.
 * 
 * @author stephelu
 * 
 */
public class GluProcessMonitor extends ZookeeperMonitor {
    private static final Logger LOG = LoggerFactory.getLogger(GluProcessMonitor.class);

    private static final String AGENT_PATH = "_";

    private List<ProcessStateChangeListener> processStateChangeListeners;

    @Override
    void onEvent(final NodeEvent<Object> nodeEvent) {
        String mountPoint = extractMountPointFromPath(nodeEvent.getPath());
        if (mountPoint != null) {
            for (ProcessStateChangeListener processStateChangeListener : processStateChangeListeners) {
                processStateChangeListener.processStateChanged(environment, mountPoint, null);
            }
        }
    }

    /**
     * Glu replaces any '/' characters in the mountpoint name with '_' as '/' is reserved for zookeeper path delimeters.
     * This reverses that logic.
     * 
     * @param path
     * @return
     */
    private String extractMountPointFromPath(final String path) {
        int lastIndex = path.lastIndexOf('/');
        if (lastIndex != -1) {
            String nodeName = path.substring(lastIndex + 1);

            if (nodeName.equals(AGENT_PATH)) {
                LOG.debug("Ignoring update to agent at path '{}'", path);
                return null;
            }

            return nodeName.replace('_', '/');
        } else {
            LOG.debug("Received notification of change to ZK path {} but unsure how to handle", path);
            return null;
        }
    }

    @Required
    public void setProcessStateChangeListeners(final List<ProcessStateChangeListener> processStateChangeListeners) {
        this.processStateChangeListeners = processStateChangeListeners;
    }

}
