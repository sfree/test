package com.ubs.f35.swift.config;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.codehaus.jackson.type.TypeReference;
import org.linkedin.util.clock.Timespan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import com.google.common.base.Predicate;
import com.google.common.collect.ComparisonChain;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.ubs.f35.swift.artifact.MavenVersionNumberComparator;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.model.GluScriptConfig;
import com.ubs.f35.swift.model.JsonObjectMapper;
import com.ubs.f35.swift.model.ScriptArgumentDetails;

/**
 * Finds Glu scripts along with their config files on the file system. Each artifact defined in Swift must be associated
 * with a script, which is used by the Glu agent to perform deployment actions on the artifact.
 * 
 * @author levyjo
 * 
 */
@ManagedResource(objectName = "com.ubs.f35.swift.config:GluScriptFinder=GluScriptFinder")
public class GluScriptFinder {

    private static final Logger LOG = LoggerFactory.getLogger(GluScriptFinder.class);

    private static final JsonObjectMapper mapper = new JsonObjectMapper();

    private File scriptsBaseDir;

    private OrganisationBeanFactory<List<String>> orgScriptPackageMappings;

    private volatile List<GluScriptConfig> scripts;

    private volatile ImmutableMap<String, GluScriptConfig> scriptsIndex;
    private volatile ImmutableMultimap<String, GluScriptConfig> orgScriptsIndex;

    @Required
    public void setScriptsBaseDir(final File scriptsBaseDir) {
        this.scriptsBaseDir = scriptsBaseDir;
    }

    public List<GluScriptConfig> getScripts(final String organisation) {
        if (scripts == null) {
            scanScripts();
        }
        return Lists.newArrayList(orgScriptsIndex.get(organisation));
    }

    /**
     * Scheduled job runs every 5 minutes
     */
    @ManagedOperation(description = "Scan for new Glu scripts to populate the dropdown on the Artifact configuration screen")
    public void scanScripts() {

        LOG.info("Scanning Glu script folder");

        List<GluScriptConfig> scripts = Lists.newArrayList();

        ImmutableMap.Builder<String, GluScriptConfig> scriptsIndex = ImmutableMap.builder();
        ImmutableMultimap.Builder<String, GluScriptConfig> orgScriptsIndexBuilder = ImmutableMultimap.builder();
        for (File scriptFile : findScripts()) {
            String scriptConfigFile = getScriptConfigJson(scriptFile);
            if (scriptConfigFile != null) {
                String pckage = getPackage(scriptFile);
                GluScriptConfig script = new GluScriptConfig(pckage, pckage + "/" + getRelativePath(scriptFile),
                        scriptConfigFile);
                scripts.add(script);

                scriptsIndex.put(script.getScript(), script);

                // Add this script to all the organisations which use it.
                for (Entry<String, List<String>> orgScriptPackages : orgScriptPackageMappings.getAll().entrySet()) {
                    if (orgScriptPackages.getValue().contains(script.getPackage())) {
                        orgScriptsIndexBuilder.put(orgScriptPackages.getKey(), script);
                    }
                }
            }
        }

        this.scripts = scripts;
        this.scriptsIndex = scriptsIndex.build();
        this.orgScriptsIndex = orgScriptsIndexBuilder.build();
    }

    public void validate(final ArtifactConfig config) {
        String script = config.getScript();

        GluScriptConfig scriptConf = getScript(script);

        if (scriptConf == null) {
            throw new IllegalArgumentException("Invalid script file '" + script + "'");
        }

        List<ScriptArgumentDetails> configsArgs = mapper.readValue(scriptConf.getConfig(),
                new TypeReference<List<ScriptArgumentDetails>>() {
                });

        Map<String, String> scriptArgs;
        if (StringUtils.hasText(config.getScriptArguments())) {
            scriptArgs = mapper.readValue(config.getScriptArguments(), Map.class);
        } else {
            scriptArgs = Collections.emptyMap();
        }

        Set<String> allowedParams = Sets.newHashSet();
        for (ScriptArgumentDetails configArg : configsArgs) {
            allowedParams.add(configArg.getParamName());
            String value = scriptArgs.get(configArg.getParamName());
            if (!configArg.isOptional() && !StringUtils.hasText(value)) {
                throw new IllegalArgumentException("Parameter '" + configArg.getParamName() + "' is required");
            }
            if (configArg.getParamName().equals("startTimeout") && StringUtils.hasText(value)) {
                String msg = "startTimeout should be a time period such as 90s or 5m30s";
                try {
                    long timeInMillis = Timespan.parseTimespan(value).getDurationInMilliseconds();
                    Assert.isTrue(timeInMillis > 1000, msg);
                } catch (IllegalArgumentException ex) {
                    throw new IllegalArgumentException(msg, ex);
                }
            }
        }

        SetView<String> paramsDiff = Sets.difference(scriptArgs.keySet(), allowedParams);
        if (!paramsDiff.isEmpty()) {
            throw new IllegalArgumentException("Parameter with name '" + paramsDiff.iterator().next()
                    + "' is not allowed.");
        }
    }

    private String getScriptConfigJson(final File scriptFile) {
        String configFileName = FilenameUtils.removeExtension(scriptFile.getAbsolutePath()) + ".config";
        try {
            String jsonConfig = FileUtils.readFileToString(new File(configFileName));
            try {
                JsonObjectMapper.getInstance().readValue(jsonConfig, List.class);
            } catch (RuntimeException ex) {
                LOG.error("Invalid glu script configuration file.  Not importing {}", configFileName, ex);
                return null;
            }
            return jsonConfig;
        } catch (IOException e) {
            LOG.info("No config file found for " + scriptFile.getAbsolutePath());
            return null;
        }
    }

    private Collection<File> findScripts() {
        try {

            final IOFileFilter fileFilter = FileFilterUtils.suffixFileFilter("groovy");

            final IOFileFilter dirFilter = new IOFileFilter() {

                @Override
                public boolean accept(final File file) {
                    return !file.getName().startsWith(".");
                }

                @Override
                public boolean accept(final File dir, final String name) {
                    return dir.isDirectory();
                }

            };

            List<File> filesAndSymlinks = new ArrayList<File>(
                    FileUtils.listFiles(scriptsBaseDir, fileFilter, dirFilter));
            List<File> files = Lists.newArrayList(Iterables.filter(filesAndSymlinks, new Predicate<File>() {

                @Override
                public boolean apply(final File input) {
                    return !isSymlink(input);
                }
            }));

            Collections.sort(files, SCRIPT_FILE_COMPARATOR);
            return files;

        } catch (IllegalArgumentException ex) {
            throw new RuntimeException("Cannot access Glu scripts directory: " + scriptsBaseDir, ex);
        }
    }

    private GluScriptConfig getScript(final String configFile) {
        if (scripts == null) {
            scanScripts();
        }
        return scriptsIndex.get(configFile);
    }

    private String getRelativePath(final File file) {
        String parent = file.getParent();
        String filename = file.getName();

        String lastDir = parent.substring(parent.lastIndexOf(File.separatorChar) + 1);

        // Strip off the ".groovy" extension. No one needs to see that.
        return lastDir + "/" + filename.replace(".groovy", "");

    }

    private String getPackage(final File file) {
        String pacakgeDir = file.getParentFile().getParent();

        return pacakgeDir.substring(pacakgeDir.lastIndexOf(File.separatorChar) + 1);
    }

    private static boolean isSymlink(final File file) {
        if (file == null) {
            throw new NullPointerException("File must not be null");
        }
        File parent;
        try {
            if (file.getParent() == null) {
                parent = file;
            } else {
                parent = file.getParentFile();
            }
            return !parent.getCanonicalFile().equals(parent.getAbsoluteFile());
        } catch (IOException ex) {
            return false;
        }
    }

    private static Comparator<File> SCRIPT_FILE_COMPARATOR = new Comparator<File>() {

        @Override
        public int compare(final File o1, final File o2) {

            return ComparisonChain.start()
                    .compare(o1.getParent(), o2.getParent(), MavenVersionNumberComparator.INSTANCE)
                    .compare(o1.getName(), o2.getName()).result();

        }
    };

    @Required
    public void setOrgScriptPackageMappings(final OrganisationBeanFactory<List<String>> orgScriptPackageMappings) {
        this.orgScriptPackageMappings = orgScriptPackageMappings;
    }

}
