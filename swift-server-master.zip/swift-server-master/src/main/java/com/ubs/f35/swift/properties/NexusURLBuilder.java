package com.ubs.f35.swift.properties;

import java.net.MalformedURLException;
import java.net.URL;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.StringUtils;

import com.ubs.f35.swift.artifact.NexusInstanceSpecific;
import com.ubs.f35.swift.dao.Artifact;

public class NexusURLBuilder implements NexusInstanceSpecific {

    private String nexusContentUrl = "http://cft-nexus.ldn.swissbank.com:8081/nexus/service/local/artifact/maven/content";
    private String repositoryId = "g-internal-releases-and-snapshots";
    private String resolverId;

    public URL buildDownloadURL(final Artifact artifact, final String extension, final String classifier)
            throws MalformedURLException {

        String groupId = artifact.getGroupId();
        String artifactId = artifact.getArtifactId();
        String version = artifact.getVersion();

        StringBuilder urlBuilder = new StringBuilder(nexusContentUrl + "?r=" + repositoryId + "&g=" + groupId + "&a="
                + artifactId + "&v=" + version);
        if (StringUtils.hasText(extension)) {
            urlBuilder.append("&e=").append(extension);
        }
        if (StringUtils.hasText(classifier)) {
            urlBuilder.append("&c=").append(classifier);
        }

        return new URL(urlBuilder.toString());
    }

    @Required
    public void setNexusContentUrl(final String nexusContentUrl) {
        this.nexusContentUrl = nexusContentUrl;
    }

    @Required
    public void setRepositoryId(final String repositoryId) {
        this.repositoryId = repositoryId;
    }

    @Required
    public void setResolverId(final String resolverId) {
        this.resolverId = resolverId;
    }

    @Override
    public String getResolverId() {
        return resolverId;
    }
}
