package com.ubs.f35.swift.processor;

import static com.ubs.f35.swift.processor.ProcessorUtil.daoFilter;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubs.f35.swift.dao.Activity;
import com.ubs.f35.swift.dao.ActivityDao;
import com.ubs.f35.swift.dao.PagingResult;
import com.ubs.f35.swift.model.ActivityFilters;
import com.ubs.f35.swift.model.ClientPagingFilter;

@Controller
@RequestMapping(value = "/api/activity")
@Transactional(readOnly = true)
public class ActivityProcessor {

    private ActivityDao activityDao;

    @Required
    public void setActivityDao(final ActivityDao activityDao) {
        this.activityDao = activityDao;
    }

    @RequestMapping(method = RequestMethod.GET)
    @ResponseBody
    public PagingResult<Activity> getActivities(final ActivityFilters activityFilters,
            final ClientPagingFilter filter) {
        PagingResult<Activity> result = activityDao.list(activityFilters, daoFilter(filter));

        return result;
    }

}
