package com.ubs.f35.swift.dao.hibernate;

import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Functions;
import com.ubs.f35.swift.config.model.ArtifactCommonConfig;
import com.ubs.f35.swift.dao.ArtifactCommonConfigDao;
import com.ubs.f35.swift.dao.NexusArtifact;

public class HibernateArtifactCommonConfigDao extends
        HibernateAuditableEntityDao<NexusArtifact, ArtifactCommonConfig> implements ArtifactCommonConfigDao {

    @Override
    @Transactional
    public ArtifactCommonConfig load(final NexusArtifact artifact) {
        return load(artifact.getGroupId(), artifact.getArtifactId());
    }

    private ArtifactCommonConfig load(final String groupId, final String artifactId) {
        ArtifactCommonConfig id = ArtifactCommonConfig.commonConfigId(groupId, artifactId);
        return super.load(ArtifactCommonConfig.class, id);
    }

    @Override
    @Transactional
    public ArtifactCommonConfig save(final ArtifactCommonConfig artifact) {
        artifact.setDependencies(mergeCollection(ArtifactCommonConfig.class, artifact.getDependencies(),
                Functions.<ArtifactCommonConfig>identity()));

        getSession().saveOrUpdate(artifact);
        getSession().flush();
        return artifact;
    }

    @Override
    Class<ArtifactCommonConfig> getValueClass() {
        return ArtifactCommonConfig.class;
    }

}
