package com.ubs.f35.swift.environment;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.config.AbstractFactoryBean;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.swift.dao.model.Environment;

public class ZookeeperLookupFactory extends AbstractFactoryBean<ZooKeeperClient> {
    private EnvironmentBeanFactory<ZooKeeperClient> zooKeeperClientFactory;
    private String environment;

    @Override
    public Class<?> getObjectType() {
        return ZooKeeperClient.class;
    }

    @Override
    protected ZooKeeperClient createInstance() throws Exception {
        String[] parts = environment.split("\\.");
        return zooKeeperClientFactory.get(new Environment(parts[1], parts[0]));
    }

    @Required
    public void setZooKeeperClientFactory(final EnvironmentBeanFactory<ZooKeeperClient> zooKeeperClientFactory) {
        this.zooKeeperClientFactory = zooKeeperClientFactory;
    }

    @Required
    public void setEnvironment(final String environment) {
        this.environment = environment;
    }

}
