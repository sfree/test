package com.ubs.f35.swift.deploy.glu.rest;

import com.google.common.base.Objects;
import com.ubs.f35.swift.deploy.glu.state.GluState;
import com.ubs.f35.swift.model.State.StateLevel;

/**
 * Currently only returns the state level as no other details were required. But could be extended to return further
 * details.
 * 
 * @author stephelu
 * 
 */
public class ProcessDetails {
    final GluState gluState;
    final StateLevel stateLevel;
    final boolean stateMachineInError;
    final String version;

    public ProcessDetails(final GluState gluState, final StateLevel stateLevel, final boolean stateMachineInError) {
        this(gluState, stateLevel, stateMachineInError, null);
    }

    public ProcessDetails(final GluState gluState, final StateLevel stateLevel, final boolean stateMachineInError,
            final String version) {
        this.gluState = gluState;
        this.stateLevel = stateLevel;
        this.stateMachineInError = stateMachineInError;
        this.version = version;
    }

    public GluState getGluState() {
        return gluState;
    }

    public StateLevel getStateLevel() {
        return stateLevel;
    }

    /**
     * The version of the process currently deployed
     * 
     * @return
     */
    public String getVersion() {
        return version;
    }

    /**
     * Flags if the state machine for this process has an error set.
     * 
     * @return
     */
    public boolean isStateMachineInError() {
        return stateMachineInError;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("gluState", gluState)
                .add("stateLevel", stateLevel)
                .add("stateMachineInError", stateMachineInError)
                .add("version", version)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(gluState, stateLevel);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ProcessDetails) {
            ProcessDetails that = (ProcessDetails) object;
            return Objects.equal(this.gluState, that.gluState)
                    && Objects.equal(this.stateLevel, that.stateLevel)
                    && Objects.equal(this.stateMachineInError, that.stateMachineInError)
                    && Objects.equal(this.version, that.version);
        }
        return false;
    }
}