package com.ubs.f35.swift.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseDefinitionDao;
import com.ubs.f35.swift.dao.model.DeploymentProcess;
import com.ubs.f35.swift.deploy.template.DeploymentTemplateGenerator;
import com.ubs.f35.swift.deploy.template.model.DeploymentTemplate;

@Controller
@RequestMapping(value = "/api/releasetemplate")
@Transactional
public class ReleaseDeploymentTemplateProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(ReleaseDeploymentTemplateProcessor.class);

    private ReleaseDefinitionDao releaseDefinitionDao;
    private DeploymentTemplateGenerator deploymentTemplateGenerator;

    @RequestMapping(value = "/{releaseId}", method = RequestMethod.GET)
    @ResponseBody
    public DeploymentTemplate generateDeploymentTemplate(@PathVariable final Integer releaseId) {
        ReleaseDefinition release = releaseDefinitionDao.load(releaseId);

        String org = release.getTeam().getOrganisation().getName();
        return deploymentTemplateGenerator.generateDeploymentTemplate(org, release.getArtifacts(),
                DeploymentProcess.valueOf(release.getDeploymentProcess()));
    }

    @RequestMapping(value = "/{releaseId}/{deploymentProcess}", method = RequestMethod.GET)
    @ResponseBody
    public DeploymentTemplate generateDeploymentTemplate(@PathVariable final Integer releaseId,
            @PathVariable final DeploymentProcess deploymentProcess) {
        ReleaseDefinition release = releaseDefinitionDao.load(releaseId);

        String org = release.getTeam().getOrganisation().getName();
        return deploymentTemplateGenerator.generateDeploymentTemplate(org, release.getArtifacts(), deploymentProcess);
    }

    @Required
    public void setDeploymentTemplateGenerator(final DeploymentTemplateGenerator deploymentTemplateGenerator) {
        this.deploymentTemplateGenerator = deploymentTemplateGenerator;
    }

    @Required
    public void setReleaseDefinitionDao(final ReleaseDefinitionDao releaseDefinitionDao) {
        this.releaseDefinitionDao = releaseDefinitionDao;
    }
}
