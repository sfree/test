package com.ubs.f35.swift.dao.model;

import static com.ubs.f35.swift.config.model.Objects2.toStringSafe;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.NaturalId;

import com.google.common.base.Objects;

@SequenceGenerator(name = "oracle_seq", sequenceName = "seq_teams_id")
@Entity
@Table(name = "teams")
public class Team {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "oracle_seq")
    private Integer id;
    @NaturalId(mutable = true)
    private String name;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn
    @NaturalId(mutable = false)
    private Organisation organisation;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public Organisation getOrganisation() {
        return organisation;
    }

    public void setOrganisation(final Organisation organisation) {
        this.organisation = organisation;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, name, organisation);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof Team) {
            Team that = (Team) object;
            return Objects.equal(this.id, that.id)
                    && Objects.equal(this.name, that.name)
                    && Objects.equal(this.organisation, that.organisation);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("name", name)
                .add("organisation", toStringSafe(organisation))
                .toString();
    }
}
