package com.ubs.f35.swift.document;

import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.environment.model.glu.Entry;

public interface ArtifactEntryConvertorPostProcessor {
    /**
     * Once an {@link ArtifactConfig} is converted to {@link Entry}, provides an additional hook to enrich the
     * {@link Entry}
     * 
     * @param artifact
     * @param entry
     */
    void enrich(ArtifactConfig artifact, Entry entry);
}
