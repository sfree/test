package com.ubs.f35.swift.deploy.glu.plan;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.Validate;
import org.codehaus.jackson.annotate.JsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Objects;
import com.ubs.f35.swift.deploy.glu.action.Action;

/**
 * Represents a deployment plan. Top level actions are considered to be executable in parallel.
 * 
 * @author stephelu
 * 
 */
public class DeploymentPlan implements Serializable {
    private static final Logger LOG = LoggerFactory.getLogger(DeploymentPlan.class);

    private final UUID id;
    // Ideally Deployment plan would only have a single action. If this action needed to perform multiple steps, it
    // could be wrapped in a ParallelAction or RelatedActions
    private final List<Action> actions;
    private List<Warning> warnings;

    public DeploymentPlan(@JsonProperty(value = "id") final UUID id,
            @JsonProperty(value = "actions") final List<Action> actions) {
        Validate.notNull(id, "deployment plan must have an id");
        Validate.notNull(actions, "deployment plan must have actions");

        if (actions.size() != 1) {
            // not expected, but historical plans may have more than one action
            LOG.warn("Deployment plan {} has more than one action.", id);
        }

        this.id = id;
        this.actions = actions;
    }

    public List<Action> getActions() {
        return actions;
    }

    public UUID getId() {
        return id;
    }

    public List<Warning> getWarnings() {
        return warnings;
    }

    public void setWarnings(final List<Warning> warnings) {
        this.warnings = warnings;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, actions, warnings);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DeploymentPlan) {
            DeploymentPlan that = (DeploymentPlan) object;
            return Objects.equal(this.id, that.id)
                    && Objects.equal(this.actions, that.actions)
                    && Objects.equal(this.warnings, that.warnings);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("actions", actions)
                .add("warnings", warnings)
                .toString();
    }

}
