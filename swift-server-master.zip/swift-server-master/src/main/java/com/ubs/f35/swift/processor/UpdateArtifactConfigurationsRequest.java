package com.ubs.f35.swift.processor;

import java.util.List;

import com.google.common.base.Objects;
import com.ubs.f35.swift.config.model.ArtifactConfig;

/**
 * Request from the client to save a list of {@link ArtifactConfig} as a single operation. The client may also specify
 * artifacts which are not deployed to an environment.
 */
public class UpdateArtifactConfigurationsRequest {
    public List<ArtifactConfig> configured;
    public List<NotDeployedArtifact> notDeployed;

    public List<ArtifactConfig> getConfigured() {
        return configured;
    }

    public void setConfigured(final List<ArtifactConfig> configured) {
        this.configured = configured;
    }

    public List<NotDeployedArtifact> getNotDeployed() {
        return notDeployed;
    }

    public void setNotDeployed(final List<NotDeployedArtifact> notDeployed) {
        this.notDeployed = notDeployed;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("configured", configured)
                .add("notDeployed", notDeployed)
                .toString();
    }

    static class NotDeployedArtifact {
        private String groupId;
        private String artifactId;
        private Integer environmentId;

        public String getGroupId() {
            return groupId;
        }

        public void setGroupId(final String groupId) {
            this.groupId = groupId;
        }

        public String getArtifactId() {
            return artifactId;
        }

        public void setArtifactId(final String artifactId) {
            this.artifactId = artifactId;
        }

        public Integer getEnvironmentId() {
            return environmentId;
        }

        public void setEnvironmentId(final Integer environmentId) {
            this.environmentId = environmentId;
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this)
                    .add("groupId", groupId)
                    .add("artifactId", artifactId)
                    .add("environmentId", environmentId)
                    .toString();
        }
    }
}
