package com.ubs.f35.swift.dao.hibernate.framework;

import org.hibernate.Query;

public interface PagingQueryBuilder {

    String getQuery();

    String getCountQuery();

    void bindArguments(Query resultsQuery);

}
