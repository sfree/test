package com.ubs.f35.swift.dao;

import java.util.List;

import com.ubs.f35.swift.dao.hibernate.AuditEntry;
import com.ubs.f35.swift.dao.model.Environment;

public interface DefaultPropertiesDao {

    List<PropertiesDefault> loadDefaultProperties(Environment environment);

    PropertiesDefault loadDefaultProperty(Environment environment, String propertyKey);

    void removeDefaultProperty(Environment environment, String propertyKey);

    void saveOrUpdateDefaultProperty(PropertiesDefault property);

    void setDefaultProperties(List<PropertiesDefault> properties, Environment environment);

    List<AuditEntry<PropertiesDefault>> getAuditHistory(Environment environment, PagingFilter daoFilter);

}
