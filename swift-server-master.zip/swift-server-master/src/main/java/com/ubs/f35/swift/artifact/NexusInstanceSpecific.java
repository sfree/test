package com.ubs.f35.swift.artifact;

public interface NexusInstanceSpecific {
    String getResolverId();
}
