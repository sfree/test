package com.ubs.f35.swift.dao;

import java.util.List;

import com.google.common.base.Objects;

public class PagingResult<T> {
    private final PagingFilter requestFilter;
    private final long totalRecords;
    private final List<T> pageResults;

    public PagingResult(final PagingFilter requestFilter, final long totalRecords,
            final List<T> pageResults) {
        this.requestFilter = requestFilter;
        this.totalRecords = totalRecords;
        this.pageResults = pageResults;
    }

    public PagingFilter getRequestFilter() {
        return requestFilter;
    }

    public long getTotalRecords() {
        return totalRecords;
    }

    public List<T> getPageResults() {
        return pageResults;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("requestFilter", requestFilter)
                .add("totalRecords", totalRecords)
                .add("pageResults", pageResults)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(requestFilter, totalRecords, pageResults);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof PagingResult) {
            PagingResult that = (PagingResult) object;
            return Objects.equal(this.requestFilter, that.requestFilter)
                    && Objects.equal(this.totalRecords, that.totalRecords)
                    && Objects.equal(this.pageResults, that.pageResults);
        }
        return false;
    }

}
