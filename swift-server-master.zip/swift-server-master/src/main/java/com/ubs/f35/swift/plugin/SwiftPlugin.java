package com.ubs.f35.swift.plugin;

import org.springframework.beans.factory.BeanFactory;

/**
 * Plugins may implement this interface to access the Swift Spring application context
 * 
 * @author stephelu
 * 
 */
public interface SwiftPlugin {
    void initialise(BeanFactory appContext);
}
