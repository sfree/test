package com.ubs.f35.swift.dao;

import com.google.common.base.Objects;

/**
 * Specifies the range of data a query request is for.
 * <p>
 * For the first record in the list, specify a start index of 0.
 * 
 * @author stephelu
 * 
 */
public class PagingFilter {
    private final int start;
    private final int records;

    public PagingFilter(final int start, final int records) {
        this.start = start;
        this.records = records;
    }

    public int getStart() {
        return start;
    }

    public int getRecords() {
        return records;
    }

    /**
     * Returns the paging filter to return the next page of results.
     * 
     * @return
     */
    public PagingFilter nextPage() {
        return new PagingFilter(this.start + records, records);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(start, records);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof PagingFilter) {
            PagingFilter that = (PagingFilter) object;
            return Objects.equal(this.start, that.start)
                    && Objects.equal(this.records, that.records);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("start", start)
                .add("records", records)
                .toString();
    }

}
