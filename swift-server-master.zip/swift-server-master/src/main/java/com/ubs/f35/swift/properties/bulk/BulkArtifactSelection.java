package com.ubs.f35.swift.properties.bulk;

import java.util.List;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonTypeName;

import com.ubs.f35.swift.dao.Artifact;

@JsonTypeName("artifact-selection")
public class BulkArtifactSelection implements BulkUpdateSelection {
    final String organisation;
    final String environment;
    final List<Artifact> artifacts;

    @JsonCreator
    public BulkArtifactSelection(@JsonProperty("organisation") final String organisation,
            @JsonProperty("environment") final String environment,
            @JsonProperty("artifacts") final List<Artifact> artifacts) {
        this.organisation = organisation;
        this.environment = environment;
        this.artifacts = artifacts;
    }

    public String getOrganisation() {
        return organisation;
    }

    public String getEnvironment() {
        return environment;
    }

    public List<Artifact> getArtifacts() {
        return artifacts;
    }
}