package com.ubs.f35.swift.io.processor;

import com.google.common.base.Objects;

/**
 * Tells the client that a subscription update has occurred and it no longer needs to display this record for the filter
 * params it has supplied.
 * 
 * @author stephelu
 * 
 */
public class HideRecordMessage {
    // TODO ideally the client wouldn't need this.
    private final String environment;
    private final String id;

    public HideRecordMessage(final String environment, final String id) {
        this.environment = environment;
        this.id = id;
    }

    public boolean getHide() {
        return true;
    }

    public String getEnvironment() {
        return environment;
    }

    public String getId() {
        return id;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(environment, id);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof HideRecordMessage) {
            HideRecordMessage that = (HideRecordMessage) object;
            return Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.id, that.id);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("environment", environment)
                .add("id", id)
                .toString();
    }

}
