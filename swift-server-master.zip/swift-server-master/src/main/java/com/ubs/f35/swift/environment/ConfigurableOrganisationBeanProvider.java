package com.ubs.f35.swift.environment;

import org.springframework.beans.factory.BeanNameAware;

public class ConfigurableOrganisationBeanProvider<T> extends ConfigurableBeanProvider<String, T> implements
        OrganisationBeanFactory<T>, BeanNameAware {

    @Override
    protected String getSourceType() {
        return "organisation";
    }

    @Override
    protected String getMBeanPrefix(final String organisation) {
        return organisation;
    }

}
