package com.ubs.f35.swift.properties.model;

import com.google.common.base.Objects;

/**
 * Extension of a basic property model used for configuring properties for a new version of an artifact. Represents a
 * property that has not yet been saved for a particular artifact version, but is suggested based on discovered keys
 * and/or properties from another version of an artifact.
 * 
 * @author levyjo
 * 
 */
public class SuggestedProperty extends Property {

    private final SuggestionType suggestion;

    /**
     * SuggestionType flag:
     * <ul>
     * <li>NEW: New property key discovered which did not exist previously.</li>
     * <li>PREVIOUS: Property exists in a previous version.</li>
     * <li>REMOVED: Property exists in a previous version but this key has not been found in the new version.</li>
     * </ul>
     */
    public static enum SuggestionType {
        NEW, PREVIOUS, REMOVED
    }

    public SuggestedProperty(final String key, final String value, final String defaultValue,
            final SuggestionType suggestion) {
        this(key, value, defaultValue, DefaultType.ENVIRONMENT, suggestion);
    }

    public SuggestedProperty(final String key, final String value, final String defaultValue,
            final DefaultType defaultType, final SuggestionType suggestion) {
        super(key, value, defaultValue, defaultType);
        this.suggestion = suggestion;
    }

    public SuggestionType getSuggestion() {
        return suggestion;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(super.hashCode(), suggestion);
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (!super.equals(obj)) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SuggestedProperty that = (SuggestedProperty) obj;
        return Objects.equal(this.suggestion, that.suggestion);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("super", super.toString())
                .add("suggestion", suggestion)
                .toString();
    }

    @Override
    public int compareTo(final Property o) {
        if (o instanceof SuggestedProperty) {
            SuggestedProperty that = (SuggestedProperty) o;
            int comparison;
            if (this.suggestion == null && that.suggestion == null) {
            } else if (this.suggestion == null) {
                return -1;
            } else if (that.suggestion == null) {
                return 1;
            } else {
                comparison = this.suggestion.compareTo(that.suggestion);
                if (comparison != 0) {
                    return comparison;
                }
            }
        }
        return super.compareTo(o);
    }

}
