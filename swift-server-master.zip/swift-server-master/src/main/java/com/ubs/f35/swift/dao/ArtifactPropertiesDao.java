package com.ubs.f35.swift.dao;

import java.util.List;

import com.ubs.f35.swift.dao.hibernate.AuditEntry;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.model.ArtifactPropertyKeyHistory;
import com.ubs.f35.swift.properties.bulk.PropertyUpdate;
import com.ubs.f35.swift.properties.model.ArtifactProperties;
import com.ubs.f35.swift.properties.model.Property;
import com.ubs.f35.swift.properties.model.PropertyList;

public interface ArtifactPropertiesDao {

    PropertyList getProperties(Artifact artifact, Environment environment);

    Property getProperty(Artifact artifact, Environment environment, String key);

    void saveProperties(ArtifactProperties artifactProperties, Environment environment);

    String getSeedVersion(Artifact artifact, Environment environment);

    void saveProperty(Artifact artifact, Environment environment, Property property);

    void deleteProperty(Artifact artifact, Environment environment, Property property);

    List<AuditEntry<Property>> getAuditHistory(Environment environment, Artifact artifact, PagingFilter daoFilter);

    List<ArtifactPropertyKeyHistory> getAuditHistory(Environment environment, NexusArtifact artifact, String key,
            PagingFilter daoFilter);

    List<ArtifactPropertiesCount> loadSavedPropertiesCount(List<Artifact> artifacts, List<Environment> environments);

    List<ArtifactProperty> getConfiguredArtifactsUsingProperty(Environment env, String key, String value);

    void saveUpdates(Artifact artifact, Environment environment, List<PropertyUpdate> propertyUpdates);
}
