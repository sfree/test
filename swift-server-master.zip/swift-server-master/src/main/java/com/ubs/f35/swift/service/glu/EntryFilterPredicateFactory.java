package com.ubs.f35.swift.service.glu;

import org.springframework.util.CollectionUtils;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.model.EntryFilter;

/**
 * Builds a list of {@link Predicate} which will answer if a given {@link Entry} matches the supplied
 * {@link EntryFilter}.
 * 
 * Note that the Predicate is expected to be reused so is optimised to not return unnecessary predicates for evaluation.
 * 
 * @author stephelu
 * 
 */
public class EntryFilterPredicateFactory {
    public Predicate<Entry> buildFilterForCriteria(final EntryFilter filter) {
        Builder<Predicate<Entry>> builder = ImmutableList.builder();

        // Ordering the list of predicates based on those which should execute fastest / reduce the subset of results
        // quickest.
        if (!CollectionUtils.isEmpty(filter.getAgents())) {
            builder.add(new EntryMatchesAgentsPredicate(filter.getAgents()));
        }
        if (!CollectionUtils.isEmpty(filter.getTags())) {
            builder.add(new EntryMatchesTagsPredicate(filter.getTags()));
        }
        if (!CollectionUtils.isEmpty(filter.getGroups())) {
            builder.add(new EntryMatchesGroupsPredicate(filter.getGroups()));
        }
        if (!CollectionUtils.isEmpty(filter.getArtifacts())) {
            builder.add(new EntryMatchesArtifactsPredicate(filter.getArtifacts()));
        }

        return Predicates.and(builder.build());
    }
}
