package com.ubs.f35.swift.deploy.glu.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.model.Environment;

/**
 * Exists because the {@link GluAgentDiscoverer} requires a scheduled task to run it. And scheduled tasks cannot be
 * embedded into the env specific env-config.xml.
 * 
 */
@ManagedResource
public class GluAgentDiscovererWrapper {
    private static final Logger LOG = LoggerFactory.getLogger(GluAgentDiscovererWrapper.class);

    private EnvironmentDao environmentDao;
    private GluAgentDiscoverer gluAgentDiscoverer;

    @ManagedOperation(description = "Forces discovery of new zookeeper agents")
    public synchronized void discover() {
        for (Environment environment : environmentDao.loadEnvironments()) {
            try {
                gluAgentDiscoverer.discover(environment);
            } catch (Exception ex) {
                LOG.warn("Exception discovering agents for environment {}", environment, ex);
            }
        }
    }

    @Required
    public void setGluAgentDiscoverer(final GluAgentDiscoverer gluAgentDiscoverer) {
        this.gluAgentDiscoverer = gluAgentDiscoverer;
    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }

}
