package com.ubs.f35.swift.processor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.common.base.Function;
import com.ubs.f35.swift.dao.model.Team;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.service.TeamsService;

@Controller
@RequestMapping(value = "/api/teams")
@Transactional
public class TeamsProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(TeamsProcessor.class);

    public static final Function<Team, String> TEAM_NAME_FUNCTION = new Function<Team, String>() {
        @Override
        public String apply(final Team input) {
            return input.getName();
        }
    };

    private AuthorisationController authorisationController;
    private TeamsService teamsService;

    @RequestMapping(method = RequestMethod.GET)
    public List<Team> getTeams(@RequestParam(required = false) final String organisation,
            @RequestParam(defaultValue = "") final String filter) {
        return ProcessorUtil.filterList(filter, teamsService.getAllTeams(organisation), TEAM_NAME_FUNCTION);
    }

    // TODO the following belong in a UserProcessor. Split it out when saving settings other than teams against a user.
    @RequestMapping(value = "/user", method = RequestMethod.GET)
    public List<Team> getCurrentUserTeams(@RequestParam(required = false) final String organisation) {
        return teamsService.getCurrentUserTeams(organisation);
    }

    @RequestMapping(value = "/user", method = RequestMethod.PUT)
    public void saveUserTeams(@RequestBody final Integer[] teams) {
        teamsService.saveCurrentUserTeams(teams);
    }

    @RequestMapping(value = "/user/{user}", method = RequestMethod.GET)
    public List<Team> getUserTeams(@PathVariable final String user) {
        return teamsService.getUserTeams(user);
    }

    @RequestMapping(value = "/organisation/{organisation}", method = RequestMethod.GET)
    public List<String> getOrganisationTeams(@PathVariable final String organisation) {
        return ProcessorUtil.transform(teamsService.getAllTeams(organisation), TEAM_NAME_FUNCTION);
    }

    @RequestMapping(value = "/organisation/{organisation}/{team}", method = RequestMethod.POST)
    public void registerOrganisationTeam(@PathVariable final String organisation, @PathVariable final String team) {
        authorisationController.checkAccess(AdminProcessor.ADMINISTRATION_ACCESS_RIGHT);
        teamsService.registerTeam(organisation, team);
    }

    @Required
    public void setTeamsService(final TeamsService teamsService) {
        this.teamsService = teamsService;
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }
}
