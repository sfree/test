package com.ubs.f35.swift.processor;

import java.util.List;
import java.util.regex.Pattern;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.PagingResult;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.hibernate.AuditEntry;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.model.ClientPagingFilter;
import com.ubs.f35.swift.model.EnvironmentId;

public class ProcessorUtil {

    static PagingFilter daoFilter(final ClientPagingFilter filter) {
        Integer start = defaultValue(filter.getStart(), 0);
        Integer records = defaultValue(filter.getRecords(), 20);
        return new PagingFilter(start, records);
    }

    static <T> T defaultValue(final T value, final T defaultValue) {
        return value != null ? value : defaultValue;
    }

    static List<String> filterList(final String filter, final List<String> list) {
        Predicate<CharSequence> containsPredicate = Predicates.contains(Pattern.compile(Pattern.quote(filter),
                Pattern.CASE_INSENSITIVE));
        return Lists.newArrayList(Iterables.filter(list, containsPredicate));
    }

    static <T> List<T> filterList(final String filter, final List<T> list, final Function<T, String> valueFunction) {
        final Pattern pattern = Pattern.compile(Pattern.quote(filter), Pattern.CASE_INSENSITIVE);
        return Lists.newArrayList(Iterables.filter(list, new Predicate<T>() {
            @Override
            public boolean apply(final T input) {
                String stringValue = valueFunction.apply(input);
                return pattern.matcher(stringValue).find();
            }
        }));
    }

    /**
     * Performs an actual list translation from one list to another immediately (not a live view as provided by guava).
     * 
     * @param fromList
     * @param function
     * @return
     */
    public static <F, T> List<T> transform(
            final List<F> fromList, final Function<? super F, ? extends T> function) {
        if (fromList == null) {
            return null;
        }

        List<T> result = Lists.newArrayListWithCapacity(fromList.size());
        for (F from : fromList) {
            result.add(function.apply(from));
        }
        return result;
    }

    /**
     * Performs an actual list translation from one paging result to another immediately (not a live view as provided by
     * guava).
     * 
     * @param fromList
     * @param function
     * @return
     */
    public static <F, T> PagingResult<T> transform(
            final PagingResult<F> pagingResult, final Function<? super F, ? extends T> function) {
        List<T> initialised = transform(pagingResult.getPageResults(), function);
        return new PagingResult<T>(pagingResult.getRequestFilter(), pagingResult.getTotalRecords(), initialised);
    }

    /**
     * Translates a list of AuditEntry. Allows each hibernate {@link AuditEntry} to be initialised for serialisation.
     * 
     * @param fromList
     * @param function
     * @return
     */
    public static <T> List<AuditEntry<T>> transformAuditEntries(final List<AuditEntry<T>> auditHistory,
            final Function<T, T> auditMapper) {
        return transform(auditHistory,
                new Function<AuditEntry<T>, AuditEntry<T>>() {
                    @Override
                    public AuditEntry<T> apply(final AuditEntry<T> input) {
                        return new AuditEntry<T>(auditMapper.apply(input.getEntity()),
                                input.getRevision(), input.getRevisionType());
                    }
                });
    }

    /**
     * Restricts a potentially long list to the limitations specified by the {@link PagingFilter}.
     * 
     * @param pagingFilter
     * @param list
     * @return
     */
    static <T> PagingResult<T> getPagedList(final PagingFilter pagingFilter, final List<T> list) {

        int totalResults = list.size();

        List<T> page;
        if (pagingFilter.getRecords() != -1) {
            int fromIndex = Math.min(pagingFilter.getStart(), totalResults);
            int toIndex = Math.min(pagingFilter.getStart() + pagingFilter.getRecords(), totalResults);
            page = list.subList(fromIndex, toIndex);
        } else {
            page = list;
        }
        return new PagingResult<T>(pagingFilter, totalResults, page);
    }

    static Environment resolveEnvironment(final EnvironmentDao environmentDao, final String environment,
            final ReleaseDefinition release) {
        return environmentDao.loadEnvironment(environment, release.getTeam().getOrganisation().getName());
    }

    static List<Environment> resolveEnvironments(final EnvironmentDao environmentDao, final List<String> environments,
            final ReleaseDefinition release) {
        List<Environment> envIds = transform(environments, new Function<String, Environment>() {
            @Override
            public Environment apply(final String input) {
                return new Environment(input, release.getTeam().getOrganisation());
            }
        });
        return environmentDao.loadEnvironments(envIds);
    }

    static Environment resolveEnvironment(final EnvironmentDao environmentDao, final EnvironmentId environment) {
        return environmentDao.loadEnvironment(environment.getEnvironmentName(), environment.getOrganisationName());
    }

}
