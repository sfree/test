package com.ubs.f35.swift.dao;

import java.util.List;

import com.ubs.f35.swift.dao.model.Environment;

public interface EnvironmentDao {
    Environment loadEnvironment(String environment, String organisation);

    Environment loadEnvironment(Environment environment);

    Environment loadEnvironment(Integer id);

    /**
     * Takes a list of potentially non persistent environments and returns a corresponding persistent list.
     * 
     * @param environments
     * @return
     */
    List<Environment> loadEnvironments(List<Environment> environments);

    List<Environment> loadEnvironments();

    void save(Environment environment);
}
