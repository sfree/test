package com.ubs.f35.swift.deploy.glu.action;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

import com.google.common.base.Objects;

/**
 * Groups a set of actions which can be included or excluded from a deployment plan. These actions are all intended to
 * be executed sequentially. A failure to execute one action will prevent further actions from executing.
 */
public class SequentialAction extends BaseGroupedAction {

    /**
     * If this grouped action relates specifically to one process, include the artifactInstanceId so the client can make
     * requests for logs.
     */
    private String artifactInstanceId;
    /**
     * If this grouped action relates specifically to one process, include the artifactId so the client can link to the
     * status screen.
     */
    private String artifactId;

    public SequentialAction(@JsonProperty(value = "id") final String id,
            @JsonProperty(value = "name") final String name,
            @JsonProperty(value = "included") final List<Action> includedActions) {
        super(id, name, includedActions);
    }

    public String getArtifactInstanceId() {
        return artifactInstanceId;
    }

    public void setArtifactInstanceId(final String artifactInstanceId) {
        this.artifactInstanceId = artifactInstanceId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(final String artifactId) {
        this.artifactId = artifactId;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("super", super.toString())
                .add("artifactInstanceId", artifactInstanceId)
                .add("artifactId", artifactId)
                .toString();
    }

    @Override
    public boolean equals(final Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (getClass() != object.getClass()) {
            return false;
        }

        SequentialAction that = (SequentialAction) object;
        return super.equals(that)
                && Objects.equal(this.artifactInstanceId, that.artifactInstanceId)
                && Objects.equal(this.artifactId, that.artifactId);
    }
}
