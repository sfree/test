package com.ubs.f35.swift.activity.data;

import java.util.HashSet;
import java.util.Set;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.ubs.f35.swift.dao.Activity;
import com.ubs.f35.swift.dao.Activity.ActivityType;
import com.ubs.f35.swift.dao.Artifact;

/**
 * Data object format for an {@link Activity} of type {@link ActivityType#PROPERTIES}
 * 
 * @author levyjo
 * 
 */
public class PropertiesActivityData implements ActivityData {

    private Artifact artifact;

    private Set<String> propertiesAdded = new HashSet<String>();
    private Set<String> propertiesModified = new HashSet<String>();
    private Set<String> propertiesRemoved = new HashSet<String>();

    public PropertiesActivityData() {

    }

    public PropertiesActivityData(final Artifact artifact) {
        this.artifact = artifact;
    }

    public PropertiesActivityData(final Artifact artifact, final Set<String> newProperties) {
        this.artifact = artifact;
        propertiesAdded = newProperties;
    }

    public PropertiesActivityData(final Artifact artifact, final Set<String> newProperties,
            final Set<String> modifiedProperties, final Set<String> removedProperties) {
        this.artifact = artifact;
        propertiesAdded = newProperties;
        propertiesModified = modifiedProperties;
        propertiesRemoved = removedProperties;
    }

    public Artifact getArtifact() {
        return artifact;
    }

    public void setArtifact(final Artifact artifact) {
        this.artifact = artifact;
    }

    public Set<String> getPropertiesAdded() {
        return propertiesAdded;
    }

    public void setPropertiesAdded(final Set<String> propertiesAdded) {
        this.propertiesAdded = propertiesAdded;
    }

    public Set<String> getPropertiesModified() {
        return propertiesModified;
    }

    public void setPropertiesModified(final Set<String> propertiesModified) {
        this.propertiesModified = propertiesModified;
    }

    public Set<String> getPropertiesRemoved() {
        return propertiesRemoved;
    }

    public void setPropertiesRemoved(final Set<String> propertiesRemoved) {
        this.propertiesRemoved = propertiesRemoved;
    }

    @Override
    public PropertiesActivityData merge(final ActivityData newDataI) {

        PropertiesActivityData newData = (PropertiesActivityData) newDataI;

        for (String s : newData.getPropertiesRemoved()) {
            if (!propertiesAdded.remove(s)) {
                propertiesRemoved.add(s);
            }
            propertiesModified.remove(s);
        }

        for (String s : newData.getPropertiesModified()) {
            if (!propertiesAdded.contains(s)) {
                propertiesModified.add(s);
            }
        }

        for (String s : newData.getPropertiesAdded()) {
            if (propertiesRemoved.remove(s)) {
                propertiesModified.add(s);
            } else {
                propertiesAdded.add(s);
            }
        }

        return this;

    }

    @JsonIgnore
    @Override
    public boolean isEmpty() {
        return propertiesAdded.isEmpty() && propertiesModified.isEmpty() && propertiesRemoved.isEmpty();
    }

    public static PropertiesActivityData modifyProperty(final Artifact artifact, final String property) {
        PropertiesActivityData data = new PropertiesActivityData();
        data.artifact = artifact;
        data.propertiesModified.add(property);
        return data;
    }

    public static PropertiesActivityData removeProperty(final Artifact artifact, final String property) {
        PropertiesActivityData data = new PropertiesActivityData();
        data.artifact = artifact;
        data.propertiesRemoved.add(property);
        return data;
    }

}
