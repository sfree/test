package com.ubs.f35.swift.processor;

import static com.ubs.f35.swift.processor.ProcessorUtil.daoFilter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Function;
import com.google.common.collect.Iterables;
import com.google.common.collect.LinkedListMultimap;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.google.common.collect.Multimaps;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.client.model.ArtifactType;
import com.ubs.f35.swift.client.model.ArtifactWithType;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ArtifactPropertiesDao;
import com.ubs.f35.swift.dao.ArtifactProperty;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.StateStore;
import com.ubs.f35.swift.dao.hibernate.AuditEntry;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.model.ArtifactNotDefinedInReleaseException;
import com.ubs.f35.swift.model.ArtifactPropertyKeyHistory;
import com.ubs.f35.swift.model.ClientPagingFilter;
import com.ubs.f35.swift.properties.DefaultPropertiesProvider;
import com.ubs.f35.swift.properties.PropertiesManager;
import com.ubs.f35.swift.properties.bulk.BulkArtifactInstanceSelection;
import com.ubs.f35.swift.properties.bulk.BulkArtifactSelection;
import com.ubs.f35.swift.properties.bulk.BulkPropertyUpdate;
import com.ubs.f35.swift.properties.bulk.BulkPropertyUpdateRequest;
import com.ubs.f35.swift.properties.bulk.BulkUpdateResult;
import com.ubs.f35.swift.properties.bulk.BulkUpdateResult.BulkUpdateStatus;
import com.ubs.f35.swift.properties.bulk.BulkUpdateSelection;
import com.ubs.f35.swift.properties.model.ArtifactProperties;
import com.ubs.f35.swift.properties.model.ArtifactPropertiesList;
import com.ubs.f35.swift.properties.model.Property;
import com.ubs.f35.swift.properties.model.PropertyKey;
import com.ubs.f35.swift.properties.model.PropertyList;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.security.Permission;
import com.ubs.f35.swift.service.ArtifactConfigurationService;
import com.ubs.f35.swift.service.ArtifactConfigurationService.EnvironmentArtifactPair;
import com.ubs.f35.swift.service.ArtifactTypeService;

/**
 * 
 * Processes requests for retrieving and storing artifact properties.
 * 
 * @author levyjo
 * 
 */
@Controller
@RequestMapping(value = "/api/properties")
@Transactional
public class PropertiesProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(PropertiesProcessor.class);

    private PropertiesManager propertiesManager;
    private DefaultPropertiesProvider defaultPropertiesProvider;
    private ReleaseQueryProcessor releaseQueryProcessor;
    private ArtifactConfigurationService artifactConfigurationService;
    private EnvironmentDao environmentDao;
    private ArtifactPropertiesDao artifactPropertiesDao;
    private StateStore stateStore;
    private AuthorisationController authorisationController;
    private ArtifactTypeService artifactTypeService;
    // maximum of ten bulk upload failures (by default) before giving up
    private int maxBulkUploadFailures = 10;

    @RequestMapping(value = "/{organisation}/{environment}/{group}/{artifact}/{version}", method = RequestMethod.GET)
    public ArtifactProperties getProperties(
            @PathVariable(value = "organisation") final String organisation,
            @PathVariable(value = "environment") final String environment,
            @PathVariable(value = "group") final String group,
            @PathVariable(value = "artifact") final String artifact,
            @PathVariable(value = "version") final String version,
            @RequestParam(value = "suggest", defaultValue = "false") final Boolean suggest,
            @RequestParam(value = "prevVersion", required = false) final String previousVersion) {

        Artifact artifactModel = new Artifact(group, artifact, version);
        Environment env = resolveEnvironment(organisation, environment);
        ArtifactProperties result;
        if (suggest) {
            result = propertiesManager.getArtifactPropertiesWithSuggestions(env, artifactModel, previousVersion);
        } else {
            result = propertiesManager.getArtifactPropertiesWithComparison(env, artifactModel);
        }
        return enrichWithArtifactType(result, env);
    }

    // TODO should organisation / environment be on ArtifactProperties object. I think so.
    @RequestMapping(value = "/{organisation}/{environment}", method = RequestMethod.PUT)
    public ArtifactProperties saveProperties(
            @PathVariable(value = "organisation") final String organisation,
            @PathVariable(value = "environment") final String environment,
            @RequestBody final ArtifactProperties properties) {

        Environment env = resolveEnvironment(organisation, environment);
        ArtifactProperties result = propertiesManager.saveArtifactProperties(env, properties);

        return enrichWithArtifactType(result, env);
    }

    @RequestMapping(value = "/{organisation}/{environment}/{group}/{artifact}/{version}/history", method = RequestMethod.GET)
    public List<AuditEntry<Property>> getPropertiesAudit(
            @PathVariable(value = "organisation") final String organisation,
            @PathVariable(value = "environment") final String environment,
            @PathVariable(value = "group") final String group,
            @PathVariable(value = "artifact") final String artifact,
            @PathVariable(value = "version") final String version,
            final ClientPagingFilter filter) {
        Artifact artifactModel = new Artifact(group, artifact, version);
        return propertiesManager.getAuditHistory(resolveEnvironment(organisation, environment), artifactModel,
                daoFilter(filter));
    }

    /**
     * Returns an audit history of all audited changes to a property key across all versions of an artifact.
     */
    @RequestMapping(value = "/history/key/{organisation}/{environment}/{group}/{artifact}/{key}", method = RequestMethod.GET)
    @ResponseBody
    public List<ArtifactPropertyKeyHistory> getPropertyKeyAudit(
            @PathVariable final String organisation,
            @PathVariable final String environment,
            @PathVariable final String group,
            @PathVariable final String artifact,
            @PathVariable final String key,
            final ClientPagingFilter filter) {
        NexusArtifact artifactModel = new NexusArtifact(group, artifact);
        return propertiesManager.getAuditHistory(resolveEnvironment(organisation, environment), artifactModel, key,
                daoFilter(filter));
    }

    @RequestMapping(value = "/release/{environment}/{releaseId}", method = RequestMethod.GET)
    public ArtifactPropertiesList getPropertiesForRelease(
            @PathVariable(value = "environment") final String environment,
            @PathVariable(value = "releaseId") final Integer releaseId,
            @RequestParam(value = "revision", required = false) final Integer revision,
            @RequestParam(value = "suggest", defaultValue = "true") final Boolean suggest) {

        ReleaseDefinition release = releaseQueryProcessor.getRelease(releaseId, revision);

        if (release == null) {
            throw new RuntimeException("Release definition " + releaseId
                    + ((revision != null) ? " revision " + revision : "") + " does not exist");
        }

        Environment env = env(environment, release);
        ArtifactPropertiesList results = new ArtifactPropertiesList();

        for (Artifact artifact : release.getArtifacts()) {
            if (artifactConfigurationService.hasZooKeeperProperties(artifact)) {
                ArtifactProperties properties;
                if (suggest) {
                    properties = propertiesManager
                            .getArtifactPropertiesWithSuggestions(env, artifact);
                } else {
                    properties = propertiesManager.getArtifactPropertiesWithComparison(env,
                            artifact);
                }
                results.add(enrichWithArtifactType(properties, env));
            }
        }

        return results;

    }

    @RequestMapping(value = "/release/{environment}/{releaseId}", method = RequestMethod.PUT)
    public ArtifactPropertiesList savePropertiesForRelease(
            @PathVariable(value = "environment") final String environment,
            @PathVariable(value = "releaseId") final Integer releaseId,
            @RequestParam(value = "revision", required = false) final Integer revision,
            @RequestBody final ArtifactPropertiesList properties) {

        ReleaseDefinition release = releaseQueryProcessor.getRelease(releaseId, revision);

        if (release == null) {
            throw new RuntimeException("Release definition " + releaseId
                    + ((revision != null) ? " revision " + revision : "") + " does not exist");
        }

        Environment env = env(environment, release);
        ArtifactPropertiesList results = new ArtifactPropertiesList();
        checkAllArtifactsInReleaseDef(release, properties);
        for (ArtifactProperties a : properties) {
            ArtifactProperties returnedProperties =
                    propertiesManager.saveArtifactProperties(env, a);
            results.add(enrichWithArtifactType(returnedProperties, env));
        }

        return results;
    }

    @RequestMapping(value = "/defaults/{organisation}/{environment}", method = RequestMethod.GET)
    public PropertyList getDefaultProperties(
            @PathVariable final String organisation,
            @PathVariable(value = "environment") final String environment) {

        return defaultPropertiesProvider.getDefaultProperties(resolveEnvironment(organisation, environment));

    }

    @RequestMapping(value = "/defaults/{organisation}/{environment}", method = RequestMethod.PUT)
    public PropertyList saveDefaultProperties(
            @PathVariable final String organisation,
            @PathVariable(value = "environment") final String environment,
            @RequestBody final PropertyList properties) {

        defaultPropertiesProvider.saveDefaultProperties(resolveEnvironment(organisation, environment), properties);

        return getDefaultProperties(organisation, environment);

    }

    @RequestMapping(value = "/defaults/{organisation}/{environment}/{key}", method = RequestMethod.GET)
    public Property getDefaultProperty(
            @PathVariable final String organisation,
            @PathVariable(value = "environment") final String environment,
            @PathVariable(value = "key") final String propertyKey) {

        return defaultPropertiesProvider.getDefaultProperty(resolveEnvironment(organisation, environment), propertyKey);

    }

    @RequestMapping(value = "/defaults/{organisation}/{environment}/{key}", method = RequestMethod.PUT)
    public Property saveDefaultProperty(
            @PathVariable final String organisation,
            @PathVariable(value = "environment") final String environment,
            @PathVariable(value = "key") final String propertyKey,
            @RequestBody final String propertyValue) {

        Environment env = resolveEnvironment(organisation, environment);
        Property property = new Property(propertyKey, propertyValue);
        defaultPropertiesProvider.saveDefaultProperty(env, property);

        return getDefaultProperty(organisation, environment, propertyKey);

    }

    @RequestMapping(value = "/defaults/{organisation}/{environment}/{key}", method = RequestMethod.DELETE)
    public void deleteDefaultProperty(
            @PathVariable final String organisation,
            @PathVariable(value = "environment") final String environment,
            @PathVariable(value = "key") final String propertyKey) {

        defaultPropertiesProvider.deleteDefaultProperty(resolveEnvironment(organisation, environment), propertyKey);

    }

    @RequestMapping(value = "/defaults/{organisation}/{environment}/history", method = RequestMethod.GET)
    public List<AuditEntry<Property>> getDefaultsAudit(@PathVariable final String organisation,
            @PathVariable final String environment,
            final ClientPagingFilter filter) {
        return defaultPropertiesProvider.getAuditHistory(resolveEnvironment(organisation, environment),
                daoFilter(filter));
    }

    @RequestMapping(value = "/keys/{organisation}/{group}/{artifact}/{version}", method = RequestMethod.GET)
    public List<PropertyKey> getKeys(
            @PathVariable(value = "organisation") final String organisation,
            @PathVariable(value = "group") final String groupId,
            @PathVariable(value = "artifact") final String artifactId,
            @PathVariable(value = "version") final String version
            ) {
        Artifact artifact = new Artifact(groupId, artifactId, version);
        Set<PropertyKey> keys = propertiesManager.fetchPropertyKeys(organisation, artifact);
        ArrayList<PropertyKey> keysList = Lists.newArrayList(keys);
        Collections.sort(keysList);
        return keysList;
    }

    /**
     * Returns a list of currently configured artifacts using the specified property key or value or both.
     */
    @RequestMapping(value = "/search/{organisation}/{environment}", method = RequestMethod.GET)
    @ResponseBody
    public List<ArtifactProperty> searchForProperty(
            @PathVariable(value = "organisation") final String organisation,
            @PathVariable(value = "environment") final String environment,
            @RequestParam(required = false) final String propertyKey,
            @RequestParam(required = false) final String propertyValue) {

        if (!StringUtils.hasText(propertyKey) && !StringUtils.hasText(propertyValue)) {
            throw new IllegalArgumentException("No property key or value specified for searching.");
        }

        Environment env = resolveEnvironment(organisation, environment);

        List<ArtifactProperty> results = artifactPropertiesDao.getConfiguredArtifactsUsingProperty(env, propertyKey,
                propertyValue);

        List<NexusArtifact> artifacts = Lists.transform(results, new Function<ArtifactProperty, NexusArtifact>() {
            @Override
            public NexusArtifact apply(final ArtifactProperty input) {
                return input.getArtifact().getNexusArtifact();
            }
        });

        final Set<NexusArtifact> allowedToView = authorisationController.canAccess(env, artifacts,
                Permission.ViewProperties);

        List<ArtifactProperty> entitledResults = Lists.newArrayList();
        for (ArtifactProperty result : results) {
            // Strip off the environment information (which is the same for every item in the results)
            // entitlements - only show allowed results
            if (allowedToView.contains(result.getArtifact().getNexusArtifact())) {
                entitledResults
                        .add(new ArtifactProperty(enrich(result.getArtifact(), env), null, result.getKey(), result
                                .getValue()));
            } else if (!StringUtils.hasText(propertyValue)) {
                // If the user has specified a search string, don't include this in the results as they could abuse the
                // search to determine what the property value was.
                entitledResults.add(new ArtifactProperty(enrich(result.getArtifact(), env), null, result.getKey(),
                        "<User not entitled to view>"));
            }
        }
        return entitledResults;
    }

    private ArtifactWithType enrich(final Artifact artifact, final Environment environment) {
        ArtifactType artifactType = artifactTypeService.getArtifactType(artifact.getNexusArtifact(), environment);
        return new ArtifactWithType(artifact, artifactType);
    }

    /**
     * Hack for resourceful not elegantly handling POST to another resource. I never found an ideal way to pass a large
     * amount of state with resourceful. See https://connections.swissbank.com/message/37775#37775
     */
    @RequestMapping(value = "/register-bulk-update", method = RequestMethod.POST)
    @ResponseBody
    public UUID registerBuldUpdate(@RequestBody final BulkUpdateSelection selection) {
        return stateStore.create(selection);
    }

    /**
     * Returns the set of unique property keys which are used by the specified artifacts. Only the currently configured
     * versions are returned. If all artifacts share the same property value, the shared value will be returned as well.
     */
    @RequestMapping(value = "/initiate-bulk-update/{stateId}", method = RequestMethod.GET)
    @ResponseBody
    public BulkPropertyUpdate initiateBulkPropertyUpdate(@PathVariable final UUID stateId) {
        BulkUpdateSelection selection = stateStore.load(stateId, BulkUpdateSelection.class);
        Pair<Environment, List<Artifact>> envArtifacts = resolveBulkUpdateSelection(selection);

        // Filter to unique Artifacts and sort for nice ordering on the client
        final Set<Artifact> selectedArtifacts = Sets.newLinkedHashSet(envArtifacts.getRight());

        Environment environment = envArtifacts.getLeft();
        List<ArtifactProperties> allArtifactProps = propertiesManager
                .getAllArtifactProperties(environment, selectedArtifacts);

        ListMultimap<String, String> allPropertiesAndValues = LinkedListMultimap.create();

        for (ArtifactProperties artifactProps : allArtifactProps) {
            for (Property prop : artifactProps.getProperties()) {
                allPropertiesAndValues.put(prop.getKey(), prop.getValue());
            }
        }

        // Return the value only if it is the same across all artifacts. If any artifact has a different value or does
        // not specify a value, do not show the existing value as this could lead to the user incorrectly thinking the
        // value was current for all listed artifacts.
        Map<String, String> mergedValues = Maps.transformValues(allPropertiesAndValues.asMap(),
                new Function<Collection<String>, String>() {
                    @Override
                    public String apply(final Collection<String> allValuesForProperty) {
                        boolean allArtifactsHaveSamePropertyValue = selectedArtifacts.size() == allValuesForProperty
                                .size() && Sets.newHashSet(allValuesForProperty).size() == 1;
                        return allArtifactsHaveSamePropertyValue ? Iterables.get(allValuesForProperty, 0) : null;
                    }
                });

        List<Property> properties = Lists.newArrayList();
        for (Entry<String, String> mergedValue : mergedValues.entrySet()) {
            properties.add(new Property(mergedValue.getKey(), mergedValue.getValue()));
        }

        Collections.sort(properties);
        return new BulkPropertyUpdate(environment, properties, Lists.newArrayList(selectedArtifacts), selection);
    }

    /**
     * Executes a bulk property update.
     */
    @RequestMapping(value = "/bulk-update", method = RequestMethod.POST)
    @ResponseBody
    public List<BulkUpdateResult> executeBulkPropertyUpdate(@RequestBody final BulkPropertyUpdateRequest bulkUpdate) {

        Assert.notEmpty(bulkUpdate.getPropertyUpdates(), "No properties selected for updating.");

        Pair<Environment, List<Artifact>> envArtifacts = resolveBulkUpdateSelection(bulkUpdate.getSelection());

        Set<Artifact> artifactsToUpdate = Sets.newLinkedHashSet(envArtifacts.getRight());

        List<BulkUpdateResult> updateSummary = new ArrayList<>();
        int failures = 0;

        // If any artifact fails, record the failure but continue with the bulk updated. If many (maxBulkUploadFailures)
        // artifacts fail to upload, then give up and skip the rest.
        for (Artifact artifact : artifactsToUpdate) {

            BulkUpdateStatus status = BulkUpdateStatus.SKIPPED;
            String message = null;
            if (failures < maxBulkUploadFailures) {
                try {
                    propertiesManager.updateAllArtifactProperties(
                            envArtifacts.getLeft(), artifact, bulkUpdate.getPropertyUpdates());
                    status = BulkUpdateStatus.SUCCESS;
                } catch (RuntimeException ex) {
                    LOG.error("Exception updating properties for {}.  Skipping remaining updates", artifact, ex);
                    failures++;
                    status = BulkUpdateStatus.FAILURE;
                    message = ex.getMessage();
                }
            }

            updateSummary.add(new BulkUpdateResult(status, artifact, message));
        }

        return updateSummary;
    }

    /**
     * Entry point may either be selection of specific artifacts or artifact instances.
     * 
     * @param selection
     * @return
     */
    private Pair<Environment, List<Artifact>> resolveBulkUpdateSelection(final BulkUpdateSelection selection) {
        if (selection instanceof BulkArtifactSelection) {
            BulkArtifactSelection artifactSelection = (BulkArtifactSelection) selection;
            Environment env = resolveEnvironment(artifactSelection.getOrganisation(),
                    artifactSelection.getEnvironment());
            return Pair.of(env, artifactSelection.getArtifacts());
        } else {
            return resolveBulkUpdateArtifactInstanceIds(((BulkArtifactInstanceSelection) selection)
                    .getArtifactInstanceIds());
        }
    }

    private Pair<Environment, List<Artifact>> resolveBulkUpdateArtifactInstanceIds(
            final List<String> artifactInstanceIds) {
        List<EnvironmentArtifactPair> envArtifacts = artifactConfigurationService
                .resolveArtifactInstanceIdsToArtifacts(artifactInstanceIds);
        Multimap<Environment, EnvironmentArtifactPair> envIndex = Multimaps.index(envArtifacts,
                new Function<EnvironmentArtifactPair, Environment>() {
                    @Override
                    public Environment apply(final EnvironmentArtifactPair input) {
                        return input.getEnvironment();
                    }
                });

        List<Artifact> artifacts = ProcessorUtil.transform(envArtifacts,
                new Function<EnvironmentArtifactPair, Artifact>() {
                    @Override
                    public Artifact apply(final EnvironmentArtifactPair input) {
                        return input.getArtifact();
                    }
                });

        Assert.isTrue(envIndex.keySet().size() == 1, "Bulk update can only be used against a single environment");

        return Pair.of(Iterables.getOnlyElement(envIndex.keySet()), artifacts);
    }

    private void checkAllArtifactsInReleaseDef(final ReleaseDefinition def, final ArtifactPropertiesList list) {
        for (ArtifactProperties artifactProperties : list) {
            if (!def.getArtifacts().contains(artifactProperties.getArtifact().toSimpleArtifact())) {
                throw new ArtifactNotDefinedInReleaseException(artifactProperties.getArtifact(), def);
            }
        }
    }

    private Environment env(final String environment, final ReleaseDefinition def) {
        return ProcessorUtil.resolveEnvironment(environmentDao, environment, def);
    }

    private Environment resolveEnvironment(final String organisation, final String environment) {
        return environmentDao.loadEnvironment(environment, organisation);
    }

    private ArtifactProperties enrichWithArtifactType(final ArtifactProperties properties, final Environment environment) {
        ArtifactType artifactType = artifactTypeService.getArtifactType(properties.getArtifact().getNexusArtifact(),
                environment);
        properties.setArtifactType(artifactType);
        return properties;
    }

    @Required
    public void setDefaultPropertiesProvider(final DefaultPropertiesProvider defaultPropertiesProvider) {
        this.defaultPropertiesProvider = defaultPropertiesProvider;
    }

    @Required
    public void setReleaseQueryProcessor(final ReleaseQueryProcessor releaseQueryProcessor) {
        this.releaseQueryProcessor = releaseQueryProcessor;
    }

    @Required
    public void setPropertiesManager(final PropertiesManager propertiesManager) {
        this.propertiesManager = propertiesManager;
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }

    @Required
    public void setArtifactPropertiesDao(final ArtifactPropertiesDao artifactPropertiesDao) {
        this.artifactPropertiesDao = artifactPropertiesDao;
    }

    @Required
    public void setStateStore(final StateStore stateStore) {
        this.stateStore = stateStore;
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

    @Required
    public void setArtifactTypeService(final ArtifactTypeService artifactTypeService) {
        this.artifactTypeService = artifactTypeService;
    }

    public void setMaxBulkUploadFailures(final int maxBulkUploadFailures) {
        this.maxBulkUploadFailures = maxBulkUploadFailures;
    }
}
