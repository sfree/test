package com.ubs.f35.swift.deploy.glu.rest;

import static com.ubs.f35.swift.deploy.glu.rest.GluJsonUtils.extractFromMap;
import static com.ubs.f35.swift.util.ErrorUtils.buildErrorLink;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.linkedin.zookeeper.tracker.TrackedNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.StringUtils;

import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.google.common.collect.MapDifference;
import com.google.common.collect.MapDifference.ValueDifference;
import com.google.common.collect.Maps;
import com.ubs.f35.swift.deploy.glu.state.GluState;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.environment.model.glu.Script;
import com.ubs.f35.swift.model.State;
import com.ubs.f35.swift.model.State.StateLevel;
import com.ubs.f35.swift.zookeeper.ZooKeeperTreeTracker;
import com.ubs.f35.swift.zookeeper.ZooKeeperTreeTracker.ZKState;

/**
 * Exposes functionality provided by the GLU orchestration engine.
 * 
 * @author stephelu
 * 
 */
public class GluProcessManager implements ProcessDetailsProvider {
    private static final Logger LOG = LoggerFactory.getLogger(GluProcessManager.class);

    /**
     * Regular expressions for extracting the script details for live and configured entries.
     */
    private static final String SCRIPT_JAR_VERSION_PATTERN = "(?:http|swift-scripts).*/.*?\\-?([0-9][^a-zA-Z].*)\\.jar";
    private static final Pattern SCRIPT_VERSION_NUMBER_PATTERN =
            Pattern.compile(SCRIPT_JAR_VERSION_PATTERN);

    public static final String LEGACY_SCRIPT_JAR_VERSION_PATTERN = "swift-glu-scripts/(.*)/swift-glu-scripts";
    private static final Pattern LEGACY_SCRIPT_VERSION_NUMBER_PATTERN =
            Pattern.compile(LEGACY_SCRIPT_JAR_VERSION_PATTERN);

    private static final String LOGS_DIR_ATTRIBUTE = "logsDir";
    private static final String JMX_PORT_ATTRIBUTE = "jmxPort";
    private static final String STATE_MACHINE_ERROR_KEY = "error";

    // Injected
    private String environment;
    private ZooKeeperTreeTracker<Map> agentTracker;
    private ZooKeeperTreeTracker<Map> mountPointTracker;

    @Required
    public void setEnvironment(final String environment) {
        this.environment = environment;
    }

    @Required
    public void setAgentTracker(final ZooKeeperTreeTracker<Map> agentTracker) {
        this.agentTracker = agentTracker;
    }

    @Required
    public void setMountPointTracker(final ZooKeeperTreeTracker<Map> mountPointTracker) {
        this.mountPointTracker = mountPointTracker;
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> getAgentDetails(final String agentName) {
        TrackedNode<Map> node = agentTracker.get(agentName);

        if (node == null) {
            String error = environment
                    + " agent '"
                    + agentName
                    + "' is not running. Verify that the host is responding and the Glu agent is running. "
                    + buildErrorLink(
                            "http://confluence.swissbank.com/display/neo/Swift+Troubleshooting#SwiftTroubleshooting-Agentnotrunning",
                            "Click here for help");
            throw new AgentNotFoundException(error);
        }
        return node.getData();
    }

    public String getJMXPort(final String agentName, final String mountPoint) {
        Map details = getMountPointDetails(agentName, mountPoint);

        if (details == null) {
            throw new NoSuchMountPointException("No mountpoint found: " + mountPoint);
        }

        return GluJsonUtils.extractFromMap(details, "scriptState", "script", JMX_PORT_ATTRIBUTE);
    }

    public String getLogDirectory(final String agentName, final String mountPoint) {
        Map details = getMountPointDetails(agentName, mountPoint);

        if (details == null) {
            throw new NoSuchMountPointException("No mountpoint found: " + mountPoint);
        }

        return GluJsonUtils.extractFromMap(details, "scriptState", "script", LOGS_DIR_ATTRIBUTE);
    }

    /**
     * Returns the current state of a process. This includes
     * <ul>
     * <li>Current errors in the state machine</li>
     * <li>Deltas in the deployed state to desired state</li>
     * <li>Details of the process logs</li>
     * </ul>
     * 
     * @param entry
     * @return
     */
    @SuppressWarnings("rawtypes")
    public State getProcessState(final Entry entry) {
        // The large try catch block is essential as reading the state from zookeeper involves many assumptions about
        // the data structure stored in zookeeper and many blind casts to extract data from it.
        try {
            TrackedNode<Map> mountPointNode = getMountPointNode(entry.getAgent(), entry.getMountPoint());
            Map details = mountPointNode == null ? null : mountPointNode.getData();

            if (details == null) {
                switch (getState()) {
                case Connected:
                    return new State(StateLevel.ERROR, "Not Deployed", Lists.<String>newArrayList());
                case Connecting:
                    return new State(StateLevel.ERROR, "Zookeeper", "Process details not synchronised from zookeeper.");
                default:
                    return new State(StateLevel.ERROR, "Zookeeper",
                            "Process state cannot be reported while zookeeper is down");
                }
            }

            State procState = getProcessStateFromDetails(details, entry);
            if (mountPointNode != null && mountPointNode.getStat() != null) {
                procState.setStateLastModified(mountPointNode.getStat().getMtime());
            }
            addAgentDownWarning(entry, procState);
            addZkDownWarning(entry, procState);

            return procState;

        } catch (RuntimeException ex) {
            // If any exception occurs attempting to create the State for the entry, return that in the summary so it
            // still shows in the status dashboard.
            LOG.error("Exception extracting details for entry {}", entry.getMountPoint(), ex);

            return new State(StateLevel.ERROR, "Exception",
                    Arrays.asList("Unable to extract data for the artifact. Please contact support",
                            ex.getClass().getName() + ": " + ex.getMessage()));
        }
    }

    @Override
    public ProcessDetails getCurrentProcessState(final Entry entry) throws ProcessDetailsUnavailableException {
        if (getState() != ZKState.Connected) {
            throw new ProcessDetailsUnavailableException("state cannot be provided while zookeeper is down in "
                    + environment);
        } else if (isAgentDown(entry.getAgent())) {
            throw new ProcessDetailsUnavailableException("state cannot be provided while agent is down: "
                    + entry.getAgent());
        }

        Map details = getMountPointDetails(entry.getAgent(), entry.getMountPoint());
        if (details == null) {
            return new ProcessDetails(GluState.nomountpoint, StateLevel.ERROR, false);
        }
        return getProcessDetails(details, entry);
    }

    // TODO consider making this non-static and refactoring the delta calculation into smaller modules. this is starting
    // to get a bit big.
    static ProcessDetails getProcessDetails(final Map details, final Entry entry) {
        State state = getProcessStateFromDetails(details, entry);

        String stateMachineError = extractFromMap(details, "scriptState", "stateMachine", STATE_MACHINE_ERROR_KEY);

        String deployedVersion = extractFromMap(details, "scriptDefinition", "initParameters", "project", "v");

        return new ProcessDetails(extractGluState(details), state.getState(), StringUtils.hasText(stateMachineError),
                deployedVersion);
    }

    private static GluState extractGluState(final Map result) {
        String value = extractFromMap(result, "scriptState", "stateMachine", "currentState");
        return GluState.valueOf(value);
    }

    private static State getProcessStateFromDetails(final Map details, final Entry entry) {
        Map scriptState = (Map) details.get("scriptState");
        Map stateMachine = (Map) scriptState.get("stateMachine");

        State state = new State(StateLevel.OK, "Running", Lists.<String>newArrayList());

        addErrors(entry, stateMachine, state);
        addDeltas(entry, details, state);

        return state;
    }

    public List<DeploymentAction> getProcessActions(final Entry entry) {
        if (getState() != ZKState.Connected) {
            return Lists.newArrayList(DeploymentAction.values());
        }

        Map details = getMountPointDetails(entry.getAgent(), entry.getMountPoint());

        if (details == null) {
            return DeploymentAction.getDeploymentActionsFromState(GluState.nomountpoint);
        }

        String currentState = GluJsonUtils.extractFromMap(details, "scriptState", "stateMachine", "currentState");

        return DeploymentAction.getDeploymentActionsFromState(GluState.valueOf(currentState));
    }

    public boolean isProcessDeployed(final String agent, final String mountPoint) {
        return getMountPointDetails(agent, mountPoint) != null;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private static void addErrors(final Entry entry, final Map stateMachine, final State state) {
        String currentState = (String) stateMachine.get("currentState");
        state.setStatus(StringUtils.capitalize(currentState));

        GluState expectedState = entry.isColdStandby() ? GluState.stopped : GluState.running;
        if (!expectedState.name().equals(currentState)) {
            // running cold backups are a warning.
            if (GluState.running.name().equals(currentState)) {
                state.setState(StateLevel.WARNING);
                state.setStatus("Cold standby is running");
            } else {
                state.setState(StateLevel.ERROR);
                state.setStatus("Not Expected State");
            }

            Set<Map.Entry> errorEntries = stateMachine.entrySet();
            for (Map.Entry error : errorEntries) {
                state.getStatusInfos().add(String.valueOf(error.getKey()) + " : " + String.valueOf(error.getValue()));
            }
        } else if (stateMachine.containsKey(STATE_MACHINE_ERROR_KEY)) {
            state.setState(StateLevel.WARNING);
            state.setStatus("Not Expected State");
            state.getStatusInfos().add(
                    STATE_MACHINE_ERROR_KEY + " : " + String.valueOf(stateMachine.get(STATE_MACHINE_ERROR_KEY)));
        }
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private static void addDeltas(final Entry entry, final Map details, final State state) {
        Map scriptDef = (Map) details.get("scriptDefinition");
        Map<String, Object> initParams = (Map) scriptDef.get("initParameters");
        List<String> deltas = getDelta(entry, initParams);

        String liveScript = getLiveScript(scriptDef);
        String configuredScript = getConfiguredScript(entry);

        if (!Objects.equal(configuredScript, liveScript)) {
            addDiff(deltas, null, "script", configuredScript, liveScript);
        }

        if (!deltas.isEmpty()) {
            if (state.getStatusInfos().isEmpty()) {
                state.setState(StateLevel.WARNING);
                state.setStatus("Delta");
            }
            LOG.debug("Delta {} for entry {}", deltas, entry);

            state.getStatusInfos().addAll(deltas);
            state.getStatusInfos().add("To resolve the delta, please redeploy.");
        }
    }

    private static String getConfiguredScript(final Entry entry) {
        Script script = entry.getScript();
        return script.getVersion() + '/' + script.getScript();
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private static String getLiveScript(final Map scriptDef) {
        Map<String, Object> scriptFactory = (Map) scriptDef.get("scriptFactory");
        try {
            String className = (String) scriptFactory.get("className");
            List<String> classPaths = (List<String>) scriptFactory.get("classPath");
            String classPath = classPaths.get(0);

            Matcher scriptVersionNumberMatcher = SCRIPT_VERSION_NUMBER_PATTERN.matcher(classPath);
            if (!scriptVersionNumberMatcher.find()) {
                scriptVersionNumberMatcher = LEGACY_SCRIPT_VERSION_NUMBER_PATTERN.matcher(classPath);
                scriptVersionNumberMatcher.find();
            }
            String version = scriptVersionNumberMatcher.group(1);
            String liveScript = version + '/' + className;
            return liveScript;
        } catch (RuntimeException ex) {
            LOG.info("Unable to extract script version from {}", scriptFactory);
            return String.valueOf(scriptFactory);
        }
    }

    /**
     * If the glu agent is down for this process, add a warning that the details being reported may not be accurate.
     * 
     * @param entry
     * @param state
     */
    private void addAgentDownWarning(final Entry entry, final State state) {
        if (isAgentDown(entry.getAgent())) {
            if (state.getState() == StateLevel.OK) {
                state.setState(StateLevel.WARNING);
            }
            state.getStatusInfos().add("The agent is down. Reporting the last known state");
        }
    }

    /**
     * If the zookeeper connection is down for this environment, add a warning that the details being reported may not
     * be accurate.
     * 
     * @param entry
     * @param state
     */
    private void addZkDownWarning(final Entry entry, final State state) {
        if (getState() != ZKState.Connected) {
            if (state.getState() == StateLevel.OK) {
                state.setState(StateLevel.WARNING);
            }
            if (getState() == ZKState.Disconnected) {
                state.getStatusInfos().add("Zookeeper is down. Reporting the last known state");
            } else {
                state.getStatusInfos().add("Resyncing zookeeper data after connecting. Reporting the last known state");
            }
        }
    }

    private ZKState getState() {
        if (agentTracker.getState() == ZKState.Disconnected || mountPointTracker.getState() == ZKState.Disconnected) {
            return ZKState.Disconnected;
        }
        if (agentTracker.getState() == ZKState.Connecting || mountPointTracker.getState() == ZKState.Connecting) {
            return ZKState.Connecting;
        } else {
            return ZKState.Connected;
        }
    }

    public boolean isAgentDown(final String agent) {
        return agentTracker.get(agent) == null;
    }

    private static List<String> getDelta(final Entry entry, final Map<String, Object> liveInitParams) {
        Map<String, Object> expectedInitParams = entry.getInitParameters();

        List<String> deltas = Lists.newArrayList();
        compareMaps(deltas, expectedInitParams, liveInitParams, null);

        return deltas;
    }

    private static void compareMaps(final List<String> deltas, final Map<String, Object> expectedInitParams,
            final Map<String, Object> details, final String path) {
        MapDifference<String, Object> diffs = Maps.difference(expectedInitParams, details);
        if (!diffs.areEqual()) {
            for (java.util.Map.Entry<String, ValueDifference<Object>> diff : diffs.entriesDiffering().entrySet()) {
                addDiff(deltas, path, diff.getKey(), diff.getValue().leftValue(), diff.getValue().rightValue());
            }
            for (java.util.Map.Entry<String, Object> diff : diffs.entriesOnlyOnLeft().entrySet()) {
                addDiff(deltas, path, diff.getKey(), diff.getValue(), null);
            }
            for (java.util.Map.Entry<String, Object> diff : diffs.entriesOnlyOnRight().entrySet()) {
                addDiff(deltas, path, diff.getKey(), null, diff.getValue());
            }
        }
    }

    private static void addDiff(final List<String> deltas, final String path, final String key, final Object left,
            final Object right) {
        String currentPath = (path == null ? "" : path + ".") + key;

        if ("project.name".equals(currentPath)) {
            // instance name is ignored as this was added recently and would result in a delta to every mountpoint.
            return;
        }
        else if (left == null && "".equals(right)) {
            // Historically the artifact config screen saved unspecified script configuration arguments as empty string.
            // The bulk upload saved them as null. For consistency, null was adopted, however there will be legacy
            // deployments whose state is still empty string. This should not result in a delta.
            return;
        }

        if (left instanceof Map && right instanceof Map) {
            compareMaps(deltas, (Map<String, Object>) left, (Map<String, Object>) right, currentPath);
        }
        else {
            deltas.add(currentPath + ":[" + String.valueOf(left) + "!=" + String.valueOf(right) + "]");
        }
    }

    private TrackedNode<Map> getMountPointNode(final String agentName, final String mountPoint) {
        String path = getMountPointPath(agentName, mountPoint);
        return mountPointTracker.get(path);
    }

    private Map getMountPointDetails(final String agentName, final String mountPoint) {
        TrackedNode<Map> node = getMountPointNode(agentName, mountPoint);
        if (node == null) {
            return null;
        }

        return node.getData();
    }

    static String getMountPointPath(final String agentName, final String mountPoint) {
        String escapedMountPoint = mountPoint.replace('/', '_');

        return agentName + "/" + escapedMountPoint;
    }
}
