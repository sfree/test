package com.ubs.f35.swift.deploy.client.action;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import com.google.common.collect.Lists;
import com.ubs.f35.swift.deploy.glu.action.Action;
import com.ubs.f35.swift.deploy.glu.action.BaseGroupedAction;
import com.ubs.f35.swift.deploy.glu.action.SequentialAction;
import com.ubs.f35.swift.deploy.glu.action.TransitionAction;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlan;
import com.ubs.f35.swift.deploy.glu.plan.GluDeploymentPlanGenerator;

public class ClientDeploymentPlanConvertor {

    private static final Logger LOG = LoggerFactory.getLogger(ClientDeploymentPlanConvertor.class);

    /**
     * convert to a client representation. This means changes can be made on the server side without impacting the
     * client. Initially implemented when switching from mcollective to glu to avoid refactoring the client.
     * 
     * @param deploymentPlan
     * @return
     */
    public ClientDeploymentPlan convert(final DeploymentPlan deploymentPlan) {
        Assert.notNull(deploymentPlan, "Deployment plan is null");
        Assert.isTrue(deploymentPlan.getActions().size() == 1, "Can only convert a single root action");

        ClientPlanGroupAction groupActions = convertGroupedAction((BaseGroupedAction) deploymentPlan.getActions()
                .get(0));

        return new ClientDeploymentPlan(deploymentPlan.getId().toString(), Arrays.asList(groupActions),
                deploymentPlan.getWarnings());
    }

    /**
     * Flattens nested groups actions.
     * 
     * @param action
     * @param groupActions
     * @return
     */
    private ClientPlanGroupAction convertGroupedAction(final BaseGroupedAction action) {
        List<Action> rootActions = Lists.newArrayList();
        addRootActions(rootActions, action.getIncluded());

        List<ClientAction> childActions = convertActions(rootActions);

        String artifactInstanceId = null;
        String artifactId = null;
        if (action instanceof SequentialAction) {
            artifactInstanceId = ((SequentialAction) action).getArtifactInstanceId();
            artifactId = ((SequentialAction) action).getArtifactId();
        }

        return new ClientPlanGroupAction(action.getId(), action.getName(), childActions, action.isExecute(),
                artifactInstanceId, artifactId);
    }

    /**
     * Evil piece of code which flattens the deployment plan to hide higher levels of grouping which the client should
     * not see.
     * 
     * @param rootActions
     * @param list
     */
    private void addRootActions(final List<Action> rootActions, final List<Action> list) {
        for (Action childAction : list) {
            if (childAction.getName().equals(GluDeploymentPlanGenerator.ACTION_NAME_PERFORM_RELEASE)) {
                addRootActions(rootActions, ((BaseGroupedAction) childAction).getIncluded());
            } else {
                rootActions.add(childAction);
            }
        }
    }

    /**
     * Converts the deployment plan to a client side plan. Note that the client currently does not support the concept
     * of grouped actions so this is flattened.
     * 
     * @param actions
     * @param clientActions
     */
    private List<ClientAction> convertActions(final List<Action> actions) {
        List<ClientAction> childActions = Lists.newArrayList();
        for (Action action : actions) {
            if (action instanceof TransitionAction) {
                childActions.add(convertAction((TransitionAction) action));
            } else if (action instanceof BaseGroupedAction) {
                childActions.add(convertGroupedAction((BaseGroupedAction) action));
            } else if (action instanceof ClientAction) {
                childActions.add((ClientAction) action);
            } else {
                LOG.error("Unexpected action cannot be mapped {}", action);
            }
        }
        return childActions;
    }

    private ClientPlanAction convertAction(final TransitionAction input) {
        return ClientActionConvertor.INSTANCE.apply(input);
    }

}
