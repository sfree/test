package com.ubs.f35.swift.model;

import java.util.Date;
import java.util.List;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.model.Team;

public class ReleaseDeploymentSummary {

    private final LiteReleaseDefinition releaseDefinition;
    private final List<EnvironmentDeploymentSummary> deploymentSummaries;

    public ReleaseDeploymentSummary(final ReleaseDefinition releaseDefinition,
            final List<EnvironmentDeploymentSummary> deploymentSummaries) {
        this.releaseDefinition = new LiteReleaseDefinition(releaseDefinition);
        this.deploymentSummaries = deploymentSummaries;
    }

    public LiteReleaseDefinition getReleaseDefinition() {
        return releaseDefinition;
    }

    public List<EnvironmentDeploymentSummary> getDeploymentSummaries() {
        return deploymentSummaries;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(releaseDefinition, deploymentSummaries);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ReleaseDeploymentSummary) {
            ReleaseDeploymentSummary that = (ReleaseDeploymentSummary) object;
            return Objects.equal(this.releaseDefinition, that.releaseDefinition)
                    && Objects.equal(this.deploymentSummaries, that.deploymentSummaries);
        }
        return false;
    }

    @Override
    public String toString() {
        // Note that only the size of the deployment summaries is displayed to avoid excessive logging slowing down this
        // request.
        Object summariesOut = deploymentSummaries != null && deploymentSummaries.size() >= 10 ? deploymentSummaries
                .size() : deploymentSummaries;

        return Objects.toStringHelper(this)
                .add("releaseDefinition", releaseDefinition)
                .add("deploymentSummaries", summariesOut)
                .toString();
    }

    /**
     * Tailored made object with only the specific fields required on the releases screen.
     */
    public static class LiteReleaseDefinition {

        private final Integer id;
        private final String name;
        private final Team team;
        private final Date releaseDate;
        private final Boolean locked;

        private LiteReleaseDefinition(final ReleaseDefinition release) {
            id = release.getId();
            name = release.getName();
            team = new Team();
            team.setName(release.getTeam().getName());
            locked = release.isLocked();
            releaseDate = release.getReleaseDate();
        }

        public Integer getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public Team getTeam() {
            return team;
        }

        public Date getReleaseDate() {
            return releaseDate;
        }

        public Boolean getLocked() {
            return locked;
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof LiteReleaseDefinition) {
                LiteReleaseDefinition that = (LiteReleaseDefinition) object;
                return Objects.equal(this.id, that.id)
                        && Objects.equal(this.name, that.name)
                        && Objects.equal(this.team, that.team)
                        && Objects.equal(this.locked, that.locked)
                        && Objects.equal(this.releaseDate, that.releaseDate);
            }
            return false;
        }
    }
}
