package com.ubs.f35.swift.activity.data;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.ObjectUtils;
import org.codehaus.jackson.annotate.JsonIgnore;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.Activity;
import com.ubs.f35.swift.dao.Activity.ActivityType;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseLink;

/**
 * Data object format for an {@link Activity} of type {@link ActivityType#RELEASE}
 * 
 * @author levyjo
 * 
 */
public class ReleaseActivityData implements ActivityData {

    private String releaseName;

    private String oldReleaseName;
    private boolean descriptionChanged = false;
    private boolean releaseDateChanged = false;
    private Date oldReleaseDate;
    private Date newReleaseDate;

    private Set<Artifact> artifactsAdded = new HashSet<Artifact>();
    private Set<Artifact> artifactsRemoved = new HashSet<Artifact>();

    private Set<ReleaseLink> releaseLinksAdded = new HashSet<ReleaseLink>();
    private Set<ReleaseLink> releaseLinksRemoved = new HashSet<ReleaseLink>();

    private Boolean lockedUnlocked;

    public ReleaseActivityData() {

    }

    public ReleaseActivityData(final String releaseName) {
        this.releaseName = releaseName;
    }

    public String getReleaseName() {
        return releaseName;
    }

    public void setReleaseName(final String releaseName) {
        this.releaseName = releaseName;
    }

    public String getOldReleaseName() {
        return oldReleaseName;
    }

    public void setOldReleaseName(final String oldReleaseName) {
        this.oldReleaseName = oldReleaseName;
    }

    public boolean isDescriptionChanged() {
        return descriptionChanged;
    }

    public void setDescriptionChanged(final boolean descriptionChanged) {
        this.descriptionChanged = descriptionChanged;
    }

    public boolean isReleaseDateChanged() {
        return releaseDateChanged;
    }

    public void setReleaseDateChanged(final boolean releaseDateChanged) {
        this.releaseDateChanged = releaseDateChanged;
    }

    public Date getOldReleaseDate() {
        return oldReleaseDate;
    }

    public void setOldReleaseDate(final Date oldReleaseDate) {
        this.oldReleaseDate = oldReleaseDate;
    }

    public Date getNewReleaseDate() {
        return newReleaseDate;
    }

    public void setNewReleaseDate(final Date newReleaseDate) {
        this.newReleaseDate = newReleaseDate;
    }

    public Set<Artifact> getArtifactsAdded() {
        return artifactsAdded;
    }

    public void setArtifactsAdded(final Set<Artifact> artifactsAdded) {
        this.artifactsAdded = artifactsAdded;
    }

    public Set<Artifact> getArtifactsRemoved() {
        return artifactsRemoved;
    }

    public void setArtifactsRemoved(final Set<Artifact> artifactsRemoved) {
        this.artifactsRemoved = artifactsRemoved;
    }

    public Set<ReleaseLink> getReleaseLinksAdded() {
        return releaseLinksAdded;
    }

    public void setReleaseLinksAdded(final Set<ReleaseLink> releaseLinksAdded) {
        this.releaseLinksAdded = releaseLinksAdded;
    }

    public Set<ReleaseLink> getReleaseLinksRemoved() {
        return releaseLinksRemoved;
    }

    public void setReleaseLinksRemoved(final Set<ReleaseLink> releaseLinksRemoved) {
        this.releaseLinksRemoved = releaseLinksRemoved;
    }

    public Boolean getLockedUnlocked() {
        return lockedUnlocked;
    }

    public void setLockedUnlocked(final Boolean lockedUnlocked) {
        this.lockedUnlocked = lockedUnlocked;
    }

    @Override
    public ReleaseActivityData merge(final ActivityData newDataI) {

        ReleaseActivityData newData = (ReleaseActivityData) newDataI;

        if (newData.getOldReleaseName() != null) { // Release name changed
            releaseName = newData.getReleaseName();
            if (oldReleaseName == null) {
                oldReleaseName = newData.getOldReleaseName();
            } else if (oldReleaseName.equals(releaseName)) {
                // release name has been changed back to what it was originally
                oldReleaseName = null;
            } // else: release name was already changed so show original name
        }

        if (newData.isDescriptionChanged()) {
            descriptionChanged = true;
        }

        if (newData.isReleaseDateChanged()) { // Release date changed
            newReleaseDate = newData.getNewReleaseDate();
            if (!releaseDateChanged) {
                // release date not previously changed
                releaseDateChanged = true;
                oldReleaseDate = newData.getOldReleaseDate();
            } else if (ObjectUtils.equals(oldReleaseDate, newReleaseDate)) {
                // release date has been changed back to what it was originally
                releaseDateChanged = false;
                oldReleaseDate = null;
                newReleaseDate = null;
            } // else: release date was already changed so show original date
        }

        addIfCannotRemove(newData.getArtifactsAdded(), artifactsRemoved, artifactsAdded);

        addIfCannotRemove(newData.getArtifactsRemoved(), artifactsAdded, artifactsRemoved);

        addIfCannotRemove(newData.getReleaseLinksAdded(), releaseLinksRemoved, releaseLinksAdded);

        addIfCannotRemove(newData.getReleaseLinksRemoved(), releaseLinksAdded, releaseLinksRemoved);

        if (newData.getLockedUnlocked() != null) {
            if (lockedUnlocked == null) {
                lockedUnlocked = newData.getLockedUnlocked();
            } else if (!newData.getLockedUnlocked().equals(lockedUnlocked)) {
                // previous lock/unlock cancelled out by this one
                lockedUnlocked = null;
            }
        }

        return this;

    }

    @JsonIgnore
    @Override
    public boolean isEmpty() {
        return oldReleaseName == null && !descriptionChanged && !releaseDateChanged && artifactsAdded.isEmpty()
                && artifactsRemoved.isEmpty() && releaseLinksAdded.isEmpty() && releaseLinksRemoved.isEmpty()
                && lockedUnlocked == null;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(releaseName, oldReleaseName, descriptionChanged, releaseDateChanged, oldReleaseDate,
                newReleaseDate, artifactsAdded, artifactsRemoved, releaseLinksAdded, releaseLinksRemoved,
                lockedUnlocked);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ReleaseActivityData) {
            ReleaseActivityData that = (ReleaseActivityData) object;
            return Objects.equal(this.releaseName, that.releaseName)
                    && Objects.equal(this.oldReleaseName, that.oldReleaseName)
                    && Objects.equal(this.descriptionChanged, that.descriptionChanged)
                    && Objects.equal(this.releaseDateChanged, that.releaseDateChanged)
                    && Objects.equal(this.oldReleaseDate, that.oldReleaseDate)
                    && Objects.equal(this.newReleaseDate, that.newReleaseDate)
                    && Objects.equal(this.artifactsAdded, that.artifactsAdded)
                    && Objects.equal(this.artifactsRemoved, that.artifactsRemoved)
                    && Objects.equal(this.releaseLinksAdded, that.releaseLinksAdded)
                    && Objects.equal(this.releaseLinksRemoved, that.releaseLinksRemoved)
                    && Objects.equal(this.lockedUnlocked, that.lockedUnlocked);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("releaseName", releaseName)
                .add("oldReleaseName", oldReleaseName)
                .add("descriptionChanged", descriptionChanged)
                .add("releaseDateChanged", releaseDateChanged)
                .add("oldReleaseDate", oldReleaseDate)
                .add("newReleaseDate", newReleaseDate)
                .add("artifactsAdded", artifactsAdded)
                .add("artifactsRemoved", artifactsRemoved)
                .add("releaseLinksAdded", releaseLinksAdded)
                .add("releaseLinksRemoved", releaseLinksRemoved)
                .add("lockedUnlocked", lockedUnlocked)
                .toString();
    }

    public static ReleaseActivityData newRelease(final ReleaseDefinition releaseDefinition) {
        ReleaseActivityData data = new ReleaseActivityData(releaseDefinition.getName());
        return data;
    }

    public static ReleaseActivityData editDetails(final ReleaseDefinition releaseDefinition) {
        ReleaseActivityData data = new ReleaseActivityData(releaseDefinition.getName());
        return data;
    }

    public static ReleaseActivityData editDescription(final ReleaseDefinition releaseDefinition) {
        ReleaseActivityData data = new ReleaseActivityData(releaseDefinition.getName());
        data.setDescriptionChanged(true);
        return data;
    }

    public static ReleaseActivityData addArtifact(final ReleaseDefinition releaseDefinition, final Artifact artifact) {
        ReleaseActivityData data = new ReleaseActivityData(releaseDefinition.getName());
        data.getArtifactsAdded().add(artifact);
        return data;
    }

    public static ReleaseActivityData modifyArtifact(final ReleaseDefinition releaseDefinition,
            final Artifact oldArtifact, final Artifact newArtifact) {
        ReleaseActivityData data = new ReleaseActivityData(releaseDefinition.getName());
        data.getArtifactsAdded().add(newArtifact);
        data.getArtifactsRemoved().add(oldArtifact);
        return data;
    }

    public static ReleaseActivityData modifyArtifacts(final ReleaseDefinition releaseDefinition,
            final List<Artifact> oldArtifacts, final List<Artifact> newArtifacts) {
        ReleaseActivityData data = new ReleaseActivityData(releaseDefinition.getName());
        data.getArtifactsAdded().addAll(newArtifacts);
        data.getArtifactsRemoved().addAll(oldArtifacts);
        return data;
    }

    public static ReleaseActivityData removeArtifact(final ReleaseDefinition releaseDefinition, final Artifact artifact) {
        ReleaseActivityData data = new ReleaseActivityData(releaseDefinition.getName());
        data.getArtifactsRemoved().add(artifact);
        return data;
    }

    public static ReleaseActivityData addReleaseLink(final ReleaseDefinition releaseDefinition,
            final ReleaseLink releaseLink) {
        ReleaseActivityData data = new ReleaseActivityData(releaseDefinition.getName());
        data.getReleaseLinksAdded().add(releaseLink);
        return data;
    }

    public static ReleaseActivityData removeReleaseLink(final ReleaseDefinition releaseDefinition,
            final ReleaseLink releaseLink) {
        ReleaseActivityData data = new ReleaseActivityData(releaseDefinition.getName());
        data.getReleaseLinksRemoved().add(releaseLink);
        return data;
    }

    public static ReleaseActivityData lockUnlock(final ReleaseDefinition releaseDefinition, final boolean lock) {
        ReleaseActivityData data = new ReleaseActivityData(releaseDefinition.getName());
        data.setLockedUnlocked(lock);
        return data;
    }

    /**
     * For each item in newDataset, add it to addPool if it cannot be removed from the removePool.
     */
    private static <T> void addIfCannotRemove(final Set<T> newDataset, final Set<T> removePool, final Set<T> addPool) {
        for (T item : newDataset) {
            if (!removePool.remove(item)) {
                addPool.add(item);
            }
        }
    }
}
