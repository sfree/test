package com.ubs.f35.swift.zookeeper;

import org.apache.zookeeper.KeeperException;

public class ZookeeperTemplate {
    private ZookeeperTemplate() {
    }

    public static <T> T doInZookeeper(final ZookeeperExecutor<T> executor) {
        try {
            return executor.doInZK();
        } catch (KeeperException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public interface ZookeeperExecutor<T> {
        T doInZK() throws KeeperException, InterruptedException;
    }

}
