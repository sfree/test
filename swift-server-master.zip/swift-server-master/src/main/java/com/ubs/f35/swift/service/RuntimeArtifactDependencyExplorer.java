package com.ubs.f35.swift.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Required;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ubs.f35.swift.config.model.ArtifactCommonConfig;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.ProcessDetails;
import com.ubs.f35.swift.deploy.glu.rest.ProcessDetailsProvider;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.model.glu.Entry;

public class RuntimeArtifactDependencyExplorer {
    private ArtifactConfigurationService artifactConfigurationService;
    private EnvironmentDocumentStore environmentDocumentStore;
    private EnvironmentBeanFactory<ProcessDetailsProvider> processDetailsProviderFactory;

    public Map<NexusArtifact, List<ProcessDetails>> getDependantArtifactsAndStatus(final Environment environment,
            final Set<NexusArtifact> artifacts) {
        return getDependantArtifactsAndStatus(environment, artifacts, GetDependantOnArtifactFunction.INSTANCE);
    }

    public Map<NexusArtifact, List<ProcessDetails>> getArtifactDependenciesAndStatus(final Environment environment,
            final Set<NexusArtifact> artifacts) {
        return getDependantArtifactsAndStatus(environment, artifacts, GetArtifactDependenciesFunction.INSTANCE);
    }

    private Map<NexusArtifact, List<ProcessDetails>> getDependantArtifactsAndStatus(final Environment environment,
            final Set<NexusArtifact> artifacts,
            final Function<ArtifactCommonConfig, List<ArtifactCommonConfig>> dependencyFunction) {
        ProcessDetailsProvider processDetailsProvider = processDetailsProviderFactory.get(environment);
        Map<NexusArtifact, List<ProcessDetails>> result = Maps.newHashMap();

        for (NexusArtifact nexusArtifact : artifacts) {
            ArtifactCommonConfig artifact = artifactConfigurationService.loadOrDefaultCommonConfig(nexusArtifact);

            for (ArtifactCommonConfig dependency : dependencyFunction.apply(artifact)) {
                NexusArtifact depArtifact = dependency.getArtifact();
                if (!result.containsKey(depArtifact) && !artifacts.contains(depArtifact)) {
                    Collection<Entry> entries = environmentDocumentStore.filterEntriesByArtifact(environment,
                            depArtifact);
                    List<ProcessDetails> statuses = Lists.newArrayList();
                    for (Entry entry : entries) {
                        statuses.add(processDetailsProvider.getCurrentProcessState(entry));
                    }
                    result.put(depArtifact, statuses);
                }
            }
        }
        return result;
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

    @Required
    public void setProcessDetailsProviderFactory(
            final EnvironmentBeanFactory<ProcessDetailsProvider> processDetailsProviderFactory) {
        this.processDetailsProviderFactory = processDetailsProviderFactory;
    }

}
