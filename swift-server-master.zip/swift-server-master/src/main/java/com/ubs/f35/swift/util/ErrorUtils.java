package com.ubs.f35.swift.util;

public class ErrorUtils {
    /**
     * Builds an error message with a url link for rendering on the client. The link will open in a new tab / window.
     * 
     * @param url
     * @param text
     * @return
     */
    public static String buildErrorLink(final String url, final String text) {
        return "<a href='" + url + "' target='blank'>" + text + "</a>";
    }
}
