package com.ubs.f35.swift.properties;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Required;

import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.GluDeploymentInvoker;
import com.ubs.f35.swift.service.CommandBuilderService;

public class GluAgentZooKeeperConnectorBuilder {

    private HealthyAgentProvider healthyAgentProvider;

    public GluAgentZooKeeperConnector build(final Environment environment, final GluDeploymentInvoker gluAgentInvoker,
            final CommandBuilderService commandBuilderService, final Properties zooKeeperClientProperties,
            final ZooKeeperConnector nativeZooKeeperConnector) {
        return new GluAgentZooKeeperConnector(environment, gluAgentInvoker, commandBuilderService,
                zooKeeperClientProperties, nativeZooKeeperConnector, healthyAgentProvider);
    }

    @Required
    public void setHealthyAgentProvider(final HealthyAgentProvider healthyAgentProvider) {
        this.healthyAgentProvider = healthyAgentProvider;
    }
}
