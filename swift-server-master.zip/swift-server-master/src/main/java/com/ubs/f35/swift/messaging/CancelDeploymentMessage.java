package com.ubs.f35.swift.messaging;

import com.google.common.base.Objects;

public class CancelDeploymentMessage {
    private String deploymentId;

    public String getDeploymentId() {
        return deploymentId;
    }

    public void setDeploymentId(final String deploymentId) {
        this.deploymentId = deploymentId;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(deploymentId);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof CancelDeploymentMessage) {
            CancelDeploymentMessage that = (CancelDeploymentMessage) object;
            return Objects.equal(this.deploymentId, that.deploymentId);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("deploymentId", deploymentId)
                .toString();
    }

}
