package com.ubs.f35.swift.properties;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Required;

import com.google.common.collect.Lists;
import com.ubs.f35.swift.dao.DefaultPropertiesDao;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.PropertiesDefault;
import com.ubs.f35.swift.dao.hibernate.AuditEntry;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.properties.model.Property;
import com.ubs.f35.swift.properties.model.PropertyList;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.security.Permission;

/**
 * Provides environment property defaults from the data store to the front end and to the business logic layers.
 * 
 * @author levyjo
 * 
 */
public class DefaultPropertiesProvider {

    private DefaultPropertiesDao defaultPropertiesDao;
    private AuthorisationController authorisationController;

    /**
     * Returns all default properties that exist for the given environment as a map
     * 
     * @param environment
     * @return {@link Map} of property keys and values
     */
    public Map<String, String> getDefaultPropertiesAsMap(final Environment environment) {
        return getDefaultProperties(environment).toMap();
    }

    /**
     * Returns all default properties that exist for the given environment as a {@link PropertyList}
     * 
     * @param environment
     * @return {@link PropertyList} of {@link Property} or empty list if no defaults exist
     */
    public PropertyList getDefaultProperties(final Environment environment) {
        authorisationController.checkEnvironmentAccess(environment, Permission.ViewProperties);
        return fromDaoModels(defaultPropertiesDao.loadDefaultProperties(environment));
    }

    /**
     * Returns the {@link Property} containing the value for the given key and environment
     * 
     * @param environment
     * @param propertyKey
     * @return {@link Property} or null if key does not exist
     */
    public Property getDefaultProperty(final Environment environment, final String propertyKey) {
        authorisationController.checkEnvironmentAccess(environment, Permission.ViewProperties);
        return fromDaoModel(defaultPropertiesDao.loadDefaultProperty(environment, propertyKey));
    }

    /**
     * Sets all default properties for the given environment. This will create, update and delete defaults from the data
     * store as necessary so that properties exactly match those in the given list.
     * 
     * @param environment
     * @param properties
     *            {@link PropertyList} of properties
     */
    public void saveDefaultProperties(final Environment environment, final PropertyList properties) {
        authorisationController.checkEnvironmentAccess(environment, Permission.ModifyProperties);
        defaultPropertiesDao.setDefaultProperties(toDaoModels(properties, environment), environment);
    }

    /**
     * Creates or updates the given default property for the given environment
     * 
     * @param environment
     * @param property
     *            {@link Property} to save
     */
    public void saveDefaultProperty(final Environment environment, final Property property) {
        authorisationController.checkEnvironmentAccess(environment, Permission.ModifyProperties);
        defaultPropertiesDao.saveOrUpdateDefaultProperty(toDaoModel(property, environment));
    }

    /**
     * Deletes the default property with the given key in the given environment
     * 
     * @param environment
     * @param propertyKey
     */
    public void deleteDefaultProperty(final Environment environment, final String propertyKey) {
        authorisationController.checkEnvironmentAccess(environment, Permission.ModifyProperties);
        defaultPropertiesDao.removeDefaultProperty(environment, propertyKey);
    }

    public List<AuditEntry<Property>> getAuditHistory(final Environment environment, final PagingFilter filter) {
        List<AuditEntry<PropertiesDefault>> daoEntries = defaultPropertiesDao.getAuditHistory(environment, filter);

        List<AuditEntry<Property>> entries = Lists.newArrayListWithExpectedSize(daoEntries.size());
        for (AuditEntry<PropertiesDefault> audit : daoEntries) {
            AuditEntry<Property> entry = new AuditEntry<Property>(fromDaoModel(audit.getEntity()),
                    audit.getRevision(), audit.getRevisionType());
            entries.add(entry);
        }

        return entries;
    }

    /**
     * Converts a {@link Property} and environment name into a {@link PropertiesDefault} model
     * 
     * @param property
     * @param environment
     * @return {@link PropertiesDefault} model
     */
    public static PropertiesDefault toDaoModel(final Property property, final Environment environment) {
        PropertiesDefault daoModel = new PropertiesDefault();
        daoModel.setEnvironment(environment);
        daoModel.setKey(property.getKey());
        daoModel.setValue(property.getValue());
        return daoModel;
    }

    /**
     * Converts a {@link PropertiesDefault} model from the data store to a {@link Property} object used in the client
     * response
     * 
     * @param propertiesDefault
     * @return {@link Property} or null if the supplied model was null
     */
    public static Property fromDaoModel(final PropertiesDefault propertiesDefault) {

        if (propertiesDefault == null) {
            return null;
        }

        return new Property(propertiesDefault.getKey(), propertiesDefault.getValue());
    }

    /**
     * Converts a {@link PropertyList} and an environment to a {@link List} of {@link PropertiesDefault} models
     * 
     * @param properties
     *            {@link PropertyList}
     * @param environment
     * @return {@link List} of {@link PropertiesDefault}
     */
    public static List<PropertiesDefault> toDaoModels(final PropertyList properties, final Environment environment) {
        List<PropertiesDefault> daoModels = new ArrayList<PropertiesDefault>();
        for (Property property : properties) {
            daoModels.add(toDaoModel(property, environment));
        }
        return daoModels;
    }

    /**
     * Converts a {@link List} of {@link PropertiesDefault} models from the data store to a {@link PropertyList} used in
     * the client response
     * 
     * @param propertiesDefaults
     * @return
     */
    public static PropertyList fromDaoModels(final List<PropertiesDefault> propertiesDefaults) {

        PropertyList propertyList = new PropertyList();
        if (propertiesDefaults == null) {
            return propertyList;
        }

        for (PropertiesDefault propertiesDefault : propertiesDefaults) {
            propertyList.add(fromDaoModel(propertiesDefault));
        }

        return propertyList;
    }

    @Required
    public void setDefaultPropertiesDao(final DefaultPropertiesDao defaultPropertiesDao) {
        this.defaultPropertiesDao = defaultPropertiesDao;
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

}
