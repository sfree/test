package com.ubs.f35.swift.processor;

import static com.ubs.f35.swift.processor.ProcessorUtil.daoFilter;
import static com.ubs.f35.swift.processor.ProcessorUtil.transform;
import static com.ubs.f35.swift.service.ArtifactConfigurationService.isSnapshot;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.regex.Pattern;

import javax.persistence.EntityNotFoundException;
import javax.xml.ws.WebServiceException;
import javax.xml.ws.soap.SOAPFaultException;

import org.joda.time.DateTime;
import org.joda.time.Interval;
import org.linkedin.util.clock.Clock;
import org.linkedin.util.clock.SystemClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import com.google.common.base.Objects;
import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.base.Stopwatch;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.activity.ActivityFeedWriter;
import com.ubs.f35.swift.client.model.ArtifactType;
import com.ubs.f35.swift.client.model.ArtifactWithType;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ArtifactDao;
import com.ubs.f35.swift.dao.DailyReleaseStats;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.PagingResult;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseDefinitionDao;
import com.ubs.f35.swift.dao.ReleaseLink;
import com.ubs.f35.swift.dao.ReleaseWatchDao;
import com.ubs.f35.swift.dao.hibernate.AuditEntry;
import com.ubs.f35.swift.dao.model.DeploymentProcess;
import com.ubs.f35.swift.dao.model.ReleaseWatch.WatchType;
import com.ubs.f35.swift.dao.model.Team;
import com.ubs.f35.swift.deploy.client.rollback.RollbackPrep;
import com.ubs.f35.swift.deploy.client.rollback.RollbackPrepBuilder;
import com.ubs.f35.swift.deploy.glu.plan.Warning;
import com.ubs.f35.swift.deploy.template.DeploymentTemplateValidator;
import com.ubs.f35.swift.deploy.validator.ProductionDeploymentValidator;
import com.ubs.f35.swift.model.ClientPagingFilter;
import com.ubs.f35.swift.model.JsonObjectMapper;
import com.ubs.f35.swift.model.ReleaseDeploymentSummary;
import com.ubs.f35.swift.model.ReleaseFilters;
import com.ubs.f35.swift.model.ReleaseLockedException;
import com.ubs.f35.swift.properties.PropertyKeysPrefetcher;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.service.ArtifactConfigurationService;
import com.ubs.f35.swift.service.ArtifactTypeService;
import com.ubs.f35.swift.service.EnvironmentDeploymentSummaryBuilder;
import com.ubs.f35.swift.service.NexusArtifactService;
import com.ubs.f35.swift.service.TeamsService;
import com.ubs.f35.swift.state.OperationContextProvider;
import com.ubs.swift.rnow.ChangeRequestDetails;
import com.ubs.swift.rnow.ServiceNowClient;

/**
 * Warning about the response objects returned from the update methods in this class.
 * 
 * Several methods return the updated release. However, because of the mapping of objects to their client side
 * representation before the method returns and the transaction boundary completes, the objects have not been updated
 * and the last updated timestamp is stale. A fix though requires some heavy refactoring. The alternative is to move the
 * majority of this logic to a service which has it's own transactional boundaries. Then the processor would see the
 * correctly updated object and be able to return that to the client.
 * 
 * Even if that is fixed, the revision number and latest revision info is not managed by hibernate so this will still be
 * stale requiring another load call. For now the swift-client accomodates this, but something to be wary of.
 */
@Controller
@RequestMapping(value = "/api/release")
@Transactional
public class ReleaseQueryProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(ReleaseQueryProcessor.class);

    public static final String STATS_CACHE_KEY = "ReleaseQueryProcessor.stats";

    private static final String MODIFY_RELEASE_ROLE = "release-create-modify";
    private static final String RELEASE_LOCKDOWN_ROLE = "release-lockdown";

    private static final Pattern VERSION_PATTERN = Pattern.compile("\\d+\\..*");

    private ArtifactConfigurationService artifactConfigurationService;
    private ReleaseDefinitionDao releaseDefinitionDao;
    private ArtifactDao artifactDao;
    private EnvironmentDeploymentSummaryBuilder environmentDeploymentSummaryBuilder;
    private OperationContextProvider contextProvider;
    private ActivityFeedWriter activityFeedWriter;
    private NexusArtifactService nexusArtifactService;
    private TeamsService teamsService;
    private RollbackPrepBuilder rollbackPrepBuilder;
    private PropertyKeysPrefetcher propertyKeysPrefetcher;
    private AuthorisationController authorisationController;
    private Clock clock = SystemClock.instance();
    private ServiceNowClient serviceNowClient;
    private DeploymentTemplateValidator deploymentTemplateValidator;
    private ProductionDeploymentValidator productionDeploymentValidator;
    private ReleaseWatchDao releaseWatchDao;
    private ArtifactTypeService artifactTypeService;

    @InitBinder
    protected void initBinder(final WebDataBinder binder) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }

    @RequestMapping(method = RequestMethod.GET)
    @ResponseBody
    public PagingResult<ReleaseDefinition> getReleases(final ReleaseFilters releaseFilters,
            final ClientPagingFilter filter) {
        PagingResult<ReleaseDefinition> result = releaseDefinitionDao.list(releaseFilters, daoFilter(filter));

        return transform(result, SUMMARY_MAPPER);
    }

    @RequestMapping(value = "/statuses", method = RequestMethod.GET)
    @ResponseBody
    public PagingResult<ReleaseDeploymentSummary> getReleasesWithDeploymentStatuses(
            final ReleaseFilters releaseFilters,
            final ClientPagingFilter filter) {
        Stopwatch timer = Stopwatch.createStarted();
        PagingResult<ReleaseDefinition> releaseResults = getReleases(releaseFilters, filter);
        timer.stop();

        Stopwatch timer2 = Stopwatch.createStarted();
        PagingResult<ReleaseDeploymentSummary> result = new PagingResult<ReleaseDeploymentSummary>(
                releaseResults.getRequestFilter(),
                releaseResults.getTotalRecords(),
                environmentDeploymentSummaryBuilder.getEnvironmentDeploymentSummaries(releaseResults.getPageResults()));
        timer2.stop();

        LOG.info("Releases lookup timing {}, summaries lookup timing {}", timer, timer2);

        return result;
    }

    @RequestMapping(value = "/myteams", method = RequestMethod.GET)
    @ResponseBody
    public PagingResult<ReleaseDefinition> getMyTeamReleases(final ReleaseFilters releaseFilters,
            final ClientPagingFilter filter) {

        // TODO consider having the dao join between user and teams rather than two db hits.
        releaseFilters.setTeam(teamsService.getCurrentUserTeamNames());
        return getReleases(releaseFilters, filter);

    }

    /**
     * Retrieves a given release.
     * 
     * @param releaseId
     *            The release id
     * @param revision
     *            The revision of the release, if not specified the latest will be returned
     * @return
     */
    @RequestMapping(value = "/{releaseId}", method = RequestMethod.GET)
    public ReleaseDefinition getRelease(@PathVariable final Integer releaseId,
            @RequestParam(value = "revision", required = false) final Integer revision) {

        return getRelease(releaseId, revision, FULL_MAPPER);
    }

    /**
     * Retrieves a given release.
     * 
     * @param releaseId
     *            The release id
     * @param revision
     *            The revision of the release, if not specified the latest will be returned
     * @param asAtDate
     *            The release as it was on a given timestamp
     * @return
     */
    @RequestMapping(value = "/{releaseId}/revision/{timestamp}", method = RequestMethod.GET)
    @ResponseBody
    public Integer getReleaseRevision(@PathVariable final Integer releaseId, @PathVariable final Long timestamp) {
        return releaseDefinitionDao.getRevisionAtDate(releaseId, timestamp);
    }

    @RequestMapping(value = "/{releaseId}/summary", method = RequestMethod.GET)
    public ReleaseDefinition getReleaseSummary(
            @PathVariable final Integer releaseId,
            @RequestParam(value = "revision", required = false) final Integer revision) {

        return getRelease(releaseId, revision, SUMMARY_MAPPER);
    }

    private ReleaseDefinition getRelease(final Integer releaseId, final Integer revision,
            final Function<ReleaseDefinition, ReleaseDefinition> mapper) {
        ReleaseDefinition release;
        if (revision == null) {
            release = releaseDefinitionDao.load(releaseId);
        } else {
            release = releaseDefinitionDao.loadRevision(releaseId, revision);
        }

        return mapper.apply(release);
    }

    @RequestMapping(method = RequestMethod.POST)
    public ReleaseDefinition createRelease(@RequestBody final ReleaseDefinition releaseDefinition) {
        Preconditions.checkArgument(releaseDefinition.getId() == null, "Release id must not be specified for create");
        Preconditions.checkArgument(releaseDefinition.getCreatedBy() == null,
                "Created by must not be specified for create");

        validate(releaseDefinition);

        releaseDefinition.setCreatedBy(contextProvider.getCurrentUser());
        releaseDefinition.setLastUpdatedBy(contextProvider.getCurrentUser());
        if (!StringUtils.hasText(releaseDefinition.getDeploymentProcess())) {
            releaseDefinition.setDeploymentProcess(DeploymentProcess.RollingUpgrade.name());
        }

        releaseDefinitionDao.create(releaseDefinition);

        activityFeedWriter.createRelease(releaseDefinition);

        // release creator automatically watches for all events on release
        for (WatchType watch : WatchType.values()) {
            releaseWatchDao.addWatch(releaseDefinition, watch, contextProvider.getCurrentUser());
        }

        return initialise(releaseDefinition);
    }

    @RequestMapping(value = "/clone/{releaseId}", method = RequestMethod.POST)
    public ReleaseDefinition cloneRelease(@PathVariable final Integer releaseId,
            @RequestBody final ReleaseDefinition clone) {
        ReleaseDefinition original = releaseDefinitionDao.load(releaseId);
        if (clone.getTeam() == null) {
            clone.setTeam(original.getTeam());
        }
        clone.setDescription(original.getDescription());
        clone.setArtifacts(Lists.<Artifact>newArrayList(original.getArtifacts()));
        clone.setDeploymentProcess(original.getDeploymentProcess());
        clone.setDeploymentTemplate(original.getDeploymentTemplate());
        return createRelease(clone);
    }

    @RequestMapping(value = "/deploymentProcess/{releaseId}", method = RequestMethod.POST)
    public ReleaseDefinition updateDeploymentProcess(@PathVariable final Integer releaseId,
            @RequestBody final UpdateDeploymentProcessRequest request) {
        ReleaseDefinition release = releaseDefinitionDao.load(releaseId);

        checkUserCanModifyUnlockedRelease(release);

        release.setDeploymentProcess(request.getDeploymentProcess().name());
        if (request.getDeploymentProcess() == DeploymentProcess.Custom) {
            deploymentTemplateValidator.validate(request.getDeploymentTemplate().getAction());
            deploymentTemplateValidator.validate(release.getArtifacts(), request.getDeploymentTemplate());

            release.setDeploymentTemplate(JsonObjectMapper.getInstance().writeValueAsString(
                    request.getDeploymentTemplate()));
        }

        return initialise(release);
    }

    @RequestMapping(value = "/{releaseId}/artifact", method = RequestMethod.POST)
    public Artifact addArtifact(@PathVariable final Integer releaseId, @RequestBody final Artifact artifact) {

        ReleaseDefinition releaseDefinition = releaseDefinitionDao.load(releaseId);
        Artifact persistentArtifact = artifactDao.resolveOrCreatePersistentArtifact(artifact);
        releaseDefinition.getArtifacts().add(persistentArtifact);
        validate(releaseDefinition);
        activityFeedWriter.addReleaseArtifact(releaseDefinition, persistentArtifact);
        prefetchPropertyKeys(releaseDefinition, artifact);
        return persistentArtifact;

    }

    @RequestMapping(value = "/{releaseId}/artifact", method = RequestMethod.DELETE)
    public Artifact removeArtifact(@PathVariable final Integer releaseId, @RequestBody final Artifact artifact) {

        Artifact persistentArtifact = artifactDao.resolvePersistentArtifact(artifact);
        ReleaseDefinition releaseDefinition = releaseDefinitionDao.load(releaseId);
        releaseDefinition.getArtifacts().remove(persistentArtifact);
        validate(releaseDefinition);
        activityFeedWriter.removeReleaseArtifact(releaseDefinition, persistentArtifact);
        return persistentArtifact;

    }

    @RequestMapping(value = "/{releaseId}/artifact", method = RequestMethod.PUT)
    public Artifact changeArtifactVersion(@PathVariable final Integer releaseId, @RequestBody final Artifact artifact) {

        ReleaseDefinition releaseDefinition = releaseDefinitionDao.load(releaseId);
        List<Artifact> originalArtifacts = releaseDefinition.getArtifacts();
        NexusArtifact versionlessArtifact = artifact.getNexusArtifact();
        Artifact persistentArtifact = null;
        boolean found = false;
        for (Artifact oldVersion : originalArtifacts) {
            if (oldVersion.getNexusArtifact().equals(versionlessArtifact)) {
                originalArtifacts.remove(oldVersion);
                persistentArtifact = artifactDao.resolveOrCreatePersistentArtifact(artifact);
                originalArtifacts.add(persistentArtifact);
                prefetchPropertyKeys(releaseDefinition, persistentArtifact);
                activityFeedWriter.modifyReleaseArtifact(releaseDefinition, oldVersion, persistentArtifact);
                found = true;
                break;
            }
        }
        if (!found) {
            throw new EntityNotFoundException(versionlessArtifact + " is not part of release.");
        }

        validate(releaseDefinition);

        return persistentArtifact;
    }

    private Artifact switchVersion(final String organisation, final Artifact artifact, final SwitchTypes switchType,
            final String artifactType,
            final String version) {
        if (switchType == SwitchTypes.RELEASE && isSnapshot(artifact)) {
            return toReleaseVersion(artifact);
        } else if (switchType == SwitchTypes.SNAPSHOT
                && artifactConfigurationService.isArtifactType(organisation, artifact, artifactType)) {
            return toLatestSnapshotVersion(artifact);
        } else if (switchType == SwitchTypes.SPECIFIC
                && artifactConfigurationService.isArtifactType(organisation, artifact, artifactType)) {
            return toSpecificVersion(artifact, version);
        }
        return null;
    }

    private Artifact toReleaseVersion(final Artifact artifact) {
        String releaseVersion = artifact.getVersion().substring(0, artifact.getVersion().indexOf("-SNAPSHOT"));
        return new Artifact(artifact.getGroupId(), artifact.getArtifactId(), releaseVersion);
    }

    /**
     * Returns the latest snapshot version for an artifact. Note that latest is defined by the version number on the
     * artifact, not the time the artifact was built. If the artifact uses versioning which cannot be ordered (eg
     * master-SNAPSHOT, feature-a-SNAPSHOT), then the version is left as is.
     */
    private Artifact toLatestSnapshotVersion(final Artifact artifact) {
        if (isVersionNumberOrderable(artifact.getVersion())) {
            List<String> versions = nexusArtifactService.getSnapshotVersions(artifact.getGroupId(),
                    artifact.getArtifactId());
            if (CollectionUtils.isEmpty(versions)) {
                LOG.info("No snapshot for artifact {} to switch to.  Leaving untouched", artifact);
            } else {
                String snapshotVersion = versions.get(0);
                if (isVersionNumberOrderable(snapshotVersion)) {
                    return new Artifact(artifact.getGroupId(), artifact.getArtifactId(), snapshotVersion);
                }
            }
        }
        return null;
    }

    /**
     * Updates the artifact to the specified version if valid for that artifact
     */
    private Artifact toSpecificVersion(final Artifact artifact, final String version) {
        Optional<String> foundVersion = Iterables.tryFind(
                nexusArtifactService.getVersionsForArtifact(artifact.getNexusArtifact(), false),
                new Predicate<String>() {
                    @Override
                    public boolean apply(final String input) {
                        return version.equalsIgnoreCase(input);
                    }
                });

        if (foundVersion.isPresent()) {
            return new Artifact(artifact.getGroupId(), artifact.getArtifactId(), foundVersion.get());
        }
        return null;
    }

    private boolean isVersionNumberOrderable(final String version) {
        return VERSION_PATTERN.matcher(version).matches();
    }

    public enum SwitchTypes {
        RELEASE,
        SNAPSHOT,
        SPECIFIC;
    }

    @RequestMapping(value = "/{releaseId}/switchArtifacts/{switchType}", method = RequestMethod.PUT)
    public ReleaseDefinition bulkSwitchArtifacts(
            @PathVariable final Integer releaseId,
            @PathVariable final SwitchTypes switchType,
            @RequestParam(required = false) final String artifactType,
            @RequestParam(required = false) final String version) {

        ReleaseDefinition releaseDefinition = releaseDefinitionDao.load(releaseId);

        List<Artifact> artifactsAdded = Lists.<Artifact>newArrayList();
        List<Artifact> artifactsRemoved = Lists.<Artifact>newArrayList();

        String org = releaseDefinition.getTeam().getOrganisation().getName();

        ListIterator<Artifact> iterator = releaseDefinition.getArtifacts().listIterator();
        while (iterator.hasNext()) {
            Artifact artifact = iterator.next();
            Artifact newArtifact = switchVersion(org, artifact, switchType, artifactType, version);
            if (newArtifact != null) {
                newArtifact = artifactDao.resolveOrCreatePersistentArtifact(newArtifact);
                iterator.remove();
                iterator.add(newArtifact);
                prefetchPropertyKeys(releaseDefinition, newArtifact);
                artifactsRemoved.add(artifact);
                artifactsAdded.add(newArtifact);
            }
        }

        validate(releaseDefinition);

        activityFeedWriter.modifyReleaseArtifacts(releaseDefinition, artifactsRemoved, artifactsAdded);
        return initialise(releaseDefinition);
    }

    /**
     * Perform any validation checks related to this release (eg not correctly linked to RNOW) and warn the user so that
     * they can be fixed.
     * 
     * @return
     */
    @RequestMapping(value = "/{releaseId}/validate")
    public List<Warning> validateRelease(@PathVariable final Integer releaseId) {
        return productionDeploymentValidator.validateReleaseSetupForProductionDeployment(releaseDefinitionDao
                .load(releaseId));
    }

    @RequestMapping(value = "/{releaseId}/lock/{locked}", method = RequestMethod.PUT)
    public void lockRelease(@PathVariable final Integer releaseId, @PathVariable final Boolean locked) {
        ReleaseDefinition releaseDefinition = releaseDefinitionDao.load(releaseId);
        checkCanModifyRelease(releaseDefinition, RELEASE_LOCKDOWN_ROLE);
        releaseDefinition.setLocked(locked);
        activityFeedWriter.lockUnlockRelease(releaseDefinition, locked);
    }

    @RequestMapping(value = "/{releaseId}/history", method = RequestMethod.GET)
    public List<AuditEntry<ReleaseDefinition>> getReleaseHistory(@PathVariable final Integer releaseId,
            final ClientPagingFilter filter) {
        List<AuditEntry<ReleaseDefinition>> auditHistory = releaseDefinitionDao.getAuditHistory(releaseId,
                daoFilter(filter));
        return ProcessorUtil.transformAuditEntries(auditHistory, FULL_MAPPER);
    }

    @Cacheable(value = STATS_CACHE_KEY)
    @RequestMapping(value = "/stats/{organisation}", method = RequestMethod.GET)
    public List<DailyReleaseStats> getReleaseStats(@PathVariable final String organisation) {
        return releaseDefinitionDao.getDailyReleaseStats(organisation);
    }

    @RequestMapping(value = "/{releaseId}/details", method = RequestMethod.PUT)
    @ResponseBody
    public ReleaseDefinition updateReleaseDetails(
            @PathVariable final Integer releaseId,
            @RequestBody final ReleaseDefinition details) {
        ReleaseDefinition existing = releaseDefinitionDao.load(releaseId);

        if (details.getLastUpdatedTime() == null
                || existing.getLastUpdatedTime().getTime() != details.getLastUpdatedTime().getTime()) {
            throw new IllegalArgumentException(
                    "The release details you are viewing are old.  Please refresh to obtain the latest details");
        }
        // Don't call out to rnow until before the links have been validated.
        validateReleaseLinks(details);

        checkForUpdateToReleaseDateUsingRnowDetails(existing, details);

        activityFeedWriter.modifyReleaseDetails(existing, details);

        existing.setName(details.getName());
        existing.setReleaseDate(details.getReleaseDate());
        existing.setDescription(details.getDescription());

        List<ReleaseLink> linksToMerge = (details.getReleaseLinks() == null) ?
                Collections.<ReleaseLink>emptyList() : details.getReleaseLinks();
        for (ReleaseLink link : linksToMerge) {
            link.setReleaseDefinition(existing);
        }
        List<ReleaseLink> linksExisting = new ArrayList<ReleaseLink>(existing.getReleaseLinks());

        // remove links first
        for (ReleaseLink existingLink : linksExisting) {
            if (!linksToMerge.contains(existingLink)) {
                existing.getReleaseLinks().remove(existingLink);
                activityFeedWriter.removeReleaseLink(existing, existingLink);
            }
        }

        // add new links
        for (ReleaseLink newLink : linksToMerge) {
            if (!linksExisting.contains(newLink)) {
                existing.getReleaseLinks().add(newLink);
                activityFeedWriter.addReleaseLink(existing, newLink);
            }
        }

        validate(existing);

        return initialise(existing);
    }

    private void checkForUpdateToReleaseDateUsingRnowDetails(final ReleaseDefinition existing,
            final ReleaseDefinition details) {
        String existingChangeRequestId = extractChangeRequest(existing);
        String newChangeRequestId = extractChangeRequest(details);

        // If the release has a change request id which has changed or the release date has changed, double check the
        // date from now and use that.
        if (newChangeRequestId != null &&
                (!newChangeRequestId.equals(existingChangeRequestId) ||
                !Objects.equal(existing.getReleaseDate(), details.getReleaseDate()))) {
            LOG.debug("Change request id has changed to {}.  Checking if release date needs to be refresh",
                    newChangeRequestId);

            ChangeRequestDetails crDetails;
            try {
                crDetails = serviceNowClient.retrieveEssentialDetails(newChangeRequestId);
            } catch (SOAPFaultException ex) {// rnow up, but returned a fault.
                throw ex;
            } catch (WebServiceException ex) {
                LOG.error("Unable to verify release date in rnow", ex);
                return;
            }

            Interval crDeploymentInterval = new Interval(crDetails.getStartDate().getMillis(),
                    crDetails.getEndDate().getMillis());
            // if the current swift release date is not specified or outside range defined in rnow, then update.
            if (details.getReleaseDate() == null || !crDeploymentInterval.contains(details.getReleaseDate().getTime())) {
                // Use the start date on the change request
                Date swiftSuggestedReleaseDate = crDetails.getStartDate().toDate();

                LOG.info("Updating release date based on change request to {}", swiftSuggestedReleaseDate);
                details.setReleaseDate(swiftSuggestedReleaseDate);
            } else {
                LOG.debug("Date on release {} is within interval for change request {}.  Leaving unchanged",
                        details.getReleaseDate(), crDeploymentInterval);
            }
        }
    }

    @RequestMapping(value = "/{releaseId}/rollback/{environment}", method = RequestMethod.GET)
    public RollbackPrep rollback(
            @PathVariable final Integer releaseId,
            @PathVariable final String environment) {

        ReleaseDefinition releaseDefinition = releaseDefinitionDao.load(releaseId);
        return rollbackPrepBuilder.generateRollbackPrep(initialise(releaseDefinition), environment);

    }

    @RequestMapping(value = "/snow/status/{changeRequest}", method = RequestMethod.GET)
    @ResponseBody
    public String getChangeRequestStatus(@PathVariable final String changeRequest) {
        try {
            ChangeRequestDetails change = serviceNowClient.retrieveEssentialDetails(changeRequest);

            return change.getChangeStatus();
        } catch (WebServiceException ex) {
            LOG.info("Unable to obtain change request {} status", changeRequest, ex);
            return "Unavailable";
        }
    }

    /**
     * Expects the change request id to be within the release description.
     * 
     * @param releaseDefinition
     */
    public static String extractChangeRequest(final ReleaseDefinition releaseDefinition) {
        if (!CollectionUtils.isEmpty(releaseDefinition.getReleaseLinks())) {
            for (ReleaseLink link : releaseDefinition.getReleaseLinks()) {
                if (ReleaseLink.TYPE_RNOW.equals(link.getType())) {
                    return link.getPointer();
                }
            }
        }
        return null;
    }

    private void validate(final ReleaseDefinition releaseDefinition) {
        Assert.notNull(releaseDefinition.getTeam(), "Release must have a team");
        Assert.notNull(releaseDefinition.getTeam().getId(), "Release must have a team");
        Assert.hasText(releaseDefinition.getName(), "Release must have a name");

        // retrieve the persistent team so that the organisation is available for access right checks
        Team team = teamsService.loadTeam(releaseDefinition.getTeam().getId());
        releaseDefinition.setTeam(team);

        checkUserCanModifyUnlockedRelease(releaseDefinition);

        // Only validate the date if it is not sourced from rnow. If there is an rnow ticket, then leave rnow to
        // validate the release date.
        if (extractChangeRequest(releaseDefinition) == null) {
            validateReleaseDate(releaseDefinition.getReleaseDate());
        }

        Set<NexusArtifact> artifacts = new HashSet<NexusArtifact>();
        if (!CollectionUtils.isEmpty(releaseDefinition.getArtifacts())) {
            for (Artifact artifact : releaseDefinition.getArtifacts()) {
                if (!artifacts.add(artifact.getNexusArtifact())) {
                    throw new IllegalArgumentException("Release contains duplicate artifact: "
                            + artifact.getArtifactId());
                }
            }
        }

        validateReleaseLinks(releaseDefinition);
    }

    private void checkUserCanModifyUnlockedRelease(final ReleaseDefinition releaseDefinition) {
        if (releaseDefinition.isLocked()) {
            throw new ReleaseLockedException(releaseDefinition);
        }

        checkCanModifyRelease(releaseDefinition, MODIFY_RELEASE_ROLE);
    }

    private void validateReleaseLinks(final ReleaseDefinition releaseDefinition) {
        boolean hasRnowLink = false;
        Set<ReleaseLink> links = new HashSet<ReleaseLink>();
        if (!CollectionUtils.isEmpty(releaseDefinition.getReleaseLinks())) {
            for (ReleaseLink link : releaseDefinition.getReleaseLinks()) {
                if (ReleaseLink.TYPE_RNOW.equals(link.getType())) {
                    if (hasRnowLink) {
                        throw new IllegalArgumentException("Release may only be linked to a single RNOW change request");
                    }
                    hasRnowLink = true;
                }

                if (!links.add(link)) {
                    throw new IllegalArgumentException("Release contains duplicate link: "
                            + link.getPointer());
                }
            }
        }
    }

    private void validateReleaseDate(final Date releaseDate) {
        if (releaseDate != null) {
            DateTime now = new DateTime(clock.currentTimeMillis());

            Assert.isTrue(!releaseDate.before(now.toDateMidnight().toDate()),
                    "Release date must not be in the past");

            Assert.isTrue(!releaseDate.after(now.plusMonths(6).toDate()),
                    "Release date must not be more than 6 months in the future");
        }
    }

    private void checkCanModifyRelease(final ReleaseDefinition releaseDefinition, final String role) {
        authorisationController.checkAccess(releaseDefinition.getTeam().getOrganisation().getName(), role);
    }

    private void prefetchPropertyKeys(final ReleaseDefinition releaseDefinition, final Artifact artifact) {
        propertyKeysPrefetcher.prefetchPropertyKeys(releaseDefinition.getTeam().getOrganisation().getName(), artifact);
    }

    private ReleaseDefinition initialise(final ReleaseDefinition releaseDefinition) {
        return FULL_MAPPER.apply(releaseDefinition);
    }

    /**
     * Note that the summary mapper does not map the {@link ReleaseDefinition#getDescription()} as it is potentially
     * very large and is lazily loaded.
     */
    private static final Function<ReleaseDefinition, ReleaseDefinition> SUMMARY_MAPPER = new Function<ReleaseDefinition, ReleaseDefinition>() {
        @Override
        public ReleaseDefinition apply(final ReleaseDefinition input) {
            ReleaseDefinition result = new ReleaseDefinition();
            result.setId(input.getId());
            result.setName(input.getName());
            result.setReleaseDate(input.getReleaseDate());

            if (input.getTeam() != null) {
                Team team = new Team();
                team.setId(input.getTeam().getId());
                team.setName(input.getTeam().getName());
                team.setOrganisation(input.getTeam().getOrganisation());
                result.setTeam(team);
            }
            result.setCreatedBy(input.getCreatedBy());
            result.setCreatedTime(input.getCreatedTime());
            result.setDeploymentProcess(input.getDeploymentProcess());
            result.setLastUpdatedBy(input.getLastUpdatedBy());
            result.setLastUpdatedTime(input.getLastUpdatedTime());
            result.setLocked(input.isLocked());
            result.setLatestRevision(input.getLatestRevision());
            result.setRevision(input.getRevision());

            return result;
        }
    };

    // TODO The only reason this object is being cloned is to stop hibernate proxies from getting in the way
    // during serialisation. Consider improving.
    private final Function<ReleaseDefinition, ReleaseDefinition> FULL_MAPPER = new Function<ReleaseDefinition, ReleaseDefinition>() {
        @Override
        public ReleaseDefinition apply(final ReleaseDefinition input) {
            if (input == null) {
                return null;
            }
            ReleaseDefinition result = SUMMARY_MAPPER.apply(input);
            result.setDescription(input.getDescription());
            if (input.getArtifacts() != null) {
                // Enrich each artifact with the artifact type information.
                List<Artifact> enrichedArtifacts = transform(input.getArtifacts(), new Function<Artifact, Artifact>() {
                    @Override
                    public Artifact apply(final Artifact input) {
                        ArtifactType typeInfo = artifactTypeService.getArtifactType(input.getNexusArtifact());
                        return new ArtifactWithType(input, typeInfo);
                    }
                });
                result.setArtifacts(enrichedArtifacts);
            }
            if (input.getReleaseLinks() != null) {
                result.setReleaseLinks(new ArrayList<ReleaseLink>(input.getReleaseLinks()));
            }
            result.setDeploymentTemplate(input.getDeploymentTemplate());
            return result;
        }
    };

    @Required
    public void setReleaseDefinitionDao(final ReleaseDefinitionDao releaseDefinitionDao) {
        this.releaseDefinitionDao = releaseDefinitionDao;
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }

    @Required
    public void setArtifactDao(final ArtifactDao artifactDao) {
        this.artifactDao = artifactDao;
    }

    @Required
    public void setEnvironmentDeploymentSummaryBuilder(
            final EnvironmentDeploymentSummaryBuilder environmentDeploymentSummaryBuilder) {
        this.environmentDeploymentSummaryBuilder = environmentDeploymentSummaryBuilder;
    }

    @Required
    public void setRollbackPrepBuilder(final RollbackPrepBuilder rollbackPrepBuilder) {
        this.rollbackPrepBuilder = rollbackPrepBuilder;
    }

    @Required
    public void setOpContextProvider(final OperationContextProvider contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Required
    public void setActivityFeedWriter(final ActivityFeedWriter activityFeedWriter) {
        this.activityFeedWriter = activityFeedWriter;
    }

    @Required
    public void setNexusArtifactService(final NexusArtifactService nexusArtifactService) {
        this.nexusArtifactService = nexusArtifactService;
    }

    @Required
    public void setTeamsService(final TeamsService teamsService) {
        this.teamsService = teamsService;
    }

    @Required
    public void setPropertyKeysPrefetcher(final PropertyKeysPrefetcher propertyKeysPrefetcher) {
        this.propertyKeysPrefetcher = propertyKeysPrefetcher;
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

    @Required
    public void setServiceNowClient(final ServiceNowClient serviceNowClient) {
        this.serviceNowClient = serviceNowClient;
    }

    @Required
    public void setDeploymentTemplateValidator(final DeploymentTemplateValidator deploymentTemplateValidator) {
        this.deploymentTemplateValidator = deploymentTemplateValidator;
    }

    @Required
    public void setProductionDeploymentValidator(final ProductionDeploymentValidator productionDeploymentValidator) {
        this.productionDeploymentValidator = productionDeploymentValidator;
    }

    @Required
    public void setReleaseWatchDao(final ReleaseWatchDao releaseWatchDao) {
        this.releaseWatchDao = releaseWatchDao;
    }

    @Required
    public void setArtifactTypeService(final ArtifactTypeService artifactTypeService) {
        this.artifactTypeService = artifactTypeService;
    }

    @VisibleForTesting
    void setClock(final Clock clock) {
        this.clock = clock;
    }

}
