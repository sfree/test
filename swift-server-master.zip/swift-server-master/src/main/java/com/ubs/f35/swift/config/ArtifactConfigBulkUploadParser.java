package com.ubs.f35.swift.config;

import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.DeployTag;
import com.ubs.f35.swift.config.model.Tag;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.processor.ProcessorUtil;
import com.ubs.f35.swift.util.CSVUtil;

public class ArtifactConfigBulkUploadParser {
    private static final Logger LOG = LoggerFactory.getLogger(ArtifactConfigBulkUploadParser.class);

    private static final DateTimeFormatter TIME_FORMATTER = ISODateTimeFormat.dateTime();

    private static final List<String> EXPORTED_COLUMNS = Arrays.asList("groupId", "artifactId", "name", "environment",
            "artifactVersion", "script", "deployTags", "tags", "coldStandby", "lastUpdatedTime");
    private static final int BASE_FIELDS_COUNT = EXPORTED_COLUMNS.size();
    private static final String ARG_KEY_PREFIX = "args.";
    private static final String TAG_DELIMETER = ";";

    public List<ArtifactConfig> parse(final String organisation, final Reader bulkUpload) {
        List<String[]> parsedCsv = CSVUtil.readCSV(bulkUpload);

        List<ArtifactConfig> records = Lists.newArrayListWithCapacity(parsedCsv.size());
        String[] columns = parsedCsv.get(0);

        Map<String, Integer> columnIndex = Maps.newHashMap();
        for (int i = 0; i < columns.length; i++) {
            columnIndex.put(columns[i], i);
        }

        for (int row = 1; row < parsedCsv.size(); row++) {
            String[] rowData = parsedCsv.get(row);

            if (blankLine(rowData)) {
                continue;
            }

            try {
                records.add(parseRecord(organisation, rowData, columns, columnIndex));
            } catch (RuntimeException ex) {
                throw new IllegalArgumentException("Error on line " + (row + 1) + ": " + ex.getMessage(), ex);
            }
        }
        return records;
    }

    private ArtifactConfig parseRecord(final String organisation, final String[] rowData, final String[] columns,
            final Map<String, Integer> columnIndex) {
        String environment = rowData[columnIndex.get("environment")];

        ArtifactConfig config = new ArtifactConfig();
        config.setTags(new ArrayList<Tag>());
        config.setDeployTags(new ArrayList<DeployTag>());

        Map<String, String> scriptArgs = Maps.newHashMap();
        for (int col = 0; col < rowData.length && col < columns.length; col++) {
            String data = rowData[col];
            String column = columns[col];
            // extract the environment
            if ("groupId".equals(column)) {
                config.setGroupId(data);
            } else if ("artifactId".equals(column)) {
                config.setArtifactId(data);
            } else if ("name".equals(column)) {
                config.setName(data);
            } else if ("environment".equals(column)) {
                config.setEnvironment(env(organisation, data));
            } else if ("artifactVersion".equals(column)) {
                config.setArtifactVersion(data);
            } else if ("script".equals(column)) {
                config.setScript(data);
            } else if ("coldStandby".equals(column)) {
                config.setColdStandby(Boolean.parseBoolean(data));
            } else if (column.startsWith(ARG_KEY_PREFIX)) {
                String scriptArg = column.substring(ARG_KEY_PREFIX.length());
                if (StringUtils.hasText(data)) {
                    scriptArgs.put(scriptArg, data);
                }
            } else if ("deployTags".equals(column)) {
                for (String tag : data.split(TAG_DELIMETER)) {
                    if (StringUtils.hasText(tag)) {
                        config.getDeployTags().add(new DeployTag(env(organisation, environment), tag));
                    }
                }
            } else if ("tags".equals(column)) {
                for (String tag : data.split(TAG_DELIMETER)) {
                    if (StringUtils.hasText(tag)) {
                        config.getTags().add(new Tag(tag));
                    }
                }
            } else if ("lastUpdatedTime".equals(column)) {
                if (StringUtils.hasText(data)) {
                    DateTime date = TIME_FORMATTER.parseDateTime(data);
                    config.setLastUpdatedTime(new Date(date.getMillis()));
                }
            } else {
                LOG.debug("Unknown column {}", column);
            }
        }

        config.setScriptArgumentsMap(scriptArgs);

        return config;
    }

    private boolean blankLine(final String[] rowData) {
        return rowData.length == 1 && !StringUtils.hasText(rowData[0]);
    }

    public void exportRecords(final List<ArtifactConfig> records, final Writer output) {
        Set<String> scriptArgKeys = Sets.newLinkedHashSet();

        List<String> columns = Lists.newArrayList();
        columns.addAll(EXPORTED_COLUMNS);

        for (ArtifactConfig record : records) {
            scriptArgKeys.addAll(record.getScriptArgumentsMap().keySet());
        }

        List<String[]> csvData = Lists.newArrayList();

        for (String key : scriptArgKeys) {
            columns.add(ARG_KEY_PREFIX + key);
        }

        csvData.add(columns.toArray(new String[columns.size()]));

        for (ArtifactConfig record : records) {
            String[] fields = new String[scriptArgKeys.size() + BASE_FIELDS_COUNT];
            fields[0] = record.getGroupId();
            fields[1] = record.getArtifactId();
            fields[2] = record.getName();
            fields[3] = record.getEnvironment().getName();
            fields[4] = record.getArtifactVersion();
            fields[5] = record.getScript();
            fields[6] = join(record.getDeployTags(), new Function<DeployTag, String>() {
                @Override
                public String apply(final DeployTag input) {
                    return input.getTag();
                }
            });
            fields[7] = join(record.getTags(), new Function<Tag, String>() {
                @Override
                public String apply(final Tag input) {
                    return input.getTag();
                }
            });
            fields[8] = String.valueOf(record.isColdStandby());
            fields[9] = TIME_FORMATTER.print(record.getLastUpdatedTime().getTime());

            int scriptArgIndex = 0;
            for (String argKey : scriptArgKeys) {
                String data = record.getScriptArgumentsMap().get(argKey);
                fields[scriptArgIndex + BASE_FIELDS_COUNT] = data;

                scriptArgIndex++;
            }

            csvData.add(fields);
        }

        CSVUtil.writeCSV(csvData, output);
    }

    private static <T> String join(final List<T> fromList, final Function<T, String> function) {
        List<String> values = ProcessorUtil.transform(fromList, function);
        return StringUtils.collectionToDelimitedString(values, TAG_DELIMETER);
    }

    private Environment env(final String organisation, final String environment) {
        return new Environment(environment, organisation);
    }

}
