package com.ubs.f35.swift.deploy.glu;

public class DeploymentCancelledException extends RuntimeException {

}
