package com.ubs.f35.swift.document;

import java.util.Set;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.model.IndexEntry;
import com.ubs.f35.swift.model.IndexEntry.EntryType;

/**
 * Provides an organisation specific index for the status screen.
 * 
 * @author stephelu
 * 
 */
public class OrganisationIndex {
    private final HashMultimap<String, IndexEntry> orgIndex = HashMultimap.create();
    private final Set<IndexEntry> commonIndex = Sets.newHashSet();

    /**
     * Adds an index which only applies to the specific organisation.
     */
    void add(final Environment environment, final String entry, final EntryType type) {
        orgIndex.put(environment.getOrganisation().getName(), new IndexEntry(entry, type));
    }

    /**
     * Adds an index which applies to all organisations.
     */
    void add(final String entry, final EntryType type) {
        commonIndex.add(new IndexEntry(entry, type));
    }

    public Set<IndexEntry> getIndex(final String organisation) {
        return Sets.union(commonIndex, orgIndex.get(organisation));
    }
}
