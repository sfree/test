package com.ubs.f35.swift.dao.model;

import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.deploy.template.model.DeploymentTemplate;

/**
 * <ul>
 * <li>RollingUpgrade - all server artifacts are redeployed sequentially so that there is no outage (provided the
 * environment has multiple running processes). Client artifacts are redeployed in parallel as swift can't control which
 * host serves a client artifact to a client.</li>
 * <li>SequentialUpgrade - all artifacts are first undeployed in parallel, before being started again in parallel.
 * <li>
 * <li>Custom - The user has saved a custom {@link DeploymentTemplate} against the {@link ReleaseDefinition}.
 * <li>
 * </ul>
 * 
 * @author stephelu
 * 
 */
public enum DeploymentProcess {
    RollingUpgrade,
    SequentialUpgrade,
    Custom
}
