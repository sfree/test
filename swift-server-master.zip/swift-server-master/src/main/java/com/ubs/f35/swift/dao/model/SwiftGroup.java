package com.ubs.f35.swift.dao.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.google.common.base.Objects;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.config.model.Objects2;
import com.ubs.f35.swift.dao.NexusArtifact;

/**
 * A SwiftGroup is a collection of hosts and artifacts which can only be operated on if the user has the appropriate ARP
 * access right. The {@link #name} of the group matches the name of the group in ARP. Swift only provides the mapping of
 * what hosts / artifacts apply to the group. The assigning of members to groups, approvers and security administration
 * remains in the domain of ARP.
 * <p>
 * All groups must start with the prefix SWIFT. Eg, the group for Neo DEV CID (client identifying data) servers could be
 * called SWIFT-NEO-DEV-CID. Only users belonging to the group SWIFT-NEO-DEV-CID-ADMIN would be allowed to modify the
 * details of the group within swift.
 * <p>
 * Hosts must also be secured if they are to contain CID data. If only the artifacts were secured, a bad artifact could
 * be deployed to a CID host which exposed the logs and other details present on the host.
 * <p>
 * Note that this was originally introduced to entitle CID hosts and artifacts, but the concept should hopefully extend
 * to other requirements.
 * <p>
 * Each group may entitle the user to a particular set of {@link #permissions}. These permissions have been
 * intentionally mapped as a relationship (as opposed to properties on this object) so that additional permissions do
 * not require db schema changes.
 * 
 * TODO: update http://confluence.swissbank.com/display/neo/Swift+Security
 * 
 * @author stephelu
 * 
 */
@Entity
@Table(name = "groups")
@Audited
public class SwiftGroup {
    @Id
    private String name;

    @Version
    private Date lastUpdatedTime;

    @ElementCollection
    @CollectionTable(name = "group_permissions", joinColumns = @JoinColumn(name = "group_name"))
    @Column(name = "permission")
    private List<String> permissions;

    @ManyToMany(targetEntity = Environment.class)
    @JoinTable(name = "GROUP_ENVIRONMENT",
            joinColumns = { @JoinColumn(name = "group_name", referencedColumnName = "name") },
            inverseJoinColumns = { @JoinColumn(name = "environment_id", referencedColumnName = "id") })
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @AuditJoinTable(name = "GROUP_ENVIRONMENT_AUD")
    private List<Environment> environments;

    @ManyToMany(targetEntity = Host.class)
    @JoinTable(name = "GROUP_HOST",
            joinColumns = { @JoinColumn(name = "group_name", referencedColumnName = "name") },
            inverseJoinColumns = { @JoinColumn(name = "hostname", referencedColumnName = "hostname") })
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @AuditJoinTable(name = "GROUP_HOST_AUD")
    private List<Host> hosts;

    @ManyToMany(targetEntity = NexusArtifact.class, cascade = {})
    @JoinTable(name = "GROUP_ARTIFACT",
            joinColumns = { @JoinColumn(name = "group_name", referencedColumnName = "name") },
            inverseJoinColumns = { @JoinColumn(name = "artifact_group_id", referencedColumnName = "group_id"),
                    @JoinColumn(name = "artifact_artifact_id", referencedColumnName = "artifact_id") })
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @AuditJoinTable(name = "GROUP_ARTIFACT_AUD")
    private List<NexusArtifact> artifacts;

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public List<Environment> getEnvironments() {
        return environments;
    }

    public void setEnvironments(final List<Environment> environments) {
        this.environments = environments;
    }

    public List<Host> getHosts() {
        return hosts;
    }

    public void setHosts(final List<Host> hosts) {
        this.hosts = hosts;
    }

    public List<NexusArtifact> getArtifacts() {
        return artifacts;
    }

    public void setArtifacts(final List<NexusArtifact> artifacts) {
        this.artifacts = artifacts;
    }

    public Date getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    public void setLastUpdatedTime(final Date lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

    public List<String> getPermissions() {
        return permissions;
    }

    public void setPermissions(final List<String> permissions) {
        this.permissions = permissions;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, lastUpdatedTime, environments, hosts, artifacts, permissions);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof SwiftGroup) {
            SwiftGroup that = (SwiftGroup) object;
            return Objects2.equal(this.name, that.name)
                    && Objects2.equal(this.lastUpdatedTime, that.lastUpdatedTime)
                    && Objects2.equal(this.environments, that.environments)
                    && Objects2.equal(this.hosts, that.hosts)
                    && Objects2.equal(this.artifacts, that.artifacts)
                    && Objects2.equal(this.permissions, that.permissions);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("name", name)
                .add("lastUpdatedTime", lastUpdatedTime)
                .add("environments", environments)
                .add("hosts", hosts)
                .add("artifacts", artifacts)
                .add("permissions", permissions)
                .toString();
    }

}
