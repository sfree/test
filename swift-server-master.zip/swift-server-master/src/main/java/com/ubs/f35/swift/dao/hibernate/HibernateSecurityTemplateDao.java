package com.ubs.f35.swift.dao.hibernate;

import java.util.List;

import com.ubs.f35.swift.dao.SecurityTemplateDao;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.model.SecurityTemplate;

public class HibernateSecurityTemplateDao extends HibernateDaoSupport implements SecurityTemplateDao {

    @Override
    public void createOrUpdate(final SecurityTemplate template) {
        getSession().saveOrUpdate(template);
    }

    @Override
    public SecurityTemplate load(final String name) {
        return load(SecurityTemplate.class, name);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<String> getIds() {
        return getSession().createQuery("select name from SecurityTemplate").list();
    }

}
