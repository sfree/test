package com.ubs.f35.swift.environment.model.glu;

import java.util.Map;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;

public class EntryBuilder {
    public static Entry create(final String groupId, final String artifactId, final String version, final String name) {
        Map<String, String> projectParameters = ImmutableMap.of(
                "g", groupId,
                "a", artifactId,
                "v", version,
                "name", name);

        Map<String, Object> initParameters = Maps.newHashMap();
        initParameters.put("project", projectParameters);

        Entry entry = new Entry();
        entry.setInitParameters(initParameters);

        return entry;
    }
}