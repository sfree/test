package com.ubs.f35.swift.service;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.ubs.f35.swift.dao.OrganisationDao;
import com.ubs.f35.swift.dao.SwiftUserDao;
import com.ubs.f35.swift.dao.TeamDao;
import com.ubs.f35.swift.dao.model.Organisation;
import com.ubs.f35.swift.dao.model.SwiftUser;
import com.ubs.f35.swift.dao.model.Team;
import com.ubs.f35.swift.processor.TeamsProcessor;
import com.ubs.f35.swift.state.OperationContextProvider;

@ManagedResource
public class SwiftTeamsService implements TeamsService {

    private static final Logger LOG = LoggerFactory.getLogger(SwiftTeamsService.class);

    private OperationContextProvider opContextProvider;
    private SwiftUserDao userDao;
    private TeamDao teamDao;
    private OrganisationDao organisationDao;

    @Override
    public Team loadTeam(final Integer id) {
        return teamDao.load(id);
    }

    @Override
    public List<Team> getAllTeams(final String organisation) {
        return teamDao.loadAll(organisation);
    }

    @Override
    public List<Team> getCurrentUserTeams(final String organisation) {
        // Don't modify the persistent collection, clone first.
        List<Team> userTeams = Lists.newArrayList(getUserTeams(opContextProvider.getCurrentUser()));
        if (organisation != null) {
            userTeams.retainAll(getAllTeams(organisation));
        }
        return userTeams;
    }

    @Override
    public List<String> getCurrentUserTeamNames() {
        return teamNames(getCurrentUserTeams(null));
    }

    @Override
    public List<Team> getUserTeams(final String userGuid) {
        SwiftUser user = userDao.load(userGuid);
        if (user == null) {
            return Collections.emptyList();
        }
        return user.getTeams();
    }

    @Override
    public void saveCurrentUserTeams(final Integer[] teams) {
        String userId = opContextProvider.getCurrentUser();

        SwiftUser user = userDao.loadOrCreate(userId);

        user.getTeams().clear();
        for (Integer teamId : teams) {
            Team team = teamDao.load(teamId);
            user.getTeams().add(team);
        }
    }

    @ManagedOperationParameters(value = {
            @ManagedOperationParameter(name = "organisationName", description = "The organisation the team will belong to"),
            @ManagedOperationParameter(name = "teamName", description = "The name of the team") })
    @Transactional
    @Override
    public void registerTeam(final String organisationName, final String teamName) {
        Organisation organisation = organisationDao.load(organisationName);

        Team team = new Team();
        team.setOrganisation(organisation);
        team.setName(teamName);
        teamDao.create(team);
    }

    private List<String> teamNames(final List<Team> teams) {
        return Lists.transform(teams, TeamsProcessor.TEAM_NAME_FUNCTION);
    }

    @Required
    public void setOpContextProvider(final OperationContextProvider opContextProvider) {
        this.opContextProvider = opContextProvider;
    }

    @Required
    public void setUserDao(final SwiftUserDao userDao) {
        this.userDao = userDao;
    }

    @Required
    public void setTeamDao(final TeamDao teamDao) {
        this.teamDao = teamDao;
    }

    @Required
    public void setOrganisationDao(final OrganisationDao organisationDao) {
        this.organisationDao = organisationDao;
    }

}
