package com.ubs.f35.swift.deploy.validator;

import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlanBuilder;

public interface ReleaseDeploymentPlanValidator {
    void validate(DeploymentPlanBuilder builder, ReleaseDefinition releaseDefinition, Environment environment,
            boolean rollback);
}
