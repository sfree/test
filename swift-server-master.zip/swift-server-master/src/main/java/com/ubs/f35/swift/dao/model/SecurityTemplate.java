package com.ubs.f35.swift.dao.model;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import com.google.common.base.Objects;

@Entity
@Table(name = "security_template")
@Audited
public class SecurityTemplate {
    @Id
    private String name;
    // server fields
    @Lob
    private byte[] keystore;
    private String keystorePassword;
    private String keyPassword;

    @Lob
    private byte[] truststore;
    private String truststorePassword;

    // agent fields
    @Lob
    private byte[] agentKeystore;
    private String agentKeystoreChecksum;
    private String agentKeystorePassword;
    private String agentKeyPassword;

    @Lob
    private byte[] agentTruststore;
    private String agentTruststoreChecksum;
    private String agentTruststorePassword;

    public SecurityTemplate() {
    }

    public SecurityTemplate(final String name,
            final byte[] keystore, final String keystorePassword, final String keyPassword,
            final byte[] truststore, final String truststorePassword,
            final byte[] agentKeystore, final String agentKeystoreChecksum, final String agentKeystorePassword,
            final String agentKeyPassword,
            final byte[] agentTruststore, final String agentTruststoreChecksum, final String agentTruststorePassword) {
        this.name = name;
        this.keystore = keystore;
        this.keystorePassword = keystorePassword;
        this.keyPassword = keyPassword;
        this.truststore = truststore;
        this.truststorePassword = truststorePassword;
        this.agentKeystore = agentKeystore;
        this.agentKeystoreChecksum = agentKeystoreChecksum;
        this.agentKeystorePassword = agentKeystorePassword;
        this.agentKeyPassword = agentKeyPassword;
        this.agentTruststore = agentTruststore;
        this.agentTruststoreChecksum = agentTruststoreChecksum;
        this.agentTruststorePassword = agentTruststorePassword;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getKeystorePassword() {
        return keystorePassword;
    }

    public void setKeystorePassword(final String keystorePassword) {
        this.keystorePassword = keystorePassword;
    }

    public String getKeyPassword() {
        return keyPassword;
    }

    public void setKeyPassword(final String keyPassword) {
        this.keyPassword = keyPassword;
    }

    public String getTruststorePassword() {
        return truststorePassword;
    }

    public void setTruststorePassword(final String truststorePassword) {
        this.truststorePassword = truststorePassword;
    }

    public byte[] getKeystore() {
        return keystore;
    }

    public void setKeystore(final byte[] keystore) {
        this.keystore = keystore;
    }

    public byte[] getTruststore() {
        return truststore;
    }

    public void setTruststore(final byte[] truststore) {
        this.truststore = truststore;
    }

    public byte[] getAgentKeystore() {
        return agentKeystore;
    }

    public void setAgentKeystore(final byte[] agentKeystore) {
        this.agentKeystore = agentKeystore;
    }

    public String getAgentKeystoreChecksum() {
        return agentKeystoreChecksum;
    }

    public void setAgentKeystoreChecksum(final String agentKeystoreChecksum) {
        this.agentKeystoreChecksum = agentKeystoreChecksum;
    }

    public String getAgentKeystorePassword() {
        return agentKeystorePassword;
    }

    public void setAgentKeystorePassword(final String agentKeystorePassword) {
        this.agentKeystorePassword = agentKeystorePassword;
    }

    public String getAgentKeyPassword() {
        return agentKeyPassword;
    }

    public void setAgentKeyPassword(final String agentKeyPassword) {
        this.agentKeyPassword = agentKeyPassword;
    }

    public byte[] getAgentTruststore() {
        return agentTruststore;
    }

    public void setAgentTruststore(final byte[] agentTruststore) {
        this.agentTruststore = agentTruststore;
    }

    public String getAgentTruststoreChecksum() {
        return agentTruststoreChecksum;
    }

    public void setAgentTruststoreChecksum(final String agentTruststoreChecksum) {
        this.agentTruststoreChecksum = agentTruststoreChecksum;
    }

    public String getAgentTruststorePassword() {
        return agentTruststorePassword;
    }

    public void setAgentTruststorePassword(final String agentTruststorePassword) {
        this.agentTruststorePassword = agentTruststorePassword;
    }

    @Override
    public String toString() {
        // Only log the name. The other information should not display in the logs.
        return Objects.toStringHelper(this)
                .add("name", name)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof SecurityTemplate) {
            SecurityTemplate that = (SecurityTemplate) object;
            return Objects.equal(this.name, that.name)
                    && Arrays.equals(this.keystore, that.keystore)
                    && Objects.equal(this.keystorePassword, that.keystorePassword)
                    && Objects.equal(this.keyPassword, that.keyPassword)
                    && Arrays.equals(this.truststore, that.truststore)
                    && Objects.equal(this.truststorePassword, that.truststorePassword)
                    && Arrays.equals(this.agentKeystore, that.agentKeystore)
                    && Objects.equal(this.agentKeystoreChecksum, that.agentKeystoreChecksum)
                    && Objects.equal(this.agentKeystorePassword, that.agentKeystorePassword)
                    && Objects.equal(this.agentKeyPassword, that.agentKeyPassword)
                    && Arrays.equals(this.agentTruststore, that.agentTruststore)
                    && Objects.equal(this.agentTruststoreChecksum, that.agentTruststoreChecksum)
                    && Objects.equal(this.agentTruststorePassword, that.agentTruststorePassword);
        }
        return false;
    }

}
