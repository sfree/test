package com.ubs.f35.swift.properties;

import java.util.Set;

import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.properties.model.PropertyKey;

/**
 * Obtain the set of property keys expected by an artifact.
 * 
 * @author levyjo
 * 
 */
public interface PropertyKeysProvider {

    Set<PropertyKey> getPropertyKeys(String organisation, Artifact artifact);

}
