package com.ubs.f35.core.zookeeper.client;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import org.apache.zookeeper.data.Stat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.ubs.f35.core.zookeeper.client.ZNode.ZNodeType;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient.DataAndStat;
import com.ubs.f35.core.zookeeper.client.config.api.ZooKeeperConfigService;
import com.ubs.f35.swift.executors.SwiftExecutors;
import com.ubs.f35.swift.util.ExecutorUtils;

/**
 * Swift customisations to ZooKeeperService
 * <p>
 * <ol>
 * <li>When walking the zookeeper tree, limit to 1 call per child node (was previously 3 calls). Each call is over the
 * wire and expensive.
 * <li>For swift, which manages remote zookeeper clusters, the latency involved in retrieving each node can be huge. The
 * walk algorithms has been updated to explore each level of the tree in parallel. Further optimisations are possible if
 * we ignore the {@link TraversalType} and just process in whatever order is fastest.
 * <p>
 * If these improvements are stable, can contribute back. But for now wanted to release quickly with no risk of other
 * projects outside of swift picking up these changes.
 */
public class SwiftZooKeeperConfigService extends ZooKeeperConfigService {

    private static final Logger logger = LoggerFactory.getLogger(SwiftZooKeeperConfigService.class);

    private final ExecutorService executor = SwiftExecutors.getZookeeperPropertiesWalkExecutor();

    public SwiftZooKeeperConfigService(final ZooKeeperClient zkc) {
        super(zkc);
    }

    /**
     * Walk algorithm with collection of ZNodeProcessor.
     */
    @Override
    protected void doWalk(final String rootPath, final Collection<ZNodeProcessor> processors, Deque<DefaultZNode> deck,
            final TraversalType traversalType) throws Exception {

        if (deck != null) {
            throw new IllegalArgumentException(
                    "deck must be null as swift implementation is multithreaded and base implementations use an ArrayDeque which is not thread safe");
        }

        if (!clientValidated()) {
            return;
        }

        DataAndStat rootData = zkc.getDataAndStat(rootPath);

        /*
         * handle missing root
         */
        if (rootData == null || rootData.stat == null) {
            return;
        }

        /*
         * handle root being leaf (has no children)
         */
        if (rootData.stat.getNumChildren() == 0) {
            for (ZNodeProcessor processor : processors) {
                processor.process(new DefaultZNode(rootPath, getType(rootData.stat), 0, true, rootData.data));
            }
            return;
        }

        deck = new ConcurrentLinkedDeque<>();

        /*
         * handle root being branch (has children)
         */
        DefaultZNode rootNode = new DefaultZNode(rootPath, getType(rootData.stat), 0, false, rootData.data);
        addToDeck(deck, traversalType, rootNode);

        while (!deck.isEmpty()) {

            List<DefaultZNode> toProcess = Lists.newArrayList();
            DefaultZNode backlogNode;
            while ((backlogNode = deck.pollFirst()) != null) {
                toProcess.add(backlogNode);
            }

            logger.info("Walk batch size {}", toProcess.size());

            List<ExploreChildrenCallable> tasks = new ArrayList<>(toProcess.size());

            for (DefaultZNode currentNode : toProcess) {
                tasks.add(new ExploreChildrenCallable(currentNode, deck, traversalType));
            }

            ExecutorUtils.invokeAllAndPropagateFirstException(executor, tasks);

            for (DefaultZNode currentNode : toProcess) {
                for (ZNodeProcessor processor : processors) {
                    processor.process(currentNode);
                }
            }
        }
    }

    private class ExploreChildrenCallable implements Callable<Void> {

        private final DefaultZNode currentNode;
        private final Deque<DefaultZNode> deck;
        private final TraversalType traversalType;

        public ExploreChildrenCallable(final DefaultZNode currentNode, final Deque<DefaultZNode> deck,
                final TraversalType traversalType) {
            this.currentNode = currentNode;
            this.deck = deck;
            this.traversalType = traversalType;
        }

        @Override
        public Void call() throws Exception {
            List<String> childNodes = zkc.getChildren(currentNode.path);
            currentNode.children = new ArrayList<ZNode>(childNodes.size());

            if (!childNodes.isEmpty()) {
                logger.info("Number of children {}", childNodes.size());
                List<LoadChildCallable> tasks = new ArrayList<>(childNodes.size());
                for (String child : childNodes) {
                    tasks.add(new LoadChildCallable(currentNode, child));
                }

                List<Future<DefaultZNode>> results = ExecutorUtils.invokeAllAndPropagateFirstException(executor, tasks);

                for (Future<DefaultZNode> result : results) {
                    DefaultZNode childNode = result.get();

                    currentNode.children.add(childNode);
                    addToDeck(deck, traversalType, childNode);
                }
            }
            return null;
        }

    }

    private class LoadChildCallable implements Callable<DefaultZNode> {
        private final DefaultZNode currentNode;
        private final String child;

        public LoadChildCallable(final DefaultZNode currentNode, final String child) {
            this.currentNode = currentNode;
            this.child = child;
        }

        @Override
        public DefaultZNode call() throws Exception {
            return loadChild(currentNode, child);
        }
    }

    private void addToDeck(final Deque<DefaultZNode> deck, final TraversalType traversalType,
            final DefaultZNode rootNode) {
        if (traversalType == TraversalType.DEPTH_FIRST) {
            deck.addFirst(rootNode);
        } else {
            deck.addLast(rootNode);
        }
    }

    /*
     * TODO: Please move everything under here to one or more new classes.
     */

    private ZNodeType getType(final Stat stat) {
        return (stat.getEphemeralOwner() == 0) ? ZNodeType.PERSISTENT : ZNodeType.EPHEMERAL;
    }

    private boolean clientValidated() {

        if (!zkc.isEnabled()) {
            logger.info("zookeeper client is disabled");
            return false;
        }

        if (!zkc.isAlive()) {
            logger.warn("zookeeper client is dead");
            throw new IllegalStateException("zk client dead");
        }

        return true;
    }
}