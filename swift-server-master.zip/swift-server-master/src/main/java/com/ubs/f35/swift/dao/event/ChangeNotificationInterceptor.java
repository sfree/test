package com.ubs.f35.swift.dao.event;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import org.hibernate.EmptyInterceptor;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.type.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionOperations;
import org.springframework.util.CollectionUtils;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Predicates;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.config.model.ArtifactCommonConfig;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.DeployTag;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.config.model.Tag;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.Organisation;
import com.ubs.f35.swift.dao.model.SecurityTemplate;
import com.ubs.f35.swift.executors.SwiftExecutors;
import com.ubs.f35.swift.state.OperationContextProvider;

/**
 * Listens to hibernate changes so that when swift environment configuration is changed. Hibernate supports per session
 * interceptors (Session, but unfortunately the spring wrappers around hibernate do not. Therefore this must be thread
 * safe and all data is stored in {@link ThreadLocal}
 * 
 * @author stephelu
 */
public class ChangeNotificationInterceptor extends EmptyInterceptor implements BeanFactoryAware,
        ApplicationListener<ContextRefreshedEvent> {
    private static final Logger LOG = LoggerFactory.getLogger(ChangeNotificationInterceptor.class);

    private Executor executor = Executors.newSingleThreadExecutor(SwiftExecutors.namedThreadFactory(
            "ChangeNotificationInterceptor", true));

    private OperationContextProvider contextProvider;
    private BeanFactory beanFactory;
    private String transactionTemplateBean;
    private String sessionFactoryBean;
    private TransactionOperations transactionTemplate;
    private SessionFactory sessionFactory;

    private final List<ArtifactConfigurationChangeListener> artifactConfigurationChangeListeners = new ArrayList<>();
    private final List<HostChangeListener> hostChangeListeners = new ArrayList<>();
    private final List<ArtifactCommonConfigurationChangeListener> artifactCommonConfigurationChangeListeners = new ArrayList<>();
    private final List<OrganisationChangeListener> organisationChangeListeners = new ArrayList<>();
    private final List<EnvironmentChangeListener> environmentChangeListeners = new ArrayList<>();
    private final List<SecurityTemplateChangeListener> securityTemplateChangeListeners = new ArrayList<>();
    private final List<ReleaseChangeListener> releaseChangeListeners = new ArrayList<>();

    private List<String> artifactConfigurationChangeListenerBeans;
    private List<String> hostChangeListenerBeans;
    private List<String> artifactCommonConfigurationChangeListenerBeans;
    private List<String> organisationChangeListenerBeans;
    private List<String> environmentChangeListenerBeans;
    private List<String> securityTemplateChangeListenerBeans;
    private List<String> releaseChangeListenerBeans;

    private final ThreadLocal<List<Object>> updatesLocal = new ThreadLocal<List<Object>>();

    @Override
    public boolean onSave(final Object entity, final Serializable id, final Object[] state,
            final String[] propertyNames, final Type[] types) {

        rememberUpdates(entity);

        // not intercepting this event, just monitoring
        return false;
    }

    @Override
    public boolean onFlushDirty(final Object entity, final Serializable id, final Object[] currentState,
            final Object[] previousState,
            final String[] propertyNames, final Type[] types) {

        rememberUpdates(entity);
        notifyArtifactCommonConfigChangeListeners(entity);

        return updateLastUpdatedBy(entity, currentState, propertyNames);
    }

    @Override
    public void onDelete(final Object entity, final Serializable id, final Object[] state,
            final String[] propertyNames, final Type[] types) {
        if (entity instanceof ArtifactConfig) {
            // Deletes need to be remembered for ArtifactConfig.
            rememberUpdates(entity);
        }
    }

    /**
     * Notify interested listeners of the change.
     */
    @Override
    public void afterTransactionCompletion(final Transaction tx) {
        try {
            if (!CollectionUtils.isEmpty(artifactConfigurationChangeListeners)) {
                if (tx.wasCommitted()) {
                    if (updatesLocal.get() != null) {
                        LOG.debug("Notifying of changes to entities after transaction commit");
                        // Process the updates on a background thread. There is no need to make the user wait while the
                        // listeners fire. In addition to this, the listener may need to access hibernate which is not
                        // permitted here.
                        executor.execute(new SendUpdatesTask(updatesLocal.get()));
                    }
                }
                else {
                    LOG.trace("Not notifying of changes as transaction did not commit.");
                }
            }
        } finally {
            updatesLocal.set(null);
        }
    }

    private void rememberUpdates(final Object entity) {
        if (entity instanceof ArtifactConfig || entity instanceof Host || entity instanceof Organisation
                || entity instanceof Environment || entity instanceof SecurityTemplate
                || entity instanceof ReleaseDefinition) {
            List<Object> updates = updatesLocal.get();
            if (updates == null) {
                updates = Lists.newLinkedList();
                updatesLocal.set(updates);
            }
            LOG.debug("Entity updated");
            updates.add(entity);
        }
    }

    private void notifyArtifactCommonConfigChangeListeners(final Object entity) {
        // Note: we only really care about the propertyTemplates field having changed.
        // We could compare the entity with the previousState, to check if this filed has actually changed,
        // but only if we used session.merge() instead of session.saveOrUpdate() to save ArtifactCommonConfig.
        // However using session.merge() resulted on lots of unnecessary exceptions on the client caused
        // by the optimistic locking.
        if (entity instanceof ArtifactCommonConfig) {
            for (ArtifactCommonConfigurationChangeListener listener : artifactCommonConfigurationChangeListeners) {
                try {
                    listener.afterUpdate((ArtifactCommonConfig) entity);
                } catch (Exception ex) {
                    LOG.error("Exception calling ArtifactCommonConfigurationChangeListener", ex);
                }
            }
        }
    }

    private boolean updateLastUpdatedBy(final Object entity, final Object[] currentState, final String[] propertyNames) {
        if (entity instanceof ReleaseDefinition) {
            int index = Iterators.indexOf(Iterators.forArray(propertyNames), Predicates.equalTo("lastUpdatedBy"));
            currentState[index] = contextProvider.getCurrentUser();
            return true;
        }
        return false;
    }

    @Override
    /**
     * Manually inject listener beans after the rest of the application context has loaded. 
     * Cannot inject during main Spring wire-up due to circular dependencies.
     */
    public void onApplicationEvent(final ContextRefreshedEvent event) {
        transactionTemplate = beanFactory.getBean(transactionTemplateBean, TransactionOperations.class);
        sessionFactory = beanFactory.getBean(sessionFactoryBean, SessionFactory.class);

        initListenerBeans(artifactConfigurationChangeListeners, artifactConfigurationChangeListenerBeans,
                ArtifactConfigurationChangeListener.class);
        initListenerBeans(hostChangeListeners, hostChangeListenerBeans, HostChangeListener.class);
        initListenerBeans(artifactCommonConfigurationChangeListeners, artifactCommonConfigurationChangeListenerBeans,
                ArtifactCommonConfigurationChangeListener.class);
        initListenerBeans(organisationChangeListeners, organisationChangeListenerBeans,
                OrganisationChangeListener.class);
        initListenerBeans(environmentChangeListeners, environmentChangeListenerBeans, EnvironmentChangeListener.class);
        initListenerBeans(securityTemplateChangeListeners, securityTemplateChangeListenerBeans,
                SecurityTemplateChangeListener.class);
    }

    private <T> void initListenerBeans(final List<T> listeners, final List<String> beanNames, final Class<T> beanClass) {
        if (listeners.isEmpty()) {
            for (String bean : beanNames) {
                listeners.add(beanFactory.getBean(bean, beanClass));
            }
        }
        if (releaseChangeListeners.isEmpty()) {
            for (String bean : releaseChangeListenerBeans) {
                releaseChangeListeners.add(beanFactory.getBean(bean, ReleaseChangeListener.class));
            }
        }
    }

    @Override
    public void setBeanFactory(final BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }

    private class SendUpdatesTask implements Runnable {

        private final List<Object> updates;

        public SendUpdatesTask(final List<Object> updates) {
            this.updates = updates;
        }

        @Override
        public void run() {

            for (final Object update : updates) {
                if (update instanceof ArtifactConfig) {
                    // reload the persistent ArtifactConfig to ensure the db version is published. Some fields are
                    // immutable and the java model may have the incorrect value.
                    transactionTemplate.execute(new TransactionCallback<Void>() {
                        @Override
                        public Void doInTransaction(final TransactionStatus status) {
                            ArtifactConfig notificationConfig = (ArtifactConfig) sessionFactory.getCurrentSession()
                                    .get(ArtifactConfig.class, (ArtifactConfig) update);
                            if (notificationConfig == null) {
                                // If the operation was a delete, just pass the update which was handled, but make it no
                                // longer deployed.
                                notificationConfig = (ArtifactConfig) update;
                                // A delete of artifact config is effectively the same as not deploying it anywhere.
                                // Remove all deploy tags and provide an update
                                notificationConfig.setDeployTags(Collections.<DeployTag>emptyList());
                                // Clear the collection of tags. Else if any code later on attempts to traverse this
                                // relationship, it will
                                // fail because hibernate has already deleted the ArtifactConfig
                                notificationConfig.setTags(Collections.<Tag>emptyList());
                            }

                            for (ArtifactConfigurationChangeListener listener : artifactConfigurationChangeListeners) {
                                try {
                                    listener.afterUpdate(notificationConfig);
                                } catch (Exception ex) {
                                    LOG.error("Exception calling ArtifactConfigurationChangeListener", ex);
                                }
                            }

                            return null;
                        }
                    });
                } else if (update instanceof Host) {
                    for (HostChangeListener listener : hostChangeListeners) {
                        try {
                            listener.afterUpdate((Host) update);
                        } catch (Exception ex) {
                            LOG.error("Exception calling HostChangeListener", ex);
                        }
                    }
                } else if (update instanceof Organisation) {
                    for (OrganisationChangeListener listener : organisationChangeListeners) {
                        try {
                            listener.afterUpdate((Organisation) update);
                        } catch (Exception ex) {
                            LOG.error("Exception calling OrganisationChangeListener", ex);
                        }
                    }
                } else if (update instanceof Environment) {
                    for (EnvironmentChangeListener listener : environmentChangeListeners) {
                        try {
                            listener.afterUpdate((Environment) update);
                        } catch (Exception ex) {
                            LOG.error("Exception calling EnvironmentChangeListener", ex);
                        }
                    }
                } else if (update instanceof SecurityTemplate) {
                    for (SecurityTemplateChangeListener listener : securityTemplateChangeListeners) {
                        try {
                            listener.afterUpdate((SecurityTemplate) update);
                        } catch (Exception ex) {
                            LOG.error("Exception calling SecurityTemplateChangeListener", ex);
                        }
                    }
                } else if (update instanceof ReleaseDefinition) {
                    for (ReleaseChangeListener listener : releaseChangeListeners) {
                        try {
                            listener.afterUpdate((ReleaseDefinition) update);
                        } catch (Exception ex) {
                            LOG.error("Exception calling ReleaseChangeListener", ex);
                        }
                    }
                }
            }
        }

    }

    @Required
    public void setContextProvider(final OperationContextProvider contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Required
    public void setTransactionTemplateBean(final String transactionTemplateBean) {
        this.transactionTemplateBean = transactionTemplateBean;
    }

    @Required
    public void setSessionFactoryBean(final String sessionFactoryBean) {
        this.sessionFactoryBean = sessionFactoryBean;
    }

    @Required
    public void setArtifactCommonConfigurationChangeListenerBeans(
            final List<String> artifactCommonConfigurationChangeListeners) {
        this.artifactCommonConfigurationChangeListenerBeans = artifactCommonConfigurationChangeListeners;
    }

    @Required
    public void setArtifactConfigurationChangeListenerBeans(final List<String> artifactConfigurationChangeListeners) {
        this.artifactConfigurationChangeListenerBeans = artifactConfigurationChangeListeners;
    }

    @Required
    public void setHostChangeListenerBeans(final List<String> hostChangeListeners) {
        this.hostChangeListenerBeans = hostChangeListeners;
    }

    @Required
    public void setOrganisationChangeListenerBeans(final List<String> organisationChangeListenerBeans) {
        this.organisationChangeListenerBeans = organisationChangeListenerBeans;
    }

    @Required
    public void setEnvironmentChangeListenerBeans(final List<String> environmentChangeListenerBeans) {
        this.environmentChangeListenerBeans = environmentChangeListenerBeans;
    }

    @Required
    public void setSecurityTemplateChangeListenerBeans(final List<String> securityTemplateChangeListenerBeans) {
        this.securityTemplateChangeListenerBeans = securityTemplateChangeListenerBeans;
    }

    @Required
    public void setReleaseChangeListenerBeans(final List<String> releaseChangeListenerBeans) {
        this.releaseChangeListenerBeans = releaseChangeListenerBeans;
    }

    @VisibleForTesting
    void setExecutor(final Executor executor) {
        this.executor = executor;
    }
}