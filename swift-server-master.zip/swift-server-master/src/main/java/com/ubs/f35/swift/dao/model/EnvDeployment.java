package com.ubs.f35.swift.dao.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;

@Entity
@Table(name = "ENV_DEPLOYMENT")
public class EnvDeployment implements Serializable {
    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    private Deployment deployment;
    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    private Environment environment;

    // Each environment has a deployment status which is separate to the overall status. Ie, deployment to this
    // environment could succeed while deployment to another fails, resulting in an overall status of failed at the
    // deployment level.
    @Column(name = "DEPLOYSTATUS")
    @Enumerated(EnumType.STRING)
    private DeploymentStatus deploymentStatus;

    // Rollback artifacts are rarely used, so lazy fetching is fine.
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "DEPLOYMENT_ROLLBACK_ARTIFACTS",
            joinColumns = { @JoinColumn(name = "DEPLOYMENT_ID", referencedColumnName = "DEPLOYMENT_ID"),
                    @JoinColumn(name = "ENVIRONMENT_ID", referencedColumnName = "ENVIRONMENT_ID") },
            inverseJoinColumns = { @JoinColumn(name = "ARTIFACT_ID") })
    private List<Artifact> rollbackVersions;

    // A list of artifacts which were deployed / affected by deployment to this environment.
    @JsonIgnore
    @OneToMany(mappedBy = "envDeployment", cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
    private List<DeployedArtifact> deployedArtifacts;

    public EnvDeployment() {

    }

    public EnvDeployment(final Deployment deployment, final Environment environment,
            final DeploymentStatus deploymentStatus) {
        this.deployment = deployment;
        this.environment = environment;
        this.deploymentStatus = deploymentStatus;
    }

    public Deployment getDeployment() {
        return deployment;
    }

    public void setDeployment(final Deployment deployment) {
        this.deployment = deployment;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }

    public DeploymentStatus getDeploymentStatus() {
        return deploymentStatus;
    }

    public void setDeploymentStatus(final DeploymentStatus deploymentStatus) {
        this.deploymentStatus = deploymentStatus;
    }

    public List<Artifact> getRollbackVersions() {
        return rollbackVersions;
    }

    public void setRollbackVersions(final List<Artifact> rollbackVersions) {
        this.rollbackVersions = rollbackVersions;
    }

    public List<DeployedArtifact> getDeployedArtifacts() {
        return deployedArtifacts;
    }

    public void setDeployedArtifacts(final List<DeployedArtifact> deployedArtifacts) {
        this.deployedArtifacts = deployedArtifacts;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(safeDeploymentId(deployment), environment, deploymentStatus, rollbackVersions);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof EnvDeployment) {
            EnvDeployment that = (EnvDeployment) object;
            return Objects.equal(safeDeploymentId(this.deployment), safeDeploymentId(that.deployment))
                    && Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.deploymentStatus, that.deploymentStatus)
                    && Objects.equal(this.rollbackVersions, that.rollbackVersions);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", safeDeploymentId(deployment))
                .add("environment", environment)
                .add("deploymentStatus", deploymentStatus)
                // .add("rollbackVersions", rollbackVersions) Not included as may be lazily loaded.
                .toString();
    }

    private static Object safeDeploymentId(final Deployment deployment) {
        return deployment == null ? null : deployment.getId();
    }

}
