package com.ubs.f35.swift.properties.model;

import com.google.common.base.Objects;

/**
 * Extension of a basic property model which includes difference metadata to indicate how this property has changed from
 * a previous version of its owning artifact. Used for the Properties screen on the client to indicate which properties
 * are new and which were seeded from a previous version.
 * 
 * @author levyjo
 * 
 */
public class DifferencedProperty extends Property {

    private final DifferenceType difference;

    private String previousValue;

    /**
     * DifferenceType flag:
     * <ul>
     * <li>ADDED: Property is new in this version.</li>
     * <li>MODIFIED: Property key existed previously but its value has been modified in this version.</li>
     * <li>UNMODIFIED: Property key and value existed in previous version.</li>
     * <li>REMOVED: Property existed previously but does not exist in the new version.</li>
     * </ul>
     */
    public static enum DifferenceType {
        ADDED, MODIFIED, UNMODIFIED, REMOVED
    }

    public DifferencedProperty(final String key, final String value, final DifferenceType difference) {
        super(key, value);
        this.difference = difference;
    }

    public DifferencedProperty(final String key, final String value, final DifferenceType difference,
            final String previousValue) {
        super(key, value);
        this.difference = difference;
        this.previousValue = previousValue;
    }

    public DifferenceType getDifference() {
        return difference;
    }

    public String getPreviousValue() {
        return previousValue;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(super.hashCode(), difference, previousValue);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DifferencedProperty) {
            if (!super.equals(object)) {
                return false;
            }
            DifferencedProperty that = (DifferencedProperty) object;
            return Objects.equal(this.difference, that.difference)
                    && Objects.equal(this.previousValue, that.previousValue);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("super", super.toString())
                .add("difference", difference)
                .add("previousValue", previousValue)
                .toString();
    }

    @Override
    public int compareTo(final Property o) {
        if (o instanceof DifferencedProperty) {
            DifferencedProperty that = (DifferencedProperty) o;
            int comparison;
            if (this.difference == null && that.difference == null) {
            } else if (this.difference == null) {
                return -1;
            } else if (that.difference == null) {
                return 1;
            } else {
                comparison = this.difference.compareTo(that.difference);
                if (comparison != 0) {
                    return comparison;
                }
            }
            if (this.previousValue == null && that.previousValue == null) {
            } else if (this.previousValue == null) {
                return -1;
            } else if (that.previousValue == null) {
                return 1;
            } else {
                comparison = this.previousValue.compareTo(that.previousValue);
                if (comparison != 0) {
                    return comparison;
                }
            }
        }
        return super.compareTo(o);
    }

}
