package com.ubs.f35.swift.dao;

import static com.ubs.f35.swift.config.model.Objects2.toStringSafe;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.linkedin.util.clock.SystemClock;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.client.rollback.RollbackRequest;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlan;
import com.ubs.f35.swift.model.JsonObjectMapper;

@Entity
@Table(name = "DEPLOYMENTS")
public class Deployment {

    @Id
    private UUID id;

    @Column(name = "DEPLOY_USER")
    private String user;

    @OneToMany(mappedBy = "deployment", cascade = CascadeType.ALL)
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<EnvDeployment> envDeployments;

    @Column(name = "CREATEDTIME", updatable = false)
    private Timestamp createdTime;

    @Column(name = "DEPLOYTIME")
    private Timestamp deployTime;

    @Column(name = "DEPLOYSTATUS")
    @Enumerated(EnumType.STRING)
    private DeploymentStatus deploymentStatus;

    // Do not reference this property in hashcode, equals, etc. Doing so will initialise it.
    // Note that this requires bytecode instrumentation which is applied to this class by maven.
    @Column(name = "DEPLOYMENT_PLAN")
    @Lob
    @Basic(fetch = FetchType.LAZY)
    private String deploymentPlan;

    /**
     * Short lived context to do with the generation of the deployment plan. Destroyed once the deployment is completed.
     * This is only used for rollback plans to hold the {@link RollbackRequest} with the deployment plan so that it can
     * be applied when the deployment is executed.
     */
    @Column(name = "GENERATION_CONTEXT")
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonIgnore
    private String generationContext;

    @Column(name = "DEPLOYMENT_TYPE")
    @Enumerated(EnumType.STRING)
    private DeploymentType deploymentType;

    @Column(name = "RELEASE_ID")
    private Integer releaseId;

    @Column(name = "RELEASE_REV")
    private Integer releaseRev;

    public enum DeploymentStatus {
        PLAN, EXECUTING, MANUAL, COMPLETED, FAILED, CANCELLED
    }

    public enum DeploymentType {
        AdHoc, Release, Rollback
    }

    public Deployment() {
    }

    public UUID getId() {
        return id;
    }

    public void setId(final UUID id) {
        this.id = id;
    }

    public List<EnvDeployment> getEnvDeployments() {
        return envDeployments;
    }

    public void setEnvDeployments(final List<EnvDeployment> envDeployments) {
        this.envDeployments = envDeployments;
    }

    public String getUser() {
        return user;
    }

    public void setUser(final String user) {
        this.user = user;
    }

    public Timestamp getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(final Timestamp createdTime) {
        this.createdTime = createdTime;
    }

    public Timestamp getDeployTime() {
        return deployTime;
    }

    public void setDeployTime(final Timestamp deployTime) {
        this.deployTime = deployTime;
    }

    public DeploymentStatus getDeploymentStatus() {
        return deploymentStatus;
    }

    public void setDeploymentStatus(final DeploymentStatus deploymentStatus) {
        this.deploymentStatus = deploymentStatus;

        // Generation context is only required until plan is completed.
        if (deploymentStatus != DeploymentStatus.PLAN) {
            this.setGenerationContext(null);
        }
    }

    public DeploymentPlan getDeploymentPlan() {
        return JsonObjectMapper.getInstance().readValue(deploymentPlan, DeploymentPlan.class);
    }

    public void setDeploymentPlan(final DeploymentPlan deploymentPlan) {
        this.deploymentPlan = JsonObjectMapper.getInstance().writeValueAsString(deploymentPlan);
    }

    public String getGenerationContext() {
        return generationContext;
    }

    public void setGenerationContext(final String generationContext) {
        this.generationContext = generationContext;
    }

    public DeploymentType getDeploymentType() {
        return deploymentType;
    }

    public void setDeploymentType(final DeploymentType deploymentType) {
        this.deploymentType = deploymentType;
    }

    public Integer getReleaseId() {
        return releaseId;
    }

    public void setReleaseId(final Integer releaseId) {
        this.releaseId = releaseId;
    }

    public Integer getReleaseRev() {
        return releaseRev;
    }

    public void setReleaseRev(final Integer releaseRev) {
        this.releaseRev = releaseRev;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof Deployment) {
            Deployment that = (Deployment) object;
            return Objects.equal(this.id, that.id)
                    && Objects.equal(this.envDeployments, that.envDeployments)
                    && Objects.equal(this.user, that.user)
                    && Objects.equal(this.createdTime, that.createdTime)
                    && Objects.equal(this.deployTime, that.deployTime)
                    && Objects.equal(this.deploymentStatus, that.deploymentStatus)
                    && Objects.equal(this.deploymentType, that.deploymentType)
                    && Objects.equal(this.releaseId, that.releaseId)
                    && Objects.equal(this.releaseRev, that.releaseRev);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("envDeployments", toStringSafe(envDeployments))
                .add("user", user)
                .add("createdTime", createdTime)
                .add("deployTime", deployTime)
                .add("deploymentStatus", deploymentStatus)
                .add("deploymentType", deploymentType)
                .add("releaseId", releaseId)
                .add("releaseRev", releaseRev)
                .toString();
    }

    /**
     * New release deployment
     */
    public static Deployment newReleaseDeployment(final DeploymentPlan deploymentPlan,
            final List<Environment> environments,
            final String user, final ReleaseDefinition release) {
        return newReleaseDeployment(deploymentPlan, environments, user, release, DeploymentType.Release);
    }

    public static Deployment newReleaseRollbackDeployment(final DeploymentPlan deploymentPlan,
            final Environment environment, final String user, final ReleaseDefinition release,
            final RollbackRequest rollbackRequest) {
        Deployment deployment = newReleaseDeployment(deploymentPlan, Collections.singletonList(environment), user,
                release, DeploymentType.Rollback);

        deployment.setGenerationContext(JsonObjectMapper.getInstance().writeValueAsString(rollbackRequest));

        return deployment;
    }

    /**
     * New release deployment or rollback deployment (only existing generated plans can be switched to a manual
     * deployment)
     */
    private static Deployment newReleaseDeployment(final DeploymentPlan deploymentPlan,
            final List<Environment> environments,
            final String user, final ReleaseDefinition release, final DeploymentType deploymentType) {
        Deployment deployment = newDeployment(deploymentPlan.getId(), environments, user, deploymentPlan,
                deploymentType);

        deployment.releaseId = release.getId();
        deployment.releaseRev = release.getRevision();

        return deployment;
    }

    /**
     * @deprecated Only visible for the 24 tests which are currently using this code. TODO consider moving to a test
     *             utility
     */
    @Deprecated
    @VisibleForTesting
    public static Deployment newReleaseDeployment(final UUID id, final List<Environment> environments,
            final String user, final DeploymentPlan deploymentPlan, final Integer releaseId, final Integer releaseRev) {
        Deployment deployment = newDeployment(id, environments, user, deploymentPlan, DeploymentType.Release);

        deployment.releaseId = releaseId;
        deployment.releaseRev = releaseRev;

        return deployment;
    }

    /**
     * New adhoc deployment
     */
    public static Deployment newAdhocDeployment(final UUID id, final Environment environment, final String user,
            final DeploymentPlan deploymentPlan) {
        return newDeployment(id, Arrays.asList(environment), user, deploymentPlan, DeploymentType.AdHoc);
    }

    private static Deployment newDeployment(final UUID id, final List<Environment> environments, final String user,
            final DeploymentPlan deploymentPlan, final DeploymentType deploymentType) {
        Deployment deployment = new Deployment();
        deployment.id = id;
        deployment.user = user;
        deployment.createdTime = new Timestamp(SystemClock.INSTANCE.currentTimeMillis());
        deployment.setDeploymentPlan(deploymentPlan); // TODO: store as transient object also?
        deployment.deploymentStatus = DeploymentStatus.PLAN;
        deployment.deploymentType = deploymentType;

        if (environments != null) {
            List<EnvDeployment> envDeployments = Lists.newArrayList();
            for (Environment env : environments) {
                envDeployments.add(new EnvDeployment(deployment, env, DeploymentStatus.PLAN));
            }
            deployment.envDeployments = envDeployments;
        }

        return deployment;
    }

}
