package com.ubs.f35.swift.config.model;

import java.util.Map;

import com.ubs.f35.core.zookeeper.client.config.api.ZooKeeperConfigService;
import com.ubs.f35.swift.properties.GluAgentZooKeeperConnector;

public class EnvironmentConfig {
    /**
     * Controls the order of presentation of the environment within an organisation on the swift UI. If two environments
     * have the same order, the sorting will revert to alphabetical by the environment name.
     */
    private int order = 0;
    /**
     * Default to this being a production environment if unspecified. Always better to play on the safe side
     */
    private boolean productionEnvironment = true;
    /**
     * Swift will warn against production release deployments which have not yet been deployed to a staging environment
     * (like UAT)
     */
    private boolean stagingEnvironment = false;
    /**
     * If true, releases will automatically be locked when deployed to this environment.
     */
    private boolean autoLockOnDeploy = true;
    /**
     * True if the processes in this environment should be automatically restarted when an agent is restarted after a
     * host crash.
     */
    private boolean autoRestartEnabled = false;
    /**
     * true to enforce a master properties template file to be provided when configuring properties in this environment
     */
    private boolean enforcePropertyTemplate = false;

    /**
     * The ARP access right required to configure / manage this environment.
     */
    private String accessRight;

    private Map<String, String> zookeeperConnectionDetails;

    /**
     * If multiple organisations with the same environment name are to share a single zookeeper cluster, then they need
     * to have custom zookeeper roots.
     */
    private String zookeeperRoot = "/org/glu";

    /**
     * The root path to save zookeeper properties under. For Neo, this will be
     * {@link ZooKeeperConfigService#ZOOKEEPER_CONFIG_ROOT_PATH} as each Neo environment has a unique zookeeper cluster,
     * there is no need to worry about a unique path. For other orgs / envs, a single zookeeper cluster may be reused
     * (especially in swift-dev).
     */
    private String zookeeperPropertiesRoot;

    /**
     * For convenience, many environments (eg all Neo prod environments) may share the same agent connection SSL certs.
     */
    private String securityConfigTemplate;

    /**
     * Optional - can provided will make use of the command builder service to invoke commands on agents. This could be
     * used to save zookeeper properties remotely for example. See {@link GluAgentZooKeeperConnector}
     */
    private CommandBuilderConfig commandBuilderConfig;

    public int getOrder() {
        return order;
    }

    public void setOrder(final int order) {
        this.order = order;
    }

    public boolean isProductionEnvironment() {
        return productionEnvironment;
    }

    public void setProductionEnvironment(final boolean productionEnvironment) {
        this.productionEnvironment = productionEnvironment;
    }

    public boolean isAutoLockOnDeploy() {
        return autoLockOnDeploy;
    }

    public void setAutoLockOnDeploy(final boolean autoLockOnDeploy) {
        this.autoLockOnDeploy = autoLockOnDeploy;
    }

    public boolean isAutoRestartEnabled() {
        return autoRestartEnabled;
    }

    public void setAutoRestartEnabled(final boolean autoRestartEnabled) {
        this.autoRestartEnabled = autoRestartEnabled;
    }

    public String getAccessRight() {
        return accessRight;
    }

    public void setAccessRight(final String accessRight) {
        this.accessRight = accessRight;
    }

    public Map<String, String> getZookeeperConnectionDetails() {
        return zookeeperConnectionDetails;
    }

    public void setZookeeperConnectionDetails(final Map<String, String> zookeeperConnectionDetails) {
        this.zookeeperConnectionDetails = zookeeperConnectionDetails;
    }

    public String getSecurityConfigTemplate() {
        return securityConfigTemplate;
    }

    public void setSecurityConfigTemplate(final String securityConfigTemplate) {
        this.securityConfigTemplate = securityConfigTemplate;
    }

    public void setZookeeperRoot(final String zookeeperRoot) {
        this.zookeeperRoot = zookeeperRoot;
    }

    public String getZookeeperRoot() {
        return zookeeperRoot;
    }

    public String getZookeeperPropertiesRoot() {
        return zookeeperPropertiesRoot;
    }

    public void setZookeeperPropertiesRoot(final String zookeeperPropertiesRoot) {
        this.zookeeperPropertiesRoot = zookeeperPropertiesRoot;
    }

    public CommandBuilderConfig getCommandBuilderConfig() {
        return commandBuilderConfig;
    }

    public void setCommandBuilderConfig(final CommandBuilderConfig commandBuilderConfig) {
        this.commandBuilderConfig = commandBuilderConfig;
    }

    public boolean isStagingEnvironment() {
        return stagingEnvironment;
    }

    public void setStagingEnvironment(final boolean stagingEnvironment) {
        this.stagingEnvironment = stagingEnvironment;
    }

    public boolean isEnforcePropertyTemplate() {
        return enforcePropertyTemplate;
    }

    public void setEnforcePropertyTemplate(final boolean enforcePropertyTemplate) {
        this.enforcePropertyTemplate = enforcePropertyTemplate;
    }

}
