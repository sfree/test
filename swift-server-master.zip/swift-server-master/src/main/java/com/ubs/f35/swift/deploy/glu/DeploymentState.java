package com.ubs.f35.swift.deploy.glu;

import org.codehaus.jackson.annotate.JsonProperty;

import com.google.common.base.Objects;
import com.ubs.f35.swift.server.ClientError;

public class DeploymentState {
    private final DeploymentStatus status;
    private final Long startTime;
    private final Long endTime;
    private final ClientError clientError;

    public DeploymentState(
            @JsonProperty(value = "status") final DeploymentStatus status,
            @JsonProperty(value = "startTime") final Long startTime,
            @JsonProperty(value = "endTime") final Long endTime,
            @JsonProperty(value = "clientError") final ClientError clientError) {
        this.status = status;
        this.startTime = startTime;
        this.endTime = endTime;
        this.clientError = clientError;
    }

    public static DeploymentState running(final long startTime) {
        return new DeploymentState(DeploymentStatus.RUNNING, startTime, null, null);
    }

    public static DeploymentState completed(final long startTime, final long endTime) {
        return new DeploymentState(DeploymentStatus.COMPLETED, startTime, endTime, null);
    }

    public static DeploymentState failed(final long startTime, final long endTime, final ClientError clientError) {
        return new DeploymentState(DeploymentStatus.FAILED, startTime, endTime, clientError);
    }

    public DeploymentStatus getStatus() {
        return status;
    }

    public Long getStartTime() {
        return startTime;
    }

    public Long getEndTime() {
        return endTime;
    }

    public ClientError getClientError() {
        return clientError;
    }

    enum DeploymentStatus {
        RUNNING, COMPLETED, FAILED
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("status", status)
                .add("startTime", startTime)
                .add("endTime", endTime)
                .add("clientError", clientError)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(status, startTime, endTime, clientError);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DeploymentState) {
            DeploymentState that = (DeploymentState) object;
            return Objects.equal(this.status, that.status)
                    && Objects.equal(this.startTime, that.startTime)
                    && Objects.equal(this.endTime, that.endTime)
                    && Objects.equal(this.clientError, that.clientError);
        }
        return false;
    }

}
