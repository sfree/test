package com.ubs.f35.swift.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Environment;

@Entity
@Table(name = "PROPERTIES")
@Audited
public class ArtifactProperty implements Serializable {

    private static final long serialVersionUID = 344052199756390793L;

    @Id
    @ManyToOne
    @JoinColumn(name = "artifact_id", referencedColumnName = "id")
    private Artifact artifact;

    @Id
    @ManyToOne(fetch = FetchType.EAGER)
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private Environment environment;

    @Id
    @Column(name = "property_key")
    private String key;

    @Column(name = "property_value")
    @Lob
    private String value;

    public ArtifactProperty() {

    }

    public ArtifactProperty(final Artifact artifact, final Environment environment, final String key, final String value) {
        this.artifact = artifact;
        this.environment = environment;
        this.key = key;
        this.value = value;
    }

    public Artifact getArtifact() {
        return artifact;
    }

    public void setArtifact(final Artifact artifact) {
        this.artifact = artifact;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }

    public String getKey() {
        return key;
    }

    public void setKey(final String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(final String value) {
        this.value = value;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(artifact, environment, key, value);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ArtifactProperty) {
            ArtifactProperty that = (ArtifactProperty) object;
            return Objects.equal(this.artifact, that.artifact)
                    && Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.key, that.key)
                    && Objects.equal(this.value, that.value);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("artifact", artifact)
                .add("environment", environment)
                .add("key", key)
                .add("value", value)
                .toString();
    }

}
