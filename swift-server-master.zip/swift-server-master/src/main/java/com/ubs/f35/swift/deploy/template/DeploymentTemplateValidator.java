package com.ubs.f35.swift.deploy.template;

import java.util.List;
import java.util.Set;

import org.springframework.util.Assert;

import com.google.common.base.Function;
import com.google.common.collect.Iterables;
import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.deploy.template.model.DeploymentTemplate;
import com.ubs.f35.swift.deploy.template.model.TemplateAction;
import com.ubs.f35.swift.deploy.template.model.TemplateArtifactAction;
import com.ubs.f35.swift.deploy.template.model.TemplateGroupAction;
import com.ubs.f35.swift.deploy.template.model.TemplateGroupAction.Mode;
import com.ubs.f35.swift.deploy.template.model.TemplateManualAction;

public class DeploymentTemplateValidator {
    /**
     * Ensures all artifacts in the release are present in the deployment template. Ensures that no artifacts are in the
     * deployment template that are not in the release.
     */
    public void validate(final List<Artifact> releaseArtifacts, final DeploymentTemplate deploymentTemplate) {
        validate(deploymentTemplate.getAction());

        Set<NexusArtifact> releaseSet = Sets.newHashSet(Iterables.transform(releaseArtifacts, new Function<Artifact,
                NexusArtifact>() {
                    @Override
                    public NexusArtifact apply(final Artifact input) {
                        return input.getNexusArtifact();
                    }
                }));

        Set<NexusArtifact> templateSet = getAffectedArtifacts(deploymentTemplate.getAction());

        SetView<NexusArtifact> onlyInRelease = Sets.difference(releaseSet, templateSet);
        if (!onlyInRelease.isEmpty()) {
            throw new IllegalArgumentException("Release artifact '"
                    + Iterables.get(onlyInRelease, 0).getArtifactId()
                    + "' is not present in custom deployment template.");
        }

        SetView<NexusArtifact> onlyInTemplate = Sets.difference(templateSet, releaseSet);
        if (!onlyInTemplate.isEmpty()) {
            throw new IllegalArgumentException("Custom deployment template artifact '"
                    + Iterables.get(onlyInTemplate, 0).getArtifactId() + "' is not present in release.");
        }
    }

    /**
     * Ensures that a TemplateAction is valid.
     */
    public void validate(final TemplateAction action) {
        validateInternal(action);
    }

    private void validateInternal(final TemplateAction action) {
        if (action instanceof TemplateGroupAction) {
            TemplateGroupAction groupAction = (TemplateGroupAction) action;

            if (groupAction.getMode() == Mode.PARALLEL) {
                validateNoConcurrentParallelOperations(groupAction);
            }

            for (TemplateAction childAction : groupAction.getActions()) {
                validateInternal(childAction);
            }
        } else if (action instanceof TemplateManualAction) {
            TemplateManualAction manualAction = (TemplateManualAction) action;
            Assert.hasText(manualAction.getTitle(), "Manual action must have a title");
            Assert.hasText(manualAction.getDescription(), "Manual action must have a description");
        }
    }

    private void validateNoConcurrentParallelOperations(final TemplateGroupAction groupAction) {
        Set<NexusArtifact> visitedArtifacts = Sets.newHashSet();

        for (TemplateAction childAction : groupAction.getActions()) {
            Set<NexusArtifact> affected = getAffectedArtifacts(childAction);

            SetView<NexusArtifact> diff = Sets.intersection(visitedArtifacts, affected);
            if (!diff.isEmpty()) {
                throw new IllegalArgumentException("Can't execute multiple parallel actions against the artifact '"
                        + Iterables.get(diff, 0).getArtifactId() + "'");
            }

            visitedArtifacts.addAll(affected);
        }
    }

    private Set<NexusArtifact> getAffectedArtifacts(final TemplateAction action) {
        Set<NexusArtifact> artifacts = Sets.newHashSet();

        if (action instanceof TemplateGroupAction) {
            TemplateGroupAction groupAction = (TemplateGroupAction) action;

            for (TemplateAction childAction : groupAction.getActions()) {
                artifacts.addAll(getAffectedArtifacts(childAction));
            }
        } else if (action instanceof TemplateArtifactAction) {
            TemplateArtifactAction artifactAction = (TemplateArtifactAction) action;
            artifacts.add(new NexusArtifact(artifactAction.getGroupId(), artifactAction.getArtifactId()));
        }

        return artifacts;
    }

}
