package com.ubs.f35.swift.service;

import java.util.List;
import java.util.Set;

import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.client.rollback.RollbackRequest;

public interface EnvironmentDefinitionService {

    /**
     * Applies the changes in the release to the environment definition, returning the list of artifacts previously
     * defined in the environment.
     * 
     * @param releaseId
     *            The release with the Artifacts which will be deployed
     * @param revision
     *            The revision of the release to deploy
     * @param environment
     *            The environment to apply to
     * @return List of Artifact versions currently deployed in the environment (before applying the release)
     */
    List<Artifact> applyRelease(Integer releaseId, Integer revision, Set<NexusArtifact> selectedArtifactIds,
            Environment environment);

    /**
     * Reverts the environment configuation to the artifact versions specified by the {@link RollbackRequest}.
     * 
     * @param env
     * @param artifacts
     */
    void applyRollback(List<Artifact> artifacts, final Set<NexusArtifact> selectedArtifacts, Environment env);
}
