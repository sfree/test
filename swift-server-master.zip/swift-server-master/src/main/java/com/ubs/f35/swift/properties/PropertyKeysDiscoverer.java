package com.ubs.f35.swift.properties;

import static com.google.common.base.Strings.emptyToNull;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.ice.tar.TarEntry;
import com.ice.tar.TarInputStream;
import com.ubs.f35.swift.config.model.ArtifactCommonConfig;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.properties.model.PropertyKey;
import com.ubs.f35.swift.properties.model.PropertyKeysExtractionException;
import com.ubs.f35.swift.properties.model.PropertyKeysTemplateFileMissingException;
import com.ubs.f35.swift.properties.model.PropertyKeysTemplateFileNotConfiguredException;
import com.ubs.f35.swift.service.ArtifactConfigurationService;
import com.ubs.f35.swift.service.NexusArtifactService;

/**
 * Implementation of PropertyKeysProvider to retrieve all property keys by downloading the artifact distribution package
 * from Nexus and pulling out all the properties files. (This is how BladeLogic currently does it.)
 * 
 * @author levyjo
 * 
 */
public class PropertyKeysDiscoverer implements PropertyKeysProvider {
    private static final Logger LOG = LoggerFactory.getLogger(PropertyKeysDiscoverer.class);

    private String tempDir = System.getProperty("java.io.tmpdir");

    private NexusArtifactService nexusArtifactService;

    private ArtifactConfigurationService artifactConfigurationService;
    private OrganisationBeanFactory<Packaging> organisationPackaging;

    private IOFileFilter excludedDirs;
    private boolean scanForAllPropertyFiles = false;

    public enum Packaging {
        DIST_TAR_GZ("tar.gz", "dist"),
        JAR("jar", null),
        WAR("war", null);

        final String extension;
        final String classifier;

        Packaging(final String extension, final String classifier) {
            this.extension = extension;
            this.classifier = classifier;
        }
    }

    @Override
    public Set<PropertyKey> getPropertyKeys(final String organisation, final Artifact artifact)
            throws PropertyKeysExtractionException {

        Packaging packaging = organisationPackaging.get(organisation);

        // generate a unique subfolder so that two simultaneous calls don't cause a collision
        File uniquePath = new File(tempDir, RandomStringUtils.randomAlphanumeric(8));

        try {

            URL url = nexusArtifactService.getNexusUrlBuilderForArtifact(artifact.getNexusArtifact())
                    .buildDownloadURL(artifact, packaging.extension, packaging.classifier);

            // download distribution
            File downloadFile = new File(uniquePath, artifact + "." + packaging.extension);
            FileUtils.copyURLToFile(url, downloadFile, 5000, 30000);

            // extract distribution
            File extractedDir = extractDistribution(packaging, downloadFile, uniquePath);

            // find the required properties files
            Collection<File> files = getSelectedPropertiesFiles(organisation, artifact, extractedDir);

            // extract all keys and add to set
            TreeSet<PropertyKey> keys = new TreeSet<PropertyKey>();
            for (File f : files) {
                LOG.debug("Reading property names from {}", f.getAbsolutePath());
                keys.addAll(parsePropertyFile(f));
            }

            return keys;

        } catch (IOException e) {

            throw new PropertyKeysExtractionException(artifact, e);

        } finally {
            // cleanup
            try {
                FileUtils.deleteDirectory(uniquePath);
            } catch (IOException e) {
                LOG.error("Could not delete temp extraction directory", e);
            }
        }

    }

    private File extractDistribution(final Packaging packaging, final File distFile, final File uniquePath)
            throws IOException {

        if (packaging == Packaging.DIST_TAR_GZ) {
            return unTarGZ(distFile, uniquePath);
        } else if (packaging == Packaging.JAR || packaging == Packaging.WAR) {
            return unJar(distFile, uniquePath);
        }
        throw new IllegalArgumentException("Unknown packaging " + packaging);
    }

    /**
     * Extracts files with a .properties extension from a gzipped tar archive
     * 
     * @param organisation
     * 
     * @param tarGzFile
     *            The gzipped tar file to extract
     * @param destination
     *            Directory in which to place the extracted files (subdirectory will be created here)
     * @return File path where extracted files can be found
     * @throws IOException
     */
    private File unTarGZ(final File tarGzFile, final File destination) throws IOException {

        File untarDir = new File(destination, "tar");
        if (!untarDir.exists())
        {
            boolean result = untarDir.mkdirs();
            if (!result) {
                throw new IOException("Cannot create directory " + untarDir + " to untar into");
            }
        }

        TarInputStream tis = null;
        try {
            tis = new TarInputStream(new GZIPInputStream(new FileInputStream(tarGzFile)));

            TarEntry tarEntry = tis.getNextEntry();

            while (tarEntry != null) {
                File destPath = new File(untarDir, tarEntry.getName());
                if (!tarEntry.isDirectory()) {
                    if (tarEntry.getName().toLowerCase().endsWith(".properties")) {
                        int di = tarEntry.getName().lastIndexOf('/');
                        if (di != -1) {
                            new File(untarDir, tarEntry.getName().substring(0, di)).mkdirs();
                        }

                        FileOutputStream fout = new FileOutputStream(destPath);
                        tis.copyEntryContents(fout);
                        fout.close();
                    }
                } else {
                    destPath.mkdir();
                }
                tarEntry = tis.getNextEntry();
            }

        } finally {
            IOUtils.closeQuietly(tis);
        }

        return untarDir;

    }

    /**
     * Extracts files with a .properties extension from a Jar archive
     * 
     * @param organisation
     * 
     * @param jarFile
     *            jar file to extract
     * @param destination
     *            Directory in which to place the extracted files (subdirectory will be created here)
     * @return File path where extracted files can be found
     * @throws IOException
     */
    private File unJar(final File jarFile, final File destination) throws IOException {

        File unjarDir = new File(destination, "jar");
        if (!unjarDir.exists())
        {
            boolean result = unjarDir.mkdirs();
            if (!result) {
                throw new IOException("Cannot create directory " + unjarDir + " to unjar into");
            }
        }

        ZipFile zip = new ZipFile(jarFile);
        try {
            Enumeration<? extends ZipEntry> zipEntries = zip.entries();
            while (zipEntries.hasMoreElements()) {
                ZipEntry zipEntry = zipEntries.nextElement();
                File destPath = new File(unjarDir, zipEntry.getName());
                if (!zipEntry.isDirectory()) {
                    if (zipEntry.getName().toLowerCase().endsWith(".properties")) {
                        FileOutputStream fout = new FileOutputStream(destPath);

                        IOUtils.copy(zip.getInputStream(zipEntry), fout);
                        fout.close();
                    }
                } else {
                    destPath.mkdir();
                }
            }
        } finally {
            IOUtils.closeQuietly(zip);
        }

        return unjarDir;

    }

    private Collection<File> getSelectedPropertiesFiles(final String organisation, final Artifact artifact,
            final File inputDir) {

        // Look for configured property template files
        ArtifactCommonConfig config = artifactConfigurationService.loadOrDefaultCommonConfig(artifact
                .getNexusArtifact());

        if (isPropertyTemplateConfigured(config)) {

            LOG.debug("Using configured template files for property keys for {}", artifact);

            String configuredTemplates = config.getPropertyTemplates();
            Collection<File> filesFound = FileUtils.listFiles(inputDir, filesIncludedFilter(configuredTemplates),
                    excludedDirs);
            checkAllConfiguredFilesExist(organisation, artifact, filesFound, configuredTemplates);
            return filesFound;

        } else if (scanForAllPropertyFiles) {

            // Look for properties everywhere
            // Note that only .properties files will have been extracted anyway by the unTarGz method.
            LOG.debug("No template files configured for artifact {}. Looking in all properties files.", artifact);
            return FileUtils.listFiles(inputDir, TrueFileFilter.INSTANCE, excludedDirs);

        } else {
            throw new PropertyKeysTemplateFileNotConfiguredException(organisation, artifact);
        }

    }

    private void checkAllConfiguredFilesExist(final String organisation, final Artifact artifact,
            final Collection<File> files,
            final String configuredTemplates) {

        Collection<String> filesFound = Collections2.transform(files,
                new Function<File, String>() {
                    @Override
                    public String apply(final File input) {
                        return input.getName();
                    }
                });

        for (String configuredTemplate : splitFilenames(configuredTemplates)) {
            if (!filesFound.contains(configuredTemplate)) {
                throw new PropertyKeysTemplateFileMissingException(organisation, artifact, configuredTemplate);
            }
        }
    }

    private boolean isPropertyTemplateConfigured(final ArtifactCommonConfig config) {
        if (config == null) {
            return false;
        }

        return !StringUtils.isBlank(config.getPropertyTemplates());
    }

    /**
     * Parses a properties file for all keys
     * 
     * @param file
     *            A properties file
     * @return TreeSet of property keys
     */
    private Set<PropertyKey> parsePropertyFile(final File file) {
        TreeSet<PropertyKey> keys = new TreeSet<PropertyKey>();
        BufferedReader br = null;

        try {

            br = new BufferedReader(new FileReader(file));
            StringBuilder comments = new StringBuilder();
            String strLine;

            // Include comments as a description of what the property is for.
            // Include the configured value (if present) as a default suggested value
            while ((strLine = br.readLine()) != null) {
                if (!strLine.isEmpty()) {
                    if (strLine.startsWith("#")) {
                        String comment = Pattern.compile("^#*").matcher(strLine).replaceAll("").trim();
                        if (!comment.isEmpty()) {
                            comments.append(comment).append("\n");
                        }
                    } else if (strLine.indexOf("=") > -1) {
                        String[] keyVal = strLine.split("=", 2);
                        String key = keyVal[0].trim();
                        String suggestedValue = keyVal.length == 1 ? null : keyVal[1].trim();

                        PropertyKey propKey;
                        if (scanForAllPropertyFiles) {
                            // Unsure what the rules
                            propKey = new PropertyKey(key, null, null);
                        } else {
                            propKey = new PropertyKey(key, emptyToNull(suggestedValue),
                                    emptyToNull(comments.toString().trim()));
                        }
                        keys.add(propKey);

                        comments.setLength(0);
                    }
                }
            }

        } catch (IOException e) {

            LOG.error("Error reading properties file", e);

        } finally {
            IOUtils.closeQuietly(br);
        }

        return keys;
    }

    private IOFileFilter dirExcludeFilter(final List<String> excludedDirs) {

        IOFileFilter[] filters = new IOFileFilter[excludedDirs.size()];
        for (int i = 0; i < excludedDirs.size(); i++) {
            filters[i] = FileFilterUtils.nameFileFilter(excludedDirs.get(i));
        }

        return FileFilterUtils.notFileFilter(FileFilterUtils.or(filters));

    }

    private IOFileFilter filesIncludedFilter(final String filenames) {

        List<String> files = splitFilenames(filenames);
        IOFileFilter[] filters = new IOFileFilter[files.size()];

        int i = 0;
        for (String f : files) {
            filters[i] = FileFilterUtils.nameFileFilter(f);
            i++;
        }

        return FileFilterUtils.or(filters);
    }

    private List<String> splitFilenames(final String filenames) {
        return Arrays.asList(filenames.trim().split(","));
    }

    @Required
    public void setNexusArtifactService(final NexusArtifactService nexusArtifactService) {
        this.nexusArtifactService = nexusArtifactService;
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }

    @Required
    public void setOrganisationPackaging(final OrganisationBeanFactory<Packaging> organisationPackaging) {
        this.organisationPackaging = organisationPackaging;
    }

    public void setTempDir(final String tempDir) {
        if (tempDir.isEmpty()) {
            this.tempDir = System.getProperty("java.io.tmpdir");
        } else {
            this.tempDir = tempDir;
        }
    }

    public void setExcludedDirs(final List<String> excludedDirs) {
        this.excludedDirs = dirExcludeFilter(excludedDirs);
    }

    public void setScanForAllPropertyFiles(final boolean scanForAllPropertyFiles) {
        this.scanForAllPropertyFiles = scanForAllPropertyFiles;
    }

}
