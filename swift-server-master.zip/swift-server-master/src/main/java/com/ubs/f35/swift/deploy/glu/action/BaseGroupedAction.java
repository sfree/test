package com.ubs.f35.swift.deploy.glu.action;

import java.util.List;

import org.springframework.util.Assert;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Environment;

/**
 * A container for other actions.
 * 
 * @author stephelu
 * 
 */
public abstract class BaseGroupedAction extends BaseAction {
    private final List<Action> included;
    // Optional. If present indicates that all actions under this are within this environment.
    private Environment environment;

    public BaseGroupedAction(final String id, final String name, final List<Action> includedActions) {
        super(id, name);
        Assert.notEmpty(includedActions, "Requested deployment has no operations");

        this.included = includedActions;
    }

    public List<Action> getIncluded() {
        return included;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .addValue(super.toString())
                .add("included", included)
                .add("environment", environment)
                .toString();
    }

    @Override
    public boolean equals(final Object object) {
        if (!super.equals(object)) {
            return false;
        }

        BaseGroupedAction that = (BaseGroupedAction) object;
        return Objects.equal(this.included, that.included)
                && Objects.equal(this.environment, that.environment);
    }

}
