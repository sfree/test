package com.ubs.f35.swift.config.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Environment;

/**
 * A host can only belong to a single environment / fabric. All deploy tags added to the host must be for the same
 * environment.
 */
@Entity
@Table(name = "HOSTS")
@Audited
public class Host implements DeployTagable {
    @Id
    private String hostname;

    @ManyToOne(fetch = FetchType.EAGER)
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private Environment environment;

    @NotAudited
    private Date lastAutoRestartTime;

    @ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE }, targetEntity = DeployTag.class)
    @JoinTable(name = "HOST_DEPLOY_TAGS",
            joinColumns = { @JoinColumn(name = "hostname") },
            inverseJoinColumns = { @JoinColumn(name = "tag", referencedColumnName = "tag"),
                    @JoinColumn(name = "environment_id", referencedColumnName = "environment_id") })
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @AuditJoinTable(name = "HOST_DEPLOY_TAGS_AUD")
    private List<DeployTag> deployTags;

    @Version
    private Date lastUpdatedTime;

    public String getHostname() {
        return hostname;
    }

    public void setHostname(final String hostname) {
        this.hostname = hostname;
    }

    @Override
    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }

    @Override
    public List<DeployTag> getDeployTags() {
        return deployTags;
    }

    @Override
    public void setDeployTags(final List<DeployTag> deployTags) {
        this.deployTags = deployTags;
    }

    public Date getLastAutoRestartTime() {
        return lastAutoRestartTime;
    }

    public void setLastAutoRestartTime(final Date lastAutoRestartTime) {
        this.lastAutoRestartTime = lastAutoRestartTime;
    }

    public Date getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    public void setLastUpdatedTime(final Date lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(hostname, environment, deployTags, lastAutoRestartTime);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof Host) {
            Host that = (Host) object;
            return Objects2.equal(this.hostname, that.hostname)
                    && Objects2.equal(this.environment, that.environment)
                    && Objects2.equal(this.lastAutoRestartTime, that.lastAutoRestartTime)
                    && Objects2.equal(this.deployTags, that.deployTags);
        }
        return false;
    }

    @Override
    public String toString() {
        return "Host [hostname=" + hostname + ", environment=" + environment + ", deployTags=" + deployTags
                + ", lastAutoRestartTime=" + lastAutoRestartTime + ", lastUpdatedTime=" + lastUpdatedTime + "]";
    }

}
