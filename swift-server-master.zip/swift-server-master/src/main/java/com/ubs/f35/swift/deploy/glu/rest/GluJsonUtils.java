package com.ubs.f35.swift.deploy.glu.rest;

import java.util.Map;

public class GluJsonUtils {

    @SuppressWarnings("rawtypes")
    public static String extractFromMap(final Map map, final String... keyPath) {
        Map current = map;
        for (int i = 0; i < keyPath.length - 1; i++) {
            current = (Map) current.get(keyPath[i]);
        }
        Object value = current.get(keyPath[keyPath.length - 1]);

        return value != null ? String.valueOf(value) : null;
    }

}
