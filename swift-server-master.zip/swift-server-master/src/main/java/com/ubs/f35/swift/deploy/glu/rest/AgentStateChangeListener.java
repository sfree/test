package com.ubs.f35.swift.deploy.glu.rest;

import com.ubs.f35.swift.dao.model.Environment;

/**
 * Callback to receive notifications when a glu agent changes state
 * 
 * @author stephelu
 * 
 */
public interface AgentStateChangeListener {

    /**
     * 
     * @param environment
     * @param agent
     * @param alive
     *            true if the agent is alive. False if it has gone down
     */
    void agentStateChanged(Environment environment, String agent, boolean alive);
}
