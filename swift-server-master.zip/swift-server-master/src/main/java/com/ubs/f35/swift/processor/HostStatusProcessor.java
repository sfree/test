package com.ubs.f35.swift.processor;

import java.util.List;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.HostDao;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.GluHostStatusManager;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.model.HostStatus;
import com.ubs.f35.swift.util.HostNameFunction;

@Controller
@RequestMapping(value = "/api/host")
@Transactional(readOnly = true)
public class HostStatusProcessor {
    private HostDao hostDao;
    private EnvironmentBeanFactory<GluHostStatusManager> hostStatusManagerFactory;

    @ResponseBody
    @RequestMapping(value = "/{organisation}/{environment}", method = RequestMethod.GET)
    public List<HostStatus> getStatus(@PathVariable final String organisation, @PathVariable final String environment) {

        Environment env = new Environment(environment, organisation);

        List<Host> hosts = hostDao.loadByEnvironment(env);
        List<String> hostNames = Lists.transform(hosts, HostNameFunction.INSTANCE);
        return hostStatusManagerFactory.get(env).getHostHealth(hostNames);
    }

    @Required
    public void setHostStatusManagerFactory(final EnvironmentBeanFactory<GluHostStatusManager> hostStatusManagerFactory) {
        this.hostStatusManagerFactory = hostStatusManagerFactory;
    }

    @Required
    public void setHostDao(final HostDao hostDao) {
        this.hostDao = hostDao;
    }
}
