package com.ubs.f35.swift.dao;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.Activity.ActivityType;
import com.ubs.f35.swift.dao.Activity.Verb;
import com.ubs.f35.swift.dao.model.Environment;

/**
 * Key used to match Activities which can be amalgamated together. Two activities which have the same user, type,
 * objectId, environment and verb can potentially be amalgamated into one activity on the activity feed.
 * 
 * @author levyjo
 * 
 */
public class ActivityAggregationKey {

    private final String user;
    private final ActivityType type;
    private final Integer objectId;
    private final Environment environment;
    private final Verb verb;

    public ActivityAggregationKey(final String user, final ActivityType type, final Integer objectId,
            final Environment environment, final Verb verb) {
        this.user = user;
        this.type = type;
        this.objectId = objectId;
        this.environment = environment;
        this.verb = verb;
    }

    public String getUser() {
        return user;
    }

    public ActivityType getType() {
        return type;
    }

    public Integer getObjectId() {
        return objectId;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public Verb getVerb() {
        return verb;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(user, type, objectId, environment, verb);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ActivityAggregationKey) {
            ActivityAggregationKey that = (ActivityAggregationKey) object;
            return Objects.equal(this.user, that.user)
                    && Objects.equal(this.type, that.type)
                    && Objects.equal(this.objectId, that.objectId)
                    && Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.verb, that.verb);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("user", user)
                .add("type", type)
                .add("objectId", objectId)
                .add("environment", environment)
                .add("verb", verb)
                .toString();
    }

}
