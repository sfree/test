package com.ubs.f35.swift.client.model;


public interface WithArtifactType {
    ArtifactType getArtifactType();
}
