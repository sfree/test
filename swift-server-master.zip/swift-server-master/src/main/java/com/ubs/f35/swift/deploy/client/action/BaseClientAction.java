package com.ubs.f35.swift.deploy.client.action;

public class BaseClientAction implements ClientAction {
    protected final String id;

    public BaseClientAction(final String id) {
        this.id = id;
    }

    @Override
    public final String getId() {
        return id;
    }

}
