package com.ubs.f35.swift.config.model;

import java.io.Serializable;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.Environment;

@Table(name = "ARTIFACT_COMMON_CONFIG")
@Audited
@Entity
public class ArtifactCommonConfig implements Serializable {

    @Id
    @Column(name = "GROUP_ID")
    private String groupId;
    @Id
    @Column(name = "ARTIFACT_ID")
    private String artifactId;

    private boolean nonProd;

    @Column(name = "HAS_PROPS")
    private boolean hasProperties;

    @Column(name = "PROPS_TEMPLATES")
    private String propertyTemplates;

    @ManyToMany(cascade = { CascadeType.DETACH, CascadeType.REFRESH }, targetEntity = ArtifactCommonConfig.class)
    @JoinTable(name = "ARTIFACT_DEPENDS_ARTIFACT",
            joinColumns = {
                    @JoinColumn(name = "group_id", referencedColumnName = "group_id"),
                    @JoinColumn(name = "artifact_id", referencedColumnName = "artifact_id") },
            inverseJoinColumns = { @JoinColumn(name = "dependent_on_group_id", referencedColumnName = "group_id"),
                    @JoinColumn(name = "dependent_on_artifact_id", referencedColumnName = "artifact_id") })
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @AuditJoinTable(name = "ARTIFACT_DEPENDS_ARTIFACT_AUD")
    private List<ArtifactCommonConfig> dependencies;

    @ManyToMany(fetch = FetchType.LAZY, mappedBy = "dependencies")
    @NotAudited
    private List<ArtifactCommonConfig> dependentOnThis;

    // A list of environments this artifact is configured to not be deployed to
    @ManyToMany(cascade = { CascadeType.DETACH }, fetch = FetchType.LAZY)
    @JoinTable(name = "ARTIFACT_NOT_DEPLOY_ENV",
            joinColumns = { @JoinColumn(name = "GROUP_ID"), @JoinColumn(name = "ARTIFACT_ID") },
            inverseJoinColumns = { @JoinColumn(name = "ENVIRONMENT_ID", referencedColumnName = "ID") })
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @AuditJoinTable(name = "ARTIFACT_NOT_DEPLOY_ENV_AUD")
    private List<Environment> notDeployedEnvironments;

    @Version
    private Date lastUpdatedTime;

    public static final boolean NONPROD_DEFAULT = false;
    public static final boolean HAS_PROPERTIES_DEFAULT = true;
    public static final String PROPERTIES_TEMPLATES_DEFAULT = "master.properties";

    /**
     * For hibernate deserialization. Do NOT USE
     */
    @Deprecated
    public ArtifactCommonConfig() {
        this(null, null, NONPROD_DEFAULT, HAS_PROPERTIES_DEFAULT, PROPERTIES_TEMPLATES_DEFAULT, null);
    }

    public ArtifactCommonConfig(final String groupId, final String artifactId, final boolean nonProd,
            final boolean hasProperties, final String propertyTemplates, final Date lastUpdatedTime) {
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.nonProd = nonProd;
        this.hasProperties = hasProperties;
        this.propertyTemplates = propertyTemplates;
        this.lastUpdatedTime = lastUpdatedTime;

        this.dependencies = Collections.emptyList();
        this.dependentOnThis = Collections.emptyList();
    }

    public String getGroupId() {
        return groupId;
    }

    /**
     * groupId should really be immutable. This setter only exists for 29west deserialisation.
     */
    @Deprecated
    public void setGroupId(final String groupId) {
        this.groupId = groupId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    /**
     * artifactId should really be immutable. This setter only exists for 29west deserialisation.
     */
    @Deprecated
    public void setArtifactId(final String artifactId) {
        this.artifactId = artifactId;
    }

    public boolean isNonProd() {
        return nonProd;
    }

    public void setNonProd(final boolean nonProd) {
        this.nonProd = nonProd;
    }

    @JsonProperty
    public boolean hasProperties() {
        return hasProperties;
    }

    public void setHasProperties(final boolean hasProperties) {
        this.hasProperties = hasProperties;
    }

    public String getPropertyTemplates() {
        return propertyTemplates;
    }

    public void setPropertyTemplates(final String propertyTemplates) {
        this.propertyTemplates = propertyTemplates;
    }

    public Date getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    public void setLastUpdatedTime(final Date lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

    public List<ArtifactCommonConfig> getDependencies() {
        return dependencies;
    }

    public void setDependencies(final List<ArtifactCommonConfig> dependencies) {
        this.dependencies = dependencies;
    }

    public List<Environment> getNotDeployedEnvironments() {
        return notDeployedEnvironments;
    }

    public void setNotDeployedEnvironments(final List<Environment> notDeployedEnvironments) {
        this.notDeployedEnvironments = notDeployedEnvironments;
    }

    @VisibleForTesting
    @Deprecated
    public void setDependentOnThis(final List<ArtifactCommonConfig> dependentOnThis) {
        this.dependentOnThis = dependentOnThis;
    }

    @JsonIgnore
    public List<ArtifactCommonConfig> getDependentOnThis() {
        return dependentOnThis;
    }

    @JsonIgnore
    public NexusArtifact getArtifact() {
        return new NexusArtifact(groupId, artifactId);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(groupId, artifactId, nonProd, hasProperties, propertyTemplates, dependencies,
                lastUpdatedTime);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ArtifactCommonConfig) {
            ArtifactCommonConfig that = (ArtifactCommonConfig) object;
            return Objects2.equal(this.groupId, that.groupId)
                    && Objects2.equal(this.artifactId, that.artifactId)
                    && Objects2.equal(this.nonProd, that.nonProd)
                    && Objects2.equal(this.hasProperties, that.hasProperties)
                    && Objects2.equal(this.propertyTemplates, that.propertyTemplates)
                    && Objects2.equal(this.dependencies, that.dependencies)
                    && Objects2.equal(this.lastUpdatedTime, that.lastUpdatedTime);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("groupId", groupId)
                .add("artifactId", artifactId)
                .add("nonProd", nonProd)
                .add("hasProperties", hasProperties)
                .add("propertyTemplates", propertyTemplates)
                .add("dependencies", dependencies)
                .add("lastUpdatedTime", lastUpdatedTime)
                .toString();
    }

    public static ArtifactCommonConfig commonConfigId(final String groupId, final String artifactId) {
        return new ArtifactCommonConfig(groupId, artifactId, NONPROD_DEFAULT, HAS_PROPERTIES_DEFAULT,
                PROPERTIES_TEMPLATES_DEFAULT, null);
    }

}
