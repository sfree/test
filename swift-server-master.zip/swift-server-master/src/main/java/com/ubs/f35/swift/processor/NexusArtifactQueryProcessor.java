package com.ubs.f35.swift.processor;

import static com.ubs.f35.swift.processor.ProcessorUtil.transform;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Function;
import com.ubs.f35.swift.client.model.NexusArtifactWithType;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.NexusArtifactDao;
import com.ubs.f35.swift.service.ArtifactTypeService;
import com.ubs.f35.swift.service.NexusArtifactService;

/**
 * Returns details of the artifacts available to be added to a release.
 * <p>
 * Note that {@link NexusArtifact}s are linked to specific organisations. When querying for artifacts, the client can
 * restrict artifacts to those relevant for the organisation.
 * <p>
 * When querying for the versions, organisation information does not need to be provided as the list of versions for the
 * artifact has nothing to do with the organisation..
 * 
 * @author stephelu
 * 
 */
@Controller
@RequestMapping(value = "/api/lookup")
@Transactional
public class NexusArtifactQueryProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(NexusArtifactQueryProcessor.class);

    private NexusArtifactService nexusArtifactService;
    private NexusArtifactDao nexusArtifactDao;
    private ArtifactTypeService artifactTypeService;

    @Deprecated
    // Not used on the client.
    @RequestMapping(value = "/groups", method = RequestMethod.GET)
    public List<String> queryGroups(
            @RequestParam(value = "g", defaultValue = "") final String group,
            @RequestParam(value = "a", required = false) final String artifact) {
        return nexusArtifactDao.getGroups(group, artifact);
    }

    @RequestMapping(value = "/artifacts/{organisation}", method = RequestMethod.GET)
    public List<NexusArtifactWithType> queryArtifacts(
            @PathVariable final String organisation,
            @RequestParam(value = "a", defaultValue = "") final String artifact) {
        return transform(nexusArtifactDao.getArtifacts(organisation, artifact),
                new Function<NexusArtifact, NexusArtifactWithType>() {
                    @Override
                    public NexusArtifactWithType apply(final NexusArtifact input) {
                        return new NexusArtifactWithType(input, artifactTypeService.getArtifactType(input));
                    }
                });
    }

    @RequestMapping(value = "/artifacts/{organisation}/{group}", method = RequestMethod.GET)
    public List<String> queryArtifacts(
            @PathVariable final String organisation,
            @PathVariable final String group,
            @RequestParam(value = "a", defaultValue = "") final String artifact) {
        return nexusArtifactDao.getArtifacts(organisation, group, artifact);
    }

    @RequestMapping(value = "/versions/{group}/{artifact}", method = RequestMethod.GET)
    public List<String> getVersionsForArtifact(@PathVariable final String group, @PathVariable final String artifact) {
        return nexusArtifactService.getVersionsForArtifact(new NexusArtifact(group, artifact), true);
    }

    @RequestMapping(value = "/register/{organisation}/{group}/{artifact}", method = RequestMethod.GET)
    @ResponseBody
    public NexusArtifact registerArtifact(@PathVariable final String organisation, @PathVariable final String group,
            @PathVariable final String artifact) {
        // Strictly speaking, a GET request should not change state, but this allows devs to quickly register additional
        // artifacts.
        return nexusArtifactService.registerArtifact(organisation, new NexusArtifact(group, artifact));
    }

    @RequestMapping(value = "/deregister/{organisation}/{group}/{artifact}", method = RequestMethod.DELETE)
    public void deregisterArtifact(@PathVariable final String organisation, @PathVariable final String group,
            @PathVariable final String artifact) {
        LOG.info("Delete artifact request for {} {} {}", organisation, artifact);

        nexusArtifactService.deregisterArtifact(organisation, new NexusArtifact(group, artifact));
    }

    @Required
    public void setNexusArtifactService(final NexusArtifactService nexusArtifactService) {
        this.nexusArtifactService = nexusArtifactService;
    }

    @Required
    public void setNexusArtifactDao(final NexusArtifactDao nexusArtifactDao) {
        this.nexusArtifactDao = nexusArtifactDao;
    }

    @Required
    public void setArtifactTypeService(final ArtifactTypeService artifactTypeService) {
        this.artifactTypeService = artifactTypeService;
    }
}
