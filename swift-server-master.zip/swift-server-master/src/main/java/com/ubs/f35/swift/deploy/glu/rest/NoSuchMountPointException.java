package com.ubs.f35.swift.deploy.glu.rest;


public class NoSuchMountPointException extends RuntimeException {

    public NoSuchMountPointException(final String message) {
        super(message);
    }

}
