package com.ubs.f35.swift.security;

import java.util.List;

public interface UserGroupsLookup {
    List<String> findUserSwiftGroups(final String guid);
}
