package com.ubs.f35.swift.dao.hibernate.framework;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.core.io.ClassPathResource;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.util.StringUtils;

import com.google.common.collect.Sets;

public class HsqldbInitializer implements InitializingBean {
    private static final Logger LOG = LoggerFactory
            .getLogger(HsqldbInitializer.class);

    private static final Set<String> INITIALISED = Sets.newHashSet();

    private JdbcTemplate jdbc;
    private String db;
    // Single sql statement per line
    private List<String> resources;
    // semicolon delimited sql statements
    private List<String> newResources = Collections.emptyList();

    @Required
    public void setJdbc(final JdbcTemplate jdbcTemplate) {
        this.jdbc = jdbcTemplate;
    }

    @Required
    public void setResources(final List<String> resources) {
        this.resources = resources;
    }

    @Required
    public void setDb(final String db) {
        this.db = db;
    }

    public void setNewResources(final List<String> newResources) {
        this.newResources = newResources;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if (INITIALISED.add(db)) {
            for (String resource : resources) {
                LOG.info("Initialising db {} using resource {}", db, resource);

                InputStream initScript = getClass().getResourceAsStream(
                        resource);

                List<String> statements = IOUtils.readLines(initScript);

                for (String statement : statements) {
                    if (StringUtils.hasText(statement)
                            && !statement.startsWith("--")) {
                        LOG.debug("execute {}", statement);
                        jdbc.execute(statement);
                    }
                }
                LOG.info("Finished initialising test db");
            }
        }

        final ResourceDatabasePopulator dbPopulator = new ResourceDatabasePopulator();
        for (String resource : newResources) {
            dbPopulator.addScript(new ClassPathResource(resource));
        }
        jdbc.execute(new ConnectionCallback<Void>() {
            @Override
            public Void doInConnection(final Connection con) throws SQLException, DataAccessException {
                dbPopulator.populate(con);
                return null;
            }
        });
    }

}
