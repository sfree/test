package com.ubs.f35.swift.processor;

import static com.ubs.f35.swift.processor.ProcessorUtil.daoFilter;
import static com.ubs.f35.swift.processor.ProcessorUtil.transform;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Function;
import com.google.common.collect.ComparisonChain;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.dao.DailyDeploymentStats;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;
import com.ubs.f35.swift.dao.DeploymentDao;
import com.ubs.f35.swift.dao.PagingResult;
import com.ubs.f35.swift.dao.model.DeployedArtifact;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.deploy.client.action.ClientAction;
import com.ubs.f35.swift.deploy.client.action.ClientDeployment;
import com.ubs.f35.swift.deploy.client.action.ClientDeploymentPlan;
import com.ubs.f35.swift.deploy.client.action.ClientDeploymentPlanConvertor;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlan;
import com.ubs.f35.swift.deploy.glu.plan.Warning;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.model.ClientPagingFilter;
import com.ubs.f35.swift.model.EnvironmentDeploymentSummary;
import com.ubs.f35.swift.service.ArtifactConfigurationService;
import com.ubs.f35.swift.service.ArtifactConfigurationService.EnvironmentEntryPair;
import com.ubs.f35.swift.service.EnvironmentDeploymentSummaryBuilder;
import com.ubs.f35.swift.util.EnvironmentCloneFunction;

@Controller
@RequestMapping(value = "/api/history")
@Transactional(readOnly = true)
public class DeploymentHistoryProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(DeploymentHistoryProcessor.class);

    public static final String STATS_CACHE_KEY = "DeploymentHistoryProcessor.stats";

    private DeploymentDao deploymentDao;
    private ClientDeploymentPlanConvertor clientDeploymentPlanConvertor;
    private EnvironmentDeploymentSummaryBuilder environmentDeploymentSummaryBuilder;
    private OrganisationBeanFactory<List<String>> orgEnvironmentsMap;
    private ArtifactConfigurationService artifactConfigurationService;

    @RequestMapping(value = "/detailed/{releaseId}", method = RequestMethod.GET)
    @ResponseBody
    public PagingResult<Deployment> getFullDeploymentHistory(@PathVariable final Integer releaseId,
            final ClientPagingFilter filter) {
        PagingResult<Deployment> results = deploymentDao.getDeploymentHistoryForRelease(releaseId, daoFilter(filter));

        return transform(results, DEPLOYMENT_SUMMARY_MAPPER_WITH_ENV);
    }

    @RequestMapping(value = "/deployment/{deploymentId}", method = RequestMethod.GET)
    @ResponseBody
    public ClientDeployment getDeploymentPlan(@PathVariable final String deploymentId) {
        Deployment d = deploymentDao.loadDeployment(UUID.fromString(deploymentId));
        DeploymentPlan plan = d.getDeploymentPlan();
        ClientDeploymentPlan clientPlan;
        if (plan == null) {
            // Provide a valid response in the case of a manual deployment which has no plan recorded.
            clientPlan = new ClientDeploymentPlan(deploymentId, Collections.<ClientAction>emptyList(),
                    Collections.<Warning>emptyList());
        } else {
            clientPlan = clientDeploymentPlanConvertor.convert(d.getDeploymentPlan());
        }
        return new ClientDeployment(d.getReleaseId(), clientPlan);
    }

    /**
     * Gets the latest {@link DeploymentStatus} for this release in each environment. Checks that the artifacts deployed
     * in the deployment actually match those in the current release definition. If they don't, the deployment status
     * will be shown as STALE.
     * 
     * @param releaseId
     * @return Map of environments to deployment statuses
     */
    @RequestMapping(value = "/summary/{releaseId}", method = RequestMethod.GET)
    @ResponseBody
    public List<EnvironmentDeploymentSummary> getEnvironmentDeploymentSummaries(
            @PathVariable final Integer releaseId,
            @RequestParam(value = "revision", required = false) final Integer revision) {

        return environmentDeploymentSummaryBuilder.getEnvironmentDeploymentSummaries(releaseId, revision);
    }

    @Cacheable(value = STATS_CACHE_KEY)
    @RequestMapping(value = "/stats/{organisation}", method = RequestMethod.GET)
    public List<DailyDeploymentStats> getDeploymentStats(@PathVariable final String organisation) {
        List<DailyDeploymentStats> results = deploymentDao.getDailyDeploymentStats(organisation);
        final List<String> environments = orgEnvironmentsMap.get(organisation);
        // Sort the results by environment then date so that the series on the client is sorted by a logical (eg dev
        // before qa before prod) environment order (not alphabetical which could have easily been done on the db
        Collections.sort(results, new Comparator<DailyDeploymentStats>() {
            @Override
            public int compare(final DailyDeploymentStats o1, final DailyDeploymentStats o2) {
                return ComparisonChain.start()
                        .compare(environments.indexOf(o1.getEnvironment()), environments.indexOf(o2.getEnvironment()))
                        .compare(o1.getDate(), o2.getDate())
                        .result();
            }
        });
        return results;
    }

    @RequestMapping(value = "/detailed/artifact", method = RequestMethod.GET)
    @ResponseBody
    public PagingResult<DeployedArtifact> getFullDeploymentHistory(@RequestParam(value = "id") final String id,
            final ClientPagingFilter filter) {
        EnvironmentEntryPair resolvedDetails = artifactConfigurationService.resolveArtifactInstanceId(id);

        Entry entry = resolvedDetails.getEntry();

        ArtifactConfig artifact = artifactConfigurationService.loadArtifactConfigurationForEntry(
                resolvedDetails.getEnvironment(), entry);

        PagingResult<DeployedArtifact> results = deploymentDao.getDeploymentHistoryForArtifact(artifact,
                entry.getAgent(), daoFilter(filter));

        return transform(results, ARTIFACT_DEPLOYMENT_MAPPER);
    }

    private static final Function<DeployedArtifact, DeployedArtifact> ARTIFACT_DEPLOYMENT_MAPPER = new Function<DeployedArtifact, DeployedArtifact>() {
        @Override
        public DeployedArtifact apply(final DeployedArtifact input) {
            DeployedArtifact output = new DeployedArtifact();
            output.setGroupId(input.getGroupId());
            output.setArtifactId(input.getArtifactId());
            output.setName(input.getName());

            EnvDeployment envOuput = new EnvDeployment(DEPLOYMENT_SUMMARY_MAPPER_WITH_ENV.apply(input
                    .getEnvDeployment().getDeployment()), input.getEnvDeployment().getEnvironment(), input
                    .getEnvDeployment().getDeploymentStatus());
            output.setEnvDeployment(envOuput);

            output.setDeploymentAction(input.getDeploymentAction());
            output.setHostname(input.getHostname());
            output.setVersion(input.getVersion());
            output.setVersionChanged(input.isVersionChanged());
            return output;
        }
    };

    private static final Function<Deployment, Deployment> DEPLOYMENT_SUMMARY_MAPPER = new Function<Deployment, Deployment>() {
        @Override
        public Deployment apply(final Deployment input) {
            // Clones everything except for the deployment plan.
            Deployment output = new Deployment();
            output.setCreatedTime(input.getCreatedTime());
            output.setDeploymentStatus(input.getDeploymentStatus());
            output.setDeploymentType(input.getDeploymentType());
            output.setDeployTime(input.getDeployTime());
            output.setId(input.getId());
            output.setReleaseId(input.getReleaseId());
            output.setReleaseRev(input.getReleaseRev());
            output.setUser(input.getUser());

            return output;
        }
    };

    private static final Function<Deployment, Deployment> DEPLOYMENT_SUMMARY_MAPPER_WITH_ENV = new Function<Deployment, Deployment>() {
        @Override
        public Deployment apply(final Deployment input) {
            Deployment output = DEPLOYMENT_SUMMARY_MAPPER.apply(input);

            List<EnvDeployment> envDeployments = transform(input.getEnvDeployments(),
                    new Function<EnvDeployment, EnvDeployment>() {
                        @Override
                        public EnvDeployment apply(final EnvDeployment input) {
                            // Don't copy env rollback artifacts
                            return new EnvDeployment(null,
                                    EnvironmentCloneFunction.INSTANCE.apply(input.getEnvironment()),
                                    input.getDeploymentStatus());
                        }
                    });
            output.setEnvDeployments(envDeployments);
            return output;
        }
    };

    @Required
    public void setDeploymentDao(final DeploymentDao deploymentDao) {
        this.deploymentDao = deploymentDao;
    }

    @Required
    public void setClientDeploymentPlanConvertor(final ClientDeploymentPlanConvertor clientDeploymentPlanConvertor) {
        this.clientDeploymentPlanConvertor = clientDeploymentPlanConvertor;
    }

    @Required
    public void setEnvironmentDeploymentSummaryBuilder(
            final EnvironmentDeploymentSummaryBuilder environmentDeploymentSummaryBuilder) {
        this.environmentDeploymentSummaryBuilder = environmentDeploymentSummaryBuilder;
    }

    @Required
    public void setOrgEnvironmentsMap(final OrganisationBeanFactory<List<String>> orgEnvironmentsMap) {
        this.orgEnvironmentsMap = orgEnvironmentsMap;
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }
}