package com.ubs.f35.swift.dao.event;

/**
 * This package contains all the listener interfaces for updates to model objects.  Unfortunately there is no ability in java to have multiple inheritance from a generic interface due to type erasure, so there is a fair amount of code duplication here. 
 */
