package com.ubs.f35.swift.config.model;

import java.util.List;

import javax.annotation.Nullable;

import org.hibernate.Hibernate;
import org.hibernate.collection.internal.PersistentBag;

import com.google.common.base.Objects;

public final class Objects2 {
    private Objects2() {
    }

    /**
     * Custom implementation of equals which handles Lists (because hibernate {@link PersistentBag} has a dreadful
     * implementation of equals).
     */
    public static boolean equal(@Nullable final List<?> a, @Nullable final List<?> b) {
        if (a == b || (a == null && b == null)) {
            return true;
        }
        else if (a == null || b == null) {
            return false;
        }
        else if (a.size() != b.size()) {
            return false;
        }

        for (int i = 0; i < a.size(); i++)
        {
            if (!a.get(i).equals(b.get(i))) {
                return false;
            }
        }
        return true;
    }

    public static boolean equal(@Nullable final Object a, @Nullable final Object b) {
        return Objects.equal(a, b);
    }

    /**
     * For use in toString methods to ensure that the conversion of the object to String does not result in hibernate
     * initialising any objects.
     */
    public static Object toStringSafe(final Object object) {
        return Hibernate.isInitialized(object) ? object : "uninitialised proxy";
    }
}
