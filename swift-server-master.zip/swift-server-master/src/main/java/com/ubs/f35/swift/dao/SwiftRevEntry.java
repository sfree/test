package com.ubs.f35.swift.dao;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Transient;

import org.hibernate.envers.DefaultRevisionEntity;
import org.hibernate.envers.RevisionEntity;
import org.hibernate.envers.RevisionNumber;
import org.hibernate.envers.RevisionTimestamp;

import com.google.common.base.Objects;

/**
 * An extension of {@link DefaultRevisionEntity} which I couldn't extend due to needing to change the
 * {@link GeneratedValue} annotation on {@link #id}
 * 
 */
@SequenceGenerator(name = "oracle_seq", sequenceName = "seq_revision_id")
@Entity
@RevisionEntity(SwiftRevisionListener.class)
public class SwiftRevEntry {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "oracle_seq")
    @RevisionNumber
    private int id;

    @RevisionTimestamp
    private long timestamp;

    @Column(name = "audit_user")
    private String user;

    public int getId() {
        return id;
    }

    public void setId(final int id) {
        this.id = id;
    }

    @Transient
    public Date getRevisionDate() {
        return new Date(timestamp);
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(final long timestamp) {
        this.timestamp = timestamp;
    }

    public String getUser() {
        return user;
    }

    public void setUser(final String user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("timestamp", timestamp)
                .add("user", user)
                .toString();
    }

    /**
     * To avoid serialisation issues.
     */
    @Override
    public SwiftRevEntry clone() {
        SwiftRevEntry clone = new SwiftRevEntry();
        clone.setId(this.getId());
        clone.setTimestamp(this.getTimestamp());
        clone.setUser(this.getUser());
        return clone;
    }
}
