package com.ubs.f35.swift.dao.model;

import java.sql.Timestamp;
import java.util.UUID;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "STATE")
public class StateModel {
    @Id
    UUID id;
    /**
     * If the state is specific to a user
     */
    @Column(name = "OWNER_USER")
    private String user;
    @Column
    @Lob
    @Basic(fetch = FetchType.LAZY)
    private String state;
    @Column
    private Timestamp expiry;

    public UUID getId() {
        return id;
    }

    public void setId(final UUID id) {
        this.id = id;
    }

    public String getUser() {
        return user;
    }

    public void setUser(final String user) {
        this.user = user;
    }

    public String getState() {
        return state;
    }

    public void setState(final String state) {
        this.state = state;
    }

    public Timestamp getExpiry() {
        return expiry;
    }

    public void setExpiry(final Timestamp expiry) {
        this.expiry = expiry;
    }
}