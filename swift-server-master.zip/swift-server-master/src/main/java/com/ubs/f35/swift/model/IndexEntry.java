package com.ubs.f35.swift.model;

import com.google.common.base.Objects;

public class IndexEntry {

    private final String entry;
    private final EntryType type;

    public enum EntryType {
        environment, group, artifact, host, state, status, tag
    }

    public IndexEntry(final String entry, final EntryType type) {
        this.entry = entry;
        this.type = type;
    }

    public final String getEntry() {
        return entry;
    }

    public final EntryType getType() {
        return type;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(entry, type);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof IndexEntry) {
            IndexEntry that = (IndexEntry) object;
            return Objects.equal(this.entry, that.entry)
                    && Objects.equal(this.type, that.type);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("entry", entry)
                .add("type", type)
                .toString();
    }

}
