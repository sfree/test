package com.ubs.f35.swift.service;

import java.util.List;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.HostDao;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.GluDeploymentInvoker;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;

/**
 * Upgrades glu agents using the command execution service.
 * <p>
 * Expects swift-scripts to be deployed and linked in the standard location using envget / envlink
 * <p>
 * It’s also worth pointing out that glu supports upgrading an agent already, but it doesn’t fit into the model of how
 * we deploy with envget / envlink etc.
 * 
 * http://linkedin.github.com/glu/docs/latest/html/agent.html#auto-upgrade
 */
@ManagedResource
public class GluScriptDeployer extends AbstractJmxProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(GluScriptDeployer.class);

    private HostDao hostDao;
    private EnvironmentBeanFactory<GluDeploymentInvoker> gluAgentClientFactory;

    private AgentGluScriptDeployerUtil agentGluScriptDeployerUtil;

    @Required
    public void setHostDao(final HostDao hostDao) {
        this.hostDao = hostDao;
    }

    @Required
    public void setGluAgentClientFactory(final EnvironmentBeanFactory<GluDeploymentInvoker> gluAgentClientFactory) {
        this.gluAgentClientFactory = gluAgentClientFactory;
    }

    @Required
    public void setAgentGluScriptDeployerUtil(final AgentGluScriptDeployerUtil agentGluScriptDeployerUtil) {
        this.agentGluScriptDeployerUtil = agentGluScriptDeployerUtil;
    }

    @Transactional(readOnly = true)
    @ManagedOperation
    @ManagedOperationParameters(value = {
            @ManagedOperationParameter(name = "organisation", description = "organisation which environment belongs to"),
            @ManagedOperationParameter(name = "environment", description = "environment to deploy swift-glu-scripts to all agents"),
            @ManagedOperationParameter(name = "targetFile", description = "The name of the target file eg swift-host-monitor-scripts-2.0.0.jar"),
            @ManagedOperationParameter(name = "downloadUrl", description = "The download url of the script jar") })
    public String deployScripts(final String organisation, final String environment, final String targetFile,
            final String downloadUrl) {
        return executeOperation(new Callable<String>() {
            @Override
            public String call() throws Exception {
                final Environment env = new Environment(environment, organisation);
                LOG.info("Deploying scripts to all agents in environment {}", env);
                List<Host> hosts = hostDao.loadByEnvironment(env);

                List<AgentCallable> operations = Lists.transform(hosts, new Function<Host, AgentCallable>() {
                    @Override
                    public AgentCallable apply(final Host host) {
                        return new AgentCallable(host.getHostname()) {
                            @Override
                            public String call() throws Exception {
                                deployScriptsInternal(env, host.getHostname(), targetFile, downloadUrl);
                                return "Scripts deployed";
                            }
                        };
                    }
                });

                String result = executeOperations(operations);

                return "Deployed scripts to " + hosts.size() + " agents.\n" + result;
            }
        });
    }

    @Transactional(readOnly = true)
    @ManagedOperation
    @ManagedOperationParameters(value = {
            @ManagedOperationParameter(name = "organisation", description = "organisation which environment belongs to"),
            @ManagedOperationParameter(name = "environment", description = "environment to deploy swift-glu-scripts to"),
            @ManagedOperationParameter(name = "agent", description = "agent to deploy swift-glu-scripts to"),
            @ManagedOperationParameter(name = "targetFile", description = "The name of the target file eg swift-host-monitor-scripts-2.0.0.jar"),
            @ManagedOperationParameter(name = "downloadUrl", description = "The download url of the script jar") })
    public String deployScripts(final String organisation, final String environment, final String agent,
            final String targetFile, final String downloadUrl) {
        return executeOperation(new Callable<String>() {
            @Override
            public String call() throws Exception {
                return deployScriptsInternal(new Environment(environment, organisation), agent, targetFile, downloadUrl);
            }
        });
    }

    private String deployScriptsInternal(final Environment environment, final String agent, final String targetFile,
            final String downloadUrl) {
        GluDeploymentInvoker gluAgentInvoker = gluAgentClientFactory.get(environment);

        agentGluScriptDeployerUtil.deployScripts(gluAgentInvoker, agent, targetFile, downloadUrl);

        return "Deployed scripts to " + agent + ".";
    }
}
