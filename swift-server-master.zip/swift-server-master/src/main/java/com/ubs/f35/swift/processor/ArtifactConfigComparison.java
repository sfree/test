package com.ubs.f35.swift.processor;

import com.google.common.base.Objects;

public class ArtifactConfigComparison {
    private final ArtifactConfigId artifactConfigId;
    private final String baseLineVersion;
    private final String targetVersion;
    // not this is a boolean because the report only highlights differences, not where the version can potentially be
    // the same.
    private final boolean targetAhead;

    public ArtifactConfigComparison(final ArtifactConfigId artifactConfigId, final String baseLineVersion,
            final String targetVersion, final boolean targetAhead) {
        this.artifactConfigId = artifactConfigId;
        this.baseLineVersion = baseLineVersion;
        this.targetVersion = targetVersion;
        this.targetAhead = targetAhead;
    }

    public ArtifactConfigId getArtifactConfigId() {
        return artifactConfigId;
    }

    public String getBaseLineVersion() {
        return baseLineVersion;
    }

    public String getTargetVersion() {
        return targetVersion;
    }

    public boolean getTargetAhead() {
        return targetAhead;
    }

    public static class ArtifactConfigId {
        private final String groupId;
        private final String artifactId;
        private final String name;

        public ArtifactConfigId(final String groupId, final String artifactId, final String name) {
            this.groupId = groupId;
            this.artifactId = artifactId;
            this.name = name;
        }

        public String getGroupId() {
            return groupId;
        }

        public String getArtifactId() {
            return artifactId;
        }

        public String getName() {
            return name;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(groupId, artifactId, name);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof ArtifactConfigId) {
                ArtifactConfigId that = (ArtifactConfigId) object;
                return Objects.equal(this.groupId, that.groupId)
                        && Objects.equal(this.artifactId, that.artifactId)
                        && Objects.equal(this.name, that.name);
            }
            return false;
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this)
                    .add("groupId", groupId)
                    .add("artifactId", artifactId)
                    .add("name", name)
                    .toString();
        }
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(artifactConfigId, baseLineVersion, targetVersion, targetAhead);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ArtifactConfigComparison) {
            ArtifactConfigComparison that = (ArtifactConfigComparison) object;
            return Objects.equal(this.artifactConfigId, that.artifactConfigId)
                    && Objects.equal(this.baseLineVersion, that.baseLineVersion)
                    && Objects.equal(this.targetVersion, that.targetVersion)
                    && Objects.equal(this.targetAhead, that.targetAhead);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("artifactConfigId", artifactConfigId)
                .add("baseLineVersion", baseLineVersion)
                .add("targetVersion", targetVersion)
                .add("targetState", targetAhead)
                .toString();
    }

}
