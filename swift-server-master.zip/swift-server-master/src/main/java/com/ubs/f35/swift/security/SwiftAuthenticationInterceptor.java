package com.ubs.f35.swift.security;

import java.io.IOException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.ubs.f35.core.AuthenticationPrincipal;
import com.ubs.f35.core.auth.UserValidationException;
import com.ubs.f35.swift.state.OperationContextProvider;

/**
 * Authenticates a user.
 * 
 * @author stephelu
 * 
 */
public class SwiftAuthenticationInterceptor extends HandlerInterceptorAdapter {
    private static final Logger LOG = LoggerFactory.getLogger(SwiftAuthenticationInterceptor.class);

    public static final String UBS_NEO_AUTH = "LWSTOKEN";
    public static final String TOKEN_SEPARATOR = ":";

    private WebSsoAuthProvider userValidator;
    private OperationContextProvider opContextProvider;

    @Required
    public void setUserValidator(final WebSsoAuthProvider userValidator) {
        this.userValidator = userValidator;
    }

    @Required
    public void setOpContextProvider(final OperationContextProvider opContextProvider) {
        this.opContextProvider = opContextProvider;
    }

    @Override
    public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler)
            throws Exception {

        String authCookie = null;
        if (!ArrayUtils.isEmpty(request.getCookies())) {
            for (Cookie requestCookie : request.getCookies()) {
                if (UBS_NEO_AUTH.equals(requestCookie.getName())) {
                    authCookie = requestCookie.getValue();
                    break;
                }
            }
        }
        if (!StringUtils.hasText(authCookie)) {
            sendError(response, HttpServletResponse.SC_UNAUTHORIZED, "Missing " + UBS_NEO_AUTH + " token");
            return false;
        }

        String ipAddress = getRemoteAddress(request);
        AuthenticationPrincipal principal;
        try {
            principal = userValidator.getPrincipal(authCookie);
        } catch (UserValidationException ex) {
            sendError(response, HttpServletResponse.SC_UNAUTHORIZED, "Invalid token");
            return false;
        }

        opContextProvider.setCurrentUser(principal);

        return true;
    }

    @Override
    public void afterCompletion(final HttpServletRequest request, final HttpServletResponse response,
            final Object handler, final Exception ex)
            throws Exception {
        opContextProvider.reset();
    }

    private void sendError(final HttpServletResponse response, final int errorCore, final String message)
            throws IOException {
        LOG.info("Blocking access.  Sending {} : {}", errorCore, message);
        response.sendError(errorCore, message);
    }

    private String getRemoteAddress(final HttpServletRequest request) {
        String address;
        try {
            address = request.getRemoteAddr();

            if (address != null) {
                return address;
            }
        } catch (Exception e) {
            LOG.warn("Unable to get remote  address", e);
        }
        return "UNKNOWN_ADDRESS";
    }
}
