package com.ubs.f35.swift.deploy.glu.action;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

/**
 * Groups a set of actions which can be included or excluded from a deployment plan. These actions are all intended to
 * be executed sequentially. A failure to execute one action will prevent further actions from executing.
 * <p>
 * 
 * @deprecated Would remove, but would break unmarshalling of saved deployment plans.
 */
@Deprecated
public class RelatedActions extends SequentialAction {

    public RelatedActions(@JsonProperty(value = "included") final List<Action> includedActions) {
        super(null, null, includedActions);
    }
}
