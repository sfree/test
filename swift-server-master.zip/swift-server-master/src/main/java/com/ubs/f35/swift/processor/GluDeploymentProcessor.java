package com.ubs.f35.swift.processor;

import static com.ubs.f35.swift.processor.ProcessorUtil.resolveEnvironment;
import static com.ubs.f35.swift.processor.ProcessorUtil.resolveEnvironments;
import static com.ubs.f35.swift.processor.ProcessorUtil.transform;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionOperations;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Function;
import com.google.common.collect.SetMultimap;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseDefinitionDao;
import com.ubs.f35.swift.dao.StateStore;
import com.ubs.f35.swift.dao.model.DeploymentProcess;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.client.action.ClientDeploymentPlan;
import com.ubs.f35.swift.deploy.client.action.ClientDeploymentPlanConvertor;
import com.ubs.f35.swift.deploy.client.rollback.RollbackRequest;
import com.ubs.f35.swift.deploy.glu.DeploymentExecutor;
import com.ubs.f35.swift.deploy.glu.DeploymentListener;
import com.ubs.f35.swift.deploy.glu.DeploymentService;
import com.ubs.f35.swift.deploy.glu.GluReleaseManager;
import com.ubs.f35.swift.deploy.glu.action.Action;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlan;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlanStrategy;
import com.ubs.f35.swift.deploy.glu.plan.GluDeploymentPlanGenerator;
import com.ubs.f35.swift.deploy.template.DeploymentTemplateGenerator;
import com.ubs.f35.swift.deploy.template.DeploymentTemplateValidator;
import com.ubs.f35.swift.deploy.template.model.DeploymentTemplate;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;
import com.ubs.f35.swift.messaging.CancelDeploymentSender;
import com.ubs.f35.swift.model.ArtifactInstanceId;
import com.ubs.f35.swift.model.EnvironmentId;
import com.ubs.f35.swift.model.JsonObjectMapper;
import com.ubs.f35.swift.model.ManualDeploymentRequest;
import com.ubs.f35.swift.model.ReleaseLogicException;
import com.ubs.f35.swift.model.TargetedInstanceDeployment;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.state.OperationContextProvider;
import com.ubs.f35.swift.util.EnvironmentCloneFunction;
import com.ubs.swift.deployment.api.DeploymentProcessor;

/**
 * Creating a deployment follows this pattern for each target environment.
 * <ul>
 * <li>Update environment model to reflect desired target state</li>
 * <li>Commit updated environment model back to store</li>
 * <li>Execute actions to resolve the delta of differences between the current state and new desired state</li>
 * </ul>
 * 
 * @author stephelu
 * 
 */

@Transactional
@Controller
@RequestMapping(value = "/api/deployment")
public class GluDeploymentProcessor implements DeploymentProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(GluDeploymentProcessor.class);

    private ReleaseDefinitionDao releaseDefinitionDao;
    private GluDeploymentPlanGenerator deploymentPlanGenerator;
    private ClientDeploymentPlanConvertor clientDeploymentPlanConvertor;
    private GluReleaseManager gluReleaseManager;
    private AuthorisationController authorisationController;
    private DeploymentService deploymentService;
    private EnvironmentDao environmentDao;
    private DeploymentTemplateGenerator deploymentTemplateGenerator;
    private DeploymentTemplateValidator deploymentTemplateValidator;
    private StateStore stateStore;
    private DeploymentExecutor deploymentExecutor;
    private OperationContextProvider contextProvider;
    private TransactionOperations transactionTemplate;
    private CancelDeploymentSender cancelDeploymentSender;

    @RequestMapping(value = "/release/{releaseId}", method = RequestMethod.GET)
    public ClientDeploymentPlan generateReleasePlan(@PathVariable final Integer releaseId,
            @RequestParam(value = "environment", required = true) final List<String> environments,
            @RequestParam(value = "revision", required = false) final Integer revision,
            @RequestParam(value = "deploymentContextId", required = false) final UUID deploymentContextId) {
        ReleaseDefinition releaseDef = loadLatestReleaseOrRevision(releaseId, revision);

        List<TargetedInstanceDeployment> deploymentTargets = null;
        if (deploymentContextId != null) {
            ReleaseDeloymentRequest request = stateStore.load(deploymentContextId, ReleaseDeloymentRequest.class);
            deploymentTargets = request.getDeploymentTargets();
        }

        Deployment deployment = generateReleaseDeployment(releaseDef, environments, deploymentTargets);

        return clientDeploymentPlanConvertor.convert(deployment.getDeploymentPlan());
    }

    protected Deployment generateReleaseDeployment(final ReleaseDefinition releaseDef, final List<String> environments,
            final List<TargetedInstanceDeployment> deploymentTargets) {
        DeploymentProcess deploymentProcess = DeploymentProcess.valueOf(releaseDef.getDeploymentProcess());
        DeploymentTemplate template;
        if (deploymentProcess == DeploymentProcess.Custom) {
            template = JsonObjectMapper.getInstance().readValue(releaseDef.getDeploymentTemplate(),
                    DeploymentTemplate.class);
            deploymentTemplateValidator.validate(releaseDef.getArtifacts(), template);
        } else {
            String org = releaseDef.getTeam().getOrganisation().getName();
            template = deploymentTemplateGenerator.generateDeploymentTemplate(org, releaseDef.getArtifacts(),
                    deploymentProcess);
        }

        List<Environment> envIds = resolveEnvironments(environmentDao, environments, releaseDef);

        return deploymentPlanGenerator
                .generateReleaseDeploymentPlan(releaseDef, envIds, template, deploymentTargets);
    }

    /**
     * Applies the changes in the release to the environment configuration without actually deploying. This can be used
     * where the deployment plan generated by swift isn't suitable and the user wishes to manually update.
     * 
     * @param releaseId
     */
    @RequestMapping(value = "/release/{releaseId}/apply", method = RequestMethod.POST)
    public void applyRelease(@PathVariable final Integer releaseId,
            @RequestBody final ManualDeploymentRequest manualDeploymentRequest) {
        LOG.info("Manually deploying release {}", releaseId);

        Deployment deployment = deploymentService.loadDeploymentToDeploy(manualDeploymentRequest.getPlanId(), true);

        gluReleaseManager.verifyProductionWarningsAcknowledged(deployment, manualDeploymentRequest);

        // deployment service checks if the deployment is manual, so status is updated first.
        deployment.setDeploymentStatus(DeploymentStatus.MANUAL);

        SetMultimap<Environment, NexusArtifact> selectedArtifacts = deploymentService.updateSelectedPlanItems(
                deployment, manualDeploymentRequest.getExecute());

        gluReleaseManager.manualRelease(deployment, selectedArtifacts);
    }

    /**
     * Generates a deployment plan which will perform the rollback of the specified artifacts. Note that the rollback
     * changes are not applied until the deployment plan is executed.
     * 
     * @param environment
     * @param releaseId
     * @param artifacts
     * @return
     */
    @RequestMapping(value = "/rollback/{environment}/{releaseId}", method = RequestMethod.POST)
    @ResponseBody
    public String generateReleaseRollbackPlan(@PathVariable final String environment,
            @PathVariable final Integer releaseId,
            @RequestBody final RollbackRequest rollbackRequest) {
        List<Artifact> artifacts = rollbackRequest.getArtifacts();
        if (artifacts.isEmpty()) {
            throw new IllegalArgumentException("Please specify at least one artifact to rollback");
        }

        ReleaseDefinition releaseDef = releaseDefinitionDao.load(releaseId);

        Environment env = resolveEnvironment(environmentDao, environment, releaseDef);
        authorisationController.checkEnvironmentAccess(env);

        // Production warnings relating to this rollback are not checked here. They were presented to the user on the
        // rollback screen, but the user doesn't need to acknowledge until they actually execute the deployment.

        // TODO could we potentially have a custom rollback template attached to the release as well?
        String org = releaseDef.getTeam().getOrganisation().getName();
        DeploymentTemplate rollbackTemplate = deploymentTemplateGenerator.generateDeploymentTemplate(org, artifacts,
                DeploymentProcess.RollingUpgrade);

        DeploymentPlan deploymentPlan = deploymentPlanGenerator
                .generateReleaseRollbackPlan(releaseDef, rollbackRequest, env, rollbackTemplate);

        return deploymentPlan.getId().toString();
    }

    /**
     * Note this doesn't modify anything. Was originally a GET request, but the number of ids exceeded sensible (and
     * enforced) url length limits. Ids are now being posted as the requset body.
     */
    @RequestMapping(value = "/process", method = RequestMethod.POST)
    public ClientDeploymentPlan generateProcessPlan(
            @RequestBody final List<String> ids,
            @RequestParam final DeploymentAction deploymentAction,
            @RequestParam(defaultValue = "false") final boolean includeDependencies) {

        Deployment deployment = generateAdHocDeployment(ids, deploymentAction, includeDependencies);

        return clientDeploymentPlanConvertor.convert(deployment.getDeploymentPlan());
    }

    @RequestMapping(value = "/execute/{deploymentAction}", method = RequestMethod.POST)
    @ResponseBody
    @Override
    @Transactional(propagation = Propagation.NEVER)
    public String executeDeployment(
            @PathVariable final com.ubs.swift.deployment.model.DeploymentAction deploymentAction,
            @RequestBody final List<String> ids) {

        RestDeploymentExecutor adHocDeploymentExecutor = new RestDeploymentExecutor() {
            @Override
            public void executeDeployment(final Deployment deployment, final DeploymentListener deploymentListener) {
                deploymentExecutor.executeDeployment(deployment, deploymentListener);
            }
        };
        return generateAndExecuteDeployment(adHocDeploymentExecutor, new DeploymentGenerator() {
            @Override
            public Deployment generate() {
                return generateAdHocDeployment(ids, mapEnum(deploymentAction, DeploymentAction.class), false);
            }
        });

    }

    @Override
    @RequestMapping(value = "/execute/release/{releaseId}/{environment}", method = RequestMethod.POST)
    @ResponseBody
    @Transactional(propagation = Propagation.NEVER)
    public String executeDeployment(
            @PathVariable final Integer releaseId,
            @PathVariable final String environment) {

        RestDeploymentExecutor releaseDeploymentExecutor = new RestDeploymentExecutor() {
            @Override
            public void executeDeployment(final Deployment deployment, final DeploymentListener deploymentListener) {
                gluReleaseManager.deployRelease(deployment, deploymentListener);
            }
        };

        return generateAndExecuteDeployment(releaseDeploymentExecutor, new DeploymentGenerator() {
            @Override
            public Deployment generate() {
                ReleaseDefinition releaseDef = releaseDefinitionDao.load(releaseId);

                return generateReleaseDeployment(releaseDef, Arrays.asList(environment), null);
            }
        });
    }

    @RequestMapping(value = "/cancel/{deploymentId}", method = RequestMethod.DELETE)
    public void cancelDeployment(@PathVariable final String deploymentId) {
        LOG.info("Request to cancel deployment {}", deploymentId);

        UUID id = UUID.fromString(deploymentId);

        Deployment deployment = deploymentService.loadDeployment(id);

        if (deployment.getDeploymentStatus() != DeploymentStatus.EXECUTING) {
            throw new ReleaseLogicException("Deployment not running.  Current state "
                    + deployment.getDeploymentStatus());
        } else if (!contextProvider.getCurrentUser().equals(deployment.getUser())) {
            throw new ReleaseLogicException("Only the deployer may cancel their deployments.");
        }

        // Broadcast to all swift nodes that this deployment needs to be cancelled.
        LOG.info("Broadcasting cancel deployment request {}", deploymentId);
        cancelDeploymentSender.cancelDeployment(id);
    }

    @RequestMapping(value = "/running/{organisation}", method = RequestMethod.GET)
    public List<Deployment> getActiveDeployments(@PathVariable final String organisation) {
        LOG.info("Loading running deployments for organisation {}", organisation);

        // Model has a circular reference from Deployment -> EnvDeployment -> Deployment so mapping only required data
        return transform(deploymentService.getRunningDeployments(organisation), new Function<Deployment, Deployment>() {
            @Override
            public Deployment apply(final Deployment input) {
                Deployment result = new Deployment();
                result.setCreatedTime(input.getCreatedTime());
                result.setDeploymentType(input.getDeploymentType());
                result.setDeployTime(input.getDeployTime());
                result.setId(input.getId());
                result.setReleaseId(input.getReleaseId());
                result.setUser(input.getUser());

                result.setEnvDeployments(transform(input.getEnvDeployments(),
                        new Function<EnvDeployment, EnvDeployment>() {
                            @Override
                            public EnvDeployment apply(final EnvDeployment input) {
                                EnvDeployment result = new EnvDeployment();
                                result.setEnvironment(EnvironmentCloneFunction.INSTANCE.apply(input.getEnvironment()));
                                return result;
                            }
                        }));
                return result;
            }
        });
    }

    private String generateAndExecuteDeployment(final RestDeploymentExecutor deploymentExecutor,
            final DeploymentGenerator deploymentGenerator) {

        // Generate the deployment as a transaction before executing. This will ensure that any exceptions propogated
        // during execution do not cause a rollback
        final Deployment deployment = transactionTemplate.execute(new TransactionCallback<Deployment>() {
            @Override
            public Deployment doInTransaction(final TransactionStatus status) {
                Deployment deployment = deploymentGenerator.generate();
                // Anyone can generate a deployment. DeploymentService will ensure the user is entitled to execute
                deployment = deploymentService.loadDeploymentToDeploy(deployment.getId(), true);
                deploymentService.createArtifactDeploymentHistory(deployment);

                return deployment;
            }
        });

        final AtomicReference<DeploymentStatus> deploymentStatusRef = new AtomicReference<>();
        final CountDownLatch deploymentCompleteWatch = new CountDownLatch(1);
        deploymentExecutor.executeDeployment(deployment, new DeploymentListener() {

            @Override
            public void deploymentComplete(final DeploymentStatus status) {
                deploymentStatusRef.set(status);
                deploymentCompleteWatch.countDown();
            }

            @Override
            public void deploymentActionChanged(final Action action) {
                // Don't care.
            }
        });

        try {
            deploymentCompleteWatch.await();
        } catch (InterruptedException e) {
            throw new RuntimeException("Deployment failed " + deployment.getId(), e);
        }
        if (deploymentStatusRef.get() == DeploymentStatus.COMPLETED) {
            return deployment.getId().toString();
        } else {
            throw new RuntimeException("Deployment failed " + deployment.getId());
        }
    }

    interface DeploymentGenerator {
        Deployment generate();
    }

    private DeploymentAction mapEnum(final com.ubs.swift.deployment.model.DeploymentAction enumValue,
            final Class<DeploymentAction> enumType) {
        return Enum.valueOf(enumType, enumValue.name());
    }

    private Deployment generateAdHocDeployment(final List<String> ids, final DeploymentAction deploymentAction,
            final boolean includeDependencies) {
        Set<EnvironmentId> environments = new HashSet<EnvironmentId>();
        List<String> mountPoints = new ArrayList<String>();

        for (String id : ids) {
            ArtifactInstanceId instanceId = ArtifactInstanceId.parse(id);
            environments.add(instanceId.getEnvironment());
            mountPoints.add(instanceId.getMountPoint());
        }

        Assert.isTrue(environments.size() <= 1, "Deployments may only cover a single environment");

        Environment environment = resolveEnvironment(environmentDao, environments.iterator().next());

        DeploymentPlanStrategy strategy = new DeploymentPlanStrategy(includeDependencies);

        Deployment deployment = deploymentPlanGenerator.generateAdhocDeploymentPlan(
                mountPoints, deploymentAction, environment, strategy);
        return deployment;
    }

    @RequestMapping(value = "/plan/{planId}", method = RequestMethod.GET)
    public ClientDeploymentPlan retrievePlan(@PathVariable final String planId) {

        Deployment deployment = deploymentService.loadDeploymentToDeploy(UUID.fromString(planId), true);

        return clientDeploymentPlanConvertor.convert(deployment.getDeploymentPlan());

    }

    private ReleaseDefinition loadLatestReleaseOrRevision(final Integer releaseId, final Integer revision) {
        if (revision == null) {
            return releaseDefinitionDao.load(releaseId);
        } else {
            return releaseDefinitionDao.loadRevision(releaseId, revision);
        }
    }

    interface RestDeploymentExecutor {

        void executeDeployment(Deployment deployment, DeploymentListener deploymentListener);
    }

    @Required
    public void setReleaseDefinitionDao(final ReleaseDefinitionDao releaseDefinitionDao) {
        this.releaseDefinitionDao = releaseDefinitionDao;
    }

    @Required
    public void setDeploymentPlanGenerator(final GluDeploymentPlanGenerator deploymentPlanGenerator) {
        this.deploymentPlanGenerator = deploymentPlanGenerator;
    }

    @Required
    public void setClientDeploymentPlanConvertor(final ClientDeploymentPlanConvertor clientDeploymentPlanConvertor) {
        this.clientDeploymentPlanConvertor = clientDeploymentPlanConvertor;
    }

    @Required
    public void setGluReleaseManager(final GluReleaseManager gluReleaseManager) {
        this.gluReleaseManager = gluReleaseManager;
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

    @Required
    public void setDeploymentService(final DeploymentService deploymentService) {
        this.deploymentService = deploymentService;
    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }

    @Required
    public void setDeploymentTemplateGenerator(final DeploymentTemplateGenerator deploymentTemplateGenerator) {
        this.deploymentTemplateGenerator = deploymentTemplateGenerator;
    }

    @Required
    public void setDeploymentTemplateValidator(final DeploymentTemplateValidator deploymentTemplateValidator) {
        this.deploymentTemplateValidator = deploymentTemplateValidator;
    }

    @Required
    public void setStateStore(final StateStore stateStore) {
        this.stateStore = stateStore;
    }

    @Required
    public void setDeploymentExecutor(final DeploymentExecutor deploymentExecutor) {
        this.deploymentExecutor = deploymentExecutor;
    }

    @Required
    public void setTransactionTemplate(final TransactionOperations transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }

    @Required
    public void setContextProvider(final OperationContextProvider contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Required
    public void setCancelDeploymentSender(final CancelDeploymentSender cancelDeploymentSender) {
        this.cancelDeploymentSender = cancelDeploymentSender;
    }
}
