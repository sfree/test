package com.ubs.f35.swift.config.model;

public interface MountPointScheme {

    /**
     * The flawed scheme initially used by swift to uniquely identify a mount point. Because the mountpoints had already
     * been deployed with this scheme, those deployments still need to be supported.
     * https://github.ldn.swissbank.com/NeoSwift/swift-client/issues/433
     */
    int ARTIFACT_INSTANCE_NAME = 0;
    /**
     * The improved scheme which includes the group id in the mount point to ensure a unique mountpoint when the same
     * artifact id exists in multiple groups.
     */
    int GROUP_ARTIFACT_INSTANCE_NAME = 1;

}
