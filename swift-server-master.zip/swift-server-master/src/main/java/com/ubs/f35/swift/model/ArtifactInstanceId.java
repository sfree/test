package com.ubs.f35.swift.model;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.dao.model.Organisation;

/**
 * Uniquely identifies an artifact instance across all environments.
 * 
 * @author stephelu
 * 
 */
public class ArtifactInstanceId {
    private static final String DELIMITER = "/";
    private final EnvironmentId environment;
    private final String mountPoint;

    public ArtifactInstanceId(final EnvironmentId environment, final String mountPoint) {
        this.environment = environment;
        this.mountPoint = mountPoint;
    }

    public EnvironmentId getEnvironment() {
        return environment;
    }

    public String getMountPoint() {
        return mountPoint;
    }

    public static ArtifactInstanceId create(final EnvironmentId environment, final String mountPoint) {
        return new ArtifactInstanceId(environment, mountPoint);
    }

    public static ArtifactInstanceId create(final Environment environment, final String mountPoint) {
        return new ArtifactInstanceId(
                new EnvironmentId(environment.getOrganisation().getName(), environment.getName()), mountPoint);
    }

    public static ArtifactInstanceId parse(final String id) {
        String[] parts = id.split(DELIMITER, 3);
        Organisation organisation = new Organisation();
        organisation.setName(parts[0]);
        return new ArtifactInstanceId(new EnvironmentId(parts[0], parts[1]), parts[2]);
    }

    @Override
    public String toString() {
        return buildId(environment.getOrganisationName(), environment.getEnvironmentName(), mountPoint);
    }

    public static String buildId(final Environment environment, final String mountPoint) {
        return buildId(environment.getOrganisation().getName(), environment.getName(), mountPoint);
    }

    private static String buildId(final String org, final String environment, final String mountPoint) {
        return org + DELIMITER + environment + DELIMITER + mountPoint;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(environment, mountPoint);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ArtifactInstanceId) {
            ArtifactInstanceId that = (ArtifactInstanceId) object;
            return Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.mountPoint, that.mountPoint);
        }
        return false;
    }
}
