package com.ubs.f35.swift.environment.model.glu;

import com.google.common.base.Objects;

public class Script {
    private final String pckage;
    private final String script;
    private final String version;

    public Script(final String pckage, final String script, final String version) {
        this.pckage = pckage;
        this.version = version;
        this.script = script;
    }

    public String getVersion() {
        return version;
    }

    public String getScript() {
        return script;
    }

    public String getPckage() {
        return pckage;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("pckage", pckage)
                .add("script", script)
                .add("version", version)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pckage, script, version);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof Script) {
            Script that = (Script) object;
            return Objects.equal(this.pckage, that.pckage)
                    && Objects.equal(this.script, that.script)
                    && Objects.equal(this.version, that.version);
        }
        return false;
    }
}