package com.ubs.f35.swift.util;

import com.google.common.base.Function;
import com.ubs.f35.swift.config.model.Host;

public class HostNameFunction implements Function<Host, String> {
    public static final HostNameFunction INSTANCE = new HostNameFunction();

    @Override
    public String apply(final Host input) {
        return input.getHostname();
    }
}
