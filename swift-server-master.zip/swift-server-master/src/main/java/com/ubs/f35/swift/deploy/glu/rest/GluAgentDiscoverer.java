package com.ubs.f35.swift.deploy.glu.rest;

import java.util.List;

import org.apache.zookeeper.KeeperException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.collect.HashMultimap;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.DuplicateHostException;
import com.ubs.f35.swift.dao.HostDao;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.security.UserConstants;
import com.ubs.f35.swift.state.OperationContextProvider;

/**
 * Discovers new agents and registers them as {@link Host} instances which can be configured in swift.
 * 
 * @author stephelu
 * 
 */
public class GluAgentDiscoverer {
    private static final Logger LOG = LoggerFactory.getLogger(GluAgentDiscoverer.class);

    private HostDao hostDao;
    private OperationContextProvider opContextProvider;
    private EnvironmentBeanFactory<ZooKeeperClient> zooKeeperClientFactory;
    private EnvironmentBeanFactory<String> zookeeperRootFactory;

    private final HashMultimap<Environment, String> knownAgents = HashMultimap.create();

    public synchronized void discover(final Environment environmentObj) throws KeeperException, InterruptedException {
        String environment = environmentObj.getName();

        try {
            opContextProvider.setCurrentUser(UserConstants.SWIFT_PRINCIPAL);

            String baseAgentPath = zookeeperRootFactory.get(environmentObj) + "/agents/fabrics/" + environment
                    + "/instances";

            LOG.info("Checking for new agents for environment {}", environment);

            List<String> agents = zooKeeperClientFactory.get(environmentObj).getChildren(baseAgentPath);

            for (String agent : agents) {
                if (!knownAgents.containsEntry(environmentObj, agent)) {
                    try {
                        register(agent, environmentObj);
                        knownAgents.put(environmentObj, agent);
                    } catch (DuplicateHostException ex) {
                        LOG.warn("Host {} is already registered against a different environment", agent, ex);
                    }
                }
            }
        } finally {
            opContextProvider.reset();
        }
    }

    public void removeAgent(final Environment environment, final String agent) {
        knownAgents.remove(environment, agent);
    }

    private void register(final String agent, final Environment environmentObj) throws DuplicateHostException {
        Host host = new Host();
        host.setHostname(agent);
        host.setEnvironment(environmentObj);

        hostDao.saveIfNew(host);
    }

    @Required
    public void setHostDao(final HostDao hostDao) {
        this.hostDao = hostDao;
    }

    @Required
    public void setZooKeeperClientFactory(final EnvironmentBeanFactory<ZooKeeperClient> zooKeeperClientFactory) {
        this.zooKeeperClientFactory = zooKeeperClientFactory;
    }

    @Required
    public void setOpContextProvider(final OperationContextProvider opContextProvider) {
        this.opContextProvider = opContextProvider;
    }

    @Required
    public void setZookeeperRootFactory(final EnvironmentBeanFactory<String> zookeeperRootFactory) {
        this.zookeeperRootFactory = zookeeperRootFactory;
    }

}