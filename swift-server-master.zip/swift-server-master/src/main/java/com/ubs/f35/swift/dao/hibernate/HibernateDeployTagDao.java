package com.ubs.f35.swift.dao.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Functions;
import com.ubs.f35.swift.config.model.DeployTag;
import com.ubs.f35.swift.config.model.DeployTagable;
import com.ubs.f35.swift.dao.DeployTagDao;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.model.Environment;

public class HibernateDeployTagDao extends HibernateDaoSupport implements DeployTagDao {

    private static final Logger LOG = LoggerFactory.getLogger(HibernateDeployTagDao.class);

    private EnvironmentDao environmentDao;

    @SuppressWarnings("unchecked")
    @Override
    public List<DeployTag> loadByEnvironment(final Environment environment) {
        Environment persistentEnv = environmentDao.loadEnvironment(environment);
        return getSession().createCriteria(DeployTag.class)
                .add(Restrictions.eq("environment", persistentEnv))
                .list();
    }

    @Override
    public DeployTag load(final DeployTag tag) {
        Environment persistentEnv = environmentDao.loadEnvironment(tag.getEnvironment());
        return load(DeployTag.class, new DeployTag(persistentEnv, tag.getTag()));
    }

    @VisibleForTesting
    void save(final DeployTag tag) {
        getSession().save(tag);
    }

    void mergeDeployTags(final DeployTagable tagable) {
        if (!CollectionUtils.isEmpty(tagable.getDeployTags())) {
            for (DeployTag tag : tagable.getDeployTags()) {
                // TODO not required if the client always passes in environment id rather than env / org names
                tag.setEnvironment(environmentDao.loadEnvironment(tag.getEnvironment()));
            }
        }
        tagable.setDeployTags(mergeCollection(DeployTag.class, tagable.getDeployTags(), Functions.<DeployTag>identity()));
    }

    /**
     * Scheduled job
     */
    @Transactional
    public void purgeOrphanedDeployTags() {

        Query query = getSession()
                .createQuery(
                        "delete from DeployTag t where t in "
                                + "( from  DeployTag t1 where "
                                + "(t1.tag, t1.environment) not in "
                                + "( select hosttag.tag, hosttag.environment from Host h join h.deployTags hosttag ) "
                                + " and (t1.tag, t1.environment) not in "
                                + "( select act.tag, act.environment from ArtifactConfig a join a.deployTags act )"
                                + ")");

        int deleteCount = query.executeUpdate();
        LOG.info("Purged {} orphaned deployTags", deleteCount);

    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }
}
