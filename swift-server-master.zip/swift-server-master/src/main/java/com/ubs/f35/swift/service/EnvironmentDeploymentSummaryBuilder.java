package com.ubs.f35.swift.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.base.Function;
import com.google.common.base.Optional;
import com.google.common.base.Predicate;
import com.google.common.base.Stopwatch;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Iterables;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentType;
import com.ubs.f35.swift.dao.DeploymentDao;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseDefinitionDao;
import com.ubs.f35.swift.dao.model.EnvDeployment;
import com.ubs.f35.swift.model.EnvironmentDeploymentSummary;
import com.ubs.f35.swift.model.EnvironmentDeploymentSummary.EnvironmentDeploymentStatus;
import com.ubs.f35.swift.model.EnvironmentDeploymentSummary.StaleArtifact;
import com.ubs.f35.swift.model.ReleaseDeploymentSummary;

/**
 * Builds {@link EnvironmentDeploymentSummary} objects by finding the latest deployment state of a release in a given
 * environment or in all environments.
 * 
 * @author levyjo
 * 
 */
public class EnvironmentDeploymentSummaryBuilder {
    private static final Logger LOG = LoggerFactory.getLogger(EnvironmentDeploymentSummaryBuilder.class);

    private DeploymentDao deploymentDao;
    private ReleaseDefinitionDao releaseDefinitionDao;

    /**
     * Returns the {@link EnvironmentDeploymentSummary} for the given release in the given environment
     * 
     * @param releaseId
     * @param environment
     * @return {@link EnvironmentDeploymentSummary}
     */
    public EnvironmentDeploymentSummary getEnvironmentDeploymentSummary(final Integer releaseId,
            final String environment) {

        EnvDeployment deployment = deploymentDao.getLatestDeploymentForReleaseInEnv(releaseId, environment);
        if (deployment == null) {
            return null;
        }

        Integer latestRevId = releaseDefinitionDao.getLatestRevisionId(releaseId);
        ReleaseDefinition latestReleaseDef = releaseDefinitionDao.load(releaseId);

        return getEnvironmentDeploymentSummary(releaseId, latestRevId,
                latestReleaseDef, deployment);
    }

    /**
     * Returns the latest deployment status of the given release in each environment where deployments have taken place.
     * 
     * @param releaseId
     * @param revision
     *            The revision of the release to compare against
     * @return {@link List} of {@link EnvironmentDeploymentSummary}
     */
    public List<EnvironmentDeploymentSummary> getEnvironmentDeploymentSummaries(final Integer releaseId,
            final Integer revision) {

        Integer currentRevision;
        if (revision == null) {
            currentRevision = releaseDefinitionDao.getLatestRevisionId(releaseId);
        } else {
            currentRevision = revision;
        }
        ReleaseDefinition releaseDef = releaseDefinitionDao.loadRevision(releaseId, currentRevision);
        List<EnvDeployment> latestDeployments = deploymentDao.getLatestDeploymentsForReleaseByEnv(releaseId);
        List<EnvironmentDeploymentSummary> envSummary = Lists.newArrayListWithExpectedSize(latestDeployments.size());

        for (EnvDeployment record : latestDeployments) {
            envSummary.add(getEnvironmentDeploymentSummary(releaseId, currentRevision, releaseDef, record));
        }

        return envSummary;
    }

    /**
     * Returns the latest deployment status of each release in each environment where deployments have taken place. This
     * method is similar to {@link #getEnvironmentDeploymentSummaries(List)} but for multiple releases - however, note
     * that for performance reasons it does not calculate whether a deployment is STALE. This method preserves the order
     * of releases provided.
     * <p>
     * The response returned contains minimal data as required for the organisation releases screen.
     * 
     * @param releases
     * @return {@link List} of {@link ReleaseDeploymentSummary}
     */
    public List<ReleaseDeploymentSummary> getEnvironmentDeploymentSummaries(final List<ReleaseDefinition> releases) {

        Map<Integer, ReleaseDefinition> releasesMap = Maps.uniqueIndex(releases,
                new Function<ReleaseDefinition, Integer>() {
                    @Override
                    public Integer apply(final ReleaseDefinition input) {
                        return input.getId();
                    }
                });

        Stopwatch timer = Stopwatch.createStarted();
        List<EnvDeployment> latestDeployments = deploymentDao.getLatestDeploymentsForReleasesByEnv(Lists
                .newArrayList(releasesMap.keySet()));
        timer.stop();
        LOG.info("getLatestDeploymentsForReleasesByEnv took {}", timer);

        ListMultimap<ReleaseDefinition, EnvironmentDeploymentSummary> releaseDeploymentsMap = ArrayListMultimap
                .create();

        for (EnvDeployment d : latestDeployments) {
            // initialise environment for serialisation
            d.getEnvironment();
            releaseDeploymentsMap.put(releasesMap.get(d.getDeployment().getReleaseId()),
                    getSimpleEnvironmentDeploymentSummary(d));
        }

        List<ReleaseDeploymentSummary> results = Lists.newArrayListWithExpectedSize(releases.size());

        // The ordering of the releases list provided is preserved
        for (ReleaseDefinition def : releases) {
            results.add(new ReleaseDeploymentSummary(def, releaseDeploymentsMap.get(def)));
        }

        return results;
    }

    private EnvironmentDeploymentSummary getEnvironmentDeploymentSummary(final Integer releaseId,
            final Integer revision, final ReleaseDefinition releaseDef, final EnvDeployment record) {
        EnvironmentDeploymentStatus status = getDeploymentStatus(record);

        // Check for stale deployment (release definition changed since deployment)
        List<StaleArtifact> staleArtifacts = null;
        Integer revId = record.getDeployment().getReleaseRev();
        if (revId > 0 && !revId.equals(revision)) {
            ReleaseDefinition deployedReleaseDef = releaseDefinitionDao.loadRevision(releaseId, revId);

            // Artifact in historical release deployment, but not in latest release. This is not highlighted as a stale
            // deployment as another deployment of the latest release definition will not make any difference to that.
            staleArtifacts = new ArrayList<>();
            for (final Artifact current : releaseDef.getArtifacts()) {
                Optional<Artifact> deployed = Iterables.tryFind(deployedReleaseDef.getArtifacts(),
                        new Predicate<Artifact>() {
                            @Override
                            public boolean apply(final Artifact input) {
                                return input.getNexusArtifact().equals(current.getNexusArtifact());
                            }
                        });

                if (deployed.isPresent()) {
                    if (!current.getVersion().equals(deployed.get().getVersion())) {
                        staleArtifacts.add(new StaleArtifact(current.getGroupId(), current.getArtifactId(),
                                deployed.get().getVersion(), current.getVersion()));
                    }
                } else {
                    staleArtifacts.add(new StaleArtifact(current.getGroupId(), current.getArtifactId(), null, current
                            .getVersion()));
                }
            }
            if (staleArtifacts.isEmpty()) {
                staleArtifacts = null;
            } else {
                status = EnvironmentDeploymentStatus.STALE;
                Collections.sort(staleArtifacts, new StaleArtifactComparator());
            }
        }

        return new EnvironmentDeploymentSummary(status, record, staleArtifacts);
    }

    /**
     * Similar to {@link #getEnvironmentDeploymentSummary(Integer, Integer, ReleaseDefinition, Deployment)} but does not
     * calculate is a deployment is STALE, rather it just returns the outcome of the latest deployment in each
     * environment.
     * 
     * @param record
     * @return
     */
    private EnvironmentDeploymentSummary getSimpleEnvironmentDeploymentSummary(final EnvDeployment record) {
        return new EnvironmentDeploymentSummary(getDeploymentStatus(record), record, null);
    }

    private EnvironmentDeploymentStatus getDeploymentStatus(final EnvDeployment record) {
        EnvironmentDeploymentStatus status = null;

        if (record.getDeployment().getDeploymentType().equals(DeploymentType.Rollback)) {
            status = EnvironmentDeploymentStatus.ROLLBACK;
        } else {
            switch (record.getDeploymentStatus()) {
            case CANCELLED:
                status = EnvironmentDeploymentStatus.CANCELLED;
                break;
            case COMPLETED:
                status = EnvironmentDeploymentStatus.COMPLETED;
                break;
            case FAILED:
                status = EnvironmentDeploymentStatus.FAILED;
                break;
            default:
                break;
            }
        }
        return status;
    }

    @Required
    public void setDeploymentDao(final DeploymentDao deploymentDao) {
        this.deploymentDao = deploymentDao;
    }

    @Required
    public void setReleaseDefinitionDao(final ReleaseDefinitionDao releaseDefinitionDao) {
        this.releaseDefinitionDao = releaseDefinitionDao;
    }

    private static class StaleArtifactComparator implements Comparator<StaleArtifact> {
        @Override
        public int compare(final StaleArtifact o1, final StaleArtifact o2) {
            return ComparisonChain.start()
                    .compare(o1.getArtifactId(), o2.getArtifactId())
                    .compare(o1.getGroupId(), o2.getGroupId())
                    .result();
        }
    }

}
