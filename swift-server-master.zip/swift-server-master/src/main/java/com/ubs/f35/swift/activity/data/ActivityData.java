package com.ubs.f35.swift.activity.data;

import com.ubs.f35.swift.dao.Activity;

/**
 * Data objects for the {@link Activity} model class's data field should implement this interface. Objects implementing
 * this class will be serialised into a JSON string and stored in the {@link Activity} data field.
 * 
 * @author levyjo
 * 
 */
public interface ActivityData {

    /**
     * Merge data from a new activity with the data from this activity
     * 
     * @param newData
     *            Data from the new activity to be amalgamated with this one
     * @return {@link ActivityData} object of the merged data
     */
    ActivityData merge(ActivityData newData);

    /**
     * Returns true if the there is no activity data. Useful for checking if a merge resulted in changes from each
     * activity cancelling each other out.
     * 
     * @return true if activity data is empty
     */
    boolean isEmpty();

}
