package com.ubs.f35.swift.deploy.glu;

import java.util.UUID;

import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.io.processor.ManualDeploymentInstructionMessage;

public interface DeploymentExecutor {
    boolean cancelDeployment(UUID deploymentId);

    void executeDeployment(Deployment deployment, DeploymentListener deploymentListener);

    void continueDeployment(UUID deploymentId, ManualDeploymentInstructionMessage deploymentMessage);
}
