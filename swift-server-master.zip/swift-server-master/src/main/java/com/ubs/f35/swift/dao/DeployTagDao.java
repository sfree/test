package com.ubs.f35.swift.dao;

import java.util.List;

import com.ubs.f35.swift.config.model.DeployTag;
import com.ubs.f35.swift.dao.model.Environment;

public interface DeployTagDao {

    List<DeployTag> loadByEnvironment(Environment environment);

    DeployTag load(DeployTag tag);

}
