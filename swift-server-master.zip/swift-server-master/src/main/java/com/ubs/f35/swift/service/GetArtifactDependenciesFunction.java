package com.ubs.f35.swift.service;

import java.util.List;

import com.google.common.base.Function;
import com.ubs.f35.swift.config.model.ArtifactCommonConfig;

public class GetArtifactDependenciesFunction implements Function<ArtifactCommonConfig, List<ArtifactCommonConfig>> {
    static final GetArtifactDependenciesFunction INSTANCE = new GetArtifactDependenciesFunction();

    @Override
    public List<ArtifactCommonConfig> apply(final ArtifactCommonConfig input) {
        return input.getDependencies();
    }
}