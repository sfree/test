package com.ubs.f35.swift.deploy.glu.plan;

import static com.ubs.f35.swift.service.ArtifactConfigurationService.isSnapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.artifact.MavenVersionNumberComparator;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.action.Action;
import com.ubs.f35.swift.deploy.glu.action.SequentialAction;
import com.ubs.f35.swift.deploy.glu.action.TransitionAction;
import com.ubs.f35.swift.deploy.glu.rest.AgentNotFoundException;
import com.ubs.f35.swift.deploy.glu.rest.GluProcessManager;
import com.ubs.f35.swift.deploy.glu.rest.ProcessDetails;
import com.ubs.f35.swift.deploy.glu.rest.ProcessDetailsProvider;
import com.ubs.f35.swift.deploy.glu.state.GluState;
import com.ubs.f35.swift.deploy.glu.state.Transition;
import com.ubs.f35.swift.deploy.template.model.TemplateArtifactAction;
import com.ubs.f35.swift.deploy.template.model.TemplateGroupAction.Mode;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.model.ArtifactNotDefinedInEnvException;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.model.ArtifactInstanceId;
import com.ubs.f35.swift.model.State.StateLevel;
import com.ubs.f35.swift.model.TargetedInstanceDeployment;
import com.ubs.f35.swift.model.TargetedInstanceDeployment.TargetedArtifactDeployment;
import com.ubs.f35.swift.service.ArtifactConfigurationService;

public class ComponentDeploymentPlanBuilder {
    private static final Logger LOG = LoggerFactory.getLogger(ComponentDeploymentPlanBuilder.class);

    private EnvironmentBeanFactory<ProcessDetailsProvider> processDetailsProviderFactory;
    private ArtifactConfigurationService artifactService;
    private EnvironmentDocumentStore environmentDocumentStore;

    @Required
    public void setProcessDetailsProviderFactory(
            final EnvironmentBeanFactory<ProcessDetailsProvider> processDetailsProviderFactory) {
        this.processDetailsProviderFactory = processDetailsProviderFactory;
    }

    @Required
    public void setArtifactService(final ArtifactConfigurationService artifactService) {
        this.artifactService = artifactService;
    }

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

    public void appendReleaseArtifactToDeploymentPlan(final DeploymentPlanBuilder builder, final Artifact artifact,
            final Environment env, final TemplateArtifactAction action, final boolean rollback,
            final TargetedInstanceDeployment targetedInstanceDeployment) {
        Iterable<Entry> entries = getEntriesForArtifact(artifact.getNexusArtifact(), env, targetedInstanceDeployment);

        if (!Iterables.isEmpty(entries)) {
            DeploymentAction deploymentAction = action.getAction();

            DeploymentActionInstruction actionInstruction;
            if (deploymentAction == DeploymentAction.Start) {
                actionInstruction = new DeploymentActionInstruction(DeploymentAction.Start,
                        Arrays.asList(GluState.nomountpoint, GluState.NONE, GluState.installed, GluState.stopped,
                                GluState.running));
            } else {
                actionInstruction = new DeploymentActionInstruction(deploymentAction);
            }
            addReleaseEntriesToDeploymentPlan(builder, artifact, env, entries, actionInstruction, rollback,
                    action.getMode() == Mode.PARALLEL);
        }
    }

    private void addReleaseEntriesToDeploymentPlan(final DeploymentPlanBuilder builder, final Artifact artifact,
            final Environment env, final Iterable<Entry> entries, final DeploymentActionInstruction actionInstruction,
            final boolean rollback, final boolean parallel) {
        boolean anyIncluded = false;

        final DeploymentAction requestedAction = actionInstruction.getAction();
        // Always group the operations for a single artifact together even if there is only a single operation so
        // that/ it is always represented consistently
        // This will flag to the client that the deployment of the artifact to multiple servers is related.
        String groupId = requestedAction.name() + "-" + artifact.getGroupId() + "-" + artifact.getArtifactId();
        String groupName = requestedAction.name() + " " + artifact.getArtifactId() + " " + artifact.getVersion();

        builder.startGroupedAction(groupId, groupName);

        // don't warn about earlier version numbers when performing a rollback
        if (!rollback) {
            addVersionNumberWarnings(builder, artifact, entries);
        }

        for (Entry entry : entries) {
            DeploymentAction action = requestedAction;
            // If the entry is a cold standby, then complete the deployment action but drop off the start transition.
            if (entry.isColdStandby()) {
                switch (requestedAction) {
                case Start:
                    action = DeploymentAction.ColdDeploy;
                    break;
                case Redeploy:
                    action = DeploymentAction.ColdRedeploy;
                    break;
                case Undeploy:
                    action = DeploymentAction.Undeploy;
                    break;
                default:
                    LOG.error("Unsure what to to with action {} for a cold standby artifact", requestedAction);
                }
            }
            String name = buildDeploymentLabel(action, entry);

            boolean artifactVersionsChanged = !artifact.getVersion().equals(entry.getVersion());
            ProcessDetails processDetails = null;
            try {
                processDetails = getCurrentState(env, entry);
            } catch (AgentNotFoundException ex) {
                addAgentDownWarning(builder, entry, ex);
                continue;
            }

            if (artifactVersionsChanged) {
                // If the artifact versions have changed, highlight this.
                name += " (current " + entry.getVersion() + ")";
            } else if (processDetails.getGluState() == GluState.nomountpoint) {
                name += " (NEW)";
            } else if (processDetails.getStateLevel() != StateLevel.OK) {
                name += " (currently in " + processDetails.getStateLevel() + ")";
            }

            // If the artifact is a SNAPSHOT version, always suggest that it is upgraded. We have no way of knowing if
            // it has changed since the last SNAPSHOT deployment. If the artifact is a release version and that release
            // version is currently deployed, do not include by default the deployment of that artifact. If that
            // artifact is currently in a delta state, or not currently running then it is included in the deployment
            // plan by default.
            // TODO Vitor suggested that we only deploy SNAPSHOTS if the latest nexus deployment is more recent than the
            // last redeployment. Leaving this a separate piece of work as there is value in this functionality alone
            // and we can come back to this later.
            boolean execute;
            if (isSnapshot(artifact)) {
                execute = true;
                LOG.debug("Entry {} is included in deployment as it's a snapshot version", entry.getMountPoint());
            } else if (artifactVersionsChanged) {
                execute = rollback
                        || MavenVersionNumberComparator.isLaterVersion(artifact.getVersion(), entry.getVersion());
                if (execute) {
                    LOG.debug("Entry {} is included in deployment as it needs to be upgraded or rolledback",
                            entry.getMountPoint());
                } else {
                    LOG.debug("Entry {} is not included in deployment as it's an older version than the live version",
                            entry.getMountPoint());
                }
            } else {
                execute = processDetails.getStateLevel() != StateLevel.OK;

                LOG.debug("Entry {} is {} in deployment with process details {}",
                        new Object[] { entry.getMountPoint(), execute, processDetails });
            }

            if (execute) {
                anyIncluded = true;
            }

            // Redeploy and undeploy start from the process current state. A start action will only be after an earlier
            // undeploy.
            GluState startState = getActualStartState(actionInstruction, processDetails);

            SequentialAction actions = getDeploymentPlanActions(name, env, entry, action, startState);

            if (actions != null) {
                actions.setExecute(execute);
                builder.addStep(actions, entry);
            } else {
                // Will be the case if the deployment includes a dependency which is asked to be undeployed and is
                // already in that state.
                LOG.info("No tranisition required to  " + action.name() + " process " + entry.getMountPoint()
                        + " as current state is " + startState);
            }

        }

        // For client artifacts, deployments to all hosts can occur in parallel. For server artifacts,
        // perform the installation sequentially (so that if one fails, the remainder of the cluster is untouched).
        builder.completeGroupedAction(parallel, anyIncluded);
    }

    /**
     * Adds warnings if the suggested artifact to be deployed is an older version than the current live version. Note
     * that no warnings are added when deploying SNAPSHOTS as the versioning schemes on snapshots often is not suitable
     * for ordering comparisons (eg master-SNASPSHOT or bug-fix-314-SNAPSHOT).
     */
    private void addVersionNumberWarnings(final DeploymentPlanBuilder builder, final Artifact artifact,
            final Iterable<Entry> entries) {
        Entry entry = Iterables.get(entries, 0);
        if (!isSnapshot(artifact)
                && MavenVersionNumberComparator.isLaterVersion(entry.getVersion(), artifact.getVersion())) {
            builder.addWarning(artifact.getArtifactId()
                    + " is not included in the deployment plan by default because Swift is currently configured with version "
                    + entry.getVersion() + " which supersedes the release version " + artifact.getVersion() + ".");
        }
    }

    public void appendDependencyToDeploymentPlan(final DeploymentPlanBuilder builder, final NexusArtifact artifact,
            final Environment env, final DeploymentActionInstruction dependencyAction) {

        DeploymentAction action = dependencyAction.getAction();

        // dependencies are not targetted to specific instances.
        Iterable<Entry> entries = getEntriesForArtifact(artifact, env, null);

        String id = action.name() + "-" + artifact.getGroupId() + "-" + artifact.getArtifactId();
        String name = action.name() + " " + artifact.getArtifactId() + " (dependency)";

        builder.startGroupedAction(id, name);

        for (Entry entry : entries) {

            ProcessDetails processDetails = getCurrentState(env, entry);

            GluState actualStartState = getActualStartState(dependencyAction, processDetails);
            if (!entry.isColdStandby() && actualStartState != null) {
                String taskName = buildDeploymentLabel(action, entry);
                // Note that this doesn't use the current state as the deployment plan may be assuming a later state
                // that occurs after earlier actions (ie the restart of a dependent artifact after the deployment).
                SequentialAction actions = getDeploymentPlanActions(taskName, env, entry, action, actualStartState);
                if (actions != null) {
                    builder.addStep(actions, entry);
                }
            } else {
                LOG.info("Not addding {} to deployment plan as it is in state {}", artifact,
                        processDetails.getGluState());
            }
        }
        builder.completeGroupedAction(false);
    }

    private Iterable<Entry> getEntriesForArtifact(final NexusArtifact artifact, final Environment env,
            final TargetedInstanceDeployment targetedInstanceDeployment) {
        // TODO I think this logic belongs in the GluDeploymentPlanGenerator. It should not request an artifact be
        // included in the deployment plan in the first place.

        Iterable<Entry> entries = new ArrayList<>(environmentDocumentStore.filterEntriesByArtifact(env, artifact));

        if (Iterables.isEmpty(entries)) {
            if (artifactService.isArtifactDeployedToEnvironment(artifact, env)) {
                throw new ArtifactNotDefinedInEnvException(artifact);
            } else {
                LOG.debug("Artifact {} is not deployed to environment {} so omitting from deployment plan", artifact,
                        env);
            }
        }

        // Filter down to the entries which have been targeted.
        if (targetedInstanceDeployment != null) {
            Iterables.removeIf(entries, new Predicate<Entry>() {
                @Override
                public boolean apply(final Entry entry) {
                    for (TargetedArtifactDeployment target : targetedInstanceDeployment
                            .getTargetedArtifactDeployments()) {
                        if (target.getArtifact().getGroupId().equals(entry.getGroupId()) &&
                                target.getArtifact().getArtifactId().equals(entry.getArtifactId())) {
                            // Include if in the list of targets
                            return !target.getInstanceNames().contains(entry.getName());
                        }
                    }
                    // Remove if there are no deployment targets.
                    return true;
                }
            });
        }

        return entries;
    }

    public void addToDeploymentPlan(final DeploymentPlanBuilder builder, final Environment environment,
            final Collection<Entry> entries, final DeploymentActionInstruction actionInstruction) {

        DeploymentAction requestedAction = actionInstruction.getAction();
        Entry artifact = entries.iterator().next();

        String id = requestedAction.name() + "-" + artifact.getGroupId() + "-" + artifact.getArtifactId();
        // TODO If we later decide to allow different versions of artifacts on different hosts, then
        // we will need to show version at host level.
        // https://github.ldn.swissbank.com/NeoSwift/swift-server/pull/79/files#r10268
        String name = requestedAction.name() + " " + artifact.getArtifactId();

        // If performing a redeploy, then the version will be the same across all artifacts in the group.
        if (requestedAction == DeploymentAction.Redeploy) {
            name += " " + artifact.getVersion();
        }

        builder.startGroupedAction(id, name);

        for (Entry entry : entries) {
            DeploymentAction action = requestedAction;
            if (entry.isColdStandby()) {
                // If the user requests a redeploy or bounce, for any cold standby instances, do not execute the start
                // transition.
                switch (requestedAction) {
                case Redeploy:
                    action = DeploymentAction.ColdRedeploy;
                    builder.addWarning("Cold standbys in deployment will not be restarted");
                    break;
                case Bounce:
                    action = DeploymentAction.Stop;
                    builder.addWarning("Cold standbys in deployment will not be restarted");
                    break;
                case Start:
                    // If starting a cold standby, warn first
                    builder.addWarning("Deployment includes cold standbys");
                    break;
                }
            }

            String nestedName = buildDeploymentLabel(action, entry);
            ProcessDetails currentState = null;
            try {
                currentState = getCurrentState(environment, entry);
            } catch (AgentNotFoundException ex) {
                addAgentDownWarning(builder, entry, ex);
                continue;
            }

            if (requestedAction != DeploymentAction.Redeploy) {
                // if there is already a deployed version, the action will be against that deployed version. That could
                // differ on each host. If there is not a currently deployed version, then any action will be against
                // the configured version.
                if (currentState.getVersion() != null && !currentState.getVersion().equals(entry.getVersion())) {
                    nestedName += " (stale " + currentState.getVersion() + ")";
                } else {
                    nestedName += " (" + artifact.getVersion() + ")";
                }
            }

            GluState startState = getActualStartState(actionInstruction, currentState);

            if (startState != null) {
                SequentialAction executeAction = getDeploymentPlanActions(nestedName, environment, entry, action,
                        startState);
                if (executeAction != null) {
                    builder.addStep(executeAction, entry);
                }
            }

        }

        builder.completeGroupedAction(false);
    }

    private GluState getActualStartState(final DeploymentActionInstruction actionInstruction,
            final ProcessDetails currentState) {
        GluState startState = null;
        if (actionInstruction.getValidStartStates() == null) {
            // include using the current state of the process
            startState = currentState.getGluState();
        } else {
            // include only if the current state of the process is in the list of valid states, if it is, then
            // when this action executes it will be in the first state in that list.
            if (actionInstruction.getValidStartStates().contains(currentState.getGluState())) {
                startState = actionInstruction.getStartState();
            }
        }
        return startState;
    }

    private SequentialAction getDeploymentPlanActions(final String groupingTitle, final Environment environment,
            final Entry entry, final DeploymentAction deploymentAction, final GluState currentState) {

        // Before doing anything with this artifact, must first check what state it is currently in.

        if (deploymentAction.anyStartState() || deploymentAction.getValidStartState() == currentState) {
            ArtifactInstanceId artifactInstanceId = ArtifactInstanceId.create(environment, entry.getMountPoint());

            List<Action> actions = Lists.newArrayList();
            // generate a list of all required transitions.
            GluState transitionFromState = currentState;
            for (GluState transitionState : deploymentAction.getTransitionStates()) {
                List<Transition> transitions = transitionFromState.getTransitionsForTargetState(transitionState);

                for (Transition transition : transitions) {
                    actions.add(new TransitionAction(artifactInstanceId, transition.getAction()));
                    transitionFromState = transition.getTargetState();
                }
            }
            if (!actions.isEmpty()) {
                String id = deploymentAction.name() + "-" + entry.getMountPoint();

                SequentialAction action = new SequentialAction(id, groupingTitle, actions);
                action.setArtifactInstanceId(artifactInstanceId.toString());
                action.setArtifactId(entry.getArtifactId());
                return action;
            }
        }
        return null;
    }

    /**
     * Retrieves the current status of the entry directly from the agent if zookeeper is down. If zookeeper is alive,
     * then the process is obtained from {@link GluProcessManager} which takes its state from zookeeper with some
     * caching in the middle. This means that the deployment plan generation will be fast, but in the unlikely event
     * zookeeper is down, a deployment plan can still be calculated to allow processes to be started.
     * 
     * @param environment
     * @param entry
     * @return
     */
    private ProcessDetails getCurrentState(final Environment environment, final Entry entry) {
        ProcessDetailsProvider processDetailsProvider = processDetailsProviderFactory.get(environment);

        return processDetailsProvider.getCurrentProcessState(entry);
    }

    private String buildDeploymentLabel(final DeploymentAction deploymentAction, final Entry entry) {
        StringBuilder taskName = new StringBuilder(deploymentAction.getDeployVerb());
        if (!ArtifactConfig.DEFAULT_INSTANCE_NAME.equals(entry.getName())) {
            taskName.append(" ").append(entry.getName());
        }
        taskName.append(" ").append(deploymentAction.getVerbHostJoiner()).append(" ").append(entry.getAgent());

        return taskName.toString();
    }

    private void addAgentDownWarning(final DeploymentPlanBuilder builder, final Entry entry,
            final AgentNotFoundException ex) {
        String message = "Agent '" + entry.getAgent()
                + "' is unavailable. Artifacts deployed to this host have been excluded from the deployment plan.";
        LOG.info(message, ex);
        builder.addWarning(message);
    }
}
