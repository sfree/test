package com.ubs.f35.swift.deploy.glu.action;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.google.common.base.Objects;
import com.ubs.f35.swift.deploy.glu.DeploymentState;

/**
 * The basic fields other actions have.
 * 
 * @author stephelu
 * 
 */
public abstract class BaseAction implements Action {
    private final String id;
    private final String name;
    // By default the action is included in the deployment plan. This provides backwards compatibility with legacy
    // deployment plans where this field was not present, but the actions were executed.
    // Note that this is a mutable field as we allow the client to specify which actions within the plan should be
    // executed.
    private boolean execute = true;

    @JsonIgnore
    private transient DeploymentState deploymentState;

    public BaseAction(final String id, final String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setExecute(final boolean execute) {
        this.execute = execute;
    }

    public boolean isExecute() {
        return execute;
    }

    @Override
    public void setDeploymentState(final DeploymentState deploymentState) {
        this.deploymentState = deploymentState;
    }

    @Override
    public DeploymentState getDeploymentState() {
        return deploymentState;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("id", id)
                .add("name", name)
                .add("execute", execute)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public boolean equals(final Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (getClass() != object.getClass()) {
            return false;
        }

        BaseAction that = (BaseAction) object;
        return Objects.equal(this.id, that.id)
                && Objects.equal(this.name, that.name)
                && Objects.equal(this.execute, that.execute);
    }

}
