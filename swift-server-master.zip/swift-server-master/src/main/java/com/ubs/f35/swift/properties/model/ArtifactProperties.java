package com.ubs.f35.swift.properties.model;

import org.codehaus.jackson.annotate.JsonProperty;

import com.google.common.base.Objects;
import com.ubs.f35.swift.client.model.ArtifactType;
import com.ubs.f35.swift.dao.Artifact;

/**
 * Model for encapsulating artifact properties and associated metadata.
 * 
 * @author levyjo
 */
public class ArtifactProperties {

    private final Artifact artifact;
    private final boolean saved;
    private PropertyList properties;
    private String seedVersion;

    /**
     * Show a warning on the client if there was a {@link PropertyKeysExtractionException}
     */
    private String warning;

    /**
     * The response to the client may be enriched with artifact type info.
     */
    private ArtifactType artifactType;

    public ArtifactProperties(final Artifact artifact, final PropertyList properties) {
        this(artifact, false, properties, null);
    }

    public ArtifactProperties(
            @JsonProperty(value = "artifact") final Artifact artifact,
            @JsonProperty(value = "properties") final PropertyList properties,
            @JsonProperty(value = "seedVersion") final String seedVersion) {
        this(artifact, false, properties, seedVersion);
    }

    public ArtifactProperties(final Artifact artifact, final boolean saved, final PropertyList properties) {
        this(artifact, saved, properties, null);
    }

    public ArtifactProperties(final Artifact artifact, final boolean saved, final PropertyList properties,
            final String seedVersion) {
        this.artifact = artifact;
        this.saved = saved;
        this.properties = properties;
        this.seedVersion = seedVersion;
    }

    public Artifact getArtifact() {
        return artifact;
    }

    public PropertyList getProperties() {
        return properties;
    }

    public void setProperties(final PropertyList properties) {
        this.properties = properties;
    }

    public String getSeedVersion() {
        return seedVersion;
    }

    public void setSeedVersion(final String seedVersion) {
        this.seedVersion = seedVersion;
    }

    public boolean isSaved() {
        return saved;
    }

    public String getWarning() {
        return warning;
    }

    public void setWarning(final String warning) {
        this.warning = warning;
    }

    public ArtifactType getArtifactType() {
        return artifactType;
    }

    public void setArtifactType(final ArtifactType artifactType) {
        this.artifactType = artifactType;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("artifact", artifact)
                .add("saved", saved)
                .add("properties", properties)
                .add("seedVersion", seedVersion)
                .add("warning", warning)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(artifact, saved, properties, seedVersion, warning);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ArtifactProperties) {
            ArtifactProperties that = (ArtifactProperties) object;
            return Objects.equal(this.artifact, that.artifact)
                    && Objects.equal(this.saved, that.saved)
                    && Objects.equal(this.properties, that.properties)
                    && Objects.equal(this.seedVersion, that.seedVersion)
                    && Objects.equal(this.warning, that.warning);
        }
        return false;
    }

}
