package com.ubs.f35.core.zookeeper.client;

import java.util.Properties;

import org.linkedin.util.clock.Timespan;
import org.linkedin.zookeeper.client.ZKClient;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.config.AbstractFactoryBean;

/**
 * This only exists because Spring gets confused by using a static factory that returns an Object with @Required
 * annotations.
 * 
 * @author stephelu
 * 
 */
public class LinkedInZKClientWrapper extends AbstractFactoryBean<ZKClient> {

    private Properties zooKeeperClientProperties;

    @Required
    public void setZooKeeperClientProperties(final Properties zooKeeperClientProperties) {
        this.zooKeeperClientProperties = zooKeeperClientProperties;
    }

    @Override
    public Class<?> getObjectType() {
        return ZKClient.class;
    }

    @Override
    protected ZKClient createInstance() throws Exception {
        String connectionString = zooKeeperClientProperties.getProperty("zookeeper.client.host.ports");
        String timeout = zooKeeperClientProperties.getProperty("zookeeper.client.connection.timeout");
        return new ZKClient(connectionString, Timespan.milliseconds(Long.parseLong(timeout, 10)), null);
    }
}
