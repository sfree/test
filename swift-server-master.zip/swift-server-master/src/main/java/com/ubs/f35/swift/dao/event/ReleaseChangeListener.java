package com.ubs.f35.swift.dao.event;

import com.ubs.f35.swift.dao.ReleaseDefinition;

public interface ReleaseChangeListener {
    void afterUpdate(ReleaseDefinition release);
}
