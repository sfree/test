package com.ubs.f35.swift.model;

public interface ReleaseDeploymentConfirmationMessage {
    String getConfirmedReleaseId();
}
