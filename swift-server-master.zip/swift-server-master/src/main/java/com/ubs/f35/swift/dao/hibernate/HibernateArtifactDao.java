package com.ubs.f35.swift.dao.hibernate;

import javax.persistence.EntityNotFoundException;

import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ArtifactDao;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.service.NexusArtifactService;

public class HibernateArtifactDao extends HibernateDaoSupport implements ArtifactDao {

    private static final Logger LOG = LoggerFactory.getLogger(HibernateArtifactDao.class);

    private NexusArtifactService nexusArtifactService;

    @Override
    public Artifact resolvePersistentArtifact(final Artifact artifact) {
        Artifact persistentArtifact = getPersistentArtifact(artifact);

        if (persistentArtifact == null) {
            throw new EntityNotFoundException(
                    "Artifact does not exist in Swift. Please create a release containing this artifact and then try again.");
        }

        return persistentArtifact;
    }

    private Artifact getPersistentArtifact(final Artifact artifact) {
        if (artifact.getId() != null) {
            return artifact;
        }

        Artifact persistentArtifact = (Artifact) getSession().createCriteria(Artifact.class).add(
                Restrictions.naturalId()
                        .set("groupId", artifact.getGroupId())
                        .set("artifactId", artifact.getArtifactId())
                        .set("version", artifact.getVersion())).setCacheable(true).uniqueResult();
        return persistentArtifact;
    }

    @Override
    public Artifact resolveOrCreatePersistentArtifact(final Artifact artifact) {

        Artifact persistentArtifact = getPersistentArtifact(artifact);

        if (persistentArtifact == null) {
            // There is a foreign key between artifacts and nexus_artifacts. If this isn't a valid artifact creation
            // will be blocked. However, this ensures the artifact version is valid.
            nexusArtifactService.validateArtifactVersion(artifact);

            LOG.info("Creating artifact {}", artifact);
            getSession().save(artifact);
            persistentArtifact = artifact;
        }

        return persistentArtifact;

    }

    @Required
    public void setNexusArtifactService(final NexusArtifactService nexusArtifactService) {
        this.nexusArtifactService = nexusArtifactService;
    }
}
