package com.ubs.f35.swift.dao;

import com.ubs.f35.swift.config.model.ArtifactCommonConfig;

public interface ArtifactCommonConfigDao {

    ArtifactCommonConfig load(NexusArtifact artifact);

    ArtifactCommonConfig save(ArtifactCommonConfig artifact);

}
