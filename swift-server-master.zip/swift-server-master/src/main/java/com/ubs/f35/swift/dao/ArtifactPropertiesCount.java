package com.ubs.f35.swift.dao;

public class ArtifactPropertiesCount {
    private final Integer environmentId;
    private final Integer artifactId;
    private final Long savePropertiesCount;

    public ArtifactPropertiesCount(final Integer environmentId, final Integer artifactId, final Long savePropertiesCount) {
        this.environmentId = environmentId;
        this.artifactId = artifactId;
        this.savePropertiesCount = savePropertiesCount;
    }

    public Integer getEnvironmentId() {
        return environmentId;
    }

    public Integer getArtifactId() {
        return artifactId;
    }

    public Long getSavePropertiesCount() {
        return savePropertiesCount;
    }

}
