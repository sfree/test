package com.ubs.f35.swift.model;

import java.util.List;

import com.google.common.base.Objects;

/**
 * Represents the filters the client may pass in to restrict the view of visible artifacts.
 * 
 * @author stephelu
 * 
 */
public class EntryFilter {

    private List<String> groups;
    private List<String> artifacts;
    private List<String> agents;
    private List<String> tags;

    public EntryFilter() {
    }

    public EntryFilter(final List<String> groups, final List<String> artifacts, final List<String> agents,
            final List<String> tags) {
        this.groups = groups;
        this.artifacts = artifacts;
        this.agents = agents;
        this.tags = tags;
    }

    public final List<String> getGroups() {
        return groups;
    }

    public final void setGroups(final List<String> groups) {
        this.groups = groups;
    }

    public final List<String> getArtifacts() {
        return artifacts;
    }

    public final void setArtifacts(final List<String> artifacts) {
        this.artifacts = artifacts;
    }

    public List<String> getAgents() {
        return agents;
    }

    public void setAgents(final List<String> agents) {
        this.agents = agents;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(final List<String> tags) {
        this.tags = tags;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(groups, artifacts, agents, tags);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof EntryFilter) {
            EntryFilter that = (EntryFilter) object;
            return Objects.equal(this.groups, that.groups)
                    && Objects.equal(this.artifacts, that.artifacts)
                    && Objects.equal(this.agents, that.agents)
                    && Objects.equal(this.tags, that.tags);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("groups", groups)
                .add("artifacts", artifacts)
                .add("agents", agents)
                .add("tags", tags)
                .toString();
    }

}
