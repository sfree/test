package com.ubs.f35.swift.model;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.PagingResult;

/**
 * Groups {@link ArtifactDeploymentStatus} by environment. Ideally the client could handle just being returned a flat
 * list of {@link ArtifactDeploymentStatus} as this duplicates the information on that object.
 */
public class EnvironmentArtifactDeploymentStatus {

    private final String environment;
    private final PagingResult<ArtifactDeploymentStatus> artifacts;

    public EnvironmentArtifactDeploymentStatus(final String environment,
            final PagingResult<ArtifactDeploymentStatus> artifacts) {
        this.environment = environment;
        this.artifacts = artifacts;
    }

    public String getEnvironment() {
        return environment;
    }

    public PagingResult<ArtifactDeploymentStatus> getArtifacts() {
        return artifacts;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(environment, artifacts);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof EnvironmentArtifactDeploymentStatus) {
            EnvironmentArtifactDeploymentStatus that = (EnvironmentArtifactDeploymentStatus) object;
            return Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.artifacts, that.artifacts);
        }
        return false;
    }

}