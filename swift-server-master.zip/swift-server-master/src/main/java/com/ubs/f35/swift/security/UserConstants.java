package com.ubs.f35.swift.security;

import com.ubs.f35.common.transport.transformer.TransportPrincipal;

public final class UserConstants {
    public static final TransportPrincipal SWIFT_PRINCIPAL = new TransportPrincipal();
    static {
        SWIFT_PRINCIPAL.setUserName("swift-server");
    }

    private UserConstants() {
    }
}
