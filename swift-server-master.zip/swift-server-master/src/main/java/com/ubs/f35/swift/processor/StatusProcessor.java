package com.ubs.f35.swift.processor;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.PagingFilter;
import com.ubs.f35.swift.dao.PagingResult;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.glu.rest.GluProcessManager;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.document.OrganisationIndex;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.model.ArtifactDeploymentStatus;
import com.ubs.f35.swift.model.ArtifactDeploymentStatusSorter;
import com.ubs.f35.swift.model.EntryFilter;
import com.ubs.f35.swift.model.EnvironmentArtifactDeploymentStatus;
import com.ubs.f35.swift.model.IndexEntry;
import com.ubs.f35.swift.model.State;
import com.ubs.f35.swift.security.AuthorisationController;
import com.ubs.f35.swift.security.Permission;
import com.ubs.f35.swift.service.ArtifactConfigurationService;
import com.ubs.f35.swift.service.ArtifactConfigurationService.EnvironmentEntryPair;
import com.ubs.f35.swift.service.glu.EntryFilterPredicateFactory;
import com.ubs.f35.swift.service.glu.StateMatchesStateLevelsPredicate;
import com.ubs.f35.swift.service.glu.StateMatchesStatusesPredicate;
import com.ubs.f35.swift.util.CSVUtil;

@Controller
@RequestMapping(value = "/api/status")
public class StatusProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(StatusProcessor.class);
    public static final MediaType CSV_MEDIA_TYPE = new MediaType("text", "csv", Charset.forName("utf-8"));

    private OrganisationBeanFactory<List<String>> orgEnvironmentsMap;
    private EnvironmentDocumentStore environmentDocumentStore;
    private EnvironmentBeanFactory<GluProcessManager> gluProcessManagerFactory;
    private EntryFilterPredicateFactory entryFilterPredicateFactory;
    private AuthorisationController authorisationController;
    private OrganisationIndex organisationIndex;
    private ArtifactConfigurationService artifactConfigurationService;

    @ResponseBody
    @RequestMapping(method = RequestMethod.GET)
    public List<EnvironmentArtifactDeploymentStatus> getStatus(
            @RequestParam(value = "organisation", required = true) final String organisation,
            @RequestParam(value = "environment", required = false) final List<String> environments,
            @RequestParam(value = "group", required = false) final List<String> groups,
            @RequestParam(value = "artifact", required = false) final List<String> artifacts,
            @RequestParam(value = "host", required = false) final List<String> agents,
            @RequestParam(value = "tag", required = false) final List<String> tags,
            @RequestParam(value = "state", required = false) final List<String> stateLevels,
            @RequestParam(value = "status", required = false) final List<String> statuses,
            @RequestParam(value = "col", required = false) final String sortColumn,
            @RequestParam(value = "dir", defaultValue = "false") final boolean sortDescending,
            @RequestParam(value = "records", defaultValue = "100") final int records
            ) {

        List<EnvironmentArtifactDeploymentStatus> result = Lists.newArrayList();

        EntryFilter filter = new EntryFilter(groups, artifacts, agents, tags);
        Predicate<Entry> entryFilterPredicate = entryFilterPredicateFactory.buildFilterForCriteria(filter);

        List<String> orgEnvironments = orgEnvironmentsMap.get(organisation);
        // Filter environment
        List<String> envs;
        if (CollectionUtils.isEmpty(environments)) {
            envs = orgEnvironments;
        } else {
            envs = Lists.newArrayListWithExpectedSize(environments.size());
            for (String e : orgEnvironments) {
                if (environments.contains(e)) {
                    envs.add(e);
                }
            }
        }

        for (String env : envs) {
            Environment environment = new Environment(env, organisation);
            GluProcessManager processManager = gluProcessManagerFactory.get(environment);
            Iterable<Entry> entries = environmentDocumentStore.filterByEnvironment(environment);

            entries = Iterables.filter(entries, entryFilterPredicate);

            List<ArtifactDeploymentStatus> deploymentStatuses = Lists.newArrayList();

            // Obtain the status for each entry.
            for (Entry entry : entries) {
                State state = processManager.getProcessState(entry);
                if (matchesStateAndStatusFilters(stateLevels, statuses, state)) {
                    ArtifactDeploymentStatus artifactDeploymentStatus = new ArtifactDeploymentStatus(entry, state,
                            environment);
                    deploymentStatuses.add(artifactDeploymentStatus);
                }
            }

            if (!deploymentStatuses.isEmpty()) {
                ArtifactDeploymentStatusSorter.sort(deploymentStatuses, sortColumn, sortDescending);

                PagingResult<ArtifactDeploymentStatus> pagedDeploymentStatuses = ProcessorUtil.getPagedList(
                        new PagingFilter(0, records), deploymentStatuses);

                result.add(new EnvironmentArtifactDeploymentStatus(env, pagedDeploymentStatuses));
            }
        }

        return result;
    }

    @RequestMapping(value = "/export", method = RequestMethod.GET)
    public void exportStatus(@RequestParam(value = "organisation", required = true) final String organisation,
            @RequestParam(value = "environment", required = false) final List<String> environments,
            @RequestParam(value = "group", required = false) final List<String> groups,
            @RequestParam(value = "artifact", required = false) final List<String> artifacts,
            @RequestParam(value = "host", required = false) final List<String> agents,
            @RequestParam(value = "tag", required = false) final List<String> tags,
            @RequestParam(value = "state", required = false) final List<String> stateLevels,
            @RequestParam(value = "status", required = false) final List<String> statuses,
            @RequestParam(value = "col", required = false) final String sortColumn,
            @RequestParam(value = "dir", defaultValue = "false") final boolean sortDescending,
            final HttpServletResponse response) throws IOException {

        List<EnvironmentArtifactDeploymentStatus> results = getStatus(organisation, environments, groups, artifacts,
                agents, tags, stateLevels, statuses, sortColumn, sortDescending, -1);

        List<String[]> csvData = new ArrayList<>();
        csvData.add(new String[] { "Environment", "Group", "Artifact", "Version", "Name", "Host", "State", "Warnings",
                "Tags" });

        for (EnvironmentArtifactDeploymentStatus envArtifacts : results) {
            for (ArtifactDeploymentStatus artifactStatus : envArtifacts.getArtifacts().getPageResults()) {
                List<String> rowData = new ArrayList<>();
                rowData.add(envArtifacts.getEnvironment());
                rowData.add(artifactStatus.getArtifact().getGroupId());
                rowData.add(artifactStatus.getArtifact().getArtifactId());
                rowData.add(artifactStatus.getArtifact().getVersion());
                rowData.add(artifactStatus.getName());
                rowData.add(artifactStatus.getAgent());
                rowData.add(artifactStatus.getState().getStatus());
                rowData.add(StringUtils.collectionToCommaDelimitedString(artifactStatus.getState().getStatusInfos()));
                rowData.add(StringUtils.collectionToCommaDelimitedString(artifactStatus.getTags()));

                csvData.add(rowData.toArray(new String[rowData.size()]));
            }
        }

        response.setContentType(CSV_MEDIA_TYPE.toString());
        response.setHeader("Content-Disposition", "attachment; filename=\"" + "status.csv" + "\"");
        CSVUtil.writeCSV(csvData, response.getWriter());
    }

    @RequestMapping(value = "/lookup/{organisation}", method = RequestMethod.GET)
    public Set<IndexEntry> getLookup(@PathVariable final String organisation) {
        return organisationIndex.getIndex(organisation);
    }

    @RequestMapping(value = "/actions", method = RequestMethod.GET)
    @ResponseBody
    @Transactional(readOnly = true)
    public List<DeploymentAction> getProcessActions(@RequestParam(value = "id") final String id) {
        EnvironmentEntryPair resolvedDetails = artifactConfigurationService.resolveArtifactInstanceId(id);
        Environment environment = resolvedDetails.getEnvironment();
        Entry entry = resolvedDetails.getEntry();

        NexusArtifact artifact = new NexusArtifact(entry.getGroupId(), entry.getArtifactId());
        if (!authorisationController.canAccess(environment, entry.getAgent(), artifact, Permission.ManageProcesses)) {
            return Collections.<DeploymentAction>emptyList();
        }

        GluProcessManager processManager = gluProcessManagerFactory.get(environment);

        return processManager.getProcessActions(entry);
    }

    @RequestMapping(value = "/jmx", method = RequestMethod.GET)
    @ResponseBody
    @Transactional(readOnly = true)
    public String getJMXLink(@RequestParam(value = "id") final String id) throws UnknownHostException {
        EnvironmentEntryPair resolvedDetails = artifactConfigurationService.resolveArtifactInstanceId(id);
        Environment environment = resolvedDetails.getEnvironment();
        Entry entry = resolvedDetails.getEntry();

        authorisationController.checkEnvironmentAccess(environment);

        GluProcessManager processManager = gluProcessManagerFactory.get(environment);

        String jmxPort = processManager.getJMXPort(entry.getAgent(), entry.getMountPoint());

        if (!StringUtils.hasText(jmxPort)) {
            return null;
        }

        String ip = processManager.getAgentDetails(entry.getAgent()).get("glu.agent.hostname");
        String hostname = InetAddress.getByName(ip).getCanonicalHostName();

        return "http://" + hostname + ":" + jmxPort;
    }

    public static boolean matchesStateAndStatusFilters(final List<String> stateLevels, final List<String> statuses,
            final State state) {
        return (new StateMatchesStateLevelsPredicate(stateLevels)).apply(state)
                && (new StateMatchesStatusesPredicate(statuses)).apply(state);
    }

    public static class EntryToArtifactConvertor implements Function<Entry, Artifact> {
        public static final EntryToArtifactConvertor INSTANCE = new EntryToArtifactConvertor();

        @Override
        public Artifact apply(final Entry entry) {
            return new Artifact(entry.getGroupId(), entry.getArtifactId(), entry.getVersion());
        }
    }

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

    @Required
    public void setGluProcessManagerFactory(final EnvironmentBeanFactory<GluProcessManager> gluProcessManagerFactory) {
        this.gluProcessManagerFactory = gluProcessManagerFactory;
    }

    @Required
    public void setOrgEnvironmentsMap(final OrganisationBeanFactory<List<String>> orgEnvironmentsMap) {
        this.orgEnvironmentsMap = orgEnvironmentsMap;
    }

    @Required
    public void setEntryFilterPredicateFactory(final EntryFilterPredicateFactory entryFilterPredicateFactory) {
        this.entryFilterPredicateFactory = entryFilterPredicateFactory;
    }

    @Required
    public void setAuthorisationController(final AuthorisationController authorisationController) {
        this.authorisationController = authorisationController;
    }

    @Required
    public void setOrganisationIndex(final OrganisationIndex organisationIndex) {
        this.organisationIndex = organisationIndex;
    }

    @Required
    public void setArtifactConfigurationService(final ArtifactConfigurationService artifactConfigurationService) {
        this.artifactConfigurationService = artifactConfigurationService;
    }
}
