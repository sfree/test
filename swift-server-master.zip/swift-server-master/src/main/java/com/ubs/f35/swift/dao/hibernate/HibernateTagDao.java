package com.ubs.f35.swift.dao.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.f35.swift.config.model.Tag;
import com.ubs.f35.swift.dao.TagDao;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;

public class HibernateTagDao extends HibernateDaoSupport implements TagDao {

    private static final Logger LOG = LoggerFactory.getLogger(HibernateTagDao.class);

    /**
     * TODO Consider making the organisation part of the key for tag so the joins are not required. Note though for now
     * I've gone with the quick development option which is to just evaluate this query. I've done this because tags are
     * held against the artifact per instance. So should this logic only show tags from other artifacts in the same
     * environment? Or should tags be configured within common config. While not completely sure what the best direction
     * is, have avoided changing the data model in favour of a query which is easier to refactor. Might become clearer
     * once we move swift into prod and the prod guys complain about having to configure tags for each environment.
     */
    @Override
    public List<Tag> loadAll(final String organisation) {
        return getSession()
                .createQuery(
                        "select distinct t from ArtifactConfig c join c.environment e join e.organisation o join c.tags t where o.name = :orgName")
                .setString("orgName", organisation)
                .list();
    }

    /**
     * Scheduled job
     */
    @Transactional
    public void purgeOrphanedTags() {

        Query query = getSession().createQuery(
                "delete from Tag t where t.tag not in ( select act.tag from ArtifactConfig a join a.tags act )");
        int deleteCount = query.executeUpdate();
        LOG.info("Purged {} orphaned tags", deleteCount);

    }

}
