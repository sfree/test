package com.ubs.f35.swift.environment;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Equivalence;
import com.google.common.collect.BiMap;
import com.google.common.collect.ConcurrentHashMultiset;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.Multiset;

/**
 * Multiple environments may make use of the same zookeeper cluster. This Factory allows those environments to share a
 * connection to the same zookeeper cluster, limiting the number of required connections by swift. Clients are expected
 * to return the Zookeeper instance to the factory so that it can be cleaned up and disposed of when no longer used (eg
 * after the environment configuration is changed, the existing zookeeper connection can be destroyed).
 */
public abstract class ZookeeperFactory<T> {
    private static final Logger LOG = LoggerFactory.getLogger(ZookeeperFactory.class);

    private final BiMap<Map<String, String>, T> zookeeperCache = HashBiMap.create();
    private final Multiset<Equivalence.Wrapper<T>> referenceCount = ConcurrentHashMultiset.create();

    public synchronized T getZookeeperForConfig(final Map<String, String> zooKeeperClientProperties) {
        T zookeeper = zookeeperCache.get(zooKeeperClientProperties);
        if (zookeeper == null) {
            LOG.info("Creating a new zookeeper client");
            zookeeper = load(zooKeeperClientProperties);
            zookeeperCache.put(zooKeeperClientProperties, zookeeper);
        } else {
            LOG.info("Returning an existing zookeeper client");
        }

        referenceCount.add(Equivalence.identity().wrap(zookeeper));

        return zookeeper;
    }

    public synchronized void returnZookeeper(final T zookeeper) {
        if (zookeeper != null) {
            referenceCount.remove(Equivalence.identity().wrap(zookeeper));

            int references = referenceCount.count(Equivalence.identity().wrap(zookeeper));
            if (references == 0) {
                LOG.info("Removing zookeeper connection.");
                try {
                    close(zookeeper);
                } catch (Throwable ex) {
                    LOG.info("Exception closing zookeeper", ex);
                }
                zookeeperCache.inverse().remove(zookeeper);
            } else {
                LOG.info("Zookeeper connection still in use by {} clients", references);
            }
        }
    }

    abstract T load(Map<String, String> zooKeeperClientProperties);

    abstract void close(T zookeeper);

}
