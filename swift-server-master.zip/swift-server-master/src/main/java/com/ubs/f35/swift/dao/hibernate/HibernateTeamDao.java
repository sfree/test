package com.ubs.f35.swift.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.swift.dao.TeamDao;
import com.ubs.f35.swift.dao.hibernate.framework.HibernateDaoSupport;
import com.ubs.f35.swift.dao.model.Team;

public class HibernateTeamDao extends HibernateDaoSupport implements TeamDao {

    private static final Logger LOG = LoggerFactory.getLogger(HibernateTeamDao.class);

    @Override
    public Team load(final Integer id) {
        return loadExpected(Team.class, id);
    }

    @Override
    public List<Team> loadAll(final String organisation) {
        Criteria criteria = getSession().createCriteria(Team.class);
        if (organisation != null) {
            criteria.createAlias("organisation", "o");
            criteria.add(Restrictions.eq("o.name", organisation));
        }
        return criteria.list();
    }

    @Override
    public void create(final Team team) {
        getSession().save(team);
    }

}
