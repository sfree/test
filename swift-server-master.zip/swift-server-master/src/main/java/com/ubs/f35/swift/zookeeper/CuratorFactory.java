package com.ubs.f35.swift.zookeeper;

import java.util.Properties;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.springframework.beans.factory.config.AbstractFactoryBean;

import com.ubs.f35.core.zookeeper.client.common.ZooKeeperClientPropertiesLoader;

public class CuratorFactory extends AbstractFactoryBean<CuratorFramework> {

    private final Properties zooKeeperClientProperties;

    public CuratorFactory(final Properties zooKeeperClientProperties) {
        this.zooKeeperClientProperties = zooKeeperClientProperties;
    }

    @Override
    public Class<CuratorFramework> getObjectType() {
        return CuratorFramework.class;
    }

    @Override
    protected CuratorFramework createInstance() throws Exception {
        String connectString = zooKeeperClientProperties.getProperty(ZooKeeperClientPropertiesLoader.HOST_PORTS);
        String sessionTimeoutMs = zooKeeperClientProperties
                .getProperty(ZooKeeperClientPropertiesLoader.SESSION_TIMEOUT);
        String connectionTimeoutMs = zooKeeperClientProperties
                .getProperty(ZooKeeperClientPropertiesLoader.CONNECTION_TIMEOUT);

        ExponentialBackoffRetry retryPolicy = new ExponentialBackoffRetry(1000, Integer.MAX_VALUE, 60000);

        CuratorFramework curatorFramework = CuratorFrameworkFactory.newClient(connectString,
                Integer.valueOf(sessionTimeoutMs), Integer.valueOf(connectionTimeoutMs), retryPolicy);
        curatorFramework.start();

        return curatorFramework;
    }
}
