package com.ubs.f35.swift.service;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Preconditions;
import com.google.common.base.Throwables;

/**
 * Executes JMX operations and converts any exceptions to a more user friendly stack trace.
 * 
 * @author stephelu
 * 
 */
public abstract class AbstractJmxProcessor {

    private final Logger LOG = LoggerFactory.getLogger(getClass());

    private ExecutorService executorService;

    public static String executeOperation(final Callable<String> runnable, final Logger logger) {
        Preconditions.checkNotNull(runnable);
        logger.info("Running JMX operation: {}", runnable);
        try {
            String result = runnable.call();
            logger.info("JMX operation successful: {}", runnable);
            return result;
        } catch (Exception e) {
            logger.error("Error running JMX operation: {}", runnable, e);
            return Throwables.getStackTraceAsString(e);
        }
    }

    protected String executeOperation(final Callable<String> runnable) {
        return executeOperation(runnable, LOG);
    }

    protected String executeOperations(final List<? extends Callable<String>> tasks) {
        StringBuilder result = new StringBuilder();

        List<Future<String>> results;
        try {
            results = executorService.invokeAll(tasks);
        } catch (InterruptedException e) {
            return Throwables.getStackTraceAsString(e);
        }

        for (int i = 0; i < tasks.size(); i++) {
            String agentOuput = getResult(tasks.get(i), results.get(i));
            result.append(tasks.get(i)).append(": ").append(agentOuput).append("\n");
        }

        return result.toString();
    }

    private String getResult(final Callable<String> task, final Future<String> taskResult) {
        try {
            String result = taskResult.get();
            LOG.info("JMX operation successful: {}", task);
            return result;
        } catch (ExecutionException e) {
            Throwable cause = e.getCause();
            LOG.error("Error running JMX operation: {}", task, cause);
            return Throwables.getStackTraceAsString(cause);
        } catch (Exception e) {
            LOG.error("Error running JMX operation: {}", task, e);
            return Throwables.getStackTraceAsString(e);
        }
    }

    abstract static class AgentCallable implements Callable<String> {
        final String agent;

        public AgentCallable(final String agent) {
            this.agent = agent;
        }

        @Override
        public String toString() {
            return agent;
        }
    }

    public void setExecutorService(final ExecutorService executorService) {
        this.executorService = executorService;
    }
}