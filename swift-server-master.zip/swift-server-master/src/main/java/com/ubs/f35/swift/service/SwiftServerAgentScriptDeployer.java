package com.ubs.f35.swift.service;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.base.Objects;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.ubs.f35.swift.deploy.glu.rest.GluDeploymentInvoker;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.environment.model.glu.Script;
import com.ubs.f35.swift.util.LoadingCacheUtil;

/**
 * Deploys scripts to the agent by downloading them from swift server
 */
public class SwiftServerAgentScriptDeployer {
    private static final Logger LOG = LoggerFactory.getLogger(SwiftServerAgentScriptDeployer.class);

    // loading cache is used to prevent multiple concurrent attempts to deploy the same script to one agent
    private final LoadingCache<Key, Boolean> processingCache = CacheBuilder.newBuilder()
            .expireAfterWrite(5, TimeUnit.MINUTES).build(
                    new CacheLoader<Key, Boolean>() {
                        @Override
                        public Boolean load(final Key key) throws Exception {
                            agentGluScriptDeployerUtil.deployScripts(key.gluAgentInvoker, key.agent, key.script,
                                    key.downloadUrl);
                            return true;
                        }
                    });

    private String baseSwiftUrl;
    private AgentGluScriptDeployerUtil agentGluScriptDeployerUtil;

    public void deployGluScript(final Entry entry, final GluDeploymentInvoker gluAgentInvoker) {
        String scriptFile = getScriptFile(entry.getScript());
        String downloadUrl = getScriptUrl(entry);

        LOG.debug("Deploying script to agent {} using download url {}", entry.getAgent(), downloadUrl);

        LoadingCacheUtil.getUnchecked(processingCache,
                new Key(entry.getAgent(), scriptFile, downloadUrl, gluAgentInvoker));
    }

    public String getScriptUrl(final Entry entry) {
        Script script = entry.getScript();

        String scriptFile = getScriptFile(script);
        return baseSwiftUrl + "/scripts/" + script.getPckage() + "/" + script.getVersion() + "/" + scriptFile;
    }

    private String getScriptFile(final Script script) {
        String scriptFile = script.getPckage() + "-" + script.getVersion() + ".jar";
        return scriptFile;
    }

    static class Key {
        String agent;
        String script;
        String downloadUrl;
        GluDeploymentInvoker gluAgentInvoker;

        public Key(final String agent, final String script, final String downloadUrl,
                final GluDeploymentInvoker gluAgentInvoker) {
            this.agent = agent;
            this.script = script;
            this.downloadUrl = downloadUrl;
            this.gluAgentInvoker = gluAgentInvoker;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(agent);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof Key) {
                Key that = (Key) object;
                return Objects.equal(this.agent, that.agent) &&
                        Objects.equal(this.script, that.script);
            }
            return false;
        }
    }

    @Required
    public void setBaseSwiftUrl(final String baseSwiftUrl) {
        this.baseSwiftUrl = baseSwiftUrl;
    }

    @Required
    public void setAgentGluScriptDeployerUtil(final AgentGluScriptDeployerUtil agentGluScriptDeployerUtil) {
        this.agentGluScriptDeployerUtil = agentGluScriptDeployerUtil;
    }
}
