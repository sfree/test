package com.ubs.f35.swift.dao.hibernate;

import java.security.AccessControlException;
import java.sql.Timestamp;
import java.util.UUID;

import org.joda.time.Duration;
import org.springframework.beans.factory.annotation.Required;

import com.ubs.f35.swift.dao.StateStore;
import com.ubs.f35.swift.dao.model.StateModel;
import com.ubs.f35.swift.model.JsonObjectMapper;
import com.ubs.f35.swift.state.OperationContextProvider;

public class HibernateStateStore implements StateStore {
    private OperationContextProvider opContextProvider;
    private HibernateStateDao stateDao;

    @Override
    public <T> T load(final UUID stateId, final Class<T> type) {
        StateModel state = load(stateId);

        return JsonObjectMapper.getInstance().readValue(state.getState(), type);
    }

    @Override
    public UUID create(final Object state) {
        StateModel stateModel = new StateModel();
        stateModel.setId(UUID.randomUUID());
        stateModel.setState(JsonObjectMapper.getInstance().writeValueAsString(state));
        stateModel.setUser(opContextProvider.getCurrentUser());
        stateModel.setExpiry(new Timestamp(Duration.standardDays(1).getMillis()));

        stateDao.save(stateModel);

        return stateModel.getId();
    }

    @Override
    public <T> UUID createOrUpdate(final UUID stateId, final T state) {
        if (stateId == null) {
            return create(state);
        }
        StateModel stateModel = load(stateId);
        stateModel.setState(JsonObjectMapper.getInstance().writeValueAsString(state));
        return stateModel.getId();
    }

    protected StateModel load(final UUID stateId) {
        StateModel state = stateDao.load(stateId);

        if (!opContextProvider.getCurrentUser().equals(state.getUser())) {
            throw new AccessControlException("Blocked access to another users state");
        }
        return state;
    }

    @Required
    public void setOpContextProvider(final OperationContextProvider opContextProvider) {
        this.opContextProvider = opContextProvider;
    }

    @Required
    public void setStateDao(final HibernateStateDao stateDao) {
        this.stateDao = stateDao;
    }

}