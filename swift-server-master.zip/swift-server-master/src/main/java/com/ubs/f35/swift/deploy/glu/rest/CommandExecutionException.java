package com.ubs.f35.swift.deploy.glu.rest;

public class CommandExecutionException extends RuntimeException {

    public CommandExecutionException(final String agent, final String exitCode, final String stdout, final String stderr) {
        super("Exit code " + exitCode + " from command on agent " + agent + ". \nstdout: " + tail(stdout, 1000)
                + "\nstderr: " + tail(stderr, 1000));
    }

    private static String tail(final String string, final int limit) {
        if (string == null || string.length() < limit) {
            return string;
        }

        // Attempt to find a relevant information in the output.
        int errorPos = string.lastIndexOf("ERROR");
        if (errorPos != -1) {
            return "... " + string.substring(errorPos, errorPos + Math.min(string.length() - errorPos, limit));
        }
        // if no error, assume the content towards the end of the response is most relevant
        return "... " + string.substring(string.length() - limit);
    }

}
