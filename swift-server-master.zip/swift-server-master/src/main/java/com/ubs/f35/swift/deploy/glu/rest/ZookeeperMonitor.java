package com.ubs.f35.swift.deploy.glu.rest;

import java.util.Collection;

import org.linkedin.zookeeper.tracker.NodeEvent;
import org.linkedin.zookeeper.tracker.NodeEventsListener;
import org.springframework.beans.factory.annotation.Required;

import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.zookeeper.ZooKeeperTreeTracker;
import com.ubs.f35.swift.zookeeper.ZooKeeperTreeTracker.ZKState;

/**
 * Uses the {@link ZooKeeperTreeTracker} to distribute changes to zookeeper nodes.
 * 
 * @author stephelu
 * 
 */
public abstract class ZookeeperMonitor implements NodeEventsListener<Object> {
    protected Environment environment;
    protected ZooKeeperTreeTracker<Object> treeTracker;

    /**
     * Filters out events which may be noise while the {@link ZooKeeperTreeTracker} is being initialised.
     */
    @Override
    public final void onEvents(final Collection<NodeEvent<Object>> events) {
        for (NodeEvent<Object> nodeEvent : events) {
            // Only process the event if the tracker is fully connected to zookeeper. Do not process events when
            // disconnected or nodes added to the tracker during a reconnection to zookeeper.
            if (treeTracker.getState() == ZKState.Connected &&
                    !treeTracker.getRoot().startsWith(nodeEvent.getPath())) {
                onEvent(nodeEvent);
            }
        }
    }

    abstract void onEvent(NodeEvent<Object> nodeEvent);

    @Required
    public void setTreeTracker(final ZooKeeperTreeTracker<Object> treeTracker) {
        this.treeTracker = treeTracker;
        treeTracker.registerListenerInBackground(this);
    }

    @Required
    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }
}
