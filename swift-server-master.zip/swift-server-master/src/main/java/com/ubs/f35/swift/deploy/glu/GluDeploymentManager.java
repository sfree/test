package com.ubs.f35.swift.deploy.glu;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentMap;

import org.linkedin.util.clock.Clock;
import org.linkedin.util.clock.SystemClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.Assert;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Maps;
import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.Deployment.DeploymentStatus;
import com.ubs.f35.swift.deploy.glu.action.Action;
import com.ubs.f35.swift.deploy.glu.action.ActionExecutor;
import com.ubs.f35.swift.deploy.glu.action.BaseAction;
import com.ubs.f35.swift.deploy.glu.action.BaseGroupedAction;
import com.ubs.f35.swift.deploy.glu.action.DeploymentContext;
import com.ubs.f35.swift.deploy.glu.action.ManualAction;
import com.ubs.f35.swift.deploy.glu.plan.DeploymentPlan;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.io.processor.ManualDeploymentInstructionMessage;
import com.ubs.f35.swift.server.ClientError;

public class GluDeploymentManager implements DeploymentExecutor {
    private static final Logger LOG = LoggerFactory.getLogger(GluDeploymentManager.class);

    private EnvironmentBeanFactory<DeploymentInvoker> gluAgentClientFactory;
    private EnvironmentDocumentStore environmentStore;
    private ActionExecutor deploymentActionExecutor;

    private Clock clock = SystemClock.INSTANCE;
    private final ConcurrentMap<UUID, DeploymentFuture> executingDeployments = Maps.newConcurrentMap();

    @Required
    public void setEnvironmentStore(final EnvironmentDocumentStore environmentStore) {
        this.environmentStore = environmentStore;
    }

    @Required
    public void setGluAgentClientFactory(final EnvironmentBeanFactory<DeploymentInvoker> gluAgentClientFactory) {
        this.gluAgentClientFactory = gluAgentClientFactory;
    }

    @Required
    public void setDeploymentActionExecutor(final ActionExecutor deploymentActionExecutor) {
        this.deploymentActionExecutor = deploymentActionExecutor;
    }

    @VisibleForTesting
    void setClock(final Clock clock) {
        this.clock = clock;
    }

    /**
     * Cancels the deployment. Any actions which are currently executing will continue until finished, but no further
     * actions will be initiated.
     * 
     * Returns true if the deployment was started and is now flagged to be cancelled. Returns false if the deployment
     * was not yet started.
     * 
     * @param deploymentId
     * @return
     */
    @Override
    public boolean cancelDeployment(final UUID deploymentId) {
        // This is potentially a memory leak if a cancel message is sent with no corresponding deploy message - the
        // deployments are only removed from the executingDeployments map when a deployment completes (successfully or
        // otherwise). If the client sends a cancel without triggering the deployment, it will never be removed from the
        // map. Currently, client logic will not allow this however.
        DeploymentFuture future = executingDeployments.putIfAbsent(deploymentId, new DeploymentFuture(true));
        if (future != null && !future.isCancelled()) {
            LOG.info("Cancelling deployment {} by cancelling future {}", deploymentId, future);
            future.cancel();
            return true;
        }
        return false;
    }

    @Override
    public void continueDeployment(final UUID deploymentId, final ManualDeploymentInstructionMessage deploymentMessage) {
        DeploymentFuture future = executingDeployments.get(deploymentId);
        if (future != null) {
            ManualAction manualAction = findActionById(future.getDeploymentPlan(),
                    deploymentMessage.getManualActionId(), ManualAction.class);
            if (deploymentMessage.isContinueDeployment()) {
                manualAction.markCompleted(deploymentMessage.getComment());
            } else {
                manualAction.markAborted(deploymentMessage.getComment());
            }
        } else {
            LOG.warn("Unable to find deployment with id {} to continue manual action {}", deploymentId,
                    deploymentMessage);
        }
    }

    private <T extends Action> T findActionById(final DeploymentPlan deploymentPlan, final String actionId,
            final Class<T> actionClass) {
        T found = findActionById(deploymentPlan.getActions(), actionId, actionClass);
        if (found == null) {
            throw new IllegalArgumentException("No action with id '" + actionId + "' found");
        }
        return found;
    }

    private <T extends Action> T findActionById(final List<Action> actions, final String actionId,
            final Class<T> actionClass) {
        for (Action action : actions) {
            if (actionId.equals(action.getId())) {
                return actionClass.cast(action);
            }
            else if (action instanceof BaseGroupedAction) {
                T found = findActionById(((BaseGroupedAction) action).getIncluded(), actionId, actionClass);
                if (found != null) {
                    return found;
                }
            }
        }

        return null;
    }

    @Override
    public void executeDeployment(final Deployment deployment, final DeploymentListener deploymentListener) {

        UUID deploymentId = deployment.getId();

        DeploymentFuture future = new DeploymentFuture();
        DeploymentFuture previousFuture = executingDeployments.putIfAbsent(deploymentId, future);

        if (previousFuture != null) {
            if (previousFuture.isCancelled()) {
                future = previousFuture;
            } else {
                LOG.warn("Not executing release {} as it is already processing", deploymentId);
                throw new IllegalStateException("Deployment already executing");
            }
        }

        try {
            executeDeploymentPlan(deployment, future, deploymentListener);
        } finally {
            executingDeployments.remove(deploymentId);
        }

    }

    private void executeDeploymentPlan(final Deployment deployment, final DeploymentFuture future,
            final DeploymentListener deploymentListener) {

        DeploymentPlan plan = deployment.getDeploymentPlan();
        future.setDeploymentPlan(plan);

        DeploymentStatus status = null;
        try {
            executeDeploymentPlanActions(plan, future, deploymentListener);
            status = DeploymentStatus.COMPLETED;
        } catch (DeploymentCancelledException ex) {
            LOG.info("Deployment cancelled {}", ex.getMessage());
            status = DeploymentStatus.CANCELLED;
        } catch (RuntimeException ex) {
            LOG.error("Deployment failed {}", ex);
            status = DeploymentStatus.FAILED;
        }

        // Set the deployment plan on the deployment record so that the DeploymentState
        // of the Actions (including any errors) gets written back to the DB
        deployment.setDeploymentPlan(plan);
        deploymentListener.deploymentComplete(status);
    }

    private void executeDeploymentPlanActions(final DeploymentPlan plan, final DeploymentFuture future,
            final DeploymentListener listener) {

        final ActionExecutor notifyingActionExecutor = new ActionExecutor() {
            @Override
            public void execute(final DeploymentContext context, final Action action) {
                // only execute this action and send notifications if its included
                if (executeAction(action)) {
                    if (future.isCancelled()) {
                        LOG.warn("Deployment has been cancelled");
                        throw new DeploymentCancelledException();
                    }

                    long startTime = clock.currentTimeMillis();
                    action.setDeploymentState(DeploymentState.running(startTime));
                    notify(listener, action);
                    try {
                        deploymentActionExecutor.execute(context, action);
                        action.setDeploymentState(DeploymentState.completed(startTime, clock.currentTimeMillis()));
                        notify(listener, action);
                    } catch (RuntimeException ex) {
                        action.setDeploymentState(DeploymentState.failed(startTime, clock.currentTimeMillis(),
                                new ClientError(ex)));
                        notify(listener, action);
                        // don't handle for now.
                        throw ex;
                    }
                }
            }

            private boolean executeAction(final Action action) {
                if (action instanceof BaseAction) {
                    return ((BaseAction) action).isExecute();
                }
                return true;
            }

            private void notify(final DeploymentListener listener, final Action action) {
                if (listener != null) {
                    listener.deploymentActionChanged(action);
                }
            }
        };

        final DeploymentContext context = new DeploymentContext(notifyingActionExecutor, gluAgentClientFactory,
                environmentStore);

        // API only allows multiple plans for retrieving legacy saved plans.
        Assert.isTrue(plan.getActions().size() == 1, "deployment plans may only have a single action");
        notifyingActionExecutor.execute(context, plan.getActions().get(0));
    }

    static class DeploymentFuture {
        private volatile boolean cancelled;
        private DeploymentPlan deploymentPlan;

        public DeploymentFuture() {
            this.cancelled = false;
        }

        public DeploymentFuture(final boolean cancelled) {
            this.cancelled = cancelled;
        }

        public void cancel() {
            cancelled = true;
        }

        public boolean isCancelled() {
            return cancelled;
        }

        public DeploymentPlan getDeploymentPlan() {
            return deploymentPlan;
        }

        public void setDeploymentPlan(final DeploymentPlan deploymentPlan) {
            this.deploymentPlan = deploymentPlan;
        }

    }

}
