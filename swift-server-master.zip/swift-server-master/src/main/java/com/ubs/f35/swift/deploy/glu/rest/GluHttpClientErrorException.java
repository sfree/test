package com.ubs.f35.swift.deploy.glu.rest;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;

import com.ubs.f35.swift.deploy.glu.rest.GluResponseErrorHandler.ExceptionDetails;

public class GluHttpClientErrorException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final HttpStatus statusCode;
    private final Map<String, Object> errorResponse;
    private final List<ExceptionDetails> errorDetails;

    public GluHttpClientErrorException(final String message, final List<ExceptionDetails> errorDetails,
            final HttpStatus statusCode, final Map<String, Object> errorResponse) {
        super(message);
        this.errorDetails = errorDetails;
        this.statusCode = statusCode;
        this.errorResponse = errorResponse;
    }

    public List<ExceptionDetails> getErrorDetails() {
        return errorDetails;
    }

    public HttpStatus getStatusCode() {
        return statusCode;
    }

    public Map<String, Object> getErrorResponse() {
        return errorResponse;
    }

}
