package com.ubs.f35.swift.zookeeper;

import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooDefs.Ids;
import org.linkedin.zookeeper.client.LifecycleListener;
import org.linkedin.zookeeper.client.ZKClient;
import org.linkedin.zookeeper.client.ZKClient.State;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.util.concurrent.Uninterruptibles;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.executors.SwiftExecutors;
import com.ubs.f35.swift.zookeeper.ZooKeeperTreeTracker.ZKState;
import com.ubs.f35.swift.zookeeper.ZookeeperTemplate.ZookeeperExecutor;

/**
 * Exposes functionality provided by the GLU orchestration engine.
 * 
 * @author stephelu
 * 
 */
public class ZooKeeperTreeTrackerFactory {

    private static final Logger LOG = LoggerFactory.getLogger(ZooKeeperTreeTrackerFactory.class);

    // Injected
    private Executor executor = SwiftExecutors.getZookeeperExecutor();
    private String environment;
    private String trackPath;
    private ZKClient zkClient;
    private int batchZookeeperConnectEventsSeconds = 1;

    // built / derived
    private ZooKeeperTreeTracker<Map> tracker;
    private final Semaphore trackLock = new Semaphore(1);

    private final LifecycleListener lifecycleListener = new LifecycleListener() {
        @Override
        public void onDisconnected() {
            LOG.info("Disconnected from {} zookeeper.  Stale tracking of {}", environment, trackPath);
            tracker.setState(ZKState.Disconnected);
        }

        @Override
        public void onConnected() {
            tracker.setState(ZKState.Connecting);
            // Seeing lots of connected events in succession. Ignoring those that occur while tracking is already
            // starting.
            if (trackLock.tryAcquire()) {
                LOG.info("Connected to {} zookeeper.  Schedule tracking {}", environment, trackPath);

                executor.execute(new Runnable() {
                    @Override
                    public void run() {
                        Thread.currentThread().setName(environment + "-zookeeper-background");
                        // Delaying for one second before releasing the lock so that the rush of zookeeper connect
                        // events that came through are filtered down to one event (or at most 1 event per second)
                        Uninterruptibles.sleepUninterruptibly(batchZookeeperConnectEventsSeconds, TimeUnit.SECONDS);

                        // the lock is released first as if the tracking fails, we can't afford to lose any events.
                        trackLock.release();
                        trackZookeeper();
                    }
                });
            } else {
                LOG.info("Connected to {} zookeeper.  Not tracking {} as already scheduled to start tracking",
                        environment, trackPath);
            }
        }
    };

    public ZooKeeperTreeTracker<Map> getObject() throws Exception {
        LOG.info("ZooKeeperTreeTrackerFactory createInstance {}", trackPath);

        tracker = createTrackerInstance();

        return tracker;
    }

    /**
     * Don't start the zookeeper tracking until the spring application wire up has completed. This will help ensure
     * application startup isn't slowed down by zookeeper noise.
     */
    public void startTracking() {
        LOG.info("Starting zookeeper tracking {} - {}", environment, trackPath);
        // Start tracking in the background. Don't slow the main thread / server startup.
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Thread.currentThread().setName(environment + "-zookeeper-background");
                register();
            }
        });
    }

    /**
     * Disposes of this tracker when it is no longer required.
     */
    public void destroy() {
        LOG.info("Destroying zookeeper tracker for environment {} tracking {}", environment, trackPath);
        tracker.destroy();
        zkClient.removeListener(lifecycleListener);
    }

    private void register() {
        zkClient.registerListener(lifecycleListener);
        synchronized (zkClient) {
            if (zkClient.getZKClientState() == State.NONE) {
                zkClient.start();
            }
        }
    }

    @VisibleForTesting
    protected ZooKeeperTreeTracker<Map> createTrackerInstance() {
        return new ZooKeeperTreeTracker<Map>(zkClient, ZKMapDataReader.INSTANCE, trackPath, executor);
    }

    private void trackZookeeper() {
        try {
            ZookeeperTemplate.doInZookeeper(new ZookeeperExecutor<Void>() {
                @Override
                public Void doInZK() throws KeeperException, InterruptedException {
                    if (zkClient.exists(trackPath) == null) {
                        LOG.info("Ensuring trackPath {} exists", trackPath);
                        zkClient.create(trackPath, (byte[]) null, Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
                    }

                    LOG.info("Starting tracking of path {} in environment {}", trackPath, environment);
                    tracker.track();
                    LOG.info("Completed tracking of path {} in environment {}", trackPath, environment);

                    tracker.setState(ZKState.Connected);

                    return null;
                }
            });
        } catch (Throwable t) {
            LOG.error("Exception attempting to track zookeeper path {}", trackPath, t);
        }
    }

    @Required
    public void setZkClient(final ZKClient zkClient) {
        this.zkClient = zkClient;
    }

    @Required
    public void setEnvironment(final Environment environment) {
        this.environment = environment.getOrganisation().getName() + "." + environment.getName();
    }

    @Required
    public void setTrackPath(final String trackPath) {
        this.trackPath = trackPath;
    }

    @VisibleForTesting
    void setExecutor(final Executor executor) {
        this.executor = executor;
    }

    @VisibleForTesting
    void setBatchZookeeperConnectEventsSeconds(final int batchZookeeperConnectEventsSeconds) {
        this.batchZookeeperConnectEventsSeconds = batchZookeeperConnectEventsSeconds;
    }
}
