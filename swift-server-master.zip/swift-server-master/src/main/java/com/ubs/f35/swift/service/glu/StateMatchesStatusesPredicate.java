package com.ubs.f35.swift.service.glu;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.google.common.base.Predicate;
import com.ubs.f35.swift.model.State;

/**
 * 
 * @author levyjo
 * 
 */
public class StateMatchesStatusesPredicate implements Predicate<State> {

    private final List<String> statuses;

    public StateMatchesStatusesPredicate(final List<String> statuses) {
        this.statuses = statuses;
    }

    @Override
    public boolean apply(final State state) {
        if (CollectionUtils.isEmpty(statuses)) {
            return true;
        }
        return statuses.contains(state.getStatus());
    }

}
