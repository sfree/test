package com.ubs.f35.swift.deploy.template.model;

import com.google.common.base.Objects;
import com.ubs.f35.swift.deploy.template.model.TemplateGroupAction.Mode;
import com.ubs.f35.swift.environment.model.glu.DeploymentAction;

public class TemplateArtifactAction implements TemplateAction {
    // Indicates if this operation should occur on all artifacts concurrently or one after the other..
    private Mode mode;
    private DeploymentAction action;
    private String groupId;
    private String artifactId;

    public Mode getMode() {
        return mode;
    }

    public void setMode(final Mode mode) {
        this.mode = mode;
    }

    public DeploymentAction getAction() {
        return action;
    }

    public void setAction(final DeploymentAction action) {
        this.action = action;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(final String groupId) {
        this.groupId = groupId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(final String artifactId) {
        this.artifactId = artifactId;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(mode, action, groupId, artifactId);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof TemplateArtifactAction) {
            TemplateArtifactAction that = (TemplateArtifactAction) object;
            return Objects.equal(this.mode, that.mode)
                    && Objects.equal(this.action, that.action)
                    && Objects.equal(this.groupId, that.groupId)
                    && Objects.equal(this.artifactId, that.artifactId);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("mode", mode)
                .add("action", action)
                .add("groupId", groupId)
                .add("artifactId", artifactId)
                .toString();
    }

}
