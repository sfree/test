package com.ubs.f35.core.zookeeper.client;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.config.AbstractFactoryBean;

/**
 * This only exists because Spring gets confused by using a static factory that returns an Object with @Required
 * annotations.
 * 
 * @author stephelu
 * 
 */
public class ZooKeeperClientWrapper extends AbstractFactoryBean<ZooKeeperClient> {

    private Properties zooKeeperClientProperties;
    private boolean waitConnection;

    @Required
    public void setZooKeeperClientProperties(final Properties zooKeeperClientProperties) {
        this.zooKeeperClientProperties = zooKeeperClientProperties;
    }

    @Required
    public void setWaitConnection(final boolean waitConnection) {
        this.waitConnection = waitConnection;
    }

    @Override
    public Class<?> getObjectType() {
        return ZooKeeperClient.class;
    }

    @Override
    protected ZooKeeperClient createInstance() throws Exception {
        return ZooKeeperClient.newFromZooKeeperClientProperties(zooKeeperClientProperties, waitConnection);
    }
}
