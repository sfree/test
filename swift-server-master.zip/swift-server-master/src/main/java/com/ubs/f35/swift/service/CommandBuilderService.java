package com.ubs.f35.swift.service;

import org.springframework.beans.factory.annotation.Required;

import com.google.common.annotations.VisibleForTesting;

public class CommandBuilderService {
    private String baseInstallDir;
    private String defaultScriptsDir;
    private String defaultSymlink;

    private String buildInstallDir() {
        return buildInstallDir(defaultSymlink);
    }

    private String buildInstallDir(final String link) {
        return baseInstallDir + "/" + defaultScriptsDir + "/" + link;
    }

    public String buildInstallDir(final String group, final String artifact, final String link) {
        return baseInstallDir + "/" + group + "/" + artifact + "/" + link;
    }

    public String buildCommand(final String command) {
        return buildInstallDir() + "/bin/" + command;
    }

    public String buildCommand(final String link, final String command) {
        return buildInstallDir(link) + "/bin/" + command;
    }

    @VisibleForTesting
    String buildCommand(final String group, final String artifact, final String link, final String command) {
        return buildInstallDir(group, artifact, link) + "/bin/" + command;
    }

    @Required
    public void setBaseInstallDir(final String baseInstallDir) {
        this.baseInstallDir = baseInstallDir;
    }

    @Required
    public void setDefaultScriptsDir(final String defaultScriptsDir) {
        this.defaultScriptsDir = defaultScriptsDir;
    }

    @Required
    public void setDefaultSymlink(final String defaultSymlink) {
        this.defaultSymlink = defaultSymlink;
    }
}
