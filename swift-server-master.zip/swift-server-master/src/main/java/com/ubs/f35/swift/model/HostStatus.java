package com.ubs.f35.swift.model;

import java.util.List;

import com.google.common.base.Objects;

public class HostStatus {
    private String host;
    private boolean agentUp;
    private String agentVersion;
    private String runningUser;
    private boolean monitorUp;

    private List<Double> loadAverages;

    private int numberOfCpus;
    private long memFreeMb; // Includes caches and buffers
    private long memTotalMb;
    private long swapFreeMb;
    private long swapTotalMb;

    public String getHost() {
        return host;
    }

    public void setHost(final String host) {
        this.host = host;
    }

    public boolean isAgentUp() {
        return agentUp;
    }

    public void setAgentUp(final boolean agentUp) {
        this.agentUp = agentUp;
    }

    public String getAgentVersion() {
        return agentVersion;
    }

    public void setAgentVersion(final String agentVersion) {
        this.agentVersion = agentVersion;
    }

    public String getRunningUser() {
        return runningUser;
    }

    public void setRunningUser(final String runningUser) {
        this.runningUser = runningUser;
    }

    public boolean isMonitorUp() {
        return monitorUp;
    }

    public void setMonitorUp(final boolean monitorUp) {
        this.monitorUp = monitorUp;
    }

    public List<Double> getLoadAverages() {
        return loadAverages;
    }

    public void setLoadAverages(final List<Double> loadAverages) {
        this.loadAverages = loadAverages;
    }

    public long getMemFreeMb() {
        return memFreeMb;
    }

    public void setMemFreeMb(final long memFreeMb) {
        this.memFreeMb = memFreeMb;
    }

    public long getSwapFreeMb() {
        return swapFreeMb;
    }

    public void setSwapFreeMb(final long swapFreeMb) {
        this.swapFreeMb = swapFreeMb;
    }

    public int getNumberOfCpus() {
        return numberOfCpus;
    }

    public void setNumberOfCpus(final int numberOfCpus) {
        this.numberOfCpus = numberOfCpus;
    }

    public long getMemTotalMb() {
        return memTotalMb;
    }

    public void setMemTotalMb(final long memTotalMb) {
        this.memTotalMb = memTotalMb;
    }

    public long getSwapTotalMb() {
        return swapTotalMb;
    }

    public void setSwapTotalMb(final long swapTotalMb) {
        this.swapTotalMb = swapTotalMb;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(host, agentUp, agentVersion, runningUser, monitorUp, loadAverages, numberOfCpus,
                memFreeMb, memTotalMb, swapFreeMb, swapTotalMb);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof HostStatus) {
            HostStatus that = (HostStatus) object;
            return Objects.equal(this.host, that.host)
                    && Objects.equal(this.agentUp, that.agentUp)
                    && Objects.equal(this.agentVersion, that.agentVersion)
                    && Objects.equal(this.runningUser, that.runningUser)
                    && Objects.equal(this.monitorUp, that.monitorUp)
                    && Objects.equal(this.loadAverages, that.loadAverages)
                    && Objects.equal(this.numberOfCpus, that.numberOfCpus)
                    && Objects.equal(this.memFreeMb, that.memFreeMb)
                    && Objects.equal(this.memTotalMb, that.memTotalMb)
                    && Objects.equal(this.swapFreeMb, that.swapFreeMb)
                    && Objects.equal(this.swapTotalMb, that.swapTotalMb);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("host", host)
                .add("agentUp", agentUp)
                .add("agentVersion", agentVersion)
                .add("runningUser", runningUser)
                .add("monitorUp", monitorUp)
                .add("loadAverages", loadAverages)
                .add("numberOfCpus", numberOfCpus)
                .add("memFreeMb", memFreeMb)
                .add("memTotalMb", memTotalMb)
                .add("swapFreeMb", swapFreeMb)
                .add("swapTotalMb", swapTotalMb)
                .toString();
    }

}
