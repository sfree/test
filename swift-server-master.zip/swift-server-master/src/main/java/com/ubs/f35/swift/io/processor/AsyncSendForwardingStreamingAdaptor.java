package com.ubs.f35.swift.io.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.ubs.f35.core.AuthenticationPrincipal;
import com.ubs.f35.core.auth.UserValidationException;
import com.ubs.f35.swift.model.JsonObjectMapper;
import com.ubs.f35.swift.security.WebSsoAuthProvider;
import com.ubs.f35.swift.server.ClientError;
import com.ubs.f35.swift.state.OperationContextProvider;
import com.ubs.sapi.service.StreamingAdaptor;
import com.ubs.sapi.service.StreamingService;
import com.ubs.sapi.service.context.StreamingInboundContext;
import com.ubs.stomp.model.client.SendFrame;
import com.ubs.stomp.model.server.MessageFrame;

/**
 * A {@link StreamingAdaptor} which forwards the send method invocations on a background thread. This is only done after
 * authenticating the user (which might be slow).
 * 
 */
public final class AsyncSendForwardingStreamingAdaptor extends StreamingAdaptor {
    private final Logger LOG = LoggerFactory.getLogger(this.getClass());

    private OperationContextProvider opContextProvider;
    private WebSsoAuthProvider webSsoAuthProvider;
    private ConverstationProcessor converstationProcessor;

    @Required
    public void setOpContextProvider(final OperationContextProvider opContextProvider) {
        this.opContextProvider = opContextProvider;
    }

    @Required
    public void setWebSsoAuthProvider(final WebSsoAuthProvider webSsoAuthProvider) {
        this.webSsoAuthProvider = webSsoAuthProvider;
    }

    @Required
    public void setConverstationProcessor(final ConverstationProcessor converstationProcessor) {
        this.converstationProcessor = converstationProcessor;
    }

    @Override
    public final boolean send(final StreamingInboundContext<SendFrame> context) {
        service().executeInBackground(new Runnable() {
            @Override
            public void run() {
                sendBackground(context.frame());
            }
        });

        return NEXT;
    }

    private void sendBackground(final SendFrame sendFrame) {
        String authToken = sendFrame.getHeader("LWSTOKEN");
        try {
            AuthenticationPrincipal principal = webSsoAuthProvider.getPrincipal(authToken);
            opContextProvider.setCurrentUser(principal);

            ConversationHandle conversationHandle = new ConversationHandle(service(),
                    sendFrame.getDestination());

            Object message = sendFrame.getBody();
            try {
                converstationProcessor.onMessage(principal, conversationHandle, message);
            } catch (RuntimeException ex) {
                LOG.error("Exception proceeding conversation message {}", message, ex);
                conversationHandle.onMessage(new ClientError(ex));
            } finally {
                opContextProvider.reset();
            }
        } catch (UserValidationException e) {
            LOG.info("Invalid user.  Not processing message");
        }
    }

    interface ConverstationProcessor {
        void onMessage(AuthenticationPrincipal principal,
                ConversationHandle conversationHandle,
                Object message);
    }

    static class ConversationHandle {

        private final StreamingService service;
        private final String destination;

        public ConversationHandle(final StreamingService service, final String destination) {
            this.service = service;
            this.destination = destination;
        }

        public void onMessage(final Object message) {
            MessageFrame messageFrame = MessageFrame.builder()
                    .setDestination(destination)
                    .setBody(JsonObjectMapper.getInstance().writeValueAsString(message)).build();

            service.send(messageFrame);
        }

        public String getDestinationId() {
            return destination;
        }

    }
}
