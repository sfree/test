package com.ubs.f35.swift.properties.bulk;

import java.util.List;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonTypeName;

@JsonTypeName("instance-selection")
public class BulkArtifactInstanceSelection implements BulkUpdateSelection {
    final List<String> artifactInstanceIds;

    @JsonCreator
    public BulkArtifactInstanceSelection(@JsonProperty("artifactInstanceIds") final List<String> artifactInstanceIds) {
        this.artifactInstanceIds = artifactInstanceIds;
    }

    public List<String> getArtifactInstanceIds() {
        return artifactInstanceIds;
    }
}