package com.ubs.f35.swift.service;

import java.util.List;

import com.google.common.base.Function;
import com.ubs.f35.swift.config.model.ArtifactCommonConfig;

public class GetDependantOnArtifactFunction implements Function<ArtifactCommonConfig, List<ArtifactCommonConfig>> {
    static final GetDependantOnArtifactFunction INSTANCE = new GetDependantOnArtifactFunction();

    @Override
    public List<ArtifactCommonConfig> apply(final ArtifactCommonConfig input) {
        return input.getDependentOnThis();
    }
}