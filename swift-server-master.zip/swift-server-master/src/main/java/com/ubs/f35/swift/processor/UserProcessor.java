package com.ubs.f35.swift.processor;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.ObjectUtils;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Sets;
import com.ubs.f35.pcc.people2.model.SmallProfile2;
import com.ubs.f35.swift.security.UserDetailsLookup;

@Controller
@RequestMapping(value = "/api/user")
public class UserProcessor {

    private UserDetailsLookup userDetailsLookup;

    @RequestMapping(value = "/details/{guid}", method = RequestMethod.GET)
    @ResponseBody
    public Map<String, Object> getUserDetails(@PathVariable final String guid) {
        return userDetailsLookup.getUserDetails(guid);
    }

    @RequestMapping(value = "profiles", method = RequestMethod.GET)
    @ResponseBody
    public Collection<SmallProfile2> getUserProfiles(@RequestParam("guid") final List<String> guids) {

        Set<SmallProfile2> result = Sets.newLinkedHashSetWithExpectedSize(guids.size());
        for (String guid : guids) {
            Map<String, Object> oidMap = userDetailsLookup.getUserDetails(guid);
            SmallProfile2 profile = new SmallProfile2(guid);
            if (oidMap != null) {
                String firstname = ObjectUtils.toString(oidMap.get("givenName"));
                String lastname = ObjectUtils.toString(oidMap.get("sn"));
                String email = ObjectUtils.toString(oidMap.get("mail"));
                profile.setFirstName(firstname);
                profile.setLastName(lastname);
                profile.setBusinessName(firstname + " " + lastname);
                profile.setEmployee(true);
                profile.setEmail(email);
            }
            result.add(profile);

        }
        return result;

    }

    @Required
    public void setUserDetailsLookup(final UserDetailsLookup userDetailsLookup) {
        this.userDetailsLookup = userDetailsLookup;
    }
}
