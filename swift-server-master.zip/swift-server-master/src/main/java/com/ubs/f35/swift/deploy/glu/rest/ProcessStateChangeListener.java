package com.ubs.f35.swift.deploy.glu.rest;

import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.environment.model.glu.Entry;

/**
 * Callback to receive notifications when a process managed by glu changes state.
 * 
 * @author stephelu
 * 
 */
public interface ProcessStateChangeListener {

    /**
     * Called when a processes state changes.
     * 
     * @param environment
     * @param mountPoint
     * @param removedEntry
     *            provided if the event which triggered this removed the entry, and that entry would no longer be able
     *            to be resolved.
     */
    void processStateChanged(Environment environment, String mountPoint, Entry removedEntry);
}
