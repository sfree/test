package com.ubs.f35.swift.security;

import static com.ubs.f35.swift.util.ErrorUtils.buildErrorLink;

import java.security.AccessControlException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.SwiftGroupDao;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.EnvironmentBeanFactory;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.state.OperationContextProvider;

/**
 * Controls access to environments and actions by authorising the current user against an LDAP directory.
 * <p>
 * Access rights are additive. For example, if both the rights SWIFT-DEV-CID and SWIFT-DEV-CID-LOGS provides log access
 * to artifact ABC, the the user only requires either of those rights to view the logs for ABC.
 * 
 * @author levyjo
 * 
 */
public class AuthorisationController {
    private static final Logger LOG = LoggerFactory.getLogger(AuthorisationController.class);

    private UserGroupsLookup userGroupsLookup;
    private OperationContextProvider opContextProvider;
    private EnvironmentBeanFactory<String> environmentAccessRightLookup;
    private Map<String, OrganisationBeanFactory<List<String>>> roleToAccessRightLookup;
    private SwiftGroupDao swiftGroupDao;
    private EnvironmentDocumentStore environmentDocumentStore;

    // derived
    private volatile Multimap<String, Environment> orgEnvironments;

    public static final String ARP_GROUP_ADMIN_SUFFIX = "-ADMIN";

    // TODO this isn't ideal. Having the ability for the server to return html in messages might be blocked at some
    // point.
    static final String SWIFT_ARP_TUTORIAL_HTML = buildErrorLink(
            "http://confluence.swissbank.com/display/neo/Swift+Entitlements", "ARP");

    /**
     * Check whether the current user has permission to perform actions in the given environment. <br>
     * This method returns a boolean which is useful when application logic or control flow depends on the user's
     * permission, or for flagging the user's permission to the client in order to enable/disable buttons. If you simply
     * want an operation to fail if the user has no permission, use {@link #checkEnvironmentAccess(String)} instead
     * which throws an exception instead of returning false.
     * 
     * @param environment
     * @return true if current user has access permission, false otherwise
     */
    public boolean canAccessEnvironment(final Environment environment) {
        return getUserGroups().contains(environmentAccessRightLookup.get(environment));
    }

    /**
     * Check whether the current user has the specified access right.
     * <p>
     * This is marked as protected so that it's clear there are no external users of this method, but it can be changed
     * to public when required.
     * 
     * @param role
     * @return true if current user has access permission, false otherwise
     */
    protected boolean hasAccess(final String organisation, final String role) {
        final List<String> accessRights = getAccessRights(organisation, role);
        return Iterables.any(getUserGroups(), new Predicate<String>() {
            @Override
            public boolean apply(final String userGroup) {
                return accessRights.contains(userGroup);
            }
        });
    }

    /**
     * Check whether the current user has any Swift permissions. <br>
     * This method returns a boolean which is useful when application logic or control flow depends on the user's
     * permission, or for flagging the user's permission to the client in order to enable/disable buttons. If you simply
     * want an operation to fail if the user has no permission, use {@link #checkAccess()} instead which throws an
     * exception instead of returning false.
     * 
     * @param environment
     * @return true if current user has access permission, false otherwise
     */
    public boolean canAccess() {
        return !getUserGroups().isEmpty();
    }

    /**
     * Check whether the current user has permission to perform actions in the given environment and throws an
     * {@link AccessControlException} if not. If there is some application logic that depends on the user's access, use
     * {@link #canAccessEnvironment(String)} instead, which returns a boolean.
     * 
     * @param environment
     * @throws AccessControlException
     *             if the user is not permissioned in the given environment
     */
    public void checkEnvironmentAccess(final Environment environment) throws AccessControlException {
        if (!canAccessEnvironment(environment)) {
            throw new AccessControlException(
                    "Access denied. Please request access to Swift role "
                            + environmentAccessRightLookup.get(environment)
                            + " in " + SWIFT_ARP_TUTORIAL_HTML);
        }
    }

    public void checkEnvironmentAccess(final Environment environment, final Permission permission)
            throws AccessControlException {
        if (!permission.isReadOnly() || environmentDocumentStore.isProdEnvironment(environment)) {
            checkEnvironmentAccess(environment);
        }
    }

    public boolean canAccess(final Environment environment, final String hostName, final NexusArtifact artifact,
            final Permission permission) {
        try {
            checkAccess(environment, hostName, artifact, permission);
            return true;
        } catch (AccessControlException ex) {
            return false;
        }
    }

    public Set<NexusArtifact> canAccess(final Environment environment, final List<NexusArtifact> artifacts,
            final Permission permission) {
        Set<NexusArtifact> canAccess = new HashSet<>();

        // final all groups for the host, artifact and permission combination.
        Multimap<NexusArtifact, String> artifactIndex = swiftGroupDao.findGroupsByArtifact(environment, artifacts,
                permission);

        for (NexusArtifact artifact : artifacts) {
            try {
                validateAccess(environment, artifact.getArtifactId(), permission, artifactIndex.get(artifact));
                canAccess.add(artifact);
            } catch (AccessControlException ex) {
                LOG.trace("User does not have access {} to artifact {}", permission, artifact.getArtifactId());
            }
        }
        return canAccess;
    }

    public void checkAccess(final Environment environment, final NexusArtifact artifact, final Permission permission) {
        checkAccess(environment, Collections.<String>emptyList(), Collections.singletonList(artifact), permission);
    }

    public void checkAccess(final Environment environment, final String hostname, final Permission permission) {
        checkAccess(environment, Collections.singletonList(hostname), Collections.<NexusArtifact>emptyList(),
                permission);
    }

    public void checkAccess(final Environment environment, final String hostName, final NexusArtifact artifact,
            final Permission permission) {
        checkAccess(environment, Collections.singletonList(hostName), Collections.singletonList(artifact), permission);
    }

    public void checkAccess(final Environment environment, final List<String> hostnames,
            final List<NexusArtifact> artifacts, final Permission permission) {
        // final all groups for the host, artifact and permission combination.
        Multimap<String, String> hostIndex = swiftGroupDao.findGroupsByHost(environment, hostnames, permission);
        Multimap<NexusArtifact, String> artifactIndex = swiftGroupDao.findGroupsByArtifact(environment, artifacts,
                permission);

        for (String hostName : hostnames) {
            validateAccess(environment, hostName, permission, hostIndex.get(hostName));
        }

        for (NexusArtifact artifact : artifacts) {
            validateAccess(environment, artifact.getArtifactId(), permission, artifactIndex.get(artifact));
        }
    }

    private void validateAccess(final Environment environment, final String accessedName, final Permission permission,
            final Collection<String> groups) {
        if (groups.isEmpty()) {
            // requires complete environment access unless it's a readonly permission in a non-prod environment
            if (!canAccessEnvironment(environment)
                    && (!permission.isReadOnly() || environmentDocumentStore.isProdEnvironment(environment))) {
                throw new AccessControlException(permission.friendlyName() + " for " + accessedName + " requires "
                        + environmentAccessRightLookup.get(environment) + ". Please request access in "
                        + SWIFT_ARP_TUTORIAL_HTML);
            } else {
                checkAccess();
            }
        } else {
            // requires access to any one of the groups
            boolean hasAccess = Iterables.any(groups, new Predicate<String>() {
                @Override
                public boolean apply(final String group) {
                    return hasArpAccessRight(group);
                }
            });
            if (!hasAccess) {
                throw new AccessControlException(permission.friendlyName() + " for " + accessedName + " requires "
                        + groupNames(groups) + ". Please request access in " + SWIFT_ARP_TUTORIAL_HTML);
            }
        }
    }

    private String groupNames(final Collection<String> requiredGroups) {
        return StringUtils.collectionToDelimitedString(requiredGroups, ", ");
    }

    /**
     * Check whether the current user has the specified access right and throws an {@link AccessControlException} if
     * not. If there is some application logic that depends on the user's access, use {@link #hasAccessRight(String)}
     * instead, which returns a boolean.
     * 
     * @param role
     * @throws AccessControlException
     *             if the user does not have the specified access right
     */
    public void checkAccess(final String organisation, final String role) throws AccessControlException {
        checkArpAccess(getAccessRights(organisation, role));
    }

    /**
     * Check whether the current user has the specified ARP access right and throws an {@link AccessControlException} if
     * not.
     * 
     * @param accessRight
     * @throws AccessControlException
     *             if the user does not have the specified access right
     */
    public void checkAccess(final String arpAccessRight) throws AccessControlException {
        checkArpAccess(arpAccessRight);
    }

    /**
     * Check whether the current user has Swift permissions and throws an {@link AccessControlException} if not. If
     * there is some application logic that depends on the user's access, use {@link #canAccess()} instead, which
     * returns a boolean.
     * 
     * @param environment
     * @throws AccessControlException
     *             if the user is not permissioned in any Swift group
     */
    public void checkAccess() throws AccessControlException {
        if (!canAccess()) {
            throw new AccessControlException(
                    "Access denied. Please request access to a Swift role in " + SWIFT_ARP_TUTORIAL_HTML);
        }
    }

    /**
     * Returns a list of environments that the current user is permissioned for.
     * 
     * @param organisation
     * 
     * @return List of environments
     */
    public List<Environment> getUserEnvironments(final String organisation) {
        Collection<Environment> environments = orgEnvironments.get(organisation);
        List<Environment> allowedEnvs = Lists.newArrayListWithExpectedSize(orgEnvironments.size());
        for (Environment e : environments) {
            if (canAccessEnvironment(e)) {
                allowedEnvs.add(e);
            }
        }
        return allowedEnvs;
    }

    /**
     * Returns a list of access rights that the current user has.
     * 
     * @return List of access rights
     */
    public List<String> getUserAccessRights(final String organisation) {
        List<String> accessRights = Lists.newArrayListWithExpectedSize(roleToAccessRightLookup.size());
        for (String right : roleToAccessRightLookup.keySet()) {
            if (hasAccess(organisation, right)) {
                accessRights.add(right);
            }
        }
        return accessRights;
    }

    public List<String> getUserAdminGroups() {
        return Lists.newArrayList(Collections2.filter(getUserGroups(), new Predicate<String>() {
            @Override
            public boolean apply(final String input) {
                return input.endsWith(ARP_GROUP_ADMIN_SUFFIX);
            }
        }));
    }

    /**
     * Check whether the user has the admin right associated with the specified access right
     * 
     * @param accessRight
     */
    public void checkAdminAccess(final String accessRight) {
        checkArpAccess(accessRight + ARP_GROUP_ADMIN_SUFFIX);
    }

    /**
     * Check whether the current user has the specified ARP access right.
     * 
     * @param accessRight
     * @return true if current user has access permission, false otherwise
     */
    public boolean hasArpAccessRight(final String accessRight) {
        return getUserGroups().contains(accessRight);
    }

    private void checkArpAccess(final String accessRight) throws AccessControlException {
        if (!hasArpAccessRight(accessRight)) {
            throw new AccessControlException(
                    "Access denied. Please request access to Swift access right "
                            + accessRight + " in " + SWIFT_ARP_TUTORIAL_HTML);
        }
    }

    /**
     * Ensures the user has at least one of the specified ARP access rights
     */
    private void checkArpAccess(final List<String> accessRights) throws AccessControlException {
        boolean hasAccess = false;
        for (String accessRight : accessRights) {
            if (hasArpAccessRight(accessRight)) {
                hasAccess = true;
                break;
            }
        }
        if (!hasAccess) {

            throw new AccessControlException(
                    "Access denied. Please request access to one of the Swift access rights "
                            + StringUtils.collectionToCommaDelimitedString(accessRights) + " in "
                            + SWIFT_ARP_TUTORIAL_HTML);
        }
    }

    /**
     * Returns the arp access rights which are allowed to perform a specified swift role for a given organisation. Eg,
     * for organisation 'Neo' and role 'release-lockdown', the ARP access rights allowed may be SWIFT-QA an SWIFT-PROD.
     */
    private List<String> getAccessRights(final String organisation, final String role) {
        OrganisationBeanFactory<List<String>> orgAccessRights = roleToAccessRightLookup.get(role);
        if (orgAccessRights == null) {
            throw new IllegalArgumentException("Role '" + role + "' does not map to an ARP access right.");
        }

        List<String> accessRights = orgAccessRights.get(organisation);

        Assert.notEmpty(accessRights, "Role '" + role + "' does not map to an ARP access right for organisation "
                + organisation);

        return accessRights;
    }

    private List<String> getUserGroups() {
        return userGroupsLookup.findUserSwiftGroups(opContextProvider.getCurrentUser());
    }

    @Required
    public void setUserGroupsLookup(final UserGroupsLookup userGroupsLookup) {
        this.userGroupsLookup = userGroupsLookup;
    }

    @Required
    public void setOpContextProvider(final OperationContextProvider opContextProvider) {
        this.opContextProvider = opContextProvider;
    }

    @Required
    public void setEnvironmentAccessRightLookup(final EnvironmentBeanFactory<String> environmentAccessRightLookup) {
        this.environmentAccessRightLookup = environmentAccessRightLookup;
    }

    @Required
    public void setRoleToAccessRightLookup(
            final Map<String, OrganisationBeanFactory<List<String>>> roleToAccessRightLookup) {
        this.roleToAccessRightLookup = roleToAccessRightLookup;
    }

    @Required
    public void setOrgEnvironmentsMap(final OrganisationBeanFactory<List<String>> orgEnvironmentsMap) {
        orgEnvironmentsMap.registerUpdateListener(new Runnable() {
            @Override
            public void run() {
                Multimap<String, Environment> orgEnvMultimap = HashMultimap.create();
                for (Map.Entry<String, List<String>> orgEnvs : orgEnvironmentsMap.getAll().entrySet()) {
                    String org = orgEnvs.getKey();
                    for (String env : orgEnvs.getValue()) {
                        orgEnvMultimap.put(org, new Environment(env, org));
                    }
                }
                AuthorisationController.this.orgEnvironments = orgEnvMultimap;
            }
        });
    }

    @Required
    public void setSwiftGroupDao(final SwiftGroupDao swiftGroupDao) {
        this.swiftGroupDao = swiftGroupDao;
    }

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

}
