package com.ubs.f35.swift.properties.bulk;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.Artifact;

public class BulkUpdateResult {
    public enum BulkUpdateStatus {
        SUCCESS, FAILURE, SKIPPED;
    }

    private final BulkUpdateStatus status;
    private final String message;
    private final Artifact artifact;

    public BulkUpdateResult(final BulkUpdateStatus status, final Artifact artifact, final String message) {
        this.status = status;
        this.artifact = artifact;
        this.message = message;
    }

    public Artifact getArtifact() {
        return artifact;
    }

    public BulkUpdateStatus getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(status);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof BulkUpdateResult) {
            BulkUpdateResult that = (BulkUpdateResult) object;
            return Objects.equal(this.status, that.status)
                    && Objects.equal(this.artifact, that.artifact)
                    && Objects.equal(this.message, that.message);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("status", status).add("artifact", artifact).add("message", message)
                .toString();
    }
}