package com.ubs.f35.swift.webhook;

import java.util.List;
import java.util.concurrent.Executor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.ubs.f35.swift.dao.Deployment;
import com.ubs.f35.swift.dao.ReleaseDefinition;
import com.ubs.f35.swift.dao.ReleaseDefinitionDao;
import com.ubs.f35.swift.dao.ReleaseWatchDao;
import com.ubs.f35.swift.dao.model.ReleaseWatch.WatchType;
import com.ubs.f35.swift.state.OperationContextProvider;
import com.ubs.swift.webhook.model.DeploymentNotification;

/**
 * Provides methods for publishing events to the our webhook subscribers.
 * 
 * @author chaust
 * 
 */

@Transactional(readOnly = true)
public class WebhookNotifier {

    private static final Logger LOG = LoggerFactory.getLogger(WebhookNotifier.class);

    private ReleaseDefinitionDao releaseDefinitionDao;
    private ReleaseWatchDao releaseWatchDao;
    private OperationContextProvider contextProvider;
    private Executor executor;
    private RestTemplate restTemplate;
    private List<String> subscriberUrlsList;

    @Required
    public void setContextProvider(final OperationContextProvider contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Required
    public void setReleaseDefinitionDao(final ReleaseDefinitionDao releaseDefinitionDao) {
        this.releaseDefinitionDao = releaseDefinitionDao;
    }

    @Required
    public void setReleaseWatchDao(final ReleaseWatchDao releaseWatchDao) {
        this.releaseWatchDao = releaseWatchDao;
    }

    @Required
    public void setRestTemplate(final RestTemplate template) {
        this.restTemplate = template;
    }

    @Required
    public void setSubscriberUrlsList(final List<String> subscriberUrlsList) {
        // TODO - load the URL's from some other source like database?
        this.subscriberUrlsList = subscriberUrlsList;
    }

    @Required
    public void setExecutor(final Executor executor) {
        this.executor = executor;
    }

    /**
     * Tells this WebhookNotifier that an event has occurred so that it will notify its subscribers of the happening.
     * 
     * @param deployment
     */
    public void eventOccurred(final Deployment deployment) {

        ReleaseDefinition releaseDef = releaseDefinitionDao.load(deployment.getReleaseId());
        List<String> watchingUsers = releaseWatchDao.loadWatchers(deployment.getReleaseId(),
                WatchType.RELEASE_DEPLOYMENT);

        DeploymentNotification notification = DeploymentNotificationBuilder.newNotification(deployment, releaseDef,
                contextProvider.getCurrentUser(), watchingUsers);

        // non-blocking
        notifySubscribers(notification);
    }

    private void notifySubscribers(final DeploymentNotification notification) {
        for (String url : subscriberUrlsList) {

            if (StringUtils.hasText(url)) {
                LOG.info("Scheduling a job for HTTP POST {}", url);
                HttpPosterRunnable httpPoster = new HttpPosterRunnable(url, notification);
                // non-blocking
                executor.execute(httpPoster);
            } else {
                LOG.info("Skipping empty webhook URL...");
            }
        }
    }

    class HttpPosterRunnable implements Runnable {
        private final String url;
        private final DeploymentNotification notification;

        public HttpPosterRunnable(final String url, final DeploymentNotification notification) {
            this.url = url;
            this.notification = notification;
        }

        @Override
        public void run() {
            String result;
            try {
                LOG.info("Trying to contact webhook {}", url);
                // The second argument (i.e. request) in
                // postForObject(String url, Object request, Class<T> responseType, Object... uriVariables)
                // determines what message converter Spring will use,
                // which in turn determines the content-type of the HTTP request.
                // In this case, it will use "application/json".
                result = restTemplate.postForObject(url, notification, String.class);
                LOG.info("Webhook contacted. result: {}", result);
            } catch (RestClientException e) {
                LOG.warn("Cannot contact webhook url", e);
            }

        }
    }

}
