package com.ubs.f35.swift.deploy.glu.rest;

public class AgentNotFoundException extends RuntimeException {
    public AgentNotFoundException(final String message) {
        super(message);
    }
}
