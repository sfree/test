package com.ubs.f35.swift.deploy.glu.rest;

import static com.google.common.collect.ImmutableMap.of;
import static com.ubs.f35.swift.deploy.glu.rest.GluJsonUtils.extractFromMap;
import static com.ubs.f35.swift.service.ArtifactConfigurationService.isSnapshot;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;
import org.linkedin.util.clock.Timespan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.util.StringUtils;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestClientException;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.deploy.glu.DeploymentInvoker;
import com.ubs.f35.swift.deploy.glu.DeploymentTimeoutException;
import com.ubs.f35.swift.deploy.glu.state.GluState;
import com.ubs.f35.swift.deploy.glu.state.Transition.TransitionStep;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.environment.model.glu.Script;
import com.ubs.f35.swift.model.State.StateLevel;
import com.ubs.f35.swift.service.CommandBuilderService;
import com.ubs.f35.swift.service.SwiftServerAgentScriptDeployer;
import com.ubs.f35.swift.util.LoadingCacheUtil;
import com.ubs.f35.swift.web.client.TimeLimitedRestTemplate;

/**
 * This DeploymentInvoker interacts with the glu agent to deploy and run services.
 * 
 */
@ManagedResource
public class GluDeploymentInvoker implements DeploymentInvoker, ProcessDetailsProvider {
    private static final Logger LOG = LoggerFactory.getLogger(GluDeploymentInvoker.class);

    private static final Timespan START_BUFFER_TIME = Timespan.parse("90s");
    // Allow 10s for IO overheads / latency
    private static final Timespan IO_BUFFER = Timespan.parse("10s");

    public static final String SWIFT_GLU_SCRIPTS_GROUP = "com.ubs.f35.swift.scripts";
    public static final String SWIFT_GLU_SCRIPTS_ARTIFACT = "swift-glu-scripts";

    private Timespan defaultTransitionTimeout;
    private GluProcessManager gluProcessManager;
    private TimeLimitedRestTemplate template;
    private SwiftServerAgentScriptDeployer agentScriptDeployer;
    private CommandBuilderService commandBuilderService;

    // Using a cache (with a short lifespan) for the agent url building as there will be multiple calls in a short
    // period of time during deployments, then no further calls until the next deployment.
    private final LoadingCache<String, String> agentUrlCache = CacheBuilder.newBuilder()
            .expireAfterWrite(1, TimeUnit.MINUTES).build(new CacheLoader<String, String>() {
                @Override
                public String load(final String agent) {
                    Map<String, String> agentDetails = gluProcessManager.getAgentDetails(agent);
                    String hostname = agentDetails.get("glu.agent.hostname");
                    String port = agentDetails.get("glu.agent.port");
                    String sslEnabled = agentDetails.get("glu.agent.sslEnabled");

                    String protocol = Boolean.valueOf(sslEnabled) ? "https://" : "http://";

                    return protocol + hostname + ":" + port;
                }
            });

    @Override
    public void executeTransition(final Entry entry, final TransitionStep transitionStep) {
        switch (transitionStep) {
        case deploy_script:
            installMountPoint(entry);
            break;
        case remove_script:
            deleteMountPoint(entry);
            break;
        default:
            executeStateMachineTransition(entry, transitionStep);
            break;
        }
    }

    @ManagedOperation(description = "Allows a mountpoint to be uninstalled if state is corrupted.  Use only as a last resort")
    @ManagedOperationParameters(value = {
            @ManagedOperationParameter(name = "agent", description = "The agent"),
            @ManagedOperationParameter(name = "mountPoint", description = "The mount point to be removed") })
    public void forceUninstall(final String agent, final String mountPoint) {
        template.delete(getAgentEntryUrl(agent, mountPoint) + "?force=true");
    }

    private void deleteMountPoint(final Entry entry) {
        template.delete(getAgentEntryUrl(entry));
    }

    /**
     * When installing a script:
     * <ol>
     * <li>First attempt to locate the scripts under the agent home directory /swift-scripts. If the scripts have been
     * placed here they will be used. This will allow agents with firewall restrictions preventing communication back to
     * swift to still find glu scripts.
     * <li>If the script is a release version, attempt to deploy the scripts to /swift-scripts using the command
     * service. Scripts are frequently reused by many deployments and this can result in improved deployment times (and
     * less load on swift-server) by reducing the number of script downloads. SNAPSHOTS are skipped so that development
     * changes can easily be picked up. This step may fail if the agent can't {@code curl} the script package (i.e.
     * because it is a windows agent).
     * <li>Finally, if that fails, attempt to build a url which retrieves the required dependencies from swift-server.
     * </ol>
     * TODO - Consider having the strategy configurable per organisation. Note that windows agents will always fail to
     * download the scripts.
     * 
     * @param entry
     */
    private void installMountPoint(final Entry entry) {
        String fullScriptPath = getScriptUrl(entry);

        try {
            installMountPointWithScriptUrl(entry, fullScriptPath);
        } catch (GluHttpClientErrorException ex) {
            // If the exception is a FileNotFound then assume that the glu script could not be found.
            if (Iterables.any(ex.getErrorDetails(), new ExceptionTypePredicate("java.io.FileNotFoundException"))) {
                boolean scriptDeployed = false;
                if (!isSnapshot(entry.getScript().getVersion())) {
                    LOG.info("Agent {} does not have glu script {}.  Attempting to deploy now.", entry.getAgent(),
                            fullScriptPath);

                    try {
                        agentScriptDeployer.deployGluScript(entry, this);
                        scriptDeployed = true;
                    } catch (RuntimeException ex2) {
                        LOG.error("Exception deploying glu script to agent", ex2);
                    }
                }

                if (scriptDeployed) {
                    LOG.info("Glu script deployed to agent.  Attempting to install mount point again.");
                    installMountPointWithScriptUrl(entry, fullScriptPath);
                } else {
                    LOG.info("Attempting to install mount point using http classpath");
                    installMountPointUsingSwift(entry);
                }
            } else {
                throw ex;
            }
        }
    }

    private void installMountPointUsingSwift(final Entry entry) {
        Script script = entry.getScript();
        String scriptUrl = "class:/" + script.getScript() + "?cp=" + agentScriptDeployer.getScriptUrl(entry);

        installMountPointWithScriptUrl(entry, scriptUrl);
    }

    private void installMountPointWithScriptUrl(final Entry entry, final String scriptUrl) {
        Object request = of("args",
                of("scriptLocation", scriptUrl,
                        "mountPoint", entry.getMountPoint(),
                        "initParameters", entry.getInitParameters()));

        template.put(getAgentEntryUrl(entry), request);
    }

    private String getScriptUrl(final Entry entry) {
        Script script = entry.getScript();

        String scriptUrl;
        // handle legacy scripts which have already been deployed.
        if (script.getPckage().equals(SWIFT_GLU_SCRIPTS_ARTIFACT)) {
            String scriptDir = commandBuilderService.buildInstallDir(SWIFT_GLU_SCRIPTS_GROUP,
                    SWIFT_GLU_SCRIPTS_ARTIFACT, script.getVersion());

            scriptUrl = "class:/" + script.getScript() + "?cp=" + scriptDir + "/" + SWIFT_GLU_SCRIPTS_ARTIFACT + "-"
                    + script.getVersion() + ".jar";
        } else {
            Map<String, String> agentDetails = gluProcessManager.getAgentDetails(entry.getAgent());

            scriptUrl = "class:/" + script.getScript() + "?cp=file:///" +
                    agentDetails.get("glu.agent.homeDir").replace("\\", "/") +
                    "/swift-scripts/" +
                    script.getPckage() + "-" + script.getVersion() + ".jar";
        }

        return scriptUrl;
    }

    private void executeStateMachineTransition(final Entry entry, final TransitionStep transitionStep)
            throws NoSuchMountPointException {

        GluState expectedStartState = GluState.getStartStateForTransition(transitionStep);
        GluState currentState = getCurrentState(entry);
        if (currentState != expectedStartState) {
            throw new IllegalStateException("Entry is not in the expected state of " + expectedStartState
                    + " but is in state " + currentState);
        }

        // clear any errors. When moving a process between states we don't care if the state machine is in error.
        // The deployment should proceed as it may fix the state machine error.
        // Note that agents do not allow transitions while the state machine is in error, so deployments
        // would be blocked without this.
        clearError(entry);

        LOG.info("Transitioning from {} to get with action {}", currentState, transitionStep);

        executeAction(entry, transitionStep.name());

        GluState targetState = currentState.getEndState(transitionStep);

        waitForState(entry, transitionStep, targetState);
    }

    @SuppressWarnings("unchecked")
    private void waitForState(final Entry entry, final TransitionStep transitionStep, final GluState targetState) {

        String transitionTimeout = (String) entry.getInitParameters().get(transitionStep.name() + "Timeout");

        Timespan timeout = StringUtils.hasText(transitionTimeout) ? Timespan.parse(transitionTimeout)
                : defaultTransitionTimeout;

        if (transitionStep == TransitionStep.start) {
            // For start, we've always added an addition 90 second buffer. The reason for this is that the start timeout
            // for NeoServerGluScript is how long we allow the server to come up after the call to envstartlocal has
            // returned. However envstartlocal does some portcheck magic
            // https://github.ldn.swissbank.com/FedCore/core-server-container/blob/master/src/main/resources/scripts/portcheck
            // which is outside the time we allow the process to start. TODO This is very Neo specific logic which has
            // crept into the internals of swift and doesn't really belong here.
            timeout = START_BUFFER_TIME.add(timeout);
        }

        LOG.info("Waiting {} for transition to target state {} to complete", timeout, targetState);

        Timespan ioTimeout = timeout.add(IO_BUFFER);

        Map<String, ?> result = template.getForObject(
                getAgentEntryUrl(entry) + "?state={state}&timeout={timeout}", ioTimeout, Map.class,
                targetState.name(), timeout);

        LOG.debug("wait result {} for transition to {}", result, targetState);
        boolean success = parseResult(result.get("res"));
        if (!success) {
            throw new DeploymentTimeoutException("Call to agent " + entry.getAgent() + " to transition to state "
                    + targetState + " timed out after " + timeout);
        }
    }

    private boolean parseResult(final Object value) {
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        else if (value instanceof String) {
            return Boolean.valueOf((String) value);
        }
        return false;
    }

    private String getAgentEntryUrl(final Entry entry) {
        return getAgentEntryUrl(entry.getAgent(), entry.getMountPoint());
    }

    private String getAgentEntryUrl(final String agent, final String mountPoint) {
        return getAgentUrl(agent) + "/mountPoint" + mountPoint;
    }

    private String getAgentUrl(final String agent) {
        return LoadingCacheUtil.getUnchecked(agentUrlCache, agent);
    }

    private void executeAction(final Entry entry, final String action) {
        Object request = toActionArgs("executeAction", ImmutableMap.of("action", action));
        String result = template.postForObject(getAgentEntryUrl(entry), request, String.class);

        LOG.info("executeAction result {}", result);
    }

    private void clearError(final Entry entry) {
        Object request = toActionArgs("clearError", Collections.emptyMap());
        String result = template.postForObject(getAgentEntryUrl(entry), request, String.class);

        LOG.info("clearError result {}", result);
    }

    private Map<String, ?> toActionArgs(final String action, final Map<?, ?> args) {
        return ImmutableMap.of("args", ImmutableMap.of(action, args));
    }

    @SuppressWarnings("rawtypes")
    private GluState getCurrentState(final Entry entry) {
        Map result = getDetailsForEntry(entry);

        return extractGluState(result);
    }

    @SuppressWarnings("rawtypes")
    private Map getDetailsForEntry(final Entry entry) {
        try {
            Map result = template.getForObject(getAgentEntryUrl(entry), Map.class);
            LOG.info("result {}", result);
            return result;
        } catch (ResourceAccessException ex) {
            throw new RestClientException("Unable to communicate with agent " + entry.getAgent()
                    + ". Please check that it is running", ex);
        }
    }

    @Override
    @SuppressWarnings("rawtypes")
    public ProcessDetails getCurrentProcessState(final Entry entry) {
        Map result;
        try {
            result = getDetailsForEntry(entry);
        } catch (NoSuchMountPointException ex) {
            return new ProcessDetails(GluState.nomountpoint, StateLevel.ERROR, false);
        }

        LOG.info("result {}", result);

        return GluProcessManager.getProcessDetails((Map) result.get("fullState"), entry);
    }

    private GluState extractGluState(final Map result) {
        String value = extractFromMap(result, "fullState", "scriptState", "stateMachine", "currentState");
        return GluState.valueOf(value);
    }

    @SuppressWarnings("unchecked")
    public Map getLogDirectoryContents(final String agent, final String logDirectory) {
        Map<String, Map<String, ?>> logFiles = template.getForObject(getAgentUrl(agent) + "/file" + logDirectory,
                Map.class);
        LOG.info("logs {}", logFiles);

        try {
            return sortLogDirectoryContents(logFiles);
        } catch (Exception ex) {
            LOG.warn("Exception sorting log directory", ex);
            return logFiles;
        }
    }

    @SuppressWarnings("rawtypes")
    private Map sortLogDirectoryContents(final Map logFiles) {
        Map<String, Map> logFilesMap = (Map<String, Map>) logFiles.get("res");

        ArrayList<java.util.Map.Entry<String, Map>> logFilesList = Lists.newArrayList(logFilesMap.entrySet());

        Collections.sort(logFilesList, new Comparator<java.util.Map.Entry<String, Map>>() {

            @Override
            public int compare(final java.util.Map.Entry<String, Map> o1, final java.util.Map.Entry<String, Map> o2) {
                // Sort by most recent first.
                return getLastModifiedDate(o2).compareTo(getLastModifiedDate(o1));
            }

            private Long getLastModifiedDate(final java.util.Map.Entry<String, Map> entry) {
                return (Long) entry.getValue().get("lastModified");
            }
        });

        LinkedHashMap<String, Map> sortedResults = new LinkedHashMap<String, Map>();
        for (java.util.Map.Entry<String, Map> entry : logFilesList) {
            sortedResults.put(entry.getKey(), entry.getValue());
        }

        return ImmutableMap.of("res", sortedResults);
    }

    public void getLogFileContents(final String agent, final String logDirectory, final int maxLine,
            final OutputStream outputStream) {
        ResponseExtractor<Void> streamingExtractor = new ResponseExtractor<Void>() {
            @Override
            public Void extractData(final ClientHttpResponse response) throws IOException {
                IOUtils.copy(response.getBody(), outputStream);
                return null;
            }
        };

        template.execute(getAgentUrl(agent) + "/file" + logDirectory + "?maxLine={maxLine}", HttpMethod.GET, null,
                streamingExtractor, maxLine);
    }

    public String executeShellCommand(final String agent, final String command) {

        return executeShellCommand(agent, command, null);

    }

    public String executeShellCommand(final String agent, final String command, final Object requestBody) {

        String commandId = aysncInvokeShellCommand(agent, command, requestBody);

        LOG.info("Command id is {}", commandId);

        return getShellCommandResults(agent, commandId);
    }

    /**
     * Executes a command and returns the id generated for that command. The result and status of that command can later
     * be queried using that value.
     * 
     * @param agent
     * @param command
     * @param requestBody
     * @return
     */
    @SuppressWarnings("rawtypes")
    private String aysncInvokeShellCommand(final String agent, final String command, final Object requestBody) {
        Map result = template.postForObject(getAgentUrl(agent)
                + "/commands?type=shell&command={command}&redirectStderr=false",
                requestBody, Map.class, command);

        String commandId = extractFromMap(result, "res", "id");

        LOG.info("Command id is {}", commandId);

        return commandId;
    }

    /**
     * Returns the output from a command execution when execution has completed. If the command succeeds, stdout is
     * returned. If the command exits with an error code, the output to stderr is returned.
     * <p>
     * See
     * https://github.com/linkedin/glu/blob/master/agent/org.linkedin.glu.agent-api/src/main/groovy/org/linkedin/glu/
     * agent/api/Agent.groovy for a list of supported arguments
     * 
     * @param agent
     * @param commandId
     * @return
     */
    @SuppressWarnings("rawtypes")
    private String getShellCommandResults(final String agent, final String commandId) {
        Map exitValue = template.getForObject(getAgentUrl(agent)
                + "/command/{commandId}/exitValue", Map.class, commandId);

        String exitCode = extractFromMap(exitValue, "res");

        LOG.info("Exit value is {}", exitValue);

        String stdout = template.getForObject(
                getAgentUrl(agent) + "/command/{commandId}/streams?stdoutStream=true",
                String.class, commandId);

        if ("0".equals(exitCode)) {
            LOG.info("Command output is {}", stdout);
            return stdout;
        } else {
            // TODO switch to using the MultiplexedInputStream once it's available in maven. This will mean all details
            // can be retrieved with a single call to the agent rather than 3 for result, stdout and stderr.
            // ResponseExtractor<Map<String, String>> responseExtractor = new ResponseExtractor<Map<String, String>>() {
            // @Override
            // public Map<String, String> extractData(final ClientHttpResponse response) throws IOException {
            // return MultiplexedInputStream.demultiplexToString(response.getBody(), ImmutableSet.of("O", "E"),
            // MultiplexedInputStream.DEFAULT_BUFFER_SIZE);
            // }
            // };
            // Map<String, String> outputs = template.execute(getAgentUrl(agent)
            // + "/command/{commandId}/streams?stderrStream=true&stdoutStream=true", HttpMethod.GET, null,
            // responseExtractor, commandId);

            String stderr = template.getForObject(
                    getAgentUrl(agent) + "/command/{commandId}/streams?stderrStream=true",
                    String.class, commandId);

            throw new CommandExecutionException(agent, exitCode, stdout, stderr);
        }
    }

    @Required
    public void setAgentScriptDeployer(final SwiftServerAgentScriptDeployer agentScriptDeployer) {
        this.agentScriptDeployer = agentScriptDeployer;
    }

    /**
     * The default amount of time to allow a transition to complete before swift assumes it has hung, will never be
     * successful and fails the deployment.
     */
    @Required
    public void setDefaultTransitionTimeout(final String defaultTransitionTimeout) {
        this.defaultTransitionTimeout = Timespan.parse(defaultTransitionTimeout);
        LOG.info("Default transition timeout is {}", defaultTransitionTimeout);
    }

    @Required
    public void setTemplate(final TimeLimitedRestTemplate template) {
        this.template = template;
    }

    @Required
    public void setGluProcessManager(final GluProcessManager gluProcessManager) {
        this.gluProcessManager = gluProcessManager;
    }

    @Required
    public void setCommandBuilderService(final CommandBuilderService commandBuilderService) {
        this.commandBuilderService = commandBuilderService;
    }
}
