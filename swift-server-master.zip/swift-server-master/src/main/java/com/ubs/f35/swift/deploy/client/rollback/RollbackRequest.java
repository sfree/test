package com.ubs.f35.swift.deploy.client.rollback;

import java.util.List;

import com.ubs.f35.swift.dao.Artifact;

public class RollbackRequest {

    private List<Artifact> artifacts;

    public List<Artifact> getArtifacts() {
        return artifacts;
    }

    public void setArtifacts(final List<Artifact> artifacts) {
        this.artifacts = artifacts;
    }

}
