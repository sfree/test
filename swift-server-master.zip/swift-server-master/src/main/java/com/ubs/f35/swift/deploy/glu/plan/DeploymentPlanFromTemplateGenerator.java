package com.ubs.f35.swift.deploy.glu.plan;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.Deployment.DeploymentType;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.deploy.glu.action.ManualAction;
import com.ubs.f35.swift.deploy.template.model.DeploymentTemplate;
import com.ubs.f35.swift.deploy.template.model.TemplateAction;
import com.ubs.f35.swift.deploy.template.model.TemplateArtifactAction;
import com.ubs.f35.swift.deploy.template.model.TemplateGroupAction;
import com.ubs.f35.swift.deploy.template.model.TemplateManualAction;

public class DeploymentPlanFromTemplateGenerator {
    private static final Logger LOG = LoggerFactory.getLogger(DeploymentPlanFromTemplateGenerator.class);

    private ComponentDeploymentPlanBuilder componentDeploymentPlanBuilder;

    public void visitDeploymentTemplateActions(final ReleaseDeploymentBuildingContext context,
            final DeploymentTemplate deploymentTemplate) {
        visitDeploymentTemplateActions(context, deploymentTemplate.getAction());
    }

    private void visitDeploymentTemplateActions(final ReleaseDeploymentBuildingContext context,
            final TemplateAction action) {
        DeploymentPlanBuilder builder = context.builder;
        if (action instanceof TemplateGroupAction) {
            TemplateGroupAction groupAction = (TemplateGroupAction) action;
            builder.startGroupedAction("deploy-" + context.uniqueId.getAndIncrement(),
                    GluDeploymentPlanGenerator.ACTION_NAME_PERFORM_RELEASE);

            for (TemplateAction childAction : groupAction.getActions()) {
                visitDeploymentTemplateActions(context, childAction);
            }

            builder.completeGroupedAction(groupAction.getMode() == TemplateGroupAction.Mode.PARALLEL);
        } else if (action instanceof TemplateArtifactAction) {
            TemplateArtifactAction artifactAction = (TemplateArtifactAction) action;

            Artifact releaseArtifact = context.releaseArtifacts.get(new NexusArtifact(artifactAction.getGroupId(),
                    artifactAction.getArtifactId()));

            componentDeploymentPlanBuilder.appendReleaseArtifactToDeploymentPlan(builder, releaseArtifact,
                    context.environment, artifactAction, context.deploymentType == DeploymentType.Rollback,
                    context.targetedInstanceDeployment);

        } else if (action instanceof TemplateManualAction) {
            TemplateManualAction manualTemplate = (TemplateManualAction) action;
            ManualAction manualAction = new ManualAction("manual-" + context.uniqueId.getAndIncrement(),
                    manualTemplate.getTitle());
            manualAction.setSpec(manualTemplate);

            builder.addStep(manualAction);
        } else {
            throw new IllegalArgumentException("Can't handle " + action);
        }
    }

    @Required
    public void setComponentDeploymentPlanBuilder(final ComponentDeploymentPlanBuilder componentDeploymentPlanBuilder) {
        this.componentDeploymentPlanBuilder = componentDeploymentPlanBuilder;
    }

}
