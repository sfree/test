package com.ubs.f35.swift.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.swift.deploy.glu.rest.GluDeploymentInvoker;

/**
 * Deploys glu script to glu agents using the command execution service.
 */
public class AgentGluScriptDeployerUtil {
    private static final Logger LOG = LoggerFactory.getLogger(AgentGluScriptDeployerUtil.class);

    private static final String TARGET_DIR = "../swift-scripts";

    public void deployScripts(final GluDeploymentInvoker gluAgentInvoker, final String agent,
            final String targetFile, final String downloadUrl) {
        // Using a relative directory to where the agent is running from.
        String dirCommand = "mkdir -p " + TARGET_DIR;
        // -k (SSL) This option explicitly allows curl to perform "insecure" SSL connections and transfers.
        // -f fail if the download failed (rather than saving the error document from the web server)
        String downloadCommand = "curl -k -f -o " + TARGET_DIR + "/" + targetFile + " -L '" + downloadUrl + "'";

        LOG.info("Ensuring script directory exists on {} with command {}", agent, dirCommand);
        gluAgentInvoker.executeShellCommand(agent, dirCommand);

        LOG.info("Downloading scripts on {} with command {}", agent, downloadCommand);
        gluAgentInvoker.executeShellCommand(agent, downloadCommand);
    }
}
