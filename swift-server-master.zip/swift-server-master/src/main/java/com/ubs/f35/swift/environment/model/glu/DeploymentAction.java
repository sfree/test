package com.ubs.f35.swift.environment.model.glu;

import java.util.List;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.ubs.f35.swift.deploy.glu.state.GluState;

public enum DeploymentAction {
    Stop("Stop", "on", "running", "stopped"),
    Start("Start", "on", null, "running"), // start from any state
    StartOnly("Start", "on", "stopped", "running"), // start only from a stopped state.
    Bounce("Bounce", "on", "running", "stopped", "running"),
    Redeploy("Redeploy", "to", null, "nomountpoint", "running"),
    ColdDeploy("Cold deploy", "to", "nomountpoint", "stopped"), // Cold deploys install, but do not start
    ColdRedeploy("Cold redeploy", "to", null, "nomountpoint", "stopped"), // Cold deploys install, but do not start
    Undeploy("Undeploy", "on", null, "nomountpoint");

    final GluState validStartState;
    final List<GluState> transitions;
    final String actionVerb;
    final String verbHostJoiner;

    DeploymentAction(final String deployVerb, final String verbHostJoiner, final String validStartState,
            final String... transitionsToMake) {
        this.actionVerb = deployVerb;
        this.verbHostJoiner = verbHostJoiner;
        if (validStartState != null) {
            this.validStartState = GluState.valueOf(validStartState);
        } else {
            this.validStartState = null;
        }

        Builder<GluState> builder = ImmutableList.builder();

        for (String transition : transitionsToMake) {
            builder.add(GluState.valueOf(transition));
        }

        transitions = builder.build();
    }

    public boolean anyStartState() {
        return validStartState == null;
    }

    public GluState getValidStartState() {
        return validStartState;
    }

    public GluState getFinalTransitionState() {
        return Iterables.getLast(getTransitionStates());
    }

    public List<GluState> getTransitionStates() {
        return transitions;
    }

    public String getDeployVerb() {
        return actionVerb;
    }

    public String getVerbHostJoiner() {
        return verbHostJoiner;
    }

    /**
     * Calculates the available actions from the current state. From the current state, a valid transition is determined
     * if one of these rules match:
     * <ul>
     * <li>the start state matches the current state (if start state is present)</li>
     * <li>the action is valid for any start state and the first target transition state is not to the current state
     * 
     * @param currentState
     * @return
     */
    public static List<DeploymentAction> getDeploymentActionsFromState(final GluState currentState) {
        List<DeploymentAction> actions = Lists.newArrayList();
        for (DeploymentAction action : DeploymentAction.values()) {
            if (action.anyStartState() && action.getTransitionStates().get(0) != currentState) {
                actions.add(action);
            } else if (action.validStartState != null && action.validStartState == currentState) {
                actions.add(action);
            }
        }
        return actions;
    }
}