package com.ubs.f35.swift.server;

import java.util.Arrays;
import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

import com.google.common.base.Functions;
import com.google.common.base.Objects;
import com.google.common.collect.Lists;

public class ClientError {

    private final String message;
    private final String exceptionClass;
    private final List<String> stackTrace;

    public ClientError(
            @JsonProperty(value = "message") final String message,
            @JsonProperty(value = "exceptionClass") final String exceptionClass,
            @JsonProperty(value = "stackTrace") final List<String> stackTrace) {
        this.message = message;
        this.exceptionClass = exceptionClass;
        this.stackTrace = stackTrace;
    }

    public ClientError(final Exception ex) {
        this.message = ex.getMessage();
        this.exceptionClass = ex.getClass().getName();
        this.stackTrace = Lists.transform(Arrays.asList(ex.getStackTrace()), Functions.toStringFunction());
    }

    public String getMessage() {
        return message;
    }

    public String getExceptionClass() {
        return exceptionClass;
    }

    public List<String> getStackTrace() {
        return stackTrace;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(message, exceptionClass, stackTrace);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ClientError) {
            ClientError that = (ClientError) object;
            return Objects.equal(this.message, that.message)
                    && Objects.equal(this.exceptionClass, that.exceptionClass)
                    && Objects.equal(this.stackTrace, that.stackTrace);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("message", message)
                .add("exceptionClass", exceptionClass)
                .add("stackTrace", stackTrace)
                .toString();
    }

}
