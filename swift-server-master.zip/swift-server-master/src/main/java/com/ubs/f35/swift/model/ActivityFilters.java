package com.ubs.f35.swift.model;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.Activity.ActivityType;

public class ActivityFilters {

    private String user;
    private String team;
    private ActivityType type;
    private String organisation;
    private String environment;
    private Integer releaseId;

    public String getUser() {
        return user;
    }

    public void setUser(final String user) {
        this.user = user;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(final String team) {
        this.team = team;
    }

    public ActivityType getType() {
        return type;
    }

    public void setType(final ActivityType type) {
        this.type = type;
    }

    public String getOrganisation() {
        return organisation;
    }

    public void setOrganisation(final String organisation) {
        this.organisation = organisation;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(final String environment) {
        this.environment = environment;
    }

    public Integer getReleaseId() {
        return releaseId;
    }

    public void setReleaseId(final Integer releaseId) {
        this.releaseId = releaseId;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(user, team, type, organisation, environment, releaseId);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ActivityFilters) {
            ActivityFilters that = (ActivityFilters) object;
            return Objects.equal(this.user, that.user)
                    && Objects.equal(this.team, that.team)
                    && Objects.equal(this.type, that.type)
                    && Objects.equal(this.organisation, that.organisation)
                    && Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.releaseId, that.releaseId);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("user", user)
                .add("team", team)
                .add("type", type)
                .add("organisation", organisation)
                .add("environment", environment)
                .add("releaseId", releaseId)
                .toString();
    }

}
