package com.ubs.f35.swift.properties.model;

import com.ubs.f35.swift.dao.Artifact;

public class PropertyKeysTemplateFileMissingException extends PropertyKeysExtractionException {

    public PropertyKeysTemplateFileMissingException(final String organisation, final Artifact artifact,
            final String filename) {
        super(
                "Cannot find template file \""
                        + filename
                        + "\" in the artifact package. Please make sure the file exists, or change the template file in the "
                        + PropertyKeysExtractionException.getArtifactConfigLink(organisation, artifact) + ".",
                artifact);
    }

}
