package com.ubs.f35.swift.deploy.client.action;

import org.codehaus.jackson.annotate.JsonProperty;

import com.google.common.base.Objects;
import com.ubs.f35.swift.deploy.glu.DeploymentState;

/**
 * Client representation of a deployment plan action.
 * 
 * @author stephelu
 * 
 */
public class ClientPlanAction extends BaseClientAction {

    protected final String action;
    protected final DeploymentState deploymentState;

    public ClientPlanAction(final String action, final DeploymentState deploymentState, final String id) {
        super(makeDomSafeId(id));
        this.action = action.replace("_", " ");
        this.deploymentState = deploymentState;
    }

    private static String makeDomSafeId(final String input) {
        return input.replaceAll("[^A-Za-z0-9]", "-");
    }

    @JsonProperty(value = "@type")
    public String getAction() {
        return action;
    }

    public DeploymentState getDeploymentState() {
        return deploymentState;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("action", action)
                .add("deploymentState", deploymentState)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(action);
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }

        ClientPlanAction that = (ClientPlanAction) obj;

        return Objects.equal(this.id, that.id)
                && Objects.equal(this.deploymentState, that.deploymentState)
                && Objects.equal(this.action, that.action);
    }

}
