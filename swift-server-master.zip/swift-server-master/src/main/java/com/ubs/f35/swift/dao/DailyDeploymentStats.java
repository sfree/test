package com.ubs.f35.swift.dao;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.util.Assert;

import com.google.common.base.Objects;

public class DailyDeploymentStats {
    private final Date date;
    private final String environment;
    private final Long deployments;

    public DailyDeploymentStats(final Date date, final String environment, final Long deployments) {
        // hibernate needs the Date contructor, but needs to be a timestamp for the equals method.
        Assert.isInstanceOf(Timestamp.class, date);
        this.date = date;
        this.environment = environment;
        this.deployments = deployments;
    }

    public Date getDate() {
        return date;
    }

    public String getEnvironment() {
        return environment;
    }

    public Long getDeployments() {
        return deployments;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(date, environment, deployments);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DailyDeploymentStats) {
            DailyDeploymentStats that = (DailyDeploymentStats) object;
            return Objects.equal(this.date, that.date)
                    && Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.deployments, that.deployments);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("date", date)
                .add("environment", environment)
                .add("deployments", deployments)
                .toString();
    }

}