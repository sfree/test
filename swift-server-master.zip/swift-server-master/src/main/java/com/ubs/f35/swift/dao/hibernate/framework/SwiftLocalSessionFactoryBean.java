package com.ubs.f35.swift.dao.hibernate.framework;

import javax.persistence.EntityManager;
import javax.persistence.PreUpdate;

import org.hibernate.SessionFactory;
import org.hibernate.annotations.common.reflection.ReflectionManager;
import org.hibernate.ejb.event.EJB3FlushEntityEventListener;
import org.hibernate.ejb.event.EJB3PersistEventListener;
import org.hibernate.ejb.event.EntityCallbackHandler;
import org.hibernate.event.service.spi.EventListenerRegistry;
import org.hibernate.event.spi.EventType;
import org.hibernate.internal.SessionFactoryImpl;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;

import com.ubs.f35.swift.dao.ReleaseDefinition;

/**
 * When using hibernate specific {@link SessionFactory} instead of the JPA {@link EntityManager}, annotations like
 * {@link PreUpdate} do not work out of the box. At some point we should probably switch to using {@link EntityManager}
 * so this code is no longer required, but that was more change / risk than I was willing to introduce late in the
 * release cycle.
 * <p>
 * See the following references if interested for further information:
 * <ul>
 * <li>Section 13.5 JPA of http://docs.spring.io/spring/docs/3.0.x/reference/orm.html#orm-hibernate
 * <li>Use SessionFactory or EntityManager question on stack overflow
 * http://stackoverflow.com/questions/5640778/hibernate-sessionfactory-vs-entitymanagerfactory
 * <li>Explanation of PreUpdate not working
 * http://leakfromjavaheap.blogspot.com.au/2013/08/prepersist-and-preupdate-not-working.html
 * </ul>
 */
public class SwiftLocalSessionFactoryBean extends LocalSessionFactoryBean {
    @Override
    protected SessionFactory buildSessionFactory(final LocalSessionFactoryBuilder sfb) {
        SessionFactoryImpl sessionFactory = (SessionFactoryImpl) super.buildSessionFactory(sfb);

        ReflectionManager reflectionManager = sfb.getReflectionManager();
        EntityCallbackHandler callbackHandler = new EntityCallbackHandler();
        callbackHandler.add(reflectionManager.toXClass(ReleaseDefinition.class), reflectionManager);
        EventListenerRegistry registry = sessionFactory.getServiceRegistry().getService(EventListenerRegistry.class);
        // for @PrePersist:
        registry.setListeners(EventType.PERSIST, new EJB3PersistEventListener(callbackHandler));
        // for @PreUpdate
        registry.setListeners(EventType.FLUSH_ENTITY, new EJB3FlushEntityEventListener(callbackHandler));

        return sessionFactory;
    }
}
