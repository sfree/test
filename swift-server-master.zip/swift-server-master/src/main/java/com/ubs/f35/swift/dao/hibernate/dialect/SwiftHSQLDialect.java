package com.ubs.f35.swift.dao.hibernate.dialect;

import org.hibernate.dialect.HSQLDialect;
import org.hibernate.dialect.function.StandardSQLFunction;

/**
 * Registers the trunc function.
 */
public class SwiftHSQLDialect extends HSQLDialect {

    public SwiftHSQLDialect() {
        super();

        registerFunction("trunc", new StandardSQLFunction("trunc"));
    }
}
