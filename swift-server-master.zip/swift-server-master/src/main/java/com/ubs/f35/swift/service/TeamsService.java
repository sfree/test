package com.ubs.f35.swift.service;

import java.util.List;

import com.ubs.f35.swift.dao.model.Team;

public interface TeamsService {

    List<Team> getAllTeams(String organisation);

    List<Team> getCurrentUserTeams(String organisation);

    List<String> getCurrentUserTeamNames();

    List<Team> getUserTeams(String userGuid);

    void saveCurrentUserTeams(Integer[] teams);

    Team loadTeam(Integer id);

    void registerTeam(String organisationName, String teamName);

}
