package com.ubs.f35.swift.model;

import java.io.File;

import org.codehaus.jackson.annotate.JsonIgnoreType;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.hibernate.bytecode.internal.javassist.FieldHandler;

public class JsonObjectMapper {

    private static final JsonObjectMapper MAPPER = new JsonObjectMapper();
    // Mapper which will not serialise hibernate FieldHandler (added by byte code manipulation at compile time)
    public static final ObjectMapper HIBERNATE_MAPPER = new ObjectMapper();

    static {
        HIBERNATE_MAPPER.getSerializationConfig()
                .addMixInAnnotations(FieldHandler.class, IgnoreFieldHandlerMixin.class);
    }

    public static JsonObjectMapper getInstance() {
        return MAPPER;
    }

    public static ObjectMapper getObjectMapper() {
        return HIBERNATE_MAPPER;
    }

    public static ObjectMapper getHibernateMapper() {
        return HIBERNATE_MAPPER;
    }

    public <T> T readValue(final String content, final Class<T> valueType) {
        try {
            if (content != null) {
                return HIBERNATE_MAPPER.readValue(content, valueType);
            }
        } catch (Exception ex) {
            throw new JsonUnmarshallingException(valueType, ex);
        }
        return null;
    }

    public <T> T readValue(final File src, final Class<T> valueType) {
        try {
            return HIBERNATE_MAPPER.readValue(src, valueType);
        } catch (Exception ex) {
            throw new JsonUnmarshallingException(valueType, ex);
        }
    }

    @SuppressWarnings("rawtypes")
    public <T> T readValue(final String content, final TypeReference valueTypeRef) {
        try {
            return HIBERNATE_MAPPER.readValue(content, valueTypeRef);
        } catch (Exception ex) {
            throw new JsonUnmarshallingException(ex);
        }
    }

    public String writeValueAsString(final Object value) {
        try {
            return HIBERNATE_MAPPER.writeValueAsString(value);
        } catch (Exception ex) {
            throw new JsonMarshallingException(ex);
        }
    }

    public void writeValue(final File resultFile, final Object value) {
        try {
            HIBERNATE_MAPPER.writeValue(resultFile, value);
        } catch (Exception ex) {
            throw new JsonMarshallingException(ex);
        }
    }

    @JsonIgnoreType
    public class IgnoreFieldHandlerMixin {

    }
}
