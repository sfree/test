package com.ubs.f35.swift.service.glu;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.google.common.base.Predicate;
import com.ubs.f35.swift.environment.model.glu.Entry;

/**
 * Returns deployment model entries which match the agent
 * 
 * @author levyjo
 * 
 */
public class EntryMatchesArtifactsPredicate implements Predicate<Entry> {

    private final List<String> artifacts;

    public EntryMatchesArtifactsPredicate(final List<String> artifacts) {
        this.artifacts = artifacts;
    }

    @Override
    public boolean apply(final Entry entry) {
        if (CollectionUtils.isEmpty(artifacts)) {
            return true;
        }
        return artifacts.contains(entry.getArtifactId());
    }

}
