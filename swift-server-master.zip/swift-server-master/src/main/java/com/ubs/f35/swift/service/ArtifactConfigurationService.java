package com.ubs.f35.swift.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import com.google.common.base.Objects;
import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ubs.f35.swift.config.model.ArtifactCommonConfig;
import com.ubs.f35.swift.config.model.ArtifactConfig;
import com.ubs.f35.swift.config.model.DeployTag;
import com.ubs.f35.swift.config.model.GluScriptMetadata;
import com.ubs.f35.swift.config.model.Host;
import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.ArtifactCommonConfigDao;
import com.ubs.f35.swift.dao.ArtifactConfigurationDao;
import com.ubs.f35.swift.dao.EnvironmentDao;
import com.ubs.f35.swift.dao.HostDao;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.dao.model.Environment;
import com.ubs.f35.swift.deploy.template.model.DependencyGraph;
import com.ubs.f35.swift.document.EnvironmentDocumentStore;
import com.ubs.f35.swift.environment.OrganisationBeanFactory;
import com.ubs.f35.swift.environment.model.glu.Entry;
import com.ubs.f35.swift.model.ArtifactInstanceId;
import com.ubs.f35.swift.model.EnvironmentId;
import com.ubs.f35.swift.processor.ProcessorUtil;

public class ArtifactConfigurationService {
    private static final Logger LOG = LoggerFactory.getLogger(ArtifactConfigurationService.class);

    private final String CLIENT_DEPLOY_TAG = "client";

    private EnvironmentDocumentStore environmentDocumentStore;
    private ArtifactConfigurationDao artifactConfigurationDao;
    private ArtifactCommonConfigDao artifactCommonConfigDao;
    private EnvironmentDao environmentDao;
    private HostDao hostDao;
    private ArtifactTypeService artifactTypeService;

    private String defaultClientScript;
    private String[] clientGroupPrefixes;
    private OrganisationBeanFactory<List<String>> orgEnvironmentsMap;

    /**
     * Utility method to check if an artifact is a SNAPSHOT version
     * 
     * @param artifact
     * @return
     */
    public static boolean isSnapshot(final Artifact artifact) {
        return isSnapshot(artifact.getVersion());
    }

    /**
     * Utility method to check if an String version is a SNAPSHOT version
     * 
     * @param artifact
     * @return
     */
    public static boolean isSnapshot(final String version) {
        return version.endsWith("SNAPSHOT");
    }

    /**
     * Returns true if the artifact is a client artifact.
     * 
     * @deprecated This logic is too Neo specific.
     */
    @Deprecated
    @VisibleForTesting
    protected boolean isClientArtifact(final NexusArtifact artifact) {
        for (String clientGroupPrefix : clientGroupPrefixes) {
            if (artifact.getGroupId().startsWith(clientGroupPrefix)) {
                return true;
            }
        }
        return false;
    }

    public boolean isArtifactType(final String organisation, final Artifact artifact, final String artifactType) {
        GluScriptMetadata metadata = artifactTypeService.getArtifactMetadata(artifact.getNexusArtifact(), organisation);
        return ArtifactTypeService.UNKNOWN.getShortName().equals(artifactType)
                || (metadata != null && metadata.getCategory().equals(artifactType));
    }

    /**
     * Returns true if multiple instances of this artifact in a deployment can be deployed in parallel. See
     * {@link GluScriptMetadata#isParallelDeploy()}
     */
    public boolean isParallelDeployed(final NexusArtifact artifact, final String organisation) {
        GluScriptMetadata scriptMetadata = artifactTypeService.getArtifactMetadata(artifact, organisation);

        return scriptMetadata != null && scriptMetadata.isParallelDeploy();
    }

    public boolean isNonProdArtifact(final NexusArtifact artifact) {
        return loadOrDefaultCommonConfig(artifact).isNonProd();
    }

    public boolean isArtifactDeployedToEnvironment(final NexusArtifact artifact, final Environment env) {
        if (environmentDocumentStore.isProdEnvironment(env)
                && isNonProdArtifact(artifact)) {
            LOG.info("Non-prod artifact {} is not deployed to {} environment", artifact.getArtifactId(), env);
            return false;
        }

        ArtifactCommonConfig config = artifactCommonConfigDao.load(artifact);
        if (config != null && config.getNotDeployedEnvironments() != null) {
            return !config.getNotDeployedEnvironments().contains(env);
        }

        return true;
    }

    /**
     * Returns true if the given artifact uses ZooKeeper for properties storage.
     * 
     * @param artifact
     * @return
     */
    public boolean hasZooKeeperProperties(final Artifact artifact) {

        ArtifactCommonConfig config = loadOrDefaultCommonConfig(artifact.getNexusArtifact());

        return config.hasProperties();
    }

    /**
     * Returns true if any of the artifacts on this release require zookeeper properties.
     * 
     * @param environment
     * @param release
     * @return
     */
    public boolean anyRequireZookeeperProps(final String environment, final List<Artifact> artifacts) {
        for (Artifact artifact : artifacts) {
            if (hasZooKeeperProperties(artifact)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Builds default configurations for the artifacts which have no configurations in the specified environment.
     */
    public List<ArtifactConfig> getUnconfiguredArtifacts(final Environment environment, final List<Artifact> artifacts) {
        List<ArtifactConfig> unconfigured = new ArrayList<>();

        for (Artifact artifact : artifacts) {

            if (isArtifactDeployedToEnvironment(artifact.getNexusArtifact(), environment)) {
                List<ArtifactConfig> existing = artifactConfigurationDao.load(environment, artifact.getGroupId(),
                        artifact.getArtifactId());
                if (existing.isEmpty()) {
                    unconfigured.add(buildArtifactInstanceId(artifact, ArtifactConfig.DEFAULT_INSTANCE_NAME));
                }
            }
        }

        return buildDefaultConfigurations(environment, unconfigured);
    }

    /**
     * Builds default configurations for the artifacts which have not been configured for the specified instances name
     * in the specified environment.
     */
    public List<ArtifactConfig> getUnconfiguredArtifacts(final Environment environment,
            final Map<Artifact, List<String>> requiredArtifactInstances) {
        List<ArtifactConfig> unconfigured = Lists.newArrayList();

        for (Map.Entry<Artifact, List<String>> artifactInstances : requiredArtifactInstances.entrySet()) {
            // TODO more optimal just to load all rather than each instance? Or introduce an api to load all by
            // name.
            Artifact artifact = artifactInstances.getKey();
            for (String instance : artifactInstances.getValue()) {
                ArtifactConfig existing = artifactConfigurationDao.load(environment, artifact.getGroupId(),
                        artifact.getArtifactId(), instance);
                if (existing == null) {
                    unconfigured.add(buildArtifactInstanceId(artifact, instance));
                }
            }
        }

        return buildDefaultConfigurations(environment, unconfigured);
    }

    private ArtifactConfig buildArtifactInstanceId(final Artifact artifact, final String instance) {
        ArtifactConfig artifactInstanceId = new ArtifactConfig();
        artifactInstanceId.setGroupId(artifact.getGroupId());
        artifactInstanceId.setArtifactId(artifact.getArtifactId());
        artifactInstanceId.setArtifactVersion(artifact.getVersion());
        artifactInstanceId.setName(instance);
        return artifactInstanceId;
    }

    /**
     * Load existing {@link ArtifactCommonConfig} or generate a default
     * 
     * @param artifact
     * @return
     */
    public ArtifactCommonConfig loadOrDefaultCommonConfig(final NexusArtifact artifact) {
        ArtifactCommonConfig config = artifactCommonConfigDao.load(artifact);

        if (config == null) {
            config = getDefaultCommonConfig(artifact);
        }
        return config;
    }

    /**
     * Get a default {@link ArtifactCommonConfig}
     * 
     * @param artifact
     * @return
     */
    public ArtifactCommonConfig getDefaultCommonConfig(final NexusArtifact artifact) {
        // By default we assume that client artifacts do not have zookeeper properties and server artifacts do
        boolean hasProperties = !isClientArtifact(artifact);
        ArtifactCommonConfig commonConfig = new ArtifactCommonConfig(
                artifact.getGroupId(),
                artifact.getArtifactId(),
                ArtifactCommonConfig.NONPROD_DEFAULT,
                hasProperties,
                ArtifactCommonConfig.PROPERTIES_TEMPLATES_DEFAULT,
                null);
        commonConfig.setNotDeployedEnvironments(new ArrayList<Environment>());
        return commonConfig;
    }

    public List<ArtifactConfig> load(final Environment env, final Artifact artifact) {
        return artifactConfigurationDao.load(env, artifact.getGroupId(), artifact.getArtifactId());
    }

    @Transactional(readOnly = true)
    public Set<Host> getHosts(final Set<DeployTag> tags) {
        List<Host> hosts = hostDao.loadAll();

        Set<Host> matchingHosts = Sets.newHashSet();

        Predicate<DeployTag> matchesDeployTag = new Predicate<DeployTag>() {
            @Override
            public boolean apply(final DeployTag input) {
                return tags.contains(input);
            }
        };

        for (Host host : hosts) {
            if (host.getDeployTags() != null && Iterables.any(host.getDeployTags(), matchesDeployTag)) {
                matchingHosts.add(host);
            }
        }
        return matchingHosts;
    }

    private List<ArtifactConfig> buildDefaultConfigurations(final Environment transientEnvironment,
            final List<ArtifactConfig> unconfigured) {

        // ensure the environment is complete with id.
        Environment environment = environmentDao.loadEnvironment(transientEnvironment);

        List<ArtifactConfig> defaultConfigs = Lists.newArrayListWithExpectedSize(unconfigured.size());
        for (ArtifactConfig config : unconfigured) {
            config.setEnvironment(environment);

            ArtifactConfig forDefaults = findArtifactForUseAsDefaults(environment, config);

            if (forDefaults != null) {
                config.setScript(forDefaults.getScript());
                // Attempt to default the arguments from a previously configured environment.
                config.setScriptArguments(forDefaults.getScriptArguments());
            }

            // TODO Neo specific logic doesn't belong in core swift.
            if (isClientArtifact(config.getArtifact())) {
                if (config.getScript() == null) {
                    config.setScript(defaultClientScript);
                }
                config.setDeployTags(Lists.newArrayList(new DeployTag(environment, CLIENT_DEPLOY_TAG)));
            }

            defaultConfigs.add(config);

        }
        return defaultConfigs;
    }

    private ArtifactConfig findArtifactForUseAsDefaults(final Environment environment, final ArtifactConfig artifact) {
        // Search backwards through the list of environments for the startup args (ie assume that arguments in later
        // environments are more likely to be correctly configured). Start at the environment this artifact is being
        // deployed to as there may already be existing configurations in the same environment.
        List<String> orderedEnvs = orgEnvironmentsMap.get(environment.getOrganisation().getName());
        for (int i = orderedEnvs.indexOf(environment.getName()); i >= 0; i--) {
            Environment previousEnvironment = new Environment(orderedEnvs.get(i), environment.getOrganisation());
            List<ArtifactConfig> existing = artifactConfigurationDao.load(previousEnvironment, artifact.getGroupId(),
                    artifact.getArtifactId());
            if (!existing.isEmpty()) {
                LOG.info("Using artifact configuration from environment {} for artifact {}", previousEnvironment,
                        artifact);
                return existing.get(0);
            }
        }
        return null;
    }

    /**
     * Returns a list of ordered dependencies such that no artifact is dependant on another artifact at the same level
     * or later in the list. Artifacts are placed at the lowest level possible.
     * <p>
     * TODO This is just to fit dependencies into the current deployment plan structure (which just supports sequential
     * and parallel actions). It would be wiser for the deployment plan to understand dependant actions. Even if that is
     * done though, the ordering helps present items in the deployment in a logical order.
     * 
     * @param list
     * @return
     */
    private DependencyGraph<NexusArtifact> orderArtifactDependencies(final Collection<ArtifactCommonConfig> list) {
        List<ArtifactCommonConfig> toProcess = Lists.newArrayList(list);

        List<List<NexusArtifact>> groupedDeps = Lists.newArrayList();
        while (!toProcess.isEmpty()) {
            List<NexusArtifact> levelArtifacts = Lists.newArrayList();
            List<ArtifactCommonConfig> levelProcessed = Lists.newArrayList();
            for (Iterator<ArtifactCommonConfig> configIter = toProcess.iterator(); configIter.hasNext();) {
                ArtifactCommonConfig config = configIter.next();
                if (thisDependsOnNoOtherArtifact(config, toProcess)) {
                    levelArtifacts.add(config.getArtifact());
                    levelProcessed.add(config);
                }
            }

            if (levelArtifacts.isEmpty()) {
                throw new IllegalStateException("No artifacts pulled from list. Circular dependency.");
            }

            toProcess.removeAll(levelProcessed);
            groupedDeps.add(levelArtifacts);
        }
        return new DependencyGraph<NexusArtifact>(ImmutableList.copyOf(groupedDeps).reverse());
    }

    public DependencyGraph<NexusArtifact> orderDependencies(final Collection<NexusArtifact> artifacts) {
        List<ArtifactCommonConfig> artifactConfigs = Lists.newArrayList();
        for (NexusArtifact artifact : artifacts) {
            artifactConfigs.add(loadOrDefaultCommonConfig(artifact));
        }
        return orderArtifactDependencies(artifactConfigs);
    }

    public DependencyGraph<NexusArtifact> orderDependenciesGraph(final Collection<NexusArtifact> artifacts) {
        return orderDependencies(artifacts);
    }

    private boolean thisDependsOnNoOtherArtifact(final ArtifactCommonConfig config,
            final List<ArtifactCommonConfig> list) {
        for (ArtifactCommonConfig dependency : config.getDependencies()) {
            if (list.contains(dependency)) {
                return false;
            }
            if (!thisDependsOnNoOtherArtifact(dependency, list)) {
                return false;
            }
        }
        return true;
    }

    public DependencyGraph<NexusArtifact> getOrderedArtifactsDependentOn(final Collection<NexusArtifact> artifacts) {
        return getOrderedArtifactsDependencies(artifacts, GetDependantOnArtifactFunction.INSTANCE);
    }

    public DependencyGraph<NexusArtifact> getOrderedArtifactsThisDependsOn(final Collection<NexusArtifact> artifacts) {
        return getOrderedArtifactsDependencies(artifacts, GetArtifactDependenciesFunction.INSTANCE);
    }

    private DependencyGraph<NexusArtifact> getOrderedArtifactsDependencies(final Collection<NexusArtifact> artifacts,
            final Function<ArtifactCommonConfig, List<ArtifactCommonConfig>> traversalFunction) {
        Set<ArtifactCommonConfig> allDepsAndNodes = Sets.newLinkedHashSet();

        for (NexusArtifact artifact : artifacts) {
            addAllArtifactDependencies(allDepsAndNodes, loadOrDefaultCommonConfig(artifact), traversalFunction);
        }
        return orderArtifactDependencies(allDepsAndNodes);
    }

    private void addAllArtifactDependencies(final Set<ArtifactCommonConfig> allDepsAndNodes,
            final ArtifactCommonConfig dbArtifact,
            final Function<ArtifactCommonConfig, List<ArtifactCommonConfig>> traversalFunction) {
        allDepsAndNodes.add(dbArtifact);

        for (ArtifactCommonConfig parent : traversalFunction.apply(dbArtifact)) {
            addAllArtifactDependencies(allDepsAndNodes, parent, traversalFunction);
        }
    }

    /**
     * Resolves an artifactInstanceId String to the {@link Entry} and {@link Environment}.
     */
    public EnvironmentEntryPair resolveArtifactInstanceId(final String artifactInstanceId) {
        return resolveArtifactInstanceId(ArtifactInstanceId.parse(artifactInstanceId));
    }

    /**
     * Resolves an artifactInstanceId String to the {@link Entry} and {@link Environment}.
     */
    public EnvironmentEntryPair resolveArtifactInstanceId(final ArtifactInstanceId instanceId) {
        EnvironmentId environmentId = instanceId.getEnvironment();
        Environment environment = environmentDao.loadEnvironment(environmentId.getEnvironmentName(),
                environmentId.getOrganisationName());

        Entry entry = environmentDocumentStore.filterByMountPoint(environment, instanceId.getMountPoint());

        return new EnvironmentEntryPair(environment, entry);
    }

    /**
     * Resolves a collection of artifactInstanceId String to the {@link Entry} and {@link Environment}.
     */
    public List<EnvironmentEntryPair> resolveArtifactInstanceIds(final List<String> instanceIds) {
        return ProcessorUtil.transform(instanceIds, new Function<String, EnvironmentEntryPair>() {
            @Override
            public EnvironmentEntryPair apply(final String instanceId) {
                return resolveArtifactInstanceId(instanceId);
            }
        });
    }

    /**
     * Resolves a list of artifacts from the specified instance ids.
     */
    public List<EnvironmentArtifactPair> resolveArtifactInstanceIdsToArtifacts(final List<String> instanceIds) {
        return ProcessorUtil.transform(instanceIds, new Function<String, EnvironmentArtifactPair>() {
            @Override
            public EnvironmentArtifactPair apply(final String instanceId) {
                EnvironmentEntryPair envEntryPair = resolveArtifactInstanceId(instanceId);
                Entry entry = envEntryPair.entry;
                return new EnvironmentArtifactPair(envEntryPair.environment, new Artifact(entry.getGroupId(), entry
                        .getArtifactId(), entry.getVersion()));
            }
        });
    }

    public static class EnvironmentEntryPair {
        private final Environment environment;
        private final Entry entry;

        public EnvironmentEntryPair(final Environment environment, final Entry entry) {
            this.environment = environment;
            this.entry = entry;
        }

        public Environment getEnvironment() {
            return environment;
        }

        public Entry getEntry() {
            return entry;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(environment);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof EnvironmentEntryPair) {
                EnvironmentEntryPair that = (EnvironmentEntryPair) object;
                return Objects.equal(this.environment, that.environment) &&
                        Objects.equal(this.entry, that.entry);
            }
            return false;
        }
    }

    public static class EnvironmentArtifactPair {
        private final Environment environment;
        private final Artifact artifact;

        public EnvironmentArtifactPair(final Environment environment, final Artifact artifact) {
            this.environment = environment;
            this.artifact = artifact;
        }

        public Environment getEnvironment() {
            return environment;
        }

        public Artifact getArtifact() {
            return artifact;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(environment);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof EnvironmentArtifactPair) {
                EnvironmentArtifactPair that = (EnvironmentArtifactPair) object;
                return Objects.equal(this.environment, that.environment) &&
                        Objects.equal(this.artifact, that.artifact);
            }
            return false;
        }
    }

    public ArtifactConfig loadArtifactConfigurationForEntry(final Environment environment, final Entry entry) {
        return artifactConfigurationDao.load(environment, entry.getGroupId(), entry.getArtifactId(),
                entry.getName());
    }

    @Required
    public void setClientGroupPrefixes(final String clientGroupPrefixes) {
        this.clientGroupPrefixes = clientGroupPrefixes.trim().split(",");
    }

    @Required
    public void setArtifactConfigurationDao(final ArtifactConfigurationDao artifactConfigurationDao) {
        this.artifactConfigurationDao = artifactConfigurationDao;
    }

    @Required
    public void setArtifactCommonConfigDao(final ArtifactCommonConfigDao artifactCommonConfigDao) {
        this.artifactCommonConfigDao = artifactCommonConfigDao;
    }

    @Required
    public void setDefaultClientScript(final String defaultClientScript) {
        this.defaultClientScript = defaultClientScript;
    }

    @Required
    public void setEnvironmentDocumentStore(final EnvironmentDocumentStore environmentDocumentStore) {
        this.environmentDocumentStore = environmentDocumentStore;
    }

    @Required
    public void setOrgEnvironmentsMap(final OrganisationBeanFactory<List<String>> orgEnvironmentsMap) {
        this.orgEnvironmentsMap = orgEnvironmentsMap;
    }

    @Required
    public void setEnvironmentDao(final EnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }

    @Required
    public void setHostDao(final HostDao hostDao) {
        this.hostDao = hostDao;
    }

    @Required
    public void setArtifactTypeService(final ArtifactTypeService artifactTypeService) {
        this.artifactTypeService = artifactTypeService;
    }

}
