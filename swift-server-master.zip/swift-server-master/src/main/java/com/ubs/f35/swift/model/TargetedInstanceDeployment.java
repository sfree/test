package com.ubs.f35.swift.model;

import java.util.List;

import com.google.common.base.Objects;

public class TargetedInstanceDeployment {
    /**
     * A release is only for one organisation, so the environment name filters sufficiently.
     */
    private String environment;
    private List<TargetedArtifactDeployment> targetedArtifactDeployments;

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(final String environment) {
        this.environment = environment;
    }

    public List<TargetedArtifactDeployment> getTargetedArtifactDeployments() {
        return targetedArtifactDeployments;
    }

    public void setTargetedArtifactDeployments(final List<TargetedArtifactDeployment> targetedArtifactDeployments) {
        this.targetedArtifactDeployments = targetedArtifactDeployments;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(environment, targetedArtifactDeployments);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof TargetedInstanceDeployment) {
            TargetedInstanceDeployment that = (TargetedInstanceDeployment) object;
            return Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.targetedArtifactDeployments, that.targetedArtifactDeployments);
        }
        return false;
    }

    public static class TargetedArtifactDeployment {
        private ArtifactId artifact;
        private List<String> instanceNames;

        public ArtifactId getArtifact() {
            return artifact;
        }

        public void setArtifact(final ArtifactId artifact) {
            this.artifact = artifact;
        }

        public List<String> getInstanceNames() {
            return instanceNames;
        }

        public void setInstanceNames(final List<String> instanceNames) {
            this.instanceNames = instanceNames;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(artifact, instanceNames);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof TargetedArtifactDeployment) {
                TargetedArtifactDeployment that = (TargetedArtifactDeployment) object;
                return Objects.equal(this.artifact, that.artifact)
                        && Objects.equal(this.instanceNames, that.instanceNames);
            }
            return false;
        }
    }

    public static class ArtifactId {
        private String groupId;
        private String artifactId;

        public ArtifactId() {
        }

        public ArtifactId(final String groupId, final String artifactId) {
            this.groupId = groupId;
            this.artifactId = artifactId;
        }

        public String getGroupId() {
            return groupId;
        }

        public void setGroupId(final String groupId) {
            this.groupId = groupId;
        }

        public String getArtifactId() {
            return artifactId;
        }

        public void setArtifactId(final String artifactId) {
            this.artifactId = artifactId;
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(groupId, artifactId);
        }

        @Override
        public boolean equals(final Object object) {
            if (object instanceof ArtifactId) {
                ArtifactId that = (ArtifactId) object;
                return Objects.equal(this.groupId, that.groupId)
                        && Objects.equal(this.artifactId, that.artifactId);
            }
            return false;
        }
    }
}
