package com.ubs.f35.swift.properties.model;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link ArrayList} of {@link ArtifactProperties}. The main reason for this subclass is to work around a problem
 * whereby the Spring Rest Template does not correctly marshal a generic (typed) container such as {@link List}&lt;
 * {@link ArtifactProperties}&gt; when it is passed as a JSON request body.
 * 
 * @author levyjo
 * 
 */
public class ArtifactPropertiesList extends ArrayList<ArtifactProperties> {

    private static final long serialVersionUID = -4432019377760074149L;

}
