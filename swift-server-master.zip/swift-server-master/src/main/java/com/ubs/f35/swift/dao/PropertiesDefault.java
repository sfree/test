package com.ubs.f35.swift.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Environment;

@Entity
@Table(name = "PROPERTIES_DEFAULTS")
@Audited
public class PropertiesDefault implements Serializable {

    private static final long serialVersionUID = -4232984795651924744L;

    @Id
    @ManyToOne(fetch = FetchType.EAGER)
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private Environment environment;

    @Id
    @Column(name = "property_key")
    private String key;

    @Column(name = "property_value")
    @Lob
    private String value;

    public PropertiesDefault() {

    }

    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }

    public String getKey() {
        return key;
    }

    public void setKey(final String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(final String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("environment", environment)
                .add("key", key)
                .add("value", value)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(super.hashCode(), environment, key, value);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof PropertiesDefault) {
            PropertiesDefault that = (PropertiesDefault) object;
            return Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.key, that.key)
                    && Objects.equal(this.value, that.value);
        }
        return false;
    }

}
