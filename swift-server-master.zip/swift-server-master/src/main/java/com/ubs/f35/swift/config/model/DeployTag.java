package com.ubs.f35.swift.config.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.google.common.base.Objects;
import com.ubs.f35.swift.dao.model.Environment;

/**
 * Deploy tags are not audited as they are immutable
 * 
 * @author stephelu
 * 
 */
@Entity
@Table(name = "deploy_tags")
public class DeployTag implements Serializable {
    @Id
    private String tag;

    @Id
    @ManyToOne(fetch = FetchType.EAGER)
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private Environment environment;

    public DeployTag() {
    }

    public DeployTag(final Environment environment, final String tag) {
        this.environment = environment;
        this.tag = tag;
    }

    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public void setTag(final String tag) {
        this.tag = tag;
    }

    public String getTag() {
        return tag;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(environment, tag);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DeployTag) {
            DeployTag that = (DeployTag) object;
            return Objects.equal(this.environment, that.environment)
                    && Objects.equal(this.tag, that.tag);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("environment", environment)
                .add("tag", tag)
                .toString();
    }

}
