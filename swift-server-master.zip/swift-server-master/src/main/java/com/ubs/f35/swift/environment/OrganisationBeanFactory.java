package com.ubs.f35.swift.environment;

import java.util.Map;

/**
 * Swift manages releases to multiple organisations. Implementors provide access to organisation specific functionality.
 * 
 * @param <T>
 *            The manager for the organisation
 */
public interface OrganisationBeanFactory<T> {
    T get(String organisation);

    Map<String, T> getAll();

    void registerUpdateListener(Runnable runnable);
}
