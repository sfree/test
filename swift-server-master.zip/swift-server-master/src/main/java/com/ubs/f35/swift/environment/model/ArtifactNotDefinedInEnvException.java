package com.ubs.f35.swift.environment.model;

import com.ubs.f35.swift.dao.Artifact;
import com.ubs.f35.swift.dao.NexusArtifact;
import com.ubs.f35.swift.model.ReleaseLogicException;

public class ArtifactNotDefinedInEnvException extends ReleaseLogicException {

    private final NexusArtifact artifact;

    public ArtifactNotDefinedInEnvException(final Artifact artifact) {
        this(artifact.getNexusArtifact());
    }

    public ArtifactNotDefinedInEnvException(final NexusArtifact artifact) {
        super(artifact.getGroupId() + " : " + artifact.getArtifactId()
                + " is not mapped to any hosts.  Please configure first.");
        this.artifact = artifact;
    }

    public NexusArtifact getArtifact() {
        return artifact;
    }
}
