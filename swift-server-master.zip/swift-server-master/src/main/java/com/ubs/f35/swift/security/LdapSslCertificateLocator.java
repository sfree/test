package com.ubs.f35.swift.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

public class LdapSslCertificateLocator implements InitializingBean {

    private static final Logger LOG = LoggerFactory.getLogger(LdapSslCertificateLocator.class);

    static final String TRUST_STORE_PROPERTY = "javax.net.ssl.trustStore";

    private Resource certificateFile;

    @Required
    public void setCertificateFile(final Resource certificateFile) {
        this.certificateFile = certificateFile;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.isNull(System.getProperty(TRUST_STORE_PROPERTY), "System property " + TRUST_STORE_PROPERTY
                + " unexpectedly set");
        String certFile = certificateFile.getFile().getAbsolutePath();
        System.setProperty(TRUST_STORE_PROPERTY, certFile);

        LOG.info("Setting {} to {}", TRUST_STORE_PROPERTY, certFile);
    }

}
