Swift Server
============

Swift Server is the service layer behind the [Swift Client](https://github.ldn.swissbank.com/NeoSwift/swift-client).

The API exposed by Swift Server is documented in the [NeoSwift/docs](https://github.ldn.swissbank.com/NeoSwift/docs/blob/master/README.md) repository.

Check out the [Swift Tutorial](http://confluence.swissbank.com/display/neo/Swift+Tutorial) for a short guide on using Swift to manage your deployments and releases.

## For Developers

Swift Server is based on the standard [core-server-io-adaptor](https://github.ldn.swissbank.com/FedEx/core-server-io-adaptor).

For local Swift Server development, all you need to do is clone this repository: 
```
git clone git@github.ldn.swissbank.com:NeoSwift/swift-server.git
```

The following steps are highly recommended:

1. [Configuring Lifecycle Mappings](http://confluence.swissbank.com/display/neo/Configuring+Lifecycle+Mappings+in+Eclipse) (Eclipse) - Fixes m2e lifecycle configuration errors
2. [Code Formatting](http://confluence.swissbank.com/display/neo/Onboarding+Java+Developers) (Eclipse) - Prevents merge pain due to code formatting differences
3. [Swift Client](https://github.ldn.swissbank.com/NeoSwift/swift-client) - Set up and run a Swift client locally to test your server changes
4. [Postman REST Client](https://chrome.google.com/webstore/detail/postman-rest-client/fdmmgilgnpjigdojojpjoooidkmcomcm?hl=en) for Chrome - Test your server changes (you'll still need to login on your own or someone else's Swift client)
