swift-idp-server-script               [![Build Status](https://cft-teamcity.ldn.swissbank.com/app/rest/builds/buildType:%28id:UbsNeo_NeoSwift_SwiftIdpServerScript_Deploy%29/statusIcon)](https://cft-teamcity.ldn.swissbank.com/project.html?projectId=UbsNeo_NeoSwift_SwiftIdpServerScript)
=======================

Swift deployment GLU scripts for Jetty embedded Java applications.

To build, you need a Swift-compatible profile with associated *cft-nexus* repos.

```xml
    <profile>
            <id>swift</id>
            <activation>
                <activeByDefault>false</activeByDefault>
            </activation>
            <repositories>
                <repository>
                    <id>snapshots-java</id>
                    <name>INT - Java Snapshots</name>
                    <url>http://cft-nexus.ldn.swissbank.com:8081/nexus/content/repositories/snapshots-java/</url>
                </repository>
                <repository>
                    <id>releases-java</id>
                    <name>INT - Java Releases</name>
                    <url>http://cft-nexus.ldn.swissbank.com:8081/nexus/content/repositories/releases-java/</url>
                </repository>
                <repository>
                    <id>maven-central</id>
                    <name>RKYCTOOLS Maven Central</name>
                    <url>http://rkyctools.ldn.swissbank.com:8090/nexus/content/repositories/central/</url>
                </repository>

                <repository>
                    <id>g-ged-public-repositories</id>
                    <name>UBS - GED</name>
                    <url>http://cft-nexus.ldn.swissbank.com:8081/nexus/content/groups/g-ged-public-repositories/</url>
                </repository>
                
                <repository>
                    <id>thirdparty</id>
                    <name>3rd party</name>
                    <url>http://cft-nexus.ldn.swissbank.com:8081/nexus/content/repositories/thirdparty/</url>
                </repository>

            </repositories>
            <pluginRepositories>
                <pluginRepository>
                    <id>g-ged-public-repositories</id>
                    <url>http://cft-nexus.ldn.swissbank.com:8081/nexus/content/groups/g-ged-public-repositories/</url>
                </pluginRepository>
                <pluginRepository>
                    <id>proc-maven-core</id>
                    <url>http://cft-nexus.ldn.swissbank.com:8081/nexus/content/repositories/proc-maven-core/</url>
                </pluginRepository>
                <pluginRepository>
                    <id>releases-java</id>
                    <name>INT - Java Releases</name>
                    <url>http://cft-nexus.ldn.swissbank.com:8081/nexus/content/repositories/releases-java/</url>
                </pluginRepository>
                <pluginRepository>
                    <id>thirdparty</id>
                    <name>3rd party</name>
                    <url>http://cft-nexus.ldn.swissbank.com:8081/nexus/content/repositories/thirdparty/</url>
                </pluginRepository>
                <pluginRepository>
                    <id>snapshots-java</id>
                    <name>INT - Java Snapshots</name>
                    <url>http://cft-nexus.ldn.swissbank.com:8081/nexus/content/repositories/snapshots-java/</url>
                </pluginRepository>
            </pluginRepositories>
    </profile>
```
