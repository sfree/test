class SwiftIDPClientTARGZPostChangeScript extends BaseSwiftIDPClientScript {

	def install = {
		log.info "install entry"

		// Defer post-processing later
		baseInstall("tar.gz", false)

		String cmd = "tar xvfz ${mavenArtifactFileName} -C ${installRootDir}"
		String res = shell.exec(cmd)
		log.info "tar output: ${res}"

		postStateChangeProcessing()

		log.info "install exit"
	}

	def configure = {
		log.info "configure entry"

        File mountPointPath  = shell.toResource("${mountPoint}").file
        String scriptName = "${mountPointPath}/swift/checkstatus"

        if (rootShell.toResource(scriptName).exists()) {
            log.info "configure : found checkstatus swift script: " + scriptName
            baseConfigure('5m')
        }

		postStateChangeProcessing()

		log.info "configure exit"
	}

	def start = {
		log.info "start entry"

		postStateChangeProcessing()

		log.info "start exit"
	}

	def stop = {
		log.info "stop entry"

		postStateChangeProcessing()

		log.info "stop exit"
	}

	def unconfigure = {
		log.info "unconfigure entry"

		baseUnconfigure()
		
		postStateChangeProcessing()

		log.info "unconfigure exit"
	}

    /**
     * Defines the timer that will check for the server to be up and running and will act
     * according if not (change state)
     */
    def processMonitor = {
        try
        {
            def clientError = null

            try {
                checkStatus();
            } catch(Exception deploymentEx) {
                if(deploymentEx.getMessage()==null){
                    clientError = deploymentEx.toString()
                }
                else{
                    clientError = deploymentEx.getMessage()
                }
                log.info "CLIENT ERROR = " + clientError
            }

            def up = (clientError == null)

            def currentState = stateManager.state.currentState

            def newState = null
            def newError = null

            // case when current state is running
            if(currentState == 'running')
            {
                if(!up)
                {
                    newState = 'stopped'
                    newError = clientError
                    log.warn "${newError} => forcing new state ${newState}"
                }
            }
            else
            {
                if(up)
                {
                    newState = 'running'
                    log.info "Client artifact found again"
                }
            }

            if(newState)
                stateManager.forceChangeState(newState, newError)

            log.debug "Server Monitor: ${stateManager.state.currentState} / ${up}"
        }
        catch(Throwable th)
        {
            log.warn "Exception while running serverMonitor: ${th.message}"
            log.debug("Exception while running serverMonitor (ignored)", th)
        }
    }

}