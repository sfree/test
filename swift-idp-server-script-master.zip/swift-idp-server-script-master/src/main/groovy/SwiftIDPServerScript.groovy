import org.linkedin.glu.agent.api.ShellExecException

/**
 * This is a glu script for installing IDP .jar artifacts.
 *
 * Required configuration:
 * <pre>
 *     "initParameters": {*       "project": {              // the nexus artifact/group/version details
 *         "a": "core-server-entitlements",
 *         "g": "com.ubs.f35.core",
 *         "v": "3.1.2-SNAPSHOT"
 *      },
 *      "startPort": "4500",             // The agent will detect the process is running by polling this port
 *      "startTimeout": "1m",            // Server start timeout
 *      "stopTimeout": "1m",             // Server stop timeout
 *      "jmxPort": "5400",               // JMX remote connections port
 *      "serverMonitorFrequency": "10s", // Interval between monitor polling invocation
 *      "jvmArgs": "-Dmyprop=myvalue",   // Optional JVM arguments
 *      "appArgs": "myArg1 myArg2"       // Optional application arguments
 *  }
 * </pre>
 */
class SwiftIDPServerScript extends BaseSwiftIDPServerScript {

    def install = {
        log.info "install entry"
        
        // Specify 'jar' artifact type for the install
        baseInstall("jar");

        log.info "install exit"
    }

    def configure = { defaultMonitor ->
        log.info "configure entry"
        
        baseConfigure(defaultMonitor);
        
        log.info "configure exit"
    }

    def start = {
        log.info "start entry"

        String jvmArgs = params.jvmArgs ?: ""
        String appArgs = params.appArgs ?: ""
        
        // TODO: Probably not great to bind to 0.0.0.0 (use hostname?)
        baseStart(jvmArgs, "--server.address=0.0.0.0 --server.port=${params.startPort} ${appArgs}")

        log.info "start exit"
    }

    def stop = {
        log.info "stop entry"

        baseStop()
        
        log.info "stop exit"
    }
}