import org.linkedin.glu.agent.api.ShellExecException
import java.io.File;
import java.util.zip.ZipFile
import java.util.zip.ZipException

/**
 * This is a glu script for installing IDP artifacts.  Basic monitoring is provided.
 *
 * TODO Implement checking of deployed version against request version
 *
 * TODO implement post install functionality (if required)
 *
 * Required configuration:
 * <pre>
 *     "initParameters": {*       "project": {              // the nexus artifact/group/version details
 *         "a": "core-server-entitlements",
 *         "g": "com.ubs.f35.core",
 *         "v": "3.1.2-SNAPSHOT"
 *      },
 *      "startPort": "4500",             // The agent will detect the process is running by polling this port
 *      "startTimeout": "1m",            // Server start timeout
 *      "stopTimeout": "1m",             // Server stop timeout
 *      "jmxPort": "5400",               // JMX remote connections port
 *      "serverMonitorFrequency": "10s", // Interval between monitor polling invocation
 *  }
 * </pre>
 */
abstract class BaseSwiftIDPServerScript {
    def group
    def artifact
    def projectVersion
    def mavenArtifactFileName
    def installDest
    def installRootDir

    def baseInstall (String artifactSuffix) {
        log.info('baseInstall entry')
        
        String artifact = params.project.a
        String projectVersion = params.project.v
        
        // Establish installation directory
        
        // Use mount point after chat with Steve
        installDest = "${mountPoint}"
        
        log.info("Installing to ${installDest}...")
        
        def installRoot = shell.mkdirs(installDest)
        installRootDir = installRoot.file
        
        log.info("Install root set to '${installRootDir}'")

        // Establish artifact name
        
        mavenArtifactFileName = "${installRootDir}/${artifact}-${projectVersion}.${artifactSuffix}"        

        // Fetch from Nexus
        
        String artifactUrl = buildRepositoryUrl(artifactSuffix)
        
        String res = shell.exec("curl -L '${artifactUrl}' -o ${mavenArtifactFileName}")
        
        log.info("Fetch from Nexus (curl) returns : ${res}")
        
        // Extract optional Swift scripts
        
        extractSwiftScripts(mavenArtifactFileName)
        
        // TODO: Think about linking!

        postStateChangeProcessing()
        
        log.info('baseInstall exit')
    }

    def baseConfigure = { defaultMonitor ->
        log.info('baseConfigure entry')

        // setting up a timer to monitor the server.
        // Always pass a reference to the monitor as a String.  otherwise the agent attempts to find the
        // timer property, invoking other methods at the same time.
        // See http://glu.977617.n3.nabble.com/Adding-a-server-monitor-causes-function-to-be-invoked-td4025417.html
        timers.schedule(timer: "processMonitor",
                repeatFrequency: params.serverMonitorFrequency ?: 10000)
        
        postStateChangeProcessing()
        
        log.info('baseConfigure exit')
    }

    def baseStart (String jvmArgs, String appArgs) { 
        log.info('baseStart entry')
        
        def pid = getProcessId()
        
        if(pid!=null){
            shell.fail("Process is already started. Process id:${pid}")
        }
        
        if(isListening()){
            shell.fail("Port already in use. startPort:${params.startPort}")
        }

        String javaExe              = "/sbcimp/run/tp/sun/jre/v1.7.0_21-64bit/bin/java"
        String zkClientProperties   = "file:/sbclocal/apps/f35/resources/${params.project.g}/${params.project.a}/properties/zookeeper-client.properties"
        String zkGAVOverride        = "${params.project.g}/${params.project.a}/${params.project.v}"
                
        String strCommand = "${javaExe} ${jvmArgs} -DzkClientProperties=${zkClientProperties} -DzkGAVOverride=${zkGAVOverride} -jar ${mavenArtifactFileName} ${appArgs} &"
        
        log.info("Using start command: ${strCommand}")
        log.info("Using start directory: ${installRootDir}")
        
        shell.exec(pwd:installRootDir, redirectStderr:true, command:strCommand)
        
        log.info("Check process status...")
        
        shell.waitFor(timeout: params.startTimeout ?: '5s', heartbeat: '1s') {
            log.info("Waiting for process to start...")
            return isServerUpAndListening()
        }
        
        postStateChangeProcessing()
        
        log.info("baseStart exit")
    }

    public Integer getProcessId() {
        log.info("getProcessId entry")
        
        String psCmd = "ps -ef | grep ${mavenArtifactFileName}"
        
        log.info("Using 'ps' command as follows: ${psCmd}")
        
        def output = shell.exec(redirectStderr: true, command: psCmd)

        log.info("'ps' output = ${output}")
        
        // TODO: Need a better regex to find the process (this gets the first process for the artifact)

        def matcher = output =~ /( +)([0-9]+) (.+)java (.+) -jar/
        
        if (matcher) {
            def res = matcher[0][2]
            log.info("getProcessId returning ${res}")
            return res as int
        } else{
            log.info("Failed to locate process?")
        }
        
        log.info("getProcessId returning null")
        
        return null
    }

    def baseStop = {
        log.info "baseStop entry"
        
        // Kill process and wait to ensure it dies
        
        shell.exec("kill ${getProcessId()}")
        
        shell.waitFor(timeout: params.stopTimeout ?: '5s', heartbeat: '1s') {
            log.info("######## waiting for process to terminate")
            return isProcessDown()
        }
        
        postStateChangeProcessing()
        
        log.info("baseStop exit")
    }

    def unconfigure = {
        log.info "unconfigure entry"
        
        // timers.cancel(timer: "processMonitor")
        
        postStateChangeProcessing()
        
        log.info "unconfigure exit"
    }

    def uninstall = {
        log.info "uninstall entry"
        
        // TODO: Review this as this is possibly Neo-specific
        // nothing to do here.  The existing installation is left should a rollback be required.
        
        postStateChangeProcessing()
        
        log.info("uninstall exit")
    }

    String buildRepositoryUrl(String artifactSuffix) {
        
        log.info "buildRepositoryUrl entry"
        
        // Use Nexus redirect approach suggested by Luke
        
        String baseUrl = 'http://rkyctools.ldn.swissbank.com:8090//nexus/service/local/artifact/maven/redirect'
        String repo = 'g-internal-releases-and-snapshots'
        
        // Assemble redirect url
        
        String url = baseUrl +
                     "?r=${repo}" +
                     "&g=${params.project.g}" +
                     "&a=${params.project.a}" +
                     "&v=${params.project.v}" +
                     "&e=${artifactSuffix}"
                     
        log.info("buildRepositoryUrl returning: ${url}")
        
        return url
    }

    /**
     * Defines the timer that will check for the server to be up and running and will act
     * according if not (change state)
     */
    def processMonitor = {
        try
        {
            log.info "processMonitor entry"
            
            def up = isProcessUp()
            
            log.info "isProcessUp returned: $up"

            def currentState = stateManager.state.currentState
            def currentError = stateManager.state.error

            def newState = null
            def newError = null

            // case when current state is running
            if(currentState == 'running')
            {
                if(isProcessDown())
                {
                    newState = 'stopped'
                    newError = 'Server down detected. Check the log file for errors.'
                    log.warn "${newError} => forcing new state ${newState}"
                }
            }
            else
            {
                if(up)
                {
                    newState = 'running'
                    log.info "Server up detected."
                }
            }

            if(newState)
                stateManager.forceChangeState(newState, newError)

            log.debug "Server Monitor: ${stateManager.state.currentState} / ${up}"
        }
        catch(Throwable th)
        {
            log.warn "Exception while running serverMonitor: ${th.message}"
            log.debug("Exception while running serverMonitor (ignored)", th)
        }
        
        log.info "processMonitor exit"
    }

    public boolean isProcessUp()
    {
        return getProcessId() != null
    }

    public boolean isProcessDown()
    {
        return getProcessId() == null
    }

    public boolean isListening()
    {
        return shell.listening('localhost', params.startPort)
    }
    
    public boolean isServerUpAndListening()
    {
        log.info "isServerUpAndListening entry"
        
        boolean isUp = isProcessUp()
        boolean isListening = isListening()

        log.info "isServerUpAndListening results: up=${isUp}, listening=${isListening}"

        boolean res = isUp && isListening
        
        log.info "isServerUpAndListening returning: ${res}"
        
        return res
    }
    
    /**
     * Following any state transition action (start, stop etc.), execute the corresponding
     * shell script if present in the artifact 'swift' directory
     */
    def postStateChangeProcessing() {
        String transitionAction = stateManager.state.transitionAction

        log.info "postStateChangeProcessing entry for transitionAction '${transitionAction}'"
        
        String scriptName = "${installRootDir}/swift/post" + transitionAction
        
        log.info("postStateChangeProcessing : check for '${scriptName}' script...")
        
        if (rootShell.toResource(scriptName).exists()) {
            log.info "postStateChangeProcessing : found post-${transitionAction} script: " + scriptName
            
            String cmd = scriptName + " " +
                installRootDir + " " +
                mavenArtifactFileName + " " +
                params.project.g + " " +
                params.project.a + " " +
                params.project.v
            
            log.info "postStateChangeProcessing : execute command: ${cmd}"
            
            String res = shell.exec(cmd)
            
            log.info "postStateChangeProcessing : command output: ${res}"
        }
        
        log.info "postStateChangeProcessing exit"
    }
    
    /**
     * Extract optional Swift (Glu) state transition action scripts to installRootDir
     * @param artifactName
     * @return
     */
    def extractSwiftScripts(String artifactName) {
        log.info "extractSwiftScripts entry"
        
        String target = installRootDir

        ZipFile jar = new ZipFile(artifactName)
        
        def entries = jar.entries()
        
        entries.each { file->
            if (file.name.startsWith("swift"))
            {
                FileOutputStream fos = null
                InputStream is = null
                
                log.info "Processing ${file.name}"

                File f = new java.io.File(target + java.io.File.separator + file.getName())

                // if its a directory, create it

                if (file.isDirectory()) {
                    log.info "Create directory ${file.name}..."
                    f.mkdir()
                } else {
                    log.info "Extracting file ${file.name}..."

                    try {
                        is = jar.getInputStream(file)
    
                        fos = new FileOutputStream(f)
    
                        // write contents of 'is' to 'fos'
                        while (is.available() > 0) {
                            fos.write(is.read())
                        }
                        
                        // Make executable
                        shell.exec("chmod 750 ${f.getAbsolutePath()}")
                    } finally {
                        if (fos != null) fos.close()
                        if (is != null) is.close()
                    }
                }
            }
        }
        
        log.info "extractSwiftScripts exit"
    }
}