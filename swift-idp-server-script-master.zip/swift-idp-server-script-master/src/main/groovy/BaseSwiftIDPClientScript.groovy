import java.util.zip.ZipFile
/**
 * This is a glu script for installing IDP client artifacts.  Basic monitoring is provided.
 *
 * TODO Implement checking of deployed version against request version
 *
 * Required configuration:
 * <pre>
 *     "initParameters": {*       "project": {              // the nexus artifact/group/version details
 *         "a": "core-server-entitlements",
 *         "g": "com.ubs.f35.core",
 *         "v": "3.1.2-SNAPSHOT"
 *      },
 *      "postInstallArgs": "a=b", // User-defined arguments to pass to post install script
 *  }
 * </pre>
 */
abstract class BaseSwiftIDPClientScript {
    def group
    def artifact
    def projectVersion
    def mavenArtifactFileName
    def installDest
    def installLinkDir
    def installRootDir
    
    def baseInstall (String artifactSuffix, boolean postProcess) {
        group = params.project.g
        artifact = params.project.a
        projectVersion = params.project.v
        
        // Use mount point after chat with Steve
        installDest = "${mountPoint}"
        
        log.info("Installing to ${installDest}...")
        
        def installRoot = shell.mkdirs(installDest)
        installRootDir = installRoot.file
        
        log.info("Install root set to '${installRootDir}'")

        // Establish artifact name
        
        mavenArtifactFileName = "${installRootDir}/${artifact}-${projectVersion}.${artifactSuffix}"

        // Fetch from Nexus
        
        String artifactUrl = buildRepositoryUrl(artifactSuffix)

        log.info("Artifact URL: ${artifactUrl}")
        
        String cmd = "curl -L '${artifactUrl}' -o ${mavenArtifactFileName}"
        
        String res = shell.exec(cmd)
        
        log.info("Fetch from Nexus (curl) returns : ${res}")
                
        // TODO: think about symbolic links
        // It seems the provided mountpoint is pre-created without a version
       
        if (postProcess) {
            postStateChangeProcessing()
        }
        
        log.info('baseInstall exit')
    }

    def baseConfigure = { defaultMonitor ->
        log.info "Configuring..."

        timers.schedule(timer: "processMonitor", repeatFrequency: defaultMonitor)

        log.info "Configuration complete."
    }

    def baseUnconfigure = {
        log.info "Un-configuring..."
        
        timers.cancel(timer: "processMonitor")

        log.info "Un-configure complete."
    }

    def uninstall = {
        // Nothing to do here if we use the mountpoint provided as undeploy clears down the directory.
    }
    
    /**
     * Use Nexus "redirect" to resolve path to artefact (caters for snapshots with timestamps)
     * @param artifactSuffix
     * @return
     */
    String buildRepositoryUrl(String artifactSuffix) {
        
        log.info "buildRepositoryUrl entry"
        
        // Use Nexus redirect approach suggested by Luke
        
        String baseUrl = 'http://rkyctools.ldn.swissbank.com:8090//nexus/service/local/artifact/maven/redirect'
        String repo = 'g-internal-releases-and-snapshots'
        
        // Assemble redirect url
        
        String url = baseUrl +
                     "?r=${repo}" +
                     "&g=${params.project.g}" +
                     "&a=${params.project.a}" +
                     "&v=${params.project.v}" +
                     "&e=${artifactSuffix}"
                     
        log.info("buildRepositoryUrl returning: ${url}")
        
        return url
    }
    
    /**
     * Following any state transition action (start, stop etc.), execute the corresponding
     * shell script if present in the artifact 'swift' directory
     */
    def postStateChangeProcessing() {
        String transitionAction = stateManager.state.transitionAction

        log.info "postStateChangeProcessing entry for transitionAction '${transitionAction}'"
        
		File mountPointPath  = shell.toResource("${mountPoint}").file
        String scriptName = "${mountPointPath}/swift/post" + transitionAction

        log.info("postStateChangeProcessing : check for '${scriptName}' script...")
        
        if (shell.toResource(scriptName).exists()) {
            log.info "postStateChangeProcessing : found post-${transitionAction} script: " + scriptName
            
            String cmd = scriptName + " " +
                mountPointPath + " " +
                mavenArtifactFileName + " " +
                params.project.g + " " +
                params.project.a + " " +
                params.project.v
            
            if (transitionAction.equals("install") &&
                params.postInstallArgs != null &&
                params.postInstallArgs.length() > 0) {
                cmd += " " + params.postInstallArgs
            }
            
            log.info "postStateChangeProcessing : execute command: ${cmd}"
            
            String res = shell.exec(cmd)
            
            log.info "postStateChangeProcessing : command output: ${res}"
        }
        
        log.info "postStateChangeProcessing exit"
    }

    /**
     * to check status execute the corresponding
     * shell script if present in the artifact 'swift' directory
     */
    def checkStatus() {

        File mountPointPath  = shell.toResource("${mountPoint}").file
        String scriptName = "${mountPointPath}/swift/checkstatus"

        if (shell.toResource(scriptName).exists()) {
            String cmd = scriptName + " " +
                    mountPointPath + " " +
                    mavenArtifactFileName + " " +
                    params.project.g + " " +
                    params.project.a + " " +
                    params.project.v

            log.info "checkStatus : execute command: ${cmd}"

            // error handling should be done via non zero exit values returned
            // from the script it will cause an exception and display the script output in SWIFT UI
            String res = shell.exec(cmd)

            log.info "checkStatus : command output: ${res}"

        }
        else{
            log.info "checkStatus : No Action - no script present: " + scriptName
        }
    }

    /**
     * Extract optional Swift (Glu) state transition action scripts to installRootDir
     * @param artifactName
     * @return
     */
    def extractSwiftScripts(String artifactName) {
        log.info "extractSwiftScripts entry"
        
        String target = installRootDir

        ZipFile jar = new ZipFile(artifactName)
        
        def entries = jar.entries()
        
        entries.each { file->
            if (file.name.startsWith("swift"))
            {
                FileOutputStream fos = null
                InputStream is = null
                
                log.info "Processing ${file.name}"

                File f = new java.io.File(target + java.io.File.separator + file.getName())

                // if its a directory, create it

                if (file.isDirectory()) {
                    log.info "Create directory ${file.name}..."
                    f.mkdir()
                } else {
                    log.info "Extracting file ${file.name}..."

                    try {
                        is = jar.getInputStream(file)
    
                        fos = new FileOutputStream(f)
    
                        // write contents of 'is' to 'fos'
                        while (is.available() > 0) {
                            fos.write(is.read())
                        }
                        
                        // Make executable
                        shell.exec("chmod 750 ${f.getAbsolutePath()}")
                    } finally {
                        if (fos != null) fos.close()
                        if (is != null) is.close()
                    }
                }
            }
        }
        
        log.info "extractSwiftScripts exit"
    }
}