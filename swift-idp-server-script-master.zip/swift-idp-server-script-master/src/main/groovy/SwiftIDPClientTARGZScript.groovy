import org.linkedin.glu.agent.api.ShellExecException

/**
 * This is a glu script for installing IDP .war artifacts.
 *
 * Required configuration:
 * <pre>
 *     "initParameters": {*       "project": {              // the nexus artifact/group/version details
 *         "a": "core-server-entitlements",
 *         "g": "com.ubs.f35.core",
 *         "v": "3.1.2-SNAPSHOT"
 *      },
 *      "postInstallArgs": "a=b", // User-defined arguments to pass to post install script
 *  }
 * </pre>
 */
class SwiftIDPClientTARGZScript extends BaseSwiftIDPClientScript {

    def install = {
        log.info "install entry"
        
        // Specify 'tar.gz' artifact type for the install
        baseInstall("tar.gz",
                    false) // Defer post-processing (we call below)
        
        // Un-tar mavenArtifactFileName into installRootDir
        
        String cmd = "tar xvfz ${mavenArtifactFileName} -C ${installRootDir}"
        String res = shell.exec(cmd)
        log.info("tar output: ${res}")
        
        // Chmod optional Swift scripts
		if (shell.toResource("${installRootDir}/swift").exists()) {
	        cmd = "chmod -f 750 ${installRootDir}/swift/*"
	        shell.exec(cmd)
		}
        
        // Check for deployment errors
        try {
            checkDeployment()
        } catch(Exception deploymentEx) {
            String errorMsg = "Artifact deployment error: " + deploymentEx.getMessage()
            log.warn errorMsg
            shell.fail(errorMsg)
        }
        
        postStateChangeProcessing()
        
        log.info "install exit"
    }

    def configure = {
        log.info "configure entry"
        
        baseConfigure('10m')
        
        log.info "configure exit"
    }
    
    def unconfigure = {
        log.info "unconfigure entry"

        baseUnconfigure()

        log.info "unconfigure exit"
    }
    
    def start = {
        log.info "start entry"

        // Check for deployment errors
        try {
            checkDeployment()
        } catch(Exception deploymentEx) {
            String errorMsg = "Artifact start error: " + deploymentEx.getMessage()
            log.warn errorMsg
            shell.fail(errorMsg)
        }

        log.info "start exit"
    }

    def stop = {
        log.info "stop entry"
        
        // Nothing to do
        
        log.info "stop exit"
    }
    
    /**
     * Defines the timer that will check for the server to be up and running and will act
     * according if not (change state)
     */
    def processMonitor = {
        try
        {
            def clientError = null
            
            try {
                checkDeployment();
            } catch(Exception deploymentEx) {
                clientError = deploymentEx.getMessage()
            }
            
            def up = (clientError == null)

            def currentState = stateManager.state.currentState

            def newState = null
            def newError = null

            // case when current state is running
            if(currentState == 'running')
            {
                if(!up)
                {
                    newState = 'stopped'
                    newError = clientError
                    log.warn "${newError} => forcing new state ${newState}"
                }
            }
            else
            {
                if(up)
                {
                    newState = 'running'
                    log.info "Client artifact found again"
                }
            }

            if(newState)
                stateManager.forceChangeState(newState, newError)

            log.debug "Server Monitor: ${stateManager.state.currentState} / ${up}"
        }
        catch(Throwable th)
        {
            log.warn "Exception while running serverMonitor: ${th.message}"
            log.debug("Exception while running serverMonitor (ignored)", th)
        }
    }
    
    private void checkDeployment()
    {
        // TODO: Implement via exceptions rather than return value (based on inputs from Spencer)
    }
}