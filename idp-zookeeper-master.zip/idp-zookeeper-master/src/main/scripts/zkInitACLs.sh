#!/bin/bash
# Initialise Zookeeper node ACL(s)
#
# e.g.: zkInitACLs.sh /Paul=digest:foo:VNy+Z9IdXrOUk9Rtia4fQS071t4=:rwdca,/Paul=ip:127.0.0.1:rwdca
#

ZOOBIN="${BASH_SOURCE-$0}"
ZOOBIN="$(dirname "${ZOOBIN}")"
ZOOBINDIR="$(cd "${ZOOBIN}"; pwd)"

if [ -e "$ZOOBIN/../libexec/zkEnv.sh" ]; then
  . "$ZOOBINDIR"/../libexec/zkEnv.sh
else
  . "$ZOOBINDIR"/zkEnv.sh
fi

echo $CLASSPATH

java -Duser.timezone=UTC -Dzookeeper.log.dir=${ZOO_LOG_DIR} -Dzookeeper.root.logger=${ZOO_LOG4J_PROP} -cp "$CLASSPATH" com.ubs.idp.zookeeper.utils.ZkInit $*