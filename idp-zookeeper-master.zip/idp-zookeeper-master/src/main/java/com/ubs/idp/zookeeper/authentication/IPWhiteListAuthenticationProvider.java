package com.ubs.idp.zookeeper.authentication;

import org.apache.zookeeper.KeeperException.Code;
import org.apache.zookeeper.data.Id;
import org.apache.zookeeper.server.ServerCnxn;
import org.apache.zookeeper.server.auth.AuthenticationProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.idp.auth.BaseWhiteListAuthenticator;

/**
 * Server "white list" authentication provider based on
 * similar white list rule created for Neo4J
 * Overrides built in "ip" scheme!
 * @author mcminnp
 */
public class IPWhiteListAuthenticationProvider extends BaseWhiteListAuthenticator implements AuthenticationProvider {
	
	private static Logger LOGGER = LoggerFactory.getLogger(IPWhiteListAuthenticationProvider.class);
	
	/**
	 * Constructor
	 */
	public IPWhiteListAuthenticationProvider() {
		super();
		LOGGER.info("White list initialised!");
	}

	/* (non-Javadoc)
	 * @see org.apache.zookeeper.server.auth.AuthenticationProvider#getScheme()
	 */
	@Override
	public String getScheme() {
		return "ip";
	}

	/* (non-Javadoc)
	 * @see org.apache.zookeeper.server.auth.AuthenticationProvider#handleAuthentication(org.apache.zookeeper.server.ServerCnxn, byte[])
	 */
	@Override
	public Code handleAuthentication(ServerCnxn cnxn, byte[] authData) {
		Code res = Code.AUTHFAILED;
		String ipAddr = cnxn.getRemoteSocketAddress().getAddress().getHostAddress();
		String hostName = cnxn.getRemoteSocketAddress().getAddress().getHostName();
		
		LOGGER.debug("Verify access for host {} (ip {})...", hostName, ipAddr);
		if (isAuthorized(hostName, ipAddr)) {
			LOGGER.debug("Access granted for host {} (ip {})...", hostName, ipAddr);
			
	        cnxn.addAuthInfo(new Id(getScheme(), ipAddr));
	        
	        res = Code.OK;
		} else {
			LOGGER.warn("Access denied for host {} (ip {})...", hostName, ipAddr);
		}
        return res;
        
	    //return Code.AUTHFAILED;
	}

	/* (non-Javadoc)
	 * @see org.apache.zookeeper.server.auth.AuthenticationProvider#matches(java.lang.String, java.lang.String)
	 */
	@Override
	public boolean matches(String id, String aclExpr) {
		LOGGER.debug("Check access for ID {}", id);
		
		if (aclExpr.equals("whitelist")) {
			return isAuthorized(id, id);
		} else {
			// Takes comma-separated list of ip address patterns
			return matches(id, aclExpr.split(","));
		}
	}

	/**
	 * Loop through IP expressions
	 * @param ipIn
	 * @param ipPatterns
	 * @return
	 */
	private boolean matches(String ipIn, String[] ipPatterns) {
		LOGGER.debug("Pattern matching '{}'...", ipIn);
		for (String ipPattern : ipPatterns) {
			 if (ipIn.matches(ipPattern)) {
				 LOGGER.debug("Pattern match of '{}' against pattern '{}' - access granted", ipIn, ipPattern);
				 return true;
			 }
		}
		// Fall through to no match
		LOGGER.warn("No match found for '{}' -  - access denied", ipIn);
		return false;
	}
	
	/* (non-Javadoc)
	 * @see org.apache.zookeeper.server.auth.AuthenticationProvider#isAuthenticated()
	 */
	@Override
	public boolean isAuthenticated() {
		return false;
	}

	/* (non-Javadoc)
	 * @see org.apache.zookeeper.server.auth.AuthenticationProvider#isValid(java.lang.String)
	 */
	@Override
	public boolean isValid(String id) {
		LOGGER.debug("Validating pattern '{}'...", id);
		
		if (id.equals("whitelist") || id.split("\\.", 4).length == 4)
			return true;
		else
			return false;
	}
}
