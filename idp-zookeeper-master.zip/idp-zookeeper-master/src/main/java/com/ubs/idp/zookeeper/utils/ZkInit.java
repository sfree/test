package com.ubs.idp.zookeeper.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.zookeeper.*;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooKeeper.States;
import org.apache.zookeeper.data.ACL;
import org.apache.zookeeper.data.Id;
import org.apache.zookeeper.data.Stat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Initialise Zookeeper node ACL(s)
 * @author mcminnp
 */
public class ZkInit implements Watcher {

    private static Logger LOGGER = LoggerFactory.getLogger(ZkInit.class);

	private ZooKeeper zk = null;
	private static final String ZK_CONNECT = "127.0.0.1:2181";
	private static final int CONNECTION_RETRY_LIMIT = 10;
	private int timeout = 10000;
	private int errorCount = 0;

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		validateArguments(args);
		String zkConnect = ZK_CONNECT;
		if (System.getProperty("zkConnect") != null) {
			zkConnect = System.getProperty("zkConnect");
		}
		// Connect
		ZkInit zkInit = new ZkInit();
		try {
			zkInit.connect(zkConnect);
			if (args[1].equals(Action.create.name())) {
				zkInit.processACLs(args[0]);
				LOGGER.info("Processing complete - " + zkInit.getErrorCount() + " errors");
			} else if (args[1].equals(Action.delete.name())) {
				zkInit.delete(args[0]);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				zkInit.disconnect();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private static void validateArguments(String args[]) {

		if (args.length != 2) {
			LOGGER.error("Missing ACL list or ACL action?");
			System.exit(1);
		}
		if (args[1].equals("")) {
			LOGGER.error("Blank action {} provided for ACL {}.", args[1], args[0]);
			System.exit(1);
		} else if (!(args[1].equals(Action.create.name()) || args[1].equals(Action.delete.name()))) {
			LOGGER.error("Invalid action {} provided for ACL {}.", args[1], args[0]);
			System.exit(1);
		}
	}

	/**
	 * Parse ACL list of the form:
	 * <path to node>=<ACL entry>
	 * e.g.: 
	 *    /xd=digest:foo:VNy+Z9IdXrOUk9Rtia4fQS071t4=:rwdca,ip:127.0.0.1:rwdca
	 * @param aclListIn
	 */
	public void processACLs(String aclListIn) {
		String[] aclList = aclListIn.split(",");

		Map<String, List<ACL>> aclMap = parseACLList(aclList);

		// Apply ACLs

		if (getErrorCount() > 0) {
		    LOGGER.info("{} errors when parsing input command - aborting", getErrorCount());
			System.exit(1);
		}

		applyAclMap(aclMap);
	}

	/**
	 * Return number of errors
	 * @return
	 */
	private int getErrorCount() {
		return errorCount;
	}

	/**
	 * Apply ACL changes
	 * @param aclMap
	 */
	public void applyAclMap(Map<String, List<ACL>> aclMap) {
		for (String path : aclMap.keySet()) {
			List<ACL> aclList = aclMap.get(path);

			LOGGER.info("Applying ACLs to path '{}'...", path);
			try {
				Stat status = zk.exists(path, false);

				if (status == null) {
					zk.create(path, "".getBytes(), aclList, CreateMode.PERSISTENT);
				} else {
					zk.setACL(path, aclList, -1);
				}
			} catch (Exception e) {
				e.printStackTrace();
				errorCount++;
			}
		}
	}

	/**
	 * Parse entries into ACL map
	 * @param aclListIn
	 */
	public Map<String, List<ACL>> parseACLList(String[] aclListIn) {
		Map<String, List<ACL>> aclMap = new HashMap<>();

		for (String aclEntry : aclListIn) {
			parseACLEntry(aclMap, aclEntry);
		}

		return aclMap;
	}

	/**
	 * Parse individual entry into ACL map 
	 * @param aclMap
	 * @param aclEntry
	 */
	public void parseACLEntry(Map<String, List<ACL>> aclMap, String aclEntry) {
		String[] pathACLPair = aclEntry.split("=", 2);

		if (pathACLPair.length != 2) {
		    LOGGER.error("Failed to process entry '{}' - syntax error!", aclEntry);
			errorCount++;
			return;
		}

		// Scheme is first part up to first ':'
		int firstColon = pathACLPair[1].indexOf(":");
		// Perms are the last part after the last ':'
		int lastColon = pathACLPair[1].lastIndexOf(":");

		if (lastColon <= firstColon) {
		    LOGGER.error("Failed to process entry '{}' - syntax error!", aclEntry);
			errorCount++;
			return;
		}

		String strPath = pathACLPair[0];
		String strScheme =  pathACLPair[1].substring(0, firstColon);
		String strPerms = pathACLPair[1].substring(lastColon+1);
		String strId = pathACLPair[1].substring(firstColon+1, lastColon);

		// Parse perms

		int perms = getPermFromString(strPerms);
		LOGGER.info("ACL entry details '{}' ACL to:", strPath);
		LOGGER.info("\tScheme: {}", strScheme);
		LOGGER.info("\t    Id: {}", strId);
		LOGGER.info("\t Perms: {} ({})", strPerms, perms);

		// Create and store ACL
		Id id = new Id(strScheme, strId);
		ACL acl = new ACL(perms, id);
		List<ACL> aclList;

		// Fetch current ACL for specified path

		if (aclMap.containsKey(strPath)) {
			aclList = aclMap.get(strPath);
		} else {
			aclList = new ArrayList<ACL>();

			aclMap.put(strPath, aclList);
		}
		// Add to ACL list
		aclList.add(acl);
	}

	public void delete(String path) {

		try {
			Stat nodeStatus = zk.exists(path, false);
			if(nodeStatus != null) {
				LOGGER.info("Deleting Node {} in Zoo Keeper: ", path);
				zk.addAuthInfo("digest", "foo:bar".getBytes());
				ZKUtil.deleteRecursive(zk, path);
				LOGGER.info("Deleted Node {} in Zoo Keeper: ", path);
			} else {
				LOGGER.info("Node {} does not exist in Zoo Keeper: ", path);
			}
		} catch (InterruptedException e) {
			LOGGER.error("Error while deleting Node " + path + " in Zoo keeper: " + e.getMessage(), e);
		} catch (KeeperException e) {
			LOGGER.error("Error while deleting Node " + path + " in Zoo keeper: " + e.getMessage(), e);
		}
	}

	/**
	 * Parse perms string
	 * @param permString
	 * @return
	 */
	private int getPermFromString(String permString) {
		int perm = 0;
		for (int i = 0; i < permString.length(); i++) {
			switch (permString.charAt(i)) {
			case 'r':
				perm |= ZooDefs.Perms.READ;
				break;
			case 'w':
				perm |= ZooDefs.Perms.WRITE;
				break;
			case 'c':
				perm |= ZooDefs.Perms.CREATE;
				break;
			case 'd':
				perm |= ZooDefs.Perms.DELETE;
				break;
			case 'a':
				perm |= ZooDefs.Perms.ADMIN;
				break;
			default:
			    LOGGER.error("Unknown perm type: {}", permString.charAt(i));
				errorCount++;
			}
		}
		return perm;
	}

	/**
	 * Blocking connect
	 * @param zkConnect
	 * @return
	 * @throws Exception
	 */
	public ZooKeeper connect(String zkConnect) throws Exception {
		zk = new ZooKeeper(zkConnect, timeout, this);
		int retry = 0;

		// Wait for connection
		while (!zk.getState().equals(States.CONNECTED) && retry < CONNECTION_RETRY_LIMIT) {
			Thread.sleep(10);
			retry++;
		}
		return zk;
	}

	/**
	 * Close open client
	 * @throws InterruptedException
	 */
	private void disconnect() throws InterruptedException {
		if (zk != null) {
			zk.close();
		}
	}

	/* (non-Javadoc)
	 * @see org.apache.zookeeper.Watcher#process(org.apache.zookeeper.WatchedEvent)
	 */
	@Override
	public void process(WatchedEvent event) {
		if (event.getState().compareTo(KeeperState.SyncConnected) == 0) {
			// TODO: We are now connected
		}
	}

	enum Action {
		create, delete
	}
}
