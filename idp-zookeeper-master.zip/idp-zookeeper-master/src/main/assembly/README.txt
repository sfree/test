This distribution is a modification by the IDP team of zookeeper 3.4.6

Contains
- zookeeper 3.4.6 (http://zookeeper.apache.org/)
