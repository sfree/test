package com.ubs.idp.zookeeper.authentication;

import static org.junit.Assert.*;

import org.junit.Test;

public class IPWhiteListAuthenticationProviderTest {

	private static final String WHITELIST = "whitelist";
	private static final String LOCALHOST = "127.0.0.1";

	@Test
	public void schemeTest() {
		IPWhiteListAuthenticationProvider authProvider = new IPWhiteListAuthenticationProvider();
		
		assertEquals("Unexpected scheme?", "ip", authProvider.getScheme());
	}

	@Test
	public void isAuthenticatedTest() {
		IPWhiteListAuthenticationProvider authProvider = new IPWhiteListAuthenticationProvider();
		
		assertFalse("Unexpected isAuthenticated response?", authProvider.isAuthenticated());
	}

	@Test
	public void isValidIPTest() {
		IPWhiteListAuthenticationProvider authProvider = new IPWhiteListAuthenticationProvider();
		
		assertTrue("Unexpected isValid response?", authProvider.isValid(LOCALHOST));
	}

	@Test
	public void isValidDuffIPTest() {
		IPWhiteListAuthenticationProvider authProvider = new IPWhiteListAuthenticationProvider();
		
		assertFalse("Unexpected isValid response?", authProvider.isValid("127.0.1"));
	}

	@Test
	public void isValidWhitelistTest() {
		IPWhiteListAuthenticationProvider authProvider = new IPWhiteListAuthenticationProvider();
		
		assertTrue("Unexpected isValid response?", authProvider.isValid(WHITELIST));
	}

	@Test
	public void isValidDuffWhitelistTest() {
		IPWhiteListAuthenticationProvider authProvider = new IPWhiteListAuthenticationProvider();
		
		assertFalse("Unexpected isValid response?", authProvider.isValid(WHITELIST+"zz"));
	}
	
	@Test public void matchesValidWhitelistTest() {
		IPWhiteListAuthenticationProvider authProvider = new IPWhiteListAuthenticationProvider();
		
		assertTrue("Unexpected matches response?", authProvider.matches(LOCALHOST, WHITELIST));
	}
	
	@Test public void matchesValidACLEntryTest() {
		IPWhiteListAuthenticationProvider authProvider = new IPWhiteListAuthenticationProvider();
		
		assertTrue("Unexpected matches response?", authProvider.matches(LOCALHOST, "127\\.0\\.0\\..*$"));
	}
	
	@Test public void matchesInvalidACLEntryTest() {
		IPWhiteListAuthenticationProvider authProvider = new IPWhiteListAuthenticationProvider();
		
		assertFalse("Unexpected matches response?", authProvider.matches(LOCALHOST, "192\\.168\\..*$"));
	}
}
