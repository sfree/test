package com.ubs.idp.zookeeper.utils;

import static org.junit.Assert.fail;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.Code;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.ZooKeeper.States;
import org.apache.zookeeper.data.ACL;
import org.apache.zookeeper.data.Id;
import org.apache.zookeeper.server.ServerCnxnFactory;
import org.apache.zookeeper.server.ZooKeeperServer;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZkInitTest {
	
	private static Logger logger = LoggerFactory.getLogger(ZkInitTest.class);
	
	private static ZooKeeperServer embeddedZookeeper = null;
	private static String zkConnect = null;
	
	@BeforeClass
	public static void startEmbeddedZookeeper() throws Exception {

		try {
			logger.info("Start embedded Zookeeper instance...");
			
			ServerCnxnFactory connectionFactory = ServerCnxnFactory.createFactory(0, 10);
	
			File dir = new File("target");			
			
			int tickTime = 2000;
			
			embeddedZookeeper = new ZooKeeperServer(dir, dir, tickTime);
			
			connectionFactory.startup(embeddedZookeeper);
			
			zkConnect = "127.0.0.1:" + connectionFactory.getLocalPort();
			
			logger.info("Started embedded Zookeeper instance - connect string: {}.", zkConnect);
			
		} catch (Throwable t) {
			logger.error("Failed to launch embedded Zookeeper instance!?", t);
			throw t;
		}
	}
	
	@AfterClass
	public static void stopEmbeddedZookeeper() {
		logger.info("Stop embedded Zookeeper instance...");
		
		embeddedZookeeper.shutdown();
		
		while(embeddedZookeeper.isRunning()) {
			logger.info("Waiting for embedded Zookeeper instance to stop...");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		logger.info("Stopped embedded Zookeeper instance");
	}

	@Test
	public void testNoLockDown() throws Exception {
		ZkInit zkInit = new ZkInit();
		
		logger.debug("Connect to embedded Zookeeper on {}...", zkConnect);
		
		ZooKeeper zk = zkInit.connect(zkConnect);
		
		List<ACL> aclList = new ArrayList<>();
		
		Id id = new Id("world", "anyone");
		ACL world = new ACL(ZooDefs.Perms.ALL, id);
		
		aclList.add(world);
		
		String path = "/testNoLockDown";
		
		// Pre-delete
		
		if (zk.exists(path, false) != null) {
			zk.delete(path, -1);
		}
		
		zk.create(path, "".getBytes(), aclList, CreateMode.EPHEMERAL);
		
		zk.getChildren(path, false);
		
		zk.close();
		
		logger.debug("Done");
	}

	@Test
	public void testACLsNoAuth() {
		KeeperException noAuthEx = null;
		
		ZkInit zkInit = new ZkInit();
		
		logger.debug("Connect to embedded Zookeeper on {}...", zkConnect);

		ZooKeeper zk = null;
		
		try {
			zk = zkInit.connect(zkConnect);

			List<ACL> aclList = new ArrayList<>();
			
			Id id = new Id("world", "anyone");
			ACL world = new ACL(ZooDefs.Perms.ALL, id);
			
			aclList.add(world);
			
			String path = "/testACLsNoAuth";
			
			// Pre-delete
			
			if (zk.exists(path, false) != null) {
				zk.delete(path, -1);
			}
			
			zk.create(path, "".getBytes(), aclList, CreateMode.PERSISTENT);
			
			// Apply ACLs
			
			String lockDownACL = path + "=digest:foo:VNy+Z9IdXrOUk9Rtia4fQS071t4=:rwdca";
			
			zkInit.processACLs(lockDownACL);
	
			// Close and open fresh session
			
			zk.close();
			
			zk = zkInit.connect(zkConnect);
			
			List<String> children = zk.getChildren(path, false);
			
			fail("Should not get here!");
		} catch(KeeperException ke) {
			logger.info("Got keeper exception!");
			
			assertEquals(ke.code(), Code.NOAUTH);
			
			noAuthEx = ke;
		} catch(Exception ex) {
			logger.error("Error closing Zookeeper connection?", ex);
			fail("Error processing ACLs?" + ex.getMessage());
		} finally {
			if (zk != null && zk.getState().equals(States.CONNECTED)) {
				try {
					zk.close();
				} catch (InterruptedException e) {
					logger.error("Error closing Zookeeper connection?", e);
					fail("Error closing Zookeeper connection: " + e.getMessage());
				}
			}
		}
		
		assertNotNull("Failed to get NOAUTH exception?", noAuthEx);
		
		logger.debug("Done");
	}

	@Test
	public void testACLsWithAuth() {
		ZkInit zkInit = new ZkInit();
		
		logger.debug("Connect to embedded Zookeeper on {}...", zkConnect);

		ZooKeeper zk = null;
		
		try {
			zk = zkInit.connect(zkConnect);

			List<ACL> aclList = new ArrayList<>();
			
			Id id = new Id("world", "anyone");
			ACL world = new ACL(ZooDefs.Perms.ALL, id);
			
			aclList.add(world);
			
			String path = "/testACLsWithAuth";
			
			// Pre-delete
			
			if (zk.exists(path, false) != null) {
				zk.delete(path, -1);
			}
			
			zk.create(path, "".getBytes(), aclList, CreateMode.PERSISTENT);
			
			// Apply ACLs
			
			String lockDownACL = path + "=digest:foo:VNy+Z9IdXrOUk9Rtia4fQS071t4=:rwdca";
			
			zkInit.processACLs(lockDownACL);
	
			// Close and open fresh session
			
			zk.close();
			
			zk = zkInit.connect(zkConnect);
			
			// Add auth
			
			zk.addAuthInfo("digest", "foo:bar".getBytes());
			
			List<String> children = zk.getChildren(path, false);

			assertNotNull("Failed to get children?", children);
		} catch(Exception ex) {
			logger.error("Error closing Zookeeper connection?", ex);
			fail("Error processing ACLs?" + ex.getMessage());
		} finally {
			if (zk != null && zk.getState().equals(States.CONNECTED)) {
				try {
					zk.close();
				} catch (InterruptedException e) {
					logger.error("Error closing Zookeeper connection?", e);
					fail("Error closing Zookeeper connection: " + e.getMessage());
				}
			}
		}
		
		logger.debug("Done");
	}

	@Test
	public void should_delete_existing_ACL() {
		ZkInit zkInit = new ZkInit();
		logger.debug("Connect to embedded Zookeeper on {}...", zkConnect);
		ZooKeeper zk = null;
		try {
			zk = zkInit.connect(zkConnect);
			String path = "/test";
			if (zk.exists(path, false) != null) {
				zk.delete(path, -1);
			}
			String lockDownACL = path + "=digest:foo:VNy+Z9IdXrOUk9Rtia4fQS071t4=:rwdca";
			zkInit.processACLs(lockDownACL);
			zk.close();
			zk = zkInit.connect(zkConnect);
			if (zk.exists(path, false) != null) {
				zkInit.delete(path);
			} else {
				fail("There should not be ACL");
			}
			if (zk.exists(path, false) != null) {
				fail("Should have deleted the ACL");
			}
		} catch (Exception e) {
			logger.error("Error closing Zookeeper connection?", e);
		}
	}
}
