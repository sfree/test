package com.ubs.swift.demo;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.apache.log4j.Logger;

/**
 * Simple demo application used for swift. This is not intended to reflect production quality code. Ignore the ugliness
 * of the constructing of the html, this demo is kept as free as possible of other frameworks and focuses simply on what
 * swift can do.
 * <p>
 * History:
 * <ul>
 * <li>1.0.0 - This version has a couple of issues. After 2 minutes of healthy execution, tomcat fails. After another 5
 * minutes the process exits.
 * <li>1.0.1 - This version has no issues and remains running
 * <li>1.0.2 - Demo extended to highlight properties support
 * </ul>
 */
public class SwiftDemoServer {
    private static final Logger LOG = Logger.getLogger(SwiftDemoServer.class);

    static ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
    static Tomcat tomcat;

    private static Properties p;

    public static void main(final String[] args) throws Exception {
        try {
            loadConfiguration();

            configureTomcat();

            tomcat.start();
        } catch (Exception ex) {
            LOG.error("Startup failed", ex);
            throw ex;
        }
        tomcat.getServer().await();
        LOG.info("Tomcat has died");
    }

    private static void loadConfiguration() throws IOException {
        LOG.info("Loading properties");
        p = new Properties();
        p.load(SwiftDemoServer.class.getResourceAsStream("/swift-demo-server.properties"));
    }

    private static void configureTomcat() {
        tomcat = new Tomcat();
        tomcat.setPort(8090);

        Context ctx = tomcat.addContext("/", new File(".").getAbsolutePath());

        Tomcat.addServlet(ctx, "hello", new HttpServlet() {
            @Override
            protected void service(final HttpServletRequest req, final HttpServletResponse resp)
                    throws ServletException, IOException {
                LOG.info("Received client request");

                Writer w = resp.getWriter();
                w.write("<html><body>");
                w.write("<h1>Awesome! You're running the swift demo app 1.0.3. Hello Sydney</h1>");

                w.write("<h3>Properties configured for this process</h3><table border='1'><tr><th>Key</th><th>Value</th></tr>");
                for (Entry<Object, Object> property : p.entrySet()) {
                    w.write("<tr><td>" + property.getKey() + "</td><td>" + property.getValue() + "</td></tr>");
                }
                w.write("</table></body></html>");

                w.flush();
            }
        });
        ctx.addServletMapping("/*", "hello");
    }

}
