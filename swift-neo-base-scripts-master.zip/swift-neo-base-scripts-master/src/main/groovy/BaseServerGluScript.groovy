import java.util.HashMap.Entry
import org.linkedin.glu.agent.api.ShellExecException



/**
 * Common server monitoring and startup management. 
 */
abstract class BaseServerGluScript extends BaseNeoScript {
    def startPort

    def baseServerInstall = {
        // validate the required params before attempting to install.
        startPort = params.startPort

        if (startPort == null || startPort == "") shell.fail("startPort must be provided")

        baseInstall()
    }

    def configure = { baseConfigure('60s') }

    def start = {
        // This has been put in place as if an lcds adaptor is already running, attempting to start it again will time out after 9999 port checks have completed.
        // Better and more correct to fail immediately.  If the correct version of the server is already running, the monitoring will switch the status
        // over to running.
        if (isRunning()) {
            log.info "Aborting start as server is already running"
            shell.fail("Server is already running.")
        }

        String startCommand = buildCommand(getStartCommand())
        log.info "start command [${startCommand}]"

        // this starts the service, but only provides a small amount of confidence that the process actually
        // started successfully.
        shell.exec(startCommand)

        def startTimeout = params.startTimeout ?: getStartTimeout()
        // Now that the process appears to be up, check a port to verify this is the case
        shell.waitFor(timeout: startTimeout, heartbeat: '5s') { duration ->
            log.info "${duration}: Waiting for server to be up"

            // we check if the server is down already... in which case we throw an exception
            // as the server will never
            if(!isRunning())
                shell.fail("Server could not start. Check the log file for errors.")

            return isServerListening()
        }

        log.info "Startup completed [${startCommand}]"
    }

    /**
     * Modifies the command to export any required environment variables.
     */
    protected String buildCommand(String command) {
        String fullCommand = ""
        // EXPORT any environment variables.
        String envVariables = params.envVaribles
        if (envVariables != null && envVariables != '') {
            String[] vars = envVariables.split(';')
            vars.each() { fullCommand += 'export ' + it + '; ' }
        }

        fullCommand += command

        return fullCommand
    }

    protected boolean isServerListening()
    {
        def host = shell.env["glu.agent.hostname"]
        def port = params.startPort

        boolean listening = shell.listening(host, port)

        log.info "server is listening on ${host}:${port} = ${listening}"

        return listening
    }

    /**
     * Defines the timer that will check for the server to be up and running and will act
     * according if not (change state)
     */
    def processMonitor = {
        try
        {
            def linkedVersion = getDeployedArtifactVersion()
            def isRunning = isRunning()
            def isListening = isServerListening()
            def up = isRunning && isListening

            def currentState = stateManager.state.currentState
            def currentError = stateManager.state.error

            def newState = null
            def newError = null

            // Server down takes precedence over a link to the wrong version.
            if (up && !projectVersion.equals(linkedVersion)) {
                newError = "Linked version is ${linkedVersion}"
            }

            // case when current state is running
            if(currentState == 'running')
            {
                if(!up)
                {
                    newState = 'stopped'

                    if(isRunning)
                    {
                        newError = "Server is running but not listening on port ${startPort}."
                    }
                    else if(isListening)
                    {
                        newError = "Server is not running but something else is listening on port ${startPort}."
                    }
                    else
                    {
                        newError = 'Server down detected. Check the log file for errors.'
                    }
                    log.warn "${newError} => forcing new state ${newState}"
                }
            }
            else
            {
                if(up)
                {
                    newState = 'running'
                    log.info "Server has come back up."
                }
            }

            // if the server is stopped and has an error set, do not reset that error.  If the error is reset
            // it will appear like the process was stopped by a user through the normal flow rather than crashed.

            if (newState ||  // We have a new state
               (currentState == 'running' && currentError && !newError) || // We have a current error which needs to be reset
               (newError && !newError.equals(currentError))) // We have a new error that differs to the current error
            {
                log.info "State change: ${newState} / ${newError}"
                // if newState is null, it leaves the state engine in the current state.
                stateManager.forceChangeState(newState, newError)
            }

            log.debug "Server Monitor: ${stateManager.state.currentState} / ${up}"
        }
        catch(Throwable th)
        {
            log.warn "Exception while running processMonitor: ${th.message}"
            log.debug("Exception while running processMonitor (ignored)", th)
        }
    }

    /**
     * Returns if the server process is currently running.
     */
    protected abstract boolean isRunning()

    /**
     * Returns the start command.
     */
    protected abstract String getStartCommand()

    /**
     * Returns the default timeout to allow the process to start
     */
    protected abstract String getStartTimeout()


    /**
     *@param from: is the file path of the template file, not content
     *@param to : is the file path of the destination file we write to , not content
     *@param tokens: key is the token we want to replace , and value is what we will replace with
     */
    protected void replaceTokens(String from,String to,Map<String,String> tokens) throws ShellExecException{
        
        def template = rootShell.readContent(rootShell.toResource(new File(from)))

        for(Entry entry:tokens.entrySet()){
            def token = entry.key
            def value = entry.value
            template = template.replaceAll('\\$\\{__' + token + '__\\}', value)
        }

        rootShell.saveContent(rootShell.toResource(new File(to)),template)
    }

}
