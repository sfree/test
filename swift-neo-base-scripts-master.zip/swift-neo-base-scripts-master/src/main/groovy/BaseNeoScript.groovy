import org.linkedin.glu.agent.api.ShellExecException

/**
 * This is a glu script for installing and linking neo artifacts.  Basic monitoring is provided.  If
 * the artifact installation directory disappears or is linked to another version, this will be flagged as
 * an error.
 * <p>
 * Required configuration:
 * <pre>
 *     "initParameters": {
 *       "project": {              // the nexus artifact details
 *         "a": "core-server-entitlements",
 *         "g": "com.ubs.f35.core",
 *         "v": "3.1.2-SNAPSHOT"
 *       }
 *     }
 * </pre>
 * <p>
 * The script makes use of an environment variable 'f35.shared.install'. In dev environments where installations are shared, 
 * certain operations behave differently.
 */
abstract class BaseNeoScript {
    def version = '4.5.0'
    def group
    def artifact
    def projectVersion
    def baseInstallDir
    def sharedInstall
    // The script requires that the fabric is named correctly.
    def env
    def scriptDir
    
    def baseInstall = {
        group = params.project.g
        artifact = params.project.a
        projectVersion = params.project.v

        env = shell.env["f35.scripts.env"]
        if (!env) {
            env = shell.env["glu.agent.fabric"]
        }
        scriptDir = shell.env["f35.scripts.dir"]
        baseInstallDir = shell.env["f35.install.dir"]
        sharedInstall = ("true".equals(shell.env["f35.shared.install"]))

        // -l flag = create a no-version-number symlink for .swf
        def deployCommand = "${scriptDir}/envget ${group} ${artifact} ${projectVersion} -l"
        log.info "deploy command [${deployCommand}]"

        shell.exec(deployCommand)

        def linkCommand = "${scriptDir}/envlink ${group} ${artifact} ${projectVersion} ${env}"
        log.info "link command [${linkCommand}]"

        shell.exec(linkCommand)

    }

    def baseConfigure = { defaultMonitor ->
        log.info "Configuring..."

        // setting up a timer to monitor the server.
        // Always pass a reference to the monitor as a String.  otherwise the agent attempts to find the
        // timer property, invoking other methods at the same time.
        // See http://glu.977617.n3.nabble.com/Adding-a-server-monitor-causes-function-to-be-invoked-td4025417.html
        timers.schedule(timer: "processMonitor",
                repeatFrequency: params.serverMonitorFrequency ?: defaultMonitor)

        log.info "Configuration complete."
    }

    def unconfigure = {
        timers.cancel(timer: "processMonitor")
    }

    /**
     * The artifact installation can be removed if this is the last mountpoint using this artifact deployed.  For shared install
     * environments, the uninstall will never be completed as the installation may be in use on another host.  Note the shared install
     * check is delayed so that the execution path for dev and other environments is as close as possible.
     */
    def uninstall = {
        log.info "Uninstall called"

        String anotherInstallation = null
        String anotherInstallationSameVersion = null
        String currentMountPoint = mountPoint.toString()

        // ensure only one child removed at a time.
        synchronized (parent.children) {

            parent.children.each() {
                String otherMountPoint = it.mountPoint.toString()
                if (!currentMountPoint.equals(otherMountPoint)) {
                    log.debug("Checking if ${currentMountPoint} and ${otherMountPoint} use the same installation")

                    if (getScriptProperty(it, 'group') == group &&
                        getScriptProperty(it, 'artifact') == artifact) {

                        log.info("Artifact symlink is still used by ${it}")
                        anotherInstallation = otherMountPoint;

                        if (getScriptProperty(it, 'projectVersion') == projectVersion) {
                            log.info("Artifact is still used by ${it}")
                            anotherInstallationSameVersion = otherMountPoint
                        }
                    }
                }
            }

            String symlink = "${baseInstallDir}/${group}/${artifact}/${env}"
            if (anotherInstallation) {
                log.info("Not removing artifact symlink as still in use by ${anotherInstallation}")
            } else if (sharedInstall) {
                log.info("Artifact symlink is no longer in use. Symlink NOT removed as shared install: ${symlink}")
            } else {
                log.info("Artifact is no longer in use and symlink can be removed: ${symlink}")
                shell.exec("rm '${symlink}'")
            }

            String dir = "${baseInstallDir}/${group}/${artifact}/${projectVersion}"
            if (anotherInstallationSameVersion) {
                log.info("Not removing artifact deployment as still in use by ${anotherInstallationSameVersion}")
            } else if (sharedInstall) {
                log.info("Artifact version is no longer in use. Directory NOT removed as shared install: ${dir}")
            } else {
                log.info("Artifact version is no longer in use and install dir be removed: ${dir}")
                shell.exec("rm -rf '${dir}'")
            }

        }

        log.info "Uninstall completed"
    }

    protected Object getScriptProperty(scriptNode, property) {
         if (scriptNode.getScriptState().script.hasProperty(property)) {
             return scriptNode.getScriptState().script.getProperty(property)
         }
         return null
    }

    /**
     * Returns the currently linked artifact version.  Returns null if no link exists.
     * @return
     */
    protected String getDeployedArtifactVersion()
    {
        def checkLink = "readlink ${baseInstallDir}/${group}/${artifact}/${env}"

        log.info "checking artifact version linked with command [${checkLink}]"

        try {
            def output = shell.exec(checkLink)
            return output.substring(output.lastIndexOf('/') + 1)
        } catch (ShellExecException e) {
            log.warn("Exception trying to determine running version", e)
        }

        return null
    }

}