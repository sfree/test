var staticRoot = process.env["staticRoot"] || __dirname + "/www-template"
  , staticRootMin = process.env["staticRootMin"] || __dirname + "/www-min"

var fs = require("fs")
  , path = require("path")

serve(staticRoot)

function serve(root) {
  var port = process.env["port"] || process.env["p"]
    , options = {
      ssl: process.env["ssl"] || true,
      staticRoot: root,
      resourcesRoot: "resource.json"
    }

  require("serve")(options).listen(port)
}