swift-client-build
==================


This is the swift application.

It can be used as a dave runnable by adding the folowing line to you project.json :

```
  "scripts": {
     "server": "github:NeoSwift/swift-client-build"
   }
```

# Packaging

Packaging requires nodejs 0.10.x (or newer).  This version is not available in iops so must be downloaded and installed with part.

To build a standalone application package which can be run on any other server.

`npm install && npm run-script package`

After running, to package the created folders for deployment execute `cd .. && tar --exclude='swift-client-build/node_modules' -zcvf swift-client-build.tar.gz swift-client-build`

If you receive an error `npm ERR! 404 'dave-nexus-resolver' is not in the npm registry.` please follow the instructions on https://github.ldn.swissbank.com/pages/DevOps/manual/node/index.html to register the UBS NPM Registry.

# Cache busting
For each release, you will need to manually update the references to the release version number in package.json and www-template/index.html.

Swift aggressively caches as users in locations outside London would be affected by the time it took to hit the webserver to check if the resources had been updated since the last access time.  This is very frequent for users that often open links in new tabs, resulting in swift reinitialising.

Note that when moving away from dave to npm / grunt build processes, the updating of these version numbers should be automated as part of the build.
