package com.ubs.idp.stubs.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DummyRowMapper implements RowMapper<String>
{
	// Default to tab as it's a pain to inject!
	private String delimiter = "\t";
	private boolean trim = false;
	private String[] sourceFields;
	
	@Override
	public String mapRow(ResultSet result, int arg1) throws SQLException
	{
		StringBuilder buffer = null;
		String temp =  null;
				
		temp = null;
		buffer = new StringBuilder();

		if (sourceFields != null && sourceFields.length > 0) {
	        for(int idx = 0; idx < sourceFields.length; idx++){
	            String fieldName = sourceFields[idx];
	            temp = getFieldValue(result, fieldName);
	            temp = (temp != null) ? temp + delimiter : delimiter;
	            buffer.append(temp);
	        }
		} else {
		    for(int idx = 1; idx <= result.getMetaData().getColumnCount() ; idx++) {
                temp = getFieldValue(result, idx);
                temp = (temp != null) ? temp + delimiter : delimiter;
                buffer.append(temp);
		    }
		}
		buffer.deleteCharAt(buffer.length()-1);
		return buffer.toString();
	}
	
	/**
	 * Get and optionally trim result set value by position
	 * @param result
	 * @param idx
	 * @return
	 * @throws SQLException
	 */
	private String getFieldValue(ResultSet result, int idx) throws SQLException {
	    String value = result.getString(idx);
	    
	    if (value != null && trim) {
	        value = value.trim();
	    }
	    
	    return value;
	}

    /**
     * Get and optionally trim result set value by field name
     * @param result
     * @param fieldName
     * @return
     * @throws SQLException
     */
    private String getFieldValue(ResultSet result, String fieldName) throws SQLException {
        String value = result.getString(fieldName);
        
        if (value != null && trim) {
            value = value.trim();
        }
        
        return value;
    }

	/**
	 * @return
	 */
	public String getDelimiter() {
		return delimiter;
	}

	/**
	 * @param delimiter
	 */
	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

    /**
     * @return the trim
     */
    public boolean isTrim() {
        return trim;
    }

    /**
     * @param trim the trim to set
     */
    public void setTrim(boolean trim) {
        this.trim = trim;
    }

    /**
     * @return the sourceFields
     */
    public String[] getSourceFields() {
        return sourceFields;
    }

    /**
     * @param sourceFields the sourceFields to set
     */
    public void setSourceFields(String[] sourceFields) {
        this.sourceFields = sourceFields;
    }

}