package com.ubs.idp.stubs.jdbc;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.connectors.spring.batch.readers.JDBCSourceReader;

/**
 * Test class that tests the JDBC stub using the JDBC readers in
 * the connectors package
 * @author loverids
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(value = "classpath:test-context.xml")
public class JDBCStubTest
{
	private static Logger logger = LoggerFactory.getLogger(JDBCStubTest.class);
	public final static String TEST_FILE = "src/main/resources/AccountsAndRXM.MF.csv";

	
	@Autowired	
	private JDBCSourceReader reader;
	
	@Test
	public void testJDBCReaderWithStub() throws UnexpectedInputException, ParseException, NonTransientResourceException, Exception
	{
		assertNotNull( reader);
		ExecutionContext executionContext = new ExecutionContext();
		reader.open(executionContext);
		
		// Open up the test file and read off the header
		try(BufferedReader br = new BufferedReader( new InputStreamReader(new FileInputStream(TEST_FILE)));)
		{
			br.readLine();		
			
			// Read all the rows in and ensure they match the test file we're
			// reading from in the mock
			Object row;
			while((row = reader.read())!=null)
			{		
				String testFileRow = br.readLine();
				assertEquals("Row returned does not match row in file",testFileRow,row.toString());
			}
			
			// Make sure we dont have any more lines in the file (i.e. the rows returned
			// matches the number of lines in the file
			assertNull("Did not expect any more lines in the file",br.readLine());
			
		}
	}
}
