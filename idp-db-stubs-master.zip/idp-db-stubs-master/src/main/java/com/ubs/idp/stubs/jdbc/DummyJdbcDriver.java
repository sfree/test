package com.ubs.idp.stubs.jdbc;

import java.io.*;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.io.IOUtils;
import org.springframework.util.CollectionUtils;


/**
 * Our mock driver for database connections.
 * 
 * To use the mock we simply specify this as the main driveClass for
 * the database Connection. All other databae properties (url,username,password)
 * are ignored.
 * 
 * @author loverids
 *
 */
public final class DummyJdbcDriver implements Driver {
	
	private final static Logger logger = LoggerFactory.getLogger(DummyJdbcDriver.class);
	private final static String PROPERTIES_FILE = "database-map.properties";
	private final static String DATABASE_PROP_PREFIX = "database.query.";
	private final static String RESULT_FILES_DIR = "data-files";
	private final static String CSV_SUFFIX = ".csv";
	
	private static Map<String, Set<File>> queryResources = Collections.synchronizedMap(new HashMap<String, Set<File>>());

	static {
		try {
			// Register this with the DriverManager
			DriverManager.registerDriver(new DummyJdbcDriver());
		} catch (SQLException e) {
			throw new RuntimeException("Unable to register DummyJdbcDriver", e);
		}
	}
	
	public DummyJdbcDriver() {
		initResultSets();
	}
	
	/**
	 * Dynamically add a results file for a specified query. This allows us to use
	 * this library within unit tests of other components without having to rely
	 * on the predefined query result map and data files embedded within this artifact.
	 * @param query
	 * @param resultFile
	 */
	public static void addResultsFileToQueryMap(String query, File resultFile)
	{
		Set<File> fileSet = new HashSet<File>();
		fileSet.add(resultFile);
		queryResources.put(query, fileSet);
	}

	/**
	 * Initialises the query resources to pass back the results
	 * file for a specified incoming query based on the values
	 * in the database-map.properties
	 */
	private static void initResultSets() {

		//initialise once
		if (CollectionUtils.isEmpty(queryResources)) {
			try {
				// Load in the data set to query map properties
				Properties prop = new Properties();
				ClassLoader cl = DummyJdbcDriver.class.getClassLoader();
				InputStream dataMapInputStream = cl.getResourceAsStream(PROPERTIES_FILE);
				prop.load(dataMapInputStream);
				// Add them to the table resources
				for (Object key : prop.keySet()) {
					if (key.toString().startsWith(DATABASE_PROP_PREFIX)) {
						String datasetName = key.toString().substring(DATABASE_PROP_PREFIX.length());
						Object query = prop.get(key);
					   /* REVIEW
						* While loading properties and data files with Spring ClassPathResource, came across
						* issue, when this project is added as dependency in other projects,
						* '!' is getting appended in the path after jar extension (*.jar!/data-files) and results in
						* file not found exception.
						* The test under this module works in IDE because it load files from file location not from jar.
						*/
//						ClassPathResource resultResource = new ClassPathResource( RESULT_FILES_DIR + File.separator + datasetName + CSV_SUFFIX);
//	                 	File resultFile = new File(cl.getResource(pathName).getFile());
						String pathName = datasetName + CSV_SUFFIX;
						dataMapInputStream = cl.getResourceAsStream(pathName);
						final File resultFile = File.createTempFile(datasetName, CSV_SUFFIX);
						resultFile.deleteOnExit();
						FileOutputStream out = new FileOutputStream(resultFile);
						IOUtils.copy(dataMapInputStream, out);
						if (resultFile == null || !resultFile.exists()) {
							throw new RuntimeException("Failed to find result set file for datset " + datasetName + " dataMapInputStream " + RESULT_FILES_DIR);
						}
						// Add the file to the map
						if (queryResources.get(query.toString()) != null) {
							Set<File> fileList = queryResources.get(query.toString());
							if (!isFileAlreadyAdded(datasetName, fileList)) {
								fileList.add(resultFile);
							}
						} else if (queryResources.get(query.toString()) == null) {
							TreeSet<File> files = new TreeSet<>();
							files.add(resultFile);
							queryResources.put(query.toString(), files);
						}
					}
				}
			} catch (IOException e) {
				String message = "Error occured trying to load stub database test properties: " + e;
				logger.error(message, e);
				throw new RuntimeException(message, e);
			} catch (Exception e) {
				logger.error("Unexpected error while loading the data file properties", e);
				throw new RuntimeException("Unexpected error while loading the data file properties", e);
			}
			logger.info("Loaded data mapping properties", queryResources);
		}
	}
    private static boolean isFileAlreadyAdded(String pathName, Set<File> fileList) {
        for (File file : fileList) {
            if (file.getName().startsWith(pathName)) {
                return true;
            }
        }
        return false;
    }

    @Override
	public int getMajorVersion() {
		return 1;
	}

	@Override
	public int getMinorVersion() {
		return 0;
	}

	@Override
	public boolean jdbcCompliant() {
		return false;
	}

	@Override
	public boolean acceptsURL(String url) throws SQLException {
		return true;
	}

	@Override
	public Connection connect(String url, Properties info) throws SQLException {
		return new DummyConnection(queryResources);
	}

	@Override
	public DriverPropertyInfo[] getPropertyInfo(final String url, final Properties props) throws SQLException {
		return new DriverPropertyInfo[0];
	}

	@Override
	public java.util.logging.Logger getParentLogger() throws SQLFeatureNotSupportedException
	{
		return null;
	}
}