package com.ubs.idp.stubs.jdbc;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.*;

import au.com.bytecode.opencsv.CSVReader;

/**
 * Statement implementation to execute queries.
 * 
 * Incoming queries are matched against our map of queries to files and if it
 * finds a match, the corresponding file is opened and returned as a result set
 * 
 * @author loverids
 * 
 */
public final class CsvStatement implements Statement {

    protected int noOfResultSets = 0;
	protected final Map<String, Set<File>> queryToFileMap;

	public final static char DELIMITER = '\t';

	/**
	 * @param queryResources A map of sqlQueries that correspond to files to be 
	 * read
	 */
	public CsvStatement(Map<String, Set<File>> queryResources) {

		this.queryToFileMap = queryResources;
	}

	@Override
	public ResultSet executeQuery(String sql) throws SQLException {

        Set<File> files = queryToFileMap.get(sql.replaceAll("\n", " "));
        List<File> fileList = new ArrayList<>(files);//asSortedList(files);
        File resource = fileList.get(noOfResultSets);
        // Check that we have a map
		if (resource == null) {
			String message = "The incoming query does not match any of the expected SQL queries defined in the 'database-map.properties' in the idp-stubs project. The query has either been modified in the metadata and no longer matches, or the there is no definition. The following is a list of defined queries compared to the incoming query:\n";
			Set<String> queries = queryToFileMap.keySet();
			for (String query : queries) {
				message += "[\n";
				message += "\t>> Incoming: " + sql + "\n";
				message += "\t>> Defined : " + query + "\n";
				message += "]\n";
			}
			throw new RuntimeException(message);
		}
		// Maps table columns to a number of available values.
		Collection<LinkedHashMap<String, String>> entries = new ArrayList<>();
		CSVReader dummyTableReader = null;
		try (FileInputStream fis = new FileInputStream(resource)) {
			dummyTableReader = new CSVReader(new InputStreamReader(fis), DELIMITER);
			// Read header
			String[] header = dummyTableReader.readNext();
			if (header != null) {
				String[] data;
				// Read data
				while ((data = dummyTableReader.readNext()) != null) {
					if (header.length == data.length) {
						LinkedHashMap<String, String> map = new LinkedHashMap<>();
						for (int i = 0; i < header.length; i++) {
							if (map.containsKey(header[i].trim().toUpperCase())) {
								String message = MessageFormat.format("Duplicate column in file ''{0}.txt: {1}", resource.getAbsolutePath(), header[i]);
								throw new RuntimeException(message);
							}
							//REVIEW: why we need to convert to upper case?
							//map.put(header[i].trim().toUpperCase(), data[i].trim());
                            map.put(header[i].trim(), data[i].trim());

						}
						entries.add(map);
					} else {
						throw new IllegalArgumentException("Number of data attributes not equal to number of Header attributes");
					}
				}
			}
            noOfResultSets++;
			return new CSVResultSet(resource.getName(), entries);
		}
		catch (IOException e) {
			throw new RuntimeException("Failed when processing execute command:" + e, e);
		}
		finally {
			if (dummyTableReader != null) {
				try {
					dummyTableReader.close();
				} catch (IOException e) {
					throw new RuntimeException("Failed to close table reader:" + e, e);
				}
			}
		}
	}

	@Override
	public <T> T unwrap(Class<T> iface) throws SQLException
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isWrapperFor(Class<?> iface) throws SQLException
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int executeUpdate(String sql) throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void close() throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public int getMaxFieldSize() throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setMaxFieldSize(int max) throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public int getMaxRows() throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setMaxRows(int max) throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void setEscapeProcessing(boolean enable) throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public int getQueryTimeout() throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setQueryTimeout(int seconds) throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void cancel() throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public SQLWarning getWarnings() throws SQLException
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void clearWarnings() throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void setCursorName(String name) throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public boolean execute(String sql) throws SQLException
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ResultSet getResultSet() throws SQLException
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getUpdateCount() throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean getMoreResults() throws SQLException
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setFetchDirection(int direction) throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public int getFetchDirection() throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setFetchSize(int rows) throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public int getFetchSize() throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getResultSetConcurrency() throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getResultSetType() throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void addBatch(String sql) throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void clearBatch() throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public int[] executeBatch() throws SQLException
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Connection getConnection() throws SQLException
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean getMoreResults(int current) throws SQLException
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ResultSet getGeneratedKeys() throws SQLException
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int executeUpdate(String sql, int[] columnIndexes) throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int executeUpdate(String sql, String[] columnNames) throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean execute(String sql, int autoGeneratedKeys) throws SQLException
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean execute(String sql, int[] columnIndexes) throws SQLException
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean execute(String sql, String[] columnNames) throws SQLException
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getResultSetHoldability() throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isClosed() throws SQLException
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setPoolable(boolean poolable) throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isPoolable() throws SQLException
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void closeOnCompletion() throws SQLException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isCloseOnCompletion() throws SQLException
	{
		// TODO Auto-generated method stub
		return false;
	}

    public static <T extends Comparable<? super T>> List<T> asSortedList(Collection<T> c) {
        List<T> list = new ArrayList<T>(c);
        java.util.Collections.sort(list);
        return list;
    }
}