idp-stubs
=========

A collection of end point stubs to be used for testing JDBC endpoints
