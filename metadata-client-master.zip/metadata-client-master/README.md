# Metadata Client

This project contains the Spring Data Neo4j implementation of the meta model. This supercedes the now deprecated [idp-metadata-store](https://github.ldn.swissbank.com/idp/idp-metadata-store) and [idp-metadata-service](https://github.ldn.swissbank.com/idp/idp-metadata-service)

The meta data model is defined using Spring Data entities with specific Neo4j annotations. This allows us to constrain the model so that only certain nodes and relationships can be created unlike how it currently is where the domain model knowledge is embedded within the code. 

# Configuration

To use the ```metadata-client``` API within your application you need to add the following:

1. Add the metadata-client as a dependency to your pom:

	<dependency>
		<groupId>com.ubs.idp</groupId>
		<artifactId>metadata-client</artifactId>
		<version>1.0.X</version>
	</dependency>

2. Within your Spring configuration add a component scan for the packages ```com.ubs.idp.metadata.config.neo4j``` and ```com.ubs.idp.metadata.service.neo4j```:

## Spring Java Configuration

	@ComponentScan({"com.ubs.idp.metadata.config.neo4j","com.ubs.idp.metadata.service.neo4j"})

## Spring XML Configuration

	<context:component-scan base-package="com.ubs.idp.metadata.config.neo4j,com.ubs.idp.metadata.service.neo4j"/> 

3. Specify two mandatory properties ```neo4j.mode``` and ```neo4j.dbPath``` or ```neo4j.dbUrl``` depending on the value for the mode:

	neo4j.mode		Either "embedded" or "remote"
	neo4j.dbPath		If "embedded" mode is specified then this is the full path to the Neo4j DB instance
	neo4j.dbUrl		If "remote" mode is specified then this is the URL to the running remote Neo4j server

4. Add the MetadataService bean via autowiring within your application code:

	@Autowired
	MetadataService metadataService;

# Configuration with Property Decoration

Within the metadata there are property placeholders for environment specific values (e.g. URLs for a source endpoint). The metadata service can replace these property placeholders with concrete values that have been loaded in from the properties store for a specific environment. To run the metadata service with the property placeholder replacement, configure as follows:

## Spring Java Configuration

1. Only component scan the configuration package.

	@ComponentScan({"com.ubs.idp.metadata.config.neo4j")

2. Define an explicit concrete metadata service bean, the utils bean and the metadata service decorator bean. (Note the "${environment}" value can be loaded in from your application properties. Currently this expects a ${environment}.properties file of the same name to exist on the classpath. This will eventually be replaced with a Zookeeper implementation that will lookup the properties for the specified ${environment}):

	@Bean(name = "concreteMetadataService")
	public MetadataService concreteMetadataService()
	{
		return new Neo4jMetadataServiceImpl();
	}

	@Bean(name = "neo4jUtils")
	public Neo4jUtils neo4jUtils()
	{
		return new Neo4jUtils();
	}

	@Bean(name = "metadataService")
	public MetadataServicePropertiesDecorator metadataService()
	{
		return new MetadataServiceZookeeperDecorator(concreteMetadataService(),"${environment}");
	}

## Spring XML Configuration

	<context:component-scan base-package="com.ubs.idp.metadata.config.neo4j"/> 

	<bean id="neo4jutils" class="com.ubs.idp.metadata.service.neo4j.Neo4jUtils"/>

	<bean id="concreteMetadataService" class="com.ubs.idp.metadata.service.neo4j.Neo4jMetadataServiceImpl" />

	<bean id="metadataService" class="com.ubs.idp.metadata.service.properties.MetadataServiceZookeeperDecorator" >
		<constructor-arg name="metadataService" ref="concreteMetadataService"/>
		<constructor-arg name="environment" value="${environment}"/>
	</bean>

3. The autowiring in your application code remains the same:

	@Autowired
	MetadataService metadataService;