package test.com.ubs.idp.metadata.model;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.client.properties.MetadataServicePropertiesDecorator;
import com.ubs.idp.metadata.model.JDBCChannel;
import com.ubs.idp.metadata.repositories.PhysicalAttributeRepository;
import com.ubs.idp.metadata.repositories.PhysicalDatasetRepository;

public class MetadataServiceZookeeperTest extends MetadataServiceTest {
    public final static String CLEAR_DB_CYPHER = "START n = node(*) OPTIONAL MATCH n-[r]-() WHERE (ID(n)>0 AND ID(n)<10000) DELETE n, r";

    @Autowired
    @Qualifier("neo4jMetadataService")
    private MetadataService concreteMds;

    @Autowired
    @Qualifier("mdsClient")
    private MetadataServicePropertiesDecorator decorator;

    @Autowired
    private GraphDatabaseService graphDatabaseService;

    @Autowired
    private PhysicalDatasetRepository physicalDatasetRepo;

    @Autowired
    private PhysicalAttributeRepository physicalAttributeRepo;

    @Autowired
    private Environment env;

    @Test
    @Override
    public void testGetDatabaseDetailsForDataset() {
        String driver = "testDriver";
        String url = "jdbc://testHost:testPort/db";
        String username = "testUser";
        String password = "testPass";

        JDBCChannel channel = decorator.getDatabaseDetailsForDataset("Equity.RDDH");

        assertEquals("Database driver not as expected", driver, channel.driverClass);
        assertEquals("Database url not as expected", url, channel.url);
        // assertEquals("Database username not as expected",username,channel.username);
        assertEquals("Database password not as expected", password, channel.password);
    }

    @Test
    @Override
    public void testGetSourceUrlsForAllDatasets() {
        Object[] equityExpected = Arrays
                .asList("http://www.equity:testPort.com?fields=cb64:eJxzLSzNLKnUC3Jx8dDLLC4uTQWS_mmBpYk5QGEdVyTZkhy90qRizxR0wbTMouKSkKLElFSXxJJUAIxAHNA",
                        "http://www.equity:testPort.com/delta").toArray();
        Object[] indexExpected = Arrays.asList("http://www.index:testPort.com").toArray();

        Map<String, List<String>> received = decorator.getSourceUrlsForAllDatasets();

        List<String> receivedList = received.get("Equity.RDDH");
        doObjectListComparison(receivedList, equityExpected, "Equity URLs");

        receivedList = received.get("Index.RDDH");
        doObjectListComparison(receivedList, indexExpected, "Index URLs");
    }

    @Test
    @Override
    public void testGetSourceUrlsForDataset() {
        Object[] expected = Arrays
                .asList("http://www.equity:testPort.com?fields=cb64:eJxzLSzNLKnUC3Jx8dDLLC4uTQWS_mmBpYk5QGEdVyTZkhy90qRizxR0wbTMouKSkKLElFSXxJJUAIxAHNA",
                        "http://www.equity:testPort.com/delta", "jdbc://testHost:testPort/db").toArray();
        List<String> receivedList = decorator.getSourceUrlsForDataset("Equity.RDDH");

        doObjectListComparison(receivedList, expected, "Dataset URLs");
    }

    @Test
    @Override
    public void testGetSourceAutheintcationUriForDataset() {
        String expected = "http://www.equity.com:testPort";
        String received = decorator.getSourceAuthenticationUriForDataset("Equity.RDDH");

        assertEquals("Dataset Authentication URi", expected, received);
    }

    @Test
    @Override
    public void testGetUrlForChannel() {
        String expected = "http://www.equity:testPort.com?fields=cb64:eJxzLSzNLKnUC3Jx8dDLLC4uTQWS_mmBpYk5QGEdVyTZkhy90qRizxR0wbTMouKSkKLElFSXxJJUAIxAHNA";
        String received = decorator.getUrlForChannel("EQUTITY.CHANNEL.HTTP.INBOUND");

        assertEquals("Channel URL incorrect", expected, received);
    }
}
