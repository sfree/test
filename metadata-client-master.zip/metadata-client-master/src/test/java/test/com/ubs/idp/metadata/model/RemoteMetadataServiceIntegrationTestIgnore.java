package test.com.ubs.idp.metadata.model;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.model.JDBCChannel;
import com.ubs.idp.metadata.model.JoinRelation;
import com.ubs.idp.metadata.model.PhysicalDataset;

@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
@PropertySource("classpath:integrationTest.properties")
@ContextConfiguration(classes = RemoteMetadataServiceIntegrationTestIgnore.class)
@Configuration
@ComponentScan({ "com.ubs.idp.metadata" })
public class RemoteMetadataServiceIntegrationTestIgnore {
    
    @Autowired
    @Qualifier("neo4jMetadataService")
    private MetadataService mds;

    @Test
    public void testGetSQLQueryForDataset() {
        String expected = "select tgl.cconsol,tgc.cclientclass,tgl.factive,tcl.cvalue,tgc.crxm,tr.creventity,tgl.dvalidfrom,tgl.dvalidto from tgloballocation tgl inner join tconsol tc on tc.cconsol = tgl.cconsol and tc.cconsoltype = 3 inner join tglobalclient tgc on tgc.cconsol = tc.cprconsol and tgc.nversion = 0 left outer join tclassification tcl on tcl.cconsol = tgc.cconsol and tcl.nversion = 0 and tcl.cclasstype = 39 left outer join treporting tr on tr.cconsol = tgl.cconsol and tr.nversion = 0 where tgl.nversion = 0 and tgc.cclientclass not in ('A','B','C','PC','V')";
        String received = mds.getSQLQueryForDataset("AccountsAndRXM.MF");
        assertEquals("Query not as expected", expected, received);
    }

    @Test
    public final void testGetAttributeNamesDataset() throws Exception {
        // Dataset
        List<String> expectedList = Arrays.asList("GLcconsol", "Class", "Factive", "CPType", "RXM", "ReverseEntity");
        List<String> outputList = mds.getAttributeNamesForDataset("GLCCONSOL");
        doObjectListComparisonNoSort(outputList, expectedList.toArray(), "Dataset Atrributes");
    }

    @Test
    public void testGetAttributeNamesForView() {
        // View
        Object[] expectedList = Arrays.asList("issue.assetClass", "issue.assetType", "issue.cusip", "issue.isin", "issue.nominalCurrency",
                "issue.issueName", "issue.ubsId", "issuer.cconsol", "issuer.ubsPartyId", "tL.countryUbsId", "tL.sedol", "isoCode",
                "description", "currencyOffset", "domain", "issue.bbTicker", "tL.bbTicker", "issuer.countryOfIncorporation",
                "issue.ubsIsoCfi", "coupon.couponType", "issue.issueDate", "issue.nominalValueOfUnit", "issue.issueSize",
                "issuer.countryOfDomicile", "issue.ubsUniqueDescription", "issue.bondIssuerType", "issue.series", "bond.maturityDate",
                "bond.minimumTradeSize", "issuer.countryOfRisk", "tL.ticker", "issue.collateralType", "bond.stripType",
                "bond.callOptionType", "coupon.currentCouponRate", "derived.isin", "derived.cusip", "derived.sedol",
                "derived.bondIssuerType", "derived.issueFactor", "derived.valueFactor", "derived.issueSize", "derived.minDenomination",
                "derived.currentCouponRate", "derived.assetClass", "derived.PrimaryListing", "derived.assetType", "derived.couponType",
                "derived.FIAssetType", "derived.Fitch_event.lastUpdatedTime", "derived.Moodys_event.lastUpdatedTime",
                "derived.SandP_event.lastUpdatedTime", "derived.Fitch_issueRating.lastUpdatedTime",
                "derived.Moodys_issueRating.lastUpdatedTime", "derived.SandP_issueRating.lastUpdatedTime", "issueRating.isProvisional",
                "derived.Fitch_issueRating.code", "derived.Moodys_issueRating.code", "derived.SandP_issueRating.code",
                "derived.Fitch_issueRating.rawCode", "derived.Moodys_issueRating.rawCode", "derived.SandP_issueRating.rawCode",
                "issueRating.structuredFinanceInd", "issueRating.endorsementInd", "issueRating.recordType",
                "derived.Fitch_issueRating.validDate", "derived.Moodys_issueRating.validDate", "derived.SandP_issueRating.validDate",
                "derived.Fitch_issueRating.ratingGroup", "derived.Moodys_issueRating.ratingGroup", "derived.SandP_issueRating.ratingGroup",
                "issueRating.ratingType", "issueRating.currencyType", "derived.Fitch_event.majorVersion",
                "derived.Moodys_event.majorVersion", "derived.SandP_event.majorVersion", "derived.issue.majorVersion",
                "derived.issue.active", "derived.issue.isoCfi", "derived.issue.assetClass", "derived.issue.assetType",
                "derived.issue.nominalCurrency", "derived.issue.ubsTradable", "derived.issue.ubsIsoCfi", "derived.issue.ubsId").toArray();
        List<String> outputList = mds.getAttributeNamesForDataset("InstrumentSecFunding");
        doObjectListComparisonNoSort(outputList, expectedList, "View Atrributes");
    }

    @Test
    public void testGetKeyAttributePositionsForDatasets() {
        Object[] expected = Arrays.asList(7).toArray();
        List<Integer> receivedList = mds.getDatasetKeyAttributePositions("INDEX");
        doObjectListComparisonNoSort(receivedList, expected, "Key Attribute Positions");
    }

    @Test
    public void testGetXpathsForDataset() {
        Object[] expected = Arrays.asList("/EquityInstrumentMsg/*:tL/@ubsId", "/EquityInstrumentMsg/*:tL/bbUnique",
                "/EquityInstrumentMsg/*:tL/pmSymbol", "/EquityInstrumentMsg/*:tL/active", "/EquityInstrumentMsg/*:tL/exchange",
                "/EquityInstrumentMsg/*:tL/currency", "/EquityInstrumentMsg/*:tL/sedol").toArray();
        List<String> receivedList = mds.getAttributeXpathsForPhysicalDataset("ORCAEQUITY");
        doObjectListComparisonNoSort(receivedList, expected, "Attribute Xpaths");
    }

    @Test
    public void testGetSourceAuthenticationUriForDataset() {
        String expected = "${RDDH_WS_HOST}";
        String received = mds.getSourceAuthenticationUriForDataset("EQUITY");
        assertEquals("Authentication URI not as expected", expected, received);
    }

    @Test
    public void testGetSourceAuthenticationUriForDatasetInvalid() {
        String expected = "";
        String received = mds.getSourceAuthenticationUriForDataset("DSCURRENCY");
        assertEquals("Authentication URI not as expected", expected, received);
    }

    @Test
    public final void testGetNamespacesForDataset() throws Exception {
        assertEquals(0, mds.getNamespacesForDataset("EQUITY").size());
        assertTrue(Arrays.asList("ns0", "ns1").containsAll(mds.getNamespacesForDataset("LEGALENTITY").keySet()));
        assertEquals("urn:lingua:legalentity", mds.getNamespacesForDataset("LEGALENTITY").get("ns0"));
        assertEquals("urn:lingua:partyshared", mds.getNamespacesForDataset("LEGALENTITY").get("ns1"));
    }

    @Test
    public void testGetDelimiter() {
        assertEquals("\t", mds.getDelimiter("EQUITY"));
        assertEquals(",", mds.getDelimiter("INSTPRICE"));
        assertEquals("\t", mds.getDelimiter("DSCURRENCY.IDP"));
        assertEquals("\t", mds.getDelimiter("CURRENCY"));
        assertEquals("\t", mds.getDelimiter("CURRENCY.IDP"));
        assertEquals("\t", mds.getDelimiter("EQUITY.IDP"));
        assertEquals("\t", mds.getDelimiter("BONDTL.IDP"));
        assertEquals("\t", mds.getDelimiter("EQUITY.TRANSFORMED"));
        assertEquals("\t", mds.getDelimiter("BONDTL.TRANSFORMED"));
        assertEquals("\t", mds.getDelimiter("Ultrabond.IDP"));
        assertEquals("\t", mds.getDelimiter("RATING.IDP"));
    }

    @Test
    public void testGetSourceDeltaUrlForDataset() throws Exception {
        String expected = "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=EQUITY&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx1V9tu2zgQ_aHAi6IF9jnrJEWAZJ3aTt8pamSzpkiFFzfar9_Dm0TL7ksinpE45JkzFwtrPa1E-PvAHN3Fp5U9MkN24511TLVCHf6EV98YL-nLt2_3X_nfz6rN4Fk7sm9kduHDO_eyGrRxnZZCvzJzEIo1kta6jSYhpfjwot05zU8BaJq17gdthaPHT35k6kB3DbMncqtWnIXVpiyV7zfdWivrhPOknL2z5JykVev4oxQHATfpRGblG_vGjFNkntsKw8KrVq6cfJ8X0VytmcW-a4l_ad2zX9r8JGOFVgmBzb0PLWhp96KnBDbNXvATmbSy1GpZCA08MtOCDdxjJ_4rbAq76X54JoUbAxXpOmsmKbw-RQNk_svgJd_25lus116561h22r4Z3Xruvhvth4wqcTqRiCHYj0M5jbOEmHrrzBijJWbVBP9_nZj6JZanukDTvjc26QwpftwbpizjDjzu2We4cSeMdYDbpMugD5yeMyfO8HneCh7l1ON5N_YNGMXSCHuSZHExobgYWASL6_PewHm8FdCefYbdgwDBs3KZ6Ap-0e6OIEg3IkzgYzcgGpXgQeB3fc5ySNCR2RcBEdYkIxy8uu9VOC53nKhFCIZ4_YwshZXQCwFmBzxQNOvL-XlTve5KQCopV0AVc0vcG1y-gppmdw1yb0VRD9d9Px1EWFEez0xqxDmvfpNxAxsEmYWrJ236amele1QIufYmaGQsdYagIMHBQ6C6YpYLZa_e2XRdRVeFqwrOjn4y6WnTvSvhCr2iE3CTqtIpgygWRSL1azFYWxom5q-TOr53f0bIhRz33ih9nji4aVtPt47mtGGN7ODlFF0sWErva1yX5BmvLMxT6l4RU0tiRhGZLVlihh8XNggP2aZD-G59tUMxurldoGvOkwvT2_0DofJdGeEKDaFHfb9oR2gvDxTbhDbjljiJwU1fHnZzMyodakZYO8T7gqxQWSbpOvY5daaEQAL8NH1lppZW6Hz10olBUo02DZjpkTKhjU0dbGEL_xa2zrE6Cqk5oTbxUDnM-F7WF8mP9bJEAMrFIHSQVAnw5HCTKMr43PbhP5UTBDdFKmFL7cqrTYPE-PBps9jC8PDhtYvElbLqUqMLTyEf1unI6fv9ZDOpehfosfIuNUfK55FgLjjxK2zWvswnAjEpI15Z3pdr6V5VugRYwjxgylYu6e1FqKT7uHvtWNiWbemQudRD7ihQ0FGvmbuPNHmjFX26C8s_ybOyGGsS-Ueo8qhlG4QWvnJw5Mio1I-wfFbz8veR1HMIdPsk2SGeZNDlMYT0ogn2qabQIabBwnHuPdltuEJ-xCRVBRXsbzocIRsHoU4_QhxDQatchFniJ6kU8VhPnryKo1SS39DPjTeRJwOf0ziXoK0ztoZTYTrV-5d4RFMIKspWKrqT-7aXr4rQW5JwEMzPfHrMD_QkNXNISZ45CaqkSigKfYXJqhwH3sqUFJgyLZmt9oG8rU8s5GTbdEET0FEqD3EwEdu5IOVTMB9XO8we-TX35WtiYTMESyEX5TiOMPiO4pyDElSyeTkQa86vp2TUYIVjXgzVqZgwM14kkhKpioTDIEFCP4kUmBopukr1LSUVzpPnnmVFyfBF4clYmMhbMDoJbYFP513gsXAssCcD4OYmbIwHXsAo-gjhLcsDcQmnN22PnzWKpIvLPEpfXDFjSzamqZt9oO9j6s25l3Ee-la1jhNtkn3tKex6jQ6uf6HzeD9g6ORRPNkQShCXUEG1M2p7Pyw97wL44N1YG4roy8-jafY0twdMc2PCNGl6MPP4YOZseVYIBbiouimsqUiVZfpdx9Q47ceb8sugglD60dFrANq8xgac7QJFEWnmzl2d7QFjHhfy2rDFz4bFz8MxJMEZ9WQh9ggtqPofpq7cOw&event.lastUpdatedTime=${START},${END}&event.lastUpdatedTime.relation=between";
        String received = mds.getSourceDeltaUrlForDataset("EQUITY").toString();
        assertEquals(expected, received);
        // assertEquals(null, mds.getSourceDeltaUrlForDataset("BookFull"));
    }

    @Test
    @Ignore
    // TODO: How are we fetching the attribute names for a view?
    public void testGetAttributeNamesForDataset() throws Exception {
        // Dataset
        List<String> expectedList = Arrays.asList("GLcconsol", "Class", "Factive", "CPType", "RXM", "ReverseEntity");
        List<String> outputList = mds.getAttributeNamesForDataset("GLCCONSOL");
        doObjectListComparison(outputList, expectedList.toArray(), "Attributes");

        // View
        expectedList = Arrays.asList("issue.assetClass", "issue.assetType", "issue.cusip", "issue.isin", "issue.nominalCurrency",
                "issue.issueName", "issue.ubsId", "issuer.cconsol", "issuer.ubsPartyId", "tL.countryUbsId", "tL.sedol", "isoCode",
                "description", "currencyOffset", "domain");
        outputList = mds.getAttributeNamesForDataset("InstrumentSecFunding");
        Set<String> uniqueList = new HashSet<String>(outputList);

        doObjectListComparison(new ArrayList<String>(uniqueList), expectedList.toArray(), "Attributes");
    }

    @Test
    public void testGetAttributePositionsForDataset() throws Exception {
        // Invalid
        assertTrue(mds.getAttributePositionsForDataset("EQUITY").get("xyz") == null);

        // Valid
        assertTrue(mds.getAttributePositionsForDataset("EQUITY").get("issue.issueName") == 77);
    }

    @Test
    public void testGetSourceUrlsForDataset() {
        // Explicit fields
        assertTrue(mds
                .getSourceUrlsForDataset("INDEXCOMPOSITION")
                .get(0)
                .toString()
                .endsWith(
                        "&rddh.requesttype=TEXT&fields=issue.assetClass,"
                                + "perm.source,issue.lastUpdatedTime,tL.ubsId,issue.isoCfi,indexComps.majorVersion,"
                                + "issue.isin,tL.isdaRegion,tL.isdaRelRtrsExchCode,issue.bbSecurityType,tL.exchange,"
                                + "issue.status,tL.bbUnique,issue.ubsId,indexComps.lastUpdatedTime,tL.pmSymbol,"
                                + "tL.majorVersion,tL.currency,perm.result,tL.isdaRelExchCode,tL.tradeCountry,tL.ric,"
                                + "tL.active,issue.majorVersion,issue.issueName,issue.active,tL.lastUpdatedTime,"
                                + "perm.value,tL.bbTicker,perm.type,tL.ticker,event.majorVersion,event.lastUpdatedTime,"
                                + "comp.lastUpdatedTime,comp.indexShareFactor,comp.numOfShares,comp.tLUbsId,"
                                + "comp.tLActive,comp.weighting,comp.majorVersion,comp.issueUbsId,comp.issueActive,"
                                + "comp.sedol,comp.ticker,comp.tLName,comp.issuerName,comp.issuerUbsId,comp.active,"
                                + "instrumentGroup.majorVersion,instrumentGroup.weightingOfficialInd,"
                                + "instrumentGroup.divisor,instrumentGroup.complete,instrumentGroup.compositionEffectiveDate,"
                                + "instrumentGroup.lastUpdatedTime,instrumentGroup.divisorOfficialInd,"
                                + "instrumentGroup.totalShares,instrumentGroup.numOfConstituents," + "instrumentGroup.constituentsExchange"));
    }

    @Test
    public void testGetSourceUrlsForDataset_AddFields() throws Exception {
        // Add fields
        String source = "EQPRICING";
        String received = mds.getSourceUrlsForDataset(source).get(0).toString();
        assertTrue(received
                .endsWith("&rddh.requesttype=TEXT&fields=cb64:eJx9VVFv3CAM_kNTdeqpJ-Wx6jTtpKu0SWvfueD22OWSLJB0268fYLCBkD3F32f7szEBYJB3Uhj4BNYw3ctZH6W34Xd7Ef07OoTWYJ46-_HQGuZldGnyh7qF3ElIOPZStcIMk6d-zYNJKCF_ztrcoDdfRGuJOz12yrwO3XyD57kzykKohMHbG7RGLfDZ9blyS7UoCb38NqkWHr13o5SPSCvpq1-7X0MA4vssbOgfcnpjdJneaudpgr5FfzmHs5IsGAAJRqc3UNBZJOhAKdh2gwaWJEiiHBBMFEabpBGW4ouffCbHFLkX0c0ESolhhP7YG5hAG8zKmP-Go3CpwPOXy0OVALRKbU-ipjXvd2UuMtFZybYspvdgHt3__upQJpN79DBPbSW8pHBLco62Jqcrbe13sRCCuIh9dRH7Hc9gv5rBIdU6sNahqnVItA4rrSbValirqWo1iVaTa7k_gP-dMC1v1n4fPgwe0RyjL5cNHV7U-wVLeAtLeLMsQZGMqET0UQlPhBLd8IEVnIEFnFXqxzACpB48JO5w0L6J6WqvXzEqY31_hVFDmFjVg9WrrrKdTeVtLzW8lUsrqAaEJWkzjF9pVwhh6wTLdrOsnKG20hhqhcik_CnuWARc_FTZuTQlI7LKp2IXIxfqxkf1ia_tnMIecm712q5EKjR1tYqm3nJP6PAsYmPeCu-UqLRBkYz4LRNFLU_E4YMxHbjHOcyfcdgCJla7kOeWHO9FFsfbwTSf24f7D4CrpuMbMZ3iSFQOc5pbcunRTuLSEx7p5J7KukkJvrW2-inTV2R2ldVaSnns6R8ra9lz"));
    }

    @Test
    public void testGetSourceUrlsForDataset_EncodedFields() throws Exception {
        String source = "BONDISSUE";
        List<String> receivedList = mds.getSourceUrlsForDataset(source);
        assertEquals(8, receivedList.size());
        assertTrue(receivedList
                .get(0)
                .toString()
                .endsWith(
                        "&rddh.requesttype=TEXT&fields=cb64:eJyNWety46gSfqGpbJ2" + "qfQHHmUy5NplknWSr9ieClswYgQ4gx56n3-YigZAc-U9ivm6apmn"
                                + "6gjqi7eVOEGM_OkYssHfewrdeMnHXkl9K_wPacCW_cWN6uOPmDYh"
                                + "RElhgKedVSrI7R9lJBud7YkBwCQ9ID6SaSyKeie01t5cEt1zytm_"
                                + "fNWGwk1RDC9K-8d8LZI8asFbAXaehBq2Bvfmxm7RpQNJLUM6Kj8rs"
                                + "oqZe_2xMDArZov5moKttzcPvqnrn9Ah6oHAZfhlgSoyW-JDcepVYh"
                                + "Cw5k0rAVjGISK3Mlgg6RX6oU1w4biP8Q0aQjOjISFrVS_vSW2OJZF"
                                + "w23lrD2vj3J2nhjyORv3hEzUFpO0NrjQY5oJ7SEGrxJN_JeUGMJTi"
                                + "JjARLNP9GhN1JY3XvDLtjd8X4D3e4dJWLguXduqyDOoJcZQNmVnlUt"
                                + "c5TVS0ai7NVRtLjgJN1zY5Kww1sNbfr2pFq3fi_SEckGFjfKojmlg3U"
                                + "eNPWVaMHLqvjKltL6LpmlvAO1nfKiOTmcMOSel193ZBVHm7adaaWCH"
                                + "Ix_AbGszSwfksqTX5zsX5KLfCG6PVl3TnB-QazdQpD2uqVEta0t675-"
                                + "4aDv8FvO7yghvNq_bwkU_KWo-iUuMWRBLeH_oYLI4g93XKxKtkIhuuOC"
                                + "eBVK9ZT-0OrvgsJDtMq8lNMi8B-qjHOE9b5RMFrTonNs_DfPXKxjXkFT"
                                + "V_q1-tZI-Jlng7oQoJ3OeI00FGI7c24qE-QkS1lzwx4v3TjVKA-x2dQV"
                                + "b3NQdobzA7xt2rbbI98-HkiAoPrMPoEbTvScdDFUo9Kt5lkqVpXbGx7rX"
                                + "1JEFANLp5TtMMTZrksMVMuzYznpa4zc2W4zOC40D9E9PBSu6ogEvrKuPr"
                                + "A1QSjCf4FIdTnX3Apc3A-zlJ9WjO3dkJx03vMAkTTQ0HDM33VXDnLLM1"
                                + "6w3JjUZxTOTnOhPS6eQAi5kRcaotnh-6e78JXatkYtaFpW80blojDqBfw"
                                + "vz__3CSEm5f67x7XGpU_EONOLC2O1t3lLgnnjutLZrqxHhr9RPNxy1QJv"
                                + "L-giZg4rZwYDFPKEezO_c64iJR4yShMCrLHXjY8P-jc1x8AU50Y68SxvI"
                                + "xDjAB-DZ0tgmEi7RN96v_oFWCo5l0WB6oqUHaDZNa37WWbXSkP7NJVcoFG"
                                + "db5qHVdXx-wa9L5CjkHpgWNv4I8tQovl_iSKeMRgYU5Y_vveFaHOnB9Jf"
                                + "kHJt-fpnweQ3i7sUZBm0Al_28FFI4QanlClV4FFh3fCiN8j2yWuhX7aefN"
                                + "GWhC8sQ_cUBcyB_y5F5aPMSPur2xX0J7HiTBpeiywKdwTPNe4PYoxyqIH"
                                + "Gx-5M3aMy-SRty0jRXAfpSHDm9BhXBF53AZR2VY6F1TucRgwlH-AfS9fr"
                                + "E4LDeA76HaKbEKQD_Ir16GkWXnLMgDzhDVpY4Ic9DqsR80DuWyVPOExjF"
                                + "uqhSL2laABLzMgWziBGHYxmwT4wkGwZ7AHxTLArzIem4f2OHZe8bNvF1A"
                                + "flhP8qAHvDR7xlHuEE3vn3H8me4ImZsxgXQTnKywR09SQuTfsFzYcuRNv"
                                + "iTmgaT6Rcn9xiT5wU6oxPO4xcGYAsJ20CcPL3mEEfVKywTqBKxaPirWZ0M"
                                + "lyeBU6JTdeldmel4hJ_6EmeZH_OkvGKV3kn54XJUJs8ig6ot_rGrxzTuE"
                                + "8dVgDeENcW3bxThrUwkLC3VnM6G60d7MjAUtS51Zuk9Pk4PrNtLDz2OSM"
                                + "DnrpiotrXLDQYF2rHqmJG8s21DHYOZmsICRzMagJhpqF_XYH7h9Pyls0v"
                                + "qr4lDaEEjj7umMTslTuSnkRuAynNbnZNA3mZAQ2VyZfpWcRHatXaLtYed"
                                + "BhP71dtE2BZzeut6XphxA8R6ahGj0eQ7O7YP0QGl1WUZ-TJ6f47DLJWxEr"
                                + "E1yEa66NDY9MuQSGUd9ms-nwhDOMB-UmDz3ZM9WwqqJH1dtkoCU8FZZ6uZz"
                                + "XC_W8DqWXTmWQvvP5TmOQ3UmqNLZZWWuBVIrN1PDKpV16wLBF5GWUR6vh-m"
                                + "UQVjtW6RzAQmKOdajbBK05q1L1ken2gEU15WJO2HNzHEBc49U9X6L_xcteG"
                                + "mYIDv6f956I1Hl4LjFv6ghiPsZDbHqBxxohnUWXGHfH-DbMQgkc43PG6X1o"
                                + "E-L2Q4mHsJXDHUiMD3M8_BvdfqpGHrOXKfnWnLFeNdssb6HWcg81P7tcNTF"
                                + "SgnNhiD-6nXjiZH9aYvgdXzcLMddwH-ky8JnohsupHgErlHiCE1b1Tb78E6"
                                + "8xZHcF8iiUGpftsO4AQUZ7wvmBnzhD1dKlvEIq1nfdWMjBJTY_m5KUiwr_n"
                                + "pW0h--S5a4rRIcyhow-0ypnTWim0Y-eYLFqYR7tSrp7BrbZWSYKSlzENbZV"
                                + "fCg30k6vMGT7TRwhTc3gfokXa-zNMjtSFqXX7tSvzPE0PwvLO0l5R8R1Wy2"
                                + "wJHMtEAeLLZDijhco_RVl0r6Xidc2ke_-Gvna3LH-CAn_Kw6fbbrwYQlbvG"
                                + "ci8ULqiFD1NMMwkEcxSjvZA_hSCd5MIZc57T02RSOIff0Jy4hBltWYnGBYvx"
                                + "nEfnPFSXiqceludp4FGSaFWUGcDv2FKzja0LCU8-I9X5qBzfCJq974Zv0KbY"
                                + "z6V-jhZENr-zVPXt9dYcTM6kvLa_RnLtMHuRUe903P87mvLg0e_Mz8I8G6Rv"
                                + "oQnsRKMH8iGGk1cQWFP6YR-wTeHOzm1IT8uUBwGWAJVkSihy1Q9tASLoc6Mj"
                                + "Gw-AkSOy9w72GJgkbAtPLWAR5GAXoHKLBnLINEAl3hNT5RheeijPZsG9hOn7B"
                                + "GqsTkoJQwc1nh260785GU3sGmFhzrrbRKvmciMLjf-y9G2SrudTDogoFrfBSZ"
                                + "n_WEyt0v0NtYdy4RXaalrkmdErEV04qCceXuUKV8zeFj2xcsroDxTxC21HKJb"
                                + "f812xO5RVjkWpH10T1qLAVWuPbuzRHjcrPC516E4lV9hJJx8nJfnEYVX4IWaN"
                                + "1ViiXn72fXFxZ4_NRAXZ_rW5bQ9fk0EnLMjDQvWAqGAFj3Ent_mZNV6iuvTDV"
                                + "X6f59ObRKM5p_DlqC1Ym7MYkvGDMOL_ArXcrW-UbWWPssWDbEku9nepjT0Sm2" + "IxbLBHCPENPOMkDFWfwHu8VsRA"));
    }

    @Test
    public void testGetRolesForDataset() throws Exception {
        assertEquals(Arrays.asList("IDP_QS_PUBLIC"), mds.getRolesForDataset("EQUITY"));
        assertEquals(Arrays.asList("IDP_QS_PUBLIC"), mds.getRolesForDataset("sapphire"));
    }

    @Test
    public void testGetAttributeNamesForPhysicalDataset() throws Exception {
        List<String> expected = Arrays.asList("issue.issueDate", "issue.sharesOutstanding", "issue.sharesOutstandingDate",
                "issue.rule144A3c7Ind", "issue.votesPerShare", "tL.portfolioMarginableCode", "tL.illiquidStock", "tL.bbCompositeExchange",
                "basket.divisor", "basket.numOfConstituents", "settle.dtcEligible", "issuer.ubsPartnerId", "issuer.ubsId", "undl.tlUbsId",
                "undl.issueUbsId", "undl.assetClass", "undl.majorVersion", "undl.lastUpdatedTime", "undl.bbTicker", "undl.sedol",
                "issue.standardMarketSize", "issue.isOfQuality", "tL.settleCalendar", "issue.shortName", "settle.settleCalendar",
                "issue.amountOutstanding", "issue.fosProductGroup", "issue.nikkeiStockType", "issue.tseIndustryCode",
                "issue.issueName/kanji", "issue.shortName/kanji", "issue.nikkeiIndustryCode", "issue.frenchTransactionTax",
                "tL.firstTradeDate", "tL.indicativeNavRic", "tL.pmNavSymbol", "tL.risklessPrincipal", "tL.nikkeiInvTrustType",
                "tL.maxTradableQuantity", "tL.maxTradableLot", "equity.stockSplitDate", "issue.fosGovtClass", "issue.hasListing",
                "issue.fosCalcCode", "issue.amountOutstandingDate", "issue.fos", "issue.isStopTrade", "issue.lastUpdatedTime",
                "issue.majorVersion", "issue.active", "issue.status", "issue.isoCfi", "issue.assetClass", "issue.assetType",
                "issue.securityType", "issue.bbSecurityType", "issue.cusip", "issue.common", "issue.isin", "issue.valoren",
                "issue.wertpapier", "issue.securityFormType", "issue.nominalCurrency", "issue.restrictedListCode", "issue.cins",
                "issue.restrictedOffTime", "issue.restrictedOnTime", "issue.nominalValueOfUnit", "issue.mifidLiquidStk",
                "issue.ubsTradable", "issue.mifidTradeRep", "issue.stdMarketSize", "issue.mifidAvgDailyTurnover",
                "issue.mifidAvgDailyTurnoverCcy", "issue.mifidMarket", "issue.mifidStdMktSizeCurrency", "issue.mifidMostrelvMktCurrency",
                "issue.issueName", "issue.restrictedClass", "issue.restrictedForResearch", "issue.restrictionPriority",
                "issue.restrictedForSales", "issue.restrictedForTrading", "issue.restrictedForPADealing", "issue.restrictionComment",
                "issue.sharesPerDepositoryReceipt", "issue.regSInd", "issue.rule144AInd", "issue.adpClassification", "issue.taxableCode",
                "issue.quick", "issue.adrPerShare", "issue.isMultipleShare", "issue.bbPrimSecCompExchange", "issue.bbPrimSecPrimExchange",
                "issue.ftaClass", "issue.ubsId", "tL.countryUbsId", "tL.majorVersion", "tL.lastUpdatedTime", "tL.active", "tL.status",
                "tL.tickSize", "tL.tidm", "tL.exchange", "tL.currency", "tL.lotSize", "tL.bbUnique", "tL.sedol", "tL.quotationType",
                "tL.ticker", "tL.tradeCountry", "tL.bbTicker", "tL.ric", "tL.bbTickerExchange", "tL.localCode", "tL.bbSecurity",
                "tL.roundLotSize", "tL.ubsMarketMaker", "tL.coltMn", "tL.cubsInstrCode", "tL.tradingLineName", "tL.bbExchange",
                "tL.isdaRegion", "tL.opol", "tL.regShoCatA", "tL.euronext", "tL.regShoCatB", "tL.consolidatedThresholdInd",
                "tL.etbExternal", "tL.etbInternal", "tL.whenIssuedFlag", "tL.ipoFlag", "tL.lastTradeDate", "tL.marketSegment",
                "tL.consolidatedListingInd", "tL.opolInd", "tL.bbCurrency", "tL.ricOfIntInd", "tL.pinkQuotable", "tL.marketSettleVenue",
                "tL.mifidFungibleId", "tL.pmSymbol", "tL.isdaRelExchCode", "tL.isdaRelRtrsExchCode", "tL.mifidMktSettleVenueName",
                "tL.mifidubsMostLiquidVenue", "tL.dmlMnemonic", "tL.traxInd", "tL.freeFloatPercent", "tL.quoteLotSize",
                "tL.normalMarketSize", "tL.calendar", "tL.orderRoutingRule", "tL.countryOfRegistration", "tL.fiiRestrictionInd",
                "tL.auctionSession", "tL.t13", "tL.isOptionable", "tL.relativeIndex", "tL.adpId", "tL.marginableCode",
                "tL.occMarginableCode", "tL.earningsPerShare", "tL.bbPrimaryExchange", "tL.lniClass", "tL.takeoverMarker",
                "tL.takeoverDate", "tL.quick", "tL.ubsId", "equity.lastUpdatedTime", "equity.majorVersion", "equity.dividendCurrency",
                "equity.dividendPerShare", "equity.dividendType", "equity.dividendFrequency", "equity.dividendPayDate",
                "equity.dividendRecordDate", "equity.dividendDeclaredDate", "equity.dividendExDate", "equity.ipoDate",
                "settle.majorVersion", "settle.lastUpdatedTime", "settle.seaqReportingInd", "settle.crestInd", "settle.firstSettleDate",
                "settle.lastSettleDate", "settle.ptmLevyApplicable", "settle.euroclearInd", "settle.stampInd", "settle.crestStampDutyInd",
                "settle.calendar", "settle.date", "issuer.lastUpdatedTime", "issuer.majorVersion", "issuer.issuerName",
                "issuer.countryOfIncorporation", "issuer.cconsol", "issuer.bbCompany", "issuer.icbIndustry", "issuer.icbSector",
                "issuer.icbSubsector", "issuer.icbSupersector", "issuer.fidbCode", "issuer.countryOfDomicile", "issuer.countryOfRisk",
                "issuer.ubsPartyId", "event.majorVersion", "event.lastUpdatedTime");

        List<String> receivedList = mds.getAttributeNamesForPhysicalDataset("EQUITY");
        doObjectListComparison(receivedList, expected.toArray(), "Attributes");
    }

    @Test
    public void testGetAttributeXpathsForPhysicalDataset() throws Exception {
        List<String> expected = Arrays.asList("*:legalEntity/*:id[@domain='UbsParty']", "*:legalEntity/*:id/@version",
                "*:legalEntity/*:status", "*:legalEntity/*:legalEntityData/*:alternateIds/*:alternateId[@domain='GCRS']",
                "*:legalEntity/*:legalEntityData/*:tradingStatus", "*:legalEntity/*:legalEntityData/*:countryOfDomicile",
                "*:legalEntity/*:legalEntityData/*:countryOfRisk");

        List<String> receivedList = mds.getAttributeXpathsForPhysicalDataset("LEGALENTITY");
        doObjectListComparison(receivedList, expected.toArray(), "Xpaths");
    }

    @Test
    public void testGetJoinRelationsForView() throws Exception {
        List<String> expectedList1 = Arrays.asList("EQUITY", "EQPRICING");
        List<String> expectedList2 = Arrays.asList("BONDISSUE", "BONDPRICING");
        List<JoinRelation> joinRelations = mds.getJoinRelationsForView("INSTPRICE");
        assertEquals("No Joins returned", 2, joinRelations.size());

        List<PhysicalDataset> receivedList1 = joinRelations.get(0).getOrderedDatasets();
        List<PhysicalDataset> receivedList2 = joinRelations.get(1).getOrderedDatasets();

        if (receivedList1.toString().contains("EQUITY")) {
            assertEquals(expectedList1.toString(), receivedList1.toString());
            assertEquals(expectedList2.toString(), receivedList2.toString());
            return;
        } else if (receivedList1.toString().contains("BONDISSUE")) {
            assertEquals(expectedList2.toString(), receivedList1.toString());
            assertEquals(expectedList1.toString(), receivedList2.toString());
            return;
        }

        fail("Expected to list to contain either EQUITY or BONDISSUE");
    }

    @Test
    public void testTransformations() throws Exception {
        Object[] expected = Arrays.asList("com.ubs.idp.orchestrator.processor.rules.CurrencyRule").toArray();
        List<String> receivedList = mds.getTransformerRulesetsForDataset("CURRENCY");

        doObjectListComparison(receivedList, expected, "Rulesets");

        assertEquals("CURRENCY Delimiter incorrect", "\t", mds.getDelimiter("CURRENCY"));
        assertEquals("CURRENCY TableId", "", mds.getTableIdForDataset("CURRENCY"));
        assertEquals("CURRENCY.IDP TableId", "CURRENCY", mds.getTableIdForDataset("CURRENCY.IDP"));
    }

    @Test
    public void testGetTableIdForDataset() throws Exception {
        assertEquals("Table id incorrect", "", mds.getTableIdForDataset("EQUITY"));
        assertEquals("Table id incorrect", "EQUITY", mds.getTableIdForDataset("EQUITY.IDP"));
        assertEquals("Table id incorrect", "", mds.getTableIdForDataset("EQUITY.TRANSFORMED"));
        assertEquals("Table id incorrect", "CURRENCY", mds.getTableIdForDataset("CURRENCY.IDP"));
        assertEquals("Table id incorrect", "RATING", mds.getTableIdForDataset("RATING.IDP"));
    }

    @Test
    public void testAuthenticationUri() throws Exception {
        assertEquals("Authentication URI incorrect for RATING", "${RDDH_WS_HOST}", mds.getSourceAuthenticationUriForDataset("RATING"));
        assertEquals("Authentication URI incorrect for EQUITY", "${RDDH_WS_HOST}", mds.getSourceAuthenticationUriForDataset("EQUITY"));
        assertEquals("Authentication URI incorrect for BONDTL", "${RDDH_WS_HOST}", mds.getSourceAuthenticationUriForDataset("BONDTL"));
    }

    @Test
    public void testBookData() throws Exception {
        JDBCChannel channel = mds.getDatabaseDetailsForDataset("Book.BOOKSTORE");
        assertEquals("URL is incorrect", "jdbc:oracle:thin:@${bookdb.channel.server}:${bookdb.channel.port}:${bookdb.channel.database}",
                channel.url);
        assertEquals("Username is incorrect", "${bookdb.channel.username}", channel.username);
        assertEquals("Password is incorrect", "${bookdb.channel.password}", channel.password);
        assertEquals("Driver is incorrect", "oracle.jdbc.driver.OracleDriver", channel.driverClass);
        assertEquals(
                "SQL is incorrect",
                "select f.BOOK_ID, f.BOOK_NAME, SOURCE_NAME, BOOK_TYPE, BOOK_STATUS, BOOK_DESCRIPTION, RISK_BOOK, FINANCE_BOOK, RISK_RELEVANT_FLAG, FINANCE_RELEVANT_FLAG, BOOK_LOCATION, LEGALENTITYCODE, B2B_LEGALENTITYCODE FROM V_FUNC_DESK_FLAT_HIERARCHY  f INNER   JOIN V_BOOK_ATTRIBUTES  b on b.book_id=f.book_id",
                channel.querySQL);
    }

    @Test
    public void testAccountAndRXMData() {
        assertEquals("Dataset MF delimiter incorrect", "	", mds.getDelimiter("AccountsAndRXM.MF"));
        assertEquals("Dataset IDP delimiter incorrect", "	", mds.getDelimiter("AccountsAndRXM.IDP"));

        JDBCChannel channel = mds.getDatabaseDetailsForDataset("AccountsAndRXM.MF");
        assertEquals(
                "URL is incorrect",
                "jdbc:jtds:sybase://${creditRelationship.channel.server}:${creditRelationship.channel.port}/${creditRelationship.channel.database}",
                channel.url);
        assertEquals("Username is incorrect", "${creditRelationship.channel.username}", channel.username);
        assertEquals("Password is incorrect", "${creditRelationship.channel.password}", channel.password);
        assertEquals("Driver is incorrect", "net.sourceforge.jtds.jdbc.Driver", channel.driverClass);
        assertEquals(
                "SQL is incorrect",
                "select tgl.cconsol,tgc.cclientclass,tgl.factive,tcl.cvalue,tgc.crxm,tr.creventity,tgl.dvalidfrom,tgl.dvalidto from tgloballocation tgl inner join tconsol tc on tc.cconsol = tgl.cconsol and tc.cconsoltype = 3 inner join tglobalclient tgc on tgc.cconsol = tc.cprconsol and tgc.nversion = 0 left outer join tclassification tcl on tcl.cconsol = tgc.cconsol and tcl.nversion = 0 and tcl.cclasstype = 39 left outer join treporting tr on tr.cconsol = tgl.cconsol and tr.nversion = 0 where tgl.nversion = 0 and tgc.cclientclass not in ('A','B','C','PC','V')",
                channel.querySQL);

    }

    @Test
    public void testRatingData() {
        assertEquals("TableId IDP incorrect", "RATING", mds.getTableIdForDataset("RATING.IDP"));
        assertEquals("TableId RDDH incorrect", "", mds.getTableIdForDataset("RATING"));
        assertEquals("Dataset IDP delimiter incorrect", "	", mds.getDelimiter("RATING.IDP"));
        assertEquals("Dataset RDDH delimiter incorrect", "	", mds.getDelimiter("RATING"));

        Object[] expected = Arrays
                .asList("${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.active=true&issue.assetType=MISC&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE",
                        "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.active=true&issue.assetType=MONEY_MARKET&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE",
                        "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.active=true&issue.assetType=PREFERRED&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE",
                        "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.active=true&issue.assetType=MUNI&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE",
                        "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.active=true&issue.assetType=GOVT&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE",
                        "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.active=true&issue.assetType=CORP&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE",
                        "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.active=true&issue.assetType=CONVERTIBLE&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE",
                        "${RDDH_WS_HOST}/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&messageLevel=issueRating&issue.active=true&issue.assetType=MORTGAGE&user.app=${RDDH_WS_USER_APP}&user.host=${RDDH_WS_USER_HOST}&user.domain=ubsw&user.name=${RDDH_RCAS_SSO_USERNAME}&rddh.requesttype=TEXT&fields=cb64:eJx9kNGqwkAMRH9I_AepKL6J9N73uIkS2SYl2a349261oq3Fp2XPDDNhqCNJywie_lqERFhzQwt2z3SAxHL-qbHvTTt2VoE4UoLi2GpwrabMk-WQshFuWEAC7QRHBhJUc2rKjVPJKKhhfWvHkR1ExnU5dlLeP6szSbjNCFvT3M7wr_SQzfqMh0CP6Rq4qP2T9Rs8vXMIQuJuyCqraXXil-JOqSoj-yd4Ny9FmzJOrIbqgeaj1wYIx0hvsvsM7v94BwCguzE")
                .toArray();
        List<String> receivedList = mds.getSourceUrlsForDataset("RATING");

        doObjectListComparison(receivedList, expected, "URLs");
    }

    protected void doObjectListComparison(List<?> receivedList, Object[] expected, String name) {
        assertNotNull("No " + name + " returned", receivedList);
        assertEquals("Wrong number of " + name, expected.length, receivedList.size());

        Object[] received = receivedList.toArray();

        // Sort so that they should match
        Arrays.sort(expected);
        Arrays.sort(received);

        assertArrayEquals(name + " not as expected", expected, received);
    }

    protected void doObjectListComparisonNoSort(List<?> receivedList, Object[] expected, String name) {
        assertNotNull("No " + name + " returned", receivedList);
        assertEquals("Wrong number of " + name, expected.length, receivedList.size());

        Object[] received = receivedList.toArray();

        assertArrayEquals(name + " not as expected", expected, received);
    }
}
