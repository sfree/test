package test.com.ubs.idp.metadata.model;

import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.neo4j.config.EnableNeo4jRepositories;
import org.springframework.data.neo4j.support.Neo4jTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.idp.metadata.client.CustomNeo4jConfiguration;
import com.ubs.idp.metadata.client.Neo4jUtils;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { CustomNeo4jConfiguration.class, Neo4jTransactionConfiguration.class, EmbeddedBaseTest.class })
@Configuration
@ComponentScan({ "com.ubs.idp.metadata" })
@EnableNeo4jRepositories({ "com.ubs.idp.metadata.repositories" })
@Transactional
public abstract class EmbeddedBaseTest {
    protected final static Logger logger = LoggerFactory.getLogger(EmbeddedBaseTest.class);

    @Autowired
    Neo4jUtils neo4jUtils;

    @Autowired
    Neo4jTemplate template;

    static {
        System.setProperty("environment", "test");
    }
}
