package test.com.ubs.idp.metadata.model;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.model.Channel;
import com.ubs.idp.metadata.model.Consumer;
import com.ubs.idp.metadata.model.HTTPChannel;
import com.ubs.idp.metadata.model.JDBCChannel;
import com.ubs.idp.metadata.model.JoinRelation;
import com.ubs.idp.metadata.model.Mapping;
import com.ubs.idp.metadata.model.PhysicalAttribute;
import com.ubs.idp.metadata.model.PhysicalDataset;
import com.ubs.idp.metadata.model.PhysicalKey;
import com.ubs.idp.metadata.model.PhysicalKeyElement;
import com.ubs.idp.metadata.model.Role;
import com.ubs.idp.metadata.model.RulesTransformer;
import com.ubs.idp.metadata.model.Service;
import com.ubs.idp.metadata.model.ServiceImplementation;
import com.ubs.idp.metadata.model.Source;
import com.ubs.idp.metadata.model.ThinToWideTransformer;
import com.ubs.idp.metadata.model.Transformer;
import com.ubs.idp.metadata.model.View;
import com.ubs.idp.metadata.model.enums.PROTOCOL;
import com.ubs.idp.metadata.model.enums.RELATIONSHIP_TYPE;
import com.ubs.idp.metadata.model.exceptions.MetadataException;
import com.ubs.idp.metadata.model.relationships.AccessedViaRelationshipType;
import com.ubs.idp.metadata.model.relationships.JoinsRelationshipType;
import com.ubs.idp.metadata.model.relationships.KeyColumnRelationshipType;
import com.ubs.idp.metadata.model.relationships.SelectsRelationshipType;
import com.ubs.idp.metadata.repositories.PhysicalAttributeRepository;
import com.ubs.idp.metadata.repositories.PhysicalDatasetRepository;

public class MetadataServiceTest extends EmbeddedBaseTest {

    protected static boolean testDataLoaded = false;

    @Autowired
    @Qualifier("neo4jMetadataService")
    private MetadataService mds;

    @Autowired
    private PhysicalDatasetRepository physicalDatasetRepo;

    @Autowired
    private PhysicalAttributeRepository physicalAttributeRepo;

    // For handling expected exceptions
    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    static {
        System.setProperty("environment", "test");
    }
    
    @Before
    public void clearAndSeedDatabase() throws Exception {
        if (!testDataLoaded) {
            clearDatabase();
            populateSeedData();
            testDataLoaded = true;
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    private void clearDatabase() throws Exception {
        neo4jUtils.clearDatabase();
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    private void populateSeedData() throws Exception {
        logger.info("Populating test data");

        // ----------- EQUITY RDDH --------------------------------
        PhysicalAttribute equtiyRddhAttribute = new PhysicalAttribute();
        equtiyRddhAttribute.id = "Equity.RDDH.tl.ubsId";
        equtiyRddhAttribute.name = "UBS ID";
        equtiyRddhAttribute.position = 1;
        equtiyRddhAttribute.queryable = true;
        template.save(equtiyRddhAttribute);

        PhysicalAttribute equityRddhAttribute2 = new PhysicalAttribute();
        equityRddhAttribute2.id = "Equity.RDDH.tl.firstTradeDate";
        equityRddhAttribute2.name = "First Trade Date";
        equityRddhAttribute2.position = 2;
        template.save(equityRddhAttribute2);

        PhysicalAttribute equityRddhAttribute3 = new PhysicalAttribute();
        equityRddhAttribute3.id = "Equity.RDDH.issue.isOfQuality";
        equityRddhAttribute3.name = "Is Of Quality?";
        equityRddhAttribute3.position = 0;
        equityRddhAttribute3.queryable = true;
        template.save(equityRddhAttribute3);

        PhysicalDataset equityRddhDataset = new PhysicalDataset();
        equityRddhDataset.id = "Equity.RDDH";
        equityRddhDataset.name = "Equity";
        equityRddhDataset.delimiter = "xml://(?=<\\?)";
        equityRddhDataset.namespaces = "ns1=www.equity.com,ns2=www.equity.com/delta";
        equityRddhDataset.attributes.add(equtiyRddhAttribute);
        equityRddhDataset.attributes.add(equityRddhAttribute2);
        equityRddhDataset.attributes.add(equityRddhAttribute3);

        Role role = new Role();
        role.id = "IDP_QS_PUBLIC";
        role.name = "IDP_QS_PUBLIC";
        template.save(role);

        equityRddhDataset.getRoles().add(role);

        template.save(equityRddhDataset);

        // ----- EOF Equity RDDH ------------------------------

        // ----------- EQUITY IDP --------------------------------

        PhysicalAttribute equityIdpAttribute = new PhysicalAttribute();
        equityIdpAttribute.id = "ubsId";
        equityIdpAttribute.name = "UBS ID";
        equityIdpAttribute.queryable = true;
        template.save(equityIdpAttribute);

        PhysicalAttribute equityIdpAttribute2 = new PhysicalAttribute();
        equityIdpAttribute2.id = "firstTradeDate";
        equityIdpAttribute2.name = "First Trade Date";
        equityIdpAttribute2.position = 2;
        template.save(equityIdpAttribute2);

        PhysicalDataset equityIdpDataset = new PhysicalDataset();
        equityIdpDataset.id = "Equity.IDP";
        equityIdpDataset.name = "Equity";
        equityIdpDataset.tableId = "EQUITY";
        equityIdpDataset.attributes.add(equityIdpAttribute);
        equityIdpDataset.attributes.add(equityIdpAttribute2);
        template.save(equityIdpDataset);

        PhysicalKey key = new PhysicalKey();
        key.id = "Equity.IDP.Key";
        key.name = "Equity Key";
        key.setDataset(equityIdpDataset);
        template.save(key);

        PhysicalKeyElement keyElement = new PhysicalKeyElement();
        keyElement.id = "Equity.IDP.Key.Element.1";
        keyElement.name = "Equity Key Element 1";
        keyElement.setKey(key);
        template.save(keyElement);

        PhysicalKeyElement keyElement2 = new PhysicalKeyElement();
        keyElement2.id = "Equity.IDP.Key.Element.2";
        keyElement2.name = "Equity Key Element 2";
        keyElement2.setKey(key);
        template.save(keyElement2);

        equityIdpAttribute.setKeyElement(keyElement);
        template.save(equityIdpAttribute);

        equityIdpAttribute2.setKeyElement(keyElement2);
        template.save(equityIdpAttribute2);

        // ----------- EQUITY EOF --------------------------------

        // ----------- TRANSFORMER and
        // Mappings-------------------------------
        Mapping mapping1 = new Mapping();
        mapping1.id = "Equity.Mapping.ubsId";
        mapping1.name = "Equity Mapping UBS ID";
        template.save(mapping1);

        Mapping mapping2 = new Mapping();
        mapping2.id = "Equity.Mapping.firstTradeDate";
        mapping2.name = "Equity Mapping First Trade Date";
        template.save(mapping2);

        RulesTransformer ruleTransformer = new RulesTransformer();
        ruleTransformer.id = "Equity.RDDH.To.Equity.IDP";
        ruleTransformer.name = "Equity RDDH to IDP Transformer";
        ruleTransformer.ruleset = "ruleset1,ruleset2,ruleset3";
        ruleTransformer.mappings.add(mapping1);
        ruleTransformer.mappings.add(mapping2);
        template.save(ruleTransformer);

        equityRddhDataset.setOutgoingTransformer(ruleTransformer);
        template.save(equityRddhDataset);

        equityIdpDataset.setIncomingTransformer(ruleTransformer);
        template.save(equityIdpDataset);

        // ----------- INDEX RDDH --------------------------------
        PhysicalAttribute indexRddhAttribute = new PhysicalAttribute();
        indexRddhAttribute.id = "tl.ubsId";
        indexRddhAttribute.name = "UBS ID";
        indexRddhAttribute.position = 0;
        indexRddhAttribute.getJoinedAttributes().add(equtiyRddhAttribute);
        template.save(indexRddhAttribute);

        PhysicalAttribute indexRddhAttribute2 = new PhysicalAttribute();
        indexRddhAttribute2.id = "tl.ric";
        indexRddhAttribute2.name = "RIC";
        indexRddhAttribute2.position = 1;
        template.save(indexRddhAttribute2);

        PhysicalAttribute indexRddhAttribute3 = new PhysicalAttribute();
        indexRddhAttribute3.id = "issue.issueName";
        indexRddhAttribute3.name = "Issue Name";
        indexRddhAttribute3.position = 2;
        template.save(indexRddhAttribute3);

        PhysicalDataset indexRddhDataset = new PhysicalDataset();
        indexRddhDataset.id = "Index.RDDH";
        indexRddhDataset.name = "Index";
        indexRddhDataset.attributes.add(indexRddhAttribute);
        indexRddhDataset.attributes.add(indexRddhAttribute2);
        indexRddhDataset.attributes.add(indexRddhAttribute3);
        template.save(indexRddhDataset);
        // ----------- INDEX EOF --------------------------------

        // ----------- INDEX IDP --------------------------------
        PhysicalAttribute indexIdpAttribute = new PhysicalAttribute();
        indexIdpAttribute.id = "ubsId";
        indexIdpAttribute.name = "UBS ID";
        indexIdpAttribute.queryable = true;
        template.save(indexIdpAttribute);

        PhysicalAttribute indexIdpAttribute2 = new PhysicalAttribute();
        indexIdpAttribute2.id = "ric";
        indexIdpAttribute2.name = "RIC";
        template.save(indexIdpAttribute2);

        PhysicalDataset indexIdpDataset = new PhysicalDataset();
        indexIdpDataset.id = "Index.IDP";
        indexIdpDataset.name = "Index";
        indexIdpDataset.tableId = "INDEX";
        indexIdpDataset.attributes.add(indexIdpAttribute);
        indexIdpDataset.attributes.add(indexIdpAttribute2);
        template.save(indexIdpDataset);

        PhysicalKey indexKey = new PhysicalKey();
        indexKey.id = "Index.Key";
        indexKey.name = "Index Key";
        indexKey.setDataset(indexIdpDataset);
        template.save(indexKey);

        PhysicalKeyElement indexKeyElement = new PhysicalKeyElement();
        indexKeyElement.id = "Index.Key.Element.1";
        indexKeyElement.name = "Index Key Element 1";
        indexKeyElement.setKey(indexKey);
        template.save(indexKeyElement);

        PhysicalKeyElement indexKeyElement2 = new PhysicalKeyElement();
        indexKeyElement2.id = "Index.Key.Element.2";
        indexKeyElement2.name = "Index Key Element 2";
        indexKeyElement2.setKey(indexKey);
        template.save(indexKeyElement2);

        indexIdpAttribute.setKeyElement(indexKeyElement);
        template.save(indexIdpAttribute);

        indexIdpAttribute2.setKeyElement(indexKeyElement2);
        template.save(indexIdpAttribute2);

        // ----------- INDEX EOF --------------------------------

        // ----------- ThinToWide TRANSFORMER
        ThinToWideTransformer transformer = new ThinToWideTransformer();
        transformer.id = "Index.RDDH.To.Index.IDP";
        transformer.name = "Index RDDH to IDP Transformer";
        transformer.keyColumns.add(new KeyColumnRelationshipType(transformer, indexRddhAttribute, 1));
        transformer.keyColumns.add(new KeyColumnRelationshipType(transformer, indexRddhAttribute2, 0));
        transformer.pivotColumn = indexIdpAttribute2;
        transformer.targetPivotValues = "value1,value2";
        transformer.preProcessorRules = "ruleset3,ruleset4,ruleset5";
        transformer.columnsAssociatedWithPivot.add(indexRddhAttribute2);
        transformer.columnsAssociatedWithPivot.add(indexRddhAttribute3);
        template.save(transformer);

        indexRddhDataset.setOutgoingTransformer(transformer);
        template.save(indexRddhDataset);

        indexIdpDataset.setIncomingTransformer(transformer);
        template.save(indexIdpDataset);

        // ---------------- Channels -----------------------
        HTTPChannel channel = new HTTPChannel();
        channel.id = "EQUTITY.CHANNEL.HTTP.INBOUND";
        channel.name = "EQUTITY CHANNEL HTTP INBOUND";
        channel.protocol = PROTOCOL.http;
        channel.url = "http://www.equity:${port}.com?fields=${ADD_ENCODED_FIELDS}";
        channel.deltaUrl = "http://www.equity:${port}.com/delta";
        channel.authenticationUri = "http://www.equity.com:${port}";
        template.save(channel);

        Channel channel2 = new Channel();
        channel2.id = "EQUTITY.CHANNEL.HTTP.INBOUND.DELATA";
        channel2.name = "EQUTITY CHANNEL HTTP INBOUND DELTA";
        channel2.protocol = PROTOCOL.http;
        channel2.url = "http://www.equity:${port}.com/delta";
        template.save(channel2);

        JDBCChannel channel3 = new JDBCChannel();
        channel3.id = "EQUTITY.CHANNEL.JDBC.INBOUND";
        channel3.name = "EQUTITY CHANNEL JDBC INBOUND";
        channel3.protocol = PROTOCOL.jdbc;
        channel3.url = "jdbc://${host}:${port}/db";
        channel3.querySQL = "SELECT * FROM TABLE";
        channel3.driverClass = "${driver}";
        channel3.username = "${username}";
        channel3.password = "${password}";

        template.save(channel3);

        Channel indexChannel = new Channel();
        indexChannel.id = "INDEX.CHANNEL.HTTP.INBOUND";
        indexChannel.name = "INDEX CHANNEL HTTP INBOUND";
        indexChannel.protocol = PROTOCOL.http;
        indexChannel.url = "http://www.index:${port}.com";
        template.save(indexChannel);

        ServiceImplementation serviceImplementation = new ServiceImplementation();
        serviceImplementation.id = "EQUITY.SERVICE.HTTP/CSV";
        serviceImplementation.name = "EQUITY SERVICE HTTP/CSV";
        serviceImplementation.dataset = equityRddhDataset;
        serviceImplementation.channels.add(new AccessedViaRelationshipType(serviceImplementation, channel, 1));
        serviceImplementation.channels.add(new AccessedViaRelationshipType(serviceImplementation, channel2, 2));
        template.save(serviceImplementation);

        ServiceImplementation serviceImplementation2 = new ServiceImplementation();
        serviceImplementation2.id = "EQUITY.SERVICE.JDBC";
        serviceImplementation2.name = "EQUITY SERVICE JDBC";
        serviceImplementation2.dataset = equityRddhDataset;
        serviceImplementation2.channels.add(new AccessedViaRelationshipType(serviceImplementation2, channel3, 2));
        template.save(serviceImplementation2);

        ServiceImplementation indexServiceImplementation = new ServiceImplementation();
        indexServiceImplementation.id = "INDEX.SERVICE.HTTP/CSV";
        indexServiceImplementation.name = "INDEX SERVICE HTTP/CSV";
        indexServiceImplementation.dataset = indexRddhDataset;
        indexServiceImplementation.channels.add(new AccessedViaRelationshipType(indexServiceImplementation, indexChannel, 1));
        template.save(indexServiceImplementation);

        Service service = new Service();
        service.id = "EQUITY.SERVICE";
        service.name = "EQUITY SERVICE";
        service.serviceImplementations.add(serviceImplementation);
        service.serviceImplementations.add(serviceImplementation2);
        template.save(service);

        Service indexService = new Service();
        indexService.id = "INDEX.SERVICE";
        indexService.name = "INDEX SERVICE";
        indexService.serviceImplementations.add(indexServiceImplementation);
        template.save(indexService);

        Source source = new Source();
        source.id = "RDDH";
        source.name = "RDDH";
        source.services.add(service);
        source.services.add(indexService);
        template.save(source);

        // ------------ Index Equity View -------------------

        View view = new View();
        view.getAttributes().add(new SelectsRelationshipType(view, equityIdpAttribute, 0, "equityUbsId"));
        view.getAttributes().add(new SelectsRelationshipType(view, equityIdpAttribute2, 1, "equityfirstTradeDate"));
        view.getAttributes().add(new SelectsRelationshipType(view, indexIdpAttribute, 2, "indexUbsId"));
        view.getAttributes().add(new SelectsRelationshipType(view, indexIdpAttribute2, 3, "indexRIC"));
        view.delimiter = "|";
        view.id = "Index.Equity.View";
        view.name = "Index Equity View";
        view.unionAll = true;

        JoinRelation joinRelation = new JoinRelation();
        joinRelation.id = "Index.Equity.View.JoinRelation.1";
        joinRelation.name = "Index Equity View JoinRelation 1";
        joinRelation.position = 2;
        joinRelation.datasets.add(new JoinsRelationshipType(joinRelation, equityIdpDataset, 0, "issue.isin=123"));
        joinRelation.datasets.add(new JoinsRelationshipType(joinRelation, indexIdpDataset, 1));
        template.save(equityIdpDataset);

        PhysicalDataset dummyDataset = new PhysicalDataset();
        dummyDataset.id = "Dummy";
        dummyDataset.name = "Dummy";
        dummyDataset.tableId = "Dummy";
        dummyDataset.delimiter = "\t";
        template.save(dummyDataset);

        JoinRelation joinRelation2 = new JoinRelation();
        joinRelation2.id = "Equity.Index.View.JoinRelation.1";
        joinRelation2.name = "Equity Index View JoinRelation 1";
        joinRelation2.position = 1;
        joinRelation2.datasets.add(new JoinsRelationshipType(joinRelation2, indexIdpDataset, 0, "issue.isin=123"));
        joinRelation2.datasets.add(new JoinsRelationshipType(joinRelation2, dummyDataset, 1));
        template.save(equityIdpDataset);

        view.joinRelations.add(joinRelation);
        view.joinRelations.add(joinRelation2);
        template.save(view);

        // ------------ Dummy View -------------------
        PhysicalAttribute dummyAttribute = new PhysicalAttribute();
        dummyAttribute.id = "dummyId";
        dummyAttribute.name = "DUMMY ID";
        dummyAttribute.queryable = true;
        template.save(dummyAttribute);

        dummyDataset.attributes.add(dummyAttribute);
        template.save(dummyDataset);

        joinRelation = new JoinRelation();
        joinRelation.id = "Dummy.View.JoinRelation.1";
        joinRelation.name = "Dummy View JoinRelation 1";
        joinRelation.position = 3;
        joinRelation.datasets.add(new JoinsRelationshipType(joinRelation, equityIdpDataset, 0, ""));
        template.save(equityIdpDataset);

        view.joinRelations.add(joinRelation);
        template.save(view);

        Consumer consumer = new Consumer();
        consumer.id = "Consumer.A";
        consumer.name = "Consumer A";
        consumer.views.add(view);
        template.save(consumer);

        // -------------------- TPOS metadata -------------------------
        Transformer transformer1 = getTransformer();
        template.save(transformer1);

        PhysicalDataset dataSet = getDataSet("result1", "AddressResultSet1.79.MF");
        dataSet.setOutgoingTransformer(transformer1);
        dataSet.setIncomingTransformer(transformer1);
        template.save(dataSet);

        ServiceImplementation serviceImplementation79 = getServiceImplementation("AddressPropagationStoredProc79",
                "Address Propagation Stored Proc 79");
        serviceImplementation79.dataset = dataSet;
        template.save(serviceImplementation79);

        Service service79 = getService("79", "ADDRESS PROPAGATION 79");
        service79.serviceImplementations.add(serviceImplementation79);
        template.save(service79);

        Source mfSource = getSource("MasterFiles", "MasterFiles");
        mfSource.services.add(service79);
        template.save(mfSource);

        populateWithCyperQuery();
    }

    private void populateWithCyperQuery() {

        neo4jUtils.executeCyperCommand("CREATE (n:Dataset:PhysicalDataset:_PhysicalDataset{id:'IDP_MFEVENTS',name:'IDP MFEVENTS'});");
        neo4jUtils.executeCyperCommand("MATCH (n0:PhysicalDataset) WHERE n0.id='IDP_MFEVENTS'\n"
                + " CREATE (n1:PhysicalAttribute:_PhysicalAttribute {id:'ID',name:'ID', type:'NUMBER'}),\n"
                + "(n2:PhysicalAttribute:_PhysicalAttribute {id:'NEVENTID',name:'NEVENTID', type:'NUMBER'}),\n" + "(n0)-[:OWNS]->(n1),\n"
                + "(n0)-[:OWNS]->(n2);");
        neo4jUtils
                .executeCyperCommand("CREATE (n: ServiceImplementation:_ServiceImplementation{id:'PropagationStoredProc80',name:'Address Propagation Stored Proc 80',propertiesMap:'{\"data_type\":\"Address\",\"downstream_system\":\"BPS\"}'});");
        neo4jUtils
                .executeCyperCommand("CREATE (n:Dataset:PhysicalDataset:_PhysicalDataset{id:'AddressResultSet1.80.MF',name: 'client' ,position:1});");
        neo4jUtils
                .executeCyperCommand("MATCH (n:PhysicalDataset) WHERE n.id='AddressResultSet1.80.MF'  MATCH (m:ServiceImplementation) WHERE m.id='PropagationStoredProc80' CREATE (m)-[r:PROVIDES]->(n);");
        neo4jUtils
                .executeCyperCommand("CREATE (n: Transformer:FieldLevelTransformer:_FieldLevelTransformer{id:'AddressPropagPersister80',name: 'Address_Propag_Persister_80', attributesMapping:'{\"client\": {\n"
                        + "\t\"cconsol\":\"UBS_MF_GL\",\n" + "\t\"com_cl_num\":\"ADP_Client_Number\"\n" + "\t}\n" + "}'});");
        neo4jUtils
                .executeCyperCommand("MATCH (n:Dataset) WHERE n.id='AddressResultSet1.80.MF'  MATCH (m:Transformer) WHERE m.id='AddressPropagPersister80' CREATE (m)-[r:SOURCE_OF]->(n);");
        neo4jUtils
                .executeCyperCommand("CREATE (n: ServiceImplementation:_ServiceImplementation{id:'GetMfAccountEventsSql',name:'Get Mf Account Events Sql',propertiesMap:'{\"service_sql\":\"Select neventid , cconsol, "
                        + "ccode2, cpropagation, rpcId, dlast, cmode, ctable, chostserver from teventqueue where neventid > :maxEventId  order by neventid asc\"}'});");
    }

    private Transformer getTransformer() {

        Transformer transformer = new Transformer();
        transformer.id = "AddressPropagPersister79";
        return transformer;
    }

    private Source getSource(String id, String name) {

        Source mfSource = new Source();
        mfSource.name = id;
        mfSource.id = name;
        return mfSource;
    }

    private PhysicalDataset getDataSet(String id, String name) {

        PhysicalDataset dummyDataset = new PhysicalDataset();
        dummyDataset.id = id;
        dummyDataset.name = name;
        return dummyDataset;
    }

    private Service getService(String id, String name) {
        Service service = new Service();
        service.id = id;
        service.name = name;
        return service;
    }

    private ServiceImplementation getServiceImplementation(String id, String name) {
        ServiceImplementation serviceImplementation = new ServiceImplementation();
        serviceImplementation.id = id;
        serviceImplementation.name = name;
        return serviceImplementation;
    }

    @Test
    public void testGetSQLQueryForDataset() {
        String expected = "SELECT * FROM TABLE";
        String received = mds.getSQLQueryForDataset("Equity.RDDH");
        assertEquals("Query not as expected", expected, received);
    }

    @Test
    public void testGetNamespacesForDataset() {
        Map<String, String> expected = new HashMap<String, String>();
        expected.put("ns1", "www.equity.com");
        expected.put("ns2", "www.equity.com/delta");

        Map<String, String> received = mds.getNamespacesForDataset("Equity.RDDH");
        assertEquals("Namespaces", expected, received);
    }

    @Test
    public void testGetAllRelations() {
        Map<String, List<JoinRelation>> received = mds.getAllRelations();
        Set<String> keys = received.keySet();
        assertEquals("Wrong number of views", 1, keys.size());

        assertEquals("JoinRelations not as expected", "Dummy.View.JoinRelation.1", received.get("Index.Equity.View").get(0).id);
        assertEquals("JoinRelations not as expected", "Equity.Index.View.JoinRelation.1", received.get("Index.Equity.View").get(1).id);
        assertEquals("JoinRelations not as expected", "Index.Equity.View.JoinRelation.1", received.get("Index.Equity.View").get(2).id);
        assertEquals("JoinRelation datasets not as expected", 1, received.get("Index.Equity.View").get(0).datasets.size());
        assertEquals("JoinRelation datasets not as expected", 2, received.get("Index.Equity.View").get(1).datasets.size());

        for (String key : keys) {
            List<JoinRelation> receivedList = received.get(key);

            // Check the tableId is being fetched for the physical datasets in
            // the join relation
            for (JoinRelation jr : receivedList) {
                for (PhysicalDataset pd : jr.getOrderedDatasets()) {
                    assertNotNull("No table ID set for " + pd.id, pd.tableId);
                }
            }
        }

    }

    @Test
    public void testGetAttributePositionsForDataset() {
        Map<String, Integer> receivedMap = mds.getAttributePositionsForDataset("Equity.RDDH");

        assertEquals("Wrong number of attributes", 3, receivedMap.keySet().size());

        assertEquals("Wrong position for attribute", new Integer(1), receivedMap.get("Equity.RDDH.tl.ubsId"));
        assertEquals("Wrong position for attribute", new Integer(2), receivedMap.get("Equity.RDDH.tl.firstTradeDate"));
        assertEquals("Wrong position for attribute", new Integer(0), receivedMap.get("Equity.RDDH.issue.isOfQuality"));
    }

    @Test
    public void testGetAttributePositionsForView() {
        Map<String, Integer> receivedMap = mds.getAttributePositionsForDataset("Index.Equity.View");

        assertEquals("Wrong number of attributes", 4, receivedMap.keySet().size());

        assertEquals("Wrong position for attribute", new Integer(0), receivedMap.get("equityUbsId"));
        assertEquals("Wrong position for attribute", new Integer(1), receivedMap.get("equityfirstTradeDate"));
        assertEquals("Wrong position for attribute", new Integer(2), receivedMap.get("indexUbsId"));
        assertEquals("Wrong position for attribute", new Integer(3), receivedMap.get("indexRIC"));

    }

    @Test
    public void testGetAttributeNamesForDataset() throws Exception {
        Object[] expected = Arrays.asList("Is Of Quality?", "UBS ID", "First Trade Date").toArray();
        List<String> receivedList = mds.getAttributeNamesForDataset("Equity.RDDH");

        doObjectListComparisonNoSort(receivedList, expected, "PhysicalAttributes");
    }

    @Test
    public void testGetAttributeIdsForDataset() throws Exception {
        Object[] expected = Arrays.asList("Equity.RDDH.issue.isOfQuality", "Equity.RDDH.tl.ubsId", "Equity.RDDH.tl.firstTradeDate")
                .toArray();
        List<String> receivedList = mds.getAttributeIdsForDataset("Equity.RDDH");

        doObjectListComparisonNoSort(receivedList, expected, "PhysicalAttributes");
    }

    @Test
    public void testGetQueryableAttributePositionsForDataset() throws Exception {
        Object[] expected = Arrays.asList(0, 1).toArray();
        List<Integer> receivedList = mds.getQueryableAttributePositionsForDataset("Equity.RDDH");

        doObjectListComparisonNoSort(receivedList, expected, "PhysicalAttributes");
    }

    @Test
    public void testGetQueryableAttributePositionsForView() throws Exception {
        Object[] expected = Arrays.asList(0, 2).toArray();
        List<Integer> receivedList = mds.getQueryableAttributePositionsForDataset("Index.Equity.View");

        doObjectListComparisonNoSort(receivedList, expected, "PhysicalAttributes");
    }

    @Test
    public void testGetDatasetKeyAttributePositionsForDataset() throws Exception {
        Object[] expected = Arrays.asList(0, 2).toArray();
        List<Integer> receivedList = mds.getDatasetKeyAttributePositions("Equity.IDP");

        doObjectListComparisonNoSort(receivedList, expected, "PhysicalAttributes");
    }

    @Test
    public void testGetDatasetKeyAttributeNamesForDataset() throws Exception {
        Object[] expected = Arrays.asList("ubsId", "firstTradeDate").toArray();
        List<String> receivedList = mds.getDatasetKeyAttributeNames("Equity.IDP");

        doObjectListComparisonNoSort(receivedList, expected, "PhysicalAttributes");
    }

    @Test
    public void testGetAttributeNamesForView() throws Exception {
        Object[] expected = Arrays.asList("equityUbsId", "equityfirstTradeDate", "indexUbsId", "indexRIC").toArray();
        List<String> receivedList = mds.getAttributeNamesForDataset("Index.Equity.View");

        doObjectListComparisonNoSort(receivedList, expected, "Attribute names");
    }

    @Test
    public void testIntrospector() throws Exception {
        Object[] expected = Arrays.asList(RELATIONSHIP_TYPE.OWNS, RELATIONSHIP_TYPE.SOURCE_OF, RELATIONSHIP_TYPE.TARGET_OF).toArray();
        PhysicalDataset pd1 = new PhysicalDataset();
        List<RELATIONSHIP_TYPE> receivedList = pd1.getPermittedRelationships();
        doObjectListComparison(receivedList, expected, "PhysicalDataset relationships");
    }

    protected void doObjectListComparison(List<?> receivedList, Object[] expected, String name) {
        assertNotNull("No " + name + " returned", receivedList);
        assertEquals("Wrong number of " + name, expected.length, receivedList.size());

        Object[] received = receivedList.toArray();

        // Sort so that they should match
        Arrays.sort(expected);
        Arrays.sort(received);

        assertArrayEquals(name + " not as expected", expected, received);

    }

    protected void doObjectListComparisonNoSort(List<?> receivedList, Object[] expected, String name) {
        assertNotNull("No " + name + " returned", receivedList);
        assertEquals("Wrong number of " + name, expected.length, receivedList.size());

        Object[] received = receivedList.toArray();

        assertArrayEquals(name + " not as expected", expected, received);

    }

    @Test
    public void testGetDatabaseDetailsForDataset() {
        String driver = "${driver}";
        String url = "jdbc://${host}:${port}/db";
        String username = "${username}";
        String password = "${password}";

        JDBCChannel channel = mds.getDatabaseDetailsForDataset("Equity.RDDH");

        assertEquals("Database driver not as expected", driver, channel.driverClass);
        assertEquals("Database url not as expected", url, channel.url);
        assertEquals("Database username not as expected", username, channel.username);
        assertEquals("Database password not as expected", password, channel.password);
    }

    @Test
    public void testGetSourceUrlsForAllDatasets() {
        Object[] equityExpected = Arrays
                .asList("http://www.equity:${port}.com?fields=cb64:eJxzLSzNLKnUC3Jx8dDLLC4uTQWS_mmBpYk5QGEdVyTZkhy90qRizxR0wbTMouKSkKLElFSXxJJUAIxAHNA",
                        "http://www.equity:${port}.com/delta").toArray();
        Object[] indexExpected = Arrays.asList("http://www.index:${port}.com").toArray();

        Map<String, List<String>> received = mds.getSourceUrlsForAllDatasets();

        List<String> receivedList = received.get("Equity.RDDH");
        doObjectListComparison(receivedList, equityExpected, "Equity URLs");

        receivedList = received.get("Index.RDDH");
        doObjectListComparison(receivedList, indexExpected, "Index URLs");

    }

    @Test
    public void testGetSourceDeltaUrlForDataset() {
        String expected = "http://www.equity:${port}.com/delta";
        String received = mds.getSourceDeltaUrlForDataset("Equity.RDDH");

        assertEquals("Delta URLs dont match", expected, received);
    }

    @Test
    public void testGetSourceUrlsForDataset() {
        Object[] expected = Arrays
                .asList("http://www.equity:${port}.com?fields=cb64:eJxzLSzNLKnUC3Jx8dDLLC4uTQWS_mmBpYk5QGEdVyTZkhy90qRizxR0wbTMouKSkKLElFSXxJJUAIxAHNA",
                        "http://www.equity:${port}.com/delta", "jdbc://${host}:${port}/db").toArray();
        List<String> receivedList = mds.getSourceUrlsForDataset("Equity.RDDH");

        doObjectListComparison(receivedList, expected, "Dataset URLs");
    }

    @Test
    public void testGetSourceAutheintcationUriForDataset() {
        String expected = "http://www.equity.com:${port}";
        String received = mds.getSourceAuthenticationUriForDataset("Equity.RDDH");

        assertEquals("Dataset Authentication URi", expected, received);
    }

    @Test
    public void testGetUrlForChannel() {
        String expected = "http://www.equity:${port}.com?fields=cb64:eJxzLSzNLKnUC3Jx8dDLLC4uTQWS_mmBpYk5QGEdVyTZkhy90qRizxR0wbTMouKSkKLElFSXxJJUAIxAHNA";
        String received = mds.getUrlForChannel("EQUTITY.CHANNEL.HTTP.INBOUND");

        assertEquals("Channel URL incorrect", expected, received);
    }

    @Test
    public void testGetPrimarySourceUrlForDataset() {
        String expected = "http://www.equity:${port}.com?fields=cb64:eJxzLSzNLKnUC3Jx8dDLLC4uTQWS_mmBpYk5QGEdVyTZkhy90qRizxR0wbTMouKSkKLElFSXxJJUAIxAHNA";
        String received = mds.getPrimarySourceUrlForDataset("Equity.RDDH");
        assertEquals("URL not as expected", expected, received);

    }

    @Test
    public void testGetDelimiter() {
        String expected = "xml://(?=<\\?)";
        String received = mds.getDelimiter("Equity.RDDH");
        assertEquals("Delimiter not as expected", expected, received);
    }

    @Test
    public void testGetDelimiterNoDelimiter() {
        expectedEx.expect(MetadataException.class);
        expectedEx.expectMessage("Dataset with id=Equity.IDP does not have a value set for property 'delimiter'");
        mds.getDelimiter("Equity.IDP");

    }

    @Test
    public void testGetDelimiterInvalidDataset() {
        expectedEx.expect(MetadataException.class);
        expectedEx
                .expectMessage("Failed to find dataset with id=ARSE (Query=[match (d:Dataset {id:{id}}) return d.delimiter] Params={id=ARSE})");
        mds.getDelimiter("ARSE");
    }

    @Test
    public void testGetJoinRelationsForView() {
        List<JoinRelation> receivedList = mds.getJoinRelationsForDataset("Index.Equity.View");
        assertEquals("JoinRelations not as expected", "Equity.Index.View.JoinRelation.1", receivedList.get(0).id);
        assertEquals("JoinRelations not as expected", "Index.Equity.View.JoinRelation.1", receivedList.get(1).id);
        assertEquals("JoinRelations not as expected", "Dummy.View.JoinRelation.1", receivedList.get(2).id);

        assertEquals("JoinRelation datasets not as expected", 2, receivedList.get(0).datasets.size());
        assertEquals("JoinRelation datasets not as expected", 2, receivedList.get(1).datasets.size());
        assertEquals("JoinRelation datasets not as expected", 1, receivedList.get(2).datasets.size());

        assertEquals("JoinRelation ordered datasets not as expected", "Index.IDP", receivedList.get(0).getOrderedDatasets().get(0).id);
        assertEquals("JoinRelation ordered datasets not as expected", "Dummy", receivedList.get(0).getOrderedDatasets().get(1).id);

        assertEquals("JoinRelation ordered datasets not as expected", "Equity.IDP", receivedList.get(1).getOrderedDatasets().get(0).id);
        assertEquals("JoinRelation ordered datasets not as expected", "Index.IDP", receivedList.get(1).getOrderedDatasets().get(1).id);

        assertEquals("JoinRelation ordered datasets not as expected", 1, receivedList.get(2).getOrderedDatasets().size());

        // Check the tableId is being fetched for the physical datasets in the
        // join relation
        for (JoinRelation jr : receivedList) {
            for (PhysicalDataset pd : jr.getOrderedDatasets()) {
                assertNotNull("No table ID set for " + pd.id, pd.tableId);
            }
        }
    }

    @Test
    public void testGetJoinRelationsForDataset() {
        List<JoinRelation> receivedList = mds.getJoinRelationsForDataset("Equity.IDP");
        assertEquals("JoinRelations not as expected", "DummyJoinRelation.Equity.IDP", receivedList.get(0).id);
        assertEquals("JoinRelation datasets not as expected", 1, receivedList.get(0).datasets.size());
        assertEquals("JoinRelation ordered datasets not as expected", 1, receivedList.get(0).getOrderedDatasets().size());

        // Check the tableId is being fetched for the physical datasets in the
        // join relation
        for (JoinRelation jr : receivedList) {
            for (PhysicalDataset pd : jr.getOrderedDatasets()) {
                assertNotNull("No table ID set for " + pd.id, pd.tableId);
            }
        }
    }

    @Test
    public void testTransformerRulesetsForDataset() {
        Object[] expected = Arrays.asList("ruleset1", "ruleset2", "ruleset3").toArray();
        List<String> receivedList = mds.getTransformerRulesetsForDataset("Equity.RDDH");
        doObjectListComparison(receivedList, expected, "Rulesets");

    }

    @Test
    public void testTransformerRulesetsForDatasetNonRulesTransformer() {
        try {
            mds.getTransformerRulesetsForDataset("Index.IDP");
        } catch (MetadataException ex) {
            assertEquals(
                    "Wrong exception message",
                    ex.getMessage(),
                    "Failed to find dataset with id=Index.IDP or the dataset does not have a RulesTransformer associated with it (Query=[match (d:Dataset {id:{id}})-[:SOURCE_OF]->(rt:RulesTransformer) return rt.ruleset] Params={id=Index.IDP})");
            return;
        }
        fail();

    }

    @Test
    public void testPreProcessorTransformerRulesetsForDataset() {
        Object[] expected = Arrays.asList("ruleset3", "ruleset4", "ruleset5").toArray();
        List<String> receivedList = mds.getTransformerPreProcessorRulesetsForDataset("Index.RDDH");
        doObjectListComparison(receivedList, expected, "Pre-processor Rulesets");

    }

    @Test
    public void testPreProcessorTransformerRulesetsForDatasetNonRulesTransformer() {
        try {
            mds.getTransformerPreProcessorRulesetsForDataset("Index.IDP");
        } catch (MetadataException ex) {
            assertEquals(
                    "Wrong exception message",
                    ex.getMessage(),
                    "Failed to find dataset with id=Index.IDP or the dataset does not have a ThinToWideTransformer associated with it (Query=[match (d:Dataset {id:{id}})-[:SOURCE_OF]->(ttw:ThinToWideTransformer) return ttw.preProcessorRules] Params={id=Index.IDP})");
            return;
        }
        fail();

    }

    @Test
    public void testGetThinToWideKeyColumnPositionsForDataset() {
        Object[] expected = Arrays.asList(1, 0).toArray();
        List<Integer> receivedList = mds.getThinToWideKeyColumnPositionsForDataset("Index.RDDH");
        doObjectListComparison(receivedList, expected, "Key column positions");
    }

    @Test
    public void testGetThinToWideKeyColumnPositionsForDatasetNonThinTowWideTransformer() {
        try {
            mds.getThinToWideKeyColumnPositionsForDataset("Index.IDP");
        } catch (MetadataException ex) {
            assertEquals(
                    "Wrong exception message",
                    ex.getMessage(),
                    "Failed to find dataset with id=Index.IDP or the dataset does not have a ThinToWideTransformer associated with it, or does not have any key columns set on the Transformer (Query=[match (d:Dataset {id:{id}})-[:SOURCE_OF]->(ttw:ThinToWideTransformer)-[r:HAS_KEY_COLUMN]->(pa:PhysicalAttribute) return pa.position order by r.sortOrder ASC] Params={id=Index.IDP})");
            return;
        }
        fail();
    }

    @Test
    public void testGetThinToWideKeyColumnsForDataset() {
        Object[] expected = Arrays.asList("tl.ric", "tl.ubsId").toArray();
        List<String> receivedList = mds.getThinToWideKeyColumnsForDataset("Index.RDDH");
        doObjectListComparison(receivedList, expected, "Key column names");

    }

    @Test
    public void testGetThinToWideKeyColumnsForDatasetNonThinTowWideTransformer() {
        try {
            mds.getThinToWideKeyColumnsForDataset("Index.IDP");
        } catch (MetadataException ex) {
            assertEquals(
                    "Wrong exception message",
                    ex.getMessage(),
                    "Failed to find dataset with id=Index.IDP or the dataset does not have a ThinToWideTransformer associated with it, or does not have any key columns set on the Transformer (Query=[match (d:Dataset {id:{id}})-[:SOURCE_OF]->(ttw:ThinToWideTransformer)-[r:HAS_KEY_COLUMN]->(pa:PhysicalAttribute) return pa.id order by r.sortOrder ASC] Params={id=Index.IDP})");
            return;
        }
        fail();
    }

    @Test
    public void testGetThinToWidePivotColumnForDatasetorDataset() {
        assertEquals("Incorrect pivot column", "ric", mds.getThinToWidePivotColumnForDataset("Index.RDDH"));

    }

    @Test
    public void testGetThinToWidePivotColumnForDatasetNonThinTowWideTransformer() {
        try {
            mds.getThinToWidePivotColumnForDataset("Index.IDP");
        } catch (MetadataException ex) {
            assertEquals(
                    "Wrong exception message",
                    ex.getMessage(),
                    "Failed to find dataset with id=Index.IDP or the dataset does not have a ThinToWideTransformer associated with it, or there is no Attribute defined as the pivot column (Query=[match (d:Dataset {id:{id}})-[:SOURCE_OF]->(ttw:ThinToWideTransformer)-[:HAS_PIVOT_COLUMN]->(pa:PhysicalAttribute) return pa.id] Params={id=Index.IDP})");
            return;
        }
        fail();

    }

    @Test
    public void testGetThinToWideTargetPivotValuesForDataset() {
        Object[] expected = Arrays.asList("value1", "value2").toArray();
        List<String> receivedList = mds.getThinToWideTargetPivotValuesForDataset("Index.RDDH");
        doObjectListComparison(receivedList, expected, "Target pivot values");

    }

    @Test
    public void testGetThinToWideTargetPivotValuesForDatasetNonThinTowWideTransformer() {
        try {
            mds.getThinToWidePivotColumnForDataset("Index.IDP");
        } catch (MetadataException ex) {
            assertEquals(
                    "Wrong exception message",
                    ex.getMessage(),
                    "Failed to find dataset with id=Index.IDP or the dataset does not have a ThinToWideTransformer associated with it, or there is no Attribute defined as the pivot column (Query=[match (d:Dataset {id:{id}})-[:SOURCE_OF]->(ttw:ThinToWideTransformer)-[:HAS_PIVOT_COLUMN]->(pa:PhysicalAttribute) return pa.id] Params={id=Index.IDP})");
            return;
        }
        fail();
    }

    @Test
    public void testGetThinToWideColumnsAssociatedWithPivotForDataset() {
        Object[] expected = Arrays.asList("tl.ric", "issue.issueName").toArray();
        List<String> receivedList = mds.getThinToWideColumnsAssociatedWithPivotForDataset("Index.RDDH");
        doObjectListComparison(receivedList, expected, "Target pivot values");

    }

    @Test
    public void testGetThinToWideColumnsAssociatedWithPivotForDatasetNonThinTowWideTransformer() {
        try {
            mds.getThinToWideColumnsAssociatedWithPivotForDataset("Index.IDP");
        } catch (MetadataException ex) {
            assertEquals(
                    "Wrong exception message",
                    ex.getMessage(),
                    "Failed to find dataset with id=Index.IDP or the dataset does not have a ThinToWideTransformer associated with it, or there are no Attributes defined for pivot columns (Query=[match (d:Dataset {id:{id}})-[:SOURCE_OF]->(ttw:ThinToWideTransformer)-[:HAS_ASSOCIATED_PIVOT_COLUMN]->(pa:PhysicalAttribute) return pa.id] Params={id=Index.IDP})");
            return;
        }
        fail();

    }

    @Test
    public void testGetAllDatasetsAndAttributes() {
        Object[] equityAttributes = Arrays.asList("Equity.RDDH.issue.isOfQuality", "Equity.RDDH.tl.ubsId", "Equity.RDDH.tl.firstTradeDate")
                .toArray();
        Object[] indexAttributes = Arrays.asList("issue.issueName", "tl.ubsId", "tl.ric").toArray();
        Object[] equityIdpAttributes = Arrays.asList("ubsId", "firstTradeDate").toArray();
        Object[] indexIdpAttributes = Arrays.asList("ubsId", "ric").toArray();
        Object[] viewAttributes = Arrays.asList("equityUbsId", "equityfirstTradeDate", "indexUbsId", "indexRIC").toArray();

        Map<String, List<String>> received = mds.getAllDatasetAndAttributeNames();
        assertEquals("Wrong number of datasets returned", 7, received.keySet().size());

        List<String> receivedList = received.get("Equity.RDDH");
        doObjectListComparison(receivedList, equityAttributes, "Equity Attributes");

        receivedList = received.get("Index.RDDH");
        doObjectListComparison(receivedList, indexAttributes, "Index attributes");

        receivedList = received.get("Equity.IDP");
        doObjectListComparison(receivedList, equityIdpAttributes, "Equity Attributes");

        receivedList = received.get("Index.IDP");
        doObjectListComparison(receivedList, indexIdpAttributes, "Index attributes");

        receivedList = received.get("Index.Equity.View");
        doObjectListComparison(receivedList, viewAttributes, "Index attributes");

    }

    @Test
    public void testGetRolesForDataset() {
        Object[] expected = Arrays.asList("IDP_QS_PUBLIC").toArray();
        List<String> receivedList = mds.getRolesForDataset("Equity.RDDH");
        doObjectListComparison(receivedList, expected, "Roles");
    }

    @Test
    public void testGetJoinKeysForDatasetIds() {
        Object[] expected = Arrays.asList("Equity.RDDH.tl.ubsId", "tl.ubsId").toArray();
        List<String> receivedList = mds.getJoinKeysForDatasetIds("Equity.RDDH", "Index.RDDH");

        doObjectListComparisonNoSort(receivedList, expected, "Key attributes");
    }

    @Test
    public void testGetTableIdForDataset() {
        String expected = "EQUITY";
        String received = mds.getTableIdForDataset("Equity.IDP");
        assertEquals("Dataset table ID not as expected", expected, received);
    }

    @Test
    public void testGetTableIdForDatasetInvalidDataset() {
        expectedEx.expect(MetadataException.class);
        expectedEx
                .expectMessage("Failed to find dataset with id=BUM (Query=[match (pd:PhysicalDataset {id:{id}}) return pd.tableId] Params={id=BUM})");
        mds.getTableIdForDataset("BUM");
    }

    @Test
    public void testGetTableIdForDatasetNoProperty() {
        expectedEx.expect(MetadataException.class);
        expectedEx
                .expectMessage("Dataset with id=Equity.RDDH does not have a value set for property 'tableId' (Query=[match (pd:PhysicalDataset {id:{id}}) return pd.tableId] Params={id=Equity.RDDH})");
        mds.getTableIdForDataset("Equity.RDDH");

    }

    @Test
    public void testGetPredicatesForDatasetInJoinRelation() {
        String expected = "issue.isin=123";
        String received = mds.getPredicatesForDatasetInJoinRelation("Index.Equity.View.JoinRelation.1", "Equity.IDP");
        assertEquals("Predicate not as expected", expected, received);

    }

    @Test
    public void testGetPredicatesForDatasetInJoinRelationNoJoinRelation() {
        expectedEx.expect(MetadataException.class);
        expectedEx
                .expectMessage("Failed to find JoinRelation with id=Winky that is joined to Dataset with id=Equity.IDP (Query=[match (jr:JoinRelation {id:{jrid}})-[r:JOINS]->(d:Dataset {id:{id}}) return r.predicates] Params={id=Equity.IDP, jrid=Winky})");
        mds.getPredicatesForDatasetInJoinRelation("Winky", "Equity.IDP");
    }

    @Test
    public void testGetPredicatesForDatasetInJoinRelationNoDataset() {
        expectedEx.expect(MetadataException.class);
        expectedEx
                .expectMessage("Failed to find JoinRelation with id=Index.Equity.View.JoinRelation.1 that is joined to Dataset with id=Whaff (Query=[match (jr:JoinRelation {id:{jrid}})-[r:JOINS]->(d:Dataset {id:{id}}) return r.predicates] Params={id=Whaff, jrid=Index.Equity.View.JoinRelation.1})");
        mds.getPredicatesForDatasetInJoinRelation("Index.Equity.View.JoinRelation.1", "Whaff");

    }

    @Test
    public void testGetUnionAllForView() {
        assertTrue("Union all not as expected", mds.getUnionAllForView("Index.Equity.View"));
    }

    @Test
    public void testGetUnionAllForViewNoViewId() {
        expectedEx.expect(MetadataException.class);
        expectedEx
                .expectMessage("Failed to find view with id=Munge (Query=[match (v:View {id:{id}}) return v.unionAll] Params={id=Munge})");
        mds.getUnionAllForView("Munge");
    }

    @Test
    public void testIsView() {
        assertFalse("Expected Equity to not be a view", mds.isView("Equity.IDP"));
        assertTrue("Expected Index.Equity.View to be a view", mds.isView("Index.Equity.View"));
    }

    @Test
    public void testIsViewInvalid() {
        expectedEx.expect(MetadataException.class);
        expectedEx
                .expectMessage("Failed to find dataset with id=Bundy (Query=[match (d:Dataset {id:{id}}) return labels(d)] Params={id=Bundy})");
        mds.isView("Bundy");
    }

    @Test
    public void shouldReturnServiceImplementations() {

        List<String> allServiceImplementationsForSource = mds.getAllServiceImplementationsForSource("MasterFiles");
        assertThat(allServiceImplementationsForSource.size(), is(1));
    }

    @Test
    public void shouldTransformationMappings() {

        Map<String, Map<String, String>> dataSetTransformationMappings = mds.getDataSetTransformationMappings("PropagationStoredProc80");
        assertThat(dataSetTransformationMappings.size(), is(1));
        assertTrue(dataSetTransformationMappings.get("client").containsKey("cconsol"));
    }

    @Test
    public void shouldThrowExceptionInsteadOfReturningServiceImplementationsForInvalidSource() {

        expectedEx.expect(MetadataException.class);
        expectedEx
                .expectMessage("Failed to find Service Implementation for source id=SlaveFiles "
                        + "(Query=[MATCH (so:Source {id:{id}}) - [:OFFERS] -> (s:Service) - [:IMPLEMENTED_BY] -> (si:ServiceImplementation) RETURN si.id] Params={id=SlaveFiles})");
        mds.getAllServiceImplementationsForSource("SlaveFiles");
    }

    @Test
    public void testGetPropepertyMapOfServiceImplementation() {
        Map<String, String> propertyMap = mds.getPropertyMapOfServiceImplementation("GetMfAccountEventsSql");
        assertNotNull(propertyMap);
        assertNotNull(propertyMap.get("service_sql"));
    }

    @Test
    public void should_Return_PhysicalAttributes() {
        Map<String, String> idpMfEventsAttributes = mds.getPhysicalDatasetAttributeNamesAndTypes("IDP_MFEVENTS");
        assertThat("DataSet attributes should not be null", idpMfEventsAttributes, notNullValue());
        assertThat("Should have two DataSet attributes", idpMfEventsAttributes.size(), is(2));
    }

    @Test
    public void testGetAllDatasets() {
        Object[] expected = Arrays.asList("Equity.IDP", "Index.IDP", "Equity.RDDH", "Index.RDDH", "Dummy", "result1",
                "AddressResultSet1.80.MF", "IDP_MFEVENTS").toArray();
        List<String> receivedList = mds.getAllDatasets();
        System.out.println("********************************************************************************************");
        int count = 0;
        for (String receivedListobj : receivedList) {
            System.out.println("DataSet at index :" + ++count + " with value :" + receivedListobj);
        }
        System.out.println("********************************************************************************************");

        doObjectListComparison(receivedList, expected, "Datasets");
    }
}
