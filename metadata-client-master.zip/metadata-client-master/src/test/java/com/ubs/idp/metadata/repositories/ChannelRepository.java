package com.ubs.idp.metadata.repositories;

import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.stereotype.Repository;

import com.ubs.idp.metadata.model.Channel;

@Repository
public interface ChannelRepository extends GraphRepository<Channel>
{
	public Channel findOneById(String id);
	public Channel findOneByName(String name);
}
