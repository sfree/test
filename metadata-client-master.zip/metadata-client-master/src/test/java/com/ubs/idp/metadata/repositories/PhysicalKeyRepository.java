package com.ubs.idp.metadata.repositories;

import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.stereotype.Repository;

import com.ubs.idp.metadata.model.PhysicalKey;

@Repository
public interface PhysicalKeyRepository extends GraphRepository<PhysicalKey>
{
	public PhysicalKey findOneById(String id);
	public PhysicalKey findOneByName(String name);
}
