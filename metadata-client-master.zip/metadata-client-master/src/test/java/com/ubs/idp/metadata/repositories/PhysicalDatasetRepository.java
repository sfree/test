package com.ubs.idp.metadata.repositories;

import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.stereotype.Repository;

import com.ubs.idp.metadata.model.PhysicalDataset;

@Repository
public interface PhysicalDatasetRepository extends GraphRepository<PhysicalDataset> 
{
	public PhysicalDataset findOneById(String id);
	public PhysicalDataset findOneByName(String name);
}
