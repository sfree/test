package com.ubs.idp.metadata.repositories;

import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.stereotype.Repository;

import com.ubs.idp.metadata.model.Service;

@Repository
public interface ServiceRepository extends GraphRepository<Service>
{
	public Service findOneById(String id);
	public Service findOneByName(String name);
}
