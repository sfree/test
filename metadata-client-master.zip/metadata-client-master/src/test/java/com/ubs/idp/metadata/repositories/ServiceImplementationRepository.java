package com.ubs.idp.metadata.repositories;

import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.stereotype.Repository;

import com.ubs.idp.metadata.model.ServiceImplementation;

@Repository
public interface ServiceImplementationRepository extends GraphRepository<ServiceImplementation>
{
	public ServiceImplementation findOneById(String id);
	public ServiceImplementation findOneByName(String name);
}
