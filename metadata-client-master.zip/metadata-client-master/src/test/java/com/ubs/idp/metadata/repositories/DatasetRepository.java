package com.ubs.idp.metadata.repositories;

import org.springframework.data.neo4j.repository.GraphRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.stereotype.Repository;

import com.ubs.idp.metadata.model.Dataset;

@Repository
public interface DatasetRepository extends GraphRepository<Dataset> 
{
	public Dataset findOneById(String id);
	public Dataset findOneByName(String name);
}
