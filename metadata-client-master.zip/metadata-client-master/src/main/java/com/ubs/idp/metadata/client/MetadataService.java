package com.ubs.idp.metadata.client;

import java.util.List;
import java.util.Map;

import com.ubs.idp.metadata.model.JDBCChannel;
import com.ubs.idp.metadata.model.JMSChannel;
import com.ubs.idp.metadata.model.JoinRelation;

/**
 * This defines additional operations that the IDP Metadata Service (idp-mds)
 * will need to support. Ultimately, these methods need to be merged in to the
 * current idp-mds along with any changes to the metamodel required.
 * 
 * @author rochesi
 * @author haniffsy
 * @author loverids
 */
public interface MetadataService {

    /**
     * Returns all attribute positions for the specified dataset that are key
     * values ordered by position. Throws an exception if the dataset cannot be
     * found
     * 
     * @param datasetId
     * @return
     * @throws Exception
     * 
     */
    public List<Integer> getDatasetKeyAttributePositions(String datasetId);

    /**
     * Returns all attribute names the specified dataset that are key values
     * ordered by position. Throws an exception if the dataset cannot be found
     * 
     * @param datasetId
     * @return
     * @throws Exception
     * 
     */
    public List<String> getDatasetKeyAttributeNames(String datasetId);

    /**
     * The names of all attribute names associated with a dataset. The Dataset
     * can be either PhysicalDataset or a View. The attributes are returned
     * sorted by their attribute position
     * 
     * @param datasetId
     * @return
     */
    public List<String> getAttributeNamesForDataset(String datasetId);

    /**
     * The names of all attribute ids associated with a dataset. The Dataset can
     * be either PhysicalDataset or a View. The attributes are returned sorted
     * by their attribute position
     * 
     * @param datasetId
     * @return
     */
    public List<String> getAttributeIdsForDataset(String datasetId);

    /**
     * Returns the SQL query to fetch data for the specified dataset id
     * 
     * @param datasetId
     * @return
     */
    public String getSQLQueryForDataset(String datasetId);

    /**
     * Returns the SQL Delta query to fetch data for the specified dataset id
     * 
     * @param datasetId
     * @return
     */
    public String getSQLDeltaQueryForDataset(String datasetId);

    /**
     * Returns the JDBC channel information for a specific dataset
     * 
     * @param datasetId
     * @return
     */
    public JDBCChannel getDatabaseDetailsForDataset(String datasetId);

    /**
     * Fetches the transformer associated with a dataset and returns the list of
     * rulesets the transformer uses.
     * 
     * Throws an exception if the dataset cannot be found, if there are no
     * target transformers associated with the dataset or if the transformer is
     * not a rules based transformer
     * 
     * @param datasetId
     * @return
     */
    public List<String> getTransformerRulesetsForDataset(String datasetId);

    /**
     * Fetches the transformer associated with a source and target dataset and
     * returns the list of rulesets the transformer uses. This is used for when
     * a source dataset can be transformed into multiple target datasets
     * 
     * Throws an exception if the dataset cannot be found, if there are no
     * target transformers associated with the dataset or if the transformer is
     * not a rules based transformer
     * 
     * @param datasetId
     * @return
     */
    public List<String> getTransformerRulesetsForDatasets(String srcDataset, String targetDataset);

    /**
     * Fetches the ThinToWide transformer associated with a dataset and returns
     * the list of pre processor rulesets the transformer uses.
     * 
     * Throws an exception if the dataset cannot be found, if there are no
     * target transformers associated with the dataset or if the transformer is
     * not a ThinToWide based transformer
     * 
     * @param datasetId
     * @return
     */
    public List<String> getTransformerPreProcessorRulesetsForDataset(String datasetId);

    /**
     * Returns a map of attribute names and positions for the specified dataset.
     * 
     * Throws an Exception if the dataset cannot be found or no position
     * property is set on an attribute
     * 
     * @param datasetId
     * @param attributeId
     * @return
     * 
     * @TODO: This should be change to return an {@link PhysicalAttribute} array
     *        or just the {@link PhysicalDataset} instead
     * 
     */
    public Map<String, Integer> getAttributePositionsForDataset(String datasetId);

    /**
     * Returns the delimiter used in the output data for the specified view
     * 
     * @param view
     * @return
     */
    public String getDelimiter(String datasetId);

    /**
     * Returns an array of attribute names for a given physical dataset sorted
     * by the attribute position
     * 
     * Throws an Exception if the dataset cannot be found
     * 
     * @param datasetId
     * @return
     */
    public List<String> getAttributeNamesForPhysicalDataset(String datasetId);

    /**
     * Returns an array of attribute xpaths used to access data from the XML
     * source for the specified dataset
     * 
     * Throws an Exception if the dataset cannot be found
     * 
     * @param datasetId
     * @return
     */
    public List<String> getAttributeXpathsForPhysicalDataset(String datasetId);

    /**
     * Returns a map of all dataset Ids (Physical, Logical and View) mapped to
     * an array of all associated attribute ids
     * 
     * @param datasetId
     * @return
     * 
     * @TODO: This should be change to return a {@link PhysicalDataset} array
     *        instead
     */
    public Map<String, List<String>> getAllDatasetAndAttributeNames();

    /**
     * Returns an array of source urls for where the data for the dataset was
     * originally received from.
     * 
     * Throws an exception if the dataset could not be found
     * 
     * @param datasetId
     * @return
     */
    public List<String> getSourceUrlsForDataset(String datasetId);

    /**
     * Returns a list of XD job names which keep the dataset / view refreshed.
     * 
     * Throws an exception if the dataset could not be found
     * 
     * @param datasetId
     * @return
     */
    public List<String> getJobNamesForDataset(String datasetId);

    /**
     * Returns the primary URL used to retrieve the specified dataset
     * 
     * @param datasetId
     * @return
     */
    public String getPrimarySourceUrlForDataset(String datasetId);

    /**
     * Returns a source url for where the delta data for the dataset was
     * originally received from.
     * 
     * Throws an exception if the dataset could not be found, the delta url
     * property is not set or the URL is invalid or malformed
     * 
     * @param datasetId
     * @return
     */
    public String getSourceDeltaUrlForDataset(String datasetId);

    /**
     * Returns a map of all dataset ids and their corresponding array of source
     * URLs for where the data for the dataset was originally received from.
     * 
     * @return
     */
    public Map<String, List<String>> getSourceUrlsForAllDatasets();

    /**
     * Returns the list of roles required to access the dataset.
     * 
     * Throws an exception if the dataset cannot be found
     * 
     * @param datasetId
     * @return
     * 
     * @TODO: This should be change to return an {@link Role} array
     */
    public List<String> getRolesForDataset(String datasetId);

    /**
     * Returns the attribute names that the two specified datasets are joined on
     * 
     * @param datasetId1
     * @param datasetId2
     * @return
     */
    public List<String> getJoinKeysForDatasetIds(String datasetId, String datasetId2);

    /**
     * Returns the positions of all queryable attributes for a specified
     * dataset. Positions are returned in order. Throws an exception if the
     * dataset cannot be found
     * 
     * @param datasetId
     * @return
     */
    public List<Integer> getQueryableAttributePositionsForDataset(String datasetId);

    /**
     * Returns namespaces map for dataset keyed on namespace prefix e.g.
     * 
     * ns0=http://www.example.com
     * 
     * Thows an exception if the dataset cannot be found or the dataset does not
     * have any namespace properties
     * 
     * @param datasetId
     * @return
     */
    public Map<String, String> getNamespacesForDataset(String datasetId);

    /**
     * @Deprecated: Use getJoinRelationsForDataset Returns an array of Join
     *              Relations that the view comprises of
     * 
     * @param datasetId
     * @return
     */
    @Deprecated
    public List<JoinRelation> getJoinRelationsForView(String viewId);

    /**
     * If the datasetId is a View entity then it returns the array of
     * JoinRelations associated with the view
     * 
     * If the datasetId is for a PhysicalDataset then a single JoinRelation is
     * returned containing the details of the specified dataset
     * 
     * @param datasetId
     * @return
     */
    public List<JoinRelation> getJoinRelationsForDataset(String datasetId);

    /**
     * All the relations for all the views
     * 
     * @return
     * 
     * @TODO: This should be change to return a {@link View} array
     */
    public Map<String, List<JoinRelation>> getAllRelations();

    /**
     * Returns a specific, separate URI used for authentication if the source
     * channel for the specified datasetId requires it.
     * 
     * @param datasetId
     * @return
     */
    public String getSourceAuthenticationUriForDataset(String datasetId);

    /**
     * Returns the URL for the specified channel Id
     * 
     * @param channelId
     * @param isDelta
     * @return
     */
    public String getUrlForChannel(String channelId, boolean isDelta);

    /**
     * Returns the URL for the specified channel Id
     * 
     * @param channelId
     * @return
     */
    public String getUrlForChannel(String channelId);

    /**
     * Returns the table id for the specified physical dataset
     * 
     * @param datasetId
     * @return
     */
    public String getTableIdForDataset(String datasetId);

    /**
     * Generates an SQL insert statement based on the attributes available for
     * the dataset
     * 
     * @param datasetId
     * @return
     */
    public String generateSQLInsertForDataset(String datasetId);

    /**
     * For datasets that are transformed via a
     * {@linkplain ThinToWideTransformer}, this method will return the attribute
     * names that form the key columns to sort the datasets by before
     * transformation
     * 
     * @param datasetId
     * @return
     */
    public List<String> getThinToWideKeyColumnsForDataset(String datasetId);

    /**
     * For datasets that are transformed via a
     * {@linkplain ThinToWideTransformer}, this method will return the attribute
     * positions that form the key columns to sort the datasets by before
     * transformation
     * 
     * @param datasetId
     * @return
     */
    public List<Integer> getThinToWideKeyColumnPositionsForDataset(String datasetId);

    /**
     * For datasets that are transformed via a
     * {@linkplain ThinToWideTransformer}, this method will return the attribute
     * that is the pivot column for the transformation
     * 
     * @param datasetId
     * @return
     */
    public String getThinToWidePivotColumnForDataset(String datasetId);

    /**
     * For datasets that are transformed via a
     * {@linkplain ThinToWideTransformer}, this method will return the values
     * that are to be matched against pivot column value
     * 
     * @param datasetId
     * @return
     */
    public List<String> getThinToWideTargetPivotValuesForDataset(String datasetId);

    /**
     * For datasets that are transformed via a
     * {@linkplain ThinToWideTransformer}, this method will return the
     * attributes names of the columns that will be replicated (Thin to wide)
     * for each match of the pivot value against the target values
     * 
     * @param datasetId
     * @return
     */
    public List<String> getThinToWideColumnsAssociatedWithPivotForDataset(String datasetId);

    /**
     * Returns a comma separated predicate string that is associated with the
     * specified dataset in the join relation
     * 
     * @param joinRelaionId
     * @param datasetId
     * @return
     */
    public String getPredicatesForDatasetInJoinRelation(String joinRelaionId, String datasetId);

    /**
     * Returns true if the specified view has been set to union all datasets or
     * false if it will return the first dataset that matches a predicate in the
     * query
     * 
     * @param viewId
     * @return
     */
    public boolean getUnionAllForView(String viewId);

    /**
     * Dataset is the parent type of both PhysicalDatasets and Views. This view
     * will determine if the dataset id specified is a View.
     * 
     * @param datasetId
     * @return
     */
    public boolean isView(String datasetId);

    /**
     * Returns Service Implementations for given service
     *
     * @param serviceId
     * @return
     */
    List<String> getServiceImplementations(String serviceId);

    /**
     * Returns data set details for given service implementation
     *
     * @param serviceImplId
     * @return
     */
    Map<String, List<String>> getDataSetDetails(String serviceImplId);

    /**
     * Returns required data set attributes for given service implementation
     *
     * @param serviceImplId
     * @return
     */
    Map<String, String> getRequiredDataSetAttributes(String serviceImplId);

    /**
     * Returns stored procedure details for given service implementation
     *
     * @param serviceImplId
     * @return
     */
    Map<String, Map<String, Map<String, Object>>> getStoredProcedureDetails(String serviceImplId);

    /**
     * Returns JMS channel details for given service
     *
     * @param service
     * @return
     */
    JMSChannel getJMSChannelDetails(String service);

    /**
     * Returns all Service Implementations for a given source
     * 
     * @param sourceId
     * @return
     */
    List<String> getAllServiceImplementationsForSource(String sourceId);

    /**
     * Return the channel details for given Id
     *
     * @param channelId
     * @return
     */
    JDBCChannel getJdbcChannelDetailsWithId(String channelId);

    /**
     * Return map from mappings defined in transformer in Json Structure
     *
     * @param serviceImplId
     * @return
     */
    Map getDataSetTransformationMappings(String serviceImplId);

    /**
     * Return map from mappings defined in transformer in Json Structure
     *
     * @param viewId
     * @return
     */
    Map getTransformationMappingforView(String viewId);
    
    /**
     * Return string of the XSLT Stylesheet
     *
     * @param viewId
     * @return
     */
	String getXsltStylesheetForView(String viewId);

    List<Map<String, String>> getDataSetFilterAttributes(String dataSetId);

    /**
     *
     * @param viewId
     * @return
     */
    String getChannelWithViewId(String viewId);

    /**
     * returns a key value properties map of node of type ServiceImplementation
     * *
     * 
     * @param serviceImplementationId
     * @return
     */
    Map<String, String> getPropertyMapOfServiceImplementation(String serviceImplementationId);

    /**
     * Return the DataSet attributes with name and type for given dataset id
     *
     * @param datasetId
     * @return
     */
    Map<String, String> getPhysicalDatasetAttributeNamesAndTypes(String datasetId);

    /**
     * Returns a List of Map <K,V> of Ordered DataSetId's for a given service
     * implementation. The ordering is done on basis of data set position. Key
     * is DatasetID and Value is datasetName.
     * 
     * @param serviceImplId
     * @return
     */
    List<Map<String, String>> getOrderedDatasetDetails(String serviceImplId);

    /**
     * Returns a list of all PhysicalDataset ids (this excludes Views)
     * 
     * @param datasetId
     * @return
     */
    public List<String> getAllDatasets();
}
