package com.ubs.idp.metadata.model.relationships;

import org.neo4j.graphdb.Relationship;
import org.springframework.data.neo4j.annotation.GraphId;

import com.ubs.idp.metadata.model.DynamicRelationship;

/**
 * Base type for all custom Relationship types
 * @author loverids
 *
 */
public class BaseRelationshipType
{
	@GraphId Long nodeId;
	
	
	
	public Relationship toRelationship() throws IllegalArgumentException, IllegalAccessException
	{
		return new DynamicRelationship(this);
	}
}
