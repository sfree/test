package com.ubs.idp.metadata.model;

import org.springframework.data.neo4j.annotation.NodeEntity;

@NodeEntity
public class FieldLevelTransformer extends Transformer
{ 
	public String transformerClass;
}
