package com.ubs.idp.metadata.model;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.neo4j.graphdb.Node;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.Indexed;
import org.springframework.data.neo4j.annotation.Indexed.Level;
import org.springframework.data.neo4j.annotation.RelatedTo;
import org.springframework.data.neo4j.annotation.RelatedToVia;

import com.ubs.idp.metadata.model.enums.RELATIONSHIP_TYPE;

public abstract class BaseEntity {
    @GraphId
    public Long nodeId;

    /**
     * This is the id for a particular instance that is used to do lookups. We
     * don't do lookups based on the 'name'.
     * 
     * This is not to be confused with the 'nodeId' as this an internal, numeric
     * value] used by Neo4j
     */
    @Indexed(level = Level.INSTANCE)
    public String id;

    /**
     * This is the human readable value that describes this entity
     */
    public String name;

    /**
     * Returns a text description of this node
     * 
     * @return
     */
    public abstract String describe();

    /**
     * Returns the permitted relationship types that can be made between other
     * nodes
     * 
     * @return
     */
    public List<RELATIONSHIP_TYPE> getPermittedRelationships() {
        List<RELATIONSHIP_TYPE> relationships = new ArrayList<RELATIONSHIP_TYPE>();

        Field[] fields = this.getClass().getDeclaredFields();
        for (Field field : fields) {
            Annotation[] annotations = field.getAnnotations();
            for (Annotation annotation : annotations) {
                if (annotation.annotationType().equals(RelatedTo.class)) {
                    RelatedTo relatedTo = (RelatedTo) annotation;
                    String relationshipType = relatedTo.type();
                    relationships.add(RELATIONSHIP_TYPE.valueOf(relationshipType));
                }
            }
        }

        return relationships;
    }

    @Override
    public String toString() {
        return name;
    }

    /**
     * Returns this entity as a raw Neo4j Node
     * 
     * @return
     * @throws IllegalAccessException
     * @throws IllegalArgumentException
     */
    public Node toNode() throws IllegalArgumentException, IllegalAccessException {
        return new DynamicNode(this);
    }

    /**
     * Sets all available properties in the node against the properties in this
     * entity.
     * 
     * @param node
     * @throws IllegalAccessException
     * @throws IllegalArgumentException
     * @throws SecurityException
     * @throws NoSuchFieldException
     * @throws NoSuchMethodException
     * @throws InvocationTargetException
     */
    public void fromNode(Node node) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException,
            NoSuchMethodException, InvocationTargetException {
        // Set the properties from the entity
        Class currentClass = this.getClass();

        Iterable<String> propNames = node.getPropertyKeys();
        for (String propName : propNames) {
            Field field = currentClass.getField(propName);

            // Ignore properties that relate to others
            if (field.getAnnotation(RelatedTo.class) != null || field.getAnnotation(RelatedToVia.class) != null) {
                continue;
            }

            Object value = node.getProperty(field.getName());

            if (field.getType().getEnumConstants() != null) {
                Method method = field.getType().getMethod("valueOf", String.class);
                value = method.invoke(field, value.toString());
            }

            field.set(this, value);
        }
    }

}
