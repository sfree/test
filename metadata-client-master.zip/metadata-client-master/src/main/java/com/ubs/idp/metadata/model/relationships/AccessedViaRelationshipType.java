package com.ubs.idp.metadata.model.relationships;

import org.neo4j.graphdb.Relationship;
import org.springframework.data.neo4j.annotation.EndNode;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.RelationshipEntity;
import org.springframework.data.neo4j.annotation.StartNode;

import com.ubs.idp.metadata.model.Channel;
import com.ubs.idp.metadata.model.ServiceImplementation;

@RelationshipEntity(type="ACCESSED_VIA")
public class AccessedViaRelationshipType extends BaseRelationshipType
{
	public AccessedViaRelationshipType()
	{
		
	}
	
	public AccessedViaRelationshipType(ServiceImplementation serviceImplementation,
									   Channel channel,
									   int priority)
	{
		this.priority = priority;
		this.serviceImplementation = serviceImplementation;
		this.channel = channel;
	}
	
	public int priority;	
	@StartNode public ServiceImplementation serviceImplementation;
	@EndNode public Channel channel;
	

	
}
