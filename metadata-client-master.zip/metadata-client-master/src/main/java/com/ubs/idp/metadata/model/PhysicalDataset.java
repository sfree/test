package com.ubs.idp.metadata.model;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.neo4j.graphdb.DynamicRelationshipType;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.traversal.TraversalDescription;
import org.neo4j.kernel.Traversal;
import org.springframework.data.neo4j.annotation.Fetch;
import org.springframework.data.neo4j.annotation.GraphTraversal;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.annotation.RelatedTo;
import org.springframework.data.neo4j.core.FieldTraversalDescriptionBuilder;
import org.springframework.data.neo4j.mapping.Neo4jPersistentProperty;

import com.ubs.idp.metadata.model.enums.RELATIONSHIP_TYPE;
import com.ubs.idp.metadata.model.evaluators.NodePropertyEvaluator;
import com.ubs.idp.metadata.model.evaluators.NodeTypeEvaluator;

@NodeEntity
public class PhysicalDataset extends Dataset implements Comparable<PhysicalDataset>
{
	public PhysicalDataset()
	{
				
	}	
	
	/**
	 * Constructor that creates a PhysicalDataset from a base dataset by 
	 * copy across the values for the 'id' and 'name' properties. These are the only
	 * properties that get copied
	 *  
	 * @param dataset
	 */
	public PhysicalDataset( Dataset dataset )
	{
		this.id = dataset.id;
		this.name = dataset.name;
	}

	
	@RelatedTo(type = "OWNS", direction = Direction.OUTGOING)
	public Set<PhysicalAttribute> attributes = new HashSet<PhysicalAttribute>();

	@Query (value="start n=node({self}) match (n)-[:OWNS]->(pa:PhysicalAttribute) return pa order by pa.position ASC")
	private Iterable<PhysicalAttribute> attributesOrderedByPosition;

	@Query (value="start n=node({self}) match (n)-[:OWNS]->(pa:PhysicalAttribute) where pa.queryable=true return pa order by pa.position ASC")
	private Iterable<PhysicalAttribute> queryableAttributesOrderedByPosition;

	@Query (value="start n=node({self}) match (n)<-[:PROVIDES]-(si:ServiceImplementation)-[r:ACCESSED_VIA]->(c:Channel) where c.protocol='http' return c.url")
	private Iterable<String> sourceURLs;

	@Query (value="start n=node({self}) match (n)<-[:PROVIDES]-(si:ServiceImplementation)-[r:ACCESSED_VIA]->(c:Channel) where r.priority=1 and c.protocol='http' return c.url")
	private String primarySourceURL;

	@Query (value="start n=node({self}) match (n)<-[:PROVIDES]-(si:ServiceImplementation)-[r:ACCESSED_VIA]->(c:Channel) where r.priority=1 and c.protocol='http' return c.deltaUrl")
	private String deltaSourceURL;

	/**
	 * This identifies where in the physical data store the data for this dataset
	 * can be retrieved from.
	 * 
	 * For example, in Cassandra this would be the column family name or in Oracle it
	 * would be the tablename
	 */
	public String tableId;

	/**
	 * Comma separated list of namespaces
	 */
	public String namespaces;
			
	/**
	 * The relationship to the transformer that maps into this
	 * PhysicalDatset
	 */
	@RelatedTo(type = "TARGET_OF", direction = Direction.OUTGOING)
	private Transformer incomingTransformer;

	/**
	 * The relationship to the transformer that maps out of this
	 * PhysicalDatset to another
	 */	
	@RelatedTo(type = "SOURCE_OF", direction = Direction.OUTGOING)
	private Transformer outgoingTransformer;

	/**
	 * The available JDBC source channels used to fetch data to populate
	 * this dataset 
	 */
	@GraphTraversal(traversal = SQLTraversalBuilder.class, elementClass=JDBCChannel.class)
	private Iterable<JDBCChannel> jdbcSourceChannels;

	private static class SQLTraversalBuilder implements FieldTraversalDescriptionBuilder 
	{
		@Override
		public TraversalDescription build(Object start, Neo4jPersistentProperty props, String... params)
		{
			return Traversal.description().
					relationships(DynamicRelationshipType.withName(RELATIONSHIP_TYPE.PROVIDES.toString()), Direction.INCOMING).
					relationships(DynamicRelationshipType.withName(RELATIONSHIP_TYPE.ACCESSED_VIA.toString()), Direction.OUTGOING).					
					evaluator(new NodePropertyEvaluator("protocol","jdbc"));
		}
	}

	/**
	 * The Key attributes associated with this dataset
	 */
	@GraphTraversal(traversal = KeyAttributeTraversalBuilder.class, elementClass=PhysicalAttribute.class)
	private Iterable<PhysicalAttribute> keyAttributes;

	private static class KeyAttributeTraversalBuilder implements FieldTraversalDescriptionBuilder 
	{
		@Override
		public TraversalDescription build(Object start, Neo4jPersistentProperty props, String... params)
		{
			return Traversal.description().
					relationships(DynamicRelationshipType.withName(RELATIONSHIP_TYPE.PRIMARY_IDENTIFIER_OF.toString()), Direction.INCOMING).
					relationships(DynamicRelationshipType.withName(RELATIONSHIP_TYPE.KEY_ELEMENT_OF.toString()), Direction.INCOMING).					
					relationships(DynamicRelationshipType.withName(RELATIONSHIP_TYPE.MAKES_UP.toString()), Direction.INCOMING).
					evaluator(new NodeTypeEvaluator(PhysicalAttribute.class));
		}
	}

	
	public Iterable<JDBCChannel> getJdbcSourceChannels()
	{
		return jdbcSourceChannels;
	}

	public void setJdbcSourceChannels(Iterable<JDBCChannel> jdbcSourceChannels)
	{
		this.jdbcSourceChannels = jdbcSourceChannels;
	}
	
	
	@Fetch
	public Iterable<PhysicalAttribute> getAttributesOrderedByPosition()
	{
		return attributesOrderedByPosition;
	}

	@Override
	public int compareTo(PhysicalDataset otherDataset)
	{
		return this.name.compareTo(otherDataset.name);
	}
	
	@Override
	public boolean equals( Object otherDataset )
	{		
		return this.id.equals(((PhysicalDataset)otherDataset).id);
	}

	@Fetch
	public Iterable<PhysicalAttribute> getQueryableAttributesOrderedByPosition()
	{
		return queryableAttributesOrderedByPosition;
	}

	@Fetch
	public Iterable<PhysicalAttribute> getKeyAttributes()
	{
		return keyAttributes;
	}

	@Fetch
	public Iterable<String> getSourceURLs()
	{
		return sourceURLs;
	}

	@Fetch
	public String getPrimarySourceURL()
	{
		return primarySourceURL;
	}

	@Fetch
	public Transformer getIncomingTransformer()
	{
		return incomingTransformer;
	}

	public void setIncomingTransformer(Transformer incomingTransformer)
	{
		this.incomingTransformer = incomingTransformer;
	}

	@Fetch
	public Transformer getOutgoingTransformer()
	{
		return outgoingTransformer;
	}

	public void setOutgoingTransformer(Transformer outgoingTransformer)
	{
		this.outgoingTransformer = outgoingTransformer;
	}

	@Fetch
	public String getDeltaSourceURL()
	{
		return deltaSourceURL;
	}

	public void setDeltaSourceURL(String deltaSourceURL)
	{
		this.deltaSourceURL = deltaSourceURL;
	}

	public PhysicalAttribute getAttributeWithId( String attrId )
	{
		for( PhysicalAttribute pa : attributes )
		{
			if( pa.id.equals(attrId) )return pa;
		}
		
		throw new RuntimeException("Dataset '" + id + "' does not have an attribute with the id '" + attrId + "'");
	}
	

	
}
