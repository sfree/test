package com.ubs.idp.metadata.model;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;

@NodeEntity
public class Consumer extends BaseEntity
{
	/**
	 * The views that a consumer uses
	 */
	@RelatedTo(type = "INTERESTED_IN", direction = Direction.OUTGOING)
	public Set<View> views = new HashSet<View>();


	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}

}
