package com.ubs.idp.metadata.client;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.ubs.idp.base.IdpBoundary;
import com.ubs.idp.base.logging.Loggable;
import com.ubs.idp.base.utils.EncodingUtils;
import com.ubs.idp.metadata.model.JDBCChannel;
import com.ubs.idp.metadata.model.JMSChannel;
import com.ubs.idp.metadata.model.JoinRelation;
import com.ubs.idp.metadata.model.PhysicalDataset;
import com.ubs.idp.metadata.model.enums.RELATIONSHIP_TYPE;
import com.ubs.idp.metadata.model.exceptions.MetadataException;
import com.ubs.idp.metadata.model.relationships.JoinsRelationshipType;

@Component("neo4jMetadataService")
@IdpBoundary
public class Neo4jMetadataServiceImpl implements MetadataService {

    // Number of entities that can be stored in the cache
    public final static int DEFAULT_CACHE_SIZE = 10000;
    public final static int DEFAULT_BATCH_AMOUNT = 500;

    /**
     * Property placeholder in the metadata URLs to indicate that the fields to
     * fetch are a parameterised list that should be derived from the dataset in
     * the metatdata and encoded
     */
    public final static String ADD_ENCODED_FIELDS = "${ADD_ENCODED_FIELDS}";

    /**
     * Property placeholder in the metadata URLs to indicate that the fields to
     * fetch are a parameterised list that should be derived from the dataset in
     * the metatdata
     */
    public final static String ADD_FIELDS = "${ADD_FIELDS}";
    private static final String DUMMY_JOIN_RELATION_PREFIX = "DummyJoinRelation.";

    private static Logger logger = LoggerFactory.getLogger(Neo4jMetadataServiceImpl.class);

    @Autowired
    private Neo4jUtils neo4jUtils;

    @Override
    @Cacheable("getSQLQueryForDataset")
    public @Loggable String getSQLQueryForDataset(@Loggable String datasetId) {
        String querySQL = "";
        String cypherQuery = "match (d:Dataset {id:{id}})<-[:" + RELATIONSHIP_TYPE.PROVIDES + "]-(si:ServiceImplementation)-[r:"
                + RELATIONSHIP_TYPE.ACCESSED_VIA + "]->(c:JDBCChannel) return c.querySQL";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " with an associated JDBCChannel (Query=["
                    + cypherQuery + "] Params=" + params + ")");
        }
        Map<String, Object> row = result.next();
        querySQL = row.get("c.querySQL").toString();

        return querySQL;
    }

    @Override
    @Cacheable("getSQLDeltaQueryForDataset")
    public @Loggable String getSQLDeltaQueryForDataset(@Loggable String datasetId) {
        String querySQLDelta = "";
        String cypherQuery = "match (d:Dataset {id:{id}})<-[:" + RELATIONSHIP_TYPE.PROVIDES + "]-(si:ServiceImplementation)-[r:"
                + RELATIONSHIP_TYPE.ACCESSED_VIA + "]->(c:JDBCChannel) return c.queryDeltaSQL";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " with an associated JDBCChannel (Query=["
                    + cypherQuery + "] Params=" + params + ")");
        }
        Map<String, Object> row = result.next();
        Object value = row.get("c.queryDeltaSQL");
        if (value == null) {
            throw new MetadataException("No value set for field 'queryDeltaSQL' in channel. (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }
        querySQLDelta = value.toString();

        return querySQLDelta;
    }

    @Override
    @Cacheable("getAttributePositionsForDataset")
    public Map<String, Integer> getAttributePositionsForDataset(@Loggable String datasetId) {
        Map<String, Integer> attributePositions = new HashMap<String, Integer>();

        String cypherQuery = "match (d:Dataset {id:{id}})-[r:OWNS|:SELECTS]->(pa:PhysicalAttribute) return pa.position,pa.id,r.position,r.viewAttributeName order by r.position,pa.position ASC";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();

            // Is it a view
            Object viewAttributeName = row.get("r.viewAttributeName");
            if (viewAttributeName != null) {
                attributePositions.put(viewAttributeName.toString(), Integer.parseInt(row.get("r.position").toString()));
            } else {
                attributePositions.put(row.get("pa.id").toString(), Integer.parseInt(row.get("pa.position").toString()));
            }
        }
        return attributePositions;
    }

    @Override
    @Cacheable("getDelimiter")
    public String getDelimiter(@Loggable String datasetId) {
        String delimiter = null;
        String cypherQuery = "match (d:Dataset {id:{id}}) return d.delimiter";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        Object delimeterObj = result.next().get("d.delimiter");
        if (delimeterObj == null) {
            throw new MetadataException("Dataset with id=" + datasetId + " does not have a value set for property 'delimiter'");
        }
        delimiter = delimeterObj.toString();
        return delimiter;
    }

    @Override
    @Cacheable("getJobNamesForDataset")
    public List<String> getJobNamesForDataset(@Loggable String datasetId) {
        List<String> jobNames = new ArrayList<String>();
        List<JoinRelation> joinRelations = getJoinRelationsForDataset(datasetId);
        for (JoinRelation joinRelation : joinRelations) {
        	for(PhysicalDataset physicalDataset: joinRelation.getOrderedDatasets()) {
        		String cypherQuery = "match (d:Dataset {id:{id}}) return d.jobs";
        		Map<String, Object> params = new HashMap<String, Object>();
        		params.put("id", physicalDataset.id);
        		
        		Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        		if (!result.hasNext()) {
        			throw new MetadataException("Failed to find dataset with id=" + physicalDataset.id + " (Query=[" + cypherQuery + "] Params=" + params
        					+ ")");
        		}
        		
        		Object jobsObj = result.next().get("d.jobs");
        		if (jobsObj == null) {
        			return jobNames;
        		}
        		
        		Scanner jobsScanner = new Scanner(jobsObj.toString());
        		jobsScanner.useDelimiter(",");
        		
        		while (jobsScanner.hasNext()) {
        			String dataset = jobsScanner.next();
        			if(!jobNames.contains(dataset)) {
        				jobNames.add(dataset);
        			}
        		}
        		jobsScanner.close();
        	}
        }
        return jobNames;
    }

    @Override
    @Cacheable("getSourceUrlsForDataset")
    public List<String> getSourceUrlsForDataset(@Loggable String datasetId) {
        List<String> urls = new ArrayList<String>();
        String cypherQuery = "match (d:Dataset {id:{id}})<-[:" + RELATIONSHIP_TYPE.PROVIDES + "]-(si:ServiceImplementation)-[r:"
                + RELATIONSHIP_TYPE.ACCESSED_VIA + "]->(c:Channel) return c.url";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            Object value = row.get("c.url");
            if (value == null) {
                throw new MetadataException("The channel for datatset " + datasetId + " does not a value set for property 'url'");
            }
            urls.add(encodeDatasetFieldsForURL(value.toString(), datasetId));
        }
        return urls;
    }

    @Override
    @Cacheable("getSourceDeltaUrlForDataset")
    public @Loggable String getSourceDeltaUrlForDataset(@Loggable String datasetId) {
        String url = null;
        String cypherQuery = "match (d:Dataset {id:{id}})<-[:" + RELATIONSHIP_TYPE.PROVIDES + "]-(si:ServiceImplementation)-[r:"
                + RELATIONSHIP_TYPE.ACCESSED_VIA + "]->(c:HTTPChannel) return c.deltaUrl";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }
        Map<String, Object> row = result.next();
        Object value = row.get("c.deltaUrl");
        if (value == null) {
            throw new MetadataException("The channel for datatset " + datasetId + " does not a value set for property 'deltaUrl'");
        }

        url = encodeDatasetFieldsForURL(value.toString(), datasetId);
        return url;

    }

    @Override
    @Cacheable("getSourceUrlsForAllDatasets")
    public Map<String, List<String>> getSourceUrlsForAllDatasets() {
        Map<String, List<String>> sourceUrls = new HashMap<String, List<String>>();
        String cypherQuery = "match (d:Dataset)<-[:" + RELATIONSHIP_TYPE.PROVIDES + "]-(si:ServiceImplementation)-[r:"
                + RELATIONSHIP_TYPE.ACCESSED_VIA + "]->(c:Channel {protocol:'http'}) return d.id,c.url";
        Map<String, Object> params = new HashMap<String, Object>();

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find any Channels with a URL for any datasets! (Query=[" + cypherQuery + "] Params="
                    + params + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            String id = row.get("d.id").toString();

            List<String> urls = sourceUrls.get(id);
            if (urls == null) {
                urls = new ArrayList<String>();
                sourceUrls.put(id, urls);
            }
            urls.add(encodeDatasetFieldsForURL(row.get("c.url").toString(), id));
        }
        return sourceUrls;
    }

    @Override
    @Cacheable("getNamespacesForDataset")
    public Map<String, String> getNamespacesForDataset(@Loggable String datasetId) {
        Map<String, String> namespacesMap = new HashMap<String, String>();
        String cypherQuery = "match (pd:PhysicalDataset {id:{id}}) return pd.namespaces";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        Map<String, Object> row = result.next();
        Object datasetNamespaceObj = row.get("pd.namespaces");
        if (datasetNamespaceObj != null) {
            String datasetNamespaces = datasetNamespaceObj.toString();
            String[] namespaces = datasetNamespaces.split(",");
            for (String namespace : namespaces) {
                if (namespace == null || namespace.trim().length() == 0) {
                    continue;
                }

                if (!namespace.contains("=")) {
                    throw new MetadataException("The namespace [" + namespace + "] for dataset with id=" + datasetId
                            + " does not contain a namespace prefix");
                }

                String[] prefix = namespace.split("=");
                namespacesMap.put(prefix[0], prefix[1]);
            }
        }
        return namespacesMap;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ubs.idp.metadata.service.MetadataService#getJoinRelationsForDataset
     * (java.lang.String)
     */
    @Cacheable("getJoinRelationsForDataset")
    public List<JoinRelation> getJoinRelationsForDataset(@Loggable String datasetId) {
        // If this dataset is View call the View specific method
        if (doesNodeWithIdHaveLabel(datasetId, "View")) {
            return getJoinRelationsForView(datasetId);
        } else {
            String cypherQuery = "match (pd:PhysicalDataset {id:{id}}) return pd.id,pd.name,pd.tableId";
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("id", datasetId);

            Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
            if (!result.hasNext()) {
                throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params="
                        + params + ")");
            }

            Map<String, Object> row = result.next();
            // Create a placeholder JoinRelation
            JoinRelation jr = new JoinRelation();
            jr.id = DUMMY_JOIN_RELATION_PREFIX + datasetId;
            jr.name = jr.id;

            PhysicalDataset pd = new PhysicalDataset();
            pd.id = row.get("pd.id").toString();
            pd.name = row.get("pd.name").toString();

            if (row.get("pd.tableId") == null) {
                throw new MetadataException("Dataset with id=" + pd.id + " in JoinRelation id=" + jr.id
                        + " does not have a value set for property 'tableId' (Query=[" + cypherQuery + "] Params=" + params + ")");
            }
            pd.tableId = row.get("pd.tableId").toString();
            // As we only have a single dataset we default the position at 0
            jr.datasets.add(new JoinsRelationshipType(jr, pd, 0));
            return Arrays.asList(jr);
        }
    }

    @Override
    @Cacheable("getJoinRelationsForView")
    public List<JoinRelation> getJoinRelationsForView(@Loggable String viewId) {
        List<JoinRelation> joinRelations = new ArrayList<JoinRelation>();
        String cypherQuery = "match (v:View {id:{id}})-[r:" + RELATIONSHIP_TYPE.REPRESENTED_AS + "]->(jr:JoinRelation)-[jt:"
                + RELATIONSHIP_TYPE.JOINS
                + "]->(d:Dataset) return jr.id,jr.name,d.id,d.name,d.tableId,jt.joinPosition ORDER BY jr.position,jt.joinPosition";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", viewId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find view with id=" + viewId + " that has any JoinRelations associated with it (Query=["
                    + cypherQuery + "] Params=" + params + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            String id = row.get("jr.id").toString();

            JoinRelation jr = null;
            // Check if we have already created this join relation
            for (JoinRelation existingJr : joinRelations) {
                if (existingJr.id.equals(id)) {
                    jr = existingJr;
                    break;
                }
            }

            // If not create a new one
            if (jr == null) {
                jr = new JoinRelation();
                jr.id = id;
                jr.name = row.get("jr.name").toString();
                joinRelations.add(jr);
            }
            PhysicalDataset pd = new PhysicalDataset();
            pd.id = row.get("d.id").toString();
            pd.name = row.get("d.name").toString();

            if (row.get("d.tableId") == null) {
                throw new MetadataException("Dataset with id=" + pd.id + " in JoinRelation id=" + jr.id
                        + " does not have a value set for property 'tableId' (Query=[" + cypherQuery + "] Params=" + params + ")");
            }
            pd.tableId = row.get("d.tableId").toString();
            int joinPosition = Integer.parseInt(row.get("jt.joinPosition").toString());
            jr.datasets.add(new JoinsRelationshipType(jr, pd, joinPosition));
        }
        return joinRelations;
    }

    @Override
    @Cacheable("getAllRelations")
    public Map<String, List<JoinRelation>> getAllRelations() {
        Map<String, List<JoinRelation>> viewRelations = new HashMap<String, List<JoinRelation>>();
        String cypherQuery = "match (v:View)-[r:" + RELATIONSHIP_TYPE.REPRESENTED_AS + "]->(jr:JoinRelation)-[jt:"
                + RELATIONSHIP_TYPE.JOINS
                + "]->(d:Dataset) return v.id,jr.id,jr.name,d.id,d.name,d.tableId,jt.joinPosition ORDER BY v.id,jr.id,jt.joinPosition";
        Map<String, Object> params = new HashMap<String, Object>();
        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find any views that have a JoinRelations associated with it (Query=[" + cypherQuery
                    + "] Params=" + params + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            String viewId = row.get("v.id").toString();
            List<JoinRelation> joinRelations = viewRelations.get(viewId);
            if (joinRelations == null) {
                joinRelations = new ArrayList<JoinRelation>();
                viewRelations.put(viewId, joinRelations);
            }
            String jrId = row.get("jr.id").toString();
            JoinRelation jr = null;
            for (JoinRelation currentJr : joinRelations) {
                if (currentJr.id.equals(jrId)) {
                    jr = currentJr;
                    break;
                }
            }

            if (jr == null) {
                jr = new JoinRelation();
                jr.id = jrId;
                jr.name = row.get("jr.name").toString();
                joinRelations.add(jr);
            }
            PhysicalDataset pd = new PhysicalDataset();
            pd.id = row.get("d.id").toString();
            pd.name = row.get("d.name").toString();
            if (row.get("d.tableId") == null) {
                throw new MetadataException("Dataset with id=" + pd.id + " in JoinRelation id=" + jr.id
                        + " does not have a value set for property 'tableId' (Query=[" + cypherQuery + "] Params=" + params + ")");
            }
            pd.tableId = row.get("d.tableId").toString();
            int joinPosition = Integer.parseInt(row.get("jt.joinPosition").toString());
            jr.datasets.add(new JoinsRelationshipType(jr, pd, joinPosition));
        }
        return viewRelations;
    }

    @Override
    @Cacheable("getAttributeNamesForDataset")
    public List<String> getAttributeNamesForDataset(@Loggable String datasetId) {
        List<String> attributeNames = new ArrayList<String>();
        String cypherQuery = "match (d:Dataset {id:{id}})-[r:OWNS|:SELECTS]->(pa:PhysicalAttribute) return pa.name,r.viewAttributeName order by r.position,pa.position ASC";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();

            // Is it a view
            Object viewAttributeName = row.get("r.viewAttributeName");
            if (viewAttributeName != null) {
                if (!attributeNames.contains(viewAttributeName.toString()))
                    attributeNames.add(viewAttributeName.toString());
            } else {
                String value = row.get("pa.name").toString();
                if (!attributeNames.contains(value))
                    attributeNames.add(value);
            }
        }
        return attributeNames;
    }

    @Override
    @Cacheable("getAttributeIdsForDataset")
    public List<String> getAttributeIdsForDataset(@Loggable String datasetId) {
        List<String> attributeNames = new ArrayList<String>();
        String cypherQuery = "match (d:Dataset {id:{id}})-[r:OWNS|:SELECTS]->(pa:PhysicalAttribute) return pa.id,r.viewAttributeName order by r.position,pa.position ASC";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();

            // Is it a view
            Object viewAttributeName = row.get("r.viewAttributeName");
            if (viewAttributeName != null) {
                attributeNames.add(viewAttributeName.toString());
            } else {
                attributeNames.add(row.get("pa.id").toString());
            }
        }
        return attributeNames;
    }

    @Override
    @Cacheable("getAttributeNamesForPhysicalDataset")
    public List<String> getAttributeNamesForPhysicalDataset(@Loggable String datasetId) {
        List<String> attributeNames = new ArrayList<String>();
        String cypherQuery = "match (pd:PhysicalDataset {id:{id}})-[:OWNS]->(pa:PhysicalAttribute) return pa.name order by pa.position ASC";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        while (result.hasNext()) {
            attributeNames.add(result.next().get("pa.name").toString());
        }
        return attributeNames;
    }

    @Override
    @Cacheable("getAttributeXpathsForPhysicalDataset")
    public List<String> getAttributeXpathsForPhysicalDataset(@Loggable String datasetId) {
        List<String> attributeXpaths = new ArrayList<String>();

        String cypherQuery = "match (pd:PhysicalDataset {id:{id}})-[:OWNS]->(pa:PhysicalAttribute) return pa.xpath order by pa.position ASC";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        while (result.hasNext()) {
            attributeXpaths.add(result.next().get("pa.xpath").toString());
        }
        return attributeXpaths;
    }

    @Override
    @Cacheable("getAllDatasetAndAttributeNames")
    public Map<String, List<String>> getAllDatasetAndAttributeNames() {
        Map<String, List<String>> datasets = new HashMap<String, List<String>>();

        // First get a count
        String cypherQuery = "match (d:Dataset)-[r:OWNS|:SELECTS]->(pa:PhysicalAttribute) return count(*) as count";
        Map<String, Object> params = new HashMap<String, Object>();
        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find any datasets or attriutes?! (Query=[" + cypherQuery + "] Params=" + params + ")");
        }
        int count = Integer.parseInt(result.next().get("count").toString());
        int skip = 0;

        while (skip < count) {
            cypherQuery = "match (d:Dataset)-[r:OWNS|:SELECTS]->(pa:PhysicalAttribute) return d.id,pa.id,r.viewAttributeName order by r.position,pa.position ASC skip {skipValue} limit {limitValue}";
            params.put("skipValue", skip);
            params.put("limitValue", DEFAULT_BATCH_AMOUNT);

            if (logger.isDebugEnabled())
                logger.debug("Fetching " + skip + " to " + (skip + DEFAULT_BATCH_AMOUNT) + " of all dataset and attribute names");
            result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
            if (!result.hasNext()) {
                throw new MetadataException("Failed to find any datasets or attriutes?! (Query=[" + cypherQuery + "] Params=" + params
                        + ")");
            }

            while (result.hasNext()) {
                Map<String, Object> row = result.next();
                String id = row.get("d.id").toString();

                List<String> attributes = datasets.get(id);
                if (attributes == null) {
                    attributes = new ArrayList<String>();
                    datasets.put(id, attributes);
                }

                // Is it a view
                Object viewAttributeName = row.get("r.viewAttributeName");
                if (viewAttributeName != null) {
                    attributes.add(viewAttributeName.toString());
                } else {
                    attributes.add(row.get("pa.id").toString());
                }
            }
            skip += DEFAULT_BATCH_AMOUNT;
        }
        return datasets;
    }

    @Override
    @Cacheable("getDatasetKeyAttributePositions")
    public List<Integer> getDatasetKeyAttributePositions(@Loggable String datasetId) {
        List<Integer> attibutePositions = new ArrayList<Integer>();

        String cypherQuery = "match (d:Dataset {id:{id}})-[r:OWNS|:SELECTS]->(pa:PhysicalAttribute)-[:" + RELATIONSHIP_TYPE.MAKES_UP
                + "]->(pke:PhysicalKeyElement) return pa.position,r.position order by r.position,pa.position ASC";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();

            // Is it a view
            Object viewAttributeName = row.get("r.position");
            if (viewAttributeName != null) {
                attibutePositions.add(Integer.parseInt(viewAttributeName.toString()));
            } else {
                attibutePositions.add(Integer.parseInt(row.get("pa.position").toString()));
            }
        }
        return attibutePositions;
    }

    @Override
    @Cacheable("getQueryableAttributePositionsForDataset")
    public List<Integer> getQueryableAttributePositionsForDataset(@Loggable String datasetId) {
        List<Integer> attibutePositions = new ArrayList<Integer>();

        String cypherQuery = "match (d:Dataset {id:{id}})-[r:OWNS|:SELECTS]->(pa:PhysicalAttribute {queryable:true}) return pa.position,r.position order by r.position,pa.position ASC";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();

            // Is it a view
            Object viewAttributeName = row.get("r.position");
            if (viewAttributeName != null) {
                attibutePositions.add(Integer.parseInt(viewAttributeName.toString()));
            } else {
                attibutePositions.add(Integer.parseInt(row.get("pa.position").toString()));
            }
        }
        return attibutePositions;
    }

    @Override
    @Cacheable("getRolesForDataset")
    public List<String> getRolesForDataset(@Loggable String datasetId) {
        List<String> roleNames = new ArrayList<String>();

        String cypherQuery = "match (d:Dataset {id:{id}})-[r:" + RELATIONSHIP_TYPE.REQUIRES + "]->(ro:Role) return ro.id";
        Map<String, Object> params = new HashMap<String, Object>();

        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " that has any roles associated with it (Query=["
                    + cypherQuery + "] Params=" + params + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            roleNames.add(row.get("ro.id").toString());
        }
        return roleNames;
    }

    @Override
    @Cacheable("getDatabaseDetailsForDataset")
    public JDBCChannel getDatabaseDetailsForDataset(@Loggable String datasetId) {
        String cypherQuery = "match (d:Dataset {id:{id}})<-[:" + RELATIONSHIP_TYPE.PROVIDES + "]-(si:ServiceImplementation)-[r:"
                + RELATIONSHIP_TYPE.ACCESSED_VIA
                + "]->(c:JDBCChannel) return c.driverClass,c.id,c.name,c.password,c.username,c.querySQL,c.url";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " with an associated JDBCChannel (Query=["
                    + cypherQuery + "] Params=" + params + ")");
        }
        Map<String, Object> row = result.next();

        JDBCChannel channel = new JDBCChannel();
        channel.driverClass = row.get("c.driverClass").toString();
        channel.url = row.get("c.url").toString();
        channel.id = row.get("c.id").toString();
        channel.name = row.get("c.name").toString();
        channel.password = row.get("c.password").toString();
        channel.username = row.get("c.username").toString();
        channel.querySQL = row.get("c.querySQL").toString();
        return channel;
    }

    @Override
    @Cacheable("getPrimarySourceUrlForDataset")
    public @Loggable String getPrimarySourceUrlForDataset(@Loggable String datasetId) {
        String url = null;
        String cypherQuery = "match (d:Dataset {id:{id}})<-[:" + RELATIONSHIP_TYPE.PROVIDES + "]-(si:ServiceImplementation)-[r:"
                + RELATIONSHIP_TYPE.ACCESSED_VIA + "]->(c:Channel {protocol:'http'}) where r.priority=1 return c.url";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);
        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }
        Map<String, Object> row = result.next();
        url = encodeDatasetFieldsForURL(row.get("c.url").toString(), datasetId);
        return url;
    }

    @Override
    @Cacheable("getTransformerRulesetsForDataset")
    public List<String> getTransformerRulesetsForDataset(@Loggable String datasetId) {
        List<String> ruleSets = new ArrayList<String>();
        String cypherQuery = "match (d:Dataset {id:{id}})-[:SOURCE_OF]->(rt:RulesTransformer) return rt.ruleset";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId
                    + " or the dataset does not have a RulesTransformer associated with it (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        Map<String, Object> props = result.next();
        if (props.containsKey("rt.ruleset")) {
            Object value = props.get("rt.ruleset");
            if (value != null) {
                String ruleSet = props.get("rt.ruleset").toString();
                ruleSets = Arrays.asList(ruleSet.split(","));
            }
        }

        return ruleSets;
    }

    @Override
    @Cacheable("getTransformerRulesetsForDatasets")
    public List<String> getTransformerRulesetsForDatasets(@Loggable String srcDatasetId, String targetDatasetId) {
        List<String> ruleSets = new ArrayList<String>();
        String cypherQuery = "match (sd:Dataset {id:{sd}})-[:SOURCE_OF]->(rt:RulesTransformer)<-[:TARGET_OF]-(td:Dataset {id:{td}}) return rt.ruleset";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("sd", srcDatasetId);
        params.put("td", targetDatasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find source dataset with id=" + srcDatasetId + " or target dataset with id="
                    + targetDatasetId + " or the dataset does not have a RulesTransformer associated with it (Query=[" + cypherQuery
                    + "] Params=" + params + ")");
        }

        Map<String, Object> props = result.next();
        if (props.containsKey("rt.ruleset")) {
            Object value = props.get("rt.ruleset");
            if (value != null) {
                String ruleSet = props.get("rt.ruleset").toString();
                ruleSets = Arrays.asList(ruleSet.split(","));
            }
        }

        return ruleSets;
    }

    @Override
    @Cacheable("getSourceAuthenticationUriForDataset")
    public @Loggable String getSourceAuthenticationUriForDataset(@Loggable String datasetId) {
        String url = "";

        String cypherQuery = "match (d:Dataset {id:{id}})<-[:" + RELATIONSHIP_TYPE.PROVIDES + "]-(si:ServiceImplementation)-[r:"
                + RELATIONSHIP_TYPE.ACCESSED_VIA + "]->(c:HTTPChannel) return c.authenticationUri";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId
                    + " that has a HTTPChannel with an authenticationUri (Query=[" + cypherQuery + "] Params=" + params + ")");
        }

        Map<String, Object> row = result.next();
        Object urlResult = row.get("c.authenticationUri");
        if (urlResult != null) {
            url = encodeDatasetFieldsForURL(urlResult.toString(), datasetId);
        }
        return url;
    }

    @Override
    @Cacheable("getUrlForChannel")
    public @Loggable String getUrlForChannel(@Loggable String channelId) {
        // Default to main url
        return getUrlForChannel(channelId, false);
    }

    @Override
    @Cacheable("getUrlForChannel")
    public @Loggable String getUrlForChannel(@Loggable String channelId, boolean isDelta) {
        String url = null;
        String urlAttr = "c.url";

        if (isDelta) {
            urlAttr = "c.deltaUrl";
        }

        String cypherQuery = "match (c:Channel {id:{id}})<-[:" + RELATIONSHIP_TYPE.ACCESSED_VIA + "]-(si:ServiceImplementation)-[:"
                + RELATIONSHIP_TYPE.PROVIDES + "]->(pd:PhysicalDataset) return " + urlAttr + ",pd.id";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", channelId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find channel with id=" + channelId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        Map<String, Object> row = result.next();

        Object urlValue = row.get(urlAttr);

        if (urlValue == null) {
            throw new MetadataException("Channel with id=" + channelId + " does not have a value set for property '" + urlAttr
                    + "' (Query=[" + cypherQuery + "] Params=" + params + ")");
        }

        url = encodeDatasetFieldsForURL(urlValue.toString(), row.get("pd.id").toString());

        return url;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ubs.idp.metadata.service.MetadataService#getJoinKeysForDatasetIds
     * (java.lang.String, java.lang.String)
     */
    @Override
    @Cacheable("getJoinKeysForDatasetIds")
    public List<String> getJoinKeysForDatasetIds(@Loggable String datasetId1, String datasetId2) {
        List<String> attributeIds = new ArrayList<String>();
        String cypherQuery = "MATCH (pd1:PhysicalDataset {id:{datasetId1}})-[:" + RELATIONSHIP_TYPE.OWNS + "]->(pa1:PhysicalAttribute)<-[:"
                + RELATIONSHIP_TYPE.JOINED_TO + "]->(pa2:PhysicalAttribute)<-[:" + RELATIONSHIP_TYPE.OWNS
                + "]-(pd2:PhysicalDataset {id:{datasetId2}}) return pa1.id,pa2.id";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("datasetId1", datasetId1);
        params.put("datasetId2", datasetId2);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find any attributes joined between dataset with id=" + datasetId1
                    + " and dataset with id=" + datasetId2 + " (Query=[" + cypherQuery + "] Params=" + params + ")");
        }
        Map<String, Object> row = result.next();
        attributeIds.add(row.get("pa1.id").toString());
        attributeIds.add(row.get("pa2.id").toString());
        return attributeIds;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ubs.idp.metadata.service.MetadataService#getTableIdForDataset(java
     * .lang.String)
     */
    @Override
    @Cacheable("getTableIdForDataset")
    public @Loggable String getTableIdForDataset(@Loggable String datasetId) {
        Object tableId = null;

        String cypherQuery = "match (pd:PhysicalDataset {id:{id}}) return pd.tableId";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        Map<String, Object> row = result.next();
        tableId = row.get("pd.tableId");

        if (tableId == null) {
            throw new MetadataException("Dataset with id=" + datasetId + " does not have a value set for property 'tableId' (Query=["
                    + cypherQuery + "] Params=" + params + ")");
        }
        return tableId.toString();
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ubs.idp.metadata.service.MetadataService#generateSQLInsertForDataset
     * (java.lang.String)
     */
    @Override
    @Cacheable("generateSQLInsertForDataset")
    public @Loggable String generateSQLInsertForDataset(@Loggable String datasetId) {
        String insertSQL = "INSERT INTO " + getTableIdForDataset(datasetId);

        // Get list of attribute names and get as a string of comma separated
        // list
        List<String> attributes = getAttributeIdsForDataset(datasetId);

        String columnNames = "";
        String valueNames = "";

        for (String attr : attributes) {
            columnNames += "\"" + attr.replace('/', '_') + "\",";
            valueNames += ":" + attr.replace('/', '_') + ",";
        }
        columnNames = columnNames.substring(0, columnNames.length() - 1);
        valueNames = valueNames.substring(0, valueNames.length() - 1);

        insertSQL += "(" + columnNames + ") VALUES (" + valueNames + ")";

        return insertSQL;
    }

    /**
     * Returns all Service Implementations for given source
     *
     * @param sourceId
     * @return
     */
    @Override
    @Cacheable("getAllServiceImplementationsForSource")
    public List<String> getAllServiceImplementationsForSource(@Loggable String sourceId) {

        List<String> serviceNames = new ArrayList<>();
        String cypherQuery = "MATCH (so:Source {id:{id}}) - [:" + RELATIONSHIP_TYPE.OFFERS + "] -> (s:Service) - [:"
                + RELATIONSHIP_TYPE.IMPLEMENTED_BY + "] -> (si:ServiceImplementation) RETURN si.id";
        Map<String, Object> params = new HashMap<>();
        params.put("id", sourceId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find Service Implementation for source id=" + sourceId + " (Query=[" + cypherQuery
                    + "] Params=" + params + ")");
        }
        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            serviceNames.add(row.get("si.id").toString());
        }
        return serviceNames;
    }

    @Override
    @Cacheable("getServiceImplementations")
    public List<String> getServiceImplementations(@Loggable String serviceId) {

        List<String> serviceNames = new ArrayList<>();
        String cypherQuery = "MATCH (s:Service {id:{id}})- [:" + RELATIONSHIP_TYPE.IMPLEMENTED_BY
                + "] ->(si:ServiceImplementation) RETURN si.name";
        Map<String, Object> params = new HashMap<>();
        params.put("id", serviceId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find Service Implementation with service id=" + serviceId + " (Query=[" + cypherQuery
                    + "] Params=" + params + ")");
        }
        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            serviceNames.add(row.get("si.name").toString());
        }
        return serviceNames;
    }

    /**
     * Returns data set details for given service implementation
     *
     * @param serviceImplId
     * @return
     */
    @Override
    @Cacheable("getDataSetDetails")
    public Map<String, List<String>> getDataSetDetails(@Loggable String serviceImplId) {

        Map<String, List<String>> resultSetDetails = new HashMap<>();
        String cypherQuery = "MATCH (si:ServiceImplementation {id:{id}}) - [:" + RELATIONSHIP_TYPE.PROVIDES
                + "] -> (d1:PhysicalDataset) - [:" + RELATIONSHIP_TYPE.OWNS + "] -> (pa:PhysicalAttribute) " + " RETURN d1.name, pa.name";

        Map<String, Object> parameterMap = getParameterMap("id", serviceImplId);
        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, parameterMap);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find Result Sets for Service with id=" + serviceImplId + " (Query=[" + cypherQuery
                    + "] Params=" + parameterMap + ")");
        }
        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            String id = row.get("d1.name").toString();

            List<String> attributes = resultSetDetails.get(id);
            if (attributes == null) {
                attributes = new ArrayList<String>();
                resultSetDetails.put(id, attributes);
            }
            attributes.add(row.get("pa.name").toString());
        }
        return resultSetDetails;
    }

    /**
     * Returns required data set attributes for given service implementation
     *
     * @param serviceImplId
     * @return
     */
    @Override
    @Cacheable("getRequiredDataSetAttributes")
    public Map<String, String> getRequiredDataSetAttributes(@Loggable String serviceImplId) {

        Map<String, String> eventDataAttributes = new HashMap<>();
        String cypherQuery = "MATCH (si:ServiceImplementation {id:{id}}) - [:" + RELATIONSHIP_TYPE.REQUIRES
                + "] - > (d:PhysicalDataset) - [:" + RELATIONSHIP_TYPE.OWNS + "] -> (pa: PhysicalAttribute) RETURN pa.name;";
        Map<String, Object> parameterMap = getParameterMap("id", serviceImplId);
        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, parameterMap);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find event data for Service with id=" + serviceImplId + " (Query=[" + cypherQuery
                    + "] Params=" + parameterMap + ")");
        }
        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            String attributeName = row.get("pa.name").toString();
            eventDataAttributes.put(attributeName, attributeName);
        }
        return eventDataAttributes;

    }

    /**
     * Returns stored procedure details for given service implementation
     *
     * @param serviceImplId
     * @return
     */
    @Override
    @Cacheable("getStoredProcedureDetails")
    public Map<String, Map<String, Map<String, Object>>> getStoredProcedureDetails(@Loggable String serviceImplId) {

        Map<String, Map<String, Map<String, Object>>> storedProcedureDetails = new HashMap<>();
        String cypherQuery = "MATCH (si:ServiceImplementation {id:{id}}) - [:" + RELATIONSHIP_TYPE.REQUIRES + "] -> (r:Routine) - ["
                + RELATIONSHIP_TYPE.REQUIRES + "] - (p:PhysicalParameter)"
                + " return r.name, p.id, p.name, p.type, p.position order by p.position ASC";

        Map<String, Object> parameterMap = getParameterMap("id", serviceImplId);
        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, parameterMap);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find Stored Procedure details for Service with id=" + serviceImplId + " (Query=["
                    + cypherQuery + "] Params=" + parameterMap + ")");
        }
        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            String id = row.get("r.name").toString();

            Map<String, Map<String, Object>> cols = storedProcedureDetails.get(id);
            if (cols == null) {
                cols = new LinkedHashMap<>();
                storedProcedureDetails.put(id, cols);
            }
            Map<String, Object> colsNameValuePair = getParameterMap("name", row.get("p.name"));
            colsNameValuePair.put("type", row.get("p.type"));
            colsNameValuePair.put("position", row.get("p.position"));
            cols.put(row.get("p.id").toString(), colsNameValuePair);
        }
        return storedProcedureDetails;
    }

    /**
     * Returns JMS channel details for given channel Id
     *
     * @param jmsChannelId
     * @return
     */
    @Override
    @Cacheable("getJMSChannelDetails")
    public JMSChannel getJMSChannelDetails(@Loggable String jmsChannelId) {

        String cypherQuery = "match (ch:JMSChannel {id:{id}}) return ch.id, ch.name, ch.password, ch.user, ch.port, ch.url, ch.transportType, ch.queueManager, ch.channel,ch.SSLCipherSuite,ch.targetClient";
        Map<String, Object> parameterMap = getParameterMap("id", jmsChannelId);
        Iterator<Map<String, Object>> result =neo4jUtils.executeCypherQueryForObjects(cypherQuery, parameterMap);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find channel with  id=" + jmsChannelId + " (Query=[" + cypherQuery
                    + "] Params=" + parameterMap + ")");
        }
        JMSChannel jmsChannel = new JMSChannel();
        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            jmsChannel.name = row.get("ch.name") != null ? row.get("ch.name").toString() : null;
            jmsChannel.url = row.get("ch.url") != null ? row.get("ch.url").toString(): null;
            jmsChannel.user = row.get("ch.user") != null ? row.get("ch.user").toString() : null;
            jmsChannel.port = row.get("ch.port") != null ? row.get("ch.port").toString() : null;
            jmsChannel.password = row.get("ch.password") != null ? row.get("ch.password").toString() : null;
            jmsChannel.transportType = row.get("ch.transportType") != null ? row.get("ch.transportType").toString() : null;
            jmsChannel.queueManager = row.get("ch.queueManager") != null ? row.get("ch.queueManager").toString() : null;
            jmsChannel.channel = row.get("ch.channel") != null ? row.get("ch.channel").toString() : null;
            jmsChannel.SSLCipherSuite = row.get("ch.SSLCipherSuite") != null ? row.get("ch.SSLCipherSuite").toString() : null;
            jmsChannel.targetClient = row.get("ch.targetClient") != null ? row.get("ch.targetClient").toString() : null;
        }
        return jmsChannel;
    }

    @Override
    @Cacheable("getJdbcChannelDetailsWithId")
    public JDBCChannel getJdbcChannelDetailsWithId(@Loggable String channelId) {

        String cypherQuery = "match (c:JDBCChannel {id:{id}}) return c.driverClass, c.id,c.name, c.password, c.username, c.querySQL, c.url";
        Map<String, Object> params = new HashMap<>();
        params.put("id", channelId);
        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find channel with id=" + channelId + " with an associated JDBCChannel (Query=["
                    + cypherQuery + "] Params=" + params + ")");
        }
        Map<String, Object> row = result.next();
        JDBCChannel channel = new JDBCChannel();
        channel.driverClass = row.get("c.driverClass").toString();
        channel.url = row.get("c.url").toString();
        channel.id = row.get("c.id").toString();
        channel.name = row.get("c.name").toString();
        channel.password = row.get("c.password").toString();
        channel.username = row.get("c.username").toString();
        // channel.querySQL = row.get("c.querySQL").toString();
        return channel;
    }

    private Map<String, Object> getParameterMap(String name, Object value) {

        Map<String, Object> params = new HashMap<>();
        params.put(name, value);
        return params;
    }

    /**
     * returns a generic map.Call this function and handle the output as per
     * your JSON structure(as per depth of maps used)
     */
    @Override
    @Cacheable("getDataSetTransformationMappings")
    public Map<String, Map<String, String>> getDataSetTransformationMappings(@Loggable String serviceImplId) {

        String mappings = null;
        String cypherQuery = "MATCH (si:ServiceImplementation {id:{id}}) - [:" + RELATIONSHIP_TYPE.PROVIDES
                + "] -> (d1:PhysicalDataset) <- [:" + RELATIONSHIP_TYPE.SOURCE_OF + "] - (t:Transformer) RETURN t.attributesMapping";
        Map<String, Object> params = new HashMap<>();
        params.put("id", serviceImplId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find transformation mappings with service id=" + serviceImplId + " (Query=["
                    + cypherQuery + "] Params=" + params + ")");
        }
        Map<String, Map<String, String>> map = new HashMap<String, Map<String, String>>();
        if (result.hasNext()) {
            Map<String, Object> row = result.next();
            Gson gson = new Gson();
            mappings = row.get("t.attributesMapping").toString();
            map = gson.fromJson(mappings, map.getClass());
        }
        return map;
    }

    /**
     * returns a generic map.Call this function and handle the output as per
     * your JSON structure(as per depth of maps used)
     */
    @Override
    @Cacheable("getTransformationMappingforView")
    public Map<String, Map<String, String>> getTransformationMappingforView(@Loggable String viewId) {

        String mappings = null;
        String cypherQuery = "MATCH (vi:View {id:{id}}) - [:" + RELATIONSHIP_TYPE.SELECTS + "] -> (d1:Dataset) - "
        		+ "[*1..3] - (t:FieldLevelTransformer) RETURN t.attributesMapping";
        Map<String, Object> params = new HashMap<>();
        params.put("id", viewId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find Transformer with service id=" + viewId + " (Query=[" + cypherQuery + "] Params="
                    + params + ")");
        }
        Map<String, Map<String, String>> map = new HashMap<String, Map<String, String>>();
        if (result.hasNext()) {
            Map<String, Object> row = result.next();
            Gson gson = new Gson();
            mappings = row.get("t.attributesMapping").toString();
            map = gson.fromJson(mappings, map.getClass());
        }
        return map;
    }
    
    /**
     * returns a generic map.Call this function and handle the output as per
     * your JSON structure(as per depth of maps used)
     */
    @Override
    @Cacheable("getXsltStylesheetForView")
    public String getXsltStylesheetForView(@Loggable String viewId) {

    	String stylesheet = null;
        String cypherQuery = "MATCH (vi:View {id:{id}}) - [:" + RELATIONSHIP_TYPE.SELECTS + "] -> (d1:Dataset) <- ["
        		+ RELATIONSHIP_TYPE.TARGET_OF + "] - (t:XsltTransformer) RETURN t.stylesheet";
        Map<String, Object> params = new HashMap<>();
        params.put("id", viewId);
        
        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find XSLT Transformer with service id=" + viewId + " (Query=[" + cypherQuery + "] Params="
                    + params + ")");
        }
        if (result.hasNext()) {
            Map<String, Object> row = result.next();
            stylesheet = row.get("t.stylesheet").toString();
        }
        return stylesheet;
    }

    @Override
    @Cacheable("getDataSetFilterAttributes")
    public List<Map<String, String>> getDataSetFilterAttributes(@Loggable String dataSetId) {

        String mappings = null;
        String cypherQuery = "MATCH (d:PhysicalDataset {id:{id}}) <- [r :" + RELATIONSHIP_TYPE.PROVIDES + "] - (si:ServiceImplementation) "
                + " RETURN r.filter";
        Map<String, Object> params = new HashMap<>();
        params.put("id", dataSetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find DataSet filter attributes with id=" + dataSetId + " (Query=[" + cypherQuery
                    + "] Params=" + params + ")");
        }
        List<Map<String, String>> mapArrayList = new ArrayList<>();
        if (result.hasNext()) {
            Map<String, Object> row = result.next();
            Gson gson = new Gson();
            mappings = row.get("r.filter").toString();
            mapArrayList = gson.fromJson(mappings, mapArrayList.getClass());
        }
        return mapArrayList;
    }

    @Override
    @Cacheable("getChannelWithViewId")
    public String getChannelWithViewId(@Loggable String viewId) {

        String channelId = null;
        String cypherQuery = "MATCH (v:View {id:{id}}) - [r :" + RELATIONSHIP_TYPE.PUBLISHED_VIA + "] -> (ch:JMSChannel)" + " RETURN ch.id";
        Map<String, Object> params = new HashMap<>();
        params.put("id", viewId);
        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find Channel with View id=" + viewId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }
        if (result.hasNext()) {
            Map<String, Object> row = result.next();
            channelId = (String) row.get("ch.id");
        }
        return channelId;
    }

    /**
     * Special case where there is a property placeholder in the URL to add the
     * fields that are to be fetched. In this case, we fetch all attribute ids
     * for the dataset and encode the comma separated list
     * 
     * @param url
     * @return
     * @throws UnsupportedEncodingException
     */
    private String encodeDatasetFieldsForURL( String url,  String datasetId) {
        if (url != null && (url.contains(ADD_ENCODED_FIELDS) || url.contains(ADD_FIELDS))) {
            try {
                String attributeList = "";
                List<String> attributes = getAttributeIdsForDataset(datasetId);
                for (String attr : attributes) {
                    attributeList += attr + ",";
                }

                // Remove the braces
                attributeList = attributeList.substring(0, attributeList.length() - 1);

                // Encode if specified
                if (url.contains(ADD_ENCODED_FIELDS)) {
                    attributeList = EncodingUtils.compressAndEncode(attributeList);
                    url = url.replace(ADD_ENCODED_FIELDS, attributeList);
                } else {
                    // Replace in URL
                    url = url.replace(ADD_FIELDS, attributeList);
                }
            } catch (UnsupportedEncodingException e) {
                throw new MetadataException(
                        "The following error occurred trying to encode the fields to fetch in the source URL for dataset with id="
                                + datasetId + ":" + e.toString(), e);
            }
        }
        return url;
    }

    /**
     * Checks if the node with the specified id has the given label
     * 
     * @param id
     * @param label
     * @return
     */
    private boolean doesNodeWithIdHaveLabel(String id, String label) {
        String cypherQuery = "match (n {id:{id}}) where (n:" + label + ") return n";
        Map<String, Object> params = new HashMap<String, Object>();

        params.put("id", id);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        return result.hasNext();

    }

    @Override
    @Cacheable("getDatasetKeyAttributeNames")
    public List<String> getDatasetKeyAttributeNames(@Loggable String datasetId) {
        List<String> attibuteNames = new ArrayList<String>();

        String cypherQuery = "match (d:Dataset {id:{id}})-[r:OWNS|:SELECTS]->(pa:PhysicalAttribute)-[:" + RELATIONSHIP_TYPE.MAKES_UP
                + "]->(pke:PhysicalKeyElement) return pa.id,r.viewAttributeName order by r.position,pa.position ASC";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();

            // Is it a view
            Object viewAttributeName = row.get("r.viewAttributeName");
            if (viewAttributeName != null) {
                attibuteNames.add(viewAttributeName.toString());
            } else {
                attibuteNames.add(row.get("pa.id").toString());
            }
        }
        return attibuteNames;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getThinToWidePivotColumnForDataset(java.lang.String)
     */
    @Override
    @Cacheable("getThinToWidePivotColumnForDataset")
    public String getThinToWidePivotColumnForDataset(@Loggable String datasetId) {
        String cypherQuery = "match (d:Dataset {id:{id}})-[:SOURCE_OF]->(ttw:ThinToWideTransformer)-[:HAS_PIVOT_COLUMN]->(pa:PhysicalAttribute) return pa.id";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException(
                    "Failed to find dataset with id="
                            + datasetId
                            + " or the dataset does not have a ThinToWideTransformer associated with it, or there is no Attribute defined as the pivot column (Query=["
                            + cypherQuery + "] Params=" + params + ")");
        }

        String attributeId = result.next().get("pa.id").toString();
        return attributeId;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getThinToWideTargetPivotValuesForDataset(java.lang.String)
     */
    @Override
    @Cacheable("getThinToWideTargetPivotValuesForDataset")
    public List<String> getThinToWideTargetPivotValuesForDataset(@Loggable String datasetId) {
        List<String> targetPivotValues = new ArrayList<String>();

        String cypherQuery = "match (d:Dataset {id:{id}})-[:SOURCE_OF]->(ttw:ThinToWideTransformer) return ttw.targetPivotValues";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId
                    + " or the dataset does not have a ThinToWideTransformer associated with it (Query=[" + cypherQuery + "] Params="
                    + params + ")");
        }

        String targetValuesCSV = result.next().get("ttw.targetPivotValues").toString();
        targetPivotValues = Arrays.asList(targetValuesCSV.split(","));
        return targetPivotValues;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getThinToWideColumnsAssociatedWithPivotForDataset(java.lang.String)
     */
    @Override
    @Cacheable("getThinToWideColumnsAssociatedWithPivotForDataset")
    public List<String> getThinToWideColumnsAssociatedWithPivotForDataset(@Loggable String datasetId) {
        List<String> columnsForPivot = new ArrayList<String>();

        String cypherQuery = "match (d:Dataset {id:{id}})-[:SOURCE_OF]->(ttw:ThinToWideTransformer)-[:HAS_ASSOCIATED_PIVOT_COLUMN]->(pa:PhysicalAttribute) return pa.id";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException(
                    "Failed to find dataset with id="
                            + datasetId
                            + " or the dataset does not have a ThinToWideTransformer associated with it, or there are no Attributes defined for pivot columns (Query=["
                            + cypherQuery + "] Params=" + params + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            Object value = row.get("pa.id");
            if (value == null) {
                throw new MetadataException("Attribute for datasetId=" + datasetId + " does not have an value for the id property!");
            }

            columnsForPivot.add(value.toString());
        }

        return columnsForPivot;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getTransformerPreProcessorRulesetsForDataset(java.lang.String)
     */
    @Override
    @Cacheable("getTransformerPreProcessorRulesetsForDataset")
    public List<String> getTransformerPreProcessorRulesetsForDataset(@Loggable String datasetId) {
        List<String> ruleSets = new ArrayList<String>();
        String cypherQuery = "match (d:Dataset {id:{id}})-[:SOURCE_OF]->(ttw:ThinToWideTransformer) return ttw.preProcessorRules";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId
                    + " or the dataset does not have a ThinToWideTransformer associated with it (Query=[" + cypherQuery + "] Params="
                    + params + ")");
        }

        Map<String, Object> props = result.next();
        if (props.containsKey("ttw.preProcessorRules")) {
            Object value = props.get("ttw.preProcessorRules");
            if (value != null) {
                String ruleSet = props.get("ttw.preProcessorRules").toString();
                ruleSets = Arrays.asList(ruleSet.split(","));
            }
        }

        return ruleSets;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getThinToWideTargetPivotValuesForDataset(java.lang.String)
     */
    @Override
    @Cacheable("getThinToWideKeyColumnPositionsForDataset")
    public List<Integer> getThinToWideKeyColumnPositionsForDataset(@Loggable String datasetId) {
        List<Integer> keyColumnPositions = new ArrayList<Integer>();

        String cypherQuery = "match (d:Dataset {id:{id}})-[:SOURCE_OF]->(ttw:ThinToWideTransformer)-[r:HAS_KEY_COLUMN]->(pa:PhysicalAttribute) return pa.position order by r.sortOrder ASC";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException(
                    "Failed to find dataset with id="
                            + datasetId
                            + " or the dataset does not have a ThinToWideTransformer associated with it, or does not have any key columns set on the Transformer (Query=["
                            + cypherQuery + "] Params=" + params + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            Object value = row.get("pa.position");
            if (value == null) {
                throw new MetadataException("Attribute for datasetId=" + datasetId + " does not have an value for the position property!");
            }

            keyColumnPositions.add(Integer.parseInt(value.toString()));
        }

        return keyColumnPositions;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getThinToWideKeyColumnsForDataset(java.lang.String)
     */
    @Override
    @Cacheable("getThinToWideKeyColumnsForDataset")
    public List<String> getThinToWideKeyColumnsForDataset(@Loggable String datasetId) {
        List<String> keyColumns = new ArrayList<String>();

        String cypherQuery = "match (d:Dataset {id:{id}})-[:SOURCE_OF]->(ttw:ThinToWideTransformer)-[r:HAS_KEY_COLUMN]->(pa:PhysicalAttribute) return pa.id order by r.sortOrder ASC";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException(
                    "Failed to find dataset with id="
                            + datasetId
                            + " or the dataset does not have a ThinToWideTransformer associated with it, or does not have any key columns set on the Transformer (Query=["
                            + cypherQuery + "] Params=" + params + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            Object value = row.get("pa.id");
            if (value == null) {
                throw new MetadataException("Attribute for datasetId=" + datasetId + " does not have an value for the id property!");
            }

            keyColumns.add(value.toString());
        }

        return keyColumns;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getPredicatesForDatasetInJoinRelation(java.lang.String, java.lang.String)
     */
    @Override
    @Cacheable("getPredicatesForDatasetInJoinRelation")
    public String getPredicatesForDatasetInJoinRelation(@Loggable String joinRelationId, @Loggable String datasetId) {
        String cypherQuery = "match (jr:JoinRelation {id:{jrid}})-[r:" + RELATIONSHIP_TYPE.JOINS
                + "]->(d:Dataset {id:{id}}) return r.predicates";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("jrid", joinRelationId);
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find JoinRelation with id=" + joinRelationId + " that is joined to Dataset with id="
                    + datasetId + " (Query=[" + cypherQuery + "] Params=" + params + ")");
        }

        Object predicatesObj = result.next().get("r.predicates");
        if (predicatesObj == null) {
            throw new MetadataException("There is no predicate property set on the relation node between 'JoinRelation' and 'Dataset'");
        }
        return predicatesObj.toString();
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ubs.idp.metadata.service.MetadataService#getUnionAllForView(java.
     * lang.String)
     */
    @Override
    @Cacheable("getUnionAllForView")
    public boolean getUnionAllForView(@Loggable String viewId) {
        String cypherQuery = "match (v:View {id:{id}}) return v.unionAll";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", viewId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find view with id=" + viewId + " (Query=[" + cypherQuery + "] Params=" + params + ")");
        }

        String union = result.next().get("v.unionAll").toString();
        return Boolean.parseBoolean(union);
    }

    /**
     * returns a key value properties map of node of type ServiceImplementation
     */
    @Override
    @Cacheable("getPropertyMapOfServiceImplementation")
    public Map<String, String> getPropertyMapOfServiceImplementation(@Loggable String serviceImplementationId) {
        return getPropertyMapOfNode(serviceImplementationId, "ServiceImplementation");
    }

    /**
     * returns a key value properties of node of type nodeLable
     */
    @Cacheable("getPropertyMapOfNode")
    public Map<String, String> getPropertyMapOfNode(@Loggable String nodeId, @Loggable String nodeLabel) {
        String mappings = null;
        String cypherQuery = "MATCH (n:" + nodeLabel + "{id:{id}}) RETURN n.propertiesMap";
        Map<String, Object> params = new HashMap<>();
        params.put("id", nodeId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find Property Map with node id=" + nodeId + " (Query=[" + cypherQuery + "] Params="
                    + params + ")");
        }
        Map<String, String> map = new HashMap<String, String>();
        if (result.hasNext()) {
            Map<String, Object> row = result.next();
            Gson gson = new Gson();
            mappings = row.get("n.propertiesMap").toString();
            map = gson.fromJson(mappings, map.getClass());
        }
        return map;
    }

    @Override
    @Cacheable("getPhysicalDatasetAttributeNamesAndTypes")
    public Map<String, String> getPhysicalDatasetAttributeNamesAndTypes(@Loggable String datasetId) {
        Map<String, String> attributeNames = new HashMap<>();
        String cypherQuery = "match (pd:PhysicalDataset {id:{id}})-[:OWNS]->(pa:PhysicalAttribute) return pa.id, pa.type";
        Map<String, Object> params = new HashMap<>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find DataSet with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        while (result.hasNext()) {
            Map<String, Object> row = result.next();
            attributeNames.put(row.get("pa.id").toString(), row.get("pa.type").toString());
        }
        return attributeNames;
    }

    /**
     * Returns a Map <K,V> of Ordered DataSetId's for a given service
     * implementation. The ordering is done on basis of data set position. Key
     * is DatasetID and Value is datasetName.
     * 
     * @param serviceImplId
     * @return
     */
    @Override
    @Cacheable("getOrderedDatasetDetails")
    public List<Map<String, String>> getOrderedDatasetDetails(@Loggable String serviceImplId) {
        // TODO:Junit
        List<String> attributeNames = new ArrayList<String>();
        List<Map<String, String>> datasetlist = new ArrayList<>();
        String cypherQuery = "match (si:ServiceImplementation {id:{id}}) -[p:" + RELATIONSHIP_TYPE.PROVIDES
                + "]->(d1:PhysicalDataset)  RETURN d1.id, d1.name order by d1.position ASC";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", serviceImplId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find Service with id=" + serviceImplId + " (Query=[" + cypherQuery + "] Params="
                    + params + ")");
        }

        while (result.hasNext()) {
            Map<String, String> map = new HashMap<String, String>();
            Map<String, Object> row = result.next();
            map.put(row.get("d1.id").toString(), row.get("d1.name").toString());
            datasetlist.add(map);
        }
        return datasetlist;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ubs.idp.metadata.service.MetadataService#isView(java.lang.String)
     */
    @Override
    @Cacheable("isView")
    public boolean isView(@Loggable String datasetId) {
        String cypherQuery = "match (d:Dataset {id:{id}}) return labels(d)";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("id", datasetId);

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("Failed to find dataset with id=" + datasetId + " (Query=[" + cypherQuery + "] Params=" + params
                    + ")");
        }

        String labels = result.next().toString();
        return labels.contains("View");
    }

    @Override
    @Cacheable("getAllDatasets")
    public List<String> getAllDatasets() {
        List<String> datasetIds = new ArrayList<String>();
        String cypherQuery = "match (pd:PhysicalDataset) return pd.id order by pd.id";
        Map<String, Object> params = new HashMap<String, Object>();

        Iterator<Map<String, Object>> result = neo4jUtils.executeCypherQueryForObjects(cypherQuery, params);
        if (!result.hasNext()) {
            throw new MetadataException("No datasets found! (Query=[" + cypherQuery + "] Params=" + params + ")");
        }

        while (result.hasNext()) {
            datasetIds.add(result.next().get("pd.id").toString());
        }
        return datasetIds;
    }
}
