package com.ubs.idp.metadata.model.relationships;

import org.neo4j.graphdb.Relationship;
import org.springframework.data.neo4j.annotation.EndNode;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.RelationshipEntity;
import org.springframework.data.neo4j.annotation.StartNode;

import com.ubs.idp.metadata.model.PhysicalAttribute;
import com.ubs.idp.metadata.model.View;

@RelationshipEntity(type="SELECTS")
public class SelectsRelationshipType extends BaseRelationshipType
{
	public SelectsRelationshipType()
	{
		
	}
	
	public SelectsRelationshipType(View view,
									   PhysicalAttribute physicalAttribute,
									   int position,
									   String viewAttributeName)
	{
		this.position = position;
		this.physicalAttribute = physicalAttribute;
		this.view = view;
		this.viewAttributeName = viewAttributeName;
	}
	
	public int position;	
	
	
	/**
	 * The name this attribute is getting selected as
	 * for the view
	 */
	public String viewAttributeName;
	
	
	@StartNode public View view;
	@EndNode public PhysicalAttribute physicalAttribute;

}
