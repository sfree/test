package com.ubs.idp.metadata.model;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.Fetch;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;

@NodeEntity
public class PhysicalAttribute extends BaseEntity implements Comparable<PhysicalAttribute>
{
	@RelatedTo(type = "MAKES_UP", direction = Direction.OUTGOING)
	private PhysicalKeyElement keyElement;

	@RelatedTo(type = "JOINED_TO", direction = Direction.BOTH)
	private Set<PhysicalAttribute> joinedAttributes = new HashSet<PhysicalAttribute>();

	/**
	 * The position of this attribute within the physical attribute
	 */
	public long position;
	
	public boolean queryable;
	
	public boolean active;
	
	/**
	 * Indicates that the value for this attribute has been derived or enriched
	 * by the rules during the ingestion process so is different from the source value 
	 */
	public boolean derived;
	
	public String xpath;
	
	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int compareTo(PhysicalAttribute otherAttribute)
	{
		return this.name.compareTo(otherAttribute.name);
	}
	
/*	@Override
	public boolean equals( Object otherAttribute )
	{		
		if( otherAttribute instanceof PhysicalAttribute )
		{
			return this.id.equals(((PhysicalAttribute)otherAttribute).id);
		}

		
		return false;		
	}
*/
	@Fetch
	public Set<PhysicalAttribute> getJoinedAttributes()
	{
		return joinedAttributes;
	}

	@Fetch
	public PhysicalKeyElement getKeyElement()
	{
		return keyElement;
	}

	public void setKeyElement(PhysicalKeyElement keyElement)
	{
		this.keyElement = keyElement;
	}

	

}
