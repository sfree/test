package com.ubs.idp.metadata.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedToVia;

import com.ubs.idp.metadata.model.relationships.JoinsRelationshipType;

@NodeEntity
public class JoinRelation extends BaseEntity
{
	/**
	 * The datasets that this join brings together
	 */
	@RelatedToVia(type = "JOINS", direction = Direction.OUTGOING)
	public Set<JoinsRelationshipType> datasets = new HashSet<JoinsRelationshipType>();

	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
	 * The position of the join relation within the view. This is pertinent to the <code>union</code>
	 * flag on the view as it determines which relation is processed before others
	 */
	public int position;
	
	/**
	 * Returns the two datasets that this Join relation represents ordered
	 * left then right (i.e. left join dataset then right join dataset)
	 * @return
	 */
	public List<PhysicalDataset> getOrderedDatasets()
	{
		// TODO cache sorted, get error when declared as class field - maybe due to graph backed annotation
		List<PhysicalDataset> orderedDatasets = null;
		
		// cache sorted
		if(orderedDatasets == null) {
			orderedDatasets = new ArrayList<PhysicalDataset>(datasets.size());
			// Initialize in unsorted order to avoid IndexOutOfBoundsException when you call .set() later
			Iterator<JoinsRelationshipType> iterator = datasets.iterator();
			while(iterator.hasNext()) {
				JoinsRelationshipType jr = iterator.next();
				orderedDatasets.add(jr.physicalDataset);
			}
			
			// Sort datasets by setting them according to position
			iterator = datasets.iterator();
			while(iterator.hasNext()) {
				JoinsRelationshipType jr = iterator.next();
				orderedDatasets.set(jr.joinPosition, jr.physicalDataset);
			}
		}
		return orderedDatasets;
	}
}
