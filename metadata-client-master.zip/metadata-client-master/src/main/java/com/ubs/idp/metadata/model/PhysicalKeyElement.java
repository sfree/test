package com.ubs.idp.metadata.model;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.Fetch;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;

@NodeEntity
public class PhysicalKeyElement extends BaseEntity
{	
	@RelatedTo(type = "KEY_ELEMENT_OF", direction = Direction.OUTGOING)
	private PhysicalKey key;
	
	public int position;

	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Fetch
	public PhysicalKey getKey()
	{
		return key;
	}

	public void setKey(PhysicalKey key)
	{
		this.key = key;
	}
	
	
}
