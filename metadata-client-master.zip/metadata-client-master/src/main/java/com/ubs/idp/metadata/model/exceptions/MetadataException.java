package com.ubs.idp.metadata.model.exceptions;

/**
 * Base exception for metadata services
 * @author loverids
 *
 */
public class MetadataException extends RuntimeException
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MetadataException( String message )
	{
		super( message);
	}

	public MetadataException( String message, Exception originalException )
	{
		super( message, originalException);
	}

}
