package com.ubs.idp.metadata.model;

import org.springframework.data.neo4j.annotation.NodeEntity;

@NodeEntity
@Deprecated
public class LogicalAttribute extends Attribute
{

	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}

}
