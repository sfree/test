package com.ubs.idp.metadata.model;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;
import org.neo4j.graphdb.RelationshipType;
import org.springframework.data.neo4j.annotation.EndNode;
import org.springframework.data.neo4j.annotation.RelationshipEntity;
import org.springframework.data.neo4j.annotation.StartNode;

import com.ubs.idp.metadata.model.relationships.BaseRelationshipType;

/**
 * The dynamic relationship allows us to convert any of the custom relationship types 
 * in the model into a Neo4j raw Relationship
 * 
 * It is not tied to a Neo4j instance but is instead intended to be a lightweight holder of
 * an entities properties to be used for Cypher exporting
 * 
 * @author loverids
 *
 */
public class DynamicRelationship implements Relationship
{
	private Map<String,Object> props = new HashMap<String,Object>();
	
	private int nodeId;
	
	private static int nodeIdCounter = 0;
	
	private Node startNode;
	
	private Node endNode;
	
	private String relationshipType;
	
	public DynamicRelationship()
	{
		this.nodeId = nodeIdCounter ++;
	}
	
	public DynamicRelationship( BaseRelationshipType relationship ) throws IllegalArgumentException, IllegalAccessException
	{
		this.nodeId = nodeIdCounter ++;

		// Set the properties from the entity		
		setPropertiesFromObject(relationship);
		
		 
		
	}
	
	private void setPropertiesFromObject( Object obj ) throws IllegalArgumentException, IllegalAccessException
	{
		Class currentClass = obj.getClass();		
		
		RelationshipEntity ann  = (RelationshipEntity)currentClass.getAnnotation(RelationshipEntity.class);
		relationshipType = ann.type();
		
		do
		{
			Field[] fields = currentClass.getFields();
			Field[] decFields = currentClass.getDeclaredFields();
			for( Field field : fields )
			{
				Object value =field.get(obj);
				if( value != null && value.toString().length() > 0 )
				{				
					props.put(field.getName(), value );
				}
			}

			for( Field field : decFields )
			{
				StartNode startNodeAnn = field.getAnnotation(StartNode.class);
				EndNode endNodeAnn = field.getAnnotation(EndNode.class);
				
				if( startNodeAnn != null )
				{
					startNode = ((BaseEntity)field.get(obj)).toNode();
				}
				if( endNodeAnn != null )
				{
					endNode =  ((BaseEntity)field.get(obj)).toNode();
				}
			}
			
			currentClass = currentClass.getSuperclass();

		}while( currentClass != null );		
				
	}



	@Override
	public GraphDatabaseService getGraphDatabase()
	{
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean hasProperty(String key)
	{
		return props.containsKey(key);
	}

	@Override
	public Object getProperty(String key)
	{
		return props.get(key);
	}

	@Override
	public Object getProperty(String key, Object defaultValue)
	{
		Object value = props.get(key); 
		return value == null ? defaultValue : value;
	}

	@Override
	public void setProperty(String key, Object value)
	{
		props.put(key, value);
	}

	@Override
	public Object removeProperty(String key)
	{		
		return props.remove(key);
	}

	@Override
	public Iterable<String> getPropertyKeys()
	{
		return props.keySet();
	}

	@Override
	public long getId()
	{
		return nodeId;
	}

	@Override
	public void delete()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public Node getStartNode()
	{
		return startNode;
	}



	@Override
	public Node getEndNode()
	{
		return endNode;
	}



	@Override
	public Node getOtherNode(Node node)
	{
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Node[] getNodes()
	{
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public RelationshipType getType()
	{
		return new RelationshipType()
		{			
			@Override
			public String name()
			{
				return relationshipType;
			}
		};
	}



	@Override
	public boolean isType(RelationshipType type)
	{
		return type.name().equals(relationshipType);
	}

	public void setStartNode(Node startNode)
	{
		this.startNode = startNode;
	}

	public void setEndNode(Node endNode)
	{
		this.endNode = endNode;
	}

	public void setRelationshipType(RelationshipType relationshipType)
	{
		this.relationshipType = relationshipType.name();
	}

	
}
