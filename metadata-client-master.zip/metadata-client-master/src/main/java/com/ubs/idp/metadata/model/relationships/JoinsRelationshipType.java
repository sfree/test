package com.ubs.idp.metadata.model.relationships;

import org.neo4j.graphdb.Relationship;
import org.springframework.data.neo4j.annotation.EndNode;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.RelationshipEntity;
import org.springframework.data.neo4j.annotation.StartNode;

import com.ubs.idp.metadata.model.JoinRelation;
import com.ubs.idp.metadata.model.PhysicalDataset;

@RelationshipEntity(type="JOINS")
public class JoinsRelationshipType extends BaseRelationshipType
{

	
	public JoinsRelationshipType()
	{
		
	}
	
	public JoinsRelationshipType(	JoinRelation joinRelation,
			PhysicalDataset physicalDataset,
			int joinPosition)	
	{
		this.joinPosition = joinPosition;
		this.joinRelation = joinRelation;
		this.physicalDataset = physicalDataset;
		this.predicates = "";
	}

	
	public JoinsRelationshipType(	JoinRelation joinRelation,
									PhysicalDataset physicalDataset,
									int joinPosition,
									String predicates)	
	{
		this.joinPosition = joinPosition;
		this.joinRelation = joinRelation;
		this.physicalDataset = physicalDataset;
		this.predicates = predicates;
	}

	
	public int joinPosition;
	
	/**
	 * Comma separated list of predicates executed by the query service when fetching
	 * the dataset that this join relation is associated with
	 */
	public String predicates;

	@StartNode public JoinRelation joinRelation;
	@EndNode public PhysicalDataset physicalDataset;

	
}
