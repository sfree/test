package com.ubs.idp.metadata.model;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.neo4j.graphdb.Direction;
import org.neo4j.graphdb.DynamicLabel;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Label;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;
import org.neo4j.graphdb.RelationshipType;
import org.neo4j.graphdb.ReturnableEvaluator;
import org.neo4j.graphdb.StopEvaluator;
import org.neo4j.graphdb.Traverser;
import org.neo4j.graphdb.Traverser.Order;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;
import org.springframework.data.neo4j.annotation.RelatedToVia;

/**
 * The dynamic node allows us to convert any of the entity nodes into a Neo4j raw Node
 * 
 * It is not tied to a Neo4j instance but is instead intended to be a lightweight holder of
 * an entities properties to be used for Cypher exporting
 * 
 * @author loverids
 *
 */
public class DynamicNode implements Node
{
	private Map<String,Object> props = new HashMap<String,Object>();
	
	private long nodeId;
	
	private static int nodeIdCounter = 0;
	
	private List<Label> labels = new ArrayList<Label>(); 
	
	
	public DynamicNode( BaseEntity entity ) throws IllegalArgumentException, IllegalAccessException
	{
		if( entity.nodeId == null )
		{
			this.nodeId = nodeIdCounter ++;
		}
		else
		{
			this.nodeId = entity.nodeId;
		}
		
		// Set the properties from the entity		
		Class currentClass = entity.getClass();
		
		do
		{
			NodeEntity ann  = (NodeEntity)currentClass.getAnnotation(NodeEntity.class);
			if( ann != null )
			{
				labels.add( DynamicLabel.label(currentClass.getSimpleName()) );
			}
			
			Field[] fields = currentClass.getFields();
			for( Field field : fields )
			{
				
				// Ignore 'nodeId'
				if( field.getName().equals("nodeId") )
				{
					continue;
				}
				
				// Ignore properties that relate to others
				if( field.getAnnotation(RelatedTo.class) != null ||
					field.getAnnotation(RelatedToVia.class) != null)
				{
					continue;
				}				
				
				Object value = field.get(entity);
				if( value != null && value.toString().length() > 0 )
				{				
					props.put(field.getName(), value );
				}
			}

			currentClass = currentClass.getSuperclass();

		}while( currentClass != null );
	}
	

	@Override
	public GraphDatabaseService getGraphDatabase()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean hasProperty(String key)
	{
		return props.containsKey(key);
	}

	@Override
	public Object getProperty(String key)
	{
		return props.get(key);
	}

	@Override
	public Object getProperty(String key, Object defaultValue)
	{
		Object value = props.get(key); 
		return value == null ? defaultValue : value;
	}

	@Override
	public void setProperty(String key, Object value)
	{
		props.put(key, value);
	}

	@Override
	public Object removeProperty(String key)
	{		
		return props.remove(key);
	}

	@Override
	public Iterable<String> getPropertyKeys()
	{
		return props.keySet();
	}

	@Override
	public long getId()
	{
		return nodeId;
	}

	@Override
	public void delete()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public Iterable<Relationship> getRelationships()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean hasRelationship()
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<Relationship> getRelationships(RelationshipType... types)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<Relationship> getRelationships(Direction direction, RelationshipType... types)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean hasRelationship(RelationshipType... types)
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean hasRelationship(Direction direction, RelationshipType... types)
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<Relationship> getRelationships(Direction dir)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean hasRelationship(Direction dir)
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<Relationship> getRelationships(RelationshipType type, Direction dir)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean hasRelationship(RelationshipType type, Direction dir)
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Relationship getSingleRelationship(RelationshipType type, Direction dir)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Relationship createRelationshipTo(Node otherNode, RelationshipType type)
	{
		DynamicRelationship rel = new DynamicRelationship();
		
		rel.setStartNode( this );
		rel.setEndNode(otherNode);
		rel.setRelationshipType( type );
		
		return rel;
	}

	@Override
	public Traverser traverse(Order traversalOrder, StopEvaluator stopEvaluator, ReturnableEvaluator returnableEvaluator, RelationshipType relationshipType, Direction direction)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Traverser traverse(Order traversalOrder, StopEvaluator stopEvaluator, ReturnableEvaluator returnableEvaluator, RelationshipType firstRelationshipType, Direction firstDirection, RelationshipType secondRelationshipType, Direction secondDirection)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Traverser traverse(Order traversalOrder, StopEvaluator stopEvaluator, ReturnableEvaluator returnableEvaluator, Object... relationshipTypesAndDirections)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addLabel(Label label)
	{
		labels.add(label);
	}

	@Override
	public void removeLabel(Label label)
	{
		labels.remove(label);
	}

	@Override
	public boolean hasLabel(Label label)
	{
		return labels.contains(label);
	}

	@Override
	public Iterable<Label> getLabels()
	{
		return labels;
	}

}
