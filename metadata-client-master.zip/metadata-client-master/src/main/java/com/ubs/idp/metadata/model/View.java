package com.ubs.idp.metadata.model;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.neo4j.graphdb.DynamicRelationshipType;
import org.neo4j.graphdb.traversal.Evaluators;
import org.neo4j.graphdb.traversal.TraversalDescription;
import org.neo4j.kernel.Traversal;
import org.springframework.data.neo4j.annotation.Fetch;
import org.springframework.data.neo4j.annotation.GraphTraversal;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.annotation.RelatedTo;
import org.springframework.data.neo4j.annotation.RelatedToVia;
import org.springframework.data.neo4j.core.FieldTraversalDescriptionBuilder;
import org.springframework.data.neo4j.mapping.Neo4jPersistentProperty;

import com.ubs.idp.metadata.model.enums.RELATIONSHIP_TYPE;
import com.ubs.idp.metadata.model.relationships.SelectsRelationshipType;

@NodeEntity
public class View extends Dataset
{
	@RelatedToVia(type = "SELECTS", direction = Direction.OUTGOING)
	public Set<SelectsRelationshipType> attributes = new HashSet<SelectsRelationshipType>();
		
	@Query (value="start n=node({self}) match (n)-[r:SELECTS]->(pa:PhysicalAttribute) return pa order by r.position ASC")
	private Iterable<PhysicalAttribute> attributesOrderedByPosition;

	@Query (value="start n=node({self}) match (n)-[r:SELECTS]->(pa:PhysicalAttribute) where pa.queryable=true return pa order by r.position ASC")
	private Iterable<PhysicalAttribute> queryableAttributesOrderedByPosition;

	@Query (value="start n=node({self}) match (n)-[r:SELECTS]->(pa:PhysicalAttribute) where pa.queryable=true return r.position order by r.position ASC")
	private Iterable<Integer> queryableAttributePositions;
	
	@Query (value="start n=node({self}) match (n)-[r:SELECTS]->(pa:PhysicalAttribute) return r.viewAttributeName order by r.position ASC")
	private Iterable<String> attributeNamesOrderedByPosition;

	@Query (value="start n=node({self}) MATCH (n)-[:REPRESENTED_AS]->(jr:JoinRelation)-[:JOINS]->(pd:PhysicalDataset) RETURN pd")
	private Iterable<PhysicalDataset> associatedDatasets;

	/**
	 * The joins relations that this view has. Join Relations are a node type
	 * that link various datasets together
	 */
	@RelatedTo(type = "REPRESENTED_AS", direction = Direction.OUTGOING)
	public Set<JoinRelation> joinRelations = new HashSet<JoinRelation>();
	
	/**
	 * The available JDBC source channels used to fetch data to populate
	 * this dataset 
	 */
	@GraphTraversal(traversal = DatasetTraversalBuilder.class, elementClass=PhysicalDataset.class)
	private Iterable<PhysicalDataset> datasetsInView;
	
	/**
	 * Determines if this view should be fetched as a true union (i.e. pull back all related datasets in the view)
	 * or should only return the first dataset matching the predicate, determined by the ordering of the JoinRelations
	 */
	public boolean unionAll;

	private static class DatasetTraversalBuilder implements FieldTraversalDescriptionBuilder 
	{
		@Override
		public TraversalDescription build(Object start, Neo4jPersistentProperty props, String... params)
		{
			return Traversal.description().
					evaluator(Evaluators.excludeStartPosition()).
					relationships(DynamicRelationshipType.withName(RELATIONSHIP_TYPE.REPRESENTED_AS.toString()), Direction.OUTGOING).
					relationships(DynamicRelationshipType.withName(RELATIONSHIP_TYPE.JOINS.toString()), Direction.OUTGOING).
					evaluator(Evaluators.includeWhereLastRelationshipTypeIs( DynamicRelationshipType.withName(RELATIONSHIP_TYPE.JOINS.toString() ) ) );					
		}
	}

	public Iterable<PhysicalDataset> getDatasetsInView()
	{
		return datasetsInView;
	}

	@Fetch
	public Iterable<PhysicalAttribute> getAttributesOrderedByPosition()
	{
		return attributesOrderedByPosition;
	}

	@Fetch
	public Iterable<String> getAttributeNamesOrderedByPosition()
	{
		return attributeNamesOrderedByPosition;
	}

	@Fetch
	public Iterable<PhysicalAttribute> getQueryableAttributesOrderedByPosition()
	{
		return queryableAttributesOrderedByPosition;
	}

	@Fetch
	public Iterable<Integer> getQueryableAttributePositions()
	{
		return queryableAttributePositions;
	}

	@Fetch
	public Set<SelectsRelationshipType> getAttributes()
	{
		return attributes;
	}

	public void setAttributes(Set<SelectsRelationshipType> attributes)
	{
		this.attributes = attributes;
	}

	@Fetch
	public Iterable<PhysicalDataset> getAssociatedDatasets()
	{
		return associatedDatasets;
	}

	public void setAssociatedDatasets(Iterable<PhysicalDataset> associatedDatasets)
	{
		this.associatedDatasets = associatedDatasets;
	}

	@Fetch
	public Set<JoinRelation> getJoinRelations()
	{
		return joinRelations;
	}

	
	
	
}
