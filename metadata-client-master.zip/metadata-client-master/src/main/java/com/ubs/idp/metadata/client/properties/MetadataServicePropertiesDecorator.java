package com.ubs.idp.metadata.client.properties;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.model.JDBCChannel;
import com.ubs.idp.metadata.model.JMSChannel;
import com.ubs.idp.metadata.model.JoinRelation;

/**
 * This is a decorator class that will replace any environment specific property
 * placeholders with the meta data values being returned
 */
public abstract class MetadataServicePropertiesDecorator implements MetadataService {

    @Autowired
    protected MetadataService neo4jMetadataService;

    @Override
    public JDBCChannel getDatabaseDetailsForDataset(String datasetId) {
        JDBCChannel channel = neo4jMetadataService.getDatabaseDetailsForDataset(datasetId);

        channel.driverClass = replacePropertyPlaceholders(channel.driverClass);
        channel.password = replacePropertyPlaceholders(channel.password);
        channel.username = replacePropertyPlaceholders(channel.username);
        channel.url = replacePropertyPlaceholders(channel.url);
        channel.querySQL = replacePropertyPlaceholders(channel.querySQL);

        return channel;
    }

    @Override
    public List<Integer> getDatasetKeyAttributePositions(String datasetId) {
        return neo4jMetadataService.getDatasetKeyAttributePositions(datasetId);
    }

    @Override
    public List<String> getDatasetKeyAttributeNames(String datasetId) {
        return neo4jMetadataService.getDatasetKeyAttributeNames(datasetId);
    }

    @Override
    public List<String> getAttributeNamesForDataset(String datasetId) {
        return neo4jMetadataService.getAttributeNamesForDataset(datasetId);
    }

    @Override
    public String getSQLQueryForDataset(String datasetId) {
        return replacePropertyPlaceholders(neo4jMetadataService.getSQLQueryForDataset(datasetId));
    }

    @Override
    public String getSQLDeltaQueryForDataset(String datasetId) {
        return replacePropertyPlaceholders(neo4jMetadataService.getSQLDeltaQueryForDataset(datasetId));
    }

    @Override
    public Map<String, Integer> getAttributePositionsForDataset(String datasetId) {
        return neo4jMetadataService.getAttributePositionsForDataset(datasetId);
    }

    @Override
    public String getDelimiter(String datasetId) {
        return neo4jMetadataService.getDelimiter(datasetId);
    }

    @Override
    public List<String> getAttributeNamesForPhysicalDataset(String datasetId) {
        return neo4jMetadataService.getAttributeNamesForPhysicalDataset(datasetId);
    }

    @Override
    public Map<String, List<String>> getAllDatasetAndAttributeNames() {
        return neo4jMetadataService.getAllDatasetAndAttributeNames();
    }

    @Override
    public List<String> getSourceUrlsForDataset(String datasetId) {
        return replacePropertyPlaceholders(neo4jMetadataService.getSourceUrlsForDataset(datasetId));
    }

    @Override
    public List<String> getJobNamesForDataset(String datasetId) {
        return neo4jMetadataService.getJobNamesForDataset(datasetId);
    }

    @Override
    public String getSourceDeltaUrlForDataset(String datasetId) {
        return replacePropertyPlaceholders(neo4jMetadataService.getSourceDeltaUrlForDataset(datasetId));
    }

    @Override
    public Map<String, List<String>> getSourceUrlsForAllDatasets() {
        return replacePropertyPlaceholdersForListMap(neo4jMetadataService.getSourceUrlsForAllDatasets());
    }

    @Override
    public List<String> getRolesForDataset(String datasetId) {
        return neo4jMetadataService.getRolesForDataset(datasetId);
    }

    @Override
    public List<Integer> getQueryableAttributePositionsForDataset(String datasetId) {
        return neo4jMetadataService.getQueryableAttributePositionsForDataset(datasetId);
    }

    @Override
    public List<JoinRelation> getJoinRelationsForView(String viewId) {
        return neo4jMetadataService.getJoinRelationsForView(viewId);
    }

    @Override
    public List<String> getAttributeIdsForDataset(String datasetId) {
        return neo4jMetadataService.getAttributeIdsForDataset(datasetId);
    }

    @Override
    public String getPrimarySourceUrlForDataset(String datasetId) {
        return replacePropertyPlaceholders(neo4jMetadataService.getPrimarySourceUrlForDataset(datasetId));
    }

    @Override
    public List<String> getTransformerRulesetsForDataset(String datasetId) {
        return neo4jMetadataService.getTransformerRulesetsForDataset(datasetId);
    }

    @Override
    public List<String> getTransformerRulesetsForDatasets(String srcDataset, String targetDataset) {
        return neo4jMetadataService.getTransformerRulesetsForDatasets(srcDataset, targetDataset);
    }

    @Override
    public List<String> getAttributeXpathsForPhysicalDataset(String datasetId) {
        return replacePropertyPlaceholders(neo4jMetadataService.getAttributeXpathsForPhysicalDataset(datasetId));
    }

    @Override
    public Map<String, String> getNamespacesForDataset(String datasetId) {
        return neo4jMetadataService.getNamespacesForDataset(datasetId);
    }

    @Override
    public Map<String, List<JoinRelation>> getAllRelations() {
        return neo4jMetadataService.getAllRelations();
    }

    @Override
    public String getSourceAuthenticationUriForDataset(String datasetId) {
        return replacePropertyPlaceholders(neo4jMetadataService.getSourceAuthenticationUriForDataset(datasetId));
    }

    @Override
    public String getUrlForChannel(String channelId, boolean isDelta) {
        return replacePropertyPlaceholders(neo4jMetadataService.getUrlForChannel(channelId, isDelta));
    }

    @Override
    public String getUrlForChannel(String channelId) {
        return replacePropertyPlaceholders(neo4jMetadataService.getUrlForChannel(channelId));
    }

    @Override
    public List<String> getJoinKeysForDatasetIds(String datasetId1, String datasetId2) {
        return neo4jMetadataService.getJoinKeysForDatasetIds(datasetId1, datasetId2);
    }

    @Override
    public String getTableIdForDataset(String datasetId) {
        return neo4jMetadataService.getTableIdForDataset(datasetId);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ubs.idp.metadata.service.MetadataService#generateSQLInsertForDataset
     * (java.lang.String)
     */
    @Override
    public String generateSQLInsertForDataset(String datasetId) {
        return neo4jMetadataService.generateSQLInsertForDataset(datasetId);
    }

    /**
     * Returns Service Implementations for given service
     *
     * @param serviceId
     * @return
     */
    @Override
    public List<String> getServiceImplementations(String serviceId) {
        return neo4jMetadataService.getServiceImplementations(serviceId);
    }

    /**
     * Returns data set details for given service implementation
     *
     * @param serviceImplId
     * @return
     */
    @Override
    public Map<String, List<String>> getDataSetDetails(String serviceImplId) {
        return neo4jMetadataService.getDataSetDetails(serviceImplId);
    }

    /**
     * Returns required data set attributes for given service implementation
     *
     * @param serviceImplId
     * @return
     */
    @Override
    public Map<String, String> getRequiredDataSetAttributes(String serviceImplId) {
        return neo4jMetadataService.getRequiredDataSetAttributes(serviceImplId);
    }

    /**
     * Returns stored procedure details for given service implementation
     *
     * @param serviceImplId
     * @return
     */
    @Override
    public Map<String, Map<String, Map<String, Object>>> getStoredProcedureDetails(String serviceImplId) {
        return neo4jMetadataService.getStoredProcedureDetails(serviceImplId);
    }

    /**
     * Returns JMS channel details for a given JMS channelId
     *
     * @param serviceId
     * @return
     */
    @Override
    public JMSChannel getJMSChannelDetails(String channelId) {
        JMSChannel channel = neo4jMetadataService.getJMSChannelDetails(channelId);
        channel.name = replacePropertyPlaceholders(channel.name);
        channel.url = replacePropertyPlaceholders(channel.url);
        channel.user = replacePropertyPlaceholders(channel.user);
        channel.password = replacePropertyPlaceholders(channel.password);
        channel.queueManager = replacePropertyPlaceholders(channel.queueManager);
        channel.channel = replacePropertyPlaceholders(channel.channel);
        channel.port = replacePropertyPlaceholders(channel.port);
        channel.transportType = replacePropertyPlaceholders(channel.transportType);
        channel.SSLCipherSuite = replacePropertyPlaceholders(channel.SSLCipherSuite);
        return channel;
    }

    /**
     * Returns all Service Implementations for a given source
     *
     * @param sourceId
     * @return
     */
    @Override
    public List<String> getAllServiceImplementationsForSource(String sourceId) {
        return neo4jMetadataService.getAllServiceImplementationsForSource(sourceId);
    }

    @Override
    public JDBCChannel getJdbcChannelDetailsWithId(String channelId) {
        JDBCChannel channel = neo4jMetadataService.getJdbcChannelDetailsWithId(channelId);
        channel.driverClass = replacePropertyPlaceholders(channel.driverClass);
        channel.password = replacePropertyPlaceholders(channel.password);
        channel.username = replacePropertyPlaceholders(channel.username);
        channel.url = replacePropertyPlaceholders(channel.url);
        return channel;
    }

    @Override
    public Map<String, Map<String, String>> getDataSetTransformationMappings(String serviceImplId) {
        return neo4jMetadataService.getDataSetTransformationMappings(serviceImplId);
    }

    @Override
    public Map<String, Map<String, String>> getTransformationMappingforView(String viewId) {
        return neo4jMetadataService.getTransformationMappingforView(viewId);
    }
    
    @Override
    public String getXsltStylesheetForView(String viewId) {
        return neo4jMetadataService.getXsltStylesheetForView(viewId);
    }

    @Override
    public List<Map<String, String>> getDataSetFilterAttributes(String dataSetId) {
        return neo4jMetadataService.getDataSetFilterAttributes(dataSetId);
    }

    @Override
    public String getChannelWithViewId(String viewId) {
        return neo4jMetadataService.getChannelWithViewId(viewId);
    }

    @Override
    public Map<String, String> getPropertyMapOfServiceImplementation(String serviceImplementationId) {
        return neo4jMetadataService.getPropertyMapOfServiceImplementation(serviceImplementationId);
    }

    @Override
    public Map<String, String> getPhysicalDatasetAttributeNamesAndTypes(String datasetId) {
        return neo4jMetadataService.getPhysicalDatasetAttributeNamesAndTypes(datasetId);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ubs.idp.metadata.service.MetadataService#getJoinRelationsForDataset
     * (java.lang.String)
     */
    @Override
    public List<JoinRelation> getJoinRelationsForDataset(String datasetId) {
        return neo4jMetadataService.getJoinRelationsForDataset(datasetId);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getThinToWidePivotColumnForDataset(java.lang.String)
     */
    @Override
    public String getThinToWidePivotColumnForDataset(String datasetId) {
        return neo4jMetadataService.getThinToWidePivotColumnForDataset(datasetId);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getThinToWideTargetPivotValuesForDataset(java.lang.String)
     */
    @Override
    public List<String> getThinToWideTargetPivotValuesForDataset(String datasetId) {
        return neo4jMetadataService.getThinToWideTargetPivotValuesForDataset(datasetId);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getThinToWideColumnsAssociatedWithPivotForDataset(java.lang.String)
     */
    @Override
    public List<String> getThinToWideColumnsAssociatedWithPivotForDataset(String datasetId) {
        return neo4jMetadataService.getThinToWideColumnsAssociatedWithPivotForDataset(datasetId);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getThinToWideKeyColumnPositionsForDataset(java.lang.String)
     */
    @Override
    public List<Integer> getThinToWideKeyColumnPositionsForDataset(String datasetId) {
        return neo4jMetadataService.getThinToWideKeyColumnPositionsForDataset(datasetId);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getThinToWideKeyColumnsForDataset(java.lang.String)
     */
    @Override
    public List<String> getThinToWideKeyColumnsForDataset(String datasetId) {
        return neo4jMetadataService.getThinToWideKeyColumnsForDataset(datasetId);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#
     * getTransformerPreProcessorRulesetsForDataset(java.lang.String)
     */
    @Override
    public List<String> getTransformerPreProcessorRulesetsForDataset(String datasetId) {
        return neo4jMetadataService.getTransformerPreProcessorRulesetsForDataset(datasetId);
    }

    @Override
    public String getPredicatesForDatasetInJoinRelation(String joinRelaionId, String datasetId) {
        return neo4jMetadataService.getPredicatesForDatasetInJoinRelation(joinRelaionId, datasetId);
    }

    @Override
    public boolean getUnionAllForView(String viewId) {
        return neo4jMetadataService.getUnionAllForView(viewId);
    }

    @Override
    public boolean isView(String datasetId) {
        return neo4jMetadataService.isView(datasetId);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ubs.idp.metadata.service.MetadataService#getAllDatasets()
     */
    @Override
    public List<String> getAllDatasets() {
        return neo4jMetadataService.getAllDatasets();
    }

    public List<String> replacePropertyPlaceholders(List<String> values) {
        List<String> newList = new ArrayList<String>();
        for (String value : values) {
            newList.add(replacePropertyPlaceholders(value));
        }
        return newList;
    }

    public Map<String, String> replacePropertyPlaceholdersForStringMap(Map<String, String> mapValues) {
        for (String key : mapValues.keySet()) {
            String value = mapValues.get(key);
            String newValue = replacePropertyPlaceholders(value);
            mapValues.put(key, newValue);
        }
        return mapValues;
    }

    public Map<String, List<String>> replacePropertyPlaceholdersForListMap(Map<String, List<String>> mapValues) {
        for (String key : mapValues.keySet()) {
            List<String> values = mapValues.get(key);
            List<String> newList = replacePropertyPlaceholders(values);
            mapValues.put(key, newList);
        }
        return mapValues;
    }

    /**
     * This method is the decorator method that will inspect any value that is
     * being returned by the metadata service for any property place holders and
     * replace them with the correct configured value
     * 
     * @param value
     * @return
     */
    public abstract String replacePropertyPlaceholders(String value);

    /**
     * Returns a Map <K,V> of Ordered DataSetId's for a given service
     * implementation. The ordering is done on basis of data set position. Key
     * is DatasetID and Value is datasetName.
     * 
     * @param serviceImplId
     * @return
     */
    @Override
    public List<Map<String, String>> getOrderedDatasetDetails(String serviceImplId) {
        return neo4jMetadataService.getOrderedDatasetDetails(serviceImplId);
    }
}

