package com.ubs.idp.metadata.model.evaluators;

import java.util.Iterator;

import org.neo4j.graphdb.Label;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Path;
import org.neo4j.graphdb.traversal.Evaluation;
import org.neo4j.graphdb.traversal.Evaluator;

import com.ubs.idp.metadata.model.BaseEntity;

public class NodeTypeEvaluator implements Evaluator
{
	private Class<? extends BaseEntity> type;

	
	public NodeTypeEvaluator(final Class<? extends BaseEntity> type)
	{
		this.type = type;
	}
	
	
	@Override
	public Evaluation evaluate(Path path) 
	{
		Node attributeNode = path.endNode();
		Iterator<Label> labels = attributeNode.getLabels().iterator();
		Label label;
		while( labels.hasNext() )
		{
			label = labels.next();
			if( label.name().equals(this.type.getSimpleName() ) )
			{
				return Evaluation.INCLUDE_AND_PRUNE;
			}
		}
		
		return Evaluation.EXCLUDE_AND_CONTINUE;

	}

}
