package com.ubs.idp.metadata.model;

import org.springframework.data.neo4j.annotation.NodeEntity;

@NodeEntity
public class Mapping extends BaseEntity
{

	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}

}
