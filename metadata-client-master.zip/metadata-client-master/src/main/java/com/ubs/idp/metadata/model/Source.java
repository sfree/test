package com.ubs.idp.metadata.model;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;

@NodeEntity
public class Source extends BaseEntity
{
	@RelatedTo(type = "OFFERS", direction = Direction.OUTGOING)
	public Set<Service> services = new HashSet<Service>();

	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}

}
