package com.ubs.idp.metadata.model.evaluators;

import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.NotFoundException;
import org.neo4j.graphdb.Path;
import org.neo4j.graphdb.traversal.Evaluation;
import org.neo4j.graphdb.traversal.Evaluator;

public class NodePropertyEvaluator implements Evaluator
{
	private String propName;
	private Object propValue;

	
	public NodePropertyEvaluator(final String propName, final Object propValue)
	{
		this.propName = propName;
		this.propValue = propValue;
	}
	
	
	@Override
	public Evaluation evaluate(Path path) 
	{
		Node attributeNode = path.endNode();
		try 
		{
			Object value = attributeNode.getProperty(propName);
			if( value.equals(propValue) )
			{
				return Evaluation.INCLUDE_AND_PRUNE;
			}
		} 
		catch (NotFoundException e) 
		{
		}
		
		return Evaluation.EXCLUDE_AND_CONTINUE;

	}

}
