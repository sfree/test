package com.ubs.idp.metadata.model;

import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.neo4j.annotation.NodeEntity;

import com.ubs.idp.metadata.model.enums.PROTOCOL;

@NodeEntity
@TypeAlias("JDBCChannel")
public class JDBCChannel extends Channel
{
	public JDBCChannel()
	{
		protocol = PROTOCOL.jdbc;
	}
	
	public String querySQL;

	public String queryDeltaSQL;
	
	public String driverClass;

	public String username;
	
	public String password;
	
	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}
}
