package com.ubs.idp.metadata.client.properties;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.PropertyPlaceholderHelper;

/**
 * This is a decorator class that will replace any environment specific property
 * placeholders with the meta data values being returned
 */
@Component("mdsClient")
public class MetadataServiceZookeeperDecorator extends MetadataServicePropertiesDecorator {

    private static final Logger LOGGER = LoggerFactory.getLogger(MetadataServiceZookeeperDecorator.class);

    private PropertyPlaceholderHelper propertyPlaceholderHelper;
    private PlaceHolderResolver placeHolderResolver;

    @Autowired
    private Environment env;

    public MetadataServiceZookeeperDecorator() throws IOException {
        super();

        LOGGER.debug("Initialising...");
        propertyPlaceholderHelper = new PropertyPlaceholderHelper("${", "}");
    }

    @Override
    public String replacePropertyPlaceholders(String value) {

        if (placeHolderResolver == null)
            placeHolderResolver = new PlaceHolderResolver(env);

        String placeholdersResolved = propertyPlaceholderHelper.replacePlaceholders(value, placeHolderResolver);
        LOGGER.debug("Value of placeholder string \"{}\" from Spring environment \"{}\"", placeholdersResolved);
        return placeholdersResolved;
    }

    class PlaceHolderResolver implements PropertyPlaceholderHelper.PlaceholderResolver {

        private Environment environment;

        public PlaceHolderResolver(Environment environment) {
            this.environment = environment;
        }

        @Override
        public String resolvePlaceholder(String placeholderName) {
            String resolvedPlaceholder = environment.getProperty(placeholderName);
            if (LOGGER.isDebugEnabled())
                LOGGER.debug("Value of property \"{}\" from Spring environment \"{}\"", placeholderName, resolvedPlaceholder);
            return resolvedPlaceholder;
        }
    }
}

