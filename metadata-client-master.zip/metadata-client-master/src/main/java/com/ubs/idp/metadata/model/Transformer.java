package com.ubs.idp.metadata.model;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;

@NodeEntity
public class Transformer extends BaseEntity
{
	/**
	 * The mappings that this transformer uses to mapping between
	 * attributes in the transformers
	 */
	@RelatedTo(type = "USES", direction = Direction.OUTGOING)
	public Set<Mapping> mappings = new HashSet<Mapping>();

    /*TO BE REVIEWED
     *  mappings property not being used at the moment, so not sure if its really required
     *  After review if we remove mappings then we'll rename attributesMapping -> mappings
      * */
    public String attributesMapping;

	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}

}
