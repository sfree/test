package com.ubs.idp.metadata.model.enums;

public enum PROTOCOL
{
	http,
	jdbc,
	file,
    jms
}
