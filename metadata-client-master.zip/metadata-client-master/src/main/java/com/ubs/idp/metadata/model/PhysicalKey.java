package com.ubs.idp.metadata.model;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.Fetch;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;
@NodeEntity
public class PhysicalKey extends BaseEntity
{	
	@RelatedTo(type = "PRIMARY_IDENTIFIER_OF", direction = Direction.OUTGOING)
	private PhysicalDataset dataset;

	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Fetch
	public PhysicalDataset getDataset()
	{
		return dataset;
	}

	public void setDataset(PhysicalDataset dataset)
	{
		this.dataset = dataset;
	}
	
	
}
