package com.ubs.idp.metadata.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.neo4j.cypher.ExecutionEngine;
import org.neo4j.cypher.ExecutionResult;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;
import org.neo4j.kernel.EmbeddedGraphDatabase;
import org.neo4j.kernel.impl.util.StringLogger;
import org.neo4j.rest.graphdb.RestAPI;
import org.neo4j.rest.graphdb.RestGraphDatabase;
import org.neo4j.rest.graphdb.entity.RestNode;
import org.neo4j.rest.graphdb.entity.RestRelationship;
import org.neo4j.rest.graphdb.query.RestCypherQueryEngine;
import org.neo4j.rest.graphdb.util.QueryResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.neo4j.support.Neo4jTemplate;
import org.springframework.data.neo4j.support.node.Neo4jHelper;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.idp.metadata.model.exceptions.MetadataException;

/**
 * Helper class that provides NEO4J helper methods
 * 
 * @author loverids
 *
 */
@Component
public class Neo4jUtils extends Neo4jHelper implements InitializingBean {
    private final static Logger logger = LoggerFactory.getLogger(Neo4jUtils.class);

    public final static String CLEAR_DB_CYPHER = "MATCH (n) OPTIONAL MATCH (n)-[r]->() DELETE n,r;";
    public final static String TERMINATE_COMMAND_CHAR = ";";

    /**
     * Specified the number of cypher commands to execute per batch when loading
     * from file
     */
    private final static int CYPER_COMMAND_BATCH_SIZE = 5000;

    @Autowired
    Neo4jTemplate template;

    @Autowired
    GraphDatabaseService graphDatabaseService;

    private ExecutionEngine engine = null;
    private RestCypherQueryEngine queryEngine;
    
    public void shutdownDatabase()
    {
    	graphDatabaseService.shutdown();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if (graphDatabaseService instanceof RestGraphDatabase) {
            RestAPI restAPI = ((RestGraphDatabase) graphDatabaseService).getRestAPI();
            queryEngine = new RestCypherQueryEngine(restAPI);
        } else if (graphDatabaseService instanceof EmbeddedGraphDatabase) {
            logger.debug("Initialising Cypher query execution engine");
            engine = new ExecutionEngine(graphDatabaseService, StringLogger.SYSTEM);
        }
    }

    /**
     * Clears the database of all nodes and relationships
     * 
     * @throws Exception
     */
    // @Transactional
    public void clearDatabase() {
        logger.warn("Clearing database");
        super.cleanDb(graphDatabaseService);
        executeCyperCommand(CLEAR_DB_CYPHER);
    }

    @Transactional("neo4jTransactionManager")
    public void executeCyperCommand(String cypherCommand) {
        logger.debug("Executing command: " + cypherCommand);

        if (engine != null) {
            engine.execute(cypherCommand).dumpToString();
        } else if (queryEngine != null) {
            queryEngine.query(cypherCommand, Collections.EMPTY_MAP);
        } else {
            throw new MetadataException("No execution of query engine has been intialised. Check configuration");
        }
    }

    @Transactional("neo4jTransactionManager")
    public void executeCyperCommands(List<String> cypherCommands) {
        int count = 0;
        for (String cypherCommand : cypherCommands) {
            // Need to escape any backslashes
            cypherCommand = escapeCypherIfRequired(cypherCommand);

            if (engine != null) {
                if (logger.isDebugEnabled())
                    logger.debug("Executing command: " + cypherCommand);
                ExecutionResult result = engine.execute(cypherCommand);
            } else if (queryEngine != null) {
                logger.debug("Executing command: " + cypherCommand);
                QueryResult result = queryEngine.query(cypherCommand, Collections.EMPTY_MAP);

            } else {
                throw new MetadataException("No execution of query engine has been intialised. Check configuration");
            }
            count++;

            if (count % 100 == 0)
                logger.info("Executed " + count + " of " + cypherCommands.size() + " commands");
        }
    }

    public List<Node> getAllNodes(int offset, int limit) {
        List<Node> nodes = null;
        String cypherQuery = "START n=node(*) RETURN n SKIP {offset} LIMIT {limit} ";

        // Create the query params
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("offset", offset);
        params.put("limit", limit);

        nodes = executeCypherQueryForNodes(cypherQuery, params);
        return nodes;
    }

    public List<Node> executeCypherQueryForNodes(String cypherQuery, Map<String, Object> parameters) {
        if (graphDatabaseService instanceof RestGraphDatabase) {
            return executeRemoteCypherQueryForNodes(cypherQuery, parameters);
        } else if (graphDatabaseService instanceof EmbeddedGraphDatabase) {
            return executeEmbeddedCypherQueryForNodes(cypherQuery, parameters);
        } else {
            throw new MetadataException("Graph database service not initialised correctly. Please check configuration");
        }
    }

    private List<Node> executeEmbeddedCypherQueryForNodes(String cypherQuery, Map<String, Object> parameters) {
        List<Node> resultList = new ArrayList<Node>();

        ExecutionResult result = engine.execute(cypherQuery, parameters);
        scala.collection.Iterator<Node> nodes = result.columnAs("n");
        while (nodes.hasNext()) {
            resultList.add(nodes.next());
        }
        return resultList;
    }

    private List<Node> executeRemoteCypherQueryForNodes(String cypherQuery, Map<String, Object> parameters) {
        List<Node> resultList = new ArrayList<Node>();

        logger.debug("entry, cypherQuery: {}", cypherQuery);
        QueryResult<Map<String, Object>> result = queryEngine.query(cypherQuery, parameters);
        Iterator<Map<String, Object>> iterator = result.iterator();

        while (iterator.hasNext()) {
            Map<String, Object> resultsetMap = iterator.next();

            // The results are returned as URLs to the restful endpoint of the
            // node
            Collection<?> nodeEndpoints = resultsetMap.values();
            for (Object nodeEndpoint : nodeEndpoints) {
                // Fetch each node from the endpoint by extracting the nodeId
                // from the
                // end of the URL
                // TODO: Must be a better way of doing this!
                // TODO: This is not going to be performent on large result sets
                RestNode restNode = (RestNode) nodeEndpoint;
                Node node = graphDatabaseService.getNodeById(restNode.getId());
                resultList.add(node);
            }
        }
        logger.debug("exit...");

        return resultList;
    }

    /**
     * Returns all relationships bounded by the offset and limit
     * 
     * @param offset
     * @param limit
     * @return
     */
    public List<Relationship> executeCypherQueryForRelationsips(String cypherQuery, Map<String, Object> parameters) {
        if (graphDatabaseService instanceof RestGraphDatabase) {
            return executeRemoteCypherQueryForRelationships(cypherQuery, parameters);
        } else if (graphDatabaseService instanceof EmbeddedGraphDatabase) {
            return executeEmbeddedCypherQueryForRelationships(cypherQuery, parameters);
        } else {
            throw new MetadataException("Graph database service not initialised correctly. Please check configuration");
        }
    }

    private List<Relationship> executeEmbeddedCypherQueryForRelationships(String cypherQuery, Map<String, Object> parameters) {
        List<Relationship> resultList = new ArrayList<Relationship>();

        ExecutionResult result = engine.execute(cypherQuery, parameters);
        scala.collection.Iterator<Relationship> relationships = result.columnAs("r");
        while (relationships.hasNext()) {
            resultList.add(relationships.next());
        }
        return resultList;
    }

    private List<Relationship> executeRemoteCypherQueryForRelationships(String cypherQuery, Map<String, Object> parameters) {
        List<Relationship> resultList = new ArrayList<Relationship>();
        QueryResult<Map<String, Object>> result = queryEngine.query(cypherQuery, parameters);
        Iterator<Map<String, Object>> iterator = result.iterator();

        while (iterator.hasNext()) {
            Map<String, Object> resultsetMap = iterator.next();

            // The results are returned as URLs to the restful endpoint of the
            // node
            Collection<?> nodeEndpoints = resultsetMap.values();
            for (Object nodeEndpoint : nodeEndpoints) {
                // Fetch each node from the endpoint by extracting the nodeId
                // from the
                // end of the URL
                // TODO: Must be a better way of doing this!
                // TODO: This is not going to be performent on large result sets
                RestRelationship restRelationship = (RestRelationship) nodeEndpoint;

                Relationship relationship = graphDatabaseService.getRelationshipById(restRelationship.getId());
                resultList.add(relationship);
            }
        }
        return resultList;
    }

    public long getNodeCount() {
        Long val = null;
        String cypherQuery = "MATCH (n) RETURN count(n)";

        List<Object> result = executeCypherQueryForObjects(cypherQuery, new HashMap<String, Object>(), "count(n)");

        // Not ideal this but the Remote version returns an Integer, the
        // embedded returns a Long
        val = Long.parseLong(result.get(0).toString());

        return val;
    }

    public long getNodeCountForLabelType(String labelType) {
        Long val = null;
        String cypherQuery = "match (n:" + labelType + ") return count(n);";

        List<Object> result = executeCypherQueryForObjects(cypherQuery, new HashMap<String, Object>(), "count(n)");

        // Not ideal this but the Remote version returns an Integer, the
        // embedded returns a Long
        val = Long.parseLong(result.get(0).toString());

        return val;
    }

    public long getRelationshipCount() {
        Long val = null;
        String cypherQuery = "match (n)-[r]->() return count(r)";

        // try( Transaction tx = getTransaction())
        {
            List<Object> result = executeCypherQueryForObjects(cypherQuery, new HashMap<String, Object>(), "count(r)");

            // Not ideal this but the Remote version returns an Integer, the
            // embedded returns a Long
            val = Long.parseLong(result.get(0).toString());
        }

        return val;
    }

    public List<Object> executeCypherQueryForObjects(String cypherQuery, Map<String, Object> parameters, String columnName) {
        if (graphDatabaseService instanceof RestGraphDatabase) {
            return executeRemoteCypherQueryForObjects(cypherQuery, parameters, columnName);
        } else if (graphDatabaseService instanceof EmbeddedGraphDatabase) {
            return executeEmbeddedCypherQueryForObjects(cypherQuery, parameters, columnName);
        } else {
            throw new MetadataException("Graph database service not initialised correctly. Please check configuration");
        }

    }

    public Iterator<Map<String, Object>> executeCypherQueryForObjects(String cypherQuery, Map<String, Object> parameters) {
        if (graphDatabaseService instanceof RestGraphDatabase) {
            return executeRemoteCypherQueryForObjects(cypherQuery, parameters);
        } else if (graphDatabaseService instanceof EmbeddedGraphDatabase) {
            return executeEmbeddedCypherQueryForObjects(cypherQuery, parameters);
        } else {
            throw new MetadataException("Graph database service not initialised correctly. Please check configuration");
        }

    }

    private List<Object> executeEmbeddedCypherQueryForObjects(String cypherQuery, Map<String, Object> parameters, String columnName) {
        List<Object> resultList = new ArrayList<Object>();

        ExecutionResult result = engine.execute(cypherQuery, parameters);
        scala.collection.Iterator<Node> nodes = result.columnAs(columnName);
        while (nodes.hasNext()) {
            resultList.add(nodes.next());
        }
        return resultList;
    }

    private Iterator<Map<String, Object>> executeEmbeddedCypherQueryForObjects(String cypherQuery, Map<String, Object> parameters) {
        ExecutionResult result = engine.execute(cypherQuery, parameters);
        return result.javaIterator();
    }

    private List<Object> executeRemoteCypherQueryForObjects(String cypherQuery, Map<String, Object> parameters, String columnName) {
        List<Object> resultList = new ArrayList<Object>();
        QueryResult<Map<String, Object>> result = queryEngine.query(cypherQuery, parameters);
        Iterator<Map<String, Object>> iterator = result.iterator();

        while (iterator.hasNext()) {
            Map<String, Object> resultsetMap = iterator.next();

            Object val = resultsetMap.get(columnName);
            resultList.add(val);
        }

        return resultList;
    }

    private Iterator<Map<String, Object>> executeRemoteCypherQueryForObjects(String cypherQuery, Map<String, Object> parameters) {
        List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
        QueryResult<Map<String, Object>> result = queryEngine.query(cypherQuery, parameters);
        return result.iterator();
    }

    /**
     * Escapes any characters that would cause an InvalidSyntax error when run
     * as Cypher
     * 
     * @param value
     * @return
     */
    private String escapeCypherIfRequired(String cypher) {
        if (cypher.contains("\\")) {
            cypher = cypher.replaceAll("\\\\", "\\\\\\\\");
        }
        return cypher;
    }

    public void loadMetaDataFromCypherFile(File file) throws FileNotFoundException, IOException {
        logger.info("Initialising Neo4J database with data from seed file " + file);

        int totalStatementCount = getStatementCountFromCypherFile(file);

        try (FileInputStream fis = new FileInputStream(file)) {
            loadMetaDataFromCypherFile(fis, totalStatementCount);
        }
    }

    public void loadMetaDataFromCypherFile(InputStream is, int totalStatementCount) throws IOException {
        long startTime = System.currentTimeMillis();

        try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            String command = "";
            String line = "";

            int lineCount = 1;
            int statementCount = 0;

            while ((line = br.readLine()) != null) {
                lineCount++;
                if (line.trim().startsWith("//"))
                    continue;
                if (line.trim().startsWith("--"))
                    continue;

                command += line + "\n";

                if (line.trim().endsWith(TERMINATE_COMMAND_CHAR)) {
                    String statement = command.trim();
                    statementCount++;

                    try {
                        if (statement.trim().equals(TERMINATE_COMMAND_CHAR)) {
                            logger.warn("Statement ending on line {} does not contain any commands!", lineCount);
                        } else {
                            logger.info("Executing statement " + statementCount + " of " + totalStatementCount + " ending on line "
                                    + lineCount);
                            executeCyperCommand(statement);
                        }
                    } catch (Exception e) {
                        String message = "The following error occured on line " + lineCount + " processing statement [" + statement + "]:"
                                + e.getMessage();
                        logger.error(message, e);
                        throw new MetadataException(message, new Exception(e));
                    }

                    command = "";
                }
            }

            long diff = System.currentTimeMillis() - startTime;
            logger.info("Executed " + statementCount + " statements in " + diff + "ms");

        }
    }

    /**
     * Returns the count of semi-colan terminated cypher statements that exist
     * in the passed file
     * 
     * @param file
     * @return
     * @throws IOException
     * @throws FileNotFoundException
     * @throws Exception
     */
    private int getStatementCountFromCypherFile(File file) throws FileNotFoundException, IOException {
        int statementCount = 0;

        try (FileInputStream fis = new FileInputStream(file); BufferedReader br = new BufferedReader(new InputStreamReader(fis))) {
            String line = "";

            while ((line = br.readLine()) != null) {
                if (line.trim().startsWith("//"))
                    continue;
                if (line.trim().startsWith("--"))
                    continue;

                if (line.trim().endsWith(TERMINATE_COMMAND_CHAR)) {
                    statementCount++;
                }
            }
        }

        return statementCount;
    }

    public void loadMetaDataFromCypherFileInBatches(InputStream is) throws IOException {
        long startTime = System.currentTimeMillis();
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        List<String> commandBatch = new ArrayList<String>();
        String command = "";
        String line = "";

        int lineCount = 1;
        int commandCount = 0;

        while ((line = br.readLine()) != null) {
            lineCount++;
            if (line.trim().startsWith("//"))
                continue;
            if (line.trim().startsWith("--"))
                continue;

            command += line + "\n";

            if (line.trim().endsWith(TERMINATE_COMMAND_CHAR)) {
                command = command.trim();
                commandBatch.add(command);
                commandCount++;

                if (commandBatch.size() == CYPER_COMMAND_BATCH_SIZE) {
                    logger.info("Executing batch of " + CYPER_COMMAND_BATCH_SIZE + " commands...");
                    try {
                        executeCyperCommands(commandBatch);
                    } catch (Exception e) {
                        String message = "The following error occured on line " + lineCount + " processing command [" + command + "]:"
                                + e.getMessage();
                        logger.error(message, e);
                        throw new MetadataException(message, e);
                    }
                    commandBatch.clear();
                }

                command = "";
            }
        }

        if (commandBatch.size() > 0)
            logger.info("Executing batch of " + commandBatch.size() + " commands...");
        try {
            executeCyperCommands(commandBatch);
        } catch (Exception e) {
            String message = "The following error occured on line " + lineCount + " processing command [" + command + "]:" + e.getMessage();
            logger.error(message, e);
            throw new MetadataException(message, e);
        }

        long diff = System.currentTimeMillis() - startTime;
        logger.info("Executed " + commandCount + " in " + diff + "ms");
    }

    public void dumpAllNodesWithIdsFromDatabase(String filename) {
        try (PrintStream ps = new PrintStream(filename)) {
            int offset = 0;
            List<Node> nodes = new ArrayList<Node>();
            do {
                nodes = getAllNodes(offset, 500);
                for (Node node : nodes) {
                    // Ignore blank or rogue nodes
                    if (node.getLabels().iterator().hasNext() && node.getPropertyKeys().iterator().hasNext()) {
                        ps.println(node.getLabels() + ":" + node.getProperty("id"));
                    }
                    // Dump details out any offending nodes with no details
                    else {
                        System.err.println("*******************" + node);
                        node.getId();
                        node.getPropertyKeys();
                        Iterator<Relationship> i = node.getRelationships().iterator();
                        while (i.hasNext()) {
                            Relationship r = i.next();
                            Node startNode = r.getStartNode();
                            Node endNode = r.getEndNode();
                            String startNodeInfo = startNode.getLabels() + ":" + startNode.getPropertyKeys();
                            String endNodeInfo = endNode.getLabels() + ":" + endNode.getPropertyKeys();

                            if (startNode.getPropertyKeys().iterator().hasNext()) {
                                startNodeInfo += ":" + startNode.getProperty("id");
                            }
                            if (endNode.getPropertyKeys().iterator().hasNext()) {
                                endNodeInfo += ":" + endNode.getProperty("id");
                            }

                            System.err.println("*** " + startNodeInfo + "-[" + r.getType().name() + "]-" + endNodeInfo);
                        }
                    }
                }

                offset += nodes.size();

            } while (nodes.size() > 0);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void dumpAllRelationshipsFromDatabase(String filename) {
        try (PrintStream ps = new PrintStream(filename)) {

            int offset = 0;
            List<Relationship> relationships = new ArrayList<Relationship>();
            do {
                relationships = getAllRelationships(offset, 500);
                for (Relationship relationship : relationships) {
                    String startNode = relationship.getStartNode().getLabels() + ":" + relationship.getStartNode().getProperty("id");
                    String endNode = relationship.getEndNode().getLabels() + ":" + relationship.getStartNode().getProperty("id");

                    ps.println("-[:" + relationship.getType().name() + "]-");
                }

                offset += relationships.size();

            } while (relationships.size() > 0);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public List<Relationship> getAllRelationships(int offset, int limit) {
        String cypherQuery = "START r=relationship(*) RETURN r SKIP {offset} LIMIT {limit} ";

        // Create the query params
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("offset", offset);
        params.put("limit", limit);

        return executeCypherQueryForRelationsips(cypherQuery, params);
    }
}
