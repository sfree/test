package com.ubs.idp.metadata.model;

import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.neo4j.annotation.NodeEntity;

import com.ubs.idp.metadata.model.enums.PROTOCOL;

@NodeEntity
@TypeAlias("Channel")
public class Channel extends BaseEntity
{
	public PROTOCOL protocol;
	
	public String url;
	
	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}
}
