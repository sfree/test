package com.ubs.idp.metadata.model;

public class PhysicalParameter extends BaseEntity {

    public int position;
    public String type;

    /**
     * Returns a text description of this node
     *
     * @return
     */
    @Override
    public String describe() {
        return null;
    }
}
