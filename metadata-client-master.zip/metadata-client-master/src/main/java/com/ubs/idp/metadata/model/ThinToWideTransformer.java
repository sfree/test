package com.ubs.idp.metadata.model;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;
import org.springframework.data.neo4j.annotation.RelatedToVia;

import com.ubs.idp.metadata.model.relationships.KeyColumnRelationshipType;

@NodeEntity
public class ThinToWideTransformer extends RulesTransformer
{
	/**
	 * The key columns to be used for a group when sorting the data
	 */
	@RelatedToVia(type = "HAS_KEY_COLUMN", direction = Direction.OUTGOING)
	public Set<KeyColumnRelationshipType> keyColumns = new HashSet<KeyColumnRelationshipType>();

	/**
	 * The column to select to compare against the target pivot values and pivot on
	 */
	@RelatedTo(type = "HAS_PIVOT_COLUMN", direction = Direction.OUTGOING)
	public PhysicalAttribute pivotColumn;

	/**
	 * The list of attributes to be added to the pivot for each target pivot value
	 */
	@RelatedTo(type = "HAS_ASSOCIATED_PIVOT_COLUMN", direction = Direction.OUTGOING)
	public Set<PhysicalAttribute> columnsAssociatedWithPivot = new HashSet<PhysicalAttribute>();

	/**
	 * Comma separated list of values to use to select for pivot
	 */
	public String targetPivotValues;
	
	/**
	 * Comma separated list of rulesets to be run before the ThinToWide transformation
	 * is executed
	 */
	public String preProcessorRules;
	
	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}

}
