package com.ubs.idp.metadata.model.relationships;

import org.neo4j.graphdb.Relationship;
import org.springframework.data.neo4j.annotation.EndNode;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.RelationshipEntity;
import org.springframework.data.neo4j.annotation.StartNode;

import com.ubs.idp.metadata.model.PhysicalAttribute;
import com.ubs.idp.metadata.model.ThinToWideTransformer;
import com.ubs.idp.metadata.model.View;

@RelationshipEntity(type="HAS_KEY_COLUMN")
public class KeyColumnRelationshipType extends BaseRelationshipType
{

	
	public KeyColumnRelationshipType()
	{
		
	}
	
	public KeyColumnRelationshipType(ThinToWideTransformer transformer,
									   PhysicalAttribute physicalAttribute,
									   int sortOrder
									   )
	{
		this.sortOrder = sortOrder;
		this.physicalAttribute = physicalAttribute;
		this.transformer = transformer;
	}
	
	public int sortOrder;	
		
	@StartNode public ThinToWideTransformer transformer;
	@EndNode public PhysicalAttribute physicalAttribute;

	
}
