package com.ubs.idp.metadata.model;

import org.springframework.data.neo4j.annotation.NodeEntity;

@NodeEntity
public class Role extends BaseEntity
{

	@Override
	public String describe()
	{
		return null;
	}

}
