package com.ubs.idp.metadata.model;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.RelatedTo;

import java.util.HashSet;
import java.util.Set;

public class Routine extends BaseEntity {

    @RelatedTo(type = "REQUIRES", direction = Direction.OUTGOING)
    public Set<PhysicalParameter> parameters = new HashSet<PhysicalParameter>();

    /**
     * Returns a text description of this node
     *
     * @return
     */
    @Override
    public String describe() {
        return null;
    }

    public Set<PhysicalParameter> getParameters() {
        return parameters;
    }

    public void setParameters(Set<PhysicalParameter> parameters) {
        this.parameters = parameters;
    }
}
