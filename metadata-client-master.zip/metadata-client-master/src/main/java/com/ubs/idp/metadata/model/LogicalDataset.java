package com.ubs.idp.metadata.model;

import org.springframework.data.neo4j.annotation.NodeEntity;

@NodeEntity
@Deprecated
public class LogicalDataset extends Dataset
{

}
