package com.ubs.idp.metadata.model;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.Fetch;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;

@NodeEntity
public class Dataset extends BaseEntity
{
	
	/**
	 * Specifies the delimiter character for datasets that are ingested in a CSV format
	 */
	@Fetch
	public String delimiter;
	
	/**
	 * Specifies the XD jobs that populate / refresh this dataset
	 */
	@Fetch
	public String jobs;
	
	/**
	 * The role that is required to access this dataset
	 */
	@RelatedTo(type = "REQUIRES", direction = Direction.OUTGOING)
	public Set<Role> roles = new HashSet<Role>();


	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Fetch
	public Set<Role> getRoles()
	{
		return roles;
	}

	public void setRoles(Set<Role> roles)
	{
		this.roles = roles;
	}

	
}
