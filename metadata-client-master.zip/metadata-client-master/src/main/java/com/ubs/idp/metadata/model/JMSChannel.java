package com.ubs.idp.metadata.model;

import com.ubs.idp.metadata.model.enums.PROTOCOL;

public class JMSChannel extends Channel {

    public JMSChannel() {
        protocol = PROTOCOL.jms;
    }
    public String user;
    public String password;
    public String queueManager;
    public String transportType;
    public String port;
    public String channel;
    public String SSLCipherSuite;
    public String targetClient;

    @Override
    public String describe() {

        return null;
    }
}
