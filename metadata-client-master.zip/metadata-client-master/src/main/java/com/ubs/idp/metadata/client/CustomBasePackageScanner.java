package com.ubs.idp.metadata.client;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.ManagedSet;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelationshipEntity;
import org.springframework.data.neo4j.config.BasePackageScanner;

/**
 * This is pretty much a replication of the {@link BasePackageScanner} class
 * except that we are explicitly setting our class loader as the context class
 * loader within Spring XD doesn't find our Neo4J Entities with the jar file
 * 
 * @author loverids
 *
 */
public class CustomBasePackageScanner {
    private static final ClassLoader classLoader = CustomBasePackageScanner.class.getClassLoader();

    public static Set<String> scanBasePackage(String basePackage) {
        return scanBasePackages(basePackage.split(","));
    }

    public static Set<String> scanBasePackages(String... basePackages) {
        ClassPathScanningCandidateComponentProvider componentProvider = new ClassPathScanningCandidateComponentProvider(false);
        componentProvider.addIncludeFilter(new AnnotationTypeFilter(NodeEntity.class));
        componentProvider.addIncludeFilter(new AnnotationTypeFilter(RelationshipEntity.class));
        componentProvider.setResourceLoader(new PathMatchingResourcePatternResolver(classLoader));

        Set<String> classes = new ManagedSet<String>();
        for (String basePackage : basePackages) {
            for (BeanDefinition candidate : componentProvider.findCandidateComponents(basePackage)) {
                classes.add(candidate.getBeanClassName());
            }
        }

        return classes;
    }

    public static Set<? extends Class<?>> scanBasePackageForClasses(String... basePackages) throws ClassNotFoundException {
        Set<Class<?>> classes = new HashSet<>();
        for (String basePackage : basePackages) {
            for (String className : scanBasePackage(basePackage)) {
                classes.add(loadClass(className));
            }
        }
        return classes;
    }

    private static Class loadClass(String className) throws ClassNotFoundException {
        return classLoader.loadClass(className);
    }
}
