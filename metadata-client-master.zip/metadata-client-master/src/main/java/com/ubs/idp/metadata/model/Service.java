package com.ubs.idp.metadata.model;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.Fetch;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.annotation.RelatedTo;
@NodeEntity
public class Service extends BaseEntity
{
	@RelatedTo(type = "IMPLEMENTED_BY", direction = Direction.OUTGOING)
	public Set<ServiceImplementation> serviceImplementations = new HashSet<ServiceImplementation>();

	@Query (value="start s=node({self}) match (s:Service)-[:IMPLEMENTED_BY]->(si:ServiceImplementation)-[r:ACCESSED_VIA]->(c:Channel) where r.priority=1 return c")
	private Channel primaryServiceChannel;

	@Query (value="start s=node({self}) match (s:Service)-[:IMPLEMENTED_BY]->(si:ServiceImplementation)-[r:ACCESSED_VIA]->(c:Channel) where r.priority=1 and c.protocol='http' return c.url")
	private String primaryServiceURL;

	
	@Override
	public String describe()
	{
		// TODO Auto-generated method stub
		return null;
	}


	@Fetch
	public Channel getPrimaryServiceChannel()
	{
		return primaryServiceChannel;
	}


	@Fetch
	public String getPrimaryServiceURL()
	{
		return primaryServiceURL;
	}

	
}
