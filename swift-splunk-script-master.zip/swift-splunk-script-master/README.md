swift-splunk-script
===================
