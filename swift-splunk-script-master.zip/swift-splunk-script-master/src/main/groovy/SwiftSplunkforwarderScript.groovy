import org.linkedin.glu.agent.api.ShellExecException
import com.ubs.swift.properties.PropertiesExporter
import java.text.SimpleDateFormat

/**
 *Deploys a standard Tomcat server to a linux host
 */
class SwiftSplunkforwarderScript {
    def group
    def artifact
    def projectVersion
    def startPort = 8089
    def installDest
    def installRootDir
    def logsDir
    
    transient def baseDir = "/sbclocal/apps/devops/logforwarder"

    def install = {
        group = params.project.g
        artifact = params.project.a
        projectVersion = params.project.v
        startPort = params.startPort ?: 8089

        installDest = baseDir + '/' + group + '/' + artifact + '/' + projectVersion

        log.info("Installing to ${installDest}...")
        
        def installRoot = rootShell.mkdirs(installDest)
        installRootDir = installRoot.file
        logsDir = "${installRootDir}/logs"
        
        // can't use shell.fetch as it doesn't follow redirects.  But if no redirects required, use this.
        // shell.fetch(buildRepositoryUrl(), installDest)
        def repoUrl = buildRepositoryUrl()
        log.info("Downloading from ${repoUrl}... to ${installRoot}")

        rootShell.exec("curl -L '${repoUrl}' -o ${installRootDir}/install-dist.tar.gz")

        log.info("Extracting installation bundle '${installRoot}/install-dist.tar.gz'")
        rootShell.untar("${installRoot}/install-dist.tar.gz", installRoot)
        
        log.info("Cleaning up installation bundle '${installRoot}/install-dist.tar.gz'")
        rootShell.rm("${installRoot}/install-dist.tar.gz")

        log.info("Install Complete")
    }

    def configure = {
        log.info "Configuring..."

        // // Export properties for the application locally.
        // PropertiesExporter.get().exportProperties(this, shell.toResource(installDest + '/swift-demo-server.properties'))

        // setup some process monitoring
        timers.schedule(timer: "processMonitor",
            repeatFrequency: params.serverMonitorFrequency ?: '30s')

        log.info "Configuration complete."
    }

    def start = {
        log.info "Starting Splunk Universal LogForwarder"
        def pid = getProcessId()
        if(pid!=null){
            shell.fail("Process is already started. Process id: ${pid}")
        }
        if(isListening()){
            shell.fail("Port already in use. startPort: ${startPort}")
        }

        // Command must run in the back ground and not cause the agent to block
        String startCommand = "${installRootDir}/bin/splunk start --accept-license"

        log.info "Starting with command ${startCommand}"
        rootShell.exec(redirectStderr:true, command: startCommand)

        rootShell.waitFor(timeout: params.startTimeout ?: '15s', heartbeat: '1s') {
            log.info("Waiting for process to start")
            return isProcessUp() && isListening()
        }
    }

    def stop = {
        log.info "Stopping"
        def pid = getProcessId()
        if (pid != null) {
            // requires JRE_HOME?
            String stopCommand = "${installRootDir}/bin/splunk stop"
            log.info "Stopping with command ${stopCommand}"
            rootShell.exec(redirectStderr:true, command: stopCommand)

            rootShell.waitFor(timeout: params.stopTimeout ?: '15s', heartbeat: '1s') {
                log.info("Waiting for process to terminate")
                return isProcessDown()
            }
        }
        log.info("Stop Phase Completed")
    }

    def unconfigure = {
        log.info "Stopping process monitor"
        timers.cancel(timer: "processMonitor")
    }

    def uninstall = {
        def timestamp = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
        def trashDest = baseDir + '/' + group + '/' + artifact + '/.trash/' + timestamp

        log.info "Moving artifact to trash directory..."
        log.info "Artifact is ${installDest}; trash dir is ${trashDest}"
        def trashDir = rootShell.mv(installDest, trashDest)
    }

    /**
     * Defines the timer that will check for the server to be up and running and will act
     * according if not (change state)
     */
    def processMonitor = {
        try
        {
            log.info "Performing process monitoring"
            def up = isProcessUp()
            def listening = isListening()
            log.info "up [$up]"

            def currentState = stateManager.state.currentState
            def currentError = stateManager.state.error

            def newState = null
            def newError = null
            def forceChangeState = false

            // case when current state is running
            if (currentState == 'running') {
                if (isProcessDown()) {
                    newState = 'stopped'
                    newError = 'Server down detected. Check the log file for errors.'
                    log.warn "${newError} => forcing new state ${newState}"
                } else if (currentError && listening) {
                    // reset the error now the process is up
                    forceChangeState = true
                } else if (!currentError && !listening) {
                    newError = "Server is not listening on port ${startPort}"
                    log.warn "${newError} => leaving in state runing"
                }
            } else {
                if(up)
                {
                    newState = 'running'
                    log.info "Server up detected."
                }
            }

            if (newState || newError || forceChangeState)
                stateManager.forceChangeState(newState, newError)

            log.debug "Server Monitor: ${stateManager.state.currentState} / ${up}"
        }
        catch(Throwable th)
        {
            log.warn "Exception while running serverMonitor: ${th.message}"
            log.debug("Exception while running serverMonitor (ignored)", th)
        }
        log.info "Exit processMonitor"
    }


    private String buildRepositoryUrl() {
        String nexusUrl = "http://cft-nexus.ldn.swissbank.com:8081/nexus/service/local/artifact/maven/redirect?r=g-internal-releases-and-snapshots" +
                "&g=${group}&a=${artifact}&v=${projectVersion}&e=tar.gz&c=dist"

        log.info("URL to artifact is '${nexusUrl}'")

        return nexusUrl
    }

    private Integer getProcessId() {
        // E.g. ps -ef | grep -F 'com.jetbrains' | grep -F 'jetbrains-license-server-tomcat' | grep -v 'grep' | awk '{print $2 }'
        def output = shell.exec(redirectStderr: true, command: "ps -ef | grep -F 'splunkd pid=' | grep -v 'agent-cli.sh' | grep -v 'grep' | awk '{ print \$2 }'")
        log.info("Process ID '${output}'");

        if (output == '') return null

        return output as int
    }

    private boolean isProcessUp()
    {
        return !isProcessDown()
    }

    private boolean isProcessDown()
    {
        return getProcessId() == null
    }

    private boolean isListening()
    {
        def listening = shell.listening('localhost', startPort)
        log.info("Some process is listening on port ${startPort} = ${listening}")
        return listening
    }
}