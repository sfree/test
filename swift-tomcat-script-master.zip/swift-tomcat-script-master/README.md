swift-tomcat-script
===================

TeamCity Build status:
 * Deploy:  [![Build Status](https://cft-teamcity.ldn.swissbank.com/app/rest/builds/buildType:%28id:UbsNeo_NeoSwift_SwiftTomcatScript_Deploy%29/statusIcon)](https://cft-teamcity.ldn.swissbank.com/project.html?projectId=UbsNeo_NeoSwift_SwiftTomcatScript)
 * Release: [![Build Status](https://cft-teamcity.ldn.swissbank.com/app/rest/builds/buildType:%28id:UbsNeo_NeoSwift_SwiftTomcatScript_Release%29/statusIcon)](https://cft-teamcity.ldn.swissbank.com/project.html?projectId=UbsNeo_NeoSwift_SwiftTomcatScript)


The Groovy script is used by Swift Glu agents to deploy/start/stop a standard Tomcat server.

Refer to the following documents for developing/testing Swift Glu scripts in general:
* http://confluence.swissbank.com/display/neo/Swift+Glu+Scripts 
* https://connections.swissbank.com/docs/DOC-49595 

Don't know what Swift is? Watch the demo video at:
 * http://confluence.swissbank.com/display/neo/Swift


Motivation
----------

This script was initially written to deploy Jetbrians License Server (which is a web application with an embedded Tomcat instance).

The Jetbrains License Server can be downloaded here:
 * http://cft-nexus.ldn.swissbank.com:8081/nexus/service/local/repositories/int-ubs-other-releases/content/com/jetbrains/jetbrains-license-server-tomcat/374/jetbrains-license-server-tomcat-374-dist.tar.gz

The script is made as generic as possible to be able to deploy other Tomcat instances provided that they have the same directory structure as the Jetbrains License Server.


Testing outside of Swift
------------------------
You are welcome to modify this script to suit your needs. Pull requsts are welcome if you think you changes are generic enough to be useful in most cases.

If you want to test the script outside of Swift, read the section "Testing outside of Swift" in the following wiki page:
 * http://confluence.swissbank.com/display/neo/Swift+Glu+Scripts

If you need help with Swift in general, get in touch with the Swift Team at dl-ubs-swift@ubs.com
