package com.ubs.idp.test.zookeeper.utils.rsa;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.ubs.idp.zookeeper.utils.rsa.ConfigPropertyValueDecryptionProvider;
import com.ubs.idp.zookeeper.utils.rsa.RSASecurityProvider;

public class ConfigPropertyValueDecryptionProviderTest {

	@Test
	public void test() throws Exception {
		String publicKeyFile = "pub.der";
		String encryptedValue = "pmYP0B+HZheTaBA5tqtGj2WftKWwuIn0IUigZWoWQhMJoWAg8kwIFGp3vHjmE8Ruzm/KAi7YrBQu+UTBIenl6j5wwjmRE/o3jB7jHg5C4EdHGR+d9S8c9ipqEDhIb0vj5XgWMndvZgCMNpbV3fgq26ox079QGw4KqDbSevXycmsgcryUm+X1NniUXjurrIxT32fJKYOH9Tl5JMHarW1/unbLozmuuyEN+yIYQQaceCc41w/gNMk+JgosvqtFL3z0P/vHDEOcaR963PgefCRe2E8u3DLcs/lCYGotDnh3JOFWyRARbh6Tm/wghk+mzzsFquPQV1K9T7KkuXFBcebAzA==";
		String expectedValue = "testing123";
		
		ConfigPropertyValueDecryptionProvider provider = new ConfigPropertyValueDecryptionProvider();
		RSASecurityProvider securityProvider = new RSASecurityProvider();
		
		provider.setRsaSecurityProvider(securityProvider);
		
		Resource decryptionKeyResource = new ClassPathResource(publicKeyFile);
		
		provider.setDecryptionKeyResource(decryptionKeyResource);
		
		provider.init();
		
		String decryptedValue = provider.decrypt("myValue", encryptedValue);
		
		System.out.println("Decrypted Value: " + decryptedValue);
		
		assertEquals("Unexpected decrytion result?", expectedValue, decryptedValue);
	}

}
