package com.ubs.idp.test.zookeeper.utils.rsa;

import static org.junit.Assert.*;

import java.security.PrivateKey;
import java.security.PublicKey;

import org.bouncycastle.util.encoders.Base64;
import org.junit.Test;

import com.ubs.idp.zookeeper.utils.rsa.RSAKeyFileLoader;
import com.ubs.idp.zookeeper.utils.rsa.RSASecurityProvider;

public class RSASecurityProviderTest {

	@Test
	public void test() throws Exception {
		String privateKeyFilePath = "src/test/resources/priv.der";
		String publicKeyFile = "pub.der";
		
		RSASecurityProvider securityProvider = new RSASecurityProvider();
		
		securityProvider.init();
		
		String originalPropertyValue = "MyValue";
		
		// Encrypt using private key
		PrivateKey privateKey = RSAKeyFileLoader.loadPrivateKey(privateKeyFilePath);
		
		byte[] encryptedBytes = securityProvider.encrypt(originalPropertyValue.getBytes(), privateKey);
		String encryptedPropertyValue = new String(Base64.encode(encryptedBytes), RSASecurityProvider.DEFAULT_CHARSET);
		
		System.out.println("Encrypted value: " + encryptedPropertyValue);
		
		// Decrypt using public key
		
		byte[] decoded = Base64.decode(encryptedPropertyValue.getBytes());
		
		PublicKey publicKey = RSAKeyFileLoader.loadPublicKeyFromClasspath(publicKeyFile);
		
		byte[] decryptedBytes = securityProvider.decrypt(decoded, publicKey);

		String decryptedPropertyValue = new String(decryptedBytes, RSASecurityProvider.DEFAULT_CHARSET);

		System.out.println("Decrypted value: " + decryptedPropertyValue);

		// Check encrypt/decrypt round trip
		
		assertEquals(originalPropertyValue, decryptedPropertyValue);
	}

}
