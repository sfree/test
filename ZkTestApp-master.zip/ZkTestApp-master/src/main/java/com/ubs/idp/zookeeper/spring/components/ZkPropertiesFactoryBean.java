package com.ubs.idp.zookeeper.spring.components;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.config.AbstractFactoryBean;

import com.ubs.idp.zookeeper.utils.ZkUtils;
import com.ubs.idp.zookeeper.utils.rsa.ConfigPropertyValueDecryptionProvider;

/**
 * Spring PropertyPlaceholderConfigurer factory bean for Zookeeper hosted properties file
 * @author paulmc
 */
public class ZkPropertiesFactoryBean extends AbstractFactoryBean<Properties> {
	private int timeout = 1000;
	private String zkConnect = "localhost:2181";
	private String zkPath = "/";
	private String zkUser = null;
	private String zkPassword = null;
	private ZkUtils zkUtils = null;
	private Map<String, String> encryptedProperties = null;

	private ConfigPropertyValueDecryptionProvider decryptionProvider;

	/**
	 * Plain Spring constructor
	 */
	public ZkPropertiesFactoryBean () {
		zkUtils = new ZkUtils();
	}

	/**
	 * Set the decryption provider
	 * @param decryptionProvider
	 */
	public void setDecryptionProvider(ConfigPropertyValueDecryptionProvider decryptionProvider) {
		this.decryptionProvider = decryptionProvider;
	}  

	/**
	 * Set the Zookeeper connection string
	 * @param zkConnect
	 */
	public void setZkConnect(String zkConnect) {
		this.zkConnect = zkConnect;
	}

	/**
	 * Set the Zookeeper path for our properties file
	 * @param zkPath
	 */
	public void setZkPath(String zkPath) {
		this.zkPath = zkPath;
	}

	/**
	 * @param zkBootPath
	 * @throws IOException 
	 */
	public void setZkBoot(String zkBootPath) throws IOException {
		Properties prop = new Properties();

		if (zkBootPath.startsWith("classpath:")) {
			prop.load(this.getClass().getClassLoader().getResourceAsStream(zkBootPath.substring(zkBootPath.indexOf(":")+1)));
		} else if (zkBootPath.startsWith("file:")) {
			Reader reader = new FileReader(zkBootPath.substring(zkBootPath.indexOf(":")+1));
			prop.load(reader);
			reader.close();
		} else {
			throw new IllegalArgumentException("Invalid boot file setting?");
		}

		zkConnect = prop.getProperty(ZkUtils.ZK_CONNECT);
		zkPath = prop.getProperty(ZkUtils.ZK_PATH);
		
		// Fetch optional user+pass
		if (prop.containsKey(ZkUtils.ZK_USER)) {
			zkUser = prop.getProperty(ZkUtils.ZK_USER);
		}
		
		if (prop.containsKey(ZkUtils.ZK_PASSWORD)) {
			zkPassword = prop.getProperty(ZkUtils.ZK_PASSWORD);
		}
	}
	
	public void setEncryptedPropertieNames(List<String> propertyNames) {
		encryptedProperties = new HashMap<String, String>();
		for (String propertyname : propertyNames) {
			encryptedProperties.put(propertyname, propertyname);
		}
	}

	/**
	 * Set digest auth user id
	 * @param zkUser
	 */
	public void setZkUser(String zkUser) {
		this.zkUser = zkUser;
	}

	/**
	 * Set digest auth password
	 * @param zkPassword
	 */
	public void setZkPassword(String zkPassword) {
		this.zkPassword = zkPassword;
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.config.AbstractFactoryBean#createInstance()
	 */
	@Override
	protected Properties createInstance() throws Exception {
		zkUtils.setTimeout(timeout);
		zkUtils.setZkConnect(zkConnect);
		zkUtils.setZkPath(zkPath);
		zkUtils.setUser(zkUser);
		
		String zkPassword = this.zkPassword;
		
		if (decryptionProvider != null) {
			try {
				zkPassword = decryptionProvider.decrypt(ZkUtils.ZK_PASSWORD, zkPassword);
			} catch (GeneralSecurityException e) {
				logger.error("Failed to decrypt Zookeeper connection password!?", e);
			}
		}

		zkUtils.setPassword(zkPassword);

		Properties properties = zkUtils.pullCfg();
		
		// Check for decryption
		if (encryptedProperties != null && encryptedProperties.size() > 0 &&
			decryptionProvider != null) {
			
			for(Object tmpName : properties.keySet()) {
				String propertyName = tmpName.toString();
				if (encryptedProperties.containsKey(propertyName)) {
					String decryptedValue = decryptionProvider.decrypt(propertyName, properties.getProperty(propertyName));
					properties.put(propertyName, decryptedValue);
				}
			}
		}
		
		return properties;
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.config.AbstractFactoryBean#getObjectType()
	 */
	@Override
	public Class<Properties> getObjectType() {
		return Properties.class;
	}
}
