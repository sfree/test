package com.ubs.idp.zookeeper.spring;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Stand alone application launcher
 * @author mcminnp
 */
public class Application {
	
	private static ApplicationContext context = null;
	
	private static Logger logger = Logger.getLogger(Application.class);
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		logger.debug("Launching Spring Context...");
		
		context = new ClassPathXmlApplicationContext("META-INF/spring-context.xml");
	}
}
