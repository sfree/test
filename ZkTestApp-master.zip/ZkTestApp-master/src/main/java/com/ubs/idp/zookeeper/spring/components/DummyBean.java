package com.ubs.idp.zookeeper.spring.components;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Dummy bean to pick up properties from Zookeeper property place holder
 * @author paulmc
 */
@Component
public class DummyBean {

	/**
	 * Example of optional property
	 * @param property the property to set
	 */
	@Value("#{systemProperties.getProperty('cmdArg') ?: null}") 
	public void setCmdArg(String cmdArg) {
		if (cmdArg != null) {
			System.out.println("cmdArg set to: " + cmdArg);
		}
	}

	/**
	 * Debug output
	 * @param property
	 */
	@Value("${cassandra.node}") 
	public void setCassandraNode(String cassandraNode) { 
	    System.out.println("cassandraNode set to: " + cassandraNode);
	}

	/**
	 * Check RSA decryption
	 * @param password
	 */
	@Value("${dummy.password}")
	public void setPassword(String password) {
		System.out.println("password set to: " + password);
	}
}
