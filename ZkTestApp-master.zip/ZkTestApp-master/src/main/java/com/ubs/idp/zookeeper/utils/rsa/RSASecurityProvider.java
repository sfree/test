package com.ubs.idp.zookeeper.utils.rsa;
import java.nio.charset.Charset;
import java.security.Key;
import java.security.Security;

import javax.crypto.Cipher;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

/**
 * RSA security provider class (based on Neo/Swift - crashed together interface and RSA impl for this test
 * @author mcminnp
 */
public class RSASecurityProvider {

	public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
	
    /**
     * algorithm/mode/padding
     */
    public static final String ALGORITHM = "RSA";

    private Cipher cipher;
    private final Object cipherLock = new Object();

    public void init() throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        cipher = Cipher.getInstance(ALGORITHM);
    }

    public byte[] encrypt(byte[] input, Key key) {
        return crypt(input, key, Cipher.ENCRYPT_MODE);
    }

    public byte[] decrypt(byte[] input, Key key) {
        return crypt(input, key, Cipher.DECRYPT_MODE);
    }

    private byte[] crypt(byte[] input, Key key, int cipherMode) {
        try {
            synchronized (cipherLock) {
                cipher.init(cipherMode, key);
                return cipher.doFinal(input);
            }
        } catch (Exception e) {
            throw new RuntimeException("rsa crypt failed", e);
        }
    }

}