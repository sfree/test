package com.ubs.idp.zookeeper.utils.rsa;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.util.HashMap;
import java.util.Map;

import org.bouncycastle.util.encoders.Base64;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.core.io.Resource;
import org.springframework.util.StringUtils;

/**
 * Configuration property provider supporting RSA encrypted properties
 * @author mcminnp
 */
public class ConfigPropertyValueDecryptionProvider {

	private Map<Object, String> encryptedValues = new HashMap<Object, String>();

	private String decryptionKeyFilePath;
	private String decryptionKeyClassPath;
	private Resource decryptionKeyResource;

	private RSASecurityProvider rsaSecurityProvider;

	public void init() throws Exception {
		// Default provider (we are only using RSA for now)

		if (rsaSecurityProvider == null) {
			rsaSecurityProvider = new RSASecurityProvider();
		}
		
		rsaSecurityProvider.init();
	}

	protected PublicKey getPublicKey() throws NoSuchAlgorithmException, InvalidKeySpecException, IOException{
		if (decryptionKeyResource != null && decryptionKeyResource.exists()) {
			return RSAKeyFileLoader.loadPublicKeyFromInputStream(decryptionKeyResource.getInputStream());
		} else if (StringUtils.hasText(decryptionKeyClassPath)){
			return RSAKeyFileLoader.loadPublicKeyFromClasspath(decryptionKeyClassPath);
		}else if (StringUtils.hasText(decryptionKeyFilePath)){
			return RSAKeyFileLoader.loadPublicKey(decryptionKeyFilePath);
		}else{
			throw new IOException("A decryptionKeyClassPath or decryptionKeyFilePath must be provided");
		}
	}
	public String decrypt(String key, String propertyValue) throws GeneralSecurityException, IOException {
		encryptedValues.put(key, propertyValue);
		byte[] propertyValueBytes = propertyValue.getBytes(RSASecurityProvider.DEFAULT_CHARSET);
		byte[] decoded = Base64.decode(propertyValueBytes);
		PublicKey publicKey = getPublicKey();
		byte[] outputBytes = rsaSecurityProvider.decrypt(decoded, publicKey);
		String output = new String(outputBytes, RSASecurityProvider.DEFAULT_CHARSET);
		return output;
	}

	public boolean hasEncryptedValue(Object key) {
		return encryptedValues.containsKey(key);
	}

	public String getEncryptedValue(Object key) {
		return encryptedValues.get(key);
	}

	/**
	 * @return the decryptionKeyClassPath
	 */
	public String getDecryptionKeyClassPath() {
		return decryptionKeyClassPath;
	}

	/**
	 * @param decryptionKeyResource The Spring {@link Resource} containing the decryption key.
	 */
	public void setDecryptionKeyResource(Resource decryptionKeyResource) {
		this.decryptionKeyResource = decryptionKeyResource;
	}

	@Required
	public void setRsaSecurityProvider(RSASecurityProvider securityProvider) {
		this.rsaSecurityProvider = securityProvider;
	}
}