package com.ubs.idp.zookeeper.utils.rsa;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import com.google.common.io.Closeables;

/**
 * RSA file loader (based on Neo/Swift)
 * @author mcminnp
 */
public class RSAKeyFileLoader {

	public static PrivateKey loadPrivateKey(String privateKeyFilePath) throws FileNotFoundException, IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		byte[] keyBytes = loadKeyFile(privateKeyFilePath);
		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory kf = KeyFactory.getInstance(RSASecurityProvider.ALGORITHM);
		return kf.generatePrivate(spec);
	}

	static PublicKey makeKey(byte[] keyBytes) throws NoSuchAlgorithmException, InvalidKeySpecException {
		X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
		KeyFactory kf = KeyFactory.getInstance(RSASecurityProvider.ALGORITHM);
		return kf.generatePublic(spec);
	}

	public static PublicKey loadPublicKeyFromClasspath(String publicKeyFilePath) throws IOException,
	NoSuchAlgorithmException, InvalidKeySpecException {

		byte[] keyBytes = loadKeyFileFromClasspath(publicKeyFilePath);
		return makeKey(keyBytes);

	}

	/**
	 * Note that this closes the {@link InputStream} once it has read the key
	 */
	public static PublicKey loadPublicKeyFromInputStream(InputStream keyInputStream) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		return makeKey(loadKeyFileFromInputStream(keyInputStream));
	}

	public static PublicKey loadPublicKey(String publicKeyFilePath) throws IOException, NoSuchAlgorithmException,
	InvalidKeySpecException {
		byte[] keyBytes = loadKeyFile(publicKeyFilePath);
		return makeKey(keyBytes);

	}

	static byte[] loadKeyFileFromClasspath(String publicKeyPath) throws FileNotFoundException, IOException {
		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		InputStream is = cl.getResourceAsStream(publicKeyPath);

		if (is == null) {
			throw new IOException("Unable to find file " + publicKeyPath);
		}        

		return loadKeyFileFromInputStream(is);
	}

	static byte[] loadKeyFileFromInputStream(InputStream is) throws IOException {
		byte[] byteData;

		try {
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			for (int readBytes = is.read(); readBytes >= 0; readBytes = is.read())
				outputStream.write(readBytes);

			// Convert the contents of the output stream into a byte array
			byteData = outputStream.toByteArray();
		} finally {
			// Close the streams
			is.close();
		}
		return byteData;
	}

	private static byte[] loadKeyFile(String privateKeyFilePath) throws FileNotFoundException, IOException {
		DataInputStream dis = null;
		byte[] keyBytes = null;

		try {
			File file = new File(privateKeyFilePath);
			FileInputStream fis = new FileInputStream(file);
			dis = new DataInputStream(fis);
			keyBytes = new byte[(int) file.length()];
			dis.readFully(keyBytes);
		} finally {
			Closeables.close(dis, true);
		}
		return keyBytes;
	}

}
