package com.ubs.idp.zookeeper.utils.rsa;

import java.security.PrivateKey;
import java.security.PublicKey;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.log4j.Logger;
import org.bouncycastle.util.encoders.Base64;

public class RSACommandLineTool {

	static final Logger logger=Logger.getLogger(RSACommandLineTool.class);

	private static final String OPTION_HELP="--help";
	private static final String OPTION_DECRYPT="decrypt";
	private static final String OPTION_ENCRYPT="encrypt";
	private static final String OPTION_KEY_PATH="key-path";
	private static final String OPTION_INPUT_VALUE="input-value";

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		try {
			CommandLine cmd = parseArguments(args);

			String keyPath=cmd.getOptionValue(OPTION_KEY_PATH);
			String inputValue=cmd.getOptionValue(OPTION_INPUT_VALUE);

			RSASecurityProvider securityProvider = new RSASecurityProvider();

			byte[] inputValueBytes;
			String output;

			if(inputValue!=null)
				inputValueBytes=inputValue.getBytes(RSASecurityProvider.DEFAULT_CHARSET);
			else
				throw new Exception("--" + OPTION_INPUT_VALUE + " is required.");

			securityProvider.init();

			if(cmd.hasOption(OPTION_ENCRYPT)) {
				PrivateKey privateKey = RSAKeyFileLoader.loadPrivateKey(keyPath);
				byte[] outputBytes = securityProvider.encrypt(inputValueBytes,privateKey);
				output = new String(Base64.encode(outputBytes), RSASecurityProvider.DEFAULT_CHARSET);

			} else if(cmd.hasOption(OPTION_DECRYPT)) {

				byte[] decoded=Base64.decode(inputValueBytes);
				PublicKey publicKey=RSAKeyFileLoader.loadPublicKey(keyPath);
				byte[] outputBytes = securityProvider.decrypt(decoded,publicKey);
				output = new String(outputBytes, RSASecurityProvider.DEFAULT_CHARSET);
			} else {
				throw new IllegalStateException("must specify encrypt or decrypt action");
			}
			
			System.out.println("Result: " + output);
			
			// TODO: Build out...

		} catch (ParseException e) {
			String[] helpMe = {OPTION_HELP}; 
			System.err.println("Error processing command: " + e.getMessage());
			try {
				parseArguments(helpMe);
			} catch (ParseException e1) {
				// Do nothing
			}
		}
	}

	/**
	 * Parse command line args
	 * @param args
	 * @return
	 * @throws ParseException
	 */
	private static CommandLine parseArguments(String[] args) throws ParseException {

		Options options=new Options();

		Option encrypt=new Option(null,OPTION_ENCRYPT,false,"Encrypt (please redirect to file; output is large)");
		Option decrypt=new Option(null,OPTION_DECRYPT,false,"Decrypt");
		Option keyFile=new Option(null,OPTION_KEY_PATH,true,"Path to key file");
		Option inputValue=new Option(null,OPTION_INPUT_VALUE,true,"Input value to process");

		keyFile.setRequired(true);

		options.addOption(encrypt);
		options.addOption(decrypt);
		options.addOption(keyFile);
		options.addOption(inputValue);

		printHelp(args,options);

		CommandLineParser clp=new PosixParser();
		CommandLine cmd=clp.parse(options,args);

		return cmd;
	}

	private static void printHelp(String[] args,Options options) {
		for(int i=0;i<args.length;i++) {
			if(OPTION_HELP.equals(args[i])) {
				HelpFormatter formatter=new HelpFormatter();
				formatter.printHelp(RSACommandLineTool.class.getSimpleName(), options);
				System.exit(0);
			}
		}
	}
}
