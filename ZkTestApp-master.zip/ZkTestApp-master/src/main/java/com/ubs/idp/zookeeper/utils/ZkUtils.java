package com.ubs.idp.zookeeper.utils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.MissingOptionException;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooKeeper.States;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;

import com.google.common.io.Files;

/**
 * Utils for Zookeeper hosted properties file(s)
 * @author paulmc
 */
public class ZkUtils implements Watcher {
	
	private static final String OPTION_HELP="--help";
	private static final String OPTION_ZKCONNECT="zkConnect";
	private static final String OPTION_ZKPATH="zkPath";
	private static final String OPTION_CFGFILE="cfgFile";
	private static final String OPTION_PUT_CFG="put";
	private static final String OPTION_GET_CFG="get";
	private static final String OPTION_USER="user";
	private static final String OPTION_PASSWORD="password";
	
	public static final String ZK_CONNECT	= "zk.zkConnect";
	public static final String ZK_PATH		= "zk.zkPath";
	public static final String ZK_USER		= "zk.zkUser";
	public static final String ZK_PASSWORD	= "zk.zkPassword";
	
	private int timeout = 10000;
	private String zkConnect = "localhost:2181";
	private String zkPath = "/";
	
	private String user = null;
	private String password = null;

	/**
	 * @return the zkConnect
	 */
	public String getZkConnect() {
		return zkConnect;
	}

	/**
	 * @param zkConnect the zkConnect to set
	 */
	public void setZkConnect(String zkConnect) {
		this.zkConnect = zkConnect;
	}

	/**
	 * @return the timeout
	 */
	public int getTimeout() {
		return timeout;
	}

	/**
	 * @param timeout the timeout to set
	 */
	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	/**
	 * @return the zkPath
	 */
	public String getZkPath() {
		return zkPath;
	}

	/**
	 * @param zkPath the zkPath to set
	 */
	public void setZkPath(String zkPath) {
		this.zkPath = zkPath;
	}

	/**
	 * Set digest auth user
	 * @param user
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * Set digest auth password
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ZkUtils zkUtils = new ZkUtils();
		
		try {
			String[] helpMe = {OPTION_HELP};
			CommandLine cmd = null;
			
			try {
				cmd = parseArguments(args);
			} catch(MissingOptionException moe) {
				System.out.println("Missing argument?");
				parseArguments(helpMe);
			}

			String zkPath = cmd.getOptionValue(OPTION_ZKPATH);
			
			zkUtils.setZkPath(zkPath);
			
			if (cmd.hasOption(OPTION_USER)) {
				String user = cmd.getOptionValue(OPTION_USER);
				
				if (cmd.hasOption(OPTION_PASSWORD)) {
					String password = cmd.getOptionValue(OPTION_PASSWORD);
					
					zkUtils.setUser(user);
					zkUtils.setPassword(password);
				}
			}

			if(cmd.hasOption(OPTION_PUT_CFG)) {
				if (!cmd.hasOption(OPTION_CFGFILE)) {
					System.out.println("No " + OPTION_CFGFILE + " specified?");
					parseArguments(helpMe);
				}
				String cfgFilePath	= cmd.getOptionValue(OPTION_CFGFILE);
				zkUtils.pushCfg(cfgFilePath);
			} else if(cmd.hasOption(OPTION_GET_CFG)) {
				Properties properties = zkUtils.pullCfg();
				
				System.out.println("Got properties: ");
				
				for (Object key : properties.keySet()) {
					String value = properties.getProperty(key.toString());
					System.out.println(key + "=" + value);
				}
			} else {
				System.out.println("Missing argument (need " + OPTION_PUT_CFG + " or " + OPTION_GET_CFG + " option)?");
				
				parseArguments(helpMe);
			}
						
			// Check we can pull it back again
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Push a file to a Zookeeper node
	 * @param filePath
	 * @throws Exception
	 */
	public void pushCfg(String filePath) throws Exception {
		byte data[];
		
		if (filePath.startsWith("classpath:")) {
			InputStream in = this.getClass().getClassLoader().getResourceAsStream(filePath.substring(filePath.indexOf(":") + 1));
			
			if (in == null) {
				throw new Exception("Failed to load from classpath?");
			}
			
			byte[] buff = new byte[1024];
			StringBuffer cfg = new StringBuffer();
			int nbytes;
			
			while((nbytes = in.read(buff)) > 0) {
				cfg.append(new String(buff, 0, nbytes));
			}
			
			in.close();
			
			data = cfg.toString().getBytes();
		} else {
			File props = new File(filePath);
			
			if (!props.exists()) {
				throw new Exception("No such file? ('" + filePath + "')");
			}

			data = Files.toByteArray(props);
		}
		
		ZooKeeper zk = connect();
		
		zk.create(zkPath, data, Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
		
		zk.close();
	}

	/**
	 * Pull config from Zookeeper
	 * @return
	 * @throws Exception
	 */
	public Properties pullCfg() throws Exception {

		ZooKeeper zk = connect();
		
		Stat stat = new Stat();
		
		byte[] data = zk.getData(zkPath, false, stat);
		
		Properties properties = new Properties();
        properties.load(new ByteArrayInputStream(data));
        
        zk.close();
        
        return properties;
	}
	
	/**
	 * Blocking connect
	 * @return
	 * @throws Exception
	 */
	private ZooKeeper connect() throws Exception {
		ZooKeeper zk = new ZooKeeper(zkConnect, timeout, this);
		
		// Wait for connection
		while (!zk.getState().equals(States.CONNECTED)) {
			Thread.sleep(10);
		}
		
		if (user != null && password != null) {
			zk.addAuthInfo("digest", (user+":"+password).getBytes());
		}
		
		return zk;
	}
	
	/**
	 * Delete config from specified Zookeeper location
	 * @throws Exception
	 */
	public void deleteCfg() throws Exception {
		ZooKeeper zk = new ZooKeeper(zkConnect, timeout, this);
		
		zk.delete(zkPath, -1);
        
        zk.close();
	}

	/* (non-Javadoc)
	 * @see org.apache.zookeeper.Watcher#process(org.apache.zookeeper.WatchedEvent)
	 */
	public void process(WatchedEvent ev) {
		if (ev.getState().compareTo(KeeperState.SyncConnected) == 0) {
			// TODO: We are now connected
		}
	}
	
	/**
	 * Parse commang line args via Apache CLI API
	 * @param args
	 * @return
	 * @throws ParseException
	 */
	private static CommandLine parseArguments(String[] args) throws ParseException {

		Options options=new Options();

		// Mandatory bits
		
		Option zkConnect = new Option(null, OPTION_ZKCONNECT, true, "Zookeeper connection string");
		Option zkPath = new Option(null, OPTION_ZKPATH, true, "Zookeeper node address");

		zkConnect.setRequired(true);
		zkPath.setRequired(true);
		
		options.addOption(zkConnect);
		options.addOption(zkPath);
		
		// Optional
		
		Option put = new Option(null, OPTION_PUT_CFG,  false, "Put properties file");
		Option get = new Option(null, OPTION_GET_CFG,  false, "Get properties file");
		Option cfgFile = new Option(null, OPTION_CFGFILE, true, "Configuration properties file");

		// User+pass for basic auth
		
		Option user = new Option(null, OPTION_USER, true, "User name for ACL access");
		Option password = new Option(null, OPTION_PASSWORD, true, "User password for ACL access");
		
		options.addOption(put);
		options.addOption(get);
		options.addOption(cfgFile);
		options.addOption(user);
		options.addOption(password);

		printHelp(args,options);

		CommandLineParser clp=new PosixParser();
		CommandLine cmd=clp.parse(options,args);

		return cmd;
	}

	private static void printHelp(String[] args, Options options) {
		for(int i=0;i<args.length;i++) {
			if(OPTION_HELP.equals(args[i])) {
				HelpFormatter formatter=new HelpFormatter();
				formatter.printHelp(ZkUtils.class.getSimpleName(), options);
				System.exit(0);
			}
		}
	}
}
