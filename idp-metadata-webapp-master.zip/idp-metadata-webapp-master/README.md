## IDP Metadata Web Application

This component is the Metadata webapp that interacts with the [IDP Metadata Webservice](https://github.ldn.swissbank.com/idp/idp-metadata-webservice). 

To build this app you need to have first installed NodeJs and Bower on your machine. Instructions on doing this can be found [here](http://websdk.swissbank.com/guides/setup.html). 

You will also need an instance of the [idp-metadata-store](https://github.ldn.swissbank.com/idp/idp-metadata-store) built and running so this web app has something to interact with.

Once done, check out this code base and run the following to build and start the server:

	npm install && bower install && build.bat && npm start

If this is successful you can view the webapp by navigating to http://localhost:3000

* Note currently this webapp is hardcoded to point to http://localhost:8080 for the [IDP Metadata Webservice](https://github.ldn.swissbank.com/idp/idp-metadata-webservice)!