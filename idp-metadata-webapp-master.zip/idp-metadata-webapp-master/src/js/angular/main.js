require.config({

	// alias libraries paths
    paths: {
		'd3' : '../../packages/d3/d3.min' ,
		'grid' : '../../packages/grid/grid' , 		
		'jquery' : '../../packages/jquery/jquery' , 
		'angular' : '../../packages/angular/angular' ,
		'angular-route' : '../../packages/angular/angular-route' ,
		'angular-resource' : '../../packages/angular/angular-resource' ,
		'lightbox' : '../../packages/lightbox/js/lightbox' , 
	
	},

    // angular does not support AMD out of the box, put it in a shim
    shim: {
        'angular': {
            exports: 'angular'
        },
        'angular-route': {
			deps:	['angular'],
            exports: 'angular-route'
        },
        'angular-resource': {
			deps:	['angular'],
            exports: 'angular-resource'
        }
    },

    // kick start application
    deps: ['./bootstrap']
});