var module = angular.module("metamodel",['ngResource','ngRoute']);

// Enable X-domain support when using $resource
module.config(['$routeProvider','$httpProvider', function($routeProvider, $httpProvider) {
    $httpProvider.defaults.useXDomain = true;
    delete $httpProvider.defaults.headers.common['X-Requested-With'];

  }
]);