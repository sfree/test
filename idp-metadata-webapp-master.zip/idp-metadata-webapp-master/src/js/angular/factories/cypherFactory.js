define(['./module'], function( factories ) {
	'use strict';

	factories.factory("CypherFactory",['$resource','$http','HOST','PORT', function ($resource,$http,HOST,PORT) {

		return $http.get("http://" + HOST + ":" + PORT + "/cypher");
	}]);


});