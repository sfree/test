define([
	'./labelFactory',
	'./nodeFactory',
	'./relationshipFactory',
	'./cypherFactory'
], function() {});