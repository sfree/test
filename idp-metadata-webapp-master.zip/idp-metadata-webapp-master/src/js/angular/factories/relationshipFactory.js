define(['./module'], function( factories ) {
	'use strict';

	factories.factory("RelationshipFactory",['$resource','$http','HOST','PORT', function ($resource,$http,HOST,PORT) {

		var factory = $resource("http://" + HOST + ":" + PORT + "/relationships",
								{},
								{
									"get":{method:"GET",isArray:true},
								}
		);

		return factory;
	}]);

	factories.factory("RelationshipTypeFactory",['$resource','$http','HOST','PORT', function ($resource,$http,HOST,PORT) {

		var factory = $resource("http://" + HOST + ":" + PORT + "/relationships/types",
								{nodeId: "@nodeId" },
								{
									"get":{method:"GET",isArray:true},
								}
		);

		return factory;
	}]);

	factories.factory("NodeRelationshipFactory",['$resource','$http','HOST','PORT', function ($resource,$http,HOST,PORT) {

		var factory = $resource("http://" + HOST + ":" + PORT + "/nodes/:nodeId/relationships",
								{nodeId: "@nodeId" },
								{
									"get":{method:"GET",isArray:true},

									"getIncoming":	{method:"GET",
													 params:{direction:"INCOMING"},
													 isArray:true},

									"getOutgoing":	{method:"GET",
													params:{direction:"OUTGOING"},
													isArray:true}
								}
		);

		return factory;
	}]);

});