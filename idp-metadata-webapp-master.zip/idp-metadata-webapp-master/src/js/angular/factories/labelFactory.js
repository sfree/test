define(['./module'], function( factories ) {
	'use strict';

	factories.factory("LabelFactory", ['$resource','$http','HOST','PORT', function($resource,$http,HOST,PORT) {

		var factory = $resource("http://" + HOST + ":" + PORT + "/labels/:name",
			{Id: "@name" },
			{
			  "update": {method: "PUT"},

			  "getPage": {method: "GET",
						 params:{offset:"offset",
								 limit: "limit"},
						 isArray: true,
						},


			  "getPageCount":	{method: "GET",
								params:{pageSize:"pageSize"},
								isArray: true,
						},


		});

		return factory;
	}]);	
});

