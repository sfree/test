define(['./module'], function( factories ) {
	'use strict';
	factories.factory("NodeFactory",['$resource','$http','HOST','PORT', function ($resource,$http,HOST,PORT) {

		var factory = $resource("http://" + HOST + ":" + PORT + "/nodes/:Id",
			{Id: "@Id" },
			{"update": {method: "PUT"},

			  "getNodesOfType": {method: "GET",
								 params:{labelName:"labelName"},
								 isArray: true,
						},


			  "getPage": {method: "GET",
						 params:{offset:"offset",
								 limit: "limit"},
						 isArray: true,
						},


			  "getPageCount":	{method: "GET",
								params:{pageSize:"pageSize"},
								isArray: true,
						},

			  "getLabelPage": {method: "GET",
							   params:{ labelName:"labelName",
										offset:"offset",
									   limit: "limit"},
										isArray: true,
						},


			  "getLabelPageCount":	{method: "GET",
								params:{labelName: "labelName",
										pageSize:"pageSize"},
								isArray: true,
						},

		
		});

		return factory;
	}]);
});