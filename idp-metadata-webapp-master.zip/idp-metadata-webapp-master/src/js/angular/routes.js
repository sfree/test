define(['./app'], function(app) {
	'use strict';

	return app.config(['$routeProvider','$httpProvider', function($routeProvider,$httpProvider) {
		$routeProvider.when('/metadata', {
              templateUrl: 'partials/metadata.html',
          });


		$httpProvider.defaults.useXDomain = true;
		delete $httpProvider.defaults.headers.common['X-Requested-With'];

	}]);
});