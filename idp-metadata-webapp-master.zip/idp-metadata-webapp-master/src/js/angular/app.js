define([
	'angular',
	//'angular-resource',
	'angular-route',
	'./config/index',
	'./controllers/index',
	'./directives/index',
	'./services/index',
	'./factories/index'
], function( angular ) {
	'use strict';

	return angular.module('app', [
		'ngRoute',
		'app.config',
		'app.services',
		'app.controllers',
		'app.factories',
		'app.directives',
	]);
});
