define(['./module'], function( controllers ) {
	'use strict';

	controllers.controller('NodeDrawerController',['$rootScope','$scope','NodeService','RelationshipService', function( $rootScope, $scope, NodeService, RelationshipService ) {

	var canvas = document.getElementById("myCanvas");
	var context1 = canvas.getContext('2d');
	var canvasWidth = context1.canvas.width;
	var canvasHeight = context1.canvas.height;

	// buffer canvas
	var canvas2 = document.createElement('canvas');
	canvas2.width = canvasWidth;
	canvas2.height = canvasHeight;
	var context2 = canvas2.getContext('2d');

	var full = 2 * Math.PI;
	var threeQuart = full * 0.75;
	var half = Math.PI;
	var quart = half / 2;
	var eighth = quart / 2;

	var radius = 30;
	var fontSize = 14;
	var fontStyle = "FS Me Web";
	var centerX = context1.canvas.width/2;
	var centerY = context1.canvas.height/2;	
	var leftCenterX = centerX / 2;
	var rightCenterX = centerX + (centerX / 2);

	var defaultNodeColor = '#8888FF';
	var selectedNodeColor = '#FF8888';
	var highlightedNodeColor = '#BBBBFF';

	$scope.nodes = [];
	$scope.clickedNode = null;
	$scope.releasedNode = null;
	$scope.highlightedNodeId = null;
	$scope.clickPoint = null;
	$scope.dragPoint = null;


	canvas.addEventListener('mousedown', function(event) {
		if( event.which == 1 )
		{
			$scope.clickPoint = {x: event.offsetX, y: event.offsetY }
			$scope.checkAndSetMouseDownNode(  event.offsetX, event.offsetY );
		}
		if( event.which == 3 )
		{
			$scope.doRightClick( event );
		}
	});

	canvas.addEventListener('mouseup', function(event) {
		if( event.which == 1 )
		{
			// Are we still inside the same node as the one the mouse went down on
			if( $scope.shouldSelectClickedNode( event.offsetX, event.offsetY) )
			{
				$rootScope.$broadcast( $scope.clickedNode.position + '.node.selected', $scope.clickedNode );		
			}

			// Check if we released in a different node
			if( $scope.shouldDisplayRelationshipDialog( event.offsetX, event.offsetY) )
			{
				$scope.displayRelationshipDialog();
			}
			else
			{
				$scope.clearSelected();
				$scope.redraw();
			}
		}
	});

	canvas.addEventListener('mousemove', function(event) {
		if(  $scope.clickedNode && $scope.clickPoint )
		{
			$scope.dragPoint = {x:event.offsetX, y:event.offsetY };
			$scope.redraw();
		}

		$scope.checkAndSetHighlightedNode(event.offsetX, event.offsetY);
	});

	/**
	* Checks if the specified coords are inside a node and if so 
	* sets the node as highlighted and triggers a redraw
	*/
	$scope.checkAndSetHighlightedNode = function( mouseX, mouseY ) {

	  var currentlySet = ($scope.highlightedNodeId != null);
	  var notFound = true;
	  
	  // Check if the mouse click is within any node
	  angular.forEach( $scope.nodes, function( node, index ) {
		 
		  if( $scope.pointInCircle( {x: mouseX, y: mouseY }, node ) )
		  {
			  if( node.node.nodeId != $scope.selectedNodeId )
			  {
				  $scope.highlightedNodeId = node.node.nodeId;
				  $scope.redraw();
				  notFound = false;
				  return;
			  }
		  }
		  
	  });

	  // If we were previously set, but nothing was found
	  if( currentlySet && notFound )
	  {
		  $scope.highlightedNodeId = null;
		  $scope.redraw();
	  }

	}

	/**
	* Checks if the specified coords are inside a node and if so 
	* sets the node as selected and triggers a redraw
	*/
	$scope.checkAndSetMouseDownNode = function( mouseX, mouseY ) {

	   // Check if the mouse click is within any node
	  angular.forEach( $scope.nodes, function( node, index ) {
		 
		  if( $scope.pointInCircle( {x: mouseX, y: mouseY }, node ) )
		  {
			  if( $scope.highlightedNodeId == node.node.nodeId )
			  {
				  $scope.highlightedNodeId = null;
			  }
			  $scope.clickedNode = node.node;
			  RelationshipService.startNode = node.node;

			  $scope.redraw();
			  return;
			  //$rootScope.$broadcast( node.position + '.node.selected', node.node );		  		  
		  }

	  });
	}

	/**
	* Checks if the specified coords are inside the node that
	* we clicked the mouse down on and if so returns true
	*/
	$scope.shouldSelectClickedNode = function( mouseX, mouseY ) {

		var result = false;
	   // Check if the mouse coords is within any node
	  angular.forEach( $scope.nodes, function( node, index ) {
		 
		  if( $scope.pointInCircle( {x: mouseX, y: mouseY }, node ) )
		  {
			  if( $scope.clickedNode && 
				  $scope.clickedNode.nodeId  == node.node.nodeId )
			  {
				  $scope.clickedNode.position = node.position;
				  result = true;
				  return;
			  }
		  }
	  });

	  return result;
	}

	/**
	* Checks if the specified coords are inside a different node to the
	* one that was first clicked on and if so returns sets the node that
	* it found and returns true
	*/
	$scope.shouldDisplayRelationshipDialog = function( mouseX, mouseY ) {

		var result = false;

	   // Check if the mouse coords is within any node
	  angular.forEach( $scope.nodes, function( node, index ) {
		 
		  if( $scope.pointInCircle( {x: mouseX, y: mouseY }, node ) )
		  {
			  if( $scope.clickedNode && 
				  $scope.clickedNode.nodeId  != node.node.nodeId )
			  {
				  $scope.releasedNode = node.node;				 
				  RelationshipService.endNode = node.node;
				  result = true;
				  return;
			  }
		  }
	  });

	  return result;
	}

	$scope.displayRelationshipDialog = function() {
		$('#relationshipModal').toggleClass('is-open').trigger('dialogOpened');
	}

	/**
	* Callback for when the create relationship dialog is closed
	*/
	$('#relationshipModal').on('dialogClosed',function(){
		// Trigger a reload of both left and right nodes
		var left = $scope.leftSelectedNode;
		var right = $scope.rightSelectedNode;

		if( left )$rootScope.$broadcast('left.node.selected', left );
		if( right )$rootScope.$broadcast('right.node.selected', right );

	});


	 $scope.doRightClick = function(event) {
		 console.log("Right click");
	 }


	 $scope.clearSelected = function() {
		$scope.clickedNode = null;
		RelationshipService.newRelationshipStartNode = null;

		$scope.releasedNode = null;
		$scope.highlightedNodeId = null;
		$scope.clickPoint = null;
		$scope.dragPoint = null;
		

	 }

	 /*
	 * Set the currently selected node left
	 */
	 $scope.$on('left.node.selected', function(event,node) {
		$scope.leftSelectedNode = node;
		$scope.leftIncomingNodes = [];	// Clear the child nodes so that we know we need to fetch them
		$scope.leftOutgoingNodes = [];	// Clear the child nodes so that we know we need to fetch them
		$scope.clearSelected();

		// Load the relationships for the selected node
		$scope.leftIncomingRelationships = RelationshipService.getIncomingRelationshipsForNode( node.nodeId );			
		$scope.leftOutgoingRelationships = RelationshipService.getOutgoingRelationshipsForNode( node.nodeId );			
		
		// Wait for the relationships to load
		$scope.leftIncomingRelationships.$promise.then(function(relationships) {			
			var nodesLoaded = 0;
			var nodeCount = relationships.length;
			
			if( nodeCount > 0 )
			{
				// Next load each of the end point nodes
				angular.forEach( relationships, function( relationship, index ) {

					var node = NodeService.getNode( relationship.startNodeId );

					// Wait for the node to load
					node.$promise.then( function(data) {
						$scope.leftIncomingNodes.push( data );
						nodesLoaded ++;

						// If this is the last one then we redraw
						if( nodesLoaded == nodeCount )
						{
							$scope.redraw();
						}
					});
				});			
			}
			else
			{
				// No relationships to load to redraw now
				$scope.redraw();
			}
		});
		
		// Wait for the relationships to load
		$scope.leftOutgoingRelationships.$promise.then(function(relationships) {			
			var nodesLoaded = 0;
			var nodeCount = relationships.length;
			
			if( nodeCount > 0 )
			{
				// Next load each of the end point nodes
				angular.forEach( relationships, function( relationship, index ) {

					var node = NodeService.getNode( relationship.endNodeId );

					// Wait for the node to load
					node.$promise.then( function(data) {
						$scope.leftOutgoingNodes.push( data );
						nodesLoaded ++;

						// If this is the last one then we redraw
						if( nodesLoaded == nodeCount )
						{
							$scope.redraw();
						}
					});
				});			
			}
			else
			{
				// No relationships to load to redraw now
				$scope.redraw();
			}
		});


	 });



		






	 /*
	 * Set the currently selected right node
	 */
	 $scope.$on('right.node.selected', function(event,node) {
		$scope.rightSelectedNode = node;
		$scope.rightIncomingNodes = [];	// Clear the child nodes so that we know we need to fetch them
		$scope.rightOutgoingNodes = [];	// Clear the child nodes so that we know we need to fetch them
		$scope.clearSelected();

		// Load the relationships for the selected node
		$scope.rightIncomingRelationships = RelationshipService.getIncomingRelationshipsForNode( node.nodeId );			
		$scope.rightOutgoingRelationships = RelationshipService.getOutgoingRelationshipsForNode( node.nodeId );			
		
		// Wait for the relationships to load
		$scope.rightIncomingRelationships.$promise.then(function(relationships) {			
			var nodesLoaded = 0;
			var nodeCount = relationships.length;
			
			if( nodeCount > 0 )
			{
				// Next load each of the end point nodes
				angular.forEach( relationships, function( relationship, index ) {

					var node = NodeService.getNode( relationship.startNodeId );

					// Wait for the node to load
					node.$promise.then( function(data) {
						$scope.rightIncomingNodes.push( data );
						nodesLoaded ++;

						// If this is the last one then we redraw
						if( nodesLoaded == nodeCount )
						{
							$scope.redraw();
						}
					});
				});			
			}
			else
			{
				// No relationships to load to redraw now
				$scope.redraw();
			}
		});
		
		// Wait for the relationships to load
		$scope.rightOutgoingRelationships.$promise.then(function(relationships) {			
			var nodesLoaded = 0;
			var nodeCount = relationships.length;
			
			if( nodeCount > 0 )
			{
				// Next load each of the end point nodes
				angular.forEach( relationships, function( relationship, index ) {

					var node = NodeService.getNode( relationship.endNodeId );

					// Wait for the node to load
					node.$promise.then( function(data) {
						$scope.rightOutgoingNodes.push( data );
						nodesLoaded ++;

						// If this is the last one then we redraw
						if( nodesLoaded == nodeCount )
						{
							$scope.redraw();
						}
					});
				});			
			}
			else
			{
				// No relationships to load to redraw now
				$scope.redraw();
			}
		});

	 });

	 /**
	 * Redraws the whole canvas using double buffering.
	 */
	 $scope.redraw = function() {

		// create something on the canvas		
		$scope.clearCanvas( context2 );
		$scope.drawAllObject( context2 );

		//render the buffered canvas onto the original canvas element
		$scope.clearCanvas( context1 );
		context1.drawImage(canvas2, 0, 0);
	 }

	 /**
	 * Draws all objects on our page using the specified context
	 */
	 $scope.drawAllObject = function( context ) {
				
		$scope.drawConnectorLine( context );
		$scope.drawSelectedNodes( context );
	 }

	 /**
	 * Clears the canvas and clears the array 
	 */
	 $scope.clearCanvas = function( context ) {
		 context.clearRect( 0,0, canvasWidth, canvasHeight );		
	 }

	/**
	* Draws a line from the point where the mouse was pressed down (clickPoint)
	* to the point where the mouse currently is (dragPoint)
	*/
	$scope.drawConnectorLine = function( context ) {

		if( $scope.clickPoint && $scope.dragPoint )
		{
			// Draw a line from center node to the target node
			context.moveTo($scope.clickPoint.x,$scope.clickPoint.y);
			context.lineTo($scope.dragPoint.x,$scope.dragPoint.y);
			context.stroke();
			/*
			if( $scope.dragPoint.y < $scope.clickPoint.y )
			{
				$scope.drawArrowedLine( context, $scope.dragPoint.x,$scope.dragPoint.y,$scope.clickPoint.x,$scope.clickPoint.y );
			}
			else
			{
				$scope.drawArrowedLine( context, $scope.clickPoint.x,$scope.clickPoint.y, $scope.dragPoint.x,$scope.dragPoint.y );
			}*/
		}
	}

	 /**
	 * Draws all the node circles
	 */
	 $scope.drawSelectedNodes = function( context ) {
		$scope.nodes = [];

		// redraw the left selected node
		if(  $scope.leftSelectedNode )
		{
			if( $scope.leftIncomingRelationships && $scope.leftIncomingNodes  )
			{
				$scope.drawRelationships( context,$scope.leftIncomingRelationships,$scope.leftIncomingNodes, 'left',true);
			}
			if( $scope.leftOutgoingRelationships && $scope.leftOutgoingNodes  )
			{
				$scope.drawRelationships( context,$scope.leftOutgoingRelationships,$scope.leftOutgoingNodes, 'left',false);
			}

			$scope.drawNode( context, $scope.leftSelectedNode, leftCenterX, centerY, 'left' );			


		}

		// redraw the right selected node
		if(  $scope.rightSelectedNode  )
		{
			if( $scope.rightIncomingRelationships )
			{
				$scope.drawRelationships(context,$scope.rightIncomingRelationships,$scope.rightIncomingNodes, 'right',true);
			}
			if( $scope.rightOutgoingRelationships && $scope.rightOutgoingNodes  )
			{
				$scope.drawRelationships( context,$scope.rightOutgoingRelationships,$scope.rightOutgoingNodes, 'right',false);
			}

			$scope.drawNode(context, $scope.rightSelectedNode, rightCenterX, centerY - (radius/2), 'right' );
		}
	 }

	 /**
	 * Draws a node by creating a filled circle containing text with node name, nodeIf and label
	 */
	 $scope.drawNode = function( context, node, x, y, position ) {
			// Draw the circle
			context.beginPath();
			context.arc(x,y,radius,0,2*Math.PI);
			context.fillStyle = defaultNodeColor;			
			if( $scope.clickedNode && node.nodeId == $scope.clickedNode.nodeId )context.fillStyle = selectedNodeColor;
			if( node.nodeId == $scope.highlightedNodeId )context.fillStyle = highlightedNodeColor;
			context.fill();
			context.strokeStyle = '#000033';
			context.stroke();

			// Draw the node name
			var text = node.labels[0] + ": " + node.name + "(" + node.nodeId + ")";
			var textWidth = context.measureText(text).width;
			$scope.drawTextBox( context, text, x , y );


			var shape = {node: node,
						 center: {x:x,y:y},
						 radius: radius,
						 position: position};

			$scope.nodes.push( shape );

	 }

	 $scope.drawRelationships = function( context, relationships, nodes, position, isIncoming ) {
		 
		 var nodeCount = relationships.length;
		 var step = (context.canvas.width/2) / nodeCount;
		 var startX = 0;
		 var targetY = (isIncoming? centerY - context.canvas.height/4:centerY + context.canvas.height/4)
		 if( position == 'right') startX = centerX;

		 // Draw a line for each relationship
		 angular.forEach( relationships, function( relationship, index ) {

			var sourceX = startX + centerX/2;
			var sourceY = centerY;
			var targetX = startX + ((index+1) * step) - step/2;
			var middleX = targetX + ((sourceX - targetX)/2);
			var middleY = sourceY - ((sourceY - targetY)/2);		

			
			// Draw a line from center node to the target node			
			$scope.drawArrowedLine( context, sourceX, sourceY, targetX, targetY );


			// Draw the relationship type
			$scope.drawTextBox( context, relationship.type,middleX, middleY );
		 });

		 // Draw a line for each end point node
		 angular.forEach( nodes, function( node, index ) {

			var targetX = startX + ((index+1) * step) - step/2;			

			 $scope.drawNode( context, node ,targetX, targetY, position );
		 });
	 }

	 /**
	 * Draws a line with an arrow in the middle pointing int he direction of the line
	 * from source to target
	 */
	 $scope.drawArrowedLine = function( context, sourceX, sourceY, targetX, targetY ) {

			var arrowSize = 10;

			// Draw the main line
			context.moveTo(sourceX,sourceY);
			context.lineTo(targetX,targetY);
			context.stroke();

			// Draw an arrow to indicate the direction
			var deltaX = sourceX - targetX;
			var deltaY = sourceY - targetY;

			var angle = Math.atan( deltaY / deltaX );

			if( angle <= 0 )angle -= eighth;
			else angle += quart + eighth;

			var middleX = targetX + ((sourceX - targetX)*0.75);
			var middleY = targetY + ((sourceY - targetY)*0.75);		
			var leftX = middleX + ( Math.cos(angle) * arrowSize);
			var leftY = middleY + ( Math.sin(angle) * arrowSize);
			var rightX = middleX + ( Math.cos(angle + quart) * arrowSize);
			var rightY = middleY + ( Math.sin(angle + quart) * arrowSize);

			context.moveTo(middleX,middleY);
			context.lineTo(leftX,leftY);
			context.stroke();

			context.moveTo(middleX,middleY);
			context.lineTo(rightX,rightY);
			context.stroke();
	 }




	 $scope.drawTextBox = function(context, text, x , y) {

		var padding = 2;

		// draw the box 
		var textWidth = context.measureText(text).width;
		context.fillStyle = "#FFFFFF";
		context.fillRect(x- (textWidth/2) - padding,y - padding,textWidth + (padding*2),  fontSize + (padding*2));
		context.strokeStyle = "#000000";
		context.strokeRect(x- (textWidth/2) - padding,y - padding,textWidth + (padding*2), fontSize + (padding*2));


		// Draw the node name
		context.font = fontSize + "px " + fontStyle;
		context.fillStyle = 'black';
		context.fillText(text, x - (textWidth/2) ,y + fontSize );
	 }


	 // Check if the distance between the point and the shape's
	// center is greater than the circle's radius. (Pythagorean theroem)
	$scope.pointInCircle = function(point, shape) {
		var distX = Math.abs(point.x - shape.center.x),
			distY = Math.abs(point.y - shape.center.y),
			dist = Math.sqrt(distX * distX + distY * distY);
		return dist < shape.radius;
	}





	}]);

});

