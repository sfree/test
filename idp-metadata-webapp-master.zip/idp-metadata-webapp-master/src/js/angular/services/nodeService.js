define(['./module'], function( services ) {

	'use strict';
	services.service('NodeService',['$rootScope','$resource','NodeFactory', function( $rootScope, $resource, NodeFactory ) {
			var service = {
				
				nodes: [],
				pageCount: 0,
				
				// Fetches all the nodes and saves them in the nodes member variable
				loadNodes: function() {
					this.nodes = NodeFactory.query();
				},


				// Fetches all the nodes of the specified label type and saves them in the nodes member variable
				loadNodesOfType: function(labelName) {
					this.nodes = NodeFactory.getNodesOfType({labelName:labelName});
				},

				// Fetches a page
				loadPage: function(offset, limit) {
					this.nodes = NodeFactory.getPage({offset:offset-1,limit:limit});
				},

				// Fetches the total number of pages
				loadPageCount: function(pageSize) {
					this.pageCount = NodeFactory.getPageCount({pageSize:pageSize});
				},

				// Returns all the nodes of the specified label type 
				getNodesOfType: function(labelName) {
					return NodeFactory.getNodesOfType({labelName:labelName});
				},


				// returns all the nodes 
				getNodes: function() {
					return NodeFactory.query();
				},

				// Returns a page
				getPage: function(offset, limit) {
					return NodeFactory.getPage({offset:offset-1,limit:limit});
				},

				// Returns the total number of pages
				getPageCount: function(pageSize) {
					return NodeFactory.getPageCount({pageSize:pageSize});
				},


				// returns a single node
				getNode : function( nodeId ) {
					return NodeFactory.get({Id:nodeId});
				},


				// Creates a new label with the specified name
				createNode: function( labelName, props ) {
					
					var result = NodeFactory.save({labelName:labelName}, props);
					result.$promise.then( function() {
						$rootScope.$broadcast( 'nodes.update' );
					});
				},

				// Adds a property to a node
				addPropertyToNode: function( nodeId, propName, propValue ) {
					var props = {};
					props[ propName ] = propValue;
					NodeFactory.update({Id:nodeId}, props);
					$rootScope.$broadcast( 'nodes.update' );
				},

				
		

			}

			return service;
	}]);
});