define(['./module'], function( services ) {

	'use strict';

	services.service('LabelService',['$rootScope','$resource','LabelFactory', function( $rootScope, $resource, LabelFactory ) {
			var service = {
				
				labels: [],
				pageCount: 0,
				
				// Fetches all the labels and saves them in the labels member variable
				loadLabels: function() {
					this.labels = LabelFactory.query();
				},

				// Fetches a page
				getPage: function(offset, limit) {
					this.labels = LabelFactory.getPage({offset:offset-1,limit:limit});
				},

				// Fetches the total number of pages
				getPageCount: function(pageSize) {
					this.pageCount = LabelFactory.getPageCount({pageSize:pageSize});
				},


				// Creates a new label with the specified name
				createLabel: function( labelName ) {
					var newLabel = {name:labelName};				
					this.labels.push(newLabel);
					var result = LabelFactory.save({}, newLabel);
					result.$promise.then( function() {
						$rootScope.$broadcast( 'labels.update' );
					});
				},
				
			}

			return service;
	}]);
});