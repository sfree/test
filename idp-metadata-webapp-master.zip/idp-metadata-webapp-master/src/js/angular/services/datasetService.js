module.service('DatasetService',['$rootScope','$resource','DatasetFactory', function( $rootScope, $resource, DatasetFactory ) {
		var service = {
			
			datasets: [{name:"TEST"}],
			
			// Fetches all the datases and saves them in the datasets member variable
			loadDatasets: function() {
				this.datasets = DatasetFactory.query();
			}
		}

		return service;
}]);