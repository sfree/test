define(['./module'], function( services ) {

	'use strict';
	services.service('CypherService',['$rootScope','$resource','$http','HOST','PORT', function( $rootScope, $resource, $http, HOST, PORT ) {
			var service = {

				cypher : "",
				
				// Fetches all the nodes and saves them in the nodes member variable
				getDatabaseDump: function() {
					var _self = this;
					$http.get("http://" + HOST + ":" + PORT + "/cypher").success( function(data) {
						_self.cypher = data;
					});
				}
			}

			return service;
	}]);
});