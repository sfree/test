define(['./module'], function( services ) {

	'use strict';
	services.service('RelationshipService',['$rootScope','$resource','NodeRelationshipFactory','RelationshipFactory','RelationshipTypeFactory', function( $rootScope, $resource, NodeRelationshipFactory, RelationshipFactory, RelationshipTypeFactory) {
			var service = {
				
				relationships: [],
				relationshipTypes: [],

				startNode: null,
				endNode: null,
				type: null,

				// Fetches all the relationships for the specified node ID and loads them into the array
				loadRelationshipsForNode: function(nodeId) {
					this.relationships = NodeRelationshipFactory.get({nodeId:nodeId});
				},

				// Returns all incoming relationships for the specified node id
				getIncomingRelationshipsForNode: function(nodeId) {
					return NodeRelationshipFactory.getIncoming({nodeId:nodeId});
				},

				// Returns all outgoing relationships for the specified node id
				getOutgoingRelationshipsForNode: function(nodeId) {
					return NodeRelationshipFactory.getOutgoing({nodeId:nodeId});
				},

				// Fetches all the availble relationship types
				loadRelationshipTypes: function() {
					this.relationshipTypes = RelationshipTypeFactory.query();
				},
				
				// Creates a new relationship based on the values set
				createRelationship: function(startNodeId, relationshipType, endNodeId) {
					var result = RelationshipFactory.save({startNodeId:startNodeId,
														   relationshipType:relationshipType,
														   endNodeId:endNodeId},{});

					result.$promise.then( function() {
						$rootScope.$broadcast( 'nodes.update' );
					});
				},

			}

			// Initialse all relationship types
			service.loadRelationshipTypes();

			return service;
	}]);

});