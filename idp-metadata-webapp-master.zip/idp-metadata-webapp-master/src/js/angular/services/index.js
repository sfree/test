define([
	'./labelService',
	'./nodeService',
	'./relationshipService',
	'./cypherService'
], function() {});