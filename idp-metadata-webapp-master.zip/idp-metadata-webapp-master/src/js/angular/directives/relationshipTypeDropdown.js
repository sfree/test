define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "relationshipTypeDropdown",  function( RelationshipService ) {
	   return {
		 restrict: "E",
		 template: '<div>' +
						'<select ng-model="selectedType" ng-options="relType.name for relType in relationshipTypes">' +
					'</div>',
		 scope: {},
		 controller: function($scope )
		 {
			 $scope.relationshipTypes = RelationshipService.relationshipTypes;
			 $scope.selectedType = $scope.relationshipTypes[0];		 

			 $scope.$on('relationshipTypes.update', function() {
				$scope.relationshipTypes = RelationshipService.relationshipTypes;
			 });

			 $scope.$watch('selectedType', function() {
				 if(  $scope.selectedType )
				 {
					RelationshipService.type = $scope.selectedType.name;
				 }
			 });

		 },

		 }

	});
});