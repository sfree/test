/*
* Button which when clicked displays a dialog with a databse dump
*/
define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "displayCypherButton", [ 'CypherService','HOST','PORT', function(CypherService, HOST, PORT) {
	   return {
		 restrict: "E",
		 scope: {},
		 template: 	'<div>' +
						'<button class="btn btn-large btn-primary" ng-click="dump()">DUMP!</button>' +
						'<text-box-modal id="cypherDialog" title="Cypher Databse Dump" text="{{cypher}}" width="500px"/>' +
					'</div>',
		 controller: function( $scope, $http )	 {
			$scope.cypher = "";

			$scope.dump = function() {

				$http.get("http://" + HOST + ":" + PORT + "/cypher").success( function(data) {
						$scope.cypher = data;
						$('#cypherDialog').toggleClass('is-open').trigger('dialogOpened');
				});
			}

		 },
	   }
	}]);
});