define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "nodePropertyTable", function( ) {
	   return {
		 restrict: "E",
		template:'<div>' +
					'<header><h2>{{nodeName}}</h2></header>' +
					'<table class="datagrid" style="width:auto">' +
						'<thead>' +
							'<tr>' +
								'<th>Name</th>'+
								'<th>Value</th>' +
							'</tr>'+
						'</thead>'+
						'<tbody>'+
							'<tr ng-repeat="prop in selectedNodeProps">' +									
								'<td>{{prop.name}}</td>'+
								'<td>{{prop.value}}</td>'+
							'</tr>'+
						'</tbody>'+
					 '</table>' +				
				 '</div>',
		 
		 controller: function($scope, NodeService )
		 {
			 $scope.nodeName = "Properties";
			 /*
			 * When the selected node (left or right)
			 */
			 $scope.$on('left.node.selected', function(event,node){$scope.onNodeSelected(event,node);});
			 $scope.$on('right.node.selected', function(event,node){$scope.onNodeSelected(event,node);} );
			 
			 /**
			 * Called when a node is selected
			 */
			 $scope.onNodeSelected = function(event,node) {
				 $scope.selectedNode = node;
				 $scope.nodeName = node.name + " (" + node.nodeId + ")";
				 $scope.selectedNodeProps = [];
				 for( var prop in node )
				 {
					 if( prop.indexOf("$") != 0 )
					 {
						$scope.selectedNodeProps.push( {name: prop, value: node[prop]} );
					 }
				 }
			 };

			 // Reset all the props from the node that was updated if its the
			 // same one as the one we are looking at
			 $scope.$on('node.updated', function(event, node) {
				 if( $scope.selectedNode && $scope.selectedNode.nodeId == node.nodeId )
				 {
					 $scope.selectedNodeProps = [];
					 for( var prop in node )
					 {
						 if( prop.indexOf("$") != 0 )
						 {
							$scope.selectedNodeProps.push( {name: prop, value: node[prop]} );
						 }
					 }
				 }
			 });


		 },

		 }

	});
});