define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "relationshipTable", [ 'RelationshipService', function( RelationshipService ) {
	   return {
		 restrict: "E",
		 template:  '<div>' +
						'<div>' +
							'<header><h2>Relationships</h2></header>' +
							'<table class="datagrid">' +
								'<thead>' +
									'<tr>' +
										'<th>Relationship Type</th>'+
										'<th>End Node Id</th>' +
									'</tr>'+
								'</thead>'+
								'<tbody>'+
									'<tr ng-repeat="relationship in relationships" ng-click="onRelationshipClick(relationship)">' +
										'<td>{{relationship.type}}</td>'+
										'<td>{{relationship.endNodeId}}</td>'+
									'</tr>'+
								'</tbody>'+
							 '</table>' +
						'</div>' +
					'</div>',

		 
		 controller: function($scope, RelationshipService )
		 {
			 $scope.relationships = RelationshipService.relationships;			 // The relationships displayed in the table

			 /*
			 * When the selected label changes we reload the list of relationships
			 */
			 $scope.$on('node.selected', function(event,node) {
				RelationshipService.loadRelationshipsForNode( node.nodeId );				
				$scope.relationships = RelationshipService.relationships;			
			 });

			 $scope.onRelationshipClick = function( relationship ) {
				 console.log("Relationship=" + relationship.relationshipId );
			 }
		 },

		 }

	}]);
});