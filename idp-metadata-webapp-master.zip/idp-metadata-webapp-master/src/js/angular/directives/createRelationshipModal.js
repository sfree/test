define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "createRelationshipModal", [ 'RelationshipService', function( RelationshipService ) {
	   return {
		 restrict: "E",
		 scope: {},
		 template: 	'<div id="relationshipModal" class="lightbox-modal" >' +
						'<div class="lightbox-content border" >' +
							'<h2>Create New Relationship?</h2>' +
							'<p>Do you want to create the following relationship between these two nodes:</p>' +
							'<p><relationship-type-dropdown/></p>' +
							'<p>{{source.startNode.label}} <b>{{source.startNode.name}}({{source.startNode.nodeId}})</b> --[{{source.type}}] --> {{source.endNode.label}} <b>{{source.endNode.name}}({{source.endNode.nodeId}})</b></p>' +
							'<p><button class="btn btn-primary" ng-click="createRelationship()">Create</button>' +
							'<button class="btn" ng-click="closeRelationshipDialog()">Cancel</button></p>' +
						'</div>' +
					'</div>',

		 
		 link: function( scope, elem, attr )
		 {
			scope.source = RelationshipService;

			elem.on('dialogOpened',function(){
				scope.source = RelationshipService;
				scope.$apply(function(){
				});
			});


			/**
			* Calls the relationship service to create the relationship between the source
			* and target nodes
			*/
			scope.createRelationship = function() {
				RelationshipService.createRelationship( RelationshipService.startNode.nodeId,
														RelationshipService.type,
														RelationshipService.endNode.nodeId );
				scope.closeRelationshipDialog();
			}

			scope.closeRelationshipDialog = function() {
		 		RelationshipService.startNode = null;
				RelationshipService.endNode = null;
				RelationshipService.type = null;
				 $('#relationshipModal').toggleClass('is-open').trigger('dialogClosed');
			}			 
		 },

		 }

	}]);
});