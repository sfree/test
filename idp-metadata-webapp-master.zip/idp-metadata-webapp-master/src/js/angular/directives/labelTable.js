define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "labelTable", [ 'LabelService', function( LabelService ) {
	   return {
		 restrict: "E",
		 template: 
					'<div>' +
						'<header><h2>Labels</h2></header>' +
						'<table class="datagrid">' +
							'<thead>' +
								'<tr>' +
									'<th>Name</th>'+
								'</tr>'+
							'</thead>'+
							'<tbody>'+
								'<tr ng-repeat="label in labels">' +
									'<td>{{label.name}}</td>'+
								'</tr>'+
							'</tbody>'+
						 '</table>' +
					'</div>',
		 controller: function($scope, LabelService )
		 {
			 LabelService.loadLabels();		
			 $scope.labels = LabelService.labels;		

			 $scope.$on('labels.update', function() {
				 $scope.labels = LabelService.labels;
			 });

		 },

		 }

	}]);
	});