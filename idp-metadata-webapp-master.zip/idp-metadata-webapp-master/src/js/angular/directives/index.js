define([
	'./labelDropdown',
	'./labelInserter',
	'./labelTable',
	'./labelTablePaginated',
	'./nodeInserter',
	'./nodePropertyTable',
	'./nodeTable',
	'./propertyInserter',
	'./relationshipTable',
	'./relationshipTypeDropdown',
	'./directionButton',
	'./createRelationshipModal',
	'./textBoxModal',
	'./displayCypherButton'
], function() {});