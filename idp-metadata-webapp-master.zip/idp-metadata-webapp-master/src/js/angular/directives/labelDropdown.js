define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "labelDropdown",  function(  ) {
	   return {
		 restrict: "E",
		 template: '<div>' +
						'<select ng-model="selectedLabel" ng-options="label.name for label in labels" style="width: auto">' +
					 '</div>',
		 scope: {},
		 controller: function($scope, LabelService )
		 {
			 $scope.labels = LabelService.labels;
			 $scope.selectedLabel = $scope.labels[0];		 

			 $scope.$on('labels.update', function() {
				 $scope.labels = LabelService.labels;
			 });

		 },

		 }

	});
});