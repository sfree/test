module.directive( "datasetTable", [ 'DatasetService', function( DatasetService ) {
   return {
     restrict: "E",
	 template: '<table class="datagrid">' +
					'<thead>' +
						'<tr>' +
							'<th>Name</th>'+
						'</tr>'+
					'</thead>'+
					'<tbody>'+
						'<tr ng-repeat="dataset in datasets">' +
							'<td>{{dataset.name}}</td>'+
						'</tr>'+
					'</tbody>'+
				 '</table>',
   	 controller: function($scope, DatasetService ){
		 DatasetService.loadDatasets();		
		 $scope.datasets = DatasetService.datasets;		
	 },

	 }

}]);