define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "nodeInserter", [ 'NodeService','LabelService', function( NodeService, LabelService ) {
	   return {
		 restrict: "E",
		 scope: {},
		 template: '<div class="layout-horizontal">' +
						'<div style="padding-right:5px">' +
							'<button class="btn btn-primary" ng-click="createNewNode()">Create New Node <i class="icon-plus"/></button>' +
						'</div>' +		 
						'<div>' +
							'<label>Name: </label>' +
						'</div>' +
						'<div>' +
							'<input ng-model="name" type="text"/>' +
						'</div>' +
						'<div>' +
							'<label>Label: </label>' + 
						'</div>' +
						'<div>' +
							'<select ng-model="selectedLabel" ng-options="label.name for label in labels">' +							
						'</div>' +
					'</div>',
		 
		 controller: function($rootScope, $scope, NodeService, LabelService )
		 {
			 $scope.name = "";
			 $scope.labels = LabelService.labels;
			 $scope.selectedLabel =  $scope.labels[0];


			 $scope.createNewNode = function()
			 {
				 var node = {id: $scope.name, name: $scope.name };
				 NodeService.createNode( $scope.selectedLabel.name,node);

				 $scope.name = "";
				 $scope.selectedLabel = undefined;
			 }
			 

			  $scope.$on('labels.update', function() {
				 $scope.labels = LabelService.labels;
			  });
		 },

		 }

	}]);
});