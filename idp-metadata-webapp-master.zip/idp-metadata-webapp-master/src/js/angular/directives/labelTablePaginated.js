define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "labelTablePaginated", [ 'LabelService', function( LabelService ) {
	   return {
		 restrict: "E",
		 template: '<table class="datagrid">' +
						'<thead>' +
							'<tr>' +
								'<th>Name</th>'+
							'</tr>'+
						'</thead>'+
						'<tbody>'+
							'<tr ng-repeat="label in labels">' +
								'<td>{{label.name}}</td>'+
							'</tr>'+
						'</tbody>'+
					 '</table>' +
					'<button ng-disabled="page==1" ng-click="prevPage()">prev</button>' +
					'<input type="number" ng-model="page" min="1" max="{{lastPage}}">' +
					'<button ng-disabled="page==lastPage" ng-click="nextPage()">next</button>',
		 
		 controller: function($scope, LabelService )
		 {
			$scope.lastPage = LabelService.getPageCount();
			$scope.pageSize = 10; // TODO: pass this in as a param in the directive
			$scope.page=1;
			
			$scope.nextPage = function()
			{
				if( $scope.page <= $scope.lastPage )
				$scope.page ++;
			}

			$scope.prevPage = function()
			{
				if( $scope.page >= 1 )
					$scope.page --;
			}


			$scope.$watch('page', function() {
				$scope.labels = LabelService.getPage( $scope.page,$scope.pageSize) ;		
			});

		 },

		 }

	}]);
});