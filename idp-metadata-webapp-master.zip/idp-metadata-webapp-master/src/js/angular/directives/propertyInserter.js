define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "propertyInserter", [ 'NodeService', function( NodeService ) {
	   return {
		 restrict: "E",
		 scope: {},
		 template: '<div class="layout-horizontal">' +
						'<div>' +
							'<label>Name:</label>' +
						'</div>' +
						'<div>' +
							'<input ng-model="propName" type="text" style="width:50px"/>' +
						'</div>' +
						'<div>' +
							'<label>Value:</label>' +
						'</div>' +
						'<div>' +
							'<input ng-model="propValue" type="text" style="width:50px"/>' +
						'</div>' +			
						'<div>' +
							'<button class="btn btn-primary" ng-click="addProperty()">Add <i class="icon-plus"/></button>' +
						'</div>' +
					'</div>',
		 
		 controller: function($rootScope, $scope )
		 {
			 $scope.propName = "";
			 $scope.propValue = "";
			 $scope.selectedNode;

			 /*
			 * When the selected node (left or right)
			 */
			 $scope.$on('left.node.selected', function(event,node){$scope.onNodeSelected(event,node);});
			 $scope.$on('right.node.selected', function(event,node){$scope.onNodeSelected(event,node);});


			 /**
			 * Called when a node is selected
			 */
			 $scope.onNodeSelected = function(event,node) {
				$scope.selectedNode = node;
				$scope.propName = "";
				$scope.propValue = "";
			 };


			 $scope.addProperty = function()
			 {
				$scope.selectedNode[ $scope.propName ] = $scope.propValue;

				 NodeService.addPropertyToNode($scope.selectedNode.nodeId, $scope.propName, $scope.propValue );
				 $scope.propName = "";
				 $scope.propValue = "";

				 $rootScope.$broadcast('node.updated', $scope.selectedNode );
			 }
			 
		 },

		 }

	}]);
});