define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "directionButton",  function(  ) {
	   return {
		 restrict: "E",
		 template: '<button class="btn btn-primary" ng-click="switch()"><i ng-class="directionIcon"/></button>',
		 scope: {},
		 controller: function($scope, RelationshipService )
		 {
			$scope.directionIcon = "neo-icon-arrowleft";
			RelationshipService.newRelationshipDirection = "left";

			$scope.switch = function() {
				if( $scope.directionIcon == "neo-icon-arrowleft" )
				{
					$scope.directionIcon = "neo-icon-arrowright";
					RelationshipService.newRelationshipDirection = "right";
				}
				else
				{
					$scope.directionIcon = "neo-icon-arrowleft";
					RelationshipService.newRelationshipDirection = "left";

				}
			}
		 },

		 }

	});
});