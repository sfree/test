define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "textBoxModal", function() {
	   return {
		 restrict: "E",
		 replace: 'true',
		 scope: {id:'@', title:'@', text:'@'},
		 template: 	'<div class="lightbox-modal">' +
						'<div class="lightbox-content border">' +
							'<h2>{{title}}</h2>' +
							'<p><textarea rows="50" cols="150" >{{text}}</textarea></p>' +
							'<p><button class="btn" ng-click="closeDialog()">OK</button></p>' +
						'</div>' +
					'</div>',
		 link: function( scope, elem, attr )
		 {
			scope.closeDialog = function() {
				 $('#' + scope.id ).toggleClass('is-open').trigger('dialogClosed');
			}			 
		 },


	   }
	});
});