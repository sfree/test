define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "nodeTable", [ 'LabelService', 'NodeService', function( LabelService, NodeService ) {
	   return {
		 restrict: "E",
		 scope: {id:'@'},
		 template:	
							'<table class="datagrid">' +
								'<thead>' +
									'<tr>' +
										'<th>Id</th>'+
										'<th>Name</th>'+
										'<th>Label <select ng-model="selectedLabel" ng-options="label.name for label in labels" /></th>' +
									'</tr>'+
								'</thead>'+
								'<tbody >'+
									'<tr ng-repeat="node in nodes" ng-click="onNodeClick(node)">' +
										'<td>{{node.nodeId}}</td>'+
										'<td>{{node.id}}</td>'+
										'<td>{{node.labels[0]}}</td>'+
									'</tr>'+
								'</tbody>'+
							 '</table>',

		 
		 controller: function($rootScope, $scope, LabelService,NodeService )
		 {
			 LabelService.loadLabels();
			 $scope.labels = LabelService.labels; 		 // The list of available labels
			 $scope.selectedLabel;						 // The currently selected label
			 $scope.nodes = NodeService.getNodes();			 // The nodes displayed in the table
			 $scope.selectedNodeProps = [];

			 /*
			 * When the selected label changes we reload the list of nodes
			 */
			 $scope.$watch('selectedLabel', function() {
				 if( $scope.selectedLabel )
				 {				
					$scope.nodes = NodeService.getNodesOfType( $scope.selectedLabel.name );	
				 }
			 });

			 $scope.$on('nodes.update', function() {
				 if( $scope.selectedLabel )
				 {				
					$scope.nodes = NodeService.getNodesOfType( $scope.selectedLabel.name );	
				 }
				 else
				 {
					$scope.nodes = NodeService.getNodes();
				 }
			 });

			 $scope.$on('labels.update', function() {
				 $scope.labels = LabelService.labels;
			 });

			 $scope.onNodeClick = function( node ) {			 
				 $rootScope.$broadcast($scope.id + '.node.selected', node );
			 }

			 $scope.initGrid = function() {
				 //var node = $(document).find(".node-grid");
				 //grid().node(node);
			 }

			 $scope.initGrid();
		 },

		 }

	}]);
});