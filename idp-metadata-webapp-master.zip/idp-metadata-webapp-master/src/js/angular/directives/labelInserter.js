define(['./module'], function( directives ) {
	'use strict';
	directives.directive( "labelInserter", [ 'LabelService', function( LabelService ) {
	   return {
		 restrict: "E",
		 scope: {},
		 template: '<div class="layout-horizontal">' +
						'<input ng-model="labelName" type="text" style="width:110px;padding-right:5px"/>' +
						'<button class="btn btn-primary" ng-click="createLabel()">Create Label</button>' +
					'</div>',
		 
		 controller: function($scope, LabelService )
		 {
			 $scope.labelName = "";

			 $scope.createLabel = function()
			 {
				 LabelService.createLabel($scope.labelName);
				 $scope.labelName = "";
			 }
			 
		 },

		 }

	}]);
});