define(['./module'], function( config ) {
	'use strict';

	config.
		constant("ENV","%ENV%").
		constant("HOST","%HOST%").
		constant("PORT","%PORT%"); 

});

