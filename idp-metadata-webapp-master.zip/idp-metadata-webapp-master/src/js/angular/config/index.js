define([
	'./config'
], function() {});