/**
 * bootstraps angular onto the window.document node
 */
define([
    'require',
    'angular',
    'angular-route',
    'angular-resource',
    'app',
    'routes',
	'jquery'
], function (require, angular) {
   'use strict';

    require([], function () {
        angular.bootstrap(window.document, ['app']);
    });
});