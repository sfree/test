npm install
npm install bower
node ./node_modules/bower/bin/bower install
cp -R ./src/* public