define(
  [
    'jquery'
  , 'd3'
  , 'resourceful/address'
  , 'visualize/visualize'
  , './deployprocess/util'
  , '../utils/bootstrap'
  , './deploywizard'
  , '../utils/local/pagedown/Markdown.Converter'
  , '../utils/local/pagedown/Markdown.Sanitizer'
  , '../utils/local/pagedown-extra/Markdown.Extra'
  , 'css!./styles.css'
  ]
, function(
    $
  , d3
  , address
  , visualize
  , deployUtil
  , swift
  , deployWizard
  , Markdown
  ) {

    'use strict'

    return function() {

      var $self = $(this)
        , markdown = Markdown.getSanitizingConverter()
        , initialRender = true
        , release
        , releaseData
        , revision
        , outOfDate
        , locked
        , org
        , environments = []
        , snowHost
        , releaseLinksSaved
        , rnowStatusCache = {}
        , formatDate = d3.time.format('%b %d, %Y')
        , collapsedDescHeightPx = 90
        , descriptionHeight = collapsedDescHeightPx
        , friendlyStatuses = {
            COMPLETED: 'Deployment succeeded'
          , FAILED: 'Deployment failed'
          , CANCELLED: 'Deployment was cancelled'
          , ROLLBACK: 'Deployment was rolled back'
          , STALE: 'Deployment is out of date'
          }

        , renderEnvironments = visualize.bind()
          .key(function(d) {
            return d.environment
          })
          .changed(onRenderEnviromentsChanged)

        , renderEnvironmentsPropertyStatus = visualize.bind()
          .key(function(d) {
            return d.environment
          })
          .changed(onRenderEnvironmentsPropertyStatusChanged)

        , renderEnvironmentsDetails = visualize.bind()
          .key(function(d) {
            return d.environment
          })
          .changed(onRenderEnviromentsDetailsChanged)

        , renderReleaseLinks = visualize.bind()
          .key(function(d) {
            return d.type + d.pointer + (d.status || '')
          })
          .added(onRenderReleaseLinksAdded)
          .changed(onRenderReleaseLinksChanged)

        , renderArtifactStats = visualize.bind()
          .changed(onArtifactStatsChanged)

        , renderOptions = visualize.bind()
          .into('option')
          .each(function(opt) {
            $(this).attr('value', opt)
            $(this).text(opt)
          })

      Markdown.Extra.init(markdown, {extensions: ["tables"]});

      setupHandlers.call($(this))

      return {
          start: swift.start
        , stop: swift.stop
        , update: update
      }

      function update(req) {
        var timestamp = req.param('timestamp')
        release = req.param('release')
        if (timestamp) {
          // determine the revision number for this timestamp and reload.
          $.getJSON('/api/release/' + release + '/revision/' + timestamp)
            .done(function(revision){
              address('release').param('release', release).param('revision', revision).view()
            })
        } else {
          revision = req.param('revision')

          setupReleaseDefinition(req)
          loadWatches()
          setupDeploymentHistory()
          setupActivityFeed()
        }
      }

      function setupEnvironments(org) {
        updateEnvironments()
      }

      function setupReleaseDefinition(req) {

        // Get release definition
        $.getJSON('/api/release/' + release + (revision?'?revision='+revision:''))
          .done(function(data){
            $('.view-release').toggleClass('locked', data.locked)

            revision = data.revision

            updateReleaseDetails(data)

            locked = data.locked
            outOfDate = revision!=data.latestRevision

            // If URL contains a revision number, and it is the latest revision, remove revision number
            // from URL. This prevents confusion if the release is then modified, so that the URL does
            // not show an old revision number.
            if(!outOfDate && req && req.param('revision')) address('release').param('release', release).view()

            $('.view-release').toggleClass('out-of-date', outOfDate)
            // Overview
            $('.old-revision').toggleClass('is-hidden', !outOfDate)
            $('.old-revision a').attr('href','/swift/release/' + release)
            $('.team').text(data.team.name)
            $('[type=date]').dateinput('value', '')

            $('.last-updated-date').text(moment(+data.lastUpdatedTime).format('DD-MMM-YYYY'))

            org = data.team.organisation.name
            swift.updateOrg(org)

            swift.breadcrumbs.render([{"title":"Releases","url":"/swift/" + org + "/releases"}, {"title":data.name}])

            setupEnvironments(org)

            address('users')
              .param({'guid': data.lastUpdatedBy})
              .view($('.last-updated-by'))

            address("artifactlist")
              .header("accept", ["application/view", "text/html"])
              .header("target", $(".artifact-list-container")[0])
              .send({"artifacts":data.artifacts, "showVersions":true, "waitForCallback":true, "readOnly":locked||outOfDate, org: org})

            setHistoryHeight()
          })
      }

      function updateReleaseDetails(data) {
        releaseData = data
        $('.heading .release-name').text(data.name)
        $('.description .content').html(markdown.makeHtml(data.description || ''))
        $('.release-date span').text(data.releaseDate ? moment.utc(+data.releaseDate).format('DD-MMM-YYYY') : 'None')
        $('.deploymentProcessName', $self).text(deployUtil.deploymentTypeMap[data.deploymentProcess] || '')

        $('input.release-name').attr('data-saved', data.name)
        $('input.release-date').attr('data-saved', data.releaseDate)
        $('textarea.release-description').attr('data-saved', data.description)
        setupReleaseLinks(data.releaseLinks)

        setReleaseTitleTooltip()
        showHideMoreLess()

        checkReleaseValidationWarnings()
      }

      function setupReleaseLinks(releaseLinksRaw) {
        if (!snowHost) {
          $.getJSON('/api/misc/snow/host')
            .done(function(hostname){
              snowHost = hostname
              resetReleaseLinks(releaseLinksRaw)
            })
        } else {
          resetReleaseLinks(releaseLinksRaw)
        }
      }

      function resetReleaseLinks(releaseLinksRaw) {
        releaseLinksSaved = releaseLinksRaw.sort(byLinkTypeAndName)

        releaseLinksSaved.forEach(function(link) {
          if (link.type == 'RNOW') {
            if (rnowStatusCache[link.pointer]) {
              link.status = rnowStatusCache[link.pointer]
            } else {
              $.getJSON('/api/release/snow/status/' + link.pointer)
                .done(function(status) {
                  rnowStatusCache[link.pointer] = status
                  // A brand new "link" object has to be created (thru $.extend) to let 
                  // 'visualize' recognize that there's a change in the array and therefore render it.
                  var linkWithStatus = $.extend({status : status}, link)
                  releaseLinksSaved[releaseLinksSaved.indexOf(link)] = linkWithStatus
                  resetReleaseLinks(releaseLinksSaved)
                })
            }
          }
        })

        d3.select('.links-column div.js-link-divs')
          .datum(releaseLinksSaved)
          .call(renderReleaseLinks)
      }

      function refreshReleaseLinksForEdit() {
        // Clone the links array.
        // Otherwise, the saved version will be wrongly modified when user hits cancel.
        d3.select('.links-table table tbody.js-link-items')
          .datum(releaseLinksSaved.slice())
          .call(renderReleaseLinks)
      }

      function setupDeploymentHistory() {
        // Present deployment history for this release
        address('deployhistory')
          .param('releaseId', release)
          .view($('.deployments-container')[0])
      }

      function setupActivityFeed() {
        address('activities')
          .param('releaseId', release)
          .param('records', 100)
          .view($self.find('.activities-container'))
      }

      function renderStats(d) {
        var sortedStats = []
          , artifactTypes = []

        $.each(d, function(type, count) {
          sortedStats.push( {'type': type, 'count': count} )
          artifactTypes.push(type)
        })
        sortedStats.sort(function(a, b) {
          if (a.count != b.count) return b.count - a.count
          return a.type.localeCompare(b.type)
        })

        d3.select('.stats')
          .datum(sortedStats)
          .call(renderArtifactStats)

        d3.select($self[0]).select('.switch-artifact-type').datum(artifactTypes).call(renderOptions)
        $('.switch-artifact-type', $self).selectinput('refresh')
      }

      function onArtifactStatsChanged(d, i) {
        var node = d3.select(this)

        node.select('.artifact-type')
          .text(d.type)

        node.select('.total')
          .text(d.count)
      }

      function setReleaseTitleTooltip() {
        // Add tooltip for long release name
        var releaseTitle = $('.heading .release-name')
        if (releaseTitle.get(0).offsetWidth < releaseTitle.get(0).scrollWidth)
          releaseTitle.attr('title', $('input.release-name').attr('data-saved'))
        else
          releaseTitle.attr('title','')
      }

      function setHistoryHeight() {
        var leftColHeight = $('.left-column').height()
        $('section.history1').height(leftColHeight - 443)
        $('section.history1 .scrollable').height(leftColHeight - 500)
      }

      function updateEnvironments() {
        $('.environments-options', $self).addClass('loading')
        environments = []
        d3.select('.environments-summary').datum(environments).call(renderEnvironments)
        // Get environment summaries
        $.when(
            $.getWithCache('/api/config/' + org + '/environments'),
            $.getJSON('/api/history/summary/' + release + (revision?'?revision='+revision:''))
          )
          .then(function(envsResult, deploymentSummaryResult) {
            var envs = envsResult[0]
              , deploymentSummary = deploymentSummaryResult[0]

            var initialEnvironments = envs.map(function(e){
              return { environment: e }
            })

            initialEnvironments.forEach(function(blankEnv){
              var deployed = deploymentSummary.some(function(dataEnv){
                if (blankEnv.environment == dataEnv.environment){
                  environments.push(dataEnv)
                  return true
                }
              })
              if(!deployed) environments.push(blankEnv)
            })
            d3.select('.environments-summary').datum(environments).call(renderEnvironments)
            $(document).trigger('auth-multi', org)
            $('.environments .slider').removeClass('move-right')
            $('.environments-options', $self).removeClass('loading')
          })
        // trigger auth now before the environments are rendered, result will be cached for next call.
        $(document).trigger('auth-multi', org)
      }

      function showHideMoreLess() {
        var wasExpanded = localStorage['swift.release.description.expanded'] == 'true'
        // More/Less Button..
        $('.description .content').css("-webkit-transition", "none")

        $('.description .content').css('max-height', collapsedDescHeightPx)
        var descriptionContent = $('.description .content').get(0)
        descriptionHeight = descriptionContent.scrollHeight

        $('.left-column .expand').toggleClass('invisible', (descriptionHeight <= collapsedDescHeightPx))
        expandDescription(wasExpanded)

        setHistoryHeight()
        $('.description .content').css("-webkit-transition", "max-height 0.2s")
      }

      function getSelectedEnvironments() {
        return $('.environments-summary :checked', $self).map(function(i, e) { return $(e).attr('data-env') }).get()
      }

      /* Event handlers - Visualize */

      function onRenderEnvironmentsPropertyStatusChanged(d,i) {
        d3.select(this).select('.property-status')
          .text(d.propertiesSet)
          .classed(d.propertiesSet, true)
        onRenderEnviromentsChanged.call(this, d, i)
      }

      function onRenderEnviromentsChanged(d, i) {
        var s = d3.select(this)
        s.classed(d.environment, true)
        s.attr('data-env',d.environment)
        s.select('input')
          .attr('id', 'chk-' + d.environment)
          .attr('data-env',d.environment)
          .classed(d.environment, true)
        s.select('label')
          .attr('for', 'chk-' + d.environment)
          .text(d.environment.toUpperCase())
        if(d.status)
          s.select('label').classed(d.status, true)

        var envDetails = $('.environments-detail', this).get(0)
        if (envDetails)
          onRenderEnviromentsDetailsChanged.call(envDetails, d, i)
      }

      function onRenderEnviromentsDetailsChanged(d, i) {
        var s = d3.select(this)
        s.classed(d.environment, true)
        s.select('.heading span').text(d.environment.toUpperCase())
        s.selectAll('.buttons button').classed(d.environment, true)
        s.selectAll('.buttons button').attr('data-env', d.environment)
        if (d.status) {
          s.select('.heading span').classed(d.status, true)
          s.select('.deploy-time').text(moment(+d.deployTime).fromNow())
          s.select('.content.status').classed(d.status, true)
          s.select('.content.status').text(d.status)

          address('users')
            .param({'guid': d.user})
            .view(s.select('.user-profile-container').node())

          if (d.status == 'STALE') {
            var artifacts = ''
            d.staleArtifacts.forEach(function(e){
              artifacts += e.artifactId + ' - ' + (e.deployedVersion ? e.deployedVersion : '(not deployed)') + ' -> ' + e.releaseVersion + '<br/>'
            })
            s.select('.status-detail .content').html('Changes to release since last deployment: <br/>' + artifacts)
          }
        } else {
          s.select('.details').html('Not deployed')
          s.select('button.rollback-toggle')
            .classed('auth', false)
            .classed('is-hidden', true)
        }
      }

      function navToStatus(){
        var artifacts = d3.select('.js-artifact-items')
          .datum()
          .map(function(d){
            return d.artifactId
          })
          .join(',')

        address('status')
          .param('org', org)
          .param('environment', this.dataset.env)
          .param('artifact', artifacts)
          .view()
      }

      function onRenderReleaseLinksChanged(d, i) {
        var tr = d3.select(this)
          , linkUrl = (d.type == 'RNOW') ? 'https://' + snowHost + '/nav_to.do?uri=change_request.do?sys_id=' +  d.pointer : d.pointer

        tr.select('.release-link-type')
          .text(d.type)

        tr.select('.release-link-pointer a')
          .text(d.pointer)
          .attr('title', linkUrl)
          .attr('href', linkUrl)

        tr.select('.release-link-status')
          .text(d.status)
          .attr('title', d.status)
      }

      function onRenderReleaseLinksAdded(d, i) {
        if (!initialRender) {
          glowMomentarily(this)
          initialRender = true
        }
      }

      function byLinkTypeAndName(a, b) {
        // RNOW links always come first
        return a.type != 'RNOW' && b.type == 'RNOW' ? 1 :
               a.type == 'RNOW' && b.type != 'RNOW' ? -1 :
               a.type > b.type ? 1 :
               a.type < b.type ? -1 :
               a.pointer > b.pointer ? 1 :
               a.pointer < b.pointer ? -1 :
               0
      }

      /* Event handlers - GUI */

      function setupHandlers() {
        // Cancel default closing of dropdown.
        $('.buttons .collapsible-dropdown .children-container > *', this)
          .on('click', function(event){
            event.stopPropagation()
          })

        // Release definition
        $('.overview button.edit', this).click(onEditClick)
        $('button.save-release', this).click(onSaveClick)
        $('select.release-link-type-draft', this).change(onSelectLinkTypeChange)
        $('button.add-link', this).click(onAddLinkClick)
        $('.expand a', this).click(onExpandClick)
        $('.clone', this).click(onCloneClick)
        $('.btn.lock', this).click(onLockClick)
        $('.create-clone', this).click(onCreateCloneClick)
        $('.switch-artifacts', this).click(onSwitchArtifacts)
        $('.switch-dialog-go', this).click(onSwitchArtifactVersion)
        $('.export-list', this).click(onExportClick)
        this.on('click', '.form-field .links-table .delete', onDeleteLinkClick)
        this.on('click', '.deploymentProcess', onDeployProcessClick)
        $('.preview-toggle', this).click(onPreviewToggle)

        this.on('deployment-process-saved', '.lightbox-deployprocess', function(e, data){
          revision = null
          updateReleaseDetails(data)
        })

        // Environments
        this.on('change', '.env:checkbox', onEnvCheckboxChange)
        this.on('click', '.btn-deploy', onPredeployClick)
        this.on('click', '.btn-rollback', onRollbackClick)
        this.on('click', '.request-deploy', onRequestDeployClick)
        this.on('click', '.rollback-toggle', onRollbackClick)
        this.on('click', '.live-status', navToStatus)

        $('.btn-manage-properties', this).click(navigateToManageProperties)

        // History
        $('.btn-deployments', this).click(onHistoryShowDeploymentsClick)
        $('.btn-activities', this).click(onHistoryShowActivitiesClick)

        // Artifacts
        $('.artifact-list-container', this).on('statsChanged', onStatsChanged)
        $('.artifact-list-container', this).on('artifactAdded', onArtifactAdded)
        $('.artifact-list-container', this).on('artifactDeleted', onArtifactDeleted)
        $('.artifact-list-container', this).on('artifactVersionChanged', onArtifactVersionChanged)
        $('.artifact-list-container', this).on('renderChanged', onArtifactListRenderChanged)

        // Watches
        $('.watches li', this).click(onWatchToggled)
      }

      function onPreviewToggle() {
        var preview = $(this).text() == 'Preview'

        showEditPreview(preview)
      }

      function showEditPreview(preview) {
        $('.preview-toggle', $self).text(preview ? 'Edit' : 'Preview')
        $('.release-description', $self).toggleClass('is-hidden', preview)
        $('.preview', $self).toggleClass('is-hidden', !preview)

        if (preview) $('.preview', $self).html(markdown.makeHtml($('.release-description', $self).val()))
      }

      function loadWatches() {
        $('.watches', $self).addClass('is-hidden')

        $.getJSON('/api/watch/release/' + release)
          .done(function(data){
            $('.watches li', $self).each(function(i, ele) {
              var watchType = $(ele).attr('data-type')
                , watch = data.indexOf(watchType) != -1

              updateWatch($(ele), watch)
            })
            updateWatchesButton()

            $('.watches', $self).removeClass('is-hidden')
          })
      }

      function onWatchToggled() {
        var li = $(this).closest('li')
          , watchType = li.attr('data-type')
          , watch = !$('i', li).hasClass('neo-icon-tick')
          , url = '/api/watch/release/' + release + '/' + watchType

        // executeAjax causes the screen to shift due to loading spinner position
        return $.ajax(url, {type: watch ? 'PUT' : 'DELETE'}).done(function() {
          updateWatch(li, watch)
          updateWatchesButton()
        })
      }

      function updateWatch($item, watch) {
        $('i', $item).toggleClass('neo-icon-tick', watch)
      }

      function updateWatchesButton() {
        var anyWatches = $('.watches li i.neo-icon-tick', $self).length > 0

        $('.watches .btn-text', $self).text(anyWatches ? 'Watching' : 'Watch')
      }

      function onEditClick(e) {
        populateLatestReleaseDetails(function () {
          showEditPreview(false)
          $('.lightbox-edit').toggleClass('is-open')
          $('input.release-name').val($('input.release-name').attr('data-saved')).focus()
          $('input.release-date').dateinput('value', $('input.release-date').attr('data-saved') ? moment.utc(+$('input.release-date').attr('data-saved')).format('DD MMM YYYY') : '')
          $('textarea.release-description').val($('textarea.release-description').attr('data-saved'))
          $('select.release-link-type-draft').val('').selectinput('refresh')
          onSelectLinkTypeChange()
          refreshReleaseLinksForEdit()
        })
      }

      function onSelectLinkTypeChange() {
        var hint = ($('select.release-link-type-draft option:selected').text() == 'RNOW') ? "Eg CHG0034847" : "URL of your link"
        $('input.release-link-pointer-draft').attr("placeholder", hint);
      }

      function onAddLinkClick() {
        var type = $('select.release-link-type-draft option:selected').val()
          , pointer = $('input.release-link-pointer-draft').val()
          , releaseLinks = d3.select('.links-table table tbody.js-link-items').datum()
          , releaseLinkToAdd =
            { "id": null
              , "type": type
              , "pointer": pointer
            }

        initialRender = false
        if (!isLinkValid(releaseLinks, releaseLinkToAdd)) return

        // Just add the link to the Edit lightbox.
        // Delay the Ajax call until the user hits the Save button.
        releaseLinks.splice(0, 0, releaseLinkToAdd)

        d3.select('.links-table table tbody.js-link-items')
          .datum(releaseLinks)
          .call(renderReleaseLinks)

        $('input.release-link-pointer-draft').val('')
      }

      function isLinkValid(presentLinks, newLink) {

        // Max number of links per release
        if (presentLinks && presentLinks.length >= 5) {
          $(document).trigger("inform.warning", "Each release can contain 5 release links at most")
          return false
        }

        if (!newLink || !newLink.type || !newLink.pointer) {
          $(document).trigger("inform.warning", "Specify the change ID / URL for your release link")
          return false
        }

        var newId = newLink.type + newLink.pointer
        var duplicates = $.grep(presentLinks, function(ele) {
          var currId = ele.type + ele.pointer
          return currId == newId
        })
        if (duplicates.length > 0) return false

        if (newLink.type == 'RNOW' && !newLink.pointer.match(/^CHG/)) {
          $(document).trigger("inform.warning", "Specify a valid change ID for your RNOW link")
          return false
        } else if (newLink.type == 'Other' && !newLink.pointer.match(/^https?:\/\//)) {
          $(document).trigger("inform.warning", "Specify a valid URL for your Other link")
          return false
        }

        return true
      }

      function onDeleteLinkClick() {
        var releaseLinkToDelete = d3.select(this.parentNode.parentNode).datum()

        // Just remove the link from the Edit lightbox.
        // Delay the Ajax call until the user hits the Save button.
        var releaseLinks = d3.select('.links-table table tbody.js-link-items').datum()
        , i = getReleaseLinkIndex(releaseLinks, releaseLinkToDelete)

        if (i > -1) {
          releaseLinks.splice(i, 1)
        }

        d3.select('.links-table table tbody.js-link-items')
          .datum(releaseLinks)
          .call(renderReleaseLinks)
      }

      function getReleaseLinkIndex(arr, item) {
        for (var i =0; i < arr.length; i++) {
           if (arr[i].type == item.type && arr[i].pointer == item.pointer)
            return i;
        }
        return -1;
      }

      function onSaveClick(e) {
        var name = $('input.release-name').val()
          , releaseDate = ($('input.release-date').val() && moment.utc($('input.release-date').val()).valueOf())
          , description = $('textarea.release-description').val()
          , releaseLinks = d3.select('.links-table table tbody.js-link-items').datum()

        releaseLinks = releaseLinks ? releaseLinks : []

        releaseLinks = releaseLinks.map(function(link) {
          return {type: link.type, pointer: link.pointer}
        })

        swift.executeAjax($(this), $('.lightbox-edit', $self), function() {
          return $.ajax({
            type: 'PUT',
            data: JSON.stringify(
              { description: description
              , releaseDate: releaseDate
              , name: name
              , releaseLinks: releaseLinks
              , lastUpdatedTime: releaseData.lastUpdatedTime
              }),
            url: '/api/release/' + release + '/details',
            success: function(releaseUpdates) {
              $(document).trigger('inform.success', 'Release details successfully saved')

              $('.lightbox-edit').removeClass('is-open')
              revision = null
              updateReleaseDetails(releaseUpdates)
            },
            dataType: 'json',
            contentType: 'application/json; charset=utf-8'
          })
        })
      }

      function onCloneClick() {
        $('.lightbox-clone').toggleClass('is-open')
        $('input.clone-name').val($('input.release-name').attr('data-saved')).focus()
      }

      function onLockClick() {
        if(locked){
          if (!confirm('Are you sure you want to unlock this release?' +
                '\nProduction deployment cannot proceed if the release is unlocked.')) { return } }

        $.ajax({
            type: 'PUT'
          , url: '/api/release/'
            + release
            + '/lock/'
            + !locked })
            .done(function(){
              $(document).trigger('inform.success', 'Release has been '+ (!locked? 'locked' : 'unlocked'))
              revision = null
              setupReleaseDefinition()
            })
      }

      function onCreateCloneClick(e) {
        var clone =
        {
          name: $('input.clone-name').val()
          , releaseDate: ($('input.clone-release-date').val() && moment.utc($('input.clone-release-date').val()).valueOf())
        }
        $.post('/api/release/clone/' + release, JSON.stringify(clone))
          .done(function(data) {
            $('.lightbox-clone').toggleClass('is-open')
            $(document).trigger('inform.success', 'Release cloned successfully')
            address('release')
              .param('release', data.id)
              .view()
          })
      }

      function onExpandClick(e) {
        var expanded = !$('.description').hasClass('expanded')

        localStorage['swift.release.description.expanded'] = expanded

        expandDescription(expanded)

        setTimeout(setHistoryHeight, 500)
      }

      function expandDescription(expanded) {
        $('.description').toggleClass('expanded', expanded)
        $('.description .content').css('max-height', expanded ? descriptionHeight : collapsedDescHeightPx)
        $('.expand a span').text(expanded ? 'less' : 'more')
        $('.expand', $self).toggleClass('expanded', expanded)
      }

      function onSwitchArtifacts() {
        var switchType = this.dataset.type

        if (switchType == 'RELEASE') {
          switchArtifacts(switchType)
        } else {
          $('.switch-versions-area', $self).toggleClass('is-hidden', switchType != 'SPECIFIC')
          $('.switch-dialog', $self).addClass('is-open')
        }
      }

      function onSwitchArtifactVersion() {
        var switchType = $('.switch-versions-area', $self).hasClass('is-hidden') ? 'SNAPSHOT' : 'SPECIFIC'
          , artifactType = $('.switch-artifact-type', $self).val()
          , specificVersion = $('.switch-version', $self).val()

        switchArtifacts(switchType, artifactType, specificVersion)

        $('.switch-dialog', $self).removeClass('is-open')
      }

      function switchArtifacts(switchType, artifactType, specificVersion) {
        swift.executeAjax($('span.switch'), $('.artifact-list-container'), function onSwitchArtifactsExecute() {
          return $.ajax({
              type: 'PUT'
            , url: '/api/release/'
              + release
              + '/switchArtifacts/'
              + switchType
              + '?' + $.param({artifactType: artifactType, version: specificVersion})
            , dataType: 'json'
            , contentType: 'application/json; charset=utf-8'})
              .done(function(d) {
                revision = null
                updateEnvironments()
                address("artifactlist")
                  .header("accept", ["application/view", "text/html"])
                  .header("target", $(".artifact-list-container")[0])
                  .send({"artifacts":d.artifacts, "showVersions":true, org: org})

                $(document).trigger('inform.success', 'All artifact versions successfully switched')
              })
        })
      }

      function onExportClick() {
        var exportString = ""
          , csvExport
          , confluenceExport

        d3.select('.artifact-list-container')
          .select('.js-artifact-items').datum()
          .forEach(function(artifact) {
            exportString +=
              "_beg_" + artifact.artifactId +
              "," + artifact.groupId + "," +
              artifact.version + "_end_\n"
          })

        // Easier then regexp for beginning and end of each line
        csvExport = exportString.replace(/_beg_|_end_/g,"")
        confluenceExport = exportString.replace(/_beg_|_end_|,/g,"|")
        confluenceExport = "|| Artifact || Group ID || New Version ||\n" + confluenceExport

        $('.artifact-csv-list .artifact-csv-content > textarea').text(csvExport)
        $('.artifact-csv-list .artifact-confluence-content > textarea').text(confluenceExport)
        $('.artifact-csv-list').toggleClass('is-open')
      }

      function onEnvCheckboxChange(){
        $self
          .find('.btn-manage-properties, .btn-deploy, .btn-rollback')
          .prop('disabled', getSelectedEnvironments().length == 0)
      }

      function onPredeployClick() {
        if (getSelectedEnvironments().length == 0) {
          $(document).trigger("inform.warning", "Select at least one environment")
          return
        }
        // Perform predeploy release checks
        // TODO disable screen during ajax request
        populateLatestRevision(function() {
          deployWizard.jumpToNextStep($self, org, release, revision, getSelectedEnvironments(), null, false)
        })
      }

      function onRollbackClick() {
        var envs = getSelectedEnvironments()
        if (envs.length == 0) {
          $(document).trigger("inform.warning", "Please select an environment")
          return
        } else if (envs.length > 1) {
          $(document).trigger("inform.warning", "Rollback is only supported for a single environment")
          return
        }
        // Show Rollback Lightbox
        address('rollback')
          .param('release', release)
          .param('org', org)
          .param('env', envs[0])
          .view($('.lightbox-rollback .lightbox-content').get(0))

        $('.lightbox-rollback').toggleClass('is-open')
      }

      function onRequestDeployClick(){
        populateLatestRevision(function(){
          $('.release-url textarea').text(location.protocol + '//' + location.host + location.pathname + '?revision=' + revision)
          $('.release-url').toggleClass('is-open')
          $('.release-url textarea').select()
        })
      }

      function onDeployProcessClick() {
        address("deployprocess")
        .header("accept", ["application/view", "text/html"])
        .header("target", $('.lightbox-deployprocess .lightbox-content')[0])
        .send(releaseData)

        $('.lightbox-deployprocess').addClass('is-open')
      }

      function populateLatestRevision(callback){
        if(revision){
          callback()
        } else {
          $.getJSON('/api/release/' + release + '/summary')
            .done(function(data){
              revision = data.revision
              callback()
            })
        }
      }

      function populateLatestReleaseDetails(callback){
        // If the release is stale, refresh.
        if (revision && releaseData.revision == revision){
          callback()
        } else {
          $.getJSON('/api/release/' + release + (revision?'?revision='+revision:''))
            .done(function(data){
              revision = data.revision
              updateReleaseDetails(data)
              callback()
            })
        }
      }

      function navigateToManageProperties() {
        var envs = getSelectedEnvironments()

        if (envs.length == 0) {
          $(document).trigger("inform.warning", "Select at least one environment")
          return
        }

        populateLatestRevision(function() {
          address('releaseproperties')
            .param('org', org)
            .param('environment', envs.join(','))
            .param('release', release)
            .param('revision', revision).view()
        })
      }

      function onHistoryShowDeploymentsClick() {
        $('.history1 .slider').removeClass('move-right')
      }

      function onHistoryShowActivitiesClick() {
        $('.history1 .slider').addClass('move-right')
      }

      function onStatsChanged(e, d) {
        renderStats(d)
      }

      function onArtifactAdded(e, d) {
        // Handle new artifact added - in this case, we save immediately
        $.post('/api/release/' + release + '/artifact'
          , JSON.stringify(artifact(d)))
            .done(function() {
              revision = null
              updateEnvironments()
              setHistoryHeight()
              $(document).trigger('inform.success', 'Artifact successfully added')
              $('.artifact-list-container').trigger('artifactWasAdded', d)
            })
            .always(function() {
              $('.artifact-lookup input').val('')
              $('.version-lookup input').val('')
              $('.artifact-lookup input:not(.ghost)').focus()
            })
      }

      function onArtifactDeleted(e, d) {
        // Handle artifact being deleted - in this case, we save the change immediately
        $.ajax({
            type: 'DELETE'
          , url: '/api/release/' + release  + '/artifact'
          , data: JSON.stringify(artifact(d))
          , dataType: 'json'
          , contentType: 'application/json; charset=utf-8'})
            .done(function() {
              revision = null
              updateEnvironments() // Needed here as visualize.bind.changed() doesn't get called on remove
              setHistoryHeight()
              $(document).trigger('inform.success', 'Artifact successfully removed')
              $('.artifact-list-container').trigger('artifactWasDeleted', d)
            })
      }

      function onArtifactVersionChanged(e, d) {
        // Handle existing artifact version being changed - in this case, we save the change immediately
        $.ajax({
            type: 'PUT'
          , url: "/api/release/" + release  + "/artifact"
          , data: JSON.stringify(artifact(d))
          , dataType: "json"
          , contentType: "application/json; charset=utf-8"})
            .done(function() {
              revision = null
              updateEnvironments()
              $(document).trigger("inform.success", "Artifact version successfully updated")
            })
      }

      function artifact(data) {
        return { groupId: data.groupId, artifactId: data.artifactId, version: data.version }
      }

      function onArtifactListRenderChanged(e) {
        setHistoryHeight()
      }

      function checkReleaseValidationWarnings() {
        $.getJSON('/api/release/' + release + '/validate')
          .done(function(warnings){
            var $sticky = $('.sticky-error.release-validation')
              , show = (warnings && warnings.length > 0)

            if (show) {
              // only the first warning is shown.  Don't overwhelm the user
              $('li', $sticky).html(warnings[0].message)
            }

            $sticky.toggleClass('is-hidden', !show)
          })
      }

    } // end resource factory function

  } // end amd

) // end define
