;define(
  [ 'jquery'
  , 'visualize/visualize'
  , 'resourceful/address'
  , 'css!../../global.css'
  , 'css!./styles.css'
  ], function($, visualize, address) {

  'use strict'

  return function() {
    var release
    ,   org
    ,   environment
    ,   self = this
    ,   clone = visualize.selector.appendClone($('.tr', this).remove().get(0))
    
    function render(data){
      var node = d3.select('.p').selectAll('.tr').data(data)

      node.exit().remove()
      node.enter().select(clone)

      node.select('.group').text(function(d){ return d.artifact.groupId })
      node.select('.name').text(function(d){ return d.artifact.artifactId })
      node.select('.current').text(function(d){ return d.artifact.version })
      node.select('.deployed').text(function(d){ return d.liveVersion })

      var rollbackOptions = node.select('select').selectAll('option').data(function(d) { return d.rollbackVersions })

      rollbackOptions.enter().append('option')

      rollbackOptions
          .text(function(d) {return d})
          .attr('val', function(d) {return d})

      node.select('.rollback').each(function(d){
         if (!d.rollbackVersions.length) this.textContent = ''
         else $('select', this).selectinput()
      })

      node.select('.include input')
        .attr('disabled', function(d){ if (!d.rollbackVersions.length) return true })
        .property('checked', function(d){ return d.rollbackVersions.length })

    }

    function renderWarnings(warnings) {
      address('deploywarnings')
        .header('accept', ['application/view', 'text/html'])
        .header('target', $('.rollback-warnings', self).get(0))
        .send({ releaseId : release , warnings: warnings })
    }

    $('.btn-primary', self).click(function() {
      var data = []
      $('.tr', self).each(function(){
        var $roll = $(this)
        if (!$roll.find('.rollback').text() || !$roll.find('[type=checkbox]').is(':checked')) return;
        data.push(
          { groupId:  $roll.find('.group').text()
          , artifactId:   $roll.find('.name').text()
          , version:  $roll.find('.rollback .input-select').text()
          })
      })

      $('.btn-primary', self).prop('disabled', true)
      $('footer i', self).addClass('loading')
      $.post('/api/deployment/rollback/' + environment + '/' + release, JSON.stringify({ artifacts: data }))
        .done(function(planId){
          address('deploy')
            .param('plan', planId)
            .param('org', org)
            .param('env', environment)
            .param('release', release)
            .view()
        })
        .always(function(){
          $('.view-rollback .btn-primary').prop('disabled', false)
          $('footer i', self).removeClass('loading')
        })
    })

    function onCheckboxChange(evt) {
      var toggleCtrlObj = $('#toggle-ctrl').get(0)
      
      if (evt.target == toggleCtrlObj) {
        batchChangeAllRollbackableArtifacts($('#toggle-ctrl').prop('checked'))
      } else {
        recalculateToggleCtrlState()
      }
    }

    function batchChangeAllRollbackableArtifacts(targetState) {
      $('.view-rollback :checkbox:not([disabled])').prop('checked', targetState)
    }

    function recalculateToggleCtrlState() {
      var toggleCtrl = $('#toggle-ctrl')
      ,   rollbackableArtifacts = $('.view-rollback .td :checkbox:enabled')
      ,   numRollbackableArtifacts = rollbackableArtifacts.length
      ,   numRollbackableArtifactsChecked = rollbackableArtifacts.filter(':checked').length

      toggleCtrl.prop('disabled', (numRollbackableArtifacts == 0))
      
      if (numRollbackableArtifactsChecked == 0) {
        toggleCtrl.prop('checked', false).prop('indeterminate', false);
      } else if (numRollbackableArtifactsChecked == numRollbackableArtifacts) {
        toggleCtrl.prop('checked', true).prop('indeterminate', false);
      } else {
        toggleCtrl.prop('checked', false).prop('indeterminate', true);
      }
    }

    function recalculateRollbackBtnState() {
      var rollbackBtn = $('.view-rollback .btn-primary')
      ,   numRollbackableArtifacts = $('.view-rollback .td :checkbox:enabled').length
      
      rollbackBtn.prop('disabled', !numRollbackableArtifacts)
    }

    return function(req) {
      release = req.param('release')
      environment = req.param('env')
      org = req.param('org')

      $('.environment', self).text(environment.toUpperCase())

      render([])
      renderWarnings([])

      $.getJSON('/api/release/' + release + '/rollback/' + environment)
        .done(function(data){
          render(data.artifactVersions)
          renderWarnings(data.warnings)
        })
        .always(function(){
          $('.view-rollback .p i.loading').removeClass('loading')
          $('.view-rollback :checkbox:not([disabled])').change(onCheckboxChange)
          recalculateToggleCtrlState()
          recalculateRollbackBtnState()
        })
    }
  }
})