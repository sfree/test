;define(
  [ 'jquery'
  , 'resourceful/address'
  , 'visualize/visualize'
  , '../../config/details/updateConfig'
  , 'css!../../global.css'
  , 'css!./styles.css'
  ], function($, address, visualize, updateConfig) {

  'use strict'

  return function(){
    var $self = $(this)
      ,   data
      ,   env // current environment being configured
      ,   renderInstances = visualize.bind()
          .into('.instances')
          .each(function(config){
            $('.name', this).text(config.artifactId + ' (' + config.name + ')')
            address('configdetails')
              .header('accept', ['application/view', 'text/html'])
              .header('target', $('.config-container', this))
              .send(config)
          })

    $('.save-continue', this).click(function() {
      console.log('save')
      var deployed = []
        , notDeployed = []

      $('.instance', $self).each(function() {
        var datum = d3.select(this).datum()
        if ($('.skipDeploy', this)[0].checked) {
          notDeployed.push({groupId: datum.groupId, artifactId: datum.artifactId, environmentId: datum.environment.id})
        } else {
          console.log('updating data')
          updateConfig.update(datum, $(this), env)
          deployed.push(datum)
        }
      })

      $.ajax({
        type: 'PUT',
        url: '/api/config/artifacts',
        data: JSON.stringify({configured: deployed, notDeployed: notDeployed}),
        success: function(savedConfig){
          $(document).trigger('inform.success', 'Config Management successfully saved!')
          // Continue with predeploy
          $self.trigger('continue-predeploy-checks')
        },
        dataType: 'json',
        contentType: 'application/json; charset=utf-8'
      })
    })

    $self.on('change', '.skipDeploy', function() {
      var skipDeploy = this.checked

      $(this).closest('.instance').find('.config-container').toggleClass('is-hidden', skipDeploy)
    })

    return function(req) {
      data = req.body

      console.log(data)
      
      // only one environment at a time will be returned for configuring.
      env = data.stepData[0].environment.name
      $('.deploy-step-title .environment', $self).text(env.toUpperCase())
      console.log('render items to be configured')
      console.log(data.stepData)
      renderInstances.within($self[0])
      renderInstances([])
      renderInstances(data.stepData)
      console.log($self)
      $self.closest('.lightbox-modal').addClass('is-open')            
    }
  }
})