;define(
    [ 'jquery'
    , 'resourceful/address'
    , "../../utils/bootstrap"
    , 'css!../../global.css'
    , 'css!./styles.css'
    ], function($, address, swift) {

        'use strict'

        return function(){
            var tree, self, current, artifactInstanceId
            ,   checkButtons = function(){
                    $('.previous').toggleClass('is-disabled', current == tree.length-1)
                    $('.next').toggleClass('is-disabled', current == 0)
                }
            ,   changeCurrentIndex = function(newIndex) {
                    current = Math.min(Math.max(newIndex, 0), tree.length-1);
                    checkButtons()
                    address('history')
                        .param('id', tree[current].id)
                        .param('artifactInstanceId', artifactInstanceId)
                        .view()
                }
            ,   updateSummary = function(){
                    var status = '', type = ''
                    switch(tree[current].deploymentStatus) {
                        case 'MANUAL': status = 'completed a manual'; break;
                        case 'COMPLETED': status = 'completed ' + (tree[current].deploymentType == 'AdHoc' ? 'an': 'a'); break;
                        case 'FAILED': status = 'failed ' + (tree[current].deploymentType == 'AdHoc' ? 'an': 'a'); break;
                        case 'CANCELLED': status = 'cancelled'; break;
                    }

                    switch(tree[current].deploymentType) {
                        case 'Release': type = 'deployment'; break;
                        case 'Rollback': type = 'rollback'; break;
                        case 'AdHoc': type = 'action'; break;
                    }

                    $('summary .status', self).text(status)
                    $('summary .type', self).text(type)
                    $('summary .environment', self).text('in ' + tree[current].envDeployments.map(function(e) { return e.environment.name.toUpperCase() }).join(', '))
                    $('summary time', self).text('at ' + moment(+tree[current].deployTime).format('HH:mm on MMM-DD-YYYY'))

                    address('users')
                        .param({'guid': tree[current].user })
                        .view($('figure', self))

                    address('users')
                        .param({'guid': tree[current].user })
                        .view($('.user', self))
                }

            function renderArtifactDetails(data) {
              $('.release-summary .team').text(data.groupId)
              $('.release-summary .release').text(data.artifactId + (data.name == 'DEFAULT' ? '' : '(' + data.name + ')'))

              $('.release-summary .dates').addClass('is-hidden')

              var org = data.envDeployment.environment.organisation.name

              swift.breadcrumbs.updateByHandle(
                    'artifact'
                  , data.artifactId
                  , '/swift/' + org + '/config/artifact/' + data.groupId + '/' + data.artifactId
              )

              swift.updateOrg(org)
            }

            $(this).on('click', '.previous:not(.is-disabled)', function(){ changeCurrentIndex(++current) })
            $(this).on('click', '.next:not(.is-disabled)', function(){ changeCurrentIndex(--current) })

            return {
                update: function(req) {
                    self = this
                    // TODO expand by default actions for this instance on the deployment plan.
                    artifactInstanceId = req.param('artifactInstanceId')

                    if (!tree)
                        if (artifactInstanceId)
                            swift.breadcrumbs.render([{"title":"Artifacts"}, {handle: 'artifact', "title": 'Artifact'}, {"title":"Deployment History"}])
                        else
                            swift.breadcrumbs.render([{'handle': 'Releases'}, {'handle':'release'}, {'title':'Deployment History'}])

                    // Set Header Information..
                    $.getJSON('/api/history/deployment/' + req.param('id'))
                        .done(function(deployment){
                            // Get Tree Information..
                            if (!tree) {
                                var url = artifactInstanceId ?
                                    '/api/history/detailed/artifact?records=200&id=' + artifactInstanceId :
                                    '/api/history/detailed/' + deployment.releaseId + '?records=200'

                                $.getJSON(url)
                                    .done(function(data){
                                        tree = data.pageResults

                                        if (artifactInstanceId) {
                                            renderArtifactDetails(tree[0])
                                            tree = tree.map(function(e) { return e.envDeployment.deployment })
                                        }

                                        var org = tree[0].envDeployments[0].environment.organisation.name

                                        if (!artifactInstanceId) {
                                            swift.breadcrumbs.updateByHandle('Releases', 'Releases', '/swift/' + org + '/releases')
                                        }
                                        swift.updateOrg(org)

                                        tree.some(function(d, i){ return d.id == deployment.plan.planId ? (current = i)+1 : false })
                                        updateSummary()
                                        checkButtons()
                                    })
                            }  else updateSummary()

                            // Set Header Information..
                            if (!artifactInstanceId) {
                                $('.release-summary .dates').removeClass('is-hidden')
                                swift.render.releaseSummary(deployment.releaseId)
                            }

                            // Render Deployment Plan..
                            address('deployplan')
                                .header('accept', ['application/view', 'text/html'])
                                .header('target', $('.deployment-plan-container', self))
                                .param('historical', true)
                                .param('artifactInstanceId', artifactInstanceId)
                                .send(deployment.plan)
                        })
                        .fail(function(data){ $(self).addClass('not-found') })

                }
                , start: function() {
                    $('html').addClass('swift-ux')
                  }
                , stop: function() { $('html').removeClass('swift-ux'); swift.breadcrumbs.stop() }
            }
        }
})
