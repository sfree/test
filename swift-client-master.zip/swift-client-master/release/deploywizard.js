;define(
  [
    'jquery'
  , '../utils/bootstrap'
  , 'resourceful/address'
  ]
, function(
    $
  , swift
  , address
  ) {

    'use strict'

    var $page
      , org
      , release
      , revision
      , environments
      , deploymentContextId
      , skipPropertiesCheck

    /**
    * A wizard within the websdk and resourceful.  I think this pattern is pretty horrid implemented with the websdk and resourceful.  
    * Some dislikes 
    *  - As some screens are lightboxes, this requires the lightbox to be present in all places the wizard can be invoked from.
    *  - Each parameter in the wizard needs to be defined in sooo many places - each time when navigating, each time when loading the request, resource.json 
    *
    * It works, but it is far from elegant.  Resourceful works well for client side controlled navigation.
    */

    function jumpToNextStep($pageP, orgP, releaseP, revisionP, environmentsP, deploymentContextIdP, skipPropertiesCheckP) {
      org = orgP
      $page = $pageP
      release = releaseP
      revision = revisionP
      environments = environmentsP
      deploymentContextId = deploymentContextIdP
      skipPropertiesCheck = skipPropertiesCheckP

      // pre deployment continue events
      $page.off('continue-predeploy-checks')      
      $page.on('continue-predeploy-checks', onContinuePredeploy)

      doJumpToNextStep()
    }

    function doJumpToNextStep() {
      
      var envs = environments.join(',')

      $.getJSON('/api/releaseprep/prepare/' + release + '?' + $.param({environment: environments}, true) + 
       '&deploymentContextId=' + (deploymentContextId ? deploymentContextId : '') + 
       '&skipPropertiesCheck=' + skipPropertiesCheck + (revision?'&revision='+revision:''))
        .success(function(data){
          $('.lightbox-modal').removeClass('is-open')

          console.log(data)
          switch (data.step) {
            case 'SelectTargets':
              console.log('showing deployment targets lightbox')
              swift.sendToAddress('deploytargets', $('.lightbox-deploytargets .lightbox-content'), data, {release:release, deploymentContextId: deploymentContextId})
              break
            case 'Configure':
              // data.predeployRequest = predeployRequest            
              console.log('showing configuration lightbox')
              swift.sendToAddress('predeploy', $('.lightbox-predeploy .lightbox-content'), data, {release:release, deploymentContextId: deploymentContextId})
              break
            case 'Properties':
              console.log('navigating to properties screen')
              address('releaseproperties').param('org', org).param('environment', envs).param('release', release).param('revision', revision).param('deploymentContextId', deploymentContextId).view()
              break
            case 'Deploy':
              console.log('navigating to deploy screen')
              address('deploy').param('org', org).param('env', envs).param('release', release).param('revision', revision).param('deploymentContextId', deploymentContextId).view()
              break
            default:
              console.log('Unknown step ' + data.step)
          }
        })

    }

    function onContinuePredeploy(e, deploymentContextIdP) {
      if (deploymentContextIdP) {
        deploymentContextId = deploymentContextIdP
      }

      doJumpToNextStep()
    }

    return {
      jumpToNextStep: jumpToNextStep
    }

  }
)
