;define(
  [ 'jquery'
  , 'd3'
  , 'resourceful/address'
  , 'visualize/visualize'
  , '../../d3-lookup/lookup-multiple'
  , '../../utils/bootstrap'
  , 'log!swift/release/deploytargets'
  , 'css!../../global.css'
  , 'css!./styles.css'
  ], function($, d3, address, visualize, createLookupMultiple, swift, log) {

  'use strict'

  return function(){
    var $self = $(this)
      , release
      , deploymentContextId
      , env // current environment being configured
      , artifactLookupMap
      , applyToSelectedLookup
      , data
      , toggleCheckbox = swift.toggleCheckbox($self, '.js-instances :checkbox')
      , renderInstances = visualize.bind()
          .into('.js-instances')
          .each(function(artifact){
            $('.group-id', this).text(artifact.artifact.groupId)
            $('.artifact-id', this).text(artifact.artifact.artifactId)
            var targetLookup = createLookupMultiple()
              .label(function(d){ return d })
              .prompt('Enter selected deployment targets here..')
              .selected(artifact.instanceNames)
              .on('select', updateSelectAllDeploymentTags)
              .on('deselect', updateSelectAllDeploymentTags)

            d3.select($('.deployment-targets', this)[0]).datum(artifact.instanceNames).call(targetLookup)
            d3.select(this).datum(artifact)

            artifactLookupMap[artifact.artifact.artifactId] = targetLookup
          })

    $self.on('change', '.instances .include input', updateSelectAllDeploymentTags)
    $('.save-continue', $self).click(saveAndContinue)

    function updateSelectAllDeploymentTags() {
      // get all selected items and update the selected deployment tags list
      var allTags = $('.js-instances tr', $self).has(':checkbox:checked').map(function(e) {
        return d3.select(this).datum().instanceNames
      }).get()
      allTags = unique(allTags)
      log.debug(allTags)
      setSelectedItems(allTags)
    }
  
    function saveAndContinue() {
      log.info('save')

      data.stepData.targetedArtifactDeployments.forEach(function(targetDeployment) {
        var instanceLookup = artifactLookupMap[targetDeployment.artifact.artifactId]
        targetDeployment.instanceNames = instanceLookup.selected()
      })

      log.info(data)

      $.ajax({
        type: 'POST',
        url: '/api/releaseprep/prepare/' + release + '?deploymentContextId=' + (deploymentContextId ? deploymentContextId : ''),
        data: JSON.stringify(data.stepData),
        success: function(deploymentContextId){
          log.info(deploymentContextId)
          // trigger for the pre deployment checks to continue
          $self.trigger('continue-predeploy-checks', deploymentContextId)
        },
        dataType: 'json',
        contentType: 'application/json; charset=utf-8'
      })
    }

    function setSelectedItems(selectedArr) {
      applyToSelectedLookup.selected(selectedArr)

      d3.select($('.apply-to-selected', $self)[0]).datum(selectedArr).call(applyToSelectedLookup)  
    }

    function onSelectAllTagsAdded(added) {
      $('.js-instances tr', $self).has(':checkbox:checked').each(function(){
        var current = d3.select(this).datum().instanceNames
        var index = current.indexOf(added)
        if (index == -1) {
          current.push(added)
          setDeploymentTargets(this, current)
        }
      })
    }

    function onSelectAllTagsRemoved(removed) {
      $('.js-instances tr', $self).has(':checkbox:checked').each(function(){
        var current = d3.select(this).datum().instanceNames
        var index = current.indexOf(removed)
        if (index != -1) {
          current.splice(index, 1)
          setDeploymentTargets(this, current)
        }
      })
    }

    function setDeploymentTargets(targetTr, deploymentTargets) {
      var artifactId = d3.select(targetTr).datum().artifact.artifactId
      artifactLookupMap[artifactId].selected(deploymentTargets)

      d3.select(targetTr).select('.deployment-targets').datum(deploymentTargets).call(artifactLookupMap[artifactId]) 
    }

    return function(req) {
      artifactLookupMap = {}
      release = req.param('release')
      deploymentContextId = req.param('deploymentContextId')
      data = req.body

      // only one environment at a time will be returned for deployment targets.
      env = data.stepData.environment
      $('.deploy-step-title .environment', $self).text(env.toUpperCase())

      log.info('render items to be configured')
      log.info(data.stepData)

      renderInstances([])
      renderInstances(data.stepData.targetedArtifactDeployments)

      $self.closest('.lightbox-modal').addClass('is-open')

      applyToSelectedLookup = createLookupMultiple()
        .label(function(d){ return d })
        .prompt('Select artifacts to bulk update targets..')
        .on('select', onSelectAllTagsAdded)
        .on('deselect', onSelectAllTagsRemoved)
        
      updateSelectAllDeploymentTags()

      toggleCheckbox.recalculateToggleCtrlState()
    }
  }
})