define(
  [ "jquery"
  , 'd3' ],
    function($, d3) {

      var deploymentTypeMap = {
        "RollingUpgrade" : "Rolling Upgrade",
        "SequentialUpgrade" : "Sequential Upgrade",
        "Custom" : "Custom" }
   
      return { deploymentTypeMap : deploymentTypeMap }
    }
)
