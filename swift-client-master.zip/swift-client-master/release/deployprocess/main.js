;define(
  [ 'jquery'
  , 'visualize/visualize'
  , 'resourceful/address'
  , 'd3-draggable/draggable'
  , 'd3-draggable/droppable'
  , './util'
  , 'log!swift/release/deployprocess'
  , 'css!../../global.css'
  , 'css!./styles.css'
  ], function($, visualize, address, draggable, droppable, util, log) {

  'use strict'

  /**
   * Deployment templates are not rendered using visualize or the d3 enter / exit data selection events.
   * These are appropriate for lists / data where all items in the list are of the same type.  However,
   * within the deployment template there may be different template actions at the same level, requiring
   * a different custom renderer.  D3 is still used to bind the data to the element.
   */
  var CUSTOM = 'Custom'
    , self
    , release
    , clones = false
    , deploymentProcess
    , $horridDragNodeHack // TODO Only to remember which node was dragged.  Should be part of the drop event.
    , drag = draggable().ghostRenderer(function(node, e) {
          var $dragItem = $(node).closest('.placeholder')
          $horridDragNodeHack = $dragItem

          return d3.select('.view-deployprocess .template-group')
            .select(function () {return this.appendChild($dragItem[0].cloneNode(true))})
            .datum(d3.select(node).datum())
            .classed('draggable-ghost', true)
        })
        .ghostDx(-5)
        .ghostDy(-10)
        .isDraggable(function() {
          return getSelectedDeploymentProcess() == CUSTOM  && $(self).hasClass('editable')
        })
    , drop = droppable()
        .isDroppable(isDroppableTarget)
        .on('dragOver', function(e) {
          log.debug('dragging over ')
          log.debug(e)

          // Don't allow dropping within self (dragOver event is not filtered by isDroppable)
          if (!isDroppableTarget(e)) {
            removeDropPlaceholder()
            return
          }

          var $parentContainer = $(e.target).closest('.template-group')
          var $groupChildren = $parentContainer.find('.children-container').first()
          var childrenArr = $groupChildren.children()
          var insertPosition = -1;
          var placeholderPosition = -2;
          var parentParallel = isParallelContainer($parentContainer)

          for (var i = 0; i < childrenArr.length; i++) {
            // dropping into a parallel action always moves to the bottom.
            if (!parentParallel && insertPosition == -1 && $(childrenArr[i]).offset().top > e.y) {
              log.info('insert at position ' + i)
              insertPosition = i
            }
            if ($(childrenArr[i]).hasClass('drop-placeholder')) {
              placeholderPosition = i
            }
          }

          if (placeholderPosition != insertPosition) {
            log.info('reposition drop-placeholder to ' + insertPosition)
            removeDropPlaceholder()
            if (insertPosition == -1) {
              $groupChildren.append('<div class="drop-placeholder">insert here...</div>')
            } else {
              $('<div class="drop-placeholder">insert here...</div>').insertBefore($(childrenArr[insertPosition]))
            }
          }

        })
        .on('dragOut', function(e) {
          log.debug('dragout')
          removeDropPlaceholder()
        })
        .on('drop', function(e) {
          log.debug('droped on ' + e)

          if (!$horridDragNodeHack) return

          // TODO - update the underlying data model now or when save is clicked reconstruct a data model?
          var movedNode = removeActionFromTemplate($horridDragNodeHack)

          var insertPos = $('.view-deployprocess .template-group .drop-placeholder').index()

          var newParent = d3.select($('.view-deployprocess .template-group .drop-placeholder').closest('.template-group')[0]).datum()

          // insert into new home
          newParent.actions.splice(insertPos, 0, movedNode)

          $('.view-deployprocess .template-group .drop-placeholder').before($horridDragNodeHack)
          removeDropPlaceholder()

          $horridDragNodeHack = null
        })

  function removeActionFromTemplate($action) {
    var removedNodeData = d3.select($action[0]).datum()

    // remove from existing container
    var existingParent = d3.select($action.parents('.template-group')[0]).datum()
    removeFromArray(existingParent.actions, removedNodeData)

    $action.remove()

    return removedNodeData
  }

  function isDroppableTarget(e) {
    // if no drag no present, nothing to drop
    if (!$horridDragNodeHack) return false
    // Don't allow dropping within self or a child of self
    if (!($horridDragNodeHack.has(e.target).length == 0 && !$horridDragNodeHack.is(e.target))) return false
    // Don't allow reordering of parallel actions
    var $parentContainer = $(e.target).closest('.template-group')
    if (isParallelContainer($parentContainer)) {
      return $parentContainer.find('.children-container').first().has($horridDragNodeHack).length == 0
    }

    return true
  }

  function isParallelContainer($containerNode) {
    if ($containerNode[0]) {
      var data = d3.select($containerNode[0]).datum()
      return data && data.mode == 'PARALLEL'
    }
    return false
  }

  function removeDropPlaceholder() {
    $('.view-deployprocess .template-group .drop-placeholder').remove()
  }

  function removeFromArray(array, ele) {
    var index = array.indexOf(ele)
    array.splice(index, 1)
  }

  function renderAction(into, action) {
    var domNode
    var type = action['@class']
    if (type == 'com.ubs.f35.swift.deploy.template.model.TemplateGroupAction') {

      // This is a grouping container of other actions.
      domNode = clones.group.call(into, action)

      $('label', domNode).text(action.mode)

      var childContainer = $('.children-container', domNode)[0]

      action.actions.forEach(function(childAction){
        renderAction(childContainer, childAction)
      })

    } else if (type == 'com.ubs.f35.swift.deploy.template.model.TemplateArtifactAction') {

      domNode = clones.artifactAction.call(into, action)
      $('label', domNode).text(action.action + ' ' + action.artifactId)
      $('.children-container', domNode).text(action.mode)

    } else if (type == 'com.ubs.f35.swift.deploy.template.model.TemplateManualAction') {

      domNode = clones.artifactAction.call(into, action)
      $('label', domNode).text('Manual intervention - ' + action.title)
      $('.children-container', domNode).text(action.description)

    }

    d3.select(domNode).datum(action)
  }


  function renderSelectInput(items, selected, $target) {
    $target.html('')

    if (items) {
        items.forEach(function(d) {
            $('<option>')
                .val(d.id)
                .text(d.val)
                    .appendTo($target)
        })
    }

    $target.val(selected || '').selectinput('refresh')
  }

  function renderDeploymentTemplate(deploymentTemplate) {
    deploymentProcess = deploymentTemplate
    renderAction($('.template-holder', self).html('')[0], deploymentTemplate.action)

    // can drag anything, but can only drop into a group holder.
    d3.selectAll('.view-deployprocess .placeholder .header label').call(drag)
    d3.selectAll('.view-deployprocess .template-group').call(drop)
  }

  function setupListeners() {
    $('.save', self).click(onSaveClick)
    $('.preview', self).click(onPreviewClick)
    $('.addStep', self).click(onAddStepClick)
    $('.confirmAddStep', self).click(onAddStepConfirm)
    $('select.deploymentProcess', self).change(showDeploymentProcess)
    $('.step-choice', self).click(showStep)

    $(self).on('click', '.custom i.delete', onDeleteStepClick)
  }

  function showDeploymentProcess() {
    if (getSelectedDeploymentProcess() != CUSTOM)
      $.get('/api/releasetemplate/' + release + '/' + getSelectedDeploymentProcess())
        .done(renderDeploymentTemplate)

    handleCustomState()
  }

  function handleCustomState() {
    var custom = getSelectedDeploymentProcess() == CUSTOM
    $('.addStep', self).prop('disabled', !custom)
    $('.template-holder', self).toggleClass('custom', custom)
  }

  function onAddStepClick() {
    $('.lightbox-addStep').addClass('is-open')

    // clear existing user entries
    $('.lightbox-addStep input[type=text]').val('')
    $('.lightbox-addStep textarea').val('')
  }

  function onDeleteStepClick() {
    removeActionFromTemplate($(this).closest('.placeholder'))
  }

  function onPreviewClick() {
    alert('coming soon')
  }

  function getSelectedDeploymentProcess() {
    return $('select', self).val()
  }

  function onSaveClick() {
    var saveRequest = {deploymentProcess: getSelectedDeploymentProcess()}
    if (getSelectedDeploymentProcess() == CUSTOM) saveRequest.deploymentTemplate = deploymentProcess

    $.post('/api/release/deploymentProcess/' + release, JSON.stringify(saveRequest))
    .done(function(data) {
      $(document).trigger('inform.success', 'Deployment process saved successfully')
      $('.lightbox-deployprocess').removeClass('is-open')
      $(self).trigger('deployment-process-saved', data)
    })
  }

  function onAddStepConfirm() {
    var $selectedStep = $('.step-choice:not(.is-collapsed)')
      , actionType = $selectedStep.data('type')
      , action = { '@class': actionType }

    if (actionType == 'com.ubs.f35.swift.deploy.template.model.TemplateManualAction') {
      $.extend(action, { title: $('.lightbox-addStep input[name=title]').val(),
        description: $('.lightbox-addStep textarea[name=description]').val() })
    } else if (actionType == 'com.ubs.f35.swift.deploy.template.model.TemplateArtifactAction') {
      var artifact = $('.lightbox-addStep select[name=artifact]').val()
      action.groupId = artifact.split('/')[0]
      action.artifactId = artifact.split('/')[1]
      action.action = $('.lightbox-addStep select[name=action]').val()
      action.mode = $('.lightbox-addStep input[name=mode]:checked').val()
    }

    deploymentProcess.action.actions.push(action)

    renderDeploymentTemplate(deploymentProcess)

    $('.lightbox-addStep').removeClass('is-open')
  }

  function showStep() {
    $('.step-choice', self).not(this).addClass('is-collapsed')
  }

  function makeEditable(editable) {
    $(self).toggleClass('editable', editable)
    $('select.deploymentProcess', self).selectinput(editable ? 'enable' : 'disable')
  }

  return { send: send }

  function send() {
    self = this

    clones = (clones ? clones :
    {
      group: visualize.selector.appendClone(d3.select('.view-deployprocess .template-group').remove().node())
    , artifactAction: visualize.selector.appendClone(d3.select('.view-deployprocess .template-artifact-action').remove().node())
    })

    $('select', self).selectinput()

    var deploymentTypeOptions = $.map(util.deploymentTypeMap, function(val, key) {
      return {id: key, val: val}
    })
    renderSelectInput(deploymentTypeOptions, null, $('select.deploymentProcess', self))


    setupListeners()

    return function(req) {
      var releaseDef = req.body
      makeEditable(false)

      release = releaseDef.id
      $('select.deploymentProcess', self).val(releaseDef.deploymentProcess).selectinput('refresh')
      handleCustomState()

      var artifacts = releaseDef.artifacts.map(function (a){
        return { id: a.groupId + '/' + a.artifactId, val: a.artifactId }
      })

      renderSelectInput(artifacts, null, $('.lightbox-addStep select[name=artifact]', self))

      if (releaseDef.deploymentProcess == CUSTOM) {
        // clone the template so that if the user cancels no changes are made.
        var deploymentTemplate = jQuery.extend(true, {}, releaseDef.deploymentTemplate);
        renderDeploymentTemplate(deploymentTemplate)
      } else {
        showDeploymentProcess()
      }

      // screen will be disabled if 1. release is locked, 2. user is not entitled to edit
      if (!releaseDef.locked) {
        $.ajax('/api/auth?organisation=' + releaseDef.team.organisation.name)
            .done(function(data) {
              if (data.indexOf('release-create-modify') != -1) {
                makeEditable(true)
              }
            })
      }
    }

  }

})