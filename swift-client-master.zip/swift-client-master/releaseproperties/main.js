define(
  [
    'jquery'
  , 'd3'
  , 'resourceful/address'
  , 'grid/grid'
  , '../utils/bootstrap'
  , '../release/deploywizard'
  , 'css!grid/styles.css'
  , 'css!./styles.css'
  , 'css!../assets/swift-grid.css'
  ]
, function(
    $
  , d3
  , address
  , grid
  , swift
  , deployWizard  
  ) {

    'use strict'

    return function() {

      var self = this
        , columns = [
          {
            key: 'artifact'
          , headerRenderer:'<span>Artifact</span>'
          , width:'300px'
          , headerHeight: 40
          , accessor:function (data) {
              return function () {
                return data.artifact.artifactId
              }
            }
          },
          {
            key: 'version'
          , headerRenderer:'<span>Version</span>'
          , width:'100px'
          , headerHeight: 40
          , accessor:function (data) {
              return function () {
                return data.artifact.version
              }
            }
          }
        ]
      , org
      , release
      , revision
      , envs
      , deploymentContextId
      , artifactsGrid

      setupListeners()

      return {
        start: start
      , update: update
      , stop: stop
      }

      function start(){
        swift.start()
        $('body').css('overflow-y', 'scroll')
      }

      function stop(){
        swift.stop()
        $('body').css('overflow-y', 'initial')
      }

      function update(req) {
        swift.update(req)
        release = req.param('release')
        revision = req.param('revision')
        org = req.param('org')
        envs = req.param('environment').split(',')
        deploymentContextId = req.param('deploymentContextId')

        setupReleaseInfo()

        loadEnvironments(envs)
      }

      function loadEnvironments(environments) {
        $.getJSON(
            '/api/releaseprep/propertystatus/' + release + '/artifact?'
            + $.param({'environment':environments}, true) + (revision?'&revision='+revision:''))
          .done(function(r){
            var returnedEnvs = []
            // this release may not have any artifacts which require properties.
            if (r.length > 0) returnedEnvs = r[0].environmentPropertiesConfigured.map(function(e) { return e.environment })

            $('.artifacts-grid', self).toggleClass('is-hidden', r.length == 0)
            $('.no-artifacts-message', self).toggleClass('is-hidden', r.length != 0)

            buildGrid(returnedEnvs)

            // flatten the server side results to be more client friendly.
            r.forEach(function(record){
              record.environmentPropertiesConfigured.forEach(function(e) {
                record[e.environment] = e.propertiesSet
              })
            })
            artifactsGrid.data([]) // To hide columns when switching between views
            artifactsGrid.data(r)
          })
      }

      function buildGrid(environments) {
        var allColumns = [].concat(columns)

        environments.forEach(function(e){
          allColumns.push({
            key: e
          , headerRenderer: function() {
            d3.select(this).classed('environment', true).html('<span><a class="env-title" href="/swift/' + org + '/properties/' + e + '?' +
                $.param({ release: release, revision: revision, returnUrl: document.location.pathname + document.location.search }) +
                  '">'+e+'</a></span>')
          }
          , width:'50px'
          , headerHeight: 40
          , accessor:function (data) {
              return function () {
                return data
              }
            }
          , renderer: renderIfChanged(function (d) {
              if (d[e] != 'NotRequired') {
                var iconHtml = '<i class="' + (d[e] == 'Ready' ? 'neo-icon-tick' : 'neo-icon-warning') + ' icon-small" />'

                $(this)
                  .addClass('center')
                  .html('<a href="/swift/' + org + '/properties/' + e + '?'
                    + $.param({release: release,
                      revision: revision,
                      group: d.artifact.groupId,
                      artifact: d.artifact.artifactId,
                      version: d.artifact.version,
                      returnUrl: document.location.pathname + document.location.search}) +'">' + iconHtml + '</a>')
              }
            })
          })
        })

        artifactsGrid= grid()
          .columnsReordering(false)
          .columnsResizing(false)
          .fixedColumns(2)
          .rowHeight(35)
          .columns(allColumns)
          .node($('.artifacts-grid', this))

        d3.select('.artifacts-grid')
          .select('.datagrid-header')
      }

      function renderIfChanged(renderer, key) {
        return function () {
          var previous = {}
            , notChanged = function (data) {
              if (key !== undefined && data != undefined && previous != undefined) return (previous[key] === data[key])
              return previous === data
            }
          return function (data) {
            if (notChanged(data)) return
            renderer.apply(this, arguments)
            previous = data
          }
        }
      }

      function renderGrid(data) {
        releasesGrid.data(data)
      }

      function setupListeners() {
        $('.btn-selected-envs', self).on('click', function() { loadEnvironments(envs) })
        $('.btn-all-envs', self).on('click', function() { loadEnvironments([]) })

        $('.btn.deploy', self).on('click', onDeploy)
      }

      function setupReleaseInfo() {
        swift.render.releaseSummary(release, revision)
        swift.breadcrumbs.render([{"title":"Releases","url":"/swift/" + org + "/releases"}, {"handle":"release"}, {"title":"Manage Properties"}])

        $('.release-summary a', self).attr('href', '/swift/release/' + release + (revision?'?revision='+revision:''))
      }

      function onDeploy(){
        var data = artifactsGrid.data()

        // check if any of the deployment environments have artifacts which do not have saved properties
        var artifactWithoutProps = data.some(function(d) {
          return envs.some(function(e) {
            return d[e] != 'Ready' && d[e] != 'NotRequired'
          })
        })

        if(artifactWithoutProps){
          if (!confirm('There are artifacts with unsaved properties.' +
            '\nThese components may fail to start without configured properties.' +
            '\nAre you sure you want to continue?')) { return }
        }

        navigateToDeploy()
      }

      function navigateToDeploy() {
        // Next step in the deployment wizard.  Flag to skip the properties checks as the user is already on this screen.
        deployWizard.jumpToNextStep($(self), org, release, revision, envs, deploymentContextId, true)
      }
    }
  }
)