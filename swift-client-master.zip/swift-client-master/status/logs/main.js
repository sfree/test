;define(
  [ 'jquery'
  , 'resourceful/address'
  , 'visualize/visualize'
  , 'css!./styles.css'
  ], function($, address, visualize) {

    return function(){
      var dom = d3.select(this)
        , clone = visualize.selector.appendClone(dom.select('.log').remove().node())

      return {
        update: function(req) {
          dom
            .html('')
            .classed('loading', true)

          $.getJSON('/api/logs/dir?id='+req.param('id'))
            .always(function(){ 
              dom.classed('loading', false) 
            })
            .done(function(results) {
              var logsData = results.res || {}
              
              logsData = Object
                .keys(logsData)
                .map(function(e,i,a){
                  results.res[e].name = e
                  return results.res[e]
                })

              var logs = dom.html('')
                .selectAll('li')
                .data(logsData)

              logs.enter().select(clone)

              logs
                .select('.details')
                .text(function(d){ 
                  return Math.round(d.length*10/1024)/10 
                    + ' Kb | ' 
                    + moment(+d.lastModified).fromNow() 
                  })

              logs
                .select('.name')
                .text(function(d){ return d.name })
                .attr('target', '_blank')
                .attr('href', function(d){ 
                  return '/api/logs/file' 
                    + '?id=' + req.param('id') 
                    + '&logFile=' + d.canonicalPath
                    + '&maxLine=500'
                })

              logs.exit().remove()
            })
        }
      }
    }
})