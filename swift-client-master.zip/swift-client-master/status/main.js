define(
  [
    'jquery'
  , 'underscore/underscore'
  , 'visualize/visualize'
  , 'resourceful/address'
  , '../utils/streaming'
  , '../d3-lookup/lookup'
  , 'fuzzy-search/fuzzy'
  , 'log!swift/status'
  , '../utils/bootstrap'
  , '../properties/bulk/helper'
  , 'css!./styles.css'
  , 'css!../styles.css'
  ]
  , function(
    $
    , _
    , visualize
    , address
    , streamingUtil
    , createLookup
    , fuzzySearch
    , log
    , swift
    , bulkProp) {

    'use strict'

    return function() {

      var self = this
        , serviceRef
        , subscription
        , currentTopic
        , org
        , options = $('.side-panel .sub-title i').length
        , optionWidth = 319
        , filters = {}
        , sort = {}
        , selected = []
        , lastAjax
        , nodes = { filter: d3.select(".filter-container .swift-lookup") }
        , filterLookup = createLookup()
            .label(label)
            .drawDropdownSuggestion(drawDropdownSuggestion)
            .on('select', onLookupSelect)
            .on('input', sortFilterDatum)
            .prompt('Add Filter..')
            .allowFreeTextInput(false)
        , clones = {
            artifact: visualize.selector.appendClone(
              d3.select('.environments .artifact-row').remove().node())
          , environment: visualize.selector.appendClone(
              d3.select('.environments .environment').remove().node())
          , tag: visualize.selector.appendClone(
              d3.select('.side-panel li.tag').remove().node())
          , release: visualize.selector.appendClone(
              d3.select('.side-panel li.release').remove().node())
          , filter: visualize.selector.appendClone(
              d3.select('.filters .filter').remove().node())
          , action: visualize.selector.appendClone(
              d3.select('.running-actions .action').remove().node())
          }

      $('.filter-container form', self).submit(function(e){ e.preventDefault() })

      setupListeners()
      streamingUtil.initStreaming(streamingServiceCallback, onError)

      return {
        update: update
      , start: start
      , stop: stop
      }

      function streamingServiceCallback(service) {
        serviceRef = service
        subscribe()
      }

      function subscribe(topic) {
        if (topic)
          currentTopic = topic

        if (currentTopic && serviceRef) {
          subscription = serviceRef.subscribe('/status/' + currentTopic, function callback(frame) {
            onMessage(JSON.parse(frame.body))
          })
        }
      }

      function unsubscribe() {
        currentTopic = null
        if (subscription) {
          subscription.unsubscribe()
          subscription = null
        }
      }

      function update(req) {
        swift.update(req)

        org = req.param('org')

        // Load Options for Filter..
        $.getJSON('/api/status/lookup/' + org)
          .success(function(r) {
            nodes.filter
              .datum(r)
              .call(filterLookup)
          })

        // Get the sort params..
        sort.col = req.uri.query.col
        sort.dir = req.uri.query.dir=='true'
        delete req.uri.query.col
        delete req.uri.query.dir

        $('[data-sort='+sort.col+']')
          .addClass('sort')
          .toggleClass('desc', sort.dir)

        // Get the filters..
        filters = req.uri.query

        // Nest any multiple values under one key..
        Object.keys(filters).forEach(function(key){
          filters[key] = filters[key]
            ? unique(filters[key].split(","))
            : []
        })

        // Render Filters..
        renderFilters()

        // Render Environments..
        if(lastAjax) lastAjax.abort()
        // clear subscription
        unsubscribe()

        // only fetch status info if filters have been specifed.  Otherwise clear the data presented
        if (Object.keys(filters).length) {
          $('h2 i').addClass('loading')
          var urlParams = 'organisation=' + org + '&' + $.param($.extend(filters, sort), true)
          // update export link
          $('.export', self)
            .attr('href', '/api/status/export?' + urlParams)
            .removeClass('is-hidden')

          lastAjax = $.getJSON('/api/status?' + urlParams)
            .done(function(data){
              renderEnvironments(data);
              positionSidebar()
            })
            .always(function(){
              $('h2 i.loading').removeClass('loading')
            })

          // re-create subscriptions..
          subscribe(JSON.stringify({
              organisation: org
            , environments: filters.environment
            , groups: filters.group
            , artifacts: filters.artifact
            , agents: filters.host
            , tags: filters.tag
            , states: filters.state
            , statuses: filters.status
            }
          ))
        } else {
          $('.export', self)
            .addClass('is-hidden')

          renderEnvironments([])
        }

        swift.breadcrumbs.render([{"title":"Platform Status"}])
        filterLookup.focused(true)
      }

      function updateView(){
        // show-all filter is only allowed if ONE environment is selected.
        if (!filters['environment'] || filters['environment'].length != 1) delete filters['records']

        var joinedFilters = []
        Object.keys(filters).forEach(function(key){
          if (filters[key].length > 0) joinedFilters[key] = unique(filters[key]).join(",")
        })
        address('status')
          .param($.extend(joinedFilters, sort, {org: org}))
          .view()
      }

      function renderFilters(){
        var flattenedFilters = []
        Object.keys(filters).forEach(function(key){
          filters[key].forEach(function(value){
            if (key != 'records') flattenedFilters.push({ type: key, value: value })
          })
        })

        var node = d3.select('.filters').selectAll('.filter').data(flattenedFilters, function(d) { return d.type+d.value })
        ,   enter = node.enter().select(clones.filter)
        ,   changed = node.select(visualize.selector.dataChanged())

        changed.text(function(d) { return prettifyText(d.value, d.type) })
          .attr('data-filter-type', function(d) { return d.type })
          .attr('data-filter-value', function(d) { return d.value })
          .attr('title', function(d) { return 'Click to remove ' + d.type + ' filter ' + d.value })

        node.exit().remove()
      }

      function getStateIcon(d) {
        if (d.tags && d.tags.indexOf('cold-standby') != -1 && d.state.state == 'OK') {
          return 'COLD-OK'
        }
        return d.state.state
      }

      function renderArtifacts(into, data, environment) {
        // Bind Data, Create Selections..
        var node = d3.select(into).selectAll('.artifact-row').data(data, function(d){ return d.id }).order()
        ,   enter = node.enter().select(clones.artifact)
        ,   changed = node.select(visualize.selector.dataChanged())

        changed.attr('data-id', function(d){ return d.id })

        // State..
        changed.select('i.status')
          .attr('data-state', getStateIcon)
          .attr('data-content', function(d) { return d.state.state })
          .attr('title', function(d) { return d.state.status + ((d.state.statusInfos.length >0 && d.state.statusInfos.join() != d.state.status)? '\n' + d.state.statusInfos.join('\n'):'') })

        // Version..
        changed.select('.version span')
          .text(function(d) { return d.artifact.version })
          .attr('data-content', function(d) { return d.artifact.version })

        // Group..
        changed.select('.group a')
          .text(function(d) { return prettifyText(d.artifact.groupId, 'group') })
          .attr('data-content', function(d) { return d.artifact.groupId })

        // Artifact..
        changed.select('.artifact a')
          .text(function(d) { return d.artifact.artifactId + (d.name ? ' (' + d.name + ')' : '') })
          .attr('data-content', function(d) { return d.artifact.artifactId })

        // Server
        changed.select('.host a')
          .text(function(d) { return d.agent })
          .attr('data-content', function(d) { return d.agent })

        // Exit..
        node.exit()
          .remove()
      }

      function renderEnvironments(data, updateSidePanelDetails){
        // Bind Environments, keyed by name..
        var node = d3.select('.environments').selectAll('.environment').data(data, function(d) { return d.environment })
        ,   enter = node.enter().select(clones.environment)

        // Update Environment..
        node.select('h4 a')
          .filter(function(d,i) { return d3.select(this).attr('data-content') != d.environment || d3.select(this).attr('data-length') != d.artifacts.length } )
          .text(function(d){ return d.environment.toUpperCase() })
          .attr('data-length', function(d){ return d.artifacts.totalRecords })
          .attr('data-shown', function(d){ return (d.artifacts.totalRecords != d.artifacts.pageResults.length ? d.artifacts.pageResults.length + ' of ' : '') })
          .attr('data-content', function(d){ return d.environment } )

        node.select('.show-all').classed('is-hidden', function (d) { return d.artifacts.totalRecords == d.artifacts.pageResults.length })

        // Remove Environments..
        node.exit()
          .remove()

        // Render the Artifacts for each environment..
        node.each(function(d) {
          renderArtifacts(this, d.artifacts.pageResults, d.environment)
        })

        // update the selected map so that only items which are still present can be selected.
        var displayedIds = {}
        data.forEach(function(env) {
          env.artifacts.pageResults.forEach(function(artifact){
            displayedIds[artifact.id] = true
          })
        })
        var selectedBefore = selected.length
        selected = selected.filter(function(id) { return displayedIds[id] })

        // Only update the side panel if the number of selected records has changed or the subscription update message is for the currently selected record
        if (selectedBefore != selected.length || updateSidePanelDetails) updateSidePanel()

      }

      function prettifyText(data,type){
        switch(type){
          case 'group': {
            var label = (data || '')
            if (label.indexOf('com.ubs.') == 0) label = label.split('com.ubs.')[1]
            return label
          }
          case 'environment': return (data || '').toUpperCase()
          default: return data
        }
      }

      function updateSidePanel() {
        var title = d3.select('.side-panel h4.above-border')
          , $sidePanel = $(self).find('.side-panel')

        var content = d3.select('.side-panel')
          .classed('multiple', selected.length > 1)
          .select('.content')
          .classed('unselected', selected.length == 0)

        if (selected.length == 0) {
          title.text("Select an artifact")
          return
        }

        if (selected.length != 1) {
          title.text(" (" + selected.length + " selected instances)")
          title.attr('title', '')
          $sidePanel.find('.actions button').removeClass('is-disabled')

          // if multiple selection, only batch actions is supported.
          selectSidePanel($('.side-panel .sub-title i.actions'))
          return
        }

        var data = d3.select('[data-id="'+selected[0]+'"]').datum()

        title.text(data.artifact.artifactId + (data.name ? ' (' + data.name + ')' : '') + ' (' + data.agent + ')')
        title.attr('title', prettifyText(data.environment, 'environment') + '\n' + data.agent + '\n' + data.artifact.artifactId)

        // Logs..
        address('logs')
          .param('id', data.id)
          .view(content.select('.logs').node())

        // Artifact deployment history..
        address('deployhistory')
          .param('artifactInstanceId', data.id)
          .view(content.select('.deployment-history').node())

        // Releases..
        content.select('.releases').html('').classed('loading', true)
        $.getJSON('/api/release?group='+ data.artifact.groupId +'&artifact=' + data.artifact.artifactId + '&organisation=' + org)
          .always(function(){ content.select('.releases').classed('loading', false) })
          .done(function(data) {
            var releases = content.select('.releases')
              .selectAll('li')
              .data(data.pageResults)

            releases.enter().select(clones.release)
            releases.select('.details').text(function(d){
              return d.team.name + ' | ' + moment(+d.lastUpdatedTime).fromNow() })
            releases.select('.name').text(function(d){ return d.name })
              .attr('href', function(d){ return '/swift/release/' + d.id })
            releases.exit().remove()
          })

        // Actions..
        var $actions = $sidePanel.find('.actions')
        $actions.find('button').addClass('is-disabled')
        $.getJSON('/api/status/actions?id=' + data.id)
          .done(function (actions) {
            actions.forEach(function (action) {
              $actions.find('[data-action=' + action.toLowerCase() + ']').removeClass('is-disabled')
            })
          })
        $actions.find('.artifact-status-state').attr('data-state', getStateIcon(data))
        $actions.find('.artifact-status-name').text(data.state.status)
        $actions.find('.artifact-status-message').html(data.state.statusInfos.join('<br/>'))
        $actions.find('.artifact-state-change').text(!data.state.stateLastModified ? '' : 'State last changed ' + moment(+data.state.stateLastModified).format('HH:mm on MMM-DD-YYYY'))

        // Links..
        $sidePanel.find('.properties')
          .attr('href', function(d) { return '/swift/' + org + '/properties/' + data.environment + '?group=' + data.artifact.groupId + '&artifact=' + data.artifact.artifactId + '&version=' + data.artifact.version })
        $sidePanel.find('.artifact-config')
          .attr('href', function(d) { return '/swift/' + org + '/config/artifact/' + data.artifact.groupId + '/' + data.artifact.artifactId })

        // Artifact Config..
        var contentConfig =  $sidePanel.find(' div.config').addClass('loading')
        $.getJSON('/api/config/artifact/' + org + '/' + data.environment + '/' + data.artifact.groupId + '/' + data.artifact.artifactId + '/' + (data.name || 'DEFAULT'))
          .always(function(){ contentConfig.removeClass('loading') })
          .done(function(config){
            address('configdetails')
              .header('accept', ['application/view', 'text/html'])
              .header('target', contentConfig)
              .send(config)
          })
      }

      function positionSidebar () {
        var section = $('.view-status > section')
        if (section && section.offset()) {
          $('.side-panel').css('top', Math.max(section.offset().top - $(window).scrollTop(), 0) + 'px')
          $('.side-panel').css('left', (section.offset().left + section.outerWidth()) + 'px')
        }
      }

      function selectSidePanel($panel) {
        if (!$panel.is('is-selected')) {
          $('.side-panel .sub-title i').removeClass('is-selected')
          $panel.addClass('is-selected')
          var index = $panel.index() - options
          $('.side-panel .content').css('margin-left', index*optionWidth+'px')
          $('.side-panel .sub-title span').text($panel.attr('title'))
        }
      }

      function setupListeners(){
        $(window).on('scroll'  , positionSidebar)
        $(window).on('resize'  , positionSidebar)
        $(self).on('click'     , '[data-filter]', onAddFilter)
        $(self).on('mouseenter', '.artifact-row [data-filter]', onFilterMouseEnter)
        $(self).on('mouseout'  , '.artifact-row [data-filter]', onFilterMouseExit)
        $(self).on('click'     , '.filter', onRemoveFilter)
        $(self).on('click'     , '.artifact-row', onSelectArtifact)
        $(self).on('click'     , '.select-all', onSelectAll)
        $(self).on('click'     , '.show-all', onShowAll)
        $(self).on('click'     , '[data-sort]', onSort)
        $(self).on('click'     , '.side-panel .sub-title i', onChangeSidePanel)
        $(self).on('click'     , '[data-action]:not(.is-disabled)', onExecuteAction)
        $(self).on('click'     , '.bulk-property:not(.is-disabled)', onInitiateBulkPropertiesUpdate)
        $(self).on('click'     , '.side-panel .jmx', openJMXConsole)
        $(self).on('click'     , '.btn.commence', onDeployClick)
      }

      // start a deployment
      function onDeployClick() {
        $('.deployment-plan-container', self).trigger('start-deployment')
      }
      // Open JMX Console..
      function openJMXConsole(){
        var data = d3.select('[data-id="'+selected[0]+'"]').datum()

        $.getJSON('/api/status/jmx?id='+data.id)
          .done(function(jmxLink){
            console.log(jmxLink)
            if (jmxLink)
              window.open(jmxLink, '_blank')
            else
              $(document).trigger('inform.error', 'No JMX link available')
          })
      }

      // Filter Link Clicked..
      function onAddFilter(e){
        var filterType = $(this).attr('data-filter')
        filters[filterType] = filters[filterType] || []
        filters[filterType].push($(this).attr('data-content'))
        updateView()
        e.stopPropagation()
      }

      function onFilterMouseEnter(e){
         $(this).closest('.artifact-row').addClass('filter-hover')
      }

      function onFilterMouseExit(e){
         $(this).closest('.artifact-row').removeClass('filter-hover')
      }

      // Filter Clicked? Remove it..
      function onRemoveFilter(e){
        var candidate = $(this).attr('data-filter-value')
        var filterType = $(this).attr('data-filter-type')
        var removeIndex = filters[filterType].indexOf( candidate )
        if (removeIndex != -1) {
          filters[filterType].splice(removeIndex, 1);
          updateView()
        }
      }

      // Select an Artifact..
      function onSelectArtifact(e) {
        var clickedRowId = $(this).attr('data-id')
        // Multiple-Select
        if (event.ctrlKey) {
          if ($(this).is('.is-selected')) {
            // remove from selection
            selected.splice(selected.indexOf(clickedRowId), 1)
          } else {
            selected.push(clickedRowId)
          }

          $(this).toggleClass('is-selected')
        } else {
          $('.artifact-row.is-selected').removeClass('is-selected')

          $(this).addClass('is-selected')
          selected = [clickedRowId]
        }

        updateSidePanel()
      }

      // select all
      function onSelectAll(e){
        $('.artifact-row.is-selected').removeClass('is-selected')

        var containerEnv = $(this).closest('.environment')
        $('.artifact-row', containerEnv).addClass('is-selected')
        selected = $('.artifact-row', containerEnv).map(function(i, e) { return $(e).attr('data-id') }).get()

        updateSidePanel()
      }

      // show all
      function onShowAll(e){
        var containerEnv = $(this).closest('.environment')
        ,   environment = d3.select(containerEnv.get(0)).datum().environment

        // show all for only this environment
        filters['environment'] = [environment]
        filters['records'] = [-1]
        updateView()
      }

      // Change Side Panel..
      function onChangeSidePanel(){
        selectSidePanel($(this))
      }

      // Sort..
      function onSort(){
        $('.sort').removeClass('sort')
        var $this = $(this).addClass('sort')

        sort.col = $this.attr('data-sort')
        sort.dir = ($this.toggleClass("desc"), $this.hasClass("desc"))

        updateView()
      }

      function onExecuteAction() {
        presentDeploymentPlan($(this).text(), false);
      }

      function presentDeploymentPlan(deploymentAction, includeDependencies) {
        log.info("Loading deployment plan for selected actions")

        log.debug(selected)

        // Note that the existing node is removed so that resourceful renders the
        // deployment plan from scratch rather than attempting to reuse the dom.
        $('.view-status .lightbox-plan-target')
          .html('')
          .append($('<div></div>'))
        $('.view-status .lightbox-plan')
          .addClass('loading')
        $('.view-status .lightbox-plan #btnDeploy')
          .text('Execute')
          .attr("class", "btn commence")
        $('.view-status .lightbox-deploy')
          .addClass('is-open')

        $.ajax({
            type: 'POST',
            url: "/api/deployment/process?deploymentAction="
            + deploymentAction
            + "&includeDependencies=" + includeDependencies,
            data: JSON.stringify(selected)
          })
          .done(function(plan){
            log.debug(plan)

            var $deployTarget = $('.view-status .lightbox-plan-target div')

            address("deployexecute")
              .header("accept", ["application/view", "text/html"])
              .header("target", $deployTarget.get(0))
              .send(plan)

            $deployTarget.on('deployment-loaded', function() { $('.view-status .lightbox-plan').removeClass('loading') })

            $deployTarget.on('deployment-generate-with-deps', function() { presentDeploymentPlan(deploymentAction, true) })
          })
          .fail(function(){
            $('.view-status .lightbox-deploy').removeClass('is-open')
          })

      }

      function onInitiateBulkPropertiesUpdate() {
        bulkProp.initiateBulkUpdate({'@type' : 'instance-selection', 'artifactInstanceIds': selected})
      }

      function onMessage(changed){
        var env
          , data = d3.select('.environments').selectAll('.environment').data()
          , some  = data.some(function(e, i){
            return (e.environment == changed.environment ? (env = i, true) : false)
          })

        if (!some && !changed.hide) {
          data.push({ artifacts: {totalRecords: 0, pageResults:[]}, environment: changed.environment})
          env = data.length - 1
        }

        var found

        if (typeof env !== 'undefined') {
          found = data[env].artifacts.pageResults.some(function(artifact, i) {
            if (artifact.id == changed.id) {
              if (changed.hide) {
                data[env].artifacts.totalRecords -= 1
                data[env].artifacts.pageResults.splice(i, 1)
                if(!data[env].artifacts.pageResults.length) data.splice(env, 1)
              } else {
                data[env].artifacts.pageResults[i] = changed
              }
              return true
            }
          })
        }

        if (!found && !changed.hide) {
          // Only add the update into the collection if the client is not currently filtering the maximum number of results.
          var maxRecords = filters['records']
          if (!maxRecords) maxRecords = 100
          else maxRecords = +maxRecords

          if (maxRecords == -1 || data[env].artifacts.pageResults.length < maxRecords) {
            data[env].artifacts.totalRecords += 1
            data[env].artifacts.pageResults.push(changed)

            found = true
          }
        }

        // only trigger rerender if a change was made
        if (found) {
          var updateSidePanelDetails = selected.length == 1 && selected[0] == changed.id

          renderEnvironments(data, updateSidePanelDetails)
        }
      }

      function onError(e) {
        $(document).trigger(
          'inform.error'
        , 'Cannot connect to service. Please re-try.'
        )
      }

      function label(d) {
        return d.entry
      }

      function drawDropdownSuggestion(d, i) {
        var q = filterLookup.query()
          , f = fuzzySearch().query(q)

        d3.select(this)
          .html('<span class="sub pull-right">'
            + d.type
            + '</span>'
            + f.format(d.entry))
      }

      function onLookupSelect(d){
        filters[d.type] = filters[d.type] || []
        filters[d.type].push(d.entry)
        filterLookup.query('').call(nodes.filter)
        updateView()
      }

      function sortFilterDatum() {
        var query = filterLookup.query()
          , compare = function (a, b) {
            return d3.ascending(
              _.levenshtein(query, a.entry),
              _.levenshtein(query, b.entry)
            )
          }

        nodes.filter.datum().sort(compare)
      }

      function start() {
        $('html').addClass('swift-ux');
        positionSidebar();
        updateSidePanel()
      }

      function stop() {
        $('html').removeClass('swift-ux')
        unsubscribe()
        swift.breadcrumbs.stop()
      }
    }
  }
)
