define(
	[ "jquery"
	, "visualize/visualize"
	, "resourceful/address"
	, "../utils/bootstrap"
	, "css!../styles.css"
	, "css!./styles.css"
	], function($, visualize, address) {

	return function(req) {
		var renderReleases = visualize.bind()
			.into(".team-feed")
			.within(this)
			.each(function(d, i){
				var el = d3.select(this)
				el.transition()
					.duration(550)
					.delay(i*30)
					.style("opacity", 1)

				$(".id", this).text(d.id)
				$(".team", this).text(d.team)
				$(".name", this).text(d.name)
					.attr("href", "/swift/release/" + d.id)

				address("users")
					.param({"guid": d.createdBy})
					.view($("figure", this)[0])
				
				address("users")
					.param({"guid": d.createdBy})
					.view($(".author", this).css("color", "black")[0])

				$("time", this).text(moment(+d.lastUpdatedTime).fromNow())
				
				$("summary",this)
					.text(marked(d.description || "") || 'No description')
			})


		var updateReleases = function() {
			$.ajax({
				url: "/api/release?team=" + req.param("team")
			}).done(function(data){
				console.log(data.pageResults)
				renderReleases(data.pageResults)
			})
		}

		$("h2", this).text(req.param("team"))
		updateReleases()
	}
})
