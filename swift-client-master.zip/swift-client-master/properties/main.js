define(
  [
    "jquery"
  , "d3"
  , "resourceful/address"
  , "visualize/visualize"
  , "../utils/bootstrap"
  , "../artifactlist/artifact-type"
  , "./property-utils"
  , 'grid/grid'
  , 'css!grid/styles.css'
  , "css!./styles.css"
  ], function($, d3, address, visualize, swift, artifactType, propertyUtils, grid) {

    'use strict'

    return function() {
      var self = this
        , release
        , allReleaseArtifacts
        , url
        , returnUrl // if specified, return to this url after saving.
        , revision
        , org
        , env
        , groupId
        , artifactId
        , grouped = true
        , initialRender = true
        , defaults = []
        , $currentArtifact
        , clones = {
            property: $('.property', self).remove().get(0)
          , category: $('.properties-category', self).remove().get(0)
          , artifact: $('.artifact', self).remove().get(0) }
        , renderArtifacts = visualize.bind()
            .prototype(clones.artifact)
            .key(function(d){ var a = d.artifact; return a.groupId + a.artifactId + a.version })
            .each(renderArtifactsChange)
        , renderPropertyCategories = visualize.bind()
            .prototype(clones.category)
            .added(renderPropertyCategoriesAdd)
            .changed(renderPropertyCategoriesChange)
        , renderProperties = visualize.bind()
            .prototype(clones.property)
            .key(function(d){ return d.key })
            .changed(renderPropertiesChange)
            .removed(renderPropertiesRemove)
        , titles =
            {
            'NEW':
              {
                title: 'New properties'
              , 'default': ''
              }
          , 'PREVIOUS':
              {
                title: 'Properties seeded from previous version'
              , 'default': 'is-collapsed'
              }
          , 'REMOVED':
              {
                title: 'Properties removed in this version'
              , 'default': 'is-collapsed'
              }
          , 'ADDED':
              {
                title: 'Properties added in this version'
              , 'default': 'is-collapsed'
              }
          , 'MODIFIED':
              {
                title: 'Properties modified in this version'
              , 'default': 'is-collapsed'
              }
          , 'UNMODIFIED':
              {
                title: 'Properties unmodified from previous version'
              , 'default': 'is-collapsed'
              }
          , 'ALL':
              {
                title: 'All properties'
              , 'default': ''
              }
          }

      return {
          start: start
        , update: update
        , stop: stop
        }

      function update(req) {
        allReleaseArtifacts = req.param("artifact") == null

        swift.update(req)

        returnUrl = req.param("returnUrl") ? decodeURIComponent(req.param("returnUrl")) : null

        release = req.param("release")
        revision = req.param("revision")
        org = req.param("org")
        env = req.param("env")
        groupId = req.param("group")
        artifactId = req.param("artifact")
        url = allReleaseArtifacts
          ? "/api/properties/release/" + env + "/" + release + "?revision=" + revision
          : "/api/properties/" + org + "/" + env + "/" + groupId + "/" + artifactId + "/" + req.param("version") + "?suggest=true"

        swift.breadcrumbs.render([{"title":"Artifacts"}, {"title":artifactId, "url":"../config/artifact/"+groupId+"/"+artifactId}, {"title":"Properties"}, {"title":env.toUpperCase()}])
        $('.grouped-toggle input', this).attr('disabled', true)
        $.getJSON(url)
          .success(function(data){
            d3.select(self)
              .select('.artifacts')
              .datum(allReleaseArtifacts ? data : [data])
              .call(renderArtifacts)
            initialRender = false
            $(".save").removeClass("is-disabled")
          })
          .complete(function(data){
            $(".artifacts", self).removeClass("loading")
            $('.grouped-toggle input', self).removeAttr('disabled');
          })

        $('.environment', this).text(env)
        $('.grouped-toggle input', this).prop('checked', grouped)

        setupReleaseInfo()
        setupListeners()
        fetchDefaults()
      }

      function setupReleaseInfo(){
        if (!release) return;

        $(self).attr('data-release', 'true')
        swift.render.releaseSummary(release, revision)
        swift.breadcrumbs.render([{"title":"Releases","url":"/swift/" + org + "/releases"}, {"handle":"release"}, {"title":"Manage Properties", "url": returnUrl}, {"title":"Properties"}])
      }

      function fetchDefaults(){
        $.getJSON('/api/properties/defaults/' + org + '/' + env)
           .done(function(data){ defaults = data })
      }

      function getDefault(key){
        var defaultValue = null
        defaults.some(function(d){
          if(d.key == key){ defaultValue = d.value; return true }
          return false
        })
        return defaultValue
      }

      function renderArtifactsChange(d, i) {
        swift.transitions.flip(this)
        var artifact = d.artifact
        $('.name', this).text(artifact.artifactId)
        $('.group', this).text(artifact.groupId)
        $('.version', this).text(artifact.version)
        artifactType(d3.select(this).select('i.icon'), d.artifactType)

        if(d.saved) {
          // Seed version only selectable for unsaved artifact properties
          $(this).addClass('saved')
          if (initialRender && allReleaseArtifacts && grouped) $(this).addClass('is-collapsed')
          $('.seed', this).html(d.seedVersion)
        } else {
          var seedVersion = (d.seedVersion || '')
          $('select', this)
            .append('<option value="'+seedVersion+'">'+seedVersion+'</option>')
            .attr('data-source'
              , '/api/lookup/versions/'
              + artifact.groupId
              + '/'
              + artifact.artifactId)
              .selectinput()
        }

        if(d.warning && d.warning != '') {
          $('.config-warning', this).removeClass('is-hidden')
          $('.config-warning li', this).html(d.warning)
        }

        nestAndRenderCategories(d.properties, this)
      }

      function renderPropertyCategoriesAdd(d, i) {
        $(this).addClass(titles[d.key] && titles[d.key]['default'])
      }

      function renderPropertyCategoriesChange(d, i) {
        $('h4', this).text(titles[d.key] && titles[d.key].title)
        $('detail', this).text(d.values.length)
        $(this).attr('data-category', d.key)
        if(!grouped) $(this).removeClass('is-collapsed')

        d.values.sort(function compare(a,b) {
          if (a.key < b.key) return -1
          if (a.key > b.key) return 1
          return 0; })
        d3.select(this)
          .select('.children-container')
          .datum(d.values)
          .call(renderProperties)
      }

      function getDefaultSourceText(d) {
        return d.defaultType == 'TEMPLATE' ? 'artifact template' : (env + ' environment')
      }

      function renderPropertiesChange(d, i) {
        var $propertyValue = $(this).find('[name="property[value]"]')
          , $warningIcon = $('.small-icon', this)
        $('.key', this).text(d.key).attr('title', grouped ? d.key : d.key + ' (' + (d.suggestion || d.difference) + ')')
        // Using a flyout to present the tooltip.
        $('.prop-key', this).text(d.key)
        $propertyValue.val(d.value)
        $warningIcon.removeClass('info-low warning').attr('title','') //Reset
        $(this).attr('data-flag', (d.suggestion || d.difference))

        if(d.defaultValue){
          if(d.suggestion == 'NEW' && (!d.value || d.value == '' || d.value == d.defaultValue)){
            // Suggest value from defaults
            $propertyValue.val(d.defaultValue)
            $warningIcon
              .addClass('info-low')
              .attr('data-class', 'info-low')
              .attr('title','Value suggested from ' + getDefaultSourceText(d) + ' defaults')
          } else if(d.difference != 'REMOVED' && d.value != d.defaultValue) {
            // Warn that value differs from defaults
            $warningIcon
              .addClass('warning')
              .attr('data-class', 'warning')
              .attr('title','Value differs from the ' + getDefaultSourceText(d) + ' default of ' + d.defaultValue)
          }

          $warningIcon.attr('data-title', $warningIcon.attr('title'))
        }

        renderWhitespaceWarning($propertyValue)

        if(d.difference == 'MODIFIED') $propertyValue.attr('title', 'Previous value: ' + d.previousValue)
        if(d.difference == 'REMOVED')  $propertyValue.val(d.previousValue)

        $propertyValue.prop('disabled', $(this).attr('data-flag') == 'REMOVED');
        setCheckbox($(':checkbox', this), $propertyValue, d)

        if (d.lastAdded){
          // If new property added using Add button, draw focus to it so value can be inputted:
          $(this).closest('.properties-category').toggleClass('is-collapsed', false)
          $propertyValue.focus();
          setTimeout(function(){ $propertyValue.get(0).scrollIntoViewIfNeeded()}, 200)
          d.lastAdded = false
        }

        $propertyValue.css('height', computeTextAreaHeight)

        $('.neo-icon-information', this).toggleClass('is-hidden', !d.documentation)
        $('.key-information', this).text(d.documentation)
      }

      function renderPropertiesRemove(){
        $(this).remove()
      }

      function onSeedChange(){
        var self = $(this).closest(".artifact").get(0)
          , artifact = d3.select(self).datum().artifact

        $('.seed-loading', self).addClass('loading')
        $('input, textarea', self).prop('disabled', true);

        $.getJSON(
            "/api/properties/"
          + org + "/"
          + env + "/"
          + artifact.groupId + "/"
          + artifact.artifactId + "/"
          + artifact.version + "?prevVersion="
          + this.value
          + "&suggest=true")
          .success(function(d) {
            $('input, textarea', self).prop('disabled', false);
            nestAndRenderCategories(d.properties, self)
            d3.select(self).datum().properties = d.properties //TODO: work out why this is necessary. If you leave it out, after saving, and then adding/removing a property, all the "new" suggestions reappear.

          })
          .complete(function() {
            $('.seed-loading', self).removeClass('loading')
          })
      }

      function onImport(){
        var properties = []
          , oldProperties = d3.select($currentArtifact.get(0))
              .datum()
              .properties
          , replaceAll = $('[name=importType]:checked').val()=='replace'
          , props = propertyUtils.parse($('.lightbox-copy textarea').val(), {keepLineBreak: true})

        Object.keys(props)
          .forEach(function(key){
            var value = props[key]
              , matched = oldProperties.filter(function(d){
                  return d.key == key
                })

              // The following logic sets the suggestion or difference flag on the property so it shows up in the correct category;
              // matched[0] is a pre-existing property with the same key, if it exists.
              , suggestion = matched[0] && matched[0].suggestion != 'REMOVED' && matched[0].suggestion  // Property was already suggested, retain in the category it was already in ('NEW' or 'PREVIOUS')
                            || matched[0] && matched[0].suggestion == 'REMOVED' && 'PREVIOUS'           // Property was previously 'REMOVED' - now it's being imported move it to 'PREVIOUS'
                            || matched[0] && matched[0].difference && null                              // Property was already saved so is not a suggestion
                            || !matched[0] && 'NEW'                                                     // Property is entirely new
              , difference = matched[0] && matched[0].difference != 'REMOVED' && matched[0].difference  // Property was already here, retain in the category it was already in
                            || matched[0] && matched[0].difference == 'REMOVED' && matched[0].previousValue == value && 'UNMODIFIED' // Property was previously 'REMOVED' - new value is the same as previous so use category 'UNMODIFIED'
                            || matched[0] && matched[0].difference == 'REMOVED' && matched[0].previousValue != value && 'MODIFIED' // Property was previously 'REMOVED' - new value differs from previous so use category 'MODIFIED'
                            || null                                                                     // Property was not previously saved
              , defaultValue = matched[0] && matched[0].defaultValue || getDefault(key)
              , previousValue = matched[0] && matched[0].previousValue || null

            properties.push({
                key: key
              , value: value
              , defaultValue: defaultValue
              , previousValue: previousValue
              , suggestion: suggestion
              , difference: difference
              , imported: true
            })
          })

          if(!replaceAll){
            oldProperties.forEach(function(old){
              var matched = properties.some(function(d){
                return d.key == old.key
              })
              if(!matched) properties.push(old)
            })
          }

          $('#importTypeModify').prop('checked', true)

          d3.select($currentArtifact.get(0)).datum().properties = properties
          nestAndRenderCategories(properties, $currentArtifact.get(0))
      }

      function onExport(){
        $currentArtifact = $(this).closest('.artifact')

        var properties = $currentArtifact
            .find('.property')
            .filter(isNotRemovedProperty)
            .map(propertyElementToJavaProperty)
            .toArray()
            .join('\n')

        $('.lightbox-copy textarea').val(properties)
        $('.lightbox-copy').addClass('is-open')

        function isNotRemovedProperty(){
          var data = d3.select(this).datum()
          return data.difference != 'REMOVED' && data.suggestion != 'REMOVED'
        }
      }

      function propertyElementToJavaProperty(){
        var property = ''
          , propertyName = $('.key input', this).val() || $('.key', this).text()
          , propertyValue =  $('[name="property[value]"]', this).val().replace(/\n/g, '\\\n') || $('.value', this).text()

        property += propertyName + '=' + propertyValue

        return property
      }

      function onAdd(){
        var artifact = $(this).closest('.artifact').get(0)
          , properties = d3.select(artifact)
              .datum()
              .properties

        propertyUtils.promptForNewProperty(properties, function(key) {
            properties.push({
              key: key
            , value: ''
            , defaultValue: getDefault(key)
            , suggestion: 'NEW'
            , customAdded: true
            , lastAdded: true
            })

            nestAndRenderCategories(properties, artifact)          
        })
      }

      function onDelete(e){
        var artifact = $(this).closest('.artifact').get(0)
          , index
          , key = $(this).closest('.property').find('.key').text()
          , properties = d3.select(artifact)
              .datum()
              .properties

          properties.some(function(d, i){
            return d.key == key && (index = i, true)
          })
          properties.splice(index, 1)

        nestAndRenderCategories(properties, artifact)
        e.stopPropagation()
      }

      function artifactWhitespaceWarning(artifact) {
        return artifact.properties.filter(function(prop) { return startsOrEndsWithWhitespace(prop.value) })
      }

      function onSave(){
        var $thisBtn = $(this)
          , saveAndContinue = $thisBtn.hasClass("save-all")
          , multiArtifactSave = saveAndContinue && allReleaseArtifacts

        // This controls the scope of the area that input text will be disabled on save.
        if (!saveAndContinue) $currentArtifact = $thisBtn.closest('.artifact')
        else $currentArtifact = self

        var update
          , whitespaceWarning
        if (multiArtifactSave) {
          update = $(".artifact").map(function() { return buildSaveObject(this) }).toArray()
          whitespaceWarning = update.reduce(function(result, artifact) {
            return result.concat(artifactWhitespaceWarning(artifact))
          }, [])
        } else {
          update = buildSaveObject($currentArtifact)
          whitespaceWarning = artifactWhitespaceWarning(update)
        }

        if (whitespaceWarning.length != 0) {
          var message = 'The following properties have leading or trailing whitespace.  This is often a problem.\n'
          whitespaceWarning.forEach(function(prop) { message += ' - ' + prop.key + '\n' })
          message += 'Are you sure you wish to save?'
          if (!confirm(message)) {
            return
          }
        }

        swift.executeAjax($thisBtn, $currentArtifact, function() {

          return $.ajax({
            type: 'PUT',
            url: multiArtifactSave ? url : '/api/properties/' + org + '/' + env,
            data: JSON.stringify(update)
          })
          .done(function(data){
            if (saveAndContinue) { navigateToReleaseProperties() }
            else {
              replaceArtifactData(data, d3.select('.artifacts').datum())
              d3.select('.artifacts').call(renderArtifacts)
            }
            $(document).trigger("inform.success", "Properties saved")
          })
        })

      }

      function replaceArtifactData(newData, data){
        data.some(function(el, index, array){
          var newArtifact = newData.artifact
          var oldArtifact = el.artifact
          if(oldArtifact.groupId == newArtifact.groupId
            && oldArtifact.artifactId == newArtifact.artifactId
            && oldArtifact.version == newArtifact.version){
              data.splice(index, 1, newData)
              return true
          }
        })
      }

      function buildSaveObject(artifact){
        var obj = {}

        obj.artifact = {
          artifactId: $(".name", artifact).text(),
          groupId:    $(".group", artifact).text(),
          version:    $(".version", artifact).text()
        }

        obj.properties = []
        $(".property", artifact).each(function(j){
          var $propertyValue =  $('[name="property[value]"]', this)
          if ($(this).attr('data-flag') != 'REMOVED' && ($propertyValue.val().length || $(':checked', this).length)) {
            obj.properties.push({
                key: $(".key", this).text()
              , value: $propertyValue.val()
            })
          }
        })

        obj.seedVersion = $(".seed select", artifact).length? $(".seed select", artifact).val() : ''
        return obj
      }

      function onKeyUp() {
        var $input = $(this)
          , $property = $input.closest('.property')

        setCheckbox($(':checkbox', $property), $input, d3.select($property.get(0)).datum())
        renderWhitespaceWarning($input)
      }

      function renderWhitespaceWarning($input) {
        var whitespaceWarning = startsOrEndsWithWhitespace($input.val())
          , $property = $input.closest('.property')
          , $warningIcon = $('.small-icon', $property)

        if (whitespaceWarning) {
          $warningIcon
            .removeClass('info-low')
            .addClass('warning')
            .attr('title', 'Value has leading or trailing whitespace\n' + ($warningIcon.attr('data-title') || ''))
        } else {
          // reset to original warnings from server
          $warningIcon
            .removeClass('warning')
            .addClass($warningIcon.attr('data-class'))
            .attr('title', $warningIcon.attr('data-title'))
        }
      }

      function onRestoreRemoved(){
        var property = $(this).closest('.property')
        property.attr('data-flag', 'PREVIOUS')
        $('[name="property[value]"]', property).prop('disabled', false);
      }

      function onGroupedToggle(){
        grouped = $('.grouped-toggle input').is(":checked")

        d3.select('.artifacts')
          .selectAll('.property')[0]
          .map (function(p){
            d3.select(p).datum().value = $('[name="property[value]"]', p).val()
          })

        d3.select('.artifacts').call(renderArtifacts)
      }


      function getArtifactData($node) {
        var artifactNode = $node.closest(".artifact").get(0)

        return d3.select(artifactNode).datum().artifact
      }

      function userRenderer(guid) {
        $(this).html('<span class="user-profile-container"></span>')
        address('users')
          .param({'guid': guid })
          .view($('.user-profile-container', this).get(0))
      }

      function valueRenderer (value) {
        $(this).html('<span class="history-value">')
        $('.history-value', this).text(value).attr('title', value)
      }

      function onPropertyKeyFlyout(e, flyout) {

        var $gridContainer = $('.grid-container', flyout.$content)
        if($gridContainer.hasClass('is-hidden')) renderHistory()

        function renderHistory() {
          var $gridNode = $('.audit-grid', $gridContainer)
            , artifact = getArtifactData(flyout.$content)
            , key = d3.select(flyout.$element.closest('.property')[0]).datum().key
            , columns =
              [
                {key: 'value', headerRenderer: 'Value', renderer: valueRenderer, width: '400px' },
                {key: 'version', headerRenderer: 'Version', width: '75px'},
                {key: 'Time', headerRenderer: 'Time',  accessor: function(data) { return function() { return moment(+data.swiftRevEntry.timestamp).format('HH:mm on MMM-DD-YYYY') } }, width: '150px'},
                {key: 'User', headerRenderer: 'User', renderer: userRenderer, accessor: function(data) { return function() { return data.swiftRevEntry.user } }, width: '150px'}
              ]
            , auditGrid = grid()
              .columnsReordering(false)
              .columns(columns)
              .node($gridNode)

          $gridContainer.removeClass('is-hidden')

          $.getJSON(
              '/api/properties/history/key/'
            + org + "/"
            + env + "/"
            + artifact.groupId + "/"
            + artifact.artifactId + "/"
            + key)
            .success(function(d) {
              auditGrid.data(d)
            })
            .complete(function() {
              $gridContainer.removeClass('loading')
            })
        }
      }

      function navToStatus(){
        address('status')
          .param('org', org)
          .param('environment', env)
          .param('artifact', artifactId)
          .view()
      }

      function setupListeners(){
        $(self).on('click', '.return', navigateToReleaseProperties)
        $(self).on("change", ".seed select", onSeedChange)
        $(self).on("click" , ".seed *"     , stopPropagation)
        $(self).on("click" , ".artifact.collapsible > .header", stopPropagationIfNotRelease)
        $(self).on("click" , ".import"     , onImport)
        $(self).on("click" , ".export"     , onExport)
        $(self).on("click" , ".add"        , onAdd)
        $(self).on("click" , ".delete"     , onDelete)
        $(self).on("click" , ".save"       , onSave)
        $(self).on("click" , ".live-status", navToStatus)
        $(self).on("keyup" , '[name="property[value]"]', onKeyUp)
        $(self).on("click" , ".restore a"  , onRestoreRemoved)
        $(self).on("change" , ".grouped-toggle input", onGroupedToggle)
        $(self).on('show', '.flyout-trigger', onPropertyKeyFlyout)
      }

      function navigateToReleaseProperties() {
        address(returnUrl).view()
      }

      function nestAndRenderCategories(properties, artifact){
        var categories = d3.nest()
          .key(grouped? nestGroup : nestAll)
          .entries(properties)

        d3.select(artifact)
          .select('.properties-categories')
          .datum(categories)
          .call(renderPropertyCategories)
      }

      function nestGroup(d) { return (d.suggestion || d.difference) }
      function nestAll(d) { return 'ALL' }

      function setCheckbox(checkBox, valueField, data){
        if(data.suggestion && !valueField.val().length){
          // Only show checkbox for suggested properties and where the value is currently blank
          checkBox.removeClass('invisible')
          checkBox.attr('checked', (data.suggestion != 'NEW' || data.customAdded || data.imported))
        } else {
          checkBox.attr('checked', true).addClass('invisible')
        }
      }

      function computeTextAreaHeight(){
         var $this = $(this)
           , lineHeight = parseFloat($this.css('line-height'))
           , numberOfLines =  $this.val().split('\n').length

        return numberOfLines > 1 ? (numberOfLines * lineHeight) + 'px' : undefined
      }

      function startsOrEndsWithWhitespace(text) {
        return text && (text.match(/^\s/) || text.match(/\s$/))
      }

      function stopPropagationIfNotRelease(e){
        if(!release) e.stopPropagation()
      }

      function stopPropagation(e){
        e.stopPropagation()
      }

      function start() {
        $('html').addClass('swift-ux')
      }

      function stop() {
        $('html').removeClass('swift-ux')
        swift.breadcrumbs.stop()
      }
    }
  }
)
