;define(
  [
    'jquery'
  , 'resourceful/address'
  ]
  , function($, address) {

    'use strict'

    /**
     * Helper to initiate the transition to the bulk update screen.
     */

    // Expose Global API..
    return {
      initiateBulkUpdate: initiateBulkUpdate
    }

    function initiateBulkUpdate(selection) {
      $.post('/api/properties/register-bulk-update', JSON.stringify(selection))
        .done(function(bulkUploadId) {
          address('bulkproperties')
            .param('bulkUploadId', bulkUploadId)
            .view()
        })
    }
  }
)
