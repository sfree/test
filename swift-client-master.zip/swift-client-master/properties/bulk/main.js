define(
  [
    'jquery'
  , 'resourceful/address'
  , 'grid/grid'    
  , '../../utils/bootstrap'
  , '../property-utils'
  , 'log!swift/properties/bulk'
  , 'css!grid/styles.css'
  , 'css!./styles.css'
  ], function($, address, grid, swift, propertyUtils, log) {

    'use strict'

    return function() {
      var self = this
        , org
        , env
        , properties
        , propGrid
        , renderedArtifacts
        , selected
        , postUpdate = false
        , columns = [
            {
              key: 'include'
            , headerRenderer:'Include'
            , width:'75px'
            , renderer: checkboxRenderer('include', function(include) {
                $('input', this).prop('checked', include)
              })
            },
            {
              key: 'key'
            , headerRenderer:'Property'
            , width:'400px'
            },
            {
              key: 'value'
            , headerRenderer:'Value'
            , width:'400px'
            , renderer: propertyValueRenderer()
            },
            {
              key: 'blank'
            , headerRenderer:'Save blank'
            , width:'75px'
            , renderer: checkboxRenderer('blank', function(data) {                
                $('input', this)
                  .toggleClass('invisible', !data.include)
                  .prop('checked', data.value == '')
              })
            , accessor: rawData
            }
          ]

      function rawData(d) { 
        return function() { 
          return d 
        } 
      } 

      setupListeners()

      return {
          start: start
        , update: update
        , send: update
        , stop: stop
      }

      function update(req) {
        log.info('bulk update of properties')
        log.info(req)

        var bulkUploadId = req.param('bulkUploadId')

        $.getJSON('/api/properties/initiate-bulk-update/' + bulkUploadId)
          .done(function(result){            
            env = result.environment.name
            org = result.environment.organisation.name
            selected = result.selection
            swift.updateOrg(org)
            swift.breadcrumbs.render([{'title':'Artifacts'}, {'title':'Bulk Properties'}, {'title': env.toUpperCase()}])
            properties = result.properties
            log.debug(properties)

            propGrid.data(properties)

            renderArtifacts(result.artifacts, false)

            $('.loading', self).removeClass('loading')
          })
      }

      function renderArtifacts(artifacts, showStatus) {
        renderedArtifacts = artifacts
        swift.sendToAddress('artifactlist', $('.artifacts-container', self),
          {artifacts: artifacts, showVersions: true, showStatus: showStatus, org : org, readOnly: true})
      }

      function start() {
        $('html').addClass('swift-ux')

        propGrid = grid()
          .columnsReordering(false)
          .columnsResizing(false)
          .dataKey('key')
          .rowHeight(50)
          .columns(columns)
          .node($('.properties-grid', this))        
      }

      function stop() {
        $('html').removeClass('swift-ux')
        swift.breadcrumbs.stop()
      }

      function checkboxRenderer(addClass, postCreate) {
        return function(data) {
          $(this).html('<input type="checkbox"/>')
          $('input', this).addClass(addClass).prop('disabled', postUpdate)

          postCreate.call(this, data)
        }
      }

      function propertyValueRenderer() {
        return function(data) {
          $(this).html('<textarea/>')
          $('textarea', this).val(data).prop('disabled', postUpdate)
        }
      }

      function onAdd() {
        updatePropertiesData()

        propertyUtils.promptForNewProperty(properties, function(key) {
          properties.push({
              key: key
            , value: ''
            , include: true
          })

          propGrid.data(properties)
        })
      }

      function updatePropertiesData() {
        var newProperties = []

        $('.datagrid-row', self).each(function(){
          newProperties.push({
              include: $('.include', this).is(':checked')
            , key: $('.col-1', this).text()
            , value: $('textarea', this).val()
            , saveBlank: $('.blank', this).is(':checked')
          })
        })

        properties = newProperties
      }

      function onSave() {
        updatePropertiesData()

        var updatedProperties = $.grep(properties, function(prop) { return prop.include })
        var update = $.map(updatedProperties, function(property){
          return {
              key: property.key
            , value: property.value
            , saveBlank: property.saveBlank
          }
        })

        var request = { 
            selection: selected
          , propertyUpdates: update}

        // disable the entire screen.
        swift.executeAjax($(this), $(self), function() {
          return $.ajax({
              type: 'POST',
              url: '/api/properties/bulk-update',
              data: JSON.stringify(request)
            })
            .done(function(result) {
              log.info('Bulk update completed')
              log.info(result)

              postUpdate = true
              $(self).addClass('post-update')

              var failure = exists(result, function(artifactUpdateResult) {
                return artifactUpdateResult.status != 'SUCCESS'
              })

              if (failure) {
                $(document).trigger('inform.error', 'Bulk update failed.  Please review the results.')
                $('h1 .status').text('- Failure')
              } else {
                $(document).trigger('inform.success', 'Bulk update completed.')
                $('h1 .status').text('- Success')
              }

              // Strip out properties from grid which were not updated.
              propGrid.data(updatedProperties)

              // Flatten results for the artifact grid.
              var artifacts = result.map(function(update) {
                var error = update.message || ''
                return $.extend(update.artifact, {status: update.status + ' ' + error })
              })

              renderArtifacts(artifacts, true)
            })        
        })
      }

      // TODO use underscore or something else?
      function exists(array, predicate) {
        for (var item in array) {
          if (predicate(array[item])) return true
        }
        return false
      }

      function onValueChanged() {
        $(this).closest('.datagrid-row').find('.include').prop('checked', true)
        onPropertySelected.call(this)
      }

      function onPropertySelected() {
        var $propRow = $(this).closest('.datagrid-row')
        // TODO duplication of properties screen logic
        var data = $('textarea', $propRow).val()
        $propRow.find('.blank')
          .toggleClass('invisible', data != '')
          .prop('checked', data == '')
      }

      function navToStatus(){
        var artifacts = renderedArtifacts
          .map(function(d){
            return d.artifactId
          })
          .join(',')

        address('status')
          .param('org', org)
          .param('environment', env)
          .param('artifact', artifacts)
          .view()
      }

      function setupListeners() {
        $(self).on('click' , '.add', onAdd)
        $(self).on('click' , '.live-status', navToStatus)
        $(self).on('keyup', 'textarea', onValueChanged)
        $(self).on('change', 'input.include', onPropertySelected)
        $(self).on('click' , '.save', onSave)
      }

    }
  }
)
