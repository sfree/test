define(
  [
    'jquery'
  , 'resourceful/address'
  , 'grid/grid'
  , 'grid-plugins/sorting'
  , '../../utils/bootstrap'
  , '../bulk/helper'
  , '../../artifactlist/artifact-type'
  , 'log!swift/properties/search'
  , 'css!grid/styles.css'
  , 'css!./styles.css'
  ], function($, address, grid, sorting, swift, bulkProp, artifactType, log) {

    'use strict'

    return function() {
      var self = this
        , org
        , $environmentsContainer = $('.environments-container', self)
        , renderedArtifacts
        , columns =
          [
            {key: 'artifactId', headerRenderer: 'Artifact Name', renderer: artifactCellRenderer, accessor: rawData, headerHeight : 35, width: '225px', sortDirection:'asc', sortPriority:1, sortFunction: sort(artifact)},
            {key: 'groupId', headerRenderer: 'Group', renderer: cellRenderer, width: '175px'},
            {key: 'version', headerRenderer: 'Version', renderer: cellRenderer, width: '75px'},
            {key: 'key', headerRenderer: 'Key', renderer: cellRenderer, width: '300px'},
            {key: 'value', headerRenderer: 'Value', renderer: cellRenderer, width: '300px'}
          ]
        , artifactGridNode = $('.artifact-grid', this)
        , artifactGrid = grid()
            .register(sorting)
            .rowHeight(55)
            .columns(columns)
            .node(artifactGridNode)

      function rawData(d) { 
        return function() { 
          return d 
        } 
      }

      function sort(extract) {
        return function(a,b) {
          return extract(a).localeCompare(extract(b))
        }
      }

      function artifact(d) {
        return d.artifactId
      }

      setupListeners()

      return {
          start: start
        , update: update
        , stop: stop
        }

      function update(req) {
        swift.update(req)
        org = req.param('org')

        swift.breadcrumbs.render([{'title':'Property Search'}])

        address('environments')
          .param('org', org)
          .view($environmentsContainer.get(0))

        $('.search-results', self).addClass('is-hidden')
      }

      function renderArtifacts(artifacts) {
        artifactGrid.data(artifacts)

        $('.search-results', self).toggleClass('empty', artifacts.length == 0)
      }

      function start() {
        $('html').addClass('swift-ux')
      }

      function stop() {
        $('html').removeClass('swift-ux')
        swift.breadcrumbs.stop()
      }

      function onValueChanged() {
        $(this).closest('.datagrid-row').find('.include').prop('checked', true)
        // TODO duplication of properties screen logic
        var data = $(this).val()
        $(this).closest('.datagrid-row').find('.blank')
          .toggleClass('invisible', data != '')
          .prop('checked', data == '')
      }

      function onSearch(){
        var env = getEnv()
          , searchUrl = '/api/properties/search/' + org + '/' + env + '?' +
              $.param({ propertyKey: $('.property-key', self).val(), propertyValue: $('.property-value', self).val()})

        $('.search-results', self).removeClass('is-hidden').addClass('loading')

        renderArtifacts([])

        // disable the entire screen.
        swift.executeAjax($(this), $(self), function() {
          return $.getJSON(searchUrl)
            .success(function(result) {
              log.info('Property search completed')
              log.info(result)

              renderedArtifacts = result.map(function(item) { return item.artifact })

              // Flatten results for the artifact grid.
              result.forEach(function(d){
                $.extend(d, d.artifact)
              })

              renderArtifacts(result)
            })
            .always(function() { $('.search-results', self).removeClass('loading') })
        })
      }

      function getEnv() {
        // TODO Nasty - knows the internals of another component
        return $('select', self).val()
      }

      function onBulkUpdate() {
        var artifacts = renderedArtifacts.map(function(a){
          var copy = $.extend({}, a)
          delete copy.artifactType
          return copy
        })
        bulkProp.initiateBulkUpdate({'@type' : 'artifact-selection', 'environment': getEnv(), 'organisation': org, artifacts: artifacts})
      }

      function setupListeners() {
        $(self).on('click' , '.prop-search', onSearch)
        $(self).on('click' , '.bulk-update', onBulkUpdate)
      }

      function artifactCellRenderer(d) {
        var s = d3.select(this).html('<i class="icon artifact-type"></i><a class="truncated"></a>')

        artifactType(s.select('i.icon'), d.artifactType)
        s.select('a')
          .text(d.artifactId)
          .attr('title', d.artifactId)
          .attr('href','/swift/' + org + '/properties/' + getEnv() + '?group=' + d.groupId + '&artifact=' + d.artifactId + '&version=' + d.version)
      }

      function cellRenderer(data) {
        d3.select(this).html('<span class="truncated"></span>')
          .select('span')
          .text(data)
          .attr('title', data)
      }

    }
  }
)
