define(
  [
    'jquery'
  , 'd3'
  , 'moment'
  , 'resourceful/address'
  , 'grid/grid'
  , 'grid-plugins/sorting'
  , '../d3-lookup/lookup-multiple'
  , 'fuzzy-search/fuzzy'
  , '../utils/bootstrap'
  , '../utils/chart'
  , 'underscore/underscore'
  , '../utils/crossfilter'
  , 'css!grid/styles.css'
  , 'css!./styles.css'
  , 'css!../assets/swift-grid.css'
  ]
, function(
    $
  , d3
  , moment
  , address
  , grid
  , sorting
  , createLookup
  , fuzzySearch
  , swift
  , barChart
  , _
  ) {

    'use strict'

    return function() {

      var self = this
        , DATE_FORMAT = 'YYYY-MM-DD' // note that IE11 will fail to parse dates in format 'YYYY-M-D'
        , org
        , headerInitialOffsetTop
        , filters = {
            team: []
          , artifact: []
          , group: []
          , name: ''
        }
        , dimension = {}
        , grouping = {}
        , columns = [
          {
            key: 'locked'
          , width: '24px'
          , headerRenderer: ''
          , headerHeight : 35
          , renderer: renderIfChanged(function (d) { d3.select(this).html('<i/>').select('i').classed('locked', d) })
          }
        , {
            key: 'release'
          , width: '200px'
          , headerRenderer: '<span>Name</span>'
          , accessor: function (data) {
              return function () {
                return { id: data.id, name: data.name }
              }
            }
          , renderer: renderIfChanged(function (d) { d3.select(this).html('<a href="/swift/release/'+d.id+'">'+d.name+'</a>') }, 'id')
          }
        , {
            key: 'team'
          , width: '100px'
          , headerRenderer: '<span>Team</span>'
          , renderer: renderIfChanged(function (d) { d3.select(this).html('<a href="/swift/team/'+d.name+'">'+d.name+'</a>') })
          }
        , {
            key: 'releaseDate'
          , width: '110px'
          , headerRenderer: '<span>Release Date</span>'
          , renderer: renderIfChanged(function (d) {
              var beforeToday = (new Date(+d)) < (new Date())
              d3.select(this)
                .text(+d
                  ? moment.utc(+d).format('DD-MMM-YYYY')
                  : 'None')
              d3.select(this.parentNode)
                .classed('sub', beforeToday)
                .selectAll('a')
                .classed('sub', beforeToday)
            })
          }
        ]
      , group = {
          children: function (d, data) {
            if (d == data) {
              return d3.nest()
                .key(function (d) {
                  return +d.releaseDate
                    ? moment(d.releaseDate).format('MMMM, YYYY')
                    : 'No Release Date'
                })
                .entries(data)
            }

            return d.values
          }
        , renderer: function (row) {
            d3.select(this).html('').append('h3').text(row.data.key)
          }
        }
      , releasesGrid
      , startDate
      , endDate
      , maxRecords = 1000
      , filterLookup = createLookup()
          .label(label)
          .on('select', onUpdateFilters)
          .on('deselect', onUpdateFilters)
          .allowFreeTextInput(true)
          .drawDropdownSuggestion(drawDropdownSuggestion)
          .drawEmptyResults(Function())
          .drawLozenge(drawLozenge)
      , releases = {}
      , release
      , chart
      , buffer
      , minCreated
      , maxCreated
      , pendingRequests = []
      , uri

      swift.breadcrumbs.render([{'title':'Releases'}])

      setupListeners()

      return {
        start: start
      , update: update
      , stop: stop
      }

      function start(){
        swift.start()
        $('body').css('overflow-y', 'scroll')
      }

      function stop(){
        swift.stop()
        abortPendingRequests()
        $('body').css('overflow-y', 'initial')
      }

      function renderGrid(data) {
        if (!releasesGrid.element()) {
          d3.select('.releases-grid')
            .datum(data.concat(data).concat(data)) // TODO - Why concat data twice?
            .call(releasesGrid)
            .select('.datagrid-header')
        }
        releasesGrid.data(data)

        // Filtering of grid may affect scroll position.
        onWindowScroll()
      }

      function renderPeriod(){
        var allDates = (startDate.toString() == endDate.toString())
        $('.period-title', self).text(allDates
          ? "All Dates"
          : startDate.format('DD MMM, YYYY')
            + ' - '
            + endDate.format('DD MMM, YYYY')
          )
        $('.prev, .next').attr('disabled', allDates)
      }

      function setupListeners() {
        $('.period-controls .btn', self).on('click', onNextPrevPeriod)
        $('.select-all', self).on('click', onSelectAll)
        $(window).scroll(onWindowScroll)
      }

      function onWindowScroll() {
        var scrollTop = document.documentElement.scrollTop || document.body.scrollTop
          , $gridHeader = $('.releases-grid .datagrid-header')

        if (!headerInitialOffsetTop) headerInitialOffsetTop = $gridHeader.offset().top

        $gridHeader.toggleClass('fixed-header', scrollTop > headerInitialOffsetTop)
      }

      function onSelectAll(){
        chart.filter(null)
        startDate = endDate
        renderAll()
      }

      function onUpdateFilters(d) {
        address('releases')
          .param($.extend(applyFilters(), {org : org}))
          .view()
      }

      function onNextPrevPeriod(){
        if($(this).hasClass('prev')){
          var oldStartDate = startDate
          startDate = moment(startDate - (endDate - startDate))
          endDate = oldStartDate
          chart.filter([startDate.toDate(), endDate.toDate()])
        } else if($(this).hasClass('next')) {
          var oldEndDate = endDate
          endDate = moment(endDate + (endDate - startDate))
          startDate = oldEndDate
          chart.filter([startDate.toDate(), endDate.toDate()])
        } else {
          resetDates()
        }

        onUpdateFilters()
      }

      // the artifact dimension cannot be manipulated client-side
      // so this has to be done on the server
      // server should be fixed at some point..
      function searchByArtifacts(artifactFilters){
        if (d3.event && d3.event.type == 'brush') return;

        filterLookup
          .loading(true)
          .call(d3.select(self).select('.swift-lookup'))

        $.getJSON(
              '/api/release/statuses?'
            + 'records=' + maxRecords
            + '&organisation=' + org
            + '&ordering=RELEASE_DATE&'
            + $.param({'artifact':artifactFilters}, true))
          .done(function(r){
            filterLookup
              .loading(false)
              .call(d3.select(self).select('.swift-lookup'))
            r.pageResults.forEach(appendRelease)
            parseReleases()
            r.pageResults.forEach(tagArtifacts)
            initCrossfilter()

            initChart()
            applyFilters()
            renderAll()
          })
      }

      function loadReleases(filters) {
        if (d3.event && d3.event.type == 'brush') return;

        var filters = {
          startDate: startDate.format(DATE_FORMAT)
        , endDate:   endDate.format(DATE_FORMAT)
        , name:      filterLookup.selected().filter(onlyName)
        , team:      filterLookup.selected().filter(name).map(name)
        }

        if ((startDate.toString() == endDate.toString())) {
          delete filters.startDate
          delete filters.endDate
        }

        getJSON(
          '/api/release/statuses?'
          + 'records=' + maxRecords
          + '&organisation=' + org
          + '&ordering=RELEASE_DATE&'
          + $.param(filters, true))
          .done(function (r) {
            if ($('body').css('cursor') == 'crosshair') return;
            r.pageResults.forEach(appendRelease)
            localStorage.releases = JSON.stringify(releases)
            parseReleases()
            initCrossfilter()
            initChart()
            applyFilters()
            renderAll()
          })
      }

      function tagArtifacts (release) {
        var id = release.releaseDefinition.id
        releases[id].artifacts = 1
      }

      function appendRelease(release){
        var id = release.releaseDefinition.id
        releases[id] = release.releaseDefinition
        release.deploymentSummaries.forEach(function(env){
          releases[id][env.environment] = env
        })
      }

      function applyFilters () {
        var allDates = (startDate.toString() == endDate.toString())

        if (dimension.created.filterRange()){
          startDate = moment(dimension.created.filterRange()[0])
          endDate = moment(dimension.created.filterRange()[1])
        }

        chart.filter(allDates
          ? null
          : [startDate.toDate(), endDate.toDate()])

        var teamFilters = filterLookup
              .selected()
              .filter(function(d){
                return d.name
              })
          , nameFilters = filterLookup
              .selected()
              .filter(function(d){
                return !d.name && !d.artifactId
              })
          , artifactFilters = filterLookup
              .selected()
              .filter(function(d){
                return d.artifactId
              })

        dimension.team.filter(function(d){
          return !teamFilters.length ? true : teamFilters
            .some(function(filter){
              return d == filter.name
            })
        })

        dimension.artifacts.filter(function(d){
          return !artifactFilters.length ? true : d
        })

        dimension.name.filter(function(d){
          return !nameFilters.length ? true : nameFilters
            .some(function(filter){
              return d.contains(filter)
            })
        })

        var params = {
          'startDate' : startDate.format(DATE_FORMAT)
        , 'endDate'   : endDate.format(DATE_FORMAT)
        , 'team'      : unique(teamFilters.map(name)).join(',')
        , 'name'      : unique(nameFilters).join(',')
        , 'artifact'  : unique(artifactFilters.map(label)).join(',')
        }

        return params
      }

      function loadAllReleases(){
        if (!localStorage.releases)
          getJSON(
            '/api/release/statuses?'
              + 'records=' + maxRecords
              + '&organisation=' + org
              + '&ordering=RELEASE_DATE')
            .done(function (data) {
              releases = {}
              data.pageResults.forEach(appendRelease)
              localStorage.releases = JSON.stringify(releases)
              done()
            })
        else {
          releases = JSON.parse(localStorage.releases)
          done()
        }

        function done(){
          parseReleases()
          initCrossfilter()
          findRange()
          initChart()
          resetDates()
          // TODO WTF is this for?  Are we already not on this screen?
          address(uri).view()
        }
      }

      function parseReleases () {
        releases = JSON.parse(localStorage.releases)
        Object
          .keys(releases)
          .forEach(function(id){
            releases[id].artifacts = null
            releases[id].releaseDate = releases[id].releaseDate
              ? new Date(releases[id].releaseDate)
              : new Date(0)
          })
      }

      function loadEnvironments() {
        // Get a list of all Environments..
        $.getWithCache('/api/config/' + org + '/environments')
          .done(function(d){
            d.forEach(function(e){
              columns.push({
                key: e
              , headerRenderer:'<span class="env-title">'+e+'</span>'
              , width:'35px'
              , headerHeight: 50
              , renderer: renderIfChanged(function (d) {
                  d3.select(this)
                    .attr('data-status', d && d.status)
                    .attr('title', d && d.status)
                },'status')
              })
            })

            buildGrid()
            loadAllReleases()
          })
      }

      function setupFilterLookup(){
        var options = []

        $.getJSON('/api/lookup/artifacts/' + org).done(updateLookup)
        $.getJSON('/api/teams?organisation=' + org).done(updateLookup)

        function updateLookup(r){
          options = options.concat(r)
          d3.select(self)
            .select('.swift-lookup')
            .datum(options)
            .call(filterLookup)
        }
      }

      function buildGrid(){
        releasesGrid = grid()
          .columnsReordering(false)
          .columnsResizing(false)
          .fixedColumns(4)
          .rowHeight(35)
          .columns(columns)
          .group(group)
      }

      function resetDates(){
        startDate = moment()
          .subtract('weeks', 1)
          .startOf('month')

        var lastDate = chart.x().domain()[1]
          , threeMonths = startDate.clone()
              .add('months', 2)
              .endOf('month')
              .toDate()

        endDate = moment(lastDate < threeMonths ? lastDate : threeMonths)
        chart.filter([startDate.toDate(), endDate.toDate()])
      }

      function update(req) {
        swift.update(req)

        uri = req.uri

        var initialRender = columns.length == 4
          , orgChanged = req.param('org') != org
        org = req.param('org')
        if (orgChanged) {
          localStorage.removeItem('releases')

          loadEnvironments()
          setupFilterLookup()
        }

        // if there are only 4 columns, this is the initial render.  If there are more than 4 columns, 
        // then the environments have bee added to the grid and rendering should complete.
        if (!initialRender) {
          var filters = req.param()
          if (filters.startdate && filters.enddate) {
            startDate = moment(filters.startdate)
            endDate = moment(filters.enddate)
          }

          var selected = []
          if (filters.team) {
            selected = selected.concat(filters.team.split(',').map(function(d){
              return { name: decodeURIComponent(d), id: '' }
            }))
          }
          if (filters.artifact)
            selected = selected.concat(filters.artifact.split(',').map(function(d){
              return { artifactId: decodeURIComponent(d) }
            }))
          if (filters.name)
            selected = selected.concat(filters.name.split(',').map(decodeURIComponent))

          filterLookup.selected(selected)
          renderAll()
          if (filters.artifact && filters.artifact[0])
            searchByArtifacts(filters.artifact)
          else loadReleases()
        }
      }

      function initCrossfilter() {
        release = crossfilter(_.values(releases))
        dimension.created = release.dimension(releaseDate)
        grouping.created = dimension.created.group(d3.time.day)
        dimension.team = release.dimension(team)
        grouping.team = dimension.team.group(String)
        dimension.name = release.dimension(name)
        grouping.name = dimension.name.group(String)
        dimension.artifacts = release.dimension(artifacts)
        grouping.artifacts = dimension.artifacts.group(String)
      }

      function findRange (argument) {
        var sorted = _.values(releases).sort(sortByReleaseDate)
        minCreated = +sorted[0].releaseDate - 1000000000
        maxCreated = +sorted[sorted.length-1].releaseDate + 1000000000
      }

      function initChart(){
        d3.select('.chart').html('')
        chart = barChart()
          .dimension(dimension.created)
          .group(grouping.created)
          .key('releaseDate')
          .round(d3.time.day.round)
          .x(d3.time.scale()
            .domain([moment().subtract('years', 1), moment().add('years', 1)])
            .rangeRound([0, 10 * 105]))
          .on('brush', onUpdateFilters)
          .on('brushend', onUpdateFilters)
      }

      function renderAll() {
        clearTimeout(buffer)
        buffer = setTimeout(renderGrid.bind(0, dimension.created.top(maxRecords)), 20)
        renderPeriod()
        renderLookup()
        d3.select('.chart').call(chart)
      }

      function renderLookup(){
        d3.select(self)
          .select('.swift-lookup')
          .call(filterLookup)
      }

      function drawDropdownSuggestion(d, i) {
        var q = filterLookup.query()
          , f = fuzzySearch().query(q)

        d3.select(this)
          .html('<span class="sub pull-right">'
            + typeOf(d)
            + '</span>'
            + f.format(label(d)))
      }

      function drawLozenge (d,i) {
        this.dataset.pre = typeOf(d)
      }

      function typeOf(d) {
        return d.artifactId ? 'Artifact'
          : d.name ? 'Team'
          : 'Release'
      }

      function label(d){
        return d.artifactId || d.name
      }

      function releaseDate(d){
        return d.releaseDate
      }

      function team(d){
        return d.team.name
      }

      function name(d){
        return d.name
      }

      function artifacts(d){
        return d.artifacts
      }

      function releaseDate(d){
        return d.releaseDate
      }

      function sortByReleaseDate(a,b){
        return a.releaseDate - b.releaseDate
      }

      function onlyName (d) {
        return !d.name && !d.artifactId
      }

      function onlyArtifact (d) {
        return d.artifactId
      }

      function renderIfChanged(renderer, key) {
        return function () {
          var previous = {}
            , notChanged = function (data) {
              if (key !== undefined && data != undefined && previous != undefined) return (previous[key] === data[key])
              return previous === data
            }
          return function (data) {
            if (notChanged(data)) return
            renderer.apply(this, arguments)
            previous = data
          }
        }
      }

      function getJSON(url) {
        var promise = new jQuery.Deferred()
        pendingRequests.push(
          $.getJSON(url)
            .done(function (data, status, jqXhr) {
              pendingRequests.splice(pendingRequests.indexOf(jqXhr), 1)
              promise.resolve(data, status, jqXhr)
            })
            .fail(function (jqXhr) {
              pendingRequests.splice(pendingRequests.indexOf(jqXhr), 1)
              promise.reject(jqXhr)
            })
        )
        return promise
      }

      function abortPendingRequests() {
        pendingRequests.forEach(function (jqXhr) {
          jqXhr.abort()
        })
        pendingRequests = []
      }

    }
  }
)
