define([
  'd3',
  'jquery',
  'visualize/visualize',
  'moment',
  'css!./feed.css'
], function (d3, $, visualize, moment) {
  'use strict'

  var BASE_URL = '/api/release'
    , renderFeed = visualize.bind()
      .into('div')
      .each(function (d, i) {
        $('.title', this)
          .text(d.name)
          .attr('href', '/swift/release/' + d.id)
        $('.sub', this)
          .text(d.team.name)
          .attr('href', '/swift/team/' + d.team.name)
        $('time', this)
          .text(d.releaseDate ? 'Due: ' + moment(+d.releaseDate)
            .format('DD.MM.YYYY') : "")
      })

  return function (req) {
    var $this = $(this)
      , dataSource = makeDataSource(req.param)

    $this.addClass('is-loading')

    $.getJSON(dataSource)
      .always(function () {
        $this.removeClass('is-loading')
      })
      .done(function (data) {
        renderFeed.into($this.get(0))
        renderFeed(data.pageResults ? data.pageResults : data)
      })
  }

  function makeDataSource(param) {
    var url = BASE_URL
      , queryString = $.param({
        organisation: param('org'),
        upcoming: param('upcoming') || false
      }, true)

    if (param('myteams')) url += '/myteams'

    url += '?' + queryString

    return url
  }
})