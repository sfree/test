define(function () {

  return {
    getTotalActions: getTotalActions
  }

  function getTotalActions(action) {
    var sumActions = 0

    if (action.included) {
      if (action.execute) {
        action.included.forEach(function(child) {
          if (child.hasOwnProperty('totalChildren')) sumActions += child.totalChildren
          else sumActions++
        })
      }
      action.totalChildren = sumActions
    } else {
      // if no child actions, treat this as a single action
      sumActions++
    }
    return sumActions
  }
})