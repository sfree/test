define(
  [ 'jquery'
  , 'd3'
  , 'visualize/visualize'
  , 'resourceful/address'
  , "log!swift/deploy/plan"
  , './plan-utils'
  , 'css!./styles.css'
  ],
  function($, d3, visualize, address, log, planUtils) {
    var self
      , clones = false
      , total = function(){
        var data = d3.select(this).datum()

        return planUtils.getTotalActions(data)
      }
      , progressRound = function(dblVal) {
        // As soon as a deployment starts, show % completed as 1%
        // Do not show as complete until every action has completed.
        if (dblVal > 0 && dblVal < 1) return 1
        else if (dblVal > 99 && dblVal < 100) return 99
        else return Math.round(dblVal)
      }
      , calculatePercentage = function(){
        // treat a started action as 25% completed.
        var data = d3.select(this).datum()
        ,   sumCompletedActions = 0

        if (data.execute) {

          if (data.included) {          
            data.included.forEach(function(d) {
              if (d.hasOwnProperty('totalCompletedChildren')) sumCompletedActions += d.totalCompletedChildren
              else if (d.deploymentState) sumCompletedActions += d.deploymentState.status == 'RUNNING' ? 0.25 : 1
            })
          } else if (data.deploymentState) 
            sumCompletedActions += data.deploymentState.status == 'RUNNING' ? 0.25 : 1
        }
        data.totalCompletedChildren = sumCompletedActions
        return progressRound((sumCompletedActions / total.call(this)*100) || 0) + '%'
      }
      , isSelectedGroup = function(){
        return !!$(this).find(':checked').length
      }
      , renderActions = function(into, data){
          var node = d3
            .select(into)
            .select(function() { if (!this.children.length) clones.base.call(this); return this })
            .select('.actions-header')
            .selectAll('.action')
            .data(data, function(d) { return d.id })

          node.enter().select(clones.action)
          node.attr('id', function(d){ return d.id })
            .attr('class', function(d){ return 'action ' + (d.deploymentState ? d.deploymentState.status : '') })
            .each(function(d){
              if (failAction.call(this, d))
                $(this).closest('.actions').find('.actions-info').text(d.deploymentState.clientError.message)
            })

          node.select('label')
            .text(function(d, i) { return d['@type'] })
            .attr('data-index', function(d, i) { return ++i + '. ' })
          node.select('time').text(function(d, i) {
            if (d.deploymentState && d.deploymentState.endTime) return Math.round((d.deploymentState.endTime - d.deploymentState.startTime)/10)/100 + 's' })
          node.exit().remove()
        }
      , renderGroups = function(into, data){
          var node = d3.select(into).selectAll('.action-groups').data(data, function(d) { return d.id })
          , enter = node.enter().select(clones.group)
          node.select(':checkbox')
            .attr('data-id', function(d) { return d.id })
            .each(function(d){ this.checked = d.execute })
            .on('click', function(){ d3.event.stopPropagation() })

          node.select('.children-container').each(function(d){
            var actionType = d['@class']
            if (actionType == 'com.ubs.f35.swift.deploy.client.action.ClientPlanGroupAction') {
              var containsActions = d.included[0]['@class'] == 'com.ubs.f35.swift.deploy.client.action.ClientPlanAction'
              return containsActions
                ? renderActions(this, d.included)
                : renderGroups(this, d.included)               
            } else if (actionType == 'com.ubs.f35.swift.deploy.glu.action.ManualAction') {
              // TODO
              insertManualAction(this, d)
            }
          })
          node.select('label')
            .text(function(d) { return d.name })

          node.each(refreshPercentages)

          node.select('.logs').classed('hide', function(d){ return !d.artifactInstanceId || d.historical })
          node.exit().remove()
        }
      , refreshPercentages = function(){
        // Note this function requires all lower levels of the tree to be calculated before refreshing a higher level.
        var $this = $(this)
          , percentage
          , $bar =  $this.find('.bar').first()

        percentage = calculatePercentage.call(this)

        if (window.requestAnimationFrame) {
          window.requestAnimationFrame($bar.css.bind($bar,'width', percentage))
        } else {
          $bar.css('width', percentage)
        }
        $this.find('.percentage').first().text(percentage)

      }

    function insertManualAction(into, action) {
      var domNode = clones.manualAction.call(into, action)
      $(domNode).attr('id', action.id)
      renderManualAction(domNode, action)
    }  

    // Somewhat flawed at the moment, the manual action is actually rendered as an action-group
    function renderManualAction(domNode, action) {
      var disabled = !action.deploymentState || action.deploymentState.status != 'RUNNING'
      $('.instructions', domNode).text(action.spec.description)
      $('.comments', domNode).text(action.comment || '')
        .attr('disabled', disabled)
      // buttons disabled until manual action in progress, then disabled again on completion.      
      $('.btn', domNode).attr('disabled', disabled)

      failAction.call(domNode, action)

      // if the manual action is now active, bring the users attention to it.
      if (action.deploymentState && action.deploymentState.status == 'RUNNING') {  
        showAction(domNode)
        window.glowMomentarily(domNode)    
      }
    }  

    function showAction(actionNode) {
      $('.action-group').has(actionNode).removeClass('collapsed')
    }

    function failAction(action) {
      if (action.deploymentState && action.deploymentState.status == 'FAILED') {
        showAction(this)
        
        // don't change the status of other progress bars within the group which may have passed
        $(this).parents('.action-group').each(function() {
          $('.progress', this)
            .first()
            .removeClass('progress-success')
            .addClass('progress-danger')
        })
        return true
      }
      return false
    }

    return {
      modify: function(req){
        log.time('plan.modify'+req.body.id)
        var action = req.body
          , base = $('#'+action.id).closest('.children-container').get(0)
          , data = d3.select(base).datum()
          , $parents = $('.action-group').has(base)

        if (action['@class'] == 'com.ubs.f35.swift.deploy.glu.action.ManualAction') {
          $.extend(data, action)
          renderManualAction($('#'+action.id)[0], action)
        } else {          
          data.included.some(function(e,i){
            if (e.id == action.id) {
              data.included[i].deploymentState = action.deploymentState
              renderActions(base, data.included)
              return true
            }
          })
        }
        $parents.reverse().each(refreshPercentages)
        log.timeEnd('plan.modify'+req.body.id)
        return;
      },
      send: function(req) {
        self = this
        clones = (clones ? clones :
          { action: visualize.selector.appendClone(d3.select('.view-deploy-plan .action').remove().node())
          , base: visualize.selector.appendClone(d3.select('.view-deploy-plan .actions').remove().node())
          , group: visualize.selector.appendClone(d3.select('.view-deploy-plan .action-group').remove().node())
          , manualAction: visualize.selector.appendClone(d3.select('.view-deploy-plan .manual-action').remove().node())
          })

        $('.action-group').remove()
        $('.view-deploy-plan .manual-action').remove()

        address('deploywarnings')
          .header('accept', ['application/view', 'text/html'])
          .header('target', $('.deployment-plan-warnings', self).get(0))
          .send({ releaseId : req.body.releaseId , warnings: req.body.warnings })

        log.time('renderGroups')
        renderGroups($('.plan-holder', self).get(0), req.body.actions)
        log.timeEnd('renderGroups')

        $('.action-group:not(:has(.FAILED))').addClass('collapsed')
        $(':checkbox', self).attr('disabled', req.param('historical'))

        if (req.param('artifactInstanceId')) {
          var $relatedActions = $('.action-group').filter(function (ele) { return d3.select(this).datum().artifactInstanceId == req.param('artifactInstanceId')})
          showAction($relatedActions)
        }

        $('.header').click(function(e) {
          $(this).closest('.action-group').toggleClass('collapsed')
        })

        $(this).on('click', '.include-deps', function() { $(self).trigger('deployment-generate-with-deps') })

        $('.action-group', this).reverse().each(recalcCheckbox)

        $(':checkbox').change(function(e) {
          // Select/Deselect all Children..
          $(this).closest('.action-group').find(':checkbox').prop('checked', this.checked).prop('indeterminate', false);

          // Indeterminate Check..
          $(this).closest('.action-group').parents('.action-group').each(recalcCheckbox)

        })
        /**
         * Please speak to Luke if you dislike this approach so we can work together on an alternative approach!
         * This bubbles up recalculation of which parent checkboxes in the tree should be flagged as indeterminate based on
         * the currently checked status of all children.  This has to be done from the bottom up, as if a lower level check box
         * is changed, that could affect all parents above it.  If the order of processing of those parents is not guaranteed,
         * then the parents will not correctly apply the state change (as their closest child may still be unchecked)
         */
        function recalcCheckbox() {
          var $actionGroup = $(this)
          var childCheckboxes = $('.children-container :checkbox', $actionGroup).length
            ,   childChecked = $('.children-container :checked', $actionGroup).length
            ,   groupCheckbox = $(':checkbox', $actionGroup).get(0)

          if (childCheckboxes > 0) {
            groupCheckbox.checked = (childCheckboxes == childChecked ? true : false)
            groupCheckbox.indeterminate = (childCheckboxes != childChecked && childChecked != 0 ? true : false)
          }
        }

        // Logs..
        $(self).on('click', '.logs', function(e){
          e.stopPropagation()
          var data = d3.select($(this).closest('.action-group').get(0)).datum()
          log.debug(data)
          address('logs')
            .param('id', data.artifactInstanceId)
            .view($('.lightbox-logs')
            .toggleClass('is-open')
            .find('.p')
            .get(0))
        })

        log.info('firing deployment loaded event')
        $(self).trigger('deployment-loaded')
      }
    }
  }
)
