define(
  [ "jquery"
  , "resourceful/address"
  , "../../utils/bootstrap"
  , "../../utils/streaming"
  , "log!swift/deploy/execute"
  , "../plan/plan-utils"
  ],

  /**
   * Binds to a button id #btnDeploy with an initial state of .commence for executing deployments.
   * eg. <button id="btnDeploy" class="btn commence" title="Executes the deployment plan">Execute</button>
   *
   * Fires deployment-loaded, deployment-started and deployment-completed events.
   */

  function($, address, swift, streamingUtil, log, planUtils) {

    var self
      , plan
      , serviceRef
      , pendingMessages = []
      , disableDeployButtonWithText = function(text) {
          $("#btnDeploy").text(text)
            .attr("class", "btn is-disabled")
        }
      , deploymentComplete = function(update) {
          $(self).trigger('deployment-completed', update)
        }

    streamingUtil.initStreaming(streamingServiceCallback, onError)

    function onMessage(update) {
      log.info(update)

      if (update.message) {
        // Exception returned before deployment could start
        displayStickyError(update.message)
        disableDeployButtonWithText("Error")
        deploymentComplete(update)
      } else if (update == "FAILED") {
        displayStickyError("Deployment failed. See the relevant step for more details")

        disableDeployButtonWithText("Failed")
        deploymentComplete(update)
      } else if (update == "COMPLETED") {
        $(document).trigger("inform.success", "Deployment successful")
        disableDeployButtonWithText("Completed")
        deploymentComplete(update)
      } else if (update == "CANCELLED") {
        $(document).trigger("inform.warning", "Deployment cancelled")
        disableDeployButtonWithText("Cancelled")
        deploymentComplete(update)
      } else {
        address('deployplan').modify(update)
      }
    }

    function displayStickyError(message) {
      var $sticky = $('.sticky-error')
      $('li', $sticky).html(message)
      $sticky.removeClass('is-hidden')
    }

    function onError(e) {
      $(document).trigger(
        "inform.error"
      , "Cannot connect to service. Please re-try."
      )
    }

    function changeDeployToCancelButton() {
      $("#btnDeploy").attr("class", "btn cancel").text("Cancel")        
    }

    $(document).on("click", "#btnDeploy.cancel", function() {
      disableDeployButtonWithText("Cancelling...")
      sendMessage({action: "CANCEL"})
    })


    $(document).on('start-deployment', '.deployment-plan-container', function(e, requestParams){
      log.debug("commence clicked")

      var $deployButton = $("#btnDeploy.commence")

      $('.plan-warnings').addClass('collapse')

      var selectedItems = $(":checked", self).map(function(i, e) { return $(e).attr('data-id') }).get()
      if (!selectedItems.length) return $(document).trigger("inform.warning", "Please select at least one component to deploy.")

      function updateExecutedFlag(d) {
        if (d.included) {
          var anyChildIncluded = false
          d.included.forEach(function (child) {
            if (updateExecutedFlag(child)) anyChildIncluded = true
          })

          d.execute = anyChildIncluded ||  selectedItems.indexOf(d.id) != -1
        }
        planUtils.getTotalActions(d)
        return d.execute
      }
      // update the deployment plan to reflect the items which have been selected.
      plan.actions.forEach(updateExecutedFlag)

      // Change the deployment button text..  Done async so that this click event doesn't hit the cancel handler.
      setTimeout(changeDeployToCancelButton, 0)

      // fire deployment started event.
      $(self).trigger('deployment-started')

      $(":checkbox", self).attr("disabled", "disabled");

      $('.action-group:not(:has(:checked))').addClass('exclude').on('webkitTransitionEnd', function() { $(this).hide() })

      log.info('Executing deployment plan with id', plan.planId)

      var messageBody = {action: 'DEPLOY', execute: selectedItems}

      if (requestParams) $.extend(messageBody, requestParams)

      sendMessage(messageBody)
    })

    $(document).on('click', '.deployment-plan-container .continue', continueDeployment)
 
    $(document).on('click', '.deployment-plan-container .abort', continueDeployment)

    function continueDeployment() {
      var manualAction = $(this).closest('.manual-action')
        , manualActionId = manualAction.attr('id')

      var message = {
        'action': 'MANUAL', 
        manualActionId: manualActionId, 
        comment: $('.comments', manualAction).val(), 
        continueDeployment: $(this).hasClass('continue') }

      sendMessage(message)

      // will receive a callback from the server that the manual action is completed, buttons will be disabled then.
    }

    function streamingServiceCallback(service) {
      serviceRef = service
      subscribe()
    }

    function subscribe() {
      if (plan && serviceRef) {
        serviceRef.subscribe('/deploy/' + plan.planId, function callback(frame) {
          onMessage(JSON.parse(frame.body))
        })

        // drain any pending messages
        pendingMessages.forEach(function(message) {
          sendMessage(message)
        })
        pendingMessages = []
      }
    }

    function sendMessage(message) {
      if (!serviceRef) {
        // streaming not established yet.  Record the message to be sent and error if it's not been actioned in 5 seconds.
        pendingMessages.push(message)
        setTimeout(errorIfPendingMessages, 5000)
      } else {
        $.cookie.raw = true;
        var token = $.cookie('LWSTOKEN');
        serviceRef.send('/deploy/' + plan.planId, {'LWSTOKEN': token}, JSON.stringify(message))
      }
    }

    function errorIfPendingMessages() {
      if (pendingMessages.length > 0) onError()

      pendingMessages = []
    }

    return {
      send: function(req) {
        self = this

        plan = req.body

        subscribe()

        log.info('Rendering deployment plan with id', plan.planId)
        log.debug(plan)
        address("deployplan")
          .header("accept", ["application/view", "text/html"])
          .header("target", $(self).addClass('swift-ux').get(0))
          .send(plan)
      }
    }
  }
)