define(
  [ 'jquery'
  , 'd3'
  , 'visualize/visualize'
  , "log!swift/deploy/warnings"
  , 'css!./styles.css'
  ],
  function($, d3, visualize, log) {
    var self
      , confirmWarnings = []
      , release
      , renderWarnings = visualize.bind()
          .into('li')
          .each(function(d) {
            $(this).text(d.message)
            if (d.code == 'DeploymentBreaksDependencies' || d.code == 'DeploymentHasDependencies') {
              $(this).append(' <a class="include-deps">(Include Dependencies)</a>')
            }
          })        

    registerListeners()

    function registerListeners() {
      $(document).on('confirm-warnings', '.plan-warnings-ui', checkWarningsConfirmedAndContinue)
      $(document).on('keyup', '.deployment-confirmation .confirmedReleaseId', confirmationTextChanged)      
      $(document).on('click', '.deployment-confirmation .accept-warnings-deploy', confirmWarningsClicked)      
    }

    function confirmationTextChanged() {
      $('.deployment-confirmation .btn.accept-warnings-deploy', self).attr('disabled', $(this).val() != release)
    }

    function checkWarningsConfirmedAndContinue() {
      if (confirmWarnings.length == 0)
        fireContinue()
      else {
        $('.deployment-confirmation', self).addClass('is-open')                        
      }
    }

    function fireContinue(confirmedReleaseId) {
      $(self).trigger('confirm-warnings-continue', confirmedReleaseId)
    }

    function confirmWarningsClicked() {
      $('.deployment-confirmation', self).removeClass('is-open')  

      fireContinue($('.deployment-confirmation .confirmedReleaseId', self).val())     
    }

    return {
      send: function(req) {
        var warnings = req.body.warnings || []

        self = this
        release = req.body.releaseId        

        confirmWarnings = warnings.filter(function(d) { return d.requiresProductionConfirmation })
        // confirmation of production warnings is only for release deployments.
        if (release) {
                  
          $('.deployment-confirmation .releaseId', self).text(release)

          $.getJSON('/api/release/' + release + '/summary')
            .done(function(data){
              $('.deployment-confirmation .releaseName', self).text(data.name)
            })

        }
        d3.select(self).select('.confirm-plan-warnings').datum(confirmWarnings).call(renderWarnings)
        
        d3.select(self).select('.plan-warnings').classed('hidden', warnings.length == 0).datum(warnings).call(renderWarnings)
        
      }
    }
  }
)
