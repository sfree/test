define(
  [ 'jquery'
  , 'd3'
  , 'visualize/visualize'
  , 'resourceful/address'
  , '../../utils/bootstrap'
  , 'grid/grid'
  , 'grid-plugins/sorting'
  , 'css!grid/styles.css'
  , 'css!./styles.css'
  , 'css!../../styles.css'
  ], function($, d3, visualize, address, swift, grid, sorting) {

    'use strict'

    return function() {
      var columns =
          [
            {key: 'id', headerRenderer: 'Deployment Id', renderer: tooltipRenderer, width: '260px'},
            {key: 'environments', headerRenderer: 'Environments', renderer: tooltipRenderer, width: '200px'},
            {key: 'deploymentType', headerRenderer: 'Type', width: '80px'},
            {key: 'releaseId', headerRenderer: 'Release', renderer: releaseLink, width: '60px'},
            {key: 'user', headerRenderer: 'Deployer', renderer: userRenderer, width: '205px'},
            {key: 'createdTime', headerRenderer: 'Time', renderer: timeRenderer, width: '180px'},
            {key: 'actions', headerRenderer: 'Actions', renderer: actionsRenderer, accessor: function(data) { return function() { return data } }, width: '80px'}
          ]
      ,   $deploymentsGridNode = $('.deployments-grid', this)
      ,   deploymentsGrid = grid()
            .register(sorting)
            .rowHeight(35)
            .columns(columns)
            .node($deploymentsGridNode)
      ,   self = this
      ,   org

      setupListeners()

      return {
        start: start
        , update: update
        , stop: stop
      }

      function start() {
        $('html').addClass('swift-ux')
      }

      function update(req) {
        swift.update(req)

        org = req.param('org')

        swift.breadcrumbs.render([{'title': org,'url':'/swift/' + org}, {'title': 'Running deployments'}])

        loadRunningDeployments()
      }

      function stop() {
        swift.breadcrumbs.stop()
        $('html').removeClass('swift-ux')
      }

      function setupListeners() {
        $(self).on('click', '.cancel', onCancelClick)
      }

      function loadRunningDeployments() {
        $('.results', self).addClass('loading')
        $.getJSON('/api/deployment/running/' + org)
          .success(renderRunningDeployments)
      }

      function renderRunningDeployments(data) {
        $('.no-deployments', self).toggleClass('is-hidden', data.length != 0)
        $deploymentsGridNode.toggleClass('is-hidden', data.length == 0)

        data.forEach(function(d){
          d.environments = d.envDeployments.map(function(envDeploy) {
            return envDeploy.environment.name
          }).join(', ')
        })
        deploymentsGrid.data(data)
        $('.results', self).removeClass('loading')
      }

      function userRenderer() {
        return function(data) {
          // render the small profile, don't include the avatar.
          $(this).append('<span class="user-profile-container"></span>')

          address('users')
            .param({'guid': data})
            .view($('span', this).get(0))
        }
      }

      function timeRenderer() {
        return function(data) {
          $(this).text(moment(data).format('DD-MMM-YYYY h:mm:ss a'))
        }
      }

      function tooltipRenderer() {
        return function(data) {
          var node = d3.select(this)
             .text(data)
             .attr('title', data)
        }
      }

      function releaseLink(releaseId) {
        d3.select(this)
          .html('<a></a>')
          .select('a')
          .text(releaseId)
          .attr('href', '/swift/release/' + releaseId)
      }

      function actionsRenderer(data) {
        d3.select(this)
          .html('<button class="cancel btn btn-small" data-id="' + data.id + '">Cancel</button>')
      }

      function onCancelClick() {
        var $btn = $(this)
          , deploymentId = $btn.attr('data-id')
        swift.executeAjax($btn, $btn, function() {
          return $.ajax({
            type: 'DELETE',
            url: '/api/deployment/cancel/' + deploymentId,
            success: function(savedConfig){
              $(document).trigger('inform.success', 'Cancel deployment request acknowledged. No more actions in the deployment will be started.')
            }
          })
        })
      }
    } // end resource factory function

  } // end amd
) // end define
