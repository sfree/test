define(
  [ 'jquery'
  , 'resourceful/address'
  , '../utils/bootstrap'
  , 'log!swift/deploy'
  , 'css!./styles.css'
  , 'css!../global.css'
  ],
  /**
   * This deployment plan page is only used from within the context of a release.  If a plan id is present, this is because the deployment
   * is for a rollback.  This logic is never used from the context of deployment actions from the status dashboard.
   */
  function($, address, swift, log) {

    return function(){
      return {
        update: function(req) {
          var self = this
            , org = req.param('org')
            , env = req.param('env')
            , envs = env.split(',')
            , release = req.param('release')
            , revision = req.param('revision')
            , deploymentContextId = req.param('deploymentContextId')
            , isRollback = (req.param('plan') != null)
            , plan
            , gDeployFunction
            , $deploymentContainer = $('.deployment-plan-container', self).addClass('swift-ux')
            , navToStatus = function(){
                function reduceArtifactNames(aggr, action) {
                  if (action.artifactId) aggr.push(action.artifactId)
                  else if (action.included) action.included.reduce(reduceArtifactNames, aggr)

                  return aggr
                }

                var artifacts = unique(plan.actions.reduce(reduceArtifactNames, [])).join(',')

                address('status')
                  .param('org', org)
                  .param('environment', env)
                  .param('artifact', artifacts)
                  .view()
              }
            , selectAll = function(all){
                $(':checkbox', self).prop('checked', all).trigger('change')
              }

          swift.update(req)

          $('.environment', this).text(env)
          swift.render.releaseSummary(release, revision)
          
          if (isRollback) {
            $('.view-deploy').addClass('rollback')
            $('.view-deploy .title').text('Rollback Plan')
          } else {
            $('.commence').attr('title',
            'Updates the environment configuration to use the versions of artifacts defined on the release for selected actions and then executes the deployment plan so those changes are brought into affect')
          }

          swift.breadcrumbs.render([{"title":"Releases","url":"/swift/" + org + "/releases"}, {"handle":"release"}, {"title": (isRollback ? "Rollback" : "Deployment")}])

          $('.view-deploy .release-summary h1').on('click', function() { $('.progress .bar').addClass('easter')} )

          $(this).on('click', '.manual-deploy', function(){
            checkWarningsConfirmedAndDeploy(manualDeployRelease)
          })

          $(this).on('click', 'button.release', function() {
            address('/swift/release/' + release + (revision?'?revision='+revision:'')).view()
          })

          $(this).on('click', 'button.commence', function() {
            checkWarningsConfirmedAndDeploy(deployRelease)
          })

          $(this).on('confirm-warnings-continue', function(e, confirmedReleaseId) {
            gDeployFunction(confirmedReleaseId)
          })

          function checkWarningsConfirmedAndDeploy(deployFunction) {
            gDeployFunction = deployFunction
            $('.deployment-plan-warnings .plan-warnings-ui', self).trigger('confirm-warnings')
          }

          function deployRelease(confirmedReleaseId) {
            $deploymentContainer.trigger('start-deployment', { confirmedReleaseId: confirmedReleaseId } )
          }

          function manualDeployRelease(confirmedReleaseId) {
              // TODO pulling out the selected items list belongs in the internals of execute/main.js (this was copy pasted from there)
              var selectedItems = $(":checked", self).map(function(i, e) { return $(e).attr('data-id') }).get()
              if (!selectedItems.length) return $(document).trigger("inform.warning", "Please select at least one component to manually deploy.")

              $.post('/api/deployment/release/' + req.param('release') + '/apply',
                  JSON.stringify({ planId: plan.planId, execute: selectedItems, confirmedReleaseId: confirmedReleaseId }))
                .done(function(data){
                  $(document).trigger('inform.success', 'Artifact release versions applied. Please deploy manually.')
                  navToStatus();
                })
          } 

          $(this).on('click', 'button.status', navToStatus)

          $(this).on('click', '.select-all', function(){ selectAll(true) })
          $(this).on('click', '.select-none', function(){ selectAll(false) })

          $deploymentContainer.on('deployment-loaded', function() {
            $('.ajax.loading').hide()
            $('.deploy-buttons').removeClass('hide')
          })

          $deploymentContainer.on('deployment-started', function() {
            $('.manual-deploy').attr('class', 'btn is-disabled')
          })

          $deploymentContainer.on('deployment-completed', function() {
            $('.nav-buttons').removeClass('hidden')
          })

          $.getJSON(req.param('plan')
              ? '/api/deployment/plan/' + req.param('plan')
              : '/api/deployment/release/' + release + '?' + $.param({'environment':envs}, true) + (revision?'&revision='+revision:'') + (deploymentContextId?'&deploymentContextId='+deploymentContextId:''))
            .done(function(data){
              plan = data
              log.info('new plan id', plan.planId)
              log.debug(plan)

              address('deployexecute')
                .header('accept', ['application/view', 'text/html'])
                .header('target', $deploymentContainer.get(0))
                .send($.extend(data, { releaseId : release }))
            })
            .fail(function(data){
              $('.ajax.loading').hide()
            })

        }
        , start: function() { $('html').addClass('swift-ux') }
        , stop: function() { $('html').removeClass('swift-ux'); swift.breadcrumbs.stop() }
      }
    }

  }
)
