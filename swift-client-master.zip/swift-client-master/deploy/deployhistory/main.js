;define(
  [ 'jquery'
  , 'd3'
  , 'resourceful/address'
  , 'visualize/visualize'
  , 'css!./styles.css'
  ], function($, d3, address, visualize) {

    'use strict'

    return function(){
      var self = this
        , dom = d3.select(this)
        , artifactHistoryFunctions = {}
        , releaseHistoryFunctions = {}
        , functions = artifactHistoryFunctions
        , artifactInstanceId
        , init = false
//        , clone = visualize.selector.appendClone(dom.select('.log').remove().node())
        , formatDate = d3.time.format('%b %d, %Y')
        , renderDeploymentHistory = visualize.bind()
          .into('.deployments')
          .each(onRenderDeploymentHistoryEach)

        , renderDeploymentHistoryItems = visualize.bind()
          .into('.deployment-list')
          .key(function(d) {
            return functions.getDeployment(d).id
          })
          .each(onRenderDeploymentHistoryItemsEach)

      // This resource is used to present the deployment history summary for both releases and artifacts.  Very little differs between the two,
      // the differences are represented below.  Ideally the framework / language would make this easier, but at least this avoids duplication.
      artifactHistoryFunctions.getDeployment = function(d) { return d.envDeployment.deployment }
      artifactHistoryFunctions.getHistoryUrl = function(req) { return '/api/history/detailed/artifact?id=' + artifactInstanceId }
      artifactHistoryFunctions.buildDeploymentSummary = function(artifactDeploy) {
        if (artifactDeploy.versionChanged) {
          // Some sort of release deployment changed the deployed version.
          if (artifactDeploy.envDeployment.deployment.deploymentStatus == 'MANUAL')
            return 'Version updated to ' + artifactDeploy.version
          else 
            return 'Deployed version ' + artifactDeploy.version
        } else {
          var actionLabel
          switch (artifactDeploy.deploymentAction) {
            case 'Start' : 
              actionLabel = 'Deploy & Start'
              break
            case 'StartOnly':
              actionLabel = 'Start'
              break
            default:
              actionLabel = artifactDeploy.deploymentAction
              break
          }
          return actionLabel + ' ' + artifactDeploy.version
        }
      }

      releaseHistoryFunctions.getDeployment = function(d) { return d }
      releaseHistoryFunctions.getHistoryUrl = function(req) { return '/api/history/detailed/' + req.param('releaseId') + '?records=100' }
      releaseHistoryFunctions.buildDeploymentSummary = function(d) {
        var envNames = d.envDeployments.map(function(e) { return e.environment.name.toUpperCase() }).join(', ')
        var text = envNames
        if (d.deploymentStatus == 'MANUAL')
          text += ' manual'
        if (d.deploymentType != 'Release')
          text += ' ' + d.deploymentType.toLowerCase()
        if (d.deploymentType != 'Rollback')
          text += ' deployment'
        if (d.deploymentStatus != 'MANUAL')
          text += ' ' + d.deploymentStatus.toLowerCase()

        return text
      }

      function setupListeners() {
        if (!init) {
          $(self).on('click', '.deployment-list .deployment', onHistoryDeploymentClick)
        }
        init = true
      }

      function handleDeploymentHistoryResults(history) {
        renderDeploymentHistory(d3.nest()
            .key(function(d) { return formatDate(d3.time.day(new Date(functions.getDeployment(d).deployTime))) })
            .entries(history.pageResults))
      }

      function onRenderDeploymentHistoryEach(d, i) {
        $('.date', this).text(d.key)
        renderDeploymentHistoryItems.within(this)
        renderDeploymentHistoryItems(d.values)
      }

      function onRenderDeploymentHistoryItemsEach(historyItem, i) {
        var d = functions.getDeployment(historyItem)

        var text = functions.buildDeploymentSummary(historyItem)

        $('.text', this).text(text).attr('title', text)
        $('time', this).text(' at ' + moment(+d.deployTime).format('HH:mm'))
        $('.light', this).addClass(d.deploymentStatus)

        if (d.deploymentStatus == 'MANUAL')
          $('.light', this).addClass('is-hidden')
        if (d.deploymentType == 'Rollback')
          $('.light', this).addClass('ROLLBACK')

        address('users')
          .param({'guid': d.user})
          .view($('.user', this))
      }

      function onHistoryDeploymentClick() {
        address('history')
          .param('id', functions.getDeployment(d3.select(this).datum()).id) // TODO this is not correct here
          .param('artifactInstanceId', artifactInstanceId)
          .view()
      }

      return {
        update: function(req) {
          setupListeners()

          artifactInstanceId = req.param('artifactInstanceId')

          functions = artifactInstanceId ? artifactHistoryFunctions : releaseHistoryFunctions

          dom.classed('loading', true)
          handleDeploymentHistoryResults({ pageResults: [] })

          $.getJSON(functions.getHistoryUrl(req))
            .always(function(){
              dom.classed('loading', false)
            })
            .done(function(history) {
              $('#deployments .total').text(history.totalRecords)
              handleDeploymentHistoryResults(history)
            })
        }
      }
    }
})