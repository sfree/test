define(
    [ 'jquery'
    , 'visualize/visualize'
    , '../details/updateConfig'
    , '../../d3-lookup/lookup'
    , 'fuzzy-search/fuzzy'
    , '../../utils/bootstrap'
    , 'css!./styles.css'
    , 'css!../../styles.css'
    ], function($, visualize, updateConfig, createLookup, fuzzySearch, swift) {

        "use strict"

        return function() {
            var group
            ,   org
            ,   artifact
            ,   commonConfig
            ,   versions = []
            ,   self = this
            ,   nav = 0
            ,   artifacts = []
            ,   lastUpdatedTime

            ,   renderNav = visualize.bind()
                    .into(".nav-tabs")
                    .each(onRenderNavEach)

            ,   renderContents = visualize.bind()
                    .into(".tab-content")
                    .each(onRenderContentsEach)

            ,   renderInstanceLabels = visualize.bind()
                    .into(".instances")
                    .changed(onRenderInstanceLabelsChanged)

            ,   renderInstances = visualize.bind()
                    .into(".pull-right")
                    .changed(onRenderInstancesChanged)

            setupHandlers.call($(this))

            return {
                start: start
                , update: update
                , stop: stop
            }

            function start() {
                $('html').addClass('swift-ux')
            }

            function update(req) {
              swift.update(req)

              org = req.param('org')

                group = req.param("group")
                artifact = req.param("artifact")
                versions = []

                $.getJSON('/api/config/' + org + '/environments')
                    .done(function(envs){
                        renderNav(envs)
                        renderContents(envs)
                        renderNotDeployedEnvs()                        
                        $('togglable-trigger').togglable()
                        $(".nav-tabs a").first().click()
                    })

                $.getJSON("/api/lookup/versions/" + group + "/" + artifact)
                    .done(function(r){
                        versions = r
                    })

                // Get artifact data, inc dependencies
                $.getJSON("/api/config/artifact/common/"+group+"/"+artifact)
                    .done(function(d) {
                        commonConfig = d
                        renderCommonConfig()
                        renderNotDeployedEnvs()

                        artifacts = d.dependencies
                        lastUpdatedTime = d.lastUpdatedTime

                        swift.sendToAddress('artifactlist', $(".artifact-list-container"), {"artifacts":artifacts || [], "showVersions":false, org : org})
                    })

                $(".loaded").removeClass("loaded")
                $(".empty").removeClass("empty")
                $(".is-active.is-togglable-toggled").removeClass("is-active is-togglable-toggled")
                $(".group", this).text(group)
                $('h1 a', this).text(artifact).attr('href', '/swift/' + org + '/status?group=' + group + '&artifact=' + artifact)

                if (nav === 1)
                    $(".nav-tabs a").first().click()
                nav = 1

                swift.breadcrumbs.render([{"title":"Artifacts"}, {"title":artifact}, {"title":"Configuration"}])
            }

            function stop() {
                $('html').removeClass('swift-ux')

                swift.breadcrumbs.stop()
            }

            function renderNotDeployedEnvs() {
                // if common config not loaded yet, try again later.
                if (!commonConfig) return

                $('.tab-pane', self).each(function() {
                    var env = $(this).attr('data-env')
                    var notDeployedEnv = commonConfig.notDeployedEnvironments.some(function(e) {
                        return e.name == env && e.organisation.name == org
                    })
                    $(this).toggleClass('never-deployed', notDeployedEnv)
                })    
            }

            function removeNotDeployedFlag() {
                var $tabPane = $(this).closest('.tab-pane')
                  , env = $tabPane.attr('data-env')

                $.ajax({
                        type: 'DELETE',
                        url: "/api/config/artifact/clear-not-deployed/" + org + '/' + env + '/' + group + '/' + artifact,
                        success: function(savedConfig){
                            $(document).trigger("inform.success", "Never deployed flag cleared")
                            $tabPane.removeClass('never-deployed')
                        },
                        contentType: "application/json; charset=utf-8"
                    })
            }

            function renderConfig(config, $target) {
              swift.sendToAddress('configdetails', $target, config)
            }

            function renderCommonConfig() {
                $("#non-prod", self).prop('checked', commonConfig.nonProd)
                $("#has-props", self).prop('checked', commonConfig.hasProperties)
                $("#prop-templates", self).val(commonConfig.propertyTemplates)
                onRequirePropsToggle()
            }

            /* Event handlers - Visualize */

            function onRenderNavEach(d) {
                $("a", this).text(d.toUpperCase())  // .attr("href", "#" + d.toUpperCase())
                $(this).attr("data-target", '[data-env='+d+']')
            }

            function onRenderContentsEach(env) {
                $(this).attr('data-env', env)
            }

            function onRenderInstanceLabelsChanged(config, i) {
                var $this = $(this)
                ,   $instances = $this.closest(".tab-pane").find(".pull-right")
                ,   $instance = $this.closest(".tab-pane").find(".instance").eq($this.index())

                $this
                    .text(config.name)
                    .click(function(e){
                        if (e.srcElement && e.srcElement.tagName == 'I') return;
                        $this.closest(".tab-pane").find('.is-active').removeClass('is-active')
                        $this.addClass("is-active")
                        $this.closest(".tab-pane").find(".instance").eq($this.index()).addClass("is-active")
                    })

                $('<i class="neo-icon-lookup-clear"></i>')
                    .appendTo($this)

                var remove = function(){
                    $(document).trigger("inform.success", "Instance successfully deleted")
                    $instance.remove()
                    $this.closest(".tab-pane").find('.instances a:first-child').click()
                    $this.remove()
                }

                $this.off('click', 'i').on('click', 'i', function(){
                    if (!config.lastUpdatedTime) return remove();
                    $.ajax({
                        type: 'DELETE',
                        url: '/api/config/artifact/' + config.environment.organisation.name + '/' + config.environment.name + '/' + group + '/' + artifact + '/' + config.name,
                        success: remove,
                        dataType: "json",
                        contentType: "application/json; charset=utf-8"
                    })
                })

                if ($this.text()) return;

                $('<input type="text" class="input-small" value="DEFAULT" maxlength="10" />')
                    .on('keypress', function(e){
                        if (this.value != '' && e.charCode == 13) {
                            $this.text(this.value)
                                .append($('<i class="neo-icon-lookup-clear"></i>'))

                            var data = $instance.data()

                            data.name = this.value
                            $instance.data(data)
                        }
                    })
                    .appendTo($this.empty())
            }

            function onRenderInstancesChanged(config) {
                var $target = $(this)
                ,   scripts = {}
                ,   savedArgs = config.scriptArgumentsMap || {}
                ,   versionLookup = createLookup()
                        .prompt('Version?')

                $target.data(config)
                    .toggleClass("empty", config.lastUpdatedTime === null)

                $(".version", $target).text(config.artifactVersion || "")
                $("time", $target).text("last updated " + moment(+config.lastUpdatedTime).fromNow() || "")
                d3.select(this)
                    .select('.version-lookup')
                    .datum(versions)
                    .call(versionLookup)

                renderConfig(config, $(".config-container", $target))

                $(".save", $target).off().click(function(e) {
                    var data    = $target.data()
                    ,   env     = data.environment
                    ,   $label = $(this).closest(".tab-pane").find(".instances a").eq($target.index())

                    // Update Name
                    if ($label.find("input").length) {
                        data.name = $label.find("input").val()
                        $label.text($label.find("input").val())
                    }

                    // Update Artifact Version
                    if ($target.hasClass("empty")) data.artifactVersion = versionLookup.query()

                    updateConfig.update(data, $target, env)

                    delete data['visualize::previousData']

                    $.ajax({
                        type: 'PUT',
                        url: "/api/config/artifact",
                        data: JSON.stringify(data),
                        success: function(savedConfig){
                            $(document).trigger("inform.success", "Config Management successfully saved!")
                            $target.data(savedConfig)
                            $target.find("time").text("last updated " + moment(+savedConfig.lastUpdatedTime).fromNow() || "")
                        },
                        dataType: "json",
                        contentType: "application/json; charset=utf-8"
                    })
                })
            }

            /* Event handlers - GUI */

            function setupHandlers() {
                this.on('change', '#has-props', onRequirePropsToggle)
                $('.artifact-configuration .save', this).on('click', onSaveArtifactConfigClick)
                this.on("click", ".nav-tabs > :not(.active)", onNavClick)
                this.on('click', 'a.add', onAddClick)
                this.on('click', '.clear-never-deploy', removeNotDeployedFlag)
            }

            function onRequirePropsToggle(){
                $('#has-props', self).is(":checked") ?
                    $('#prop-templates', self).removeAttr('disabled') :
                    $('#prop-templates', self).attr('disabled', true)
            }

            function onSaveArtifactConfigClick() {
                // Re-fetch the artifacts from artifactlist - binding may not exist if the artifacts array
                // sent to artifactslist was [] (another object instance)
                artifacts =
                    d3.select('.artifact-list-container')
                        .select('.js-artifact-items').datum()

                // Strip artifact type info
                artifacts = artifacts.map(function(a) {
                  var copy = $.extend({}, a)
                  delete copy.artifactType
                  return copy
                })

                var payload =
                    {
                        "groupId": group
                      , "artifactId": artifact
                      , "nonProd": $('#non-prod', self).is(":checked")
                      , "hasProperties": $('#has-props', self).is(":checked")
                      , "propertyTemplates": $('#prop-templates', self).val()
                      , "dependencies": artifacts || []
                      , "lastUpdatedTime": lastUpdatedTime
                    }

                $.ajax({
                      type: 'PUT'
                    , url: '/api/config/artifact/common'
                    , data: JSON.stringify(payload)
                    , dataType: 'json'
                    , contentType: 'application/json; charset=utf-8'})
                        .done(function(d) {
                            lastUpdatedTime = d.lastUpdatedTime
                            $('.artifact-configuration').trigger('inform.success', 'Artifact configuration saved')
                        })
            }

            function onNavClick() {
                var $this = $(this)
                ,   env = $this.text().toLowerCase()
                ,   $target = $('[data-env=' + env + ']')

                if (!$target.hasClass("loaded")) {
                    $.getJSON("/api/config/artifact/" + org + "/" + env + "/" + group + "/" + artifact)
                        .success(function(instances) {
                            if (!instances.length) instances.push(createEmptyInstance(env))

                            renderArtifactInstances($target, instances)

                            $target.find(".instances a").first().click()

                            $target.addClass("loaded")
                        })
                }

                $(".nav-tabs .is-active").removeClass("is-active")
                $(this).addClass("is-active")
            }

            function onAddClick() {
                var $target = $(this).closest('.tab-pane')
                ,   instances = $target.find('.instance').map(function(){ return $(this).data() })

                instances.push(createEmptyInstance($target.attr('data-env')))

                renderArtifactInstances($target, instances)

                $target.find('.instances a').last().click()
            }

            function createEmptyInstance(env) {
              return { artifactId: artifact
                , groupId: group
                , environment: {name: env, organisation: {name : org }}
                , lastUpdatedTime: null
                , name: "" }
            }

            function renderArtifactInstances($target, instances) {
              renderInstances.within($target.get(0))
              renderInstanceLabels.within($target.get(0))
              renderInstances(instances)
              renderInstanceLabels(instances)
            }

        } // end resource factory function

    } // end amd
) // end define
