define(
  [
    'jquery'
  , 'visualize/visualize'
  , 'resourceful/address'
  , '../../d3-lookup/lookup-multiple'
  , 'fuzzy-search/fuzzy'
  , '../../utils/bootstrap'
  , 'css!./styles.css'
  , 'css!../../styles.css'
  ]
, function(
    $
  , visualize
  , address
  , createLookupMultiple
  , fuzzySearch
  , swift
  ) {

    'use strict'

    return function() {
      var env
        , org
        , self = this
        , $environmentsContainer = $('.environments-container', self)
        , clones = {
            host: $('.host.prototype').remove().get(0)
          }
        , lookups = []
        , renderHosts = visualize.bind()
            .prototype(clones.host)
            .each(function(d){
              var self = this
                , envData = d

              $('time', self).text(moment(+d.lastUpdatedTime).fromNow() || '')
              $('label', self).text(d.hostname)

              $.getJSON('/api/config/' + org + '/deploytag/' + env)
                .success(function(r) {
                  var oldHosts = d.deployTags.filter(Object)
                    , hostLookup = createLookupMultiple()
                        .label(function(d){ return d.tag })
                        .prompt('Enter new deployment tags here..')
                        .on('select', onHostChange)
                        .on('deselect', onHostChange)
                        .selected(d.deployTags) 

                  hostLookup.el = d3.select(self).select('.swift-lookup')
                      .datum(r)
                      .call(hostLookup)

                  lookups.push(hostLookup)

                  $('input', hostLookup.el.node()).on('keydown', onHostKey)

                  function onHostChange() {
                    var newHosts = hostLookup.selected()

                    newHosts = newHosts.map(function(host){
                      return typeof host != 'object'
                        ? { tag: host
                          , environment: envData.environment
                          }
                        : host
                    })
                    envData.deployTags = newHosts
                    $.ajax({
                      type: 'PUT',
                      url: '/api/config/host',
                      data: JSON.stringify(envData),
                    }).done(function(savedConfig){
                      $(document).trigger('inform.success', 'Config Management successfully saved!')
                      envData = savedConfig
                      oldHosts = savedConfig.deployTags.filter(Object)
                      reloadOptions()
                    }).fail(function(){
                      hostLookup.selected(oldHosts.filter(Object))
                      hostLookup.el.call(hostLookup)
                    })
                  }
                })
            })

      setupListeners()

      return {
        start: start
        , update: update
        , stop: stop
      }

      function start() {
        $('html').addClass('swift-ux')
        swift.breadcrumbs.render([{'title':'Environments'}, {'title':'Host Configuration'}])
      }

      function update(req) {
        swift.update(req)

        env = req.param('environment')
        org = req.param('org')

        address('environments')
          .param('environment', env)
          .param('org', org)
          .view($environmentsContainer.get(0))

        if (env) {
          showEnvironment(env)
        }
      }

      function stop() {
        swift.breadcrumbs.stop()
        $('html').removeClass('swift-ux')
      }

      function setupListeners() {
        $environmentsContainer.on('environment-changed', function(e, data) {
          address('host').param('org', org).param('environment', data).view()
        })

        $environmentsContainer.on('environments-loaded', function(e, data) {
          // if no environment selected, default to the first.
          if (!env) {
            env = data[0]
            showEnvironment(env)
          }
        })
      }

      function showEnvironment(env) {
        var $target = $('.hosts')
        // intentionally clearing html here to avoid multiple lookup event handlers against single dom element
        lookups = []
        $target.addClass('loading').html('')

        $.getJSON('/api/config/' + org + '/host/' + env)
        .success(function(config) {
          renderHosts.into($target.get(0))(config)
          $target.removeClass('loading')
        })
      }

      function reloadOptions() {
        $.getJSON('/api/config/' + org + '/deploytag/' + env)
          .success(function(r) {
            lookups.forEach(function(h){
                h.el
                  .datum(r)
                  .call(h)
              })

          })
      }      

      function onHostKey(e) {
        // prevent backspace deleting a lozenge..
        if (e.which == 8) e.stopPropagation()
      }      

    }
  }
)