define(
  [ "jquery"
  , 'd3' ],
    function($, d3) {
      function update(data, $target){
              // Update Deployment Tags
        data.deployTags = $.makeArray($target.find(".deploytags ol span").map(function(){
          return { environment: data.environment, tag: $(this).text() }
        }))

        // Update Script
        var scripts = d3.select($target.find(".script").get(0)).datum()
        data.script = getSelectedScript(scripts, $target)

        // Update Script Arguments
        data.scriptArgumentsMap = {}
        $target.find(".argument").each(function(){
          data.scriptArgumentsMap[$(this).find(".key .key-name").text()] = $(this).find("input").val()
        })

        // Update Tags
        data.tags = $.makeArray($target.find(".swift-tags ol span").map(function(){
          return { tag: $(this).text() }
        }))

        // update cold standby
        data.coldStandby = $target.find('.cold-standby').prop('checked')
      }

      function getSelectedScript(scripts, $target) {
        var scriptName = $('.script', $target).val()
        ,   scriptVersion = $('.script-version', $target).val()

        for (var script in scripts) {
          if (scriptName == getScriptName(script) &&
              scriptVersion == getScriptVersion(script)) {
            return script
          }
        }

        return
      }

    function getScriptName(script) {
      return scriptField(script, 2)
    }

    function getScriptVersion(script) {
      return scriptField(script, 1)
    }

    function scriptField(script, index) {
      if (script) {
        return script.split('/')[index]
      }
    }

      return { update : update,
             getSelectedScript : getSelectedScript,
             getScriptName : getScriptName,
             getScriptVersion : getScriptVersion }
    }
)
