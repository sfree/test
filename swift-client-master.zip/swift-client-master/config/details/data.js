;define(
    [ 'jquery'
    , 'd3'
    , 'visualize/visualize'
    , '../../d3-lookup/lookup-multiple'
    , 'fuzzy-search/fuzzy'
    , '../details/updateConfig'
    , '../../utils/utilities'
    , 'css!./styles.css'
    ], function($, d3, visualize, createLookupMultiple, fuzzySearch, helper, utils) {

    'use strict'

    return {
        send: function(req) {
            var self = this
            ,   scripts = {}
            ,   scriptVersions
            ,   config = req.body
            ,   org = config.environment.organisation.name
            ,   savedArgs = config.scriptArgumentsMap || {}
            ,   renderArguments = visualize.bind()
                    .into('.list')
                    .each(function(d){
                        $('.key-name', this).text(d.paramName)
                        $('.key-information', this).text(d.title)
                        $('.value input', this)
                            .val(d.value)
                            .prop('required',!d.optional)
                    })
            ,   renderArgumentsHelper = function(allArguments) {
                    var allArguments = allArguments.map(function(e) {
                        return (e.value = savedArgs[e.paramName], e)
                    })

                    renderArguments.within(self)
                    renderArguments(allArguments)

                    $('.arguments', self).toggle(allArguments.length != 0)
                }
            ,   deployTagsLookup = createLookupMultiple()
                    .prompt('Enter new deployment tags here..')
                    .label(function(d){ return d.tag })
                    .selected(config.deployTags || [])
                    .allowFreeTextInput(false)
            ,   tagsLookup = createLookupMultiple()
                    .prompt('Enter new tags here..')
                    .label(function(d){ return d.tag })
                    .selected(config.tags || [])

            $(self).off()

            $('.cold-standby', self).prop('checked', config.coldStandby)

            $.getJSON('/api/config/' + org + '/deploytag/' + config.environment.name)
                .success(function(r) {
                    d3.select(self)
                        .select('.deploytags')
                        .datum(r)
                        .call(deployTagsLookup)
                })

            $.getJSON('/api/config/tag/' + org)
                .success(function(r) {
                    d3.select(self)
                        .select('.swift-tags')
                        .datum(r)
                        .call(tagsLookup)
                })

            $.getJSON('/api/config/' + org + '/scripts')
                .success(function(data) {
                    var allArguments = []
                    ,   scriptNames = []
                    ,   uniqueScripts

                    scriptVersions = {}

                    data.forEach(function(d) {
                        var scriptName = helper.getScriptName(d.script)
                        scriptNames.push(scriptName)

                        if (!scriptVersions[scriptName]) {
                            scriptVersions[scriptName] = []
                        }
                        scriptVersions[scriptName].push(helper.getScriptVersion(d.script))

                        scripts[d.script] = d.config
                        if (d.script == config.script) allArguments = d.config
                    })

                    d3.select(self).select('.script').datum(scripts)

                    uniqueScripts = unique(scriptNames).sort()
                    renderSelectInput(uniqueScripts, helper.getScriptName(config.script), $('.script', self))

                    renderScriptVersions(helper.getScriptName(config.script))
                    renderArgumentsHelper(allArguments)
                })

            $(self).on('change', '.script', function() {
                renderScriptVersions($(this).val())
                renderArgumentsForSelectedScript()
            })

            $(self).on('change', '.script-version', renderArgumentsForSelectedScript)

            $(self).on('click', '.save-local', function(){
                if (!$(this).closest('.include-save')) return;

                // Combine these..
                helper.update(config, $(self), config.environment)

                $.ajax({
                    type: 'PUT',
                    url: "/api/config/artifact",
                    data: JSON.stringify(config),
                    success: function(savedConfig){
                        $(document).trigger("inform.success", "Config Management successfully saved!")
                        config = savedConfig
                    },
                    dataType: "json",
                    contentType: "application/json; charset=utf-8"
                })
            })


            function renderScriptVersions(scriptName) {
                var versions = scriptVersions[scriptName]

                renderSelectInput(versions, helper.getScriptVersion(config.script), $('.script-version', self))
            }

            function renderSelectInput(items, selected, $target) {
                $target.html('<option>​</option>​')
                if (items) {
                    items.forEach(function(d) {
                        $('<option>')
                            .val(d)
                            .text(d)
                                .appendTo($target)
                    })
                }

                $target.val(selected || '').selectinput('refresh')
            }

            function renderArgumentsForSelectedScript() {
                var selectedScript = helper.getSelectedScript(scripts, self)

                if (selectedScript) {
                    var allArguments = scripts[selectedScript] || []
                    renderArgumentsHelper(allArguments)
                }
            }

        }
    }

    }
)
