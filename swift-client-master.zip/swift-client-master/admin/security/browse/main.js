define(
  [
    'jquery'
  , 'd3'
  , 'visualize/visualize'
  , '../../../utils/bootstrap'
  , 'css!./styles.css'
  ]
, function(
    $
  , d3
  , visualize
  , swift
  ) {

    'use strict'

    return function() {

      var self = this
        , renderTemplates = visualize.bind()
          .changed(function(d) {
            $('a', this).text(d).attr('href', '/swift/admin/security/edit?template=' + d)
          })

      return {
        start: swift.start
      , update: update
      , stop: swift.stop
      }

      function update(request) {
        swift.update(request)

        swift.breadcrumbs.render([
          {"title":"Security Admin"}
        ])

        $.getJSON('/api/admin/security')
          .done(function(templateIds){
            d3.select('.security')
              .datum(templateIds)
              .call(renderTemplates)

            $('.security', self).removeClass('loading')
          })
      }

    }
  }
)