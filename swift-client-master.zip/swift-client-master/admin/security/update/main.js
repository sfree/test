define(
  [
    'jquery'
  , '../../../utils/bootstrap'
  , 'css!./styles.css'
  ]
, function(
    $
  , swift
  ) {

    'use strict'

    return function() {

      var self = this

      setupListeners()

      return {
        start: swift.start
      , update: update
      , stop: swift.stop
      }

      function setupListeners() {
        $('.save', self).click(onSave)
      }

      function onSave(){
        // Using this strategy for file upload multipart data.
        var formData = new FormData($('form', self)[0]);

        swift.executeAjax($(this), $(self), function() {
          return $.ajax({
            url: '/api/admin/security',  //server script to process data
            type: 'POST',
            // Form data
            data: formData,
            //Options to tell JQuery not to process data or worry about content-type
            cache: false,
            contentType: false,
            processData: false,
            success: function(releaseUpdates) {
              $(document).trigger('inform.success', 'Security template successfully saved')
            }
          }, 'json');
        })

      }

      function update(request) {
        swift.update(request)

        swift.breadcrumbs.render([
          {"title":"Security Admin"}
        ])

        var template = request.param('template')

        // read only if updating an existing template
        $('#name', self).val(template).attr('readOnly', template).toggleClass('disabled', template)
      }

    }
  }
)