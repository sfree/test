define(
  [
    'jquery'
    , 'd3'
    , 'resourceful/address'
    , 'visualize/visualize'
    , '../../../utils/bootstrap'
    , 'css!./styles.css'
  ]
  , function(
      $
    , d3
    , address
    , visualize
    , swift
    ) {

    'use strict'

    return function() {

      var self = this
        , org
        , env

      setupListeners()

      return {
        start: swift.start
        , update: update
        , stop: swift.stop
      }

      function update(request) {
        swift.update(request)

        org = request.param('org')
        env = request.param('env')

        swift.breadcrumbs.render([
          {"title":"Organisation Admin", 'url': "/swift/admin/organisation"},
          {"title": org, 'url': "/swift/admin/organisation/edit?org=" + org},
          {"title":"Environment Admin"}
        ])

        // read only if updating an existing organisation
        $('#name', self).val(env).attr('readOnly', env).toggleClass('disabled', env)

        $('.existing-env', self).toggleClass('is-hidden', !env)

        if (env) {
          $.getJSON('/api/admin/organisation/' + org + '/environment/' + env).done(function (d) {
            $('#configuration', self).val(d.configuration)
          })
          getAgentConfig(false)
        }
      }

      function setupListeners() {
        $('.save', self).click(onSave)
        $('.cancel', self).click(onCancel)
        $('.suggest-config', self).click(onSuggestConfig)
        $('.save-agent-config', self).click(onSaveAgentConfig)
      }

      function onSave(){
        var request = { name: $('#name', self).val(), configuration: $('#configuration', self).val() }

        swift.executeAjax($(this), $(self), function() {
          return $.post('/api/admin/organisation/' + org + '/environment', JSON.stringify(request))
            .done(function(data) {
              $(document).trigger('inform.success', 'Environment config successfully saved')

              address('environmentadminedit')
                .param('org', org)
                .param('env', request.name)
                .view()
            })
        })

      }

      function onSaveAgentConfig(){
        var request = $('#agentConfiguration', self).val()
          , url = '/api/admin/organisation/' + org + '/environment/' + env + '/agent'

        swift.executeAjax($(this), $(self), function() {
          return $.post(url, JSON.stringify(request))
            .done(function(data) {
              $(document).trigger('inform.success', 'Environment agent config successfully uploaded to Zookeeper')
            })
        })

      }

      function onCancel() {
        address('organisationadminedit')
          .param('org', org)
          .view()
      }

      function onSuggestConfig() {
        getAgentConfig(true)
      }

      function getAgentConfig(suggest) {
        $.getJSON('/api/admin/organisation/' + org + '/environment/' + env + '/agent' + (suggest ? '/suggest' : ''))
          .done(function (d) {
            $('#agentConfiguration', self).val(d)
          })
      }

    }
  }
)