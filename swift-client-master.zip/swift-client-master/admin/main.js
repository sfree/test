define(
  [
    'jquery'
  , 'd3'
  , 'visualize/visualize'
  , '../d3-lookup/lookup'
  , '../d3-lookup/lookup-multiple'
  , '../utils/bootstrap'
  , 'css!./styles.css'
  ]
, function(
    $
  , d3
  , visualize
  , createLookup
  , createLookupMultiple
  , swift
  ) {

    'use strict'

    return function() {

      var self = this
        , permissionsConf = [
            {id: 'ViewLogs', name: 'View Logs', tip: 'User can view logs on specified hosts or artifacts.'},
            {id: 'ManageProcesses', name: 'Manage Processes', tip: 'Users can start, stop, redeploy processes on specifed hosts or artifacts.'},
            {id: 'Configure', name: 'Configuration', tip: 'Users can configure the specified hosts and artifacts'},
            {id: 'ViewProperties', name: 'View Properties', tip: 'Users can view zookeeper properties for the specified artifacts.'},
            {id: 'ModifyProperties', name: 'Modify Properties', tip: 'Users can modify zookeeper properties for the specified artifacts.'} ]
        , renderPermissions = visualize.bind()
            .into('span')
            .each(function(perm) {
              $(this).attr('title', perm.tip)
              $('input', this).attr('id', perm.id).attr('checked', perm.checked)
              $('label', this).attr('for', perm.id).text(perm.name)
            })
        , lookups = {}
        , groupData = {}
        , org

      setupListeners()

      return {
        start: swift.start
      , update: update
      , stop: swift.stop
      }

      function setupListeners() {
        $('.save', self).click(onSave)
        $('.reset', self).click(onReset)
      }

      function setupLookups(){
        lookups.group = createLookup()
          .label(label)
          .allowFreeTextInput(false)
          .openOnStart(true)
          .drawEmptyResults(noResults)
          .on('select', onGroupChanged)
          .on('deselect', onGroupCleared)
        lookups.environments = createLookupMultiple()
          .label(label)
          .allowFreeTextInput(false)
          .openOnStart(true)
          .on('select', onEnvironmentsChanged)
          .on('deselect', onEnvironmentsChanged)
        lookups.hosts = createLookupMultiple()
          .label(label)
          .allowFreeTextInput(false)
          .openOnStart(true)
        lookups.artifacts = createLookupMultiple()
          .label(label)
          .allowFreeTextInput(false)
          .openOnStart(true)

        $('.lookup-environments', self).attr('data-url', '/api/auth/environments?organisation=' + org)
        $('.lookup-artifacts', self).attr('data-url', '/api/lookup/artifacts/' + org)

        d3.select(self).select('.permissions').datum(permissionsConf).call(renderPermissions)

        d3.selectAll('.swift-lookup')
          .each(loadLookup)
      }

      function onSave(){
        var data = JSON.parse(JSON.stringify(groupData))
        data.artifacts = lookups
          .artifacts
          .selected()

        data.environments = lookups
          .environments
          .selected()
          .map(formatEnvironment)

        data.hosts = lookups
          .hosts
          .selected()
          .map(formatHost)

        data.permissions = $(":checked", self).map(function(i, e) { return $(e).attr('id') }).get()

        $('.save', self).addClass('loading')
        $.ajax({
          url: '/api/groups'
        , type: 'PUT'
        , data: JSON.stringify(data)
        })
        .done(function(r) {
          groupData = r
          $(document).trigger('inform.success', 'Entitlement Group data saved successfully')
        })
        .always(function(){ $('.save', self).removeClass('loading') })
      }

      function onGroupChanged(d) {
        // populate values in other lookups with this group data..
        $.getJSON('/api/groups/'+d)
          .done(function(r) {
            groupData = r.name? r : { name: d }
            onReset()
            onEnvironmentsChanged()
            d3.selectAll('.disabled-by-default')
              .attr('disabled', null)
          })
      }

      function onReset(){
        lookups.environments.selected((groupData.environments || []).concat())
        lookups.hosts.selected((groupData.hosts || []).concat())
        lookups.artifacts.selected((groupData.artifacts || []).concat())

        permissionsConf.forEach(function(d) {
          d.checked = (groupData.permissions || []).some(function(perm) { return d.id == perm })
        })

        renderAll()
      }

      function onGroupCleared() {
        // clear everything, when group cleared..
        groupData = {}
        Object
          .keys(lookups)
          .forEach(function(l){
            lookups[l].selected([])
          })
        permissionsConf.forEach(function(d) {d.checked = false})
        renderAll()
        d3.selectAll('.disabled-by-default')
          .attr('disabled', true)
      }

      function onEnvironmentsChanged() {
        // reload host options..
        var url = '/api/groups/hosts?'

        lookups.environments
            .selected()
            .forEach(addToUrl)

        if (!lookups.environments.selected().length) url = ''

        d3.select('.lookup-hosts')
          .attr('data-url', url)
          .each(loadLookup)

        function addToUrl(environment){
          url += 'environment=' + (environment.id || environment) + '&'
        }
      }

      function renderAll(){
        d3.select(self)
          .selectAll('.swift-lookup')
          .each(render)

        d3.select(self).select('.permissions').datum(permissionsConf).call(renderPermissions)
      }

      function render(){
        d3.select(this)
          .call(lookups[this.dataset.key])
      }

      function clearLookup() {
        d3.select(this)
          .datum([])
          .call(lookups[this.dataset.key])
      }

      function loadLookup(){
        var node   = d3.select(this)
          , lookup = lookups[this.dataset.key]
          , url    = this.dataset.url

        if (!url) return node.each(clearLookup)

        node.call(lookup.loading(true))

        $.getJSON(url)
          .done(function(r) {
            node
              .datum(r)
              .call(lookup.loading(false))
          })
      }

      function update(request) {
        swift.update(request)

        org = request.param('org')

        swift.breadcrumbs.render([
          {'title': org, 'url': '/swift/' + org },
          {"title":"Entitlement Groups Admin"}
        ])

        setupLookups()
      }

      function label(d) {
        return d.artifactId || d.hostname || d.name || d
      }

      function formatEnvironment(d){
        return d.name ? d : { name: d }
      }

      function formatHost(d){
        return d.hostname ? d : { hostname: d }
      }

      function noResults(d) {
        d ? d3.select(this).html("No results for <strong>" + d + "</strong>")
          : d3.select(this).html("You are not an administrator of any groups")
      }

    }
  }
)