define(
  [
    'jquery'
    , 'd3'
    , 'resourceful/address'
    , 'visualize/visualize'
    , '../../../utils/bootstrap'
    , 'css!./styles.css'
    , 'css!../../admin-styles.css'
  ]
  , function(
      $
    , d3
    , address
    , visualize
    , swift
    ) {

    'use strict'

    return function() {

      var self = this
        , org
        , renderEnvironments = visualize.bind()
          .changed(function(d) {
            var env = d
            $('a', this).text(env).attr('href', '/swift/admin/organisation/' + org + '/environment?env=' + env)
          })
        , renderTeams = visualize.bind()
          .changed(function(team) {
            $(this).text(team)
          })

      setupListeners()

      return {
        start: swift.start
        , update: update
        , stop: swift.stop
      }

      function setupListeners() {
        $('.save', self).click(onSave)
        $('.add-team', self).click(addTeam)
      }

      function onSave(){
        var request = { name: $('#name', self).val(), configuration: $('#configuration', self).val() }

        swift.executeAjax($(this), $(self), function() {
          return $.post('/api/admin/organisation', JSON.stringify(request))
            .done(function(data) {
              $(document).trigger('inform.success', 'Organisation config successfully saved')
              address('organisationadminedit')
                .param('org', request.name)
                .view()
            })
        })

      }

      function update(request) {
        swift.update(request)

        swift.breadcrumbs.render([
          {"title":"Organisation Admin", 'url': "/swift/admin/organisation"}
        ])

        org = request.param('org')

        // read only if updating an existing organisation
        $('#name', self).val(org).attr('readOnly', org).toggleClass('disabled', org)
        $('.existing-org', self).toggleClass('is-hidden', !org)

        if (org) {
          $('.add-env', self).attr('href', '/swift/admin/organisation/' + org + '/environment')

          $.getJSON('/api/admin/organisation/' + org).done(function (d) {
            $('#configuration', self).val(d.configuration)
          })

          $.getJSON('/api/config/' + org + '/environments')
            .done(function(envs){
              d3.select('.environments')
                .datum(envs)
                .call(renderEnvironments)

              $('.environments', self).removeClass('loading')
            })

          loadTeams();
        }
      }

      function loadTeams() {
        $('.teams', self).addClass('loading')

        $.getJSON('/api/teams/organisation/' + org)
          .done(function(teams){
            d3.select('.teams')
              .datum(teams)
              .call(renderTeams)

            $('.teams', self).removeClass('loading')
          })
      }

      function addTeam(){
        var team = prompt('Enter the new team name for this organisation')

        if (team) {
          swift.executeAjax($(this), $(self), function() {
            return $.post('/api/teams/organisation/' + org + '/' + team)
              .done(function(data) {
                $(document).trigger('inform.success', 'Team successfully added')

                loadTeams()
              })
          })
        }
      }

    }
  }
)
