define(
  [
    'jquery'
  , 'd3'
  , 'visualize/visualize'
  , '../../../utils/bootstrap'
  , 'css!./styles.css'
  , 'css!../../admin-styles.css'
  ]
, function(
    $
  , d3
  , visualize
  , swift
  ) {

    'use strict'

    return function() {

      var self = this
        , renderOrganisations = visualize.bind()
          .changed(function(d) {
            var org = d.name
            $('a', this).text(org).attr('href', '/swift/admin/organisation/edit?org=' + org)
          })

      return {
        start: swift.start
      , update: update
      , stop: swift.stop
      }

      function update(request) {
        swift.update(request)

        swift.breadcrumbs.render([
          {"title":"Organisation Admin"}
        ])

        $.getJSON('/api/organisations')
          .done(function(templateIds){
            d3.select('.organisations')
              .datum(templateIds)
              .call(renderOrganisations)

            $('.organisations', self).removeClass('loading')
          })
      }

    }
  }
)