define(
  ["../../utils/utilities"]
, function(utilities) {
    describe("Utilities - General", function() {

      describe("String#contains", function() {

        it("should not be able to find anything if value doesn't exist in source", function() {
          "foo".contains("bar").should.be.false
        })

        it("should be able to find something if it exists in source", function() {
          "foo".contains("foo").should.be.true
        })

      })

      describe("#px", function() {

        it("should parse a pixel value with a space", function() {
          px('23 px').should.equal(23)
        })

        it("should parse a pixel value without a space", function() {
          px('46px').should.equal(46)
        })

      })

      describe("#unique", function() {

        it("should remove duplicates", function() {
          var result = unique([1,2,3,4,3,2,1])
          result[0].should.equal(1)
          result[1].should.equal(2)
          result[2].should.equal(3)
          result[3].should.equal(4)
          result.length.should.equal(4)
        })

        it("should remove nothing", function() {
          var result = unique([7,8,6])
          result[0].should.equal(7)
          result[1].should.equal(8)
          result[2].should.equal(6)
          result.length.should.equal(3)
        })

      })

    })
})