mocha.setup({globals: ['XMLHttpRequest']})

define(
  ["swift-client/utils/ajax"]
, function(ajax) {
    describe("Utilities - AJAX", function() {

      describe("#Global AJAX Setup", function() {

        var server;

        beforeEach(function () {
          server = sinon.fakeServer.create()
          $(document).off('inform.entitlements')
          $(document).off('inform.error')
        })

        afterEach(function () {
          server.restore()
        })

        it("should have set data type to json", function() {
          // $.ajax({
          //   dataFilter: function(response, dataType){
          //     dataType.should.equal('json')
          //     done()
          //   }
          // })

          $.ajaxSetup().dataType
            .should.equal('json')
        })

        it("should set content type to application/json", function() {
          $.ajaxSetup().contentType
            .should.equal("application/json; charset=utf-8")
        })

        it("should trigger an inform message - unauthorised", function (done) {
          $(document).on('inform.entitlements', function(e, message){
            message.should.equal("ajax failed due to 401")
            done()
          })

          $.ajax()

          server.requests[0].respond(
            401,
            { "Content-Type": "application/json" },
            "ajax failed due to 401"
          )
        })

        it("should trigger an inform message - forbidden  ", function (done) {
          $(document).on('inform.entitlements', function(e, message){
            message.should.equal("ajax failed due to 403")
            done()
          })

          $.ajax()

          server.requests[0].respond(
            403,
            { "Content-Type": "application/json" },
            JSON.stringify({message: "ajax failed due to 403"})
          )
        })

        it("should trigger an inform message - fail with json", function (done) {
          $(document).on('inform.error', function(e, message){
            message.should.equal("ajax failed due to 500, json error")
            done()
          })

          $.ajax()

          server.requests[0].respond(
            500,
            { "Content-Type": "application/json" },
            JSON.stringify({message: "ajax failed due to 500, json error"})
          )
        })

        it("should trigger an inform message - fail with text", function (done) {
          $(document).on('inform.error', function(e, message){
            message.should.equal("Invalid response from server!<br>500: ajax failed due to 500, text error")
            done()
          })

          $.ajax()

          server.requests[0].respond(
            500,
            { "Content-Type": "application/json" },
            "ajax failed due to 500, text error"
          )
        })

        it("should trigger an inform message - empty", function (done) {
          $(document).on('inform.error', function(e, message){
            message.should.equal("Empty response from server! (500)")
            done()
          })

          $.ajax()

          server.requests[0].respond(
            500,
            { "Content-Type": "application/json" }
          )
        })

      })

    })
})