define([ "swift-client/utils/components/breadcrumbs" ], function(breadcrumb) {
  describe("Components - breadcrumb", function() {

    describe("#render()", function() {
      it('should update the title', function() {
        breadcrumb.render([ {"title" : "Teams","url" : "/teams"}, {"title" : "Releases","url" : "/releases"} ])

        document.title.should.equal('Swift - Teams - Releases')
      })

      it('should update the title by handle', function() {
        breadcrumb.render([ {"title" : "Teams","url" : "/teams"}, {"title" : "Releases","handle" : "my-handle"} ])

        document.title.should.equal('Swift - Teams - Releases')

        breadcrumb.updateByHandle("my-handle", "gemfire-agent", "url")

        document.title.should.equal('Swift - Teams - gemfire-agent')

      })
    })

    describe("#stop()", function() {
      it('should reset the title', function() {
        document.title = 'tests'

        breadcrumb.stop()

        document.title.should.equal('Swift')
      })
    })

  })
})