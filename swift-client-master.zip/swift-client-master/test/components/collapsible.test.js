define(
  [ 
    "text!./collapsible.html" 
  , "css!swift-client/utils/components/collapsible.css" 
  , "swift-client/utils/components/collapsible" 
  ]
, function(markup) {
    describe("Components - Collapsible", function() {

      var $container = $('<div></div>').appendTo('body')
        , $markup = $(markup)
        , collapsedHeight = 0
        , expandedHeight = 0

      describe("Normal Configuration", function() {
        var $component = $markup
              .find('.test-case-1')
              .appendTo($container)

        before(function(){ init($component) })
        after(clear)

        it("should collapse", function(done) {
          shouldCollapse($component.find('.header'), $component, done)
        })

        it("should expand", function(done) {
          shouldExpand($component.find('.header'), $component, done)
        })
      })

      describe("Minimal Configuration", function() {
        var $component = $markup
              .find('.test-case-2')

        before(function(){ init($component) })
        after(clear)

        it("should collapse", function(done) {
          shouldCollapse($component, $component, done)
        })

        it("should expand", function(done) {
          shouldExpand($component, $component, done)
        })
      })

      function shouldExpand ($header, $component, done) {
        $component.should.not.have.class('is-collapsed')
        expandedHeight.should.be.above(150)
        $header.click()
        setTimeout(function(){ 
          $component.should.have.class('is-collapsed')
          collapsedHeight = $component.height()
          collapsedHeight.should.be.below(50)
          done()
        }, 500)
      }

      function shouldCollapse ($header, $component, done) {
        $component.should.have.class('is-collapsed')
        collapsedHeight = $component.height()
        collapsedHeight.should.be.below(50)
        $header.click()
        setTimeout(function(){ 
          console.log($component.attr('class'))
          $component.should.not.have.class('is-collapsed')
          expandedHeight = $component.height()
          expandedHeight.should.be.above(150)
          done()
        }, 500)
      }

      function init($component) {
        $('html').addClass('swift-ux')
        $container.append($component)
      }

      function clear() {
        $container.empty()
      }

    })
})