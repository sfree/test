define(['../../properties/property-utils'], function (propertyUtils) {


  describe('properties.parse', function () {

    it('should handle single  property', function () {
        var str = ['prop1=simpleprop'].join('\n')
          , res = propertyUtils.parse(str)

        res.should.have.property("prop1", "simpleprop")
      }
    )

    it('should handle single line properties', function () {
        var str =
            ['prop1=simpleprop',
             'prop2=heyhey',
             'prop3=hoho'
            ].join('\n')
          , res = propertyUtils.parse(str)

        res.should.have.property("prop1", "simpleprop")
        res.should.have.property("prop2", "heyhey")
        res.should.have.property("prop3", "hoho")
      }
    )

    it('should handle multiple equals', function () {
        var str =
            ['prop1=simpleprop=hh',
             'prop2=hoho'
            ].join('\n')
          , res = propertyUtils.parse(str)

        res.should.have.property("prop1", "simpleprop=hh")
        res.should.have.property("prop2", "hoho")
      }
    )


    it('should handle spaces in property value', function () {
        var str =
            ['prop1=simpleprop h h',
             'prop2=hoho'
            ].join('\n')
          , res = propertyUtils.parse(str)

        res.should.have.property("prop1", "simpleprop h h")
        res.should.have.property("prop2", "hoho")
      }
    )

    it('should handle spaces in property name', function () {
        var str =
            ['a\\ b=hoho'
            ].join('\n')
          , res = propertyUtils.parse(str)

        res.should.have.property("a b", "hoho")
      }
    )


    it('should ignores comments', function () {
        var str =
            ['prop1=simpleprop',
             '',
             '# prop2=heyhey',
             '',
             'prop3=hoho'
            ].join('\n')
          , res = propertyUtils.parse(str)

        res.should.have.property("prop1", "simpleprop")
        res.should.have.property("prop3", "hoho")
      }
    )

    it('should handle multiline properties', function () {
        var multilineContent = [ '{',
                                 'subprop:suprop, ',
                                 'qw:vd, ',
                                 'qweg:wewe, ',
                                 '}'].join('\\\n')
          , str =
            ['prop1=simpleprop',
             'prop2=' + multilineContent,
             'prop3=hoho'
            ].join('\n')
          , res = propertyUtils.parse(str)

        res.should.have.property("prop1", "simpleprop")
        res.should.have.property("prop2", multilineContent.replace(/\\\n/g,''))
        res.should.have.property("prop3", "hoho")
      }
    )

    it('should keep multiline properties \\n if needed', function () {
        var multilineContent = [ '{',
                                 'subprop:suprop, ',
                                 'qw:vd, ',
                                 'qweg:wewe, ',
                                 '}'].join('\\\n')
          , str =
            ['prop1=simpleprop',
             'prop2=' + multilineContent,
             'prop3=hoho'
            ].join('\n')
          , res = propertyUtils.parse(str, {
            keepLineBreak: true
          })

        res.should.have.property("prop1", "simpleprop")
        res.should.have.property("prop2", multilineContent.replace(/\\/g,''))
        res.should.have.property("prop3", "hoho")
      }
    )

    it('should handle multiline properties with spaces within the value', function () {
        var multilineContent = [ '{',
                                 ' qw:vd,',
                                 '}'].join('\\\n')
          , str = 'prop2=' + multilineContent
          , res = propertyUtils.parse(str)

        res.should.have.property("prop2", multilineContent.replace(/\\\n/g,''))
      }
    )

  })
})