define(
  ['jquery'
    , 'd3'
    , 'addressable/address'
    , 'visualize/visualize'
    , '../utils/bootstrap'
    , 'css!./styles.css'
  ]
  , function ($, d3, address, visualize, swift) {

    'use strict'

    var chart = chartFactory()
      , weeksLayout = d3.layout
        .histogram()
        .range([d3.time.week.offset(new Date(), -40),
                d3.time.week(new Date())])
        .bins(40)

    return function () {
      var self = this
        , $this = $(this)
        , $activities = $this.find('.activities-container')
        , renderOrganisations = visualize.bind()
          .within($('.organisations', self).get(0))
          .into('ul')
          .each(function (d, i) {
            var d3this = d3.select(this)
              , chartContainer = d3this
                .select('.organisation-chart')

            d3this
              .select('a')
              .text(d.name)
              .attr('href', '/swift/' + d.name)

            $.getWithCache('/api/history/stats/' + d.name, function (data) {
              chartContainer
                .datum(weeksLayout.value(function (d) {
                  return d.date
                })(data))
                .call(chart)
            })
          })

      return {
        update: update,
        start: swift.start,
        stop: swift.stop
      }

      function update(request) {
        swift.update(request)
        $.getJSON('/api/organisations').done(renderOrganisations)
        address('activities').view($activities)
        address('releases')
          .param('myteams', true)
          .view('.releases-feed-container')
      }
    }

    function chartFactory() {
      var x = d3.scale.linear()
        , y = d3.scale.linear()

      return function () {
        this.each(render)
      }

      function render(data) {
        var d3this = d3.select(this)
          , height = d3this.style('height')
          , width = d3this.style('width')

        x.domain(d3.extent(data, pluck('x')))
          .range([0, parseInt(width)])
        y.domain([0, d3.max(data.map(pluck('y')))])
          .rangeRound([0, parseInt(height) ])

        var svg = d3this.select('svg')
        if (svg.empty()) svg = d3this.append('svg')

        var rects = svg
          .selectAll('rect')
          .data(data)

        rects.enter().append('rect')
        rects.exit().remove()

        rects
          .attr('width', function (d) {
            return x(d.x + d.dx) - x(d.x)
          })
          .attr('height', function (d) {
            return y(d.y)
          })
          .attr('y', function (d) {
            return -y(d.y)
          })
          .attr('transform', 'translate(0,' + parseInt(height) + ')')
          .attr('fill-opacity', 0)

        rects
          .transition()
          .duration(200)
          .delay(function (d, i) {
            return i * 15
          })
          .attr('fill-opacity', 1)
          .attr('x', function (d) {
            return x(d.x)
          })
      }

      function pluck(k) {
        return function (obj) {
          return obj[k]
        }
      }
    }
  }
)