define([
  'd3',
  'jquery',
  '../utils/components/pagination',
  './util',
  'css!./pagination.css'
], function (d3, $, paginationFactory, activityUtil) {
  'use strict'

  return function () {
    var d3this = d3.select(this)
      , pagination = paginationFactory()

    return {
      update: update
    }

    function update(req) {
      var maxPages = this.parentNode.dataset.maxPages || 10
        , dataSource = activityUtil.makeDataSource(req.param)

      $.getJSON(dataSource).done(function (data) {
        var start = parseInt(req.param('start') || 0)
          , perPage = data.requestFilter.records
          , totalPages = Math.ceil(data.totalRecords / perPage)
          , currentPage = (start / perPage) + 1
          , uri = req.uri + (~req.uri.toString().indexOf('?') ? '&' : '?')
          , urls = d3.range(totalPages).map(function (i) {
            return uri + 'start=' + i * perPage
          })

        d3this
          .datum(urls)
          .call(
            pagination
              .maxPages(maxPages)
              .currentPage(currentPage)
          )
      })
    }
  }
})