define([
  'd3',
  'jquery',
  'visualize/visualize',
  'addressable/address',
  'moment',
  './util',
  'css!./list.css'
], function (d3, $, visualize, address, moment, activityUtil) {
  'use strict'
  var render = visualize.bind()
      .into('.activities')
      .key(function (d) {
        return d.id
      })
      .each(renderActivity)

  return function () {
    var $this = $(this)

    return {
      update: update
    }

    function update(req) {
      var dataSource = activityUtil.makeDataSource(req.param)

      $this.toggleClass('is-loading', true)

      $.getJSON(dataSource)
        .always(function () {
          $this.toggleClass('is-loading', false)
        })
        .done(function (data) {
          render.into($this.get(0))
          render(data.pageResults ? data.pageResults : data)
        })
    }
  }

  function renderActivity(d, i) {
    $('.activity-text', this).html(formatActivity(d))
    $('time', this).text(moment(+d.timestamp).fromNow())
    $('.user-profile-container', this).each(function () {
      address('users')
        .param({'guid': d.user})
        .view(this)
    })

    var subitems = []
    if (d.data) {
      if (d.data.artifactsAdded && d.data.artifactsAdded.length) {
        subitems = subitems.concat(
          d.data.artifactsAdded.map(function (el) {
            return {
              text: el.artifactId
                + ' (' + el.version + ')', icon: 'add'
            }
          })
        )
      }

      if (d.data.artifactsRemoved && d.data.artifactsRemoved.length) {
        subitems = subitems.concat(
          d.data.artifactsRemoved.map(function (el) {
            return {
              text: el.artifactId
                + ' (' + el.version + ')', icon: 'remove'
            }
          })
        )
      }

      if (d.data.releaseLinksAdded && d.data.releaseLinksAdded.length) {
        subitems = subitems.concat(
          d.data.releaseLinksAdded.map(function (el) {
            return {
              text: el.type
                + ': ' + el.pointer, icon: 'add'
            }
          })
        )
      }
     
      if (d.data.releaseLinksRemoved && d.data.releaseLinksRemoved.length) {
        subitems = subitems.concat(
          d.data.releaseLinksRemoved.map(function (el) {
            return {
              text: el.type
                + ': ' + el.pointer, icon: 'remove'
            }
          })
        )
      }

      if (d.data.propertiesAdded && d.data.propertiesAdded.length) {
        subitems = subitems.concat(
          d.data.propertiesAdded.map(function (el) {
            return {
              text: el, icon: 'add'
            }
          })
        )
      }

      if (d.data.propertiesRemoved && d.data.propertiesRemoved.length) {
        subitems = subitems.concat(
          d.data.propertiesRemoved.map(function (el) {
            return {
              text: el, icon: 'remove'
            }
          })
        )
      }
      if (d.data.propertiesModified && d.data.propertiesModified.length) {
        subitems = subitems.concat(
          d.data.propertiesModified.map(function (el) {
            return {
              text: el, icon: 'change'
            }
          })
        )
      }

      if (d.data.oldReleaseName) subitems.push({
        text: 'renamed from "' + d.data.oldReleaseName + '"', icon: 'change'
      })

      if (d.data.descriptionChanged) subitems.push({
        text: 'description modified', icon: 'change'
      })

      if (d.data.releaseDateChanged) subitems.push({
        text: 'release date changed from ' + (d.data.oldReleaseDate && moment(+d.data.oldReleaseDate).format('DD.MM.YYYY')) + ' to ' + (d.data.newReleaseDate && moment(+d.data.newReleaseDate).format('DD.MM.YYYY')), icon: 'change'
      })
    }
    visualize.bind()
      .into($('.children-container', this).get(0))
      .each(function (d) {
        $(this)
          .text(d.text)
          .addClass(d.icon)
      })(subitems)

    if (!subitems.length) $(this)
      .removeClass('collapsible')
      .removeClass('collapsible-header')
  }

  function formatPropsTooltip(d) {
    var output = ""
    if (d.data.propertiesAdded.length > 0) output += "Properties added: " + d.data.propertiesAdded.join(", ") + "\n"
    if (d.data.propertiesModified.length > 0) output += "Properties changed: " + d.data.propertiesModified.join(", ") + "\n"
    if (d.data.propertiesRemoved.length > 0) output += "Properties removed: " + d.data.propertiesRemoved.join(", ") + "\n"
    return output
  }

  function formatActivity(d) {
    var output = ''
      , org = ''
      , envStatusLink = ''

    if (d.environment) {
      org = d.environment ? d.environment.organisation.name : ''
      envStatusLink = '<a href="/swift/' + org + '/status?environment=' + d.environment.name + '">' + d.environment.name.toUpperCase() + '</a>'
    }
    if (d.data) {
      switch (d.type) {
        case "DEPLOYMENT":
          var rlsLink = "<a href=\"/swift/release/" + d.objectId + "\">" + d.data.releaseName + "</a>"
          output += d.data.planId ? "<a href=\"/swift/release/history/" + d.data.planId + "\">" : ""
          switch (d.data.type) {
            case "Manual":
              output += "will manually deploy"
              break
            case "Rollback":
              switch (d.data.status) {
                case "COMPLETED":
                  output += "successfully rolled back" // TODO: link to addressable view of a specific deployment history
                  break
                case "CANCELLED":
                  output += "cancelled a rollback of" // TODO: as above
                  break
                case "FAILED":
                  output += "failed to roll back" // TODO: as above
                  break
              }
              break
            case "Release":
            default:
              switch (d.data.status) {
                case "COMPLETED":
                  output += "successfully deployed"
                  break
                case "CANCELLED":
                  output += "cancelled a deployment of"
                  break
                case "FAILED":
                  output += "failed to deploy"
                  break
              }
              break
          }
          output += d.data.planId ? "</a> " : " "
          output += rlsLink + " in " + envStatusLink
          break

        case "RELEASE":
          var rlsTooltip = ""
          switch (d.verb) {
            case "CREATE":
              output += "created "
              break
            case "MODIFY":
              if (d.data.lockedUnlocked != null) {
                output += d.data.lockedUnlocked == true ? "locked " : "unlocked "
              } else {
                output += "modified "
                if (d.data.oldReleaseName) rlsTooltip += "Release renamed from '" + d.data.oldReleaseName + "' to '" + d.data.releaseName + "'\n"
                if (d.data.descriptionChanged) rlsTooltip += "Description changed" + "\n"
                if (d.data.releaseDateChanged) rlsTooltip += "Release date changed from " + (d.data.oldReleaseDate && moment(+d.data.oldReleaseDate).format("DD.MM.YYYY")) + " to " + (d.data.newReleaseDate && moment(+d.data.newReleaseDate).format("DD.MM.YYYY")) + "\n"
                if (d.data.artifactsAdded.length > 0 || d.data.artifactsRemoved.length > 0) {
                  var artTooltip = ""
                  var printArtifact = function (e) {
                    artTooltip += e.groupId + " - " + e.artifactId + " - " + e.version + "\n"
                  }
                  if (d.data.artifactsAdded.length > 0) {
                    artTooltip += "Artifacts added:\n"
                    d.data.artifactsAdded.forEach(printArtifact)
                  }
                  if (d.data.artifactsRemoved.length > 0) {
                    artTooltip += "Artifacts removed:\n"
                    d.data.artifactsRemoved.forEach(printArtifact)
                  }
                  rlsTooltip += artTooltip
                }
                // Check for the existence of releaseLinksAdded and releaseLinksRemoved for backward compatibility
                if (d.data.releaseLinksAdded && d.data.releaseLinksRemoved && 
                    (d.data.releaseLinksAdded.length > 0 || d.data.releaseLinksRemoved.length > 0)) {
                  var artTooltip = ""
                  var printReleaseLink = function (e) {
                    artTooltip += e.type + ": " + e.pointer + "\n"
                  }
                  if (d.data.releaseLinksAdded.length > 0) {
                    artTooltip += "Release Links added:\n"
                    d.data.releaseLinksAdded.forEach(printReleaseLink)
                  }
                  if (d.data.releaseLinksRemoved.length > 0) {
                    artTooltip += "Release Links removed:\n"
                    d.data.releaseLinksRemoved.forEach(printReleaseLink)
                  }
                  rlsTooltip += artTooltip
                }
              }

              break
          }
          var rlsLink = '<a title="' + rlsTooltip + '" href="/swift/release/' + d.objectId + '?timestamp=' + d.lastUpdatedTime + '">' + d.data.releaseName + '</a>'
          output += "release " + rlsLink
          break

        case "PROPERTIES":
          var artStatusLink = '<a href="/swift/' + org + '/status?environment=' + d.environment.name + '&group=' + d.data.artifact.groupId + '&artifact=' + d.data.artifact.artifactId + '&version=' + d.data.artifact.version + '">' + d.data.artifact.artifactId + ' ' + d.data.artifact.version + '</a>'
          var propTooltip = ""
          switch (d.verb) {
            case "CREATE":
              output += "created "
              break
            case "MODIFY":
              output += "modified "
              break;
          }
          var propLink = '<a title="' + formatPropsTooltip(d) + '" href="/swift/' + org + '/properties/' + d.environment.name + '?group=' + d.data.artifact.groupId + '&artifact=' + d.data.artifact.artifactId + '&version=' + d.data.artifact.version + '">properties</a>'

          output += propLink + " for " + artStatusLink + " in " + envStatusLink
          break

        case "PROPERTY_DEFAULTS":
          output += 'modified the <a href="/swift/' + org + '/defaults/' + d.environment.name + '" title="' + formatPropsTooltip(d) + '">property defaults</a> for ' + envStatusLink
          break
      }
    } else {
      // Fallback case when data==null, just return basic output
      output += d.verb + ' ' + d.type + ' ' + d.objectId
    }
    return output
  }

})