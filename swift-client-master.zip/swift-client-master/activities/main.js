define([
  'd3',
  'jquery',
  'addressable/address',
  '../utils/bootstrap',
  '../utils/url-maker',
  'css!./styles.css'
], function (d3, $, address, swift, urlMaker) {
  'use strict'

  return function () {
    var $this = $(this)
      , $filters = $this.find('.activities-filter')

    return {
      start: start,
      update: update,
      stop: swift.stop
    }

    function start() {
      swift.start()
      $filters.on('change submit', function (e) {
        address.submit(this)
        e.preventDefault()
      })
    }

    function update(req) {
      var env = req.param('environment')
        , org = req.param('org')
        , type = req.param('type')
        , records = req.param('records')
        , activities = address('activities').param(req.param())

      swift.breadcrumbs.render([
        {'title': org, 'url': '/swift/' + org },
        {'title': 'Activities'}
      ])
      swift.update(req)

      $this.find('form').attr('action', urlMaker(req.param()))
      $this.find('select[name="type"]')
        .val(type)
        .selectinput()
      $this.find('select[name="records"]')
        .val(records)
        .selectinput()
      $.getWithCache('/api/config/' + org + '/environments', refreshEnvironmentsSelect.bind(null, env))

      activities.view('.activities-container')
      activities.view('.activities-pagination-container')

      $(document).scrollTop(0)
    }

    function refreshEnvironmentsSelect(currentEnv, envs) {
      envs = [
        {text: 'All', value: ''}
      ].concat(envs)

      $this.find('select[name="environment"]')
        .html(makeOptions(envs, currentEnv))
        .selectinput('refresh')
    }
  }

  function makeOptions(opts, selected) {
    return opts.map(function (opt) {
      if (typeof  opt == 'string') opt = { text: opt, value: opt}

      return $('<option>', {
        text: opt.text,
        val: opt.value,
        selected: opt.value == selected
      })
    })
  }
})