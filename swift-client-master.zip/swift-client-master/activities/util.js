define([
  'jquery',

], function ($) {

  'use strict'

  var BASE_URL = '/api/activity'

  return { makeDataSource : makeDataSource}

  function makeDataSource(param) {
  	// Note the conversion of releaseId because resourceful converts all parameters to lower case.  This is a 
  	// hack until HTML/resourceful/issues/127 is fixed.
    var paramMap = param()
      , queryString = $.param($.extend({organisation: paramMap.org, releaseId: paramMap.releaseid}, paramMap))

    return BASE_URL + (queryString && ('?' + queryString) || '')
  }

})