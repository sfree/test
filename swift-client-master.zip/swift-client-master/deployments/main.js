define(
  [
    "jquery"
  , "../utils/charts/bar-chart"
  , "css!./styles.css"
  ],
function(
    $
  , barChart
  ) {
    return function() {

      var self = this

      function update(req) {
        $.getWithCache('/api/history/stats/' + req.param('org'))
          .done(function(data) {

            swiftHomeChart = barChart()
              .width(740)
              .height(160)
              .series(byEnvironment)
              .on('change', onChange)

            d3.select(self).html('')
              .datum(data)
              .call(swiftHomeChart)

            function byEnvironment(d) {
              return d.environment
            }

            function onChange (d) {
              var duration = 4
              if (d == 7) duration = '1w'
              if (d == 30) duration = '1m'
              if (d == 90) duration = '3m'
              if (d == Infinity) duration = 'ALL'
              $(self).trigger('duration', duration)
            }
          })
      }

      return update

    }
  }
)