define(
  [  'jquery'
    , 'resourceful/address'
    , '../utils/utilities'
    , 'css!./styles.css'
  ]
  , function ($, address) {

    var BASE_URL = '/api/user/profiles'
      , BATCH_DELAY_MS = 250
      , BATCH_GRACE_MS = 40
      , gProfilesDictCache = {}
      , gCurrBatchIdx = 0
      , gReqsInBatch = [[]]
      , gTimerRefs = []

    return function () {
      var $this = $(this)
        , $fullName = $this.find('.user-fullname')

      return function(req){

        function enrichNode($node, str) {
          $node.html(str)
        }

        function addToCache(profileData) {
          if (profileData && profileData.guid) {
            gProfilesDictCache[profileData.guid] = profileData
          }
        }

        function makeSimplisticCache(guid) {
          var simplisticProfile = {guid: guid, businessName: guid}
          addToCache(simplisticProfile)
        }

        function enrichFromCache($node, guid) {
          var cacheProfile = gProfilesDictCache[guid]

          if (cacheProfile) {
            var displayText = cacheProfile.businessName ? cacheProfile.businessName : cacheProfile.guid
            enrichNode($node, displayText)
            return true
          }

          return false
        }

        function enrichNodesInBatch(batchIdx) {
          var requests = gReqsInBatch[batchIdx]

          requests.forEach(function(obj) {
            enrichFromCache(obj.node, obj.guid)
          })
        }

        function extractUniqueGuids(batchIdx) {
          var requests = gReqsInBatch[batchIdx]
           ,  uniqueGuids = unique(requests.map(function(obj) {return obj.guid}))

           return uniqueGuids
        }

        function lookupOneGuidForBatch(guid, batchIdx) {
          var qs = 'guid=' + guid
          $.getJSON(BASE_URL + '?' + qs)
            .done(function (data) {
              addToCache(data[0])
            })
            .fail(function() {
              // add the GUID to the cache to save future similar lookups that are bound to fail
              makeSimplisticCache(guid)
            })
            .always(function() {
              enrichNodesInBatch(batchIdx)
            })
        }

        function sendAjaxIndividually(batchIdx) {
          extractUniqueGuids(batchIdx).forEach(function(guid) {
            lookupOneGuidForBatch(guid, batchIdx)
          })
        }

        function sendBatchAjax(batchIdx) {
          var requests = gReqsInBatch[batchIdx]
           ,  uniqueGuids = extractUniqueGuids(batchIdx)
           ,  qs = $.param({'guid': uniqueGuids}, true)

          $.getJSON(BASE_URL + '?' + qs)
            .done(function(data) {
              data.forEach(function(datum) {
                addToCache(datum)
              })
              enrichNodesInBatch(batchIdx)
            })
            .fail(function() {
              // The batch request can fail when only one of the GUID's cannot be looked up.
              if (uniqueGuids.length > 1) {
                sendAjaxIndividually(batchIdx)
              } else {
                // there's only one unique query in this batch. No need to retry.
                makeSimplisticCache(requests[0].guid)
                enrichNodesInBatch(batchIdx)
              }
            })
        }

        function onTimeout(batchIdx) {
          gReqsInBatch[++gCurrBatchIdx] = []
          // delay the actual sending of the JSON batch request just in case
          // some request is in the middle of joining this batch
          setTimeout(sendBatchAjax, BATCH_GRACE_MS, batchIdx)
        }

        function addToBatchRequest(guid, $node) {
          var idx = gCurrBatchIdx
          gReqsInBatch[idx].push({guid: guid, node: $node})

          if (gTimerRefs[idx] === undefined) {
            gTimerRefs[idx] = setTimeout(onTimeout, BATCH_DELAY_MS, idx)
          }
        }

        var guid = req.param().guid
        if (! enrichFromCache($fullName, guid)) {
          addToBatchRequest(guid, $fullName)
        }

        if ($this.is('.user-profile-full')) {
          address('users')
            .param(req.param())
            .view($this.find('figure.user-profile-container'))
        }
      }
    }
  }
)
