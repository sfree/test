define(
  [ 'jquery'
  , 'd3'
  , 'visualize/visualize'
  , 'resourceful/address'
  , '../utils/bootstrap'
  , 'css!./styles.css'
  , 'css!../styles.css'
  ], function($, d3, visualize, address, swift) {

    'use strict'

    return function() {

      var rendered = false
      ,   self = this
      ,   $environmentsContainer = $('.environments-container', self)
      ,   environment
      ,   org
      ,   newRow = $('.prototype.property', this).clone(true)
      ,   renderProperties = visualize.bind()
          .into('.properties')
          .each(function(d){
            $('.key input', this).val(d.key)
            $('.value input', this).val(d.value)
          })

      setupListeners()

      return {
        start: start
        , update: update
        , stop: stop
      }

      function start() {
        $('html').addClass('swift-ux')
        swift.breadcrumbs.render([{'title':'Environments'}, {'title':'Environment Defaults'}])
      }

      function update(req) {
        swift.update(req)

        environment = req.param('environment')
        org = req.param('org')

        address('environments')
          .param('environment', environment)
          .param('org', org)
          .view($environmentsContainer.get(0))

        if (environment) {
          loadEnvironmentDetails()

          $(document).trigger('auth', [org, environment])
        }

      }

      function stop() {
        swift.breadcrumbs.stop()
        $('html').removeClass('swift-ux')
      }

      function setupListeners() {
        $environmentsContainer.on('environment-changed', function(e, data) {
          showEnvironment(data)
        })

        $environmentsContainer.on('environments-loaded', function(e, data) {
          // if no environment selected, default to the first.
          if (!environment) {
            showEnvironment(data[0])
          }
        })

        $(self).on('click', '.delete', function(){
          $(this.parentNode).remove()
        })

        $('#add', self).on('click', function() {
          $('.properties').append(newRow.clone())
        })

        $('#save', self).on('click', saveClicked)
      }

      function saveClicked() {
        var update = []
        $('.property').each(function() {
          var k = $('.key input', this).val()
          var v = $('.value input', this).val()
          if (k) {
              update.push({ key: k, value: v })
          }
        })

        $.ajax({
          url: '/api/properties/defaults/' + org + '/' + environment
        , type: 'PUT'
        , data: JSON.stringify(update)
        })
        .done(function(r) {
          $(document).trigger('inform.success', 'Default properties have been saved')
        })
      }

      function showEnvironment(env) {
        address('defaults')
          .param('org', org)
          .param('environment', env)
          .view()
      }

      function loadEnvironmentDetails() {
        $.getJSON('/api/properties/defaults/' + org + '/' + environment)
          .success(renderProperties)
      }

    } // end resource factory function
  } // end amd
) // end define