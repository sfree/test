define(
  [ 'jquery'
  , 'd3'
  , 'visualize/visualize'
  , 'resourceful/address'
  , '../utils/bootstrap'
  , 'grid/grid'
  , 'grid-plugins/sorting'
  , 'css!grid/styles.css'
  , 'css!./styles.css'
  , 'css!../styles.css'
  ], function($, d3, visualize, address, swift, grid, sorting) {

    'use strict'

    return function() {
      var NUMERICAL = 'numerical'
      ,   CRITICAL = 'critical'
      ,   WARNING = 'warning'
      ,   columns =
          [
            {key: 'agentUp', headerRenderer: 'Status', renderer: statusCellRenderer(), accessor: function(d) { return function() { return d} }, headerHeight : 35, width: '65px', sortDirection:'asc', sortPriority:1, sortFunction: sort(agentStatusSortable)},
            {key: 'host', headerRenderer: 'Host', width: '125px'},
            {key: 'agentVersion', headerRenderer: 'Version', width: '75px'},
            {key: 'runningUser', headerRenderer: 'User', renderer: tooltipRenderer(), width: '75px'},
            {key: 'load0', headerRenderer: numberHeader('Load 0'), renderer: cellRenderer(loadCheck, NUMERICAL, extractRoundedFloat), width: '75px', sortFunction: sort(extractFloat)},
            {key: 'load1', headerRenderer: numberHeader('Load 1'), renderer: cellRenderer(loadCheck, NUMERICAL, extractRoundedFloat), width: '75px', sortFunction: sort(extractFloat)},
            {key: 'load2', headerRenderer: numberHeader('Load 2'), renderer: cellRenderer(loadCheck, NUMERICAL, extractRoundedFloat), width: '75px', sortFunction: sort(extractFloat)},
            {key: 'memFreeMb', headerRenderer: numberHeader('MemFree mb'), renderer: cellRenderer(memCheck, NUMERICAL, formatFloat), width: '100px', sortFunction: sort(extractFloat)},
            {key: 'memFreePercent', headerRenderer: numberHeader('MemFree %'), renderer: cellRenderer(percentCheck, NUMERICAL), sortFunction: sort(extractFloat)},
            {key: 'swapFreeMb', headerRenderer: numberHeader('SwapFree mb'), renderer: cellRenderer(memCheck, NUMERICAL, formatFloat), width: '100px', sortFunction: sort(extractFloat)},
            {key: 'swapFreePercent', headerRenderer: numberHeader('SwapFree %'), renderer: cellRenderer(percentCheck, NUMERICAL), sortFunction: sort(extractFloat)},
            {key: 'prism', headerRenderer: 'Prism', renderer: prismLink, accessor: function(data) { return function() { return data.host } }, width: '50px'}
          ]
      ,   statusGridNode = $('.host-status-grid', this)
      ,   statusGrid = grid()
            .register(sorting)
            .rowHeight(35)
            .columns(columns)
            .node(statusGridNode)
      ,   self = this
      ,   $environmentsContainer = $('.environments-container', self)
      ,   org
      ,   environment
      ,   memFormat = new Intl.NumberFormat('en', {maximumFractionDigits: 0})

      setupListeners()

      return {
        start: start
        , update: update
        , stop: stop
      }

      function start() {
        $('html').addClass('swift-ux')
        swift.breadcrumbs.render([{'title':'Environments'}, {'title':'Host Status'}])
      }

      function update(req) {
        swift.update(req)

        environment = req.param('environment')
        org = req.param('org')

        address('environments')
          .param('environment', environment)
          .param('org', req.param('org'))
          .view($environmentsContainer.get(0))

        if (environment) {
          loadEnvironmentDetails()
        }
      }

      function stop() {
        swift.breadcrumbs.stop()
        $('html').removeClass('swift-ux')
      }

      function setupListeners() {
        $environmentsContainer.on('environment-changed', function(e, data) {
          showEnvironment(data)
        })

        $environmentsContainer.on('environments-loaded', function(e, data) {
          // if no environment selected, default to the first.
          if (!environment) {
            showEnvironment(data[0])
          }
        })
      }

      function loadEnvironmentDetails() {
        $.getJSON('/api/host/' + org + '/' + environment)
          .success(renderHostStatus)
      }

      function showEnvironment(env) {
        address('hoststatus')
          .param('org', org)
          .param('environment', env)
          .view()
      }

      function cellRenderer(healthFunction, cellClass, valueFunction) {
        return function(data) {
          var status = data === undefined ? '' : healthFunction(data)

          var cellValue = valueFunction ? valueFunction(data) : data

          var node = d3.select(this)
             .text(cellValue)
             .classed(CRITICAL, status == CRITICAL)
             .classed(WARNING, status == WARNING)

          if (cellClass) node.classed(cellClass, true)
        }
      }

      function tooltipRenderer() {
        return function(data) {
          var node = d3.select(this)
             .text(data)
             .attr('title', data)
        }
      }

      function statusCellRenderer() {
        return function(data) {
          var node = $(this).html('<i class="status"></i>')
          $('i', this).attr('data-state', getAgentStatus(data))
        }
      }

      function getAgentStatus(data) {
        var state = 'ERROR'

        if (data.agentUp) {
          state = 'OK'

          if (!data.monitorUp ||
              highLoadWarning(data) ||
              lowMemoryWarning(data)) state = 'WARNING'

        }

        return state
      }

      function lowMemoryWarning(data) {
        return data.monitorUp &&
              (memCheck(data.memFreeMb) ||
              memCheck(data.swapFreeMb) ||
              percentCheck(data.memFreePercent) ||
              percentCheck(data.swapFreePercent))
      }

      function highLoadWarning(data) {
        return data.loadAverages && data.loadAverages.some(loadCheck)
      }

      function agentStatusSortable(data) {
        switch (getAgentStatus(data)) {
          case 'ERROR': return 2
          case 'WARNING': return 1
          default: return 0
        }
      }

      function percent(a, b) {
        if (a && b) return Math.round((a / b) * 100) + '%'
      }

      function numberHeader(label) {
        return '<div class="numerical header">' + label + '</div>'
      }

      function percentCheck(percentFree) {
        if (extractFloat(percentFree) < 5) return CRITICAL
        else if (extractFloat(percentFree) < 10) return WARNING
      }

      function loadCheck(load) {
        if (load > 5) return CRITICAL
        else if (load > 2) return WARNING
      }

      function memCheck(data) {
        var memMb = parseInt(data)

        if (memMb != 0) {
          if (memMb < 100) return CRITICAL
          else if (memMb < 200) return WARNING
        }
      }

      function renderHostStatus(data) {
        // grid data
        data.forEach(function(d) {
          if (d.loadAverages) {
            d.load0 = d.loadAverages[0]
            d.load1 = d.loadAverages[1]
            d.load2 = d.loadAverages[2]
          }

          d.memFreePercent = percent(d.memFreeMb, d.memTotalMb)
          d.swapFreePercent = percent(d.swapFreeMb, d.swapTotalMb)
        })
        statusGrid.data(data)

        // summary stats
        stat(data, '.agents-down', function (d) { return !d.agentUp })
        stat(data, '.high-load', highLoadWarning)
        stat(data, '.low-memory', lowMemoryWarning)
      }

      function stat(data, target, filterFunc) {
        var statCount = data.filter(filterFunc).length

        $(target, this).text(statCount).toggleClass('healthy', statCount == 0)
      }

      function sort(extract) {
        return function(a,b) {
          return extract(a) - extract(b)
        }
      }

      function extractKb(text) {
        if (!text || text.length == 0) return 0

        return parseInt(text, 10)
      }

      function extractRoundedFloat(text) {
        if (!text || text.length == 0) return 

        return parseFloat(text).toFixed(2)
      }

      function extractFloat(text) {
        if (!text || text.length == 0) return 0        
        return parseFloat(text)
      }

      function commas(str) {
        return (str + '').replace(/.(?=(?:.{3})+$)/g, '$&,');
      }

      function formatFloat(text) {
        if (!text || text.length == 0 || text == '0') return

        return commas(text)
      }

      function prismLink(host) {
        d3.select(this)
          .html('<a>Prism</a>')
          .select('a')
          .attr('target', '_blank')
          .attr('href', 'http://prism.swissbank.com/host/index.html?host=' + host)
      }
    } // end resource factory function

  } // end amd
) // end define
