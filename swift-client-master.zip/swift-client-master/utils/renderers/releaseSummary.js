;define(
  [
    'jquery'
  , 'resourceful/address'
  , 'moment'
  , '../components/breadcrumbs'
  ]
, function(
    $
  , address
  , moment
  , breadcrumbs
  ) {

    'use strict'

    return renderReleaseSummary

    function renderReleaseSummary(release, revision) {
      $.getJSON('/api/release/' + release + '/summary')
        .done(function(data){
          $('.release-summary .team').text(data.team.name)
          $('.release-summary .release').text(data.name)
          $('.release-summary .release-date').text(
            data.releaseDate
              ? moment(+data.releaseDate)
                  .format('DD-MMM-YYYY')
              : 'None'
          )
          $('.release-summary .last-updated-date').text(
            moment(+data.lastUpdatedTime)
              .format('DD-MMM-YYYY')
          )
          var lastUpdatedBy = $('.release-summary .last-updated-by')
          if(lastUpdatedBy.length){
            address('users')
              .param({'guid': data.lastUpdatedBy})
              .view(lastUpdatedBy.get(0))
          }
          breadcrumbs.updateByHandle(
            'release'
          , data.name
          , '/swift/release/' + release + (revision?'?revision='+revision:'')
          )
        })
    }
  }
)