define(function () {

  return function (params) {
    var keys = Object.keys(params)

    return function (i, val) {
      return make(val)
    }

    function make(url) {
      // Do not introduce a url if one didn't exist as this breaks functional <a> tags
      // with js handlers because the page refreshes due to <a href=''>.
      if (!url) return
      return keys.reduce(function (prev, param) {
        var val = params[param]
        return prev.replace(':' + param, val)
      }, url)
    }
  }
})