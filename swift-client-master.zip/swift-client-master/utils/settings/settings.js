;define(
  [
    'jquery'
  , 'd3'
  , '../../d3-lookup/lookup-multiple'
  , 'css!./styles.css'
  , 'css!../lookup-neo-theme.css'
  ]
, function(
    $
  , d3
  , createLookupMultiple) {

    'use strict'

    /**************
      This resource allows users to configure which teams they are a part of.

      @stephelu
    **************/

    return function(){
      var teamsLookup = createLookupMultiple()
            .allowFreeTextInput(false)
        , teamsLookupNode = d3.select(this)
            .select('.lookup-teams')
            .call(teamsLookup)
        , $self = $(this)
        , teamsMap

      $('.settings-save', $self).click(saveSettings)

      return update

      function saveSettings() {
        var selected = teamsLookup.selected()
          , selectedIds = selected.map(function(d) { return teamsMap[d] })

        $.ajax({
          type: 'PUT'
        , data: JSON.stringify(selectedIds)
        , url: '/api/teams/user'
        }).done(function() {
          $(document).trigger(
            'inform.success'
          , 'User settings successfully saved.')
          $self.removeClass('is-open')
          $(document).trigger('settings.saved')
        })
      }

      function update(req) {
        $('.settings', $self).addClass('loading')

        $.getJSON('/api/teams/user')
          .done(function(teams){
            teams = teams.map(teamName)

            teamsLookup.selected(teams)
            teamsLookupNode.call(teamsLookup)

            $('.settings', $self).removeClass('loading')
          })

        $.getJSON('/api/teams')
          .done(function(teams){
            // TODO d3-lookup needs to support id / value so I can remove this
            var teamNames = []
            teamsMap = {}

            teams.forEach(function(t) {
              teamsMap[teamName(t)] = t.id
              teamNames.push(teamName(t))
            })

            teamsLookupNode
              .datum(teamNames)
              .call(teamsLookup)
          })

        $self.addClass('is-open')
      }

      function teamName(t) {
        return t.organisation.name + '/' + t.name
      }
    }
  }
)
