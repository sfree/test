define(['d3'], function (d3) {

  /*
   * Usage :
   *
   * d3.select(elem)
   *   .datum(['/myUrl?page=1','/myUrl?page=2'])
   *   .call(pagination())
   * */

  return function pagination() {
    var currentPage = 0
      , maxPages = 20
      , sidePages = 2

    var self = function () {
      this.each(function (data) {
        var totalPages = data.length
          , currentIndex = currentPage - 1
          , ranges = makeRanges(currentPage, totalPages)
          , d = [].concat(
            {
              text: '◀',
              href: data[currentIndex - 1],
              disabled: currentIndex == 0
            },
            ranges.reduce(function (res, range) {
              return res.concat(
                range.length ?
                d3.range.apply(null, range).map(function (pageIndex) {
                  return pageData(pageIndex, data[pageIndex - 1])
                }) :
                ellipsis()
              )
            }, []),
            {
              text: '▶',
              href: data[currentIndex + 1],
              disabled: currentPage >= data.length
            }
          )

        render.call(this, d)
      })
    }

    self.currentPage = function (arg) {
      if (!arguments.length) return currentPage
      currentPage = arg
      return self
    }

    self.maxPages = function (arg) {
      if (!arguments.length) return maxPages
      maxPages = arg
      return self
    }

    self.sidePages = function (arg) {
      if (!arguments.length) return sidePages
      sidePages = arg
      return self
    }

    return self

    function render(data) {
      var buttons = d3.select(this)
        .selectAll('a.btn')
        .data(data)

      buttons.enter()
        .append('a')
        .classed('btn', true)

      buttons.exit().remove()
      buttons
        .classed('is-active', function (d) {
          return d.selected
        })
        .text(function (d) {
          return d.text
        })
        .attr('disabled', function (d) {
          return d.disabled ? 'disabled' : undefined
        })
        .attr('href', function (d) {
          return d.disabled ? 'javascript: void(0);' : d.href
        })
    }

    function ellipsis() {
      return  { text: '...', href: '', disabled: true }
    }

    function pageData(index, uri) {
      return  {
        text: index,
        href: uri,
        selected: currentPage == index
      }
    }

    function makeRanges(currentPage, totalPages) {
      var maxRange = totalPages + 1

      if (totalPages <= maxPages) {
        return [
          [1, maxRange]
        ]
      }

      var pagesToDisplay = maxPages - sidePages

      if (currentPage < pagesToDisplay) {
        return [
          [1, 1 + pagesToDisplay],
          [],
          [maxRange - sidePages, maxRange]
        ]
      }
      if (currentPage > maxRange - pagesToDisplay) {
        return [
          [1, 1 + sidePages],
          [],
          [maxRange - pagesToDisplay, maxRange]
        ]
      }

      pagesToDisplay = maxPages - (sidePages * 2)

      return [
        [1, 1 + sidePages],
        [],
        [currentPage - pagesToDisplay / 2, currentPage + pagesToDisplay / 2],
        [],
        [maxRange - sidePages , maxRange]
      ]
    }
  }
})