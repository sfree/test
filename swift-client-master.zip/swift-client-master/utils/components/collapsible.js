;define(
  [ 'jquery' ]
, function( $ ) {
    
    'use strict'

    /**************
      Collapsible components are a common widget across the swift project. This module sets up a global event listener for when a collapsible element is toggled.

        (1) HTML
          <div class="collapsible">
            <div class="header">{Header}</div>
            <div class="children-container">
              ...
            </div>
          </div>

        (2) HTML
          <div class="collapsible collapsible-header">
            {Header}
            <div class="children-container">
              ...
            </div>
          </div>

      @emrouznp
    **************/

    // Collapsible Elements..
    $('body, .collapsible-dropdown .children-container > *').on(
      'click'
    , function(){
        $('.collapsible-dropdown').addClass('is-collapsed')
      }
    )

    $('body').on(
      'click'
    , '.collapsible .header, .collapsible-header'
    , function(e){
        var target = this
        // close any open collapsible-dropdowns which do not contain the selected element
        $('.collapsible-dropdown:not(.is-collapsed)')
          .not(function(i,e) { return $(e).has(target).length != 0 })
          .addClass('is-collapsed')
        $(this).closest('.collapsible').toggleClass('is-collapsed')
        e.stopPropagation()
      }
    )

  }
)