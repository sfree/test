define(
  [ 'jquery' ],
  function($) {

    /**************
    This module provides a breadcrumbs trail, with crumbs you specify.

    To show breadcrumbs, pass in an array of objects, eg:
    [
        {"title":"Teams", "url":"/teams"}
      , {"title":"Releases", "url":"/releases"}
      , {"title":release, "handle":"bc-release-name"}
    ])

    * Each object can have a title and a url, or a handle property
    * The title property is expected unless a handle is provided to populate the title later
    * The url property is optional
    * If no url is specified, the crumb wont be linkable, but will still appear as a crumb
    * The handle property is optional and is used to populating the crumb title and/or URL asynchronously by calling updateByHandle
    * Values can be String vars, as shown in the above example

    To show breadcrumbs in your resource, add breadcrumbs as a dependency and call its
    render method, eg:

    breadcrumbs.render([{}, {}, {}])

    Note that when you add breadcrumbs in your resource, Home is already added, linking back
    to the homepage.

    To get rid of breadcrumbs once navigating away from your resource (ie page), it is unfortunately and temporarily, necessary to add a breadcrumbs.stop() to your resource lifecycle stop() method.
    Related defect: https://github.ldn.swissbank.com/HTML/resourceful/issues/92

    Example:
    breadcrumbs.stop()

    @tannerla

    **************/

    var crumbNames = []
    var handleIndexes = {}

    // TODO: This module needs to be converted to use the same reconfigurable pattern used across other JS API's (http://bost.ocks.org/mike/chart/)
    function render(d) {
      var output
        , crumb

      if (!d || d.length ==0) {
        console.log('No breadcrumbs detected, so none shown')
        return
      }

      output = '<ul><li><a href="/swift">Home</a></li>'

      crumbNames = []
      var i = 0
      for (crumb in d) {
        var crumbText = d[crumb].title
          , handle = d[crumb].handle

        if(handle) {
          output += '<li id="breadcrumb-'+handle+'">'
          if (!crumbText) crumbText = handle
          handleIndexes[handle] = i
        } else {
          output += '<li>'
        }
        output += buildCrumb(crumbText, d[crumb].url)  + '</li>'

        crumbNames.push(crumbText)
        i++
      }

      output += '</ul>'

      if ($('.breadcrumbs').length == 0) {
        $('.masthead').append($('<div class="breadcrumbs"></div>'))
      }

      $('.breadcrumbs').html(output)

      updatePageTitle()
    }

    function updateByHandle(handle, title, url) {
      $('#breadcrumb-'+handle).html(buildCrumb(title, url))

      crumbNames[handleIndexes[handle]] = title
      updatePageTitle()
    }

    function buildCrumb(title, url){
      return url ? '<a href="'+url+'">' + title + '</a>' : title
    }

    function stop() {
      $('.breadcrumbs').empty()
      crumbNames = []
      updatePageTitle()
    }

    function updatePageTitle() {
      document.title = ['UBS Deploy'].concat(crumbNames).join(' - ')
    }

    return {render: render, updateByHandle: updateByHandle, stop: stop}
  }
)
