;define(
  [
    'jquery'
  , 'resourceful/address'
  , 'visualize/visualize'
  ]
, function(
    $
  , address
  , visualize
  ) {
    // TODO: De-jquery-componentise this. Will be too expensive to maintain long-term..
    'use strict';

    $.fn.reverse = [].reverse;

    var Search = function (element, options) {
      this.options = $.extend({}, $.fn.search.defaults, options)
      this.shown = false
      this.big = false
      this.init(element)
    }

    Search.prototype = {
      init:function (element) {
        var self = this
        this.$wrapper = $(element)
        this.$input = this.$wrapper.find('input')
        this.$menu = this.$wrapper.find('.search-menu')
        this.$items = []

        this.renderCategories = visualize.bind()
          .into(this.$menu.selector)
          .key(function(d){ return d.title })
          .each(function(d,i) {
            var height = !d.results.length
              ? 0
              : 10 + 46*Math.min(d.results.length, self.big ? d.results.length : 4)
            $('h1', this).text(d.title)
            $('h2', this).text(d.total > 4 ? 'View All ' + d.total : '')
            $('.search-list', this).height(height)
              .attr('data-height', height)

            d.results = d.results.map(function(e){
              if (typeof e == 'string') e = {label: e}
              e.formatter = self.options.formatter(d)
              return e
            })
            self.renderResults.within(this)
            self.renderResults(self.big ? d.results : d.results.slice(0,4))
          })

        this.renderResults = visualize.bind()
          .into('.search-list')
          .changed(function(d,i) {
            $(this)
              .text(d.formatter.label(d))
              .attr('data-url', d.formatter.url(d))
          })

        this.listen()
      },

      listen:function () {
        this.$input
          .on('keyup', $.proxy(this.keyup, this))
          .on('keydown', $.proxy(this.keydown, this))
          .on('focus', $.proxy(this.show, this))

        this.$menu
          .on('click', 'h1', $.proxy(this.expand, this))
          .on('click', 'li', $.proxy(this.select, this))
          .on('mouseenter', 'li', $.proxy(this.mouseEnter, this))
          .on('mouseleave', 'li', $.proxy(this.mouseLeave, this))
          .on('click', 'h2', $.proxy(this.toggleBig, this))

        $(document).on('click', $.proxy(this.unselectSearch, this))
      },

      toggleBig:function (e) {
        var $active = this.$menu.find('.hover')
        , $target = $active.length ? $active.closest('section').find('h1')
                       : $(e.target).prev()
        ,   $label  = $active.length ? $active.closest('section').find('h2')
                       : $(e.target)
        , category = $target.text()
        this.big = (this.$menu.width() < 500)

        if (this.big) {
          this.$menu.width(1200)
          this.renderCategories(this.$items.filter(function(e){ return e.title == category }))
          $label.text('Reset')
        } else {
          this.$menu.width(392)
          this.renderCategories(this.$items)
        }

        e.stopPropagation()
        e.preventDefault()
        this.$input.focus()
        return this
      },

      mouseEnter: function(e){
        this.$menu.find('li').removeClass('hover')
        $(e.target).addClass('hover')
      },

      mouseLeave: function(e){
        $(e.target).removeClass('hover')
      },

      unselectSearch:function(e) {
        if (!this.$wrapper.find(e.target).length)
          this.hide()
      },

      expand:function(e) {
        var $list = $(e.target.parentNode.parentNode).toggleClass('expand').find('.search-list')
        , ideal = $list.attr('data-height')
        ,   actual = $list.height()
        $list.height(actual < 10 ? ideal : 0)
      },

      keyup:function (e) {
        var KEYS = $.keyCode
          , keyCode = e.which ? e.which : e.keyCode
          , self = this
          , char = String.fromCharCode(keyCode)

        if ((/[a-zA-Z0-9-_ ]/.test(char)) || keyCode == KEYS.BACKSPACE) {
          self.$wrapper.addClass('loading')
          this.shown = true

          if (self.lastRequest) self.lastRequest.abort()

          self.lastRequest = $.ajax(self.options.source + self.$input.val())
            .done(function(data) {
              self.$menu.addClass('show')
              self.$items = Object.keys(data).map(function(e,i,a) {
                return {title: e, results: data[e].pageResults, total: data[e].totalRecords}
              })
              self.renderCategories(self.$items)
            })
            .always(function(){
              self.$wrapper.removeClass('loading')
            })
        }
        e.stopPropagation()
      },

      keydown:function (e) {
        var KEYS = $.keyCode
          , keyCode = e.which ? e.which : e.keyCode
          , self = this
          , char = String.fromCharCode(keyCode)

        switch (keyCode) {
          case KEYS.TAB:
            if (!this.$menu.find('.hover').length) return
            this.toggleBig(e)
            break
          //case KEYS.RIGHT:
          case KEYS.ENTER:
            if (!this.shown) return
            this.select()
            e.preventDefault()
            break
          case KEYS.ESCAPE:
            this.hide()
            break
          case KEYS.UP:
            e.preventDefault()
            this.prev()
            break
          case KEYS.DOWN:
            e.preventDefault()
            if (this.shown) this.next()
            else this.show()
            break
        }
        e.stopPropagation()
      },

      select:function() {
        var url = this.$menu.find('.hover').attr('data-url')
        if (url) address(url).view()
        this.hide()
        return this
      },

      next:function () {
        var self = this
        , offset = self.$menu.scrollTop()
        , height = self.$menu.height()
        , single = 56
        , top = this.$menu.find('li').first().position().top

        if (!this.$menu.find('.hover').length) {
          this.$menu.find('li').first().addClass('hover')
        } else {
          var $active = null
          this.$menu.find('li').each(function(){
            if ($active) {
              this.className = 'hover'
              top = $(this).position().top
              return false
            }

            if (this.className == 'hover')
              $active = $(this).removeClass('hover')
          })
        }

        if (top < 0 || top + single > height) {
          self.$menu.animate({
            scrollTop: top + single + offset - height
          })
        }

        return this
      },

      prev:function () {
        var self = this
        , offset = self.$menu.scrollTop()
        , height = self.$menu.height()
        , single = 56
        , top = this.$menu.find('li').last().position().top

        if (!this.$menu.find('.hover').length) {
          this.$menu.find('li').last().addClass('hover')
        } else {
          var $active = null
          this.$menu.find('li').reverse().each(function(){
            if ($active) {
              this.className = 'hover'
              top = $(this).position().top
              return false
            }

            if (this.className == 'hover')
              $active = $(this).removeClass('hover')
          })
        }

        if (top < 0 || top + single > height) {
          self.$menu.animate({
            scrollTop: top + offset
          })
        }

        return this
      },

      show:function () {
        if (!this.$input.val()) return
        if ($.trim($('.search-menu').text()) == '') return
        this.$menu.addClass('show')
        this.shown = true;
        return this
      },

      hide:function () {
        this.$menu.removeClass('show')
        this.shown = false
        return this
      }
    }

    $.fn.search = function (option) {
      var args = Array.prototype.slice.call(arguments, 1);

      return this.each(function () {
        var $this = $(this)
          , data = $this.data('search')
          , options = (typeof option == 'object' && option) || $this.data()

        if (!data) $this.data('search', (data = new Search(this, options)))
        if (option == 'source') {
          data.options['source'] = args[0]
        } else if (typeof option == 'string') {
          data[option].apply(data, args)
        }
      })
    }

    $.fn.search.Constructor = Search;

    $.fn.search.defaults =
      { source: ''
      , url: null
      }
  }
)