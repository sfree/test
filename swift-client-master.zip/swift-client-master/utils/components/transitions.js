;define(
  [ 'jquery' ]
, function( $ ) {
    
    'use strict'

    /**************
      This module aims to improve the perceived responsiveness and overall smoothness of the web interface by introducing a set of fast and consistent enter/exit transitions to override the default jagged popping into and out of existence.

      (1) Flip:
      
        HTML
          <div class="flip">
            <li></li>
            <li></li>
            <li></li>
            ...
          </div>

        JS 
          // when appending each li element
          swift.transitions.flip(this)
          
      @emrouznp
    **************/

    function flip(self) {
      setTimeout(function(){ 
        $(self).addClass('enter') 
      }, $(self).index()*50)

      $(self).on('webkitTransitionEnd', function(){
        $(self).addClass('exit')
      })
    }

    return { flip: flip }

  }
)