;define(
  [
    'jquery'
  , 'd3'
  , 'resourceful/address'
  , 'text!./settings.html'
  , 'text!./environments.html'
  , 'text!./properties.html'
  , 'text!./search.html'
  , 'text!./brand.html'
  , '../components/search'
  , 'jquery-cookie/jquery-cookie'
  , '../entitlements'
  ]
, function(
    $
  , d3
  , address
  , settings
  , environments
  , properties
  , search
  , brand
  ) {

    'use strict'

    /**************
      This module constructs and initialises the masthead as follows:

      (1) Defines the masthead in a JSON object
      (2) Renders with D3
      (3) Loads the info for the current user (TODO: don't PCC have a module for this?)
      (4) Render the current user in the top-right
      (5) Wire the toggle-settings links to show the respective lightbox
      (6) Initialise global search

      @emrouznp
    **************/

    // (1) Define Masthead..
    // Any menu items with the class 'org' will only be displayed when an organisation has been picked
    var navItems = [
          { html: brand }
        , { html: '<a class="orgName"></a>', org: true }
        , { html: search, org: true }
        , { html: '<a data-href="/swift/:org/releases">Releases</a>', org: true }
        , { html: '<a data-href="/swift/:org/status">Status</a>', org: true }
        , { html: environments, class: 'nav pull-left divider-before collapsible collapsible-dropdown is-collapsed', org: true }
        , { html: properties, class: 'nav pull-left divider-before collapsible collapsible-dropdown is-collapsed', org: true }
        , { class: 'nav divider-before', org: true }
        , { class: 'nav pull-right divider-before' }
        , { html: settings, class: 'nav pull-right settings' }
        , { class: 'nav pull-right user'
          , html: '<div class="user-profile-container"></div>'
          }
        , { class: 'nav pull-right divider-before no-pad' }
        ]
    ,   selectedOrg

    // (2) Render Masthead..
    d3.select('.masthead')
        .html('')
        .selectAll('ul')
        .data(navItems)
        .enter()
      .append('ul')
        .attr('class', function(d){
          return (d.org ? 'org ' : '') + (d.class || 'nav pull-left divider-before') })
      .append('li')
        .html(function(d) {
          return d.html })

    $('.application').append('<div class="settings-container"></div><div class="about-container"></div>')

    // (3) Current User..
    var guid = $.cookie('UBSGUID')

    // (4) Load PCC Info..
    address('users')
      .param({'guid': guid})
      .view($('.masthead .user-profile-container').get(0))

    // (5) Show User Settings..
    $(document).on('click', '.toggle-settings', showUserSettings)

    function showUserSettings() {
      address('settings')
        .view($('.application .settings-container').get(0))
    }

    // (5) Show About box..
    $(document).on('click', '.toggle-about', showAboutBox)

    function showAboutBox() {
      address('about')
        .view($('.application .about-container').get(0))
    }

    // (7) Initialise Global Search..
    $('.search')
      .search(
        { source: '/api/search?records=50&searchStr='
        , formatter: function(d) {
            switch (d.title) {
              case 'Artifacts':
                return {
                  url: function(d) { return '/swift/' + selectedOrg + '/config/artifact/' + d.groupId + '/' + d.artifactId },
                  label: function(d) { return d.artifactId }
                }
              case 'Releases':
                return {
                  url: function(d) { return '/swift/release/' + d.id },
                  label: function(d) { return d.name }
                }
              case 'Teams':
                return {
                  url: function(d) { return '/swift/team/' + d.label },
                  label: function(d) { return d.label }
                }
              case 'Environments':
                return {
                  url: function(d) { return '/swift/' + selectedOrg + '/config/host?environment=' + d.label },
                  label: function(d) { return d.label.toUpperCase() }
                }
            }
          }
        })

    // hide administration functions if user not entitled
    // Delay as hoping to allow the other ajax requests to get in before this, as I don't consider this very critical.
    setTimeout(function() { $(document).trigger('auth-global') }, 10)

    $('.masthead .logout').click(function() {
      // clear the cookie by expiring yesterday then redirect to login.
      var yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      document.cookie = 'LWSTOKEN="";expires=' + yesterday.toUTCString() + ';domain='+document.domain+';path=/;'

      window.location = '/login'
    })

    function updateOrg(org) {
      selectedOrg = org
      $('a[data-href]', '.masthead').attr('href', function() { return $(this).attr('data-href').replace(':org', org) })
      $('.orgName', '.masthead').text(org).attr('href', '/swift/' + org)
      $('.masthead').toggleClass('orgshown', org != null)
      $('.search').search('source', '/api/search?records=50&organisation=' + org + '&searchStr=')
    }

    return {
      updateOrg: updateOrg
    }
  }
)
