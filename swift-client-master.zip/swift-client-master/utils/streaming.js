;define(
  [
    'jquery'
  , 'log!utils/streaming'
  , './local/ubs-streaming/bundled-ubs-streaming.0.0.11'
  ]
  , function($, log) {

    'use strict'

    // TODO switch to require JS
    var streaming = ubs.streaming

    var streamingUrl, useSSL

    function initStreaming(callback, onError) {
      if (!streamingUrl) {
        // Loads a streaming client for the current environment
        $.getJSON('/lib/resources/endpoints.json', function(data) {
          streamingUrl = data['swift-streaming']
          useSSL = typeof data['useSSL'] !== 'undefined' ? data['useSSL'] : true
          createStreamingClient(callback, onError)
        })
      } else {
        createStreamingClient(callback, onError)
      }
    }

    function createStreamingClient(callback, onError) {
      var client = streaming.forWsApi(streamingUrl, useSSL)
      onStreamingClientCreated(client, callback, onError)
    }

    function onStreamingClientCreated(client, callback, onError) {
      client.connect('swift',
        function(connectedFrame, service) {
          log.info('Connected to notifications: ' + connectedFrame)
          // Given this causes the client to chunk messages, and the server doesn't support message chunking, disable
          // this feature and leave it to the server to limit the maxWebSocketFrameSize as appropriate.
          service.multiplexConnection.client.maxWebSocketFrameSize = Number.MAX_VALUE
          callback(service)
        },
        function(errorFrame) {
          log.error('Error connecting: ' + errorFrame)
          onError()
        }
      )
    }

    // Expose Global API..
    return {
      initStreaming : initStreaming
    }

  }
)
