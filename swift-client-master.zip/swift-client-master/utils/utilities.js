;define(
    [
    'd3'
    ]
  , function(
    d3
    ) {

  'use strict'
  
  /**************
    This modules defines a set of useful utility function that are needed throughout the project:

    (1) px: shorthand for converting a CSS pixel-string value into a JS Number

    (2) unique: removes duplicate elements from an array

    (3) nullSafeContains: checks if a string contains a certain value
    
    (4) glowMomentarily: make the specified node glow momentarily to visualize a user's action (e.g. addition of an item)

    @emrouznp
  ***************/

  window.px = function(px) {
    return +px.substr(0, px.length-2)
  }

  window.unique = function(array) {
    var hash = Object.create(null),
        out = [],
        i = -1;

    while (array.length - ++i) {
      if (!hash[array[i]]) {
        hash[array[i]] = true;
        out.push(array[i]);
      }
    }

    return out;
  }

  String.prototype.contains = function(value) {
    return (this || "").toLowerCase().indexOf(value) !== -1
  }
  
  window.glowMomentarily = function(node) {
    d3.select(node)
      .style('background-color', 'yellowgreen')
      .transition().duration(1000)
      .style('background-color', 'white')
      .transition().duration(0)
      .style('background-color', '')
  }
  
})
