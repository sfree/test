;define(
  [ 
    'jquery'
  , 'token-expiry/monitor'
  ]
, function( $, monitor ) {
    
    'use strict'

    /************** 
      This module does two things:

      (1) Set the data-type and content-type for every ajax call in the application

      (2) Set up global handlers to catch server error. These include:
        
        * Abort: Do nothing
        * Unauthorised (401): Entitlements message
        * Forbidden (403): Entitlements message
        * Anything else (usually 500): Display specific server error message
        * Invalid error from server
        * No error from server

      @emrouznp
    **************/

    // (1) Global AJAX Defaults
    $.ajaxSetup({
      dataType: 'json'
    , contentType: 'application/json; charset=utf-8'
    })

    // For IE, for jquery not to cache AJAX requests
    if (window.navigator.userAgent.indexOf('Trident/') > -1) $.ajaxSetup({cache: false})
    
    // (2) Global Error Handling
    $(document).ajaxError(function(event, request, settings) {
      // TODO: I get the feeling this functionality has grown into a string of hacky if-then statements because it's been added to ad-hoc over large periods of time. Probably a better/cleaner way to address this. Considering refactoring at some point..

      if (request.statusText == 'abort') return

      if (request.status == 401) {
        $(this).trigger(
          'inform.entitlements'
        , request.responseText + ". Redirecting to login..."
        )
        setTimeout(monitor.redirect, 500)
      }
      else if(request.responseText) {
        try {
          var response = JSON.parse(request.responseText)
            , exception = response.exceptionClass ? response.exceptionClass.slice(response.exceptionClass.lastIndexOf('.')+1) : null
            , $sticky = $('.sticky-error.'+exception)
          if($sticky.length > 0){
              $('li', $sticky).html(response.message)
              $sticky.removeClass('is-hidden')
              $('.is-disabled-on-error.'+exception).addClass('is-disabled')
          } else {
            $(this).trigger(
              request.status == 403 ? 'inform.entitlements' : 'inform.error'
            , response.message
            )
          }
        } catch(err) {
          $(this).trigger(
            'inform.error'
          , 'Invalid response from server!<br>' 
            + request.status + ': ' 
            + request.responseText
          )
        }
      } 
      else {
        $(this).trigger(
          'inform.error'
        , 'Empty response from server! (' + request.status + ')'
        )
      }
    })

  }
)
