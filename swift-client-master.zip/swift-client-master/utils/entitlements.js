;define(
  [ 'jquery' ]
, function($) {

    'use strict'

    /**************
      This module globally determines the behaviour of a resource based on the current user's entitlements.

      TODO 1: This module currently embodies two different logic's. These have been added as patches and it should be investigated whether a single simpler solution is possible

      TODO 2: This module has a far too high level of specificity by toggling 4 different classes, 1 attribute, and 5 different selector patterns. Global modules should be largely agnostic to the implementations in different resources - and where it necessary to take an opinion on a particular structure, 1 opinion should be enforced as opposed to 10.

      @emrouznp
    **************/

    // Completely forbid everything above
    $(document).on('auth', function(event, org, env) {
      getAuthorisedEnvironments(org, function(envs){
        var unauthorised = envs.indexOf(env) < 0

        $('.auth').toggleClass('auth-disabled', unauthorised)
        $('.auth-hide').toggleClass('is-hidden', unauthorised)
        $('.auth-show').toggleClass('show', unauthorised)
        $('button.auth').attr('disabled', unauthorised)
      })
    })

    // TODO: improve these methods possibly by using data attributes,
    // and remove references to 'environment' in favour of 'access right' as the auth API from the server
    // now not only returns environments that the user is permissioned for,
    // but also other access rights such as release lockdownrights
    // Lock out based on various levels
    $(document).on('auth-multi', function(event, org) {
      getAuthorisedEnvironments(org, function(envs){
        envs.forEach(function(env){
          $('.auth.env.'+env).removeClass('locked')
          $('.auth.env.'+env).removeClass('is-hidden')
          $('.auth-hide.env.'+env).addClass('is-hidden')
          $('.auth-enable.env.'+env).attr('disabled', false)
        })
      })
    })

    // Global entitlements don't relate to an org / environment
    $(document).on('auth-global', function() {
      getGlobalAuthorisations(function(entitlements){
        $('.auth-global-hide').each(function(i, ele) {
          var unauthorised = entitlements.indexOf($(ele).attr('data-entitlement')) < 0
          $(ele).toggleClass('is-hidden', unauthorised)
        })
      })
    })

    function getAuthorisedEnvironments(org, formatAuth) {
      $.getWithCache('/api/auth?organisation=' + org, formatAuth)
    }

    function getGlobalAuthorisations(formatAuth) {
      $.ajax('/api/auth/global')
        .done(function(data) {
          formatAuth(data)
        })
    }

  }
)
