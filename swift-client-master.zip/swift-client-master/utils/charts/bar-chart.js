define(
  [
    'd3'
  , 'css!./bar-chart.css'
  , 'moment'
  ]
, function(d3) {

    'use strict'

    return function() {

      var dispatch = d3.dispatch('change')
        , width = 100
        , height = 100
        , series //= defaultSeries
        , current
        , margin = {
            top: 30
          , bottom: 20
          }
        , x
        , y
        , interpolator1 = d3.interpolateRgb('purple', 'darkred')
        , interpolator2 = d3.interpolateRgb('darkgoldenrod', 'darkolivegreen')
        , day = 24*60*60*1000
        , today = new Date()
        , svg
        , zoom
        , data
        , nested
        , datum
        , index
        , colour
        , min
        , max
        , days
        , self
        , range = 90
        , dates = [
            { label: '1 Week', value: 7 }
          , { label: '1 Month', value: 30 }
          , { label: '3 Month', value: 90 }
          , { label: 'All Time', value: Infinity }
          ]

      function barChart(){
        self = this
        data = this.datum()
        nested = d3.nest()
          .key(series)
          .entries(data)

        current = nested[0].key
        updateParameters()
        setupChart()
        setupAxis()
        draw()

        // I don't feel like this is the right spot to register this change listener, however I couldn't work out
        // how to call back into the bar chart from externally to flag the environment was changed.
        $('.view-home .environments-container').on('environment-changed', function(e, data) {
          current = data
          draw()
        })

        function draw(){
          drawAxis()
          drawChart()
          drawLegendDates()
        }

        function setupAxis(){
          svg.insert('g', '.chart-details').attr('class', 'axis')

          x = d3.time.scale()
                .domain(period(90))
                .range([0, width])
          y = d3.scale.linear()
                .domain([0, d3.max(datum.map(deployments))])
                .rangeRound([0, height - margin.bottom])

          zoom = d3.behavior.zoom()
              .x(x)
              .y(y)
              .scaleExtent([1, 10])
              .on('zoom', draw)

          svg.call(zoom)
        }

        function setupChart () {
          svg = self.append('svg')
              .attr('class', 'chart')
              .attr('width', width+2)
              .attr('height', height + margin.top + margin.bottom + 5)
            .append('g')

          svg.append('g').classed('chart-area', true)
          svg.append('g').classed('chart-legend-dates', true)

          var details = svg.append('g')
              .classed('chart-details', true)
              .style('visibility', 'hidden')
          details.append('rect')
            .attr('width', 110)
            .attr('height', 41)
            .attr('rx', 5)
            .attr('ry', 5)

          details.append('text')
            .attr('class', 'chart-details-date')
            .attr('x', '55')
            .attr('y', '15')
          details.append('text')
            .attr('class', 'chart-details-value')
            .attr('x', '55')
            .attr('y', '32')
        }

        function drawAxis () {
          x = d3.time.scale()
                .domain(period(range))
                .range([0, width])

          var xAxis = d3.svg.axis()
                .scale(x)
                .orient('bottom')
                .ticks(5)

          svg.select('.axis')
              .attr('transform', 'translate(0,' + (height + margin.top) + ')')
            .transition()
              .duration(350)
              .call(xAxis)
        }

        function drawChart(){
          updateParameters()
          var rect = svg.select('.chart-area')
                .attr('transform', 'translate(0,'+margin.top+')')
                .selectAll('rect')
                .data(
                    datum.filter(inRange)
                  , function(d) { return series(d) + d.date })

          rect.enter().insert('rect', 'line')
              .attr('y', function(d) { return height + .5 })
              .attr('height', 0)
              .style('fill', colour.toString())
              .style('stroke', colour.darker().toString())
              .on('mouseover', onMouseover)
              .on('mouseout', onMouseout)

          rect.transition()
              .duration(150)
              .attr('x', function(d, i) { return x(getX(d)) })
              .attr('width', width / days)
              .delay(function(_,i){ return i*3 })
              .attr('y', function(d) { return height - y(d.deployments) + .5 })
              .attr('height', function(d) { return y(d.deployments) })

          rect.exit().transition()
              .duration(100)
              .delay(function(_,i){ return i*3 })
              .attr('y', function(d) { return height + .5 })
              .attr('height', 0)
              .remove()

          function onMouseover(d) {
            var l = this.x.baseVal.value - 55
              , t = this.y.baseVal.value - 20

            var details = svg.select('.chart-details')
                .attr('transform', 'translate('+l+','+t+')')
                .style('visibility', 'visible')

            details.select('.chart-details-date')
                .text(moment(d.date).format('MMM D, YYYY'))
            details.select('.chart-details-value')
                .text(d.deployments + ' deployments')
          }

          function onMouseout() {
            svg.select('.chart-details')
                .style('visibility', 'hidden')
          }
        }

        function drawLegendDates () {
          var periods = svg.select('.chart-legend-dates')
                .classed('chart-legend-dates', true)
                .attr('transform', 'translate(' + width + ', 10)')
                .selectAll('.legend-item')
                .data(dates)

          var enter = periods.enter()
            .append('g')
            .classed('legend-item', true)
            .on('click', onChangeSeries)
            .attr('transform', function(d,i){
              return 'translate(-'+70*++i+',0)'})

          enter.append('text')
            .text(function(d){ return d.label.toUpperCase() })
            .attr('dx', '10')
            .attr('dy', '0.32em')

          enter.append('circle')
            .attr('r', 5)
            .style('fill', function(d,i){
              return interpolator2(i/(dates.length-1) ) })

          periods.select('circle')
            .classed('selected', function(d,i){
              return range == d.value })

          function onChangeSeries (d) {
            range = d.value
            dispatch.change(range)
            draw()
          }
        }

        function updateParameters () {
          datum = nested.filter(selected)[0]
          index = nested.indexOf(datum)
          colour = d3.rgb(interpolator1(index/(nested.length-1) ))
          datum = datum.values
          min = minmax(data)[0]
          max = minmax(data)[1]
          days = Math.floor((max - min)/day)
        }
      }

      barChart.width = function (_) {
        if (!_) return width
        width = _
        return barChart
      }

      barChart.height = function (_) {
        if (!_) return height
        height = _
        return barChart
      }

      barChart.series = function (_) {
        if (!_) return series
        series = _
        return barChart
      }

      return d3.rebind(barChart, dispatch, "on")

      function period(days) {
        if (days == Infinity) return [min, max]
        return [new Date(+today - day*days), new Date()]
      }

      function inRange (d) {
        var extent = period(range)
        return d.date > extent[0] && d.date < extent[1]
      }

      function getX(d) {
        return (new Date(d.date))
      }

      function minmax(d){
        var min = d.map(getX).sort(dateCompare)[0]
        var max = d.map(getX).sort(dateCompare).reverse()[0]
        return [min, new Date(+max + day)]
      }

      function dateCompare(a,b){
        return (new Date(a)) - (new Date(b))
      }

      function selected (d) {
        return d.key == current
      }

      function deployments(d){
        return d.deployments
      }

      function keys(d) {
        return d.key
      }

    }
  }
)