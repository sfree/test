;define(
  [
    'jquery'
  , './ajax'
  , './renderers/releaseSummary'
  , './components/transitions'
  , './components/breadcrumbs'
  , './masthead/masthead'
  , 'resourceful/address'
  , './components/collapsible'
  , './settings/settings'
  , './utilities'
  , './entitlements'
  , 'inform/inform'
  ]
, function(
    $
  , _ajax
  , renderReleaseSummary
  , transitions
  , breadcrumbs
  , masthead
  , address
  ) {

    'use strict'

    /**************
      This bootstrap module loads all the individual global modules, exposes the necessary API, and also toggles some high-level settings for the title and dual UX issue..

      @emrouznp
    **************/
    // Change Title..
    $('title').html('Swift')

    // Demarcate UX..
    $('html').removeClass('swift-ux')

    /**
     * Holds a map of the responses for common queries (eg environments / auth lookups).
     */
    var cachableUrlResults = {}

    function getWithCache(url, callback) {
      var deferred = cachableUrlResults[url]
      if (!deferred) {
        deferred = $.get(url)
        cachableUrlResults[url] = deferred
      }

      if (callback) {
        deferred.done(callback)
      }
      return deferred
    }

    $.extend({getWithCache: getWithCache})

    var dirty = true
    // $(window).on('beforeunload', function() {
    //   return 'You have unsaved changes on this page';
    // })

    // Expose Global API..
    return {
        transitions: transitions
      , breadcrumbs: breadcrumbs
      , render: {
         releaseSummary: renderReleaseSummary
        }
      , start: start
      , stop: stop
      , update: update
      , updateOrg: updateOrg
      , executeAjax: executeAjax
      , sendToAddress: sendToAddress
      , toggleCheckbox : toggleCheckbox
    }

    function start () {
      $('html').addClass('swift-ux')
    }

    function stop () {
      $('html').removeClass('swift-ux')
      breadcrumbs.stop()

      /*if (dirty) {
        var unload = confirm('You have unsaved changes on this page\n\nAre you sure you want to reload this page?')
        if (unload) {
          console.log('unload')
				} else {
          console.oog('don\'t unload')
				}
			}

      return false*/
      //'You have unsaved changes on this page'
      //Are you sure you want to reload this page?
    }

    function update(request) {
      updateOrg(request.param('org'))
    }

    function updateOrg(orgName) {
      masthead.updateOrg(orgName)
    }

    /**
    * Executes an ajax action asynchronously and takes care of ensuring no other actions or modifications are allowed while the
    * request is outstanding.
    * $actionBtn the button which was clicked. This will be disabled and an ajax spinner will be rendered nicely near it (as per loading styles).
    * $formArea the area which the action relates to. All input fields, text areas and buttons within the area will be disabled
    *   until the ajax request completes.
    * callback will only be invoked if there isn't a corresponding request relating to the $actionBtn or $formArea outstanding.
    *   The callback will need to return the ajax deferred object so that the framework can register additional completion callbacks.
    */
    function executeAjax($actionBtn, $formArea, callback) {
      // If the button is already disabled, do not reenable.
      if ($actionBtn.hasClass("is-disabled")) return

      $actionBtn.addClass("is-disabled loading")

      // restrict to fields not already disabled so we don't enable disabled fields after the operation
      var $fieldsToDisableDuringSave = $('input, textarea, button', $formArea).not(':disabled')
      $fieldsToDisableDuringSave.prop('disabled', true);

      var ajaxPromise = callback()

      ajaxPromise.always(function() {
        $fieldsToDisableDuringSave.prop('disabled', false)
        $actionBtn.removeClass("is-disabled loading")
      })
    }

    /**
    * Utility method so I don't have to remember this combination of accept and target headers.  Every time I needed this pattern
    * I was resorting to copy / paste which is never good.
    */
    function sendToAddress(resource, $target, data, params) {
      var addressable = address(resource)
        .header("accept", ["application/view", "text/html"])
        .header("target", $target[0])
      if (params) {
        $.each(params, function(k,v) {
          addressable.param(k, v)
        })
      }
      addressable.send(data)
    }

    /**
     * Registers a toggle checkbox (a single checkbox which has the power to update all other checkboxes under it).
     * $target - the area containing the checkboxes and select all checkbox
     * checkboxSelector - the filter to enabled child checkboxes which should be considered / modified.
     */
    function toggleCheckbox($target, checkboxSelector) {
      var $toggleCtrl = $('#toggle-ctrl', $target)

      $toggleCtrl.on('change', onToggleCheckboxChange)
      $target.on('change', checkboxSelector, recalculateToggleCtrlState)

      return { recalculateToggleCtrlState: recalculateToggleCtrlState }

      function onToggleCheckboxChange() {
        batchChangeAllCheckboxes($toggleCtrl.prop('checked'))
        $(checkboxSelector, $target).trigger('change')
      }

      function batchChangeAllCheckboxes(targetState) {
        $(checkboxSelector, $target).prop('checked', targetState)
      }

      function recalculateToggleCtrlState() {
        var checkboxes = $(checkboxSelector, $target)
        ,   numCheckboxes = checkboxes.length
        ,   numCheckboxesChecked = checkboxes.filter(':checked').length

        $toggleCtrl.prop('disabled', (numCheckboxes == 0))

        if (numCheckboxesChecked == 0) {
          $toggleCtrl.prop('checked', false).prop('indeterminate', false);
        } else if (numCheckboxesChecked == numCheckboxes) {
          $toggleCtrl.prop('checked', true).prop('indeterminate', false);
        } else {
          $toggleCtrl.prop('checked', false).prop('indeterminate', true);
        }
      }
    }
  }
)
