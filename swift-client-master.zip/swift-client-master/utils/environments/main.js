define(
  [ 'jquery'
  , 'd3'
  , 'visualize/visualize'
  , "log!swift/utils/environments"
  , 'css!./styles.css'
  ],
  function($, d3, visualize, log) {

    'use strict'

    return function() {
      var self = this
      ,   renderOptions = visualize.bind()
            .into('option')
            .each(function(opt) {
              $(this).attr('value', opt)
              $(this).text(opt)
            })

      setupListeners(self)

      return {
        update: render
      }

      function render(req) {
        var environment = req.param('environment')
        ,   org = req.param('org')
        ,   renderBlank = req.param('renderBlank')

        $.getWithCache('/api/config/' + org + '/environments')
          .success(renderEnvironments)

        function renderEnvironments(data) {
          if (renderBlank) {
            // clone first
            data = data.slice()
            data.splice(0, 0, '')
          }

          d3.select(self).select('select').datum(data).call(renderOptions)
          $('select', self).selectinput()
          $(self).trigger('environments-loaded', [data])
          if (environment) {
            $('select', self).val(environment).selectinput('refresh')
          }
        }
      }

      function setupListeners(self) {
        $('select', self).on('change', function() {
          log.debug('Selected environment changed')
          $(self).trigger('environment-changed', this.value)
        })
      }

    }
  }
)