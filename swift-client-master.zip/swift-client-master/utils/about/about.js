;define(
  [
    'jquery'
  , 'css!./styles.css'
  ]
, function(
    $) {

    'use strict'

    return function(){
      var $self = $(this)

      return update

      function update(req) {
        $('.about', $self).addClass('loading')

        $.getJSON('/api/misc/server/info')
          .done(populateAboutFields)
          .always(function(){
            $('.about', $self).removeClass('loading')
          })

        $self.addClass('is-open')
      }
      
      function populateAboutFields(data) {
        $('.about .server-host .content', $self).text(data.server.hostname)
        $('.about .server-version .content', $self).text(data.server.version) 
      }

    }
  }
)
