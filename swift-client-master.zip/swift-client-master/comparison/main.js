define(
  [ 'jquery'
  , 'd3'
  , 'visualize/visualize'
  , 'resourceful/address'
  , '../utils/bootstrap'
  , 'grid/grid'
  , 'grid-plugins/sorting'
  , 'css!grid/styles.css'
  , 'css!./styles.css'
  , 'css!../styles.css'
  ], function($, d3, visualize, address, swift, grid, sorting) {

    'use strict'

    return function() {
      var self = this
      ,   org
      ,   columns =
          [
            {key: 'groupId', headerRenderer: 'GroupId', width: '250px', sortDirection:'asc', sortPriority:1},
            {key: 'artifactId', headerRenderer: 'ArtifactId', width: '300px', sortDirection:'asc', sortPriority:2},
            {key: 'name', headerRenderer: 'Name', width: '75px'},
            {key: 'baseLineVersion', headerRenderer: 'Base Line'},
            {key: 'targetVersion', headerRenderer: 'Target'},
            {key: 'targetAhead', headerRenderer: 'Target Ahead', renderer: targetAheadRenderer}
          ]
      ,   comparisonGridNode = $('.comparison-grid', this)
      ,   comparisonGrid = grid()
            .register(sorting)
            .columns(columns)
            .node(comparisonGridNode)

      ,   $baseLineEnvironmentsContainer = $('.baseline-env', self)
      ,   $targetEnvironmentsContainer = $('.target-env', self)

      setupListeners()

      return {
        start: start
        , update: update
        , stop: stop
      }

      function start() {
        $('html').addClass('swift-ux')
        swift.breadcrumbs.render([{'title':'Environments'}, {'title':'Environment Comparison'}])
      }

      function update(req) {
        org = req.param('org')
        swift.update(req)

        renderEnvLookup($baseLineEnvironmentsContainer)
        renderEnvLookup($targetEnvironmentsContainer)
      }

      function stop() {
        swift.breadcrumbs.stop()
        $('html').removeClass('swift-ux')
      }

      function renderEnvLookup($target) {
        address('environments')
          .param('org', org)
          .view($target.get(0))
      }

      function setupListeners() {
        $('.compare', self).on('click', loadComparisonReport)
      }

      function renderComparisonGrid(data) {
        // flatten for grid keys
        data.forEach(function(d) {
          for (var key in d.artifactConfigId) {
            d[key] = d.artifactConfigId[key]
          }
        })
        comparisonGrid.data(data)
      }

      function loadComparisonReport() {
        var baseLineEnv = getSelected($baseLineEnvironmentsContainer)
        ,   targetEnv = getSelected($targetEnvironmentsContainer)

        $.getJSON('/api/config/comparisonReport/' + org + '?baseLineEnv=' + baseLineEnv + '&targetEnv=' + targetEnv)
          .success(renderComparisonGrid)
      }

      function getSelected($target) {
        return $('select', $target).val()
      }

      function targetAheadRenderer() {
        $(this).append('<i>')

        return function(data) {
          $('i', this)
            .toggleClass('neo-icon-uparrow', data)
            .toggleClass('neo-icon-downarrow', !data)
        }
      }

    } // end resource factory function

  } // end amd
) // end define
