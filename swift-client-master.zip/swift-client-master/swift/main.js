define(
  [
    'jquery'
    , 'd3'
    , 'addressable/address'
    , 'visualize/visualize'
    , '../utils/bootstrap'
    , '../utils/url-maker'
    , 'css!./styles.css'
  ]
  , function ($, d3, address, visualize, swift, urlMaker) {

    'use strict'

    return function () {
      var $slider = $('.slider', this)
        , self = this
        , $this = $(this)
        , $activitiesFilter = $this.find('.activities-filter')
        , org
        , renderTeams = visualize.bind()
          .into('option')
          .each(function (t) {
            $(this).attr('value', t.id)
            $(this).text(t.name)
          })

      setupListeners()

      return {
        update: update, start: swift.start, stop: swift.stop
      }

      function update(request) {
        swift.update(request)

        org = request.param('org')

        swift.breadcrumbs.render([
          {'title': org, 'url': '/swift/' + org }
        ])

        // Initialise Components..
        $('[type=date]', self).dateinput('value', '')

        updateEnvironments($('.configure-hosts', self))
        updateEnvironments($('.configure-defaults', self))

        $("a", self).attr('href', urlMaker(request.param()))
        $("form", self).attr('action', urlMaker(request.param()))

        refreshTeams()

        address('activities')
          .param('org', org)
          .view($('.activities-container'))

        address('environments')
          .param('org', org)
          .view($('.environments-container', self)[0])

        initActivitiesFilter()

        address('releases')
          .param('upcoming', true)
          .param('org', org)
          .view('.upcoming .releases-feed-container')

        // Daily Deployment Stats Chart..
        address('deployments')
          .param('org', org)
          .view('.chart-container')
          .then(function (d) {
            $('.chart-container > div').on('duration', function (e, duration) {
              updateStatistics(org, duration)
            })
            updateStatistics(org, 90)
          })
      }

      function setupListeners() {
        $('form', self).on('submit', onSubmitCreateReleaseForm)
        $('.menu-items > div', self).click(onClickOption)
        $('.menu-panels .cancel', self).click(onCancelOption)
        $('select:not(.team)', self).on('change', onSelectChange)
        $(document).on('settings.saved', refreshTeams)
      }

      function refreshTeams() {
        $.getJSON('/api/teams/user?organisation=' + org)
          .done(function (teams) {
            // TODO when d3-lookup supports ids and values, convert this across
            d3.select('select.team')
              .datum(teams)
              .call(renderTeams)

            $('select.team', self).selectinput('refresh')
            $('.no-teams-label', self).toggleClass('hide', teams.length != 0)
            $('.select-div', self).toggleClass('hide', teams.length == 0)
          })

        address('releases')
          .param('myteams', true)
          .param('org', org)
          .view('.my .releases-feed-container')
      }

      function onSelectChange() {
        var url = $(this).attr('data-url')
        if (url) {
          url = new Function('org', 'environment', url)
          address(url(org, $(this).val())).view()
        }
      }

      function onCancelOption() {
        $slider.removeClass('move-right')
      }

      function onClickOption() {
        if ($(this).index() == 2) {
          // Manage Releases is a direct link to Releases page at present.
          // TODO: maybe include search box or some other interaction to pre-filter releases page directly from this panel
          address('releases').param('org', org).view()
          return
        }
        $('.menu-panel')
          .addClass('hide')
          .eq($(this).index() - 1)
          .removeClass('hide')
        $slider.addClass('move-right')
      }

      function onSubmitCreateReleaseForm(e) {
        e.preventDefault()
        // TODO perhaps the server side should expose a custom create release object
        var releaseDateText = $('[type=date]', this).val()
          , releaseDate = releaseDateText && moment.utc(releaseDateText)
          , request = {
            name: $('[name="name"]', this).val(), team: { id: $('select.team', this).val() }, releaseDate: releaseDate && releaseDate.valueOf()
          }

        $.post('/api/release', JSON.stringify(request))
          .success(function (release) {
            address('release')
              .param('release', release.id)
              .view()
          })
      }

      function updateStatistics(org, duration) {
        address('overview-stats')
          .param('org', org)
          .param('duration', duration)
          .view('.stats')
      }

      function initActivitiesFilter() {
        $activitiesFilter.find('select[name=type]').selectinput()
        updateEnvironments($activitiesFilter.find('select[name="environment"]'))

        $activitiesFilter.on('change', function () {
          address.submit(this)
        })
      }

      function updateEnvironments($select) {
        $.getWithCache('/api/config/' + org + '/environments').done(function (data){
          $select.append(makeOptions(data)).selectinput()
        })
      }
    }

    function makeOptions(list) {
      return list.map(function (env) {
        return $('<option>', {'text': env})
      })
    }
  }
)