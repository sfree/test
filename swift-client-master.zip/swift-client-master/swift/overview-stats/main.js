define(
  [ "visualize/visualize"
  , "css!./styles.css"
  ],
  function(visualize) {
    return function() {
      var historicDurations = visualize.scale.historicDurations()
        , deployments = []
        , releases = []
        , dateFrom
        , previousDateFrom

      function render() {
        renderNewReleases()
        renderDeployments()
      }

      function renderNewReleases() {
        var newReleases = 0
          , previousReleases = 0

        releases.forEach(
          function(e) {
            if (e.date > dateFrom) {
              newReleases += e.newReleases
            }
            else if (e.date > previousDateFrom && e.date < dateFrom) {
              previousReleases += e.newReleases
            }
          }
        )

        renderInto("#newReleases", newReleases, previousReleases)
      }

      function renderDeployments() {
        var totalDeployments = 0
          , totalPreviousDeployments = 0
          , movedToQA = 0
          , previouslyMovedToQA = 0
          , movedToProd = 0
          , previouslyMovedToProd = 0

        deployments.forEach(
          function(e) {
            if (e.date > dateFrom) {
              totalDeployments += e.deployments

              if (isQA(e.environment)) {
                movedToQA += e.deployments
              }
              else if (isProd(e.environment)) {
                movedToProd += e.deployments
              }
            }
            else if (e.date > previousDateFrom && e.date < dateFrom) {
              totalPreviousDeployments += e.deployments

              if (isQA(e.environment)) {
                previouslyMovedToQA += e.deployments
              }
              else if (isProd(e.environment)) {
                previouslyMovedToProd += e.deployments
              }
            }
          }
        )

        renderInto("#totalDeployments", totalDeployments, totalPreviousDeployments)
        renderInto("#movedToQA", movedToQA, previouslyMovedToQA)
        renderInto("#movedToProd", movedToProd, previouslyMovedToProd)
      }

      function renderInto(element, current, previous) {
        var $element = $(element)

        var difference = current - previous
          , stringyfiedDifference = difference > 0 ? "+" + difference : difference

        $element.find(".total").text(current)

        var $icon = $element.find("i")
        addPositiveOrNegative($icon, difference)

        var $change = $element.find(".change")
        $change.text(difference == 0 ? "" : "(" + stringyfiedDifference + ")")
        addPositiveOrNegative($change, difference)
      }

      function addPositiveOrNegative($element, difference) {
        if (difference > 0) {
          $element.addClass("up")
          $element.removeClass("down")
        }
        else if (difference < 0) {
          $element.addClass("down")
          $element.removeClass("up")
        }
        else {
          $element.removeClass("up")
          $element.removeClass("down")
        }
      }

      function isQA(env) {
        var environment = env.substr(0, 3)
        return environment.substr(0, 2) == "qa" || environment == "nfr" || environment == "uat"
      }

      function isProd(env) {
        return env.substr(0, 3) == "prd"
      }

      return {
        update: function(req) {
          var param = req.param("duration")
          ,   org = req.param('org')

          $.when(
            $.getWithCache('/api/history/stats/' + org),
            $.getWithCache('/api/release/stats/' + org)
          )
          .then(
            function(ds, rs) {
              deployments = ds[0]
              releases = rs[0]

              render()
            }
          )

          if (param) {
            var duration = historicDurations(param)()
            dateFrom = duration ? duration[0].getTime() : 0
            previousDateFrom = dateFrom > 0 ? dateFrom - (duration[1].getTime() - dateFrom) : 0
          }
          else {
            dateFrom = previousDateFrom = 0
          }

          render()
        }
      }
    }
  }
)