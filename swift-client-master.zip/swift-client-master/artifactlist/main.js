define(
  [
    'jquery'
  , 'd3'
  , '../d3-lookup/lookup'
  , 'fuzzy-search/fuzzy'
  , 'visualize/visualize'
  , './artifact-type'
  , 'css!./styles.css'
  ], function($, d3, createLookup, fuzzySearch, visualize, artifactType) {

    'use strict'

    /*
    This resource provides a tabular view of artifacts.
    Artifacts can be selected with a respective version, via lookups.
    Each user gesture is offered as an event, allowing the container to
    choose how to handle the event (in most cases its anticipated that
    the data offered by an event is persisted via a specific service.

    Events offered:
    * renderChanged: when the view has been updated
    * statsChanged(stats obj): when the stats counters have changed
    * artifactVersionChanged(artifact): when an artifact's version has been updated
    * artifactAdded(artifact): when an artifact has been added
    * artifactDeleted(artifact): when an artifact has been deleted

    Events detected:
    * artifactWasAdded(artifact): add artifact to DOM
    * artifactWasDeleted(artifact): remove artifact from DOM

    Send params:
    * artifacts: array of artifacts to pre-populate the view with
    * showVersions: boolean flag to show/hide the version lookups
    * waitForCallback: boolean flag whether to wait for event from parent before actually adding/removing artifact from DOM
    * readOnly: boolean to show/hide input fields and controls
    */

    /*
    TIP:
    AMD factory function here - ran once, on first require.
    Whats here is global and exposed to other modules (careful!)
    */

    /*
    TIP:
    Resource factory function below - ran once, on first init.
    In this case, returns object with methods that have their own factory functions.
    */
    return { send: send }

    function send() {

      /*
      TIP:
      send method definition here, ran once on first execute.
      Use for methods and state for send.
      */

      var $this = $(this)
        , stats = { }
        , initialRender = true
        , showVersions = true
        , showStatus = false
        , waitForCallback = false
        , readOnly = false
        , org
        , renderArtifacts
        , artifactLookup
        , versionLookup
        , nodes

      setupRenderer()
      setupLookups()
      setupHandlers.call($this)

      /*
      TIP:
      Factory function for send here, called on each view resource update (aka address).
      Use for repeatable view updates.
      */
      return function(req) {
        renderView(req.body)
      }

      /*
      TIP:
      Local methods to send.  These get hoisted, so can be neatly placed below the return.
      */

      function setupRenderer() {
        renderArtifacts = visualize.bind()
          .key(visualizeKeyHandler)
          .added(visualizeAddedHandler)
          .removed(visualizeRemovedHandler)
          .changed(visualizeChangedHandler)
      }

      function setupLookups() {
        nodes =
        {
          versionLookup: d3.select(".version-lookup-d3")
          , artifactLookup: d3.select(".artifact-lookup-d3")
        }

        // Artifact lookup
        artifactLookup = createLookup()
          .label(function(d) {
            return d.artifactId
          })
          .drawDropdownSuggestion(function(d, i) {
            var q = artifactLookup.query()
              , f = fuzzySearch().query(q)

            d3.select(this)
              .html('<span class="sub pull-right">'
                + d.groupId
                + '</span>'
                + f.format(d.artifactId))
          })
          .prompt('Artifact')

        // Version lookup
        versionLookup = createLookup()
          .prompt('Version')
          .openOnStart(true)

        nodes.versionLookup.datum([]).call(versionLookup)
      }

      function setupHandlers() {
        // TODO change the format to that of artifact/main
        addNewArtifactSelectHandler()
        addNewVersionSelectHandler()
        addAddButtonClickHandler()
        addDeleteClickHandler()

        $this.parent().on('artifactWasAdded', onArtifactWasAdded)
        $this.parent().on('artifactWasDeleted', onArtifactWasDeleted)
      }

      function renderView(data) {
        org = data.org
        showVersions = data.showVersions
        showStatus = data.showStatus
        waitForCallback = data.waitForCallback
        readOnly = (data.readOnly != null)? data.readOnly : false

        if (!readOnly) {
          $.getJSON("/api/lookup/artifacts/" + org)
          .done(function(r) {
            nodes.artifactLookup.datum(r).call(artifactLookup)
          })
        }

        // show/hide versions
        if (!showVersions) {
          $(".version-lookup-d3", $this).css("display", "none")
          $(".version", $this).css("display", "none")
        }
        $('.status', $this).toggleClass('is-hidden', !showStatus)
        $('.delete-column').toggleClass('is-hidden', readOnly)

        $this.toggleClass('readOnly', readOnly)

        // Apply artifacts, if any
        if (data.artifacts) {
          d3.select('.artifact-table table tbody')
            .datum(data.artifacts.sort(byArtifactId))
            .call(renderArtifacts)
        }

        $this.trigger("renderChanged")
      }

      function byArtifactId (a,b) {
        return a.artifactId > b.artifactId ?  1 :
               a.artifactId < b.artifactId ? -1 :
               0
      }

      function visualizeKeyHandler(d) {
        return d.groupId + d.artifactId + (d.status || '')
      }

      function visualizeAddedHandler(d, i) {
        if (!initialRender) {
          glowMomentarily(this)
          initialRender = true
        }

        var type = d.artifactType.shortName
        if (!stats[type]) stats[type] = 1
        else stats[type] = stats[type] + 1

        $this.trigger("statsChanged", stats)
      }

      function visualizeRemovedHandler(d, i) {
        var type = d.artifactType.shortName
        if (!stats[type]) 1 // noop
        else if (stats[type] == 1) delete stats[type]
        else stats[type] = stats[type] - 1

        $this.trigger("statsChanged", stats)
      }

      function visualizeChangedHandler(d, i) {
        var s = d3.select(this)

        s.select('.artifact-name a')
          .text(d.artifactId)
          .attr('title', d.artifactId)
          .attr('href','/swift/' + org + '/status?group='+d.groupId+'&artifact='+d.artifactId)
          //TODO: change this link to artifact landing page when we have one
        s.select('.group-name a')
          .text(d.groupId)
          .attr('title', d.groupId)
          .attr('href','/swift/' + org + '/status?group='+ d.groupId)

        artifactType(s.select('i.icon'), d.artifactType)

        s.select('.status')
          .text(d.status)
          .attr('title', d.status)
          .classed('is-hidden', !showStatus)

        s.select('.delete-column')
          .classed('is-hidden', readOnly)

        $('.version-select-d3', this)
          .toggleClass('swift-lookup', !readOnly)
          .text(readOnly? d.version : '')

        if (!readOnly) {
          $('.version-select-d3', this).text('')

          var artifactVersionLookup = createLookup()
              .label(String)
              .query(d.version)
              .prompt('Version')
              .openOnStart(true)
              .on('focus', lazyLoadOptions)
            , artifactVersionLookupNode = s
              .select('.version-select-d3')
              .datum([])
              .call(artifactVersionLookup)
        }

        function lazyLoadOptions() {
          setTimeout(selectAll, 10)

          if (artifactVersionLookupNode.datum().length) return

          artifactVersionLookup.loading(true)
          artifactVersionLookupNode.call(artifactVersionLookup)

          $.getJSON(
            '/api/lookup/versions/'
            + d.groupId + '/'
            + d.artifactId)
            .done(function(r) {
              artifactVersionLookup
                .loading(false)
                .on('select', onVersionChange)

              artifactVersionLookupNode
                .datum(r)
                .call(artifactVersionLookup)

              selectAll()

              function onVersionChange(newVersion) {
                var artifact = s.datum()
                if (artifact.version == newVersion) return;
                artifact.version = newVersion

                $this.trigger("artifactVersionChanged", artifact)
              }
            })
        }

        function selectAll() {
          artifactVersionLookupNode
            .select('input')
            .node()
            .select()
        }
      }

      function addNewArtifactSelectHandler() {
        // Update the version list based on the selected artifact
        artifactLookup.on('select', function(d) {
          $.getJSON("/api/lookup/versions/" + d.groupId + "/" + d.artifactId)
            .done(function(d) {
              versionLookup
                .query('')
                .focused(true)
                .call(nodes.versionLookup.datum(d))
            })

          if (!showVersions) {
            $('.add-artifact .add').focus()
          }
        })
      }

      function addNewVersionSelectHandler() {
        // Place focus on the add button
        versionLookup.on('select', function(d) {
          $('.add-artifact .add').focus()
        })
      }

      function addAddButtonClickHandler() {
        // Add the artifact to the table and clear the form
        $('.add-artifact .add', this).click(function() {
          var d = artifactLookup.selected()
            , v = versionLookup.selected()

          if (!d)
            return;
          if (showVersions && !v)
            return;

          d = d[0]
          v = v[0]

          var artifact =
          {
            "groupId": d.groupId
            , "artifactId": d.artifactId
            , "version": v
            , artifactType: d.artifactType
          }

          if(!waitForCallback) onArtifactWasAdded(null, artifact)

          artifactLookup
            .query('')
            .focused(false)
            .selected(null)
            .call(nodes.artifactLookup)

          versionLookup
            .query('')
            .call(nodes.versionLookup.datum([]))

          // Allow parent to decide what to do based on this action
          $this.trigger("artifactAdded", artifact)
        })
      }

      function onArtifactWasAdded(e, artifact){
        var artifacts = d3.select('.artifact-table table tbody').datum()
        artifacts.splice(0, 0, artifact)
        artifacts = stripDuplicates(artifacts) // remove duplicates

        initialRender = false
        d3.select('.artifact-table table tbody').datum(artifacts).call(renderArtifacts)
      }

      function stripDuplicates(a) {
        var o = {}
        , i
        , l = a.length
        , r = []

        for(i=0; i<l; i+=1)
        o[a[i].artifactId] = a[i];

        for(i in o)
        r.push(o[i]);

        return r;
      }

      function addDeleteClickHandler() {
        // Remove the deleted artifact from the table
        $this.on('click', '.delete', function() {
          var artifact = d3.select(this.parentNode.parentNode).datum()

          if(!waitForCallback) onArtifactWasDeleted(null, artifact)

          // Allow parent to decide what to do based on this action
          $this.trigger("artifactDeleted", artifact)
        })
      }

      function onArtifactWasDeleted(e, artifact){
        var artifacts = d3.select('.artifact-table table tbody').datum()
          , i = getArtifactIndex(artifacts, artifact)
        if (i > -1)
          artifacts.splice(i, 1)

        d3.select('.artifact-table table tbody').datum(artifacts).call(renderArtifacts)
      }

      function getArtifactIndex(arr, item) {
        for (var i =0; i < arr.length; i++) {
           if (arr[i].artifactId == item.artifactId && arr[i].groupId == item.groupId)
            return i;
        }
        return -1;
      }

    } // end send

  } // end amd
) // end define
