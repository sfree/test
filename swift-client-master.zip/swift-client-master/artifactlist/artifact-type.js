define(function () {

  return function (d3Selection, artifactType) {
    var shortName = '???'
      , artifactColor = ''

    if (artifactType) {
      shortName = artifactType.shortName
      artifactColor = artifactType.color
    }

    d3Selection
      .text(shortName)
      .style('background-color', artifactColor)
  }
})