define(
  [
    "d3"
  , "./js/suggestions"
  , "./js/lookup"
  , "./js/dropdown-list-grouped"
  , "./js/text-input"
  , "./js/redispatcher"
  ]
, function(
    d3
  , createSuggestions
  , createLookup
  , createDropdownList
  , createTextInput
  , redispatcher
  ) {
    return function() {

      var dropdownList = createDropdownList()
        , suggestions = createSuggestions()
        , textField = createTextInput()
        , lookup = createLookup()
              .dropdownList(dropdownList)
              .suggestions(suggestions)
              .textField(textField)
        , d = redispatcher()
            .proxy(dropdownList
              , "itemClick"
              , "itemHover"
              , "expandGroup")
            .proxy(lookup, "select" , "input")

      function proxy(selection) {
        if (!suggestions.groupingFunction()) {
          console.error("Missing grouping function")
        }
        selection.call(lookup)
      }

      return d3.rebind(
        d3.rebind(
          d3.rebind(
            d3.rebind(
              proxy
            , lookup
            , "allowFreeTextInput"
            , "focused"
            , "label"
            , "loading"
            , "openOnStart"
            , "prompt"
            , "query"
            , "selected"
            )
          , d
          , "on"
          )
        , suggestions
        , "filter"
        , "groupingFunction"
        )
      , dropdownList
      , "drawEmptyResults"
      , "drawDropdownSuggestion"
      , "drawHeader"
      )
    }
  }
)
