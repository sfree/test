define(
  [
    "d3"
  , "./js/suggestions"
  , "./js/select"
  , "./js/dropdown-list"
  , "./js/text-none-multiple"
  , "./js/redispatcher"
  , "./js/ok"
  ]
, function(
    d3
  , createSuggestions
  , createSelect
  , createDropdownList
  , createTextNone
  , redispatcher
  , ok
  ) {
    return function() {

      var dropdownList = createDropdownList()
        , suggestions = createSuggestions()
        , textNone = createTextNone()
        , select = createSelect()
              .dropdownList(dropdownList)
              .suggestions(suggestions)
              .textField(textNone)
              .ok(ok)
        , d = redispatcher()
            .proxy(select, "select", "deselect", "focus", "blur")

      function proxy(selection) { (selection || this).call(select) }

      return d3.rebind(
        d3.rebind(
          d3.rebind(
            d3.rebind(
              proxy
            , select
            , "focused"
            , "label"
            , "loading"
            , "prompt"
            , "query"
            , "selected"
            )
          , d
          , "on"
          )
        , dropdownList
        , "drawEmptyResults"
        , "drawDropdownSuggestion"
        )
      , suggestions
      , "groupingFunction"
      )

    }
  }
)