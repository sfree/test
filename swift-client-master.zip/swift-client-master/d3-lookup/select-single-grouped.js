define(
  [
    "d3"
  , "./js/suggestions"
  , "./js/select"
  , "./js/dropdown-list-grouped"
  , "./js/text-none"
  , "./js/redispatcher"
  ]
, function(
    d3
  , createSuggestions
  , createSelect
  , createDropdownList
  , createTextField
  , redispatcher
  ) {
    return function() {

      var dropdownList = createDropdownList()
        , suggestions = createSuggestions()
        , textField = createTextField()
        , select = createSelect()
              .dropdownList(dropdownList)
              .suggestions(suggestions)
              .textField(textField)
        , d = redispatcher()
            .proxy(dropdownList
              , "itemClick"
              , "itemHover"
              , "expandGroup")
            .proxy(select, "select" , "input")

      function proxy(selection) {
        if (!suggestions.groupingFunction()) {
          console.error("Missing grouping function")
        }
        selection.call(select)
      }

      return d3.rebind(
        d3.rebind(
          d3.rebind(
            d3.rebind(
              proxy
            , select
            , "allowFreeTextInput"
            , "focused"
            , "label"
            , "loading"
            , "openOnStart"
            , "prompt"
            , "query"
            , "selected"
            )
          , d
          , "on"
          )
        , suggestions
        , "filter"
        , "groupingFunction"
        )
      , dropdownList
      , "drawEmptyResults"
      , "drawDropdownSuggestion"
      , "drawHeader"
      )
    }
  }
)
