IMPORTANT - local copy of v0.0.30 d3-lookup.  Required because newer versions of d3-lookup do not support dave and require npm.  However many old libraries that swift depends on have not been uploaded to the NPM repo. Given all websdk recommended solutions feel like a hack, at this point in time I've gone with the simplest solution which is to checkin d3-lookup locally.

# Lookups Component (d3-lookup) 

Lookup components enables users to quickly find and select from a pre-populated list of values as they type, leveraging searching and filtering. See the docs over in the [Wiki here](https://github.ldn.swissbank.com/emrouznp/d3-lookup/wiki) for more info.

 - Live Demo: http://websdk.swissbank.com/github/pages/html/d3-lookup//pages/simple-lookup/readme.html
