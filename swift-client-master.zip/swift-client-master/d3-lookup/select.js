define(
  [
    "d3"
  , "./js/suggestions"
  , "./js/select"
  , "./js/dropdown-list"
  , "./js/text-none"
  , "./js/redispatcher"
  ]
, function(
    d3
  , createSuggestions
  , createLookup
  , createDropdownList
  , createTextNone
  , redispatcher
  ) {
    return function() {

      var dropdownList = createDropdownList()
        , suggestions = createSuggestions()
        , textNone = createTextNone()
        , select = createLookup()
              .dropdownList(dropdownList)
              .suggestions(suggestions)
              .textField(textNone)
        , d = redispatcher()
            .proxy(select, "select", "deselect", "focus", "blur", "commit")

      function proxy(selection) { (selection || this).call(select) }

      return component = d3.rebind(
            d3.rebind(
              d3.rebind(
                d3.rebind(
                  d3.rebind(
                    proxy
                  , select
                  , "focused"
                  , "label"
                  , "loading"
                  , "prompt"
                  , "query"
                  , "selected"
                  , "textField"
                  )
                , textNone
                , "afterSelect"
                )
              , d
              , "on"
              )
            , dropdownList
            , "drawEmptyResults"
            , "drawDropdownSuggestion"
            )
          , suggestions
          , "groupingFunction"
          )

    }
  }
)