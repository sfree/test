define(
  [
    "d3/d3"
  , "./js/suggestions"
  , "./js/lookup"
  , "./js/dropdown-list"
  , "./js/text-input-multiple"
  , "./js/redispatcher"
  ]
, function(
    d3
  , createSuggestions
  , createLookup
  , createDropdownList
  , createTextInput
  , redispatcher
  ) {
    return function() {

      var dropdownList = createDropdownList()
        , suggestions = createSuggestions()
        , textField = createTextInput()
        , lookup = createLookup()
              .dropdownList(dropdownList)
              .suggestions(suggestions)
              .textField(textField)
        , d = redispatcher()
            .proxy(lookup, "select", "deselect", "input")

      function proxy(selection) { (selection || this).call(lookup) }

      return d3.rebind(
        d3.rebind(
          d3.rebind(
            d3.rebind(
              d3.rebind(
                proxy
              , lookup
              , "allowFreeTextInput"
              , "focused"
              , "label"
              , "loading"
              , "openOnStart"
              , "prompt"
              , "query"
              , "selected"
              )
            , textField
            , "drawLozenge"
            )
          , d
          , "on"
          ) 
        , dropdownList
        , "drawEmptyResults"
        , "drawDropdownSuggestion"
        )
      , suggestions
      , "filter"
      , "groupingFunction"
      )

    }
  }
)
