define(
  [ "d3/d3" ]
, function( d3 ) {
    return function (selection) { 
      var options = []
      selection
        .selectAll('option')
        .remove()
        .each(function(){ options.push(this.textContent) })

      selection.datum(options) 
    }
  }
)
