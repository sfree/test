define(
  [ "d3/d3" ]
, function() {
    return function() {

      var dispatch = d3.dispatch(
            "input"
          , "expand"
          , "clear"
          , "down"
          , "up"
          , "select"
          , "deselect"
          , "right"
          , "focus"
          , "blur"
          )
        , inputLozenge = "text-input::input-lozenge"
        , prompt = ""
        , loading = false
        , label
        , query
        , suggestion
        , allowFreeTextInput
        , focused
        , drawLozenge = Function()

      function textInput(selection) {
        selection.each(draw)
      }

      textInput.prompt = function(value) {
        if (!arguments.length) return prompt
        prompt = value
        return textInput
      }

      textInput.loading = function(value) {
        if (!arguments.length) return loading
        loading = value
        return textInput
      }

      textInput.drawLozenge = function(value) {
        if (!arguments.length) return drawLozenge
        drawLozenge = value
        return textInput
      }

      textInput.label = function(value) {
        if (!arguments.length) return label
        label = value
        return textInput
      }

      textInput.query = function(value) {
        if (!arguments.length) return query
        query = value
        return textInput
      }

      textInput.suggestion = function(value) {
        if (!arguments.length) return suggestion
        suggestion = value
        return textInput
      }

      textInput.allowFreeTextInput = function(value) {
        if (!arguments.length) return allowFreeTextInput
        allowFreeTextInput = value
        return textInput
      }

      textInput.focused = function(value) {
        if (!arguments.length) return focused
        focused = value
        return textInput
      }

      textInput.afterSelect = function(query, focused, data, selected) {
        return { 
            query: ""
          , focused: focused
          , selected: (selected.push(data), selected)
          }
      }

      textInput.unselected = function(selected, d) {
        return selected.indexOf(d) == -1
      }

      return d3.rebind(textInput, dispatch, "on")

      function draw(d, i) {

        var target = d3.select(this)
                .classed("text-field-multiple", true)
                .on("keydown.text-input", onKeyDown)
                .on("click.text-input", onClick)

          , ul = target.selectAll(".text-field-list").data([0])
          , clear = target.selectAll(".btn-clear").data([0])
          , loadingIcon = target.selectAll(".loading").data([0])
          , lozengeData
          , input
          , ghost

        d = d || []
        lozengeData = d.concat(inputLozenge)

        createMissingElements()
        drawLozenges()
        updateFocus()
        updateInputText()
        updateIconDisplay()

        function drawLozenges() {
          var li = ul.selectAll(".lozenge").data(lozengeData, inputOrLabel)
            , enter = li.enter().append("li")
                  .classed("lozenge", true)
                  .classed("metatag", allowFreeTextInput)

          enter
            .filter(isNotInput)
            .each(setupLozenge)
            .each(drawLozenge)
          li.filter(isInput).each(setupInput) // TODO: enter only?
          li.exit().remove()
          li.order()
        }

        function onKeyDown() {

          // IE11 supports key (the standard).  Chrome supports keyIdentifier
          switch (d3.event.key || d3.event.keyIdentifier) {

            case "Down": {
              dispatch.down()
              break
            }

            case "Up": {
              dispatch.up()
              break
            }

            case "Right": {
              dispatch.right()
              break
            }

            case "Enter":
            case "U+00BC":    // ,
            case "U+0009": {  // Tab
              suggestion && d3.event.preventDefault()
              dispatch.select()
              query = ""
              break
            }

            case "U+001B": {  // Esc
              input.property("value", "")
              query = ""
              dispatch.input(query)
              break
            }

            case "U+0008": {  // Delete
              if (!query.length) deleteLeftOfInput()
              break
            }

          }
        }

        function onClick() {
          if (!focused) dispatch.focus()
        }

        function setupInput(d, i) {
          var lozenge = d3.select(this).classed("edit", true)
          input = lozenge.selectAll("input").data([0])
          ghost = lozenge.selectAll(".ghost").data([0])

          createMissingElements()
          input.on("input.text-input", onInputChange)  // shim pending
              .on("focus.text-input", onTextInputFocus)
              .on("blur.text-input", onTextInputBlur)

          function onInputChange(d, i) {
            query = input.property("value")
            dispatch.input(query)
          }

          function createMissingElements() {
            ghost.enter().append("p").classed("ghost", true)
            input.enter().append("input")
                .attr("type", "text")
                .classed("input-text", true)
          }

          function onTextInputFocus(d, i) {
            dispatch.focus()
          }

          function onTextInputBlur(d, i) {
            dispatch.blur()
          }
        }

        function updateFocus() {
          target.classed('is-active', focused)
          if (focused) {
            (document.activeElement != input.node()) && input.node().focus()
          } else {
            (document.activeElement == input.node()) && input.node().blur()
          }
        }

        function updateInputText() {
          input.property("value", query)
          ghost.text(
            suggestion && query && focused      ? label(suggestion)
          : !d.length && !suggestion && !query  ? prompt
          : ""
          )
        }

        function updateIconDisplay() {
          clear.style("display", d.length || query ? null : "none")
          loadingIcon.style("display", loading ? null : "none")
        }

        function setupLozenge(d, i) {
          var lozenge = d3.select(this)
            , span = lozenge.append("span").text(stringOr(label))
            , close = lozenge.append("i").text("×").on("click" , dispatch.deselect)
        }

        function createMissingElements() {
          ul.enter().append("ol").classed("text-field-list", true)
          clear.enter().append("i")
              .classed("btn-clear", true)
              .attr("title", "Clear")
              .on("click", dispatch.clear)

          loadingIcon.enter()
              .append("i")
              .classed("loading", true)
              .attr("title", "Loading")
        }

        function stringOr(label) {
          return function(d, i) {
            if (typeof d == "string") return d
            return label(d)
          }
        }

        function deleteLeftOfInput() {
          var inputIndex = lozengeData.indexOf(inputLozenge)
          if (inputIndex < 1) return
          dispatch.deselect(lozengeData[inputIndex - 1])
        }

        function inputOrLabel(d, i) {
          if (d === inputLozenge) return inputLozenge
          return stringOr(label)(d)
        }

        function isInput(d) {
          return d == inputLozenge
        }

        function isNotInput(d) {
          return !isInput(d)
        }
      }
    }
  }
)
