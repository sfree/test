define(
  [ "d3" ]
, function() {
    return function() {

      var dispatch = d3.dispatch(
            "click"
          , "down"
          , "up"
          , "select"
          , "deselect"
          , "focus"
          , "blur"
          )
        , prompt = ""
        , loading = false
        , label
        , query
        , suggestion
        , focused
        
      function textField(selection) {
        selection.each(draw)
      }

      textField.prompt = function(value) {
        if (!arguments.length) return prompt
        prompt = value
        return textField
      }

      textField.loading = function(value) {
        if (!arguments.length) return loading
        loading = value
        return textField
      }

      textField.label = function(value) {
        if (!arguments.length) return label
        label = value
        return textField
      }

      textField.query = function(value) {
        if (!arguments.length) return query
        query = value
        return textField
      }

      textField.suggestion = function(value) {
        if (!arguments.length) return suggestion
        suggestion = value
        return textField
      }

      textField.focused = function(value) {
        if (!arguments.length) return focused
        focused = value
        return textField
      }

      textField.afterSelect = function(query, focused, data) {
        return { 
            query: query
          , focused: false
          , selected: [data]
          }
      }

      textField.unselected = function(selected, d) {
        return true
      }

      return d3.rebind(textField, dispatch, "on")

      function draw(d, i) {
        var target = d3.select(this)
                .on("keydown.text-field", onKeyDown)
                .on("click.text-field", onClick)
          , downIcon = target.selectAll(".btn-down").data([0])
          , loadingIcon = target.selectAll(".loading").data([0])
          , input = target.selectAll("input").data([0])

        d = d || []
        
        createMissingElements()
        updateFocus()
        updateInputText()
        updateIconDisplay()
        setupInput()
        
        function setupInput(d, i) {
          input.on("click.text-field", dispatch.click)
              .on("focus.text-field", dispatch.focus)
              .on("blur.text-field" , dispatch.blur)
        }

        function onKeyDown() {
          // IE11 supports key (the standard).  Chrome supports keyIdentifier
          switch (d3.event.key || d3.event.keyIdentifier) {

            case "Down": {
              dispatch.down()
              break
            }

            case "Up": {
              dispatch.up()
              break
            }

            case "Enter":
            case "U+00BC":    // ,
            case "U+0009": {  // Tab
              suggestion && d3.event.preventDefault()
              dispatch.select()
              focused = false;
              break
            }
          }
        }

        function onClick() {
          if (!focused) dispatch.focus()
        }

        function updateFocus() {
          target.classed('is-active', focused)
          if (focused) {
            (document.activeElement != input.node()) && input.node().focus()
          } else {
            (document.activeElement == input.node()) && input.node().blur()
          }
        }

        function updateInputText() {
          input.property("value", query || '')
        }

        function updateIconDisplay() {
          loadingIcon.style("display", loading ? null : "none")
        }

        function createMissingElements() {
          input.enter()
              .append("input")
              .attr("readonly", true)
              .attr("placeholder", prompt)
              .classed("input-none", true)

          loadingIcon.enter()
              .append("i")
              .classed("loading", true)
              .attr("title", "Loading")

          downIcon.enter()
              .append("i")
              .classed("btn-down", true)
              .attr("title", "Expand")
        }

      }
    }
  }
)
