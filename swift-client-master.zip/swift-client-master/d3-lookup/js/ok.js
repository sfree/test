define(
  [ "d3" ]
, function() {
    return function(selection) {
      var textField = this

      createMissingElements()

      function createMissingElements(d) {
        selection
            .selectAll(".item-ok")
            .data([0])
            .enter()
          .append('div')
            .classed('item-ok', true)
          .append('button')
            .on('click', textField.commit)
            .text('OK')
      }

    }

  }
)
