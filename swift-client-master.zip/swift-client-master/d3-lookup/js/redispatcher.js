define(
  [ "d3/d3" ]
, function(d3) {
    return function() {

      var redispatcher = {}
        , types = []

      redispatcher.proxy = function(source) {
        var newTypes = Array.prototype.slice.call(arguments, 1)
          , aggregatedTypes = types.concat(newTypes)
          , dispatcher = d3.dispatch.apply(null, aggregatedTypes)

        proxyEvents(redispatcher, types)
        proxyEvents(source, newTypes)

        types = aggregatedTypes
        dispatcher.proxy = redispatcher.proxy
        redispatcher = dispatcher
        return redispatcher

        function proxyEvents(source, events) {
          events.forEach(
            function(e) {
              source.on(
                e + ".redispatch"
              , function() { dispatcher[e].apply(this, arguments) }
              )
            }
          )
        }
      }
      return redispatcher
    }
  }
)
