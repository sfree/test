define(
  [ "d3/d3" ]
, function() {
    return function() {
      var s = {}
        , query = ""
        , label
        , filter = defaultFilter
        , allowFreeTextInput = true
        , dirty = true
        , suggestionIndex 
        , suggestions
        , bestMatch
        , options = []
        , selectedSuggestion
        , groupingFunction
        , groups

      s.selectedSuggestion = function(value) {
        if (!arguments.length) return commit(), selectedSuggestion
        invalidate()
        selectedSuggestion = value
        invalidate()
        return s
      }

      s.options = function(value) {
        if (!arguments.length) return options
        options = value
        invalidate()
        return s
      }

      s.query = function(value) {
        if (!arguments.length) return query
        query = value
        invalidate()
        return s
      }

      s.label = function(value) {
        if (!arguments.length) return label
        label = value
        invalidate()
        return s
      }

      s.filter = function(value) {
        if (!arguments.length) return filter
        filter = value
        invalidate()
        return s
      }

      s.allowFreeTextInput = function(value) {
        if (!arguments.length) return allowFreeTextInput
        allowFreeTextInput = value
        invalidate()
        return s
      }

      s.groupingFunction = function(value) {
        if (!arguments.length) return groupingFunction
        groupingFunction = value
        return s
      }

      s.groups = function(value) {
        if (!arguments.length) return groups
        groups = value
        return groups
      }

      s.suggestions = function() {
        return commit(), suggestions
      }

      s.bestMatch = function() {
        return commit(), bestMatch
      }

      s.next = function() {
        if (typeof suggestionIndex == "undefined") {
          suggestionIndex = 0
        } else {
          suggestionIndex++
        }
        selectedSuggestion = suggestions[modulo(suggestionIndex, suggestions.length)]
      }

      s.prev = function() {
        if (typeof suggestionIndex == "undefined") {
          suggestionIndex = suggestions.length -1
        } else {
          suggestionIndex--
        }
        selectedSuggestion = suggestions[modulo(suggestionIndex, suggestions.length)]
      }

      s.data = function() {
        return commit(), groupingFunction ? groups : suggestions
      }

      return s

      function invalidate() {
        dirty = true
      }

      function commit() {
        if (!dirty) return 
        bestMatch = null
        suggestions = 
          !query ? options :
          filter ? options.filter(filter) 
                 : options

        if (groupingFunction) {
          groups = groupingFunction(suggestions)
          suggestions = groups.reduce(flatten, [])
        } else {
          groups = undefined
        }

        if (
             !selectedSuggestion  
          || suggestions.indexOf(selectedSuggestion) < 0  
          ) {

          selectedSuggestion = null
          suggestionIndex = undefined

        } else {
          bestMatch = selectedSuggestion
        }

        if (!bestMatch) {
          for (var i = 0, n = suggestions.length; i < n; i++) {
            var option = suggestions[i]
            if (filter ? filter(option) : option) {
              bestMatch = option
              break
            }
          }
        }

        if (!allowFreeTextInput) selectedSuggestion = bestMatch
        suggestionIndex = suggestions.indexOf(selectedSuggestion)
        dirty = false
        
      }

      function modulo(a, n) {
        if (n === 0) return -1
        return a - (n * Math.floor(a / n))
      }

      function flatten(prev, curr) { 
        return prev.concat(curr.values[0].values 
          ? curr.values.reduce(flatten, []) 
          : curr.values
          ) 
      }

      function defaultFilter(d, i) {
        return query && label(d).toLowerCase().indexOf(query.toLowerCase()) >= 0
      }
    }
  }
)
