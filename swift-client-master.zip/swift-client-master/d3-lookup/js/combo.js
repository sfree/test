define(
  [ "d3" ]
, function(d3) {
    return function() {

      var dispatch = d3.dispatch(
            "select"
          , "deselect"
          , "click"
          , "input"
          , "focus"
          )
        , dropdownList
        , textField
        , label = string
        , query = ""
        , selected = []
        , loading = false
        , prompt = ""
        , force = false 
        , focused 
        , suggestions
        
      function combo(selection) {
        selection.each(
          function(d, i) {

            var cb = d3.select(this)
                  .classed("combo", true)
              , tf = cb.selectAll(".text-field").data([0])
              , dd = cb.selectAll(".dropdown").data([0])


            d = d || []

            createMissingElements()
            draw()

            function draw() {
              suggestions
                  .options(d.filter(onlyUnselected))
                  .query(query)
                  .allowFreeTextInput(true)
                  .label(label)
                  .filter(fromBeginning)

              textField
                  .prompt(prompt)
                  .loading(loading)
                  .focused(focused)
                  .label(label)
                  .query(query)
                  .allowFreeTextInput(true)
                  .suggestion(suggestions.bestMatch())
                  .on("input", onInput)
                  .on("expand", onExpand)
                  .on("select", onSelect)
                  .on("down", onDown)
                  .on("up", onUp)
                  .on("right", onRight)
                  .on("deselect", onDeselect)
                  .on("focus", onFocus)
                  .on("blur", onBlur)

              dropdownList
                  .loading(loading)
                  .focused(focused && force)
                  .openOnStart(true)
                  .label(label)
                  .query(query)
                  .on("itemClick", onItemClick)


              tf.datum(selected)
                  .call(textField)

              dd.datum(d)
                  .on("mousedown.combo", preventFocusLoss)
                  .call(dropdownList)
              
              cb.classed("is-open", dropdownList.open())
            }

            function createMissingElements() {
              tf.enter().append("div").classed("text-field", true)
              dd.enter().append("div").classed("dropdown", true)
            }

            function onExpand() {
              force = true
              focused = true
              dispatch.click()
              draw()
            }

            function onInput(input) {
              query = input
              dispatch.input()
              draw()
            }

            function onRight() {
              d3.event.preventDefault()
              var bestMatch = suggestions.bestMatch()
              if (!bestMatch) return
              query = label(bestMatch)
              draw()
            }

            function onSelect() {
              if (!query) return

              var values = textField.afterSelect(
                    query
                  , focused
                  , query
                  , selected
                  )

              selected = values.selected
              query = values.query
              focused = values.focused
              dispatch.select(query)
              draw()
            }

            function onDown() {
              d3.event.preventDefault()
              draw()
            }

            function onUp() {
              d3.event.preventDefault()
              draw()
            }

            function onDeselect(d) {
              selected.splice(selected.indexOf(d), 1)
              dispatch.deselect(d)
              draw()
            }

            function onItemClick(d) {
              if (d.values) return;

              var values = textField.afterSelect(
                    label(d)
                  , focused
                  , d
                  , selected
                  )

              selected = values.selected
              query = values.query
              focused = values.focused
              dispatch.select(d)
              draw()
            }

            function onFocus() {
              focused = true
              dispatch.focus()
              draw()
            }

            function onBlur() {
              force = false
              focused = false
              draw()
            }
          }
        )
      }

      combo.suggestions = function(value)  {
        if (!arguments.length) return suggestions
        suggestions = value
        return combo
      }

      combo.dropdownList = function(value) {
        if (!arguments.length) return dropdownList
        dropdownList = value
        return combo
      }

      combo.textField = function(value) {
        if (!arguments.length) return textField
        textField = value
        return combo
      }

      combo.label = function(value) {
        if (!arguments.length) return label
        label = value
        return combo
      }

      combo.query = function(value) {
        if (!arguments.length) return query
        query = value
        return combo
      }

      combo.selected = function(value) {
        if (!arguments.length) return selected
        selected = value
        return combo
      }

      combo.prompt = function(value) {
        if (!arguments.length) return prompt
        prompt = value
        return combo
      }

      combo.loading = function(value) {
        if (!arguments.length) return loading
        loading = value
        return combo
      }

      combo.focused = function(value) {
        if (!arguments.length) return focused
        focused = value
        return combo
      }

      return d3.rebind(combo, dispatch, "on")

      function string(d) {
        return d
      }

      function onlyUnselected(d, i) {
        return textField.unselected(selected, d)
      }

      function fromBeginning(d){
        return query && !label(d).toLowerCase().indexOf(query.toLowerCase())
      }

      function preventFocusLoss() {
        d3.event.preventDefault()
      }
    }
  }
)
