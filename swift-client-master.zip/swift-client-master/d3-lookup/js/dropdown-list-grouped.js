define(
  [
    "d3/d3"
  , "text/text!./dropdown-group.html"
  ]
, function(d3, groupTemplate) {

    return function() {

      var dispatch = d3.dispatch(
            "itemClick"
          , "itemHover"
          , "expandGroup"
          , "toggle"
          )
        , loading
        , suggestion
        , query = ""
        , label
        , ok = Function()
        , drawDropdownSuggestion = defaultDrawDropdownSuggestion
        , drawHeader = defaultDrawHeader
        , drawEmptyResults = defaultNoResults
        , focused
        , openOnStart = false

      function dropdownList(selection) {
        selection.each(draw)
      }

      dropdownList.openOnStart = function(value) {
        if (!arguments.length) return openOnStart
        openOnStart = value
        return dropdownList
      }

      dropdownList.loading = function(value) {
        if (!arguments.length) return loading
        loading = value
        return dropdownList
      }

      dropdownList.suggestion = function(value) {
        if (!arguments.length) return suggestion
        suggestion = value
        return dropdownList
      }

      dropdownList.query = function(value) {
        if (!arguments.length) return query
        query = value
        return dropdownList
      }

      dropdownList.label = function(value) {
        if (!arguments.length) return label
        label = value
        return dropdownList
      }

      dropdownList.ok = function(value) {
        if (!arguments.length) return ok
        ok = value
        return dropdownList
      }

      dropdownList.drawDropdownSuggestion = function(value) {
        if (!arguments.length) return drawDropdownSuggestion
        drawDropdownSuggestion = value
        return dropdownList
      }

      dropdownList.drawHeader = function(value) {
        if (!arguments.length) return drawHeader
        drawHeader = value
        return dropdownList
      }

      dropdownList.drawEmptyResults = function(value) {
        if (!arguments.length) return drawEmptyResults
        drawEmptyResults = value
        return dropdownList
      }

      dropdownList.focused = function(value) {
        if (!arguments.length) return focused
        focused = value
        return dropdownList
      }

      return d3.rebind(dropdownList, dispatch, "on")

      function draw() {

        var target = d3.select(this).call(ok)
          , d = target.datum()
          , open = focused && (d.length || !loading)
          , open = (openOnStart ? open : open && query)
          , root = target.selectAll(".dropdown-list").data([0])
          , noResults = target.selectAll(".no-results").data([0])

        target.style("display", open ? null : "none")
        if (!open) return;
        
        createMissingElements()
        drawRoot()
        updateEmptyResults()

        function drawRoot() {
          var groups = root.selectAll('>li')
            .data(d, key)
            .call(drawParent)
        }

        function drawParent() {
          this.enter().append('li').html(groupTemplate)
          this.exit().remove()
          this.each(drawGroup).order()
        }

        function drawGroup(d, i) {

          var group = d3.select(this)
                .on("mousedown.dropdown-list", onItemMousedown)
                .on("mouseover.dropdown-list", onItemMouseover)
                .classed('is-active', isActive)
                .classed('is-partial', isPartial)
                .classed('is-selected', isAllSelected)
            , suggestionsList = group.select(".dropdown-list")
            , header = group.select(".group-name")
            , checkbox = group.select(".btn-check")
                  .on("mousedown.dropdown-list",  onCheckAll)
            , expand = group.select(".btn-expand")
                  .on("mousedown.dropdown-list",  onExpand)
          
          updateHeader()
          updateSuggestions()
          
          function updateHeader() {
            header.html(drawHeader(d.key))
          }

          function onCheckAll(d) {
            d3.event.preventDefault()
            d3.event.stopPropagation()
            var to = !d3.select(this.parentNode).classed('is-selected')
            dispatch.toggle(d, to)
          }
          
          function onExpand () {
            dispatch.expandGroup()
            draw()
          }

          function updateSuggestions() {
            suggestionsList.style("display", null)
            d.values[0].values ? drawChildren() : drawLeaf()
          }

          function drawLeaf() {
            var li = suggestionsList.selectAll('>li').data(d.values)
            li.enter().append('li')
            li.exit().remove()
            li.each(drawDropdownSuggestion)
                .each(scrollIntoView)
                .on("mousedown.dropdown-list", onItemMousedown)
                .on("mouseover.dropdown-list", onItemMouseover)
                .classed("is-selected", isSelected)
                .classed("is-suggested", isSuggestion)
                .classed('child', true)
                .order()
          }

          function drawChildren() {
            suggestionsList
              .selectAll('>li')
              .data(d.values, key)
              .call(drawParent)
          }

        }

        function createMissingElements() {
          root.enter().append("ul").classed("dropdown-list", true)
          noResults.enter().append("p").classed("no-results", true)
        }

        function updateEmptyResults() {
          if (d.length) {
            noResults.style("display", "none")
            return
          }

          noResults
              .datum(query)
              .each(drawEmptyResults)
              .style("display", null)
        }

        function onItemMousedown(d, i) {
          d3.event.stopPropagation()
          d3.event.preventDefault()
          target
            .selectAll('.is-active')
            .classed('is-active', false)
          d3.select(this)
            .classed('is-active', true)
          
          dispatch.itemClick.call(this, d, i)
        }

        function onItemMouseover(d, i) {
          d3.event.stopPropagation()
          dispatch.itemHover.call(this, d, i)
        }
      }

      function isSelected(d) {
        return d.selected
      }

      function isNotSelected(d) {
        return !d.selected
      }

      function isActive(d) {
        var li = d3.select(this)
          , active = 
              li.classed('is-active') 
          || !li.selectAll('.is-active').empty()
        
        return active
      }

      function isPartial(d) {
        var children = [d].reduce(flatten, [])
          , ticked = children.some(isSelected)
          , unticked = children.some(isNotSelected)
        
        return ticked && unticked
      }
 
      function isAllSelected(d) {
        var children = [d].reduce(flatten, [])
          , ticked = children.some(isSelected)
          , unticked = children.some(isNotSelected)
        
        return ticked && !unticked
      }
 
      function isSuggestion(d) {
        return suggestion && suggestion == d
      }

      function defaultNoResults(d) {
        d3.select(this).html("No results for <strong>" + d + "</strong>")
      }

      function defaultDrawDropdownSuggestion(d, i) {
        d3.select(this)
          .text(label(d))
          .insert('i', ':first-child')
          .classed('btn-check', 1)
      }

      function defaultDrawHeader(d, i) {
        return d
      }

      function scrollIntoView(d, i) {
        isSuggestion(d) && this.scrollIntoViewIfNeeded(false)
      }

      function key(d) {
        return d.key
      }

      function flatten(prev, curr) { 
        return prev.concat(curr.values[0].values 
          ? curr.values.reduce(flatten, []) 
          : curr.values
          ) 
      }

      function toggleAll(d) { 
        if (d.values) return d.values.forEach(toggleAll.bind(this))
        d.selected = this[0]
      }

    }
  }
)
