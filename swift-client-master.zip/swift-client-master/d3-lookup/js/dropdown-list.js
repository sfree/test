define(
  [ "d3/d3" ]
, function(d3) {
    return function() {

      var dispatch = d3.dispatch("itemClick", "itemHover", "toggle")
        , suggestion
        , loading
        , query = ""
        , label
        , dropdownList
        , ok = Function()
        , drawDropdownSuggestion = defaultDrawDropdownSuggestion
        , drawEmptyResults = defaultNoResults
        , focused
        , openOnStart = false
        , open = false

      function dropdownList(selection) {
        selection.each(draw)
      }

      dropdownList.suggestion = function(value) {
        if (!arguments.length) return suggestion
        suggestion = value
        return dropdownList
      }

      dropdownList.label = function(value) {
        if (!arguments.length) return label
        label = value
        return dropdownList
      }

      dropdownList.query = function(value) {
        if (!arguments.length) return query
        query = value
        return dropdownList
      }

      dropdownList.loading = function(value) {
        if (!arguments.length) return loading
        loading = value
        return dropdownList
      }

      dropdownList.openOnStart = function(value) {
        if (!arguments.length) return openOnStart
        openOnStart = value
        return dropdownList
      }

      dropdownList.drawDropdownSuggestion = function(value) {
        if (!arguments.length) return drawDropdownSuggestion
        drawDropdownSuggestion = value
        return dropdownList
      }

      dropdownList.drawEmptyResults = function(value) {
        if (!arguments.length) return drawEmptyResults
        drawEmptyResults = value
        return dropdownList
      }

      dropdownList.ok = function(value) {
        if (!arguments.length) return ok
        ok = value
        return dropdownList
      }

      dropdownList.focused = function(value) {
        if (!arguments.length) return focused
        focused = value
        return dropdownList
      }

      dropdownList.open = function(value) {
        if (!arguments.length) return open
        open = value
        return dropdownList
      }

      return d3.rebind(dropdownList, dispatch, "on")

      function draw(d, i) {

        var target = d3.select(this).call(ok)
          , ul = target.selectAll(".dropdown-list").data([0])
          , noResults = target.selectAll(".no-results").data([0])
          , li
        
        open = focused && (d.length || !loading)
        open = (openOnStart ? open : open && query)
        target.style("display", open ? null : "none")

        if (!open) return

        createMissingElements()
        drawItems()
        updateEmptyResults()
        
        function drawItems() {
          li = ul.selectAll("li").data(d)
          li.enter().append("li")
          li.exit().remove()
          li.each(drawDropdownSuggestion)
              .each(scrollIntoView)
              .classed("child", true)
              .classed("is-selected", isSelected)
              .classed("is-suggested", isSuggestion)
              .on("mousedown.dropdown-list", onItemMousedown)
              .on("mouseover.dropdown-list", onItemMouseover)
              .order()
        }

        function updateEmptyResults() {
          if (d.length) {
            noResults.style("display", "none")
            return
          }

          noResults
              .datum(query)
              .each(drawEmptyResults)
              .style("display", null)
        }

        function createMissingElements() {
          ul.enter().append("ol").classed("dropdown-list", true)
          noResults.enter().append("p").classed("no-results", true)
        }
      }

      function isSuggestion(d) {
        // TODO: Use key if provided?
        return suggestion && suggestion == d
      }

      function isSelected(d) {
        // TODO: Use key if provided?
        return d.selected
      }

      function onItemMousedown(d, i) {
        d3.event.preventDefault()
        dispatch.itemClick.call(this, d, i)
      }

      function onItemMouseover(d, i) {
        dispatch.itemHover.call(this, d, i)
      }

      function defaultNoResults(d) {
        d3.select(this).html("No results for <strong>" + d + "</strong>")
      }

      function defaultDrawDropdownSuggestion(d, i) {
        d3.select(this)
          .text(label(d))
          .insert('i', ':first-child')
          .classed('btn-check', 1)
      }

      function scrollIntoView(d, i) {
        if (isSuggestion(d)) {
          if (this.scrollIntoViewIfNeeded) return this.scrollIntoViewIfNeeded(false)
          var containerRect = this.parentNode.getBoundingClientRect()
            , elementRect = this.getBoundingClientRect()

          if (elementRect.top < containerRect.top) this.scrollIntoView(true)
          else if (elementRect.bottom > containerRect.bottom) this.scrollIntoView(false)
        }
      }

    }
  }
)
