define(
  [ "d3/d3" ]
, function() {
    return function() {

      var dispatch = d3.dispatch(
            "input"
          , "expand"
          , "clear"
          , "down"
          , "up"
          , "select"
          , "deselect"
          , "right"
          , "focus"
          , "blur"
          )
        , prompt = ""
        , loading = false
        , label
        , query
        , suggestion
        , allowFreeTextInput
        , focused
        
      function textInput(selection) {
        selection.each(draw)
      }

      textInput.prompt = function(value) {
        if (!arguments.length) return prompt
        prompt = value
        return textInput
      }

      textInput.loading = function(value) {
        if (!arguments.length) return loading
        loading = value
        return textInput
      }

      textInput.label = function(value) {
        if (!arguments.length) return label
        label = value
        return textInput
      }

      textInput.query = function(value) {
        if (!arguments.length) return query
        query = value
        return textInput
      }

      textInput.suggestion = function(value) {
        if (!arguments.length) return suggestion
        suggestion = value
        return textInput
      }

      textInput.allowFreeTextInput = function(value) {
        if (!arguments.length) return allowFreeTextInput
        allowFreeTextInput = value
        return textInput
      }

      textInput.focused = function(value) {
        if (!arguments.length) return focused
        focused = value
        return textInput
      }

      textInput.afterSelect = function(query, focused, data) {
        return { 
            query: query
          , focused: false
          , selected: [data]
          }
      }

      textInput.unselected = function(selected, d) {
        return true
      }

      return d3.rebind(textInput, dispatch, "on")

      function draw(d, i) {

        var target = d3.select(this)
                .on("keydown.text-input", onKeyDown)
                .on("click.text-input", onClick)
          , clear = target.selectAll(".btn-clear").data([0])
          , loadingIcon = target.selectAll(".loading").data([0])
          , input = target.selectAll("input").data([0])
          , ghost = target.selectAll(".ghost").data([0])

        d = d || []
        
        createMissingElements()
        updateFocus()
        updateInputText()
        updateIconDisplay()
        setupInput()
        function setupInput(d, i) {
          input.on("input.text-input", onInputChange)  // shim pending
              .on("focus.text-input", onTextInputFocus)
              .on("blur.text-input", onTextInputBlur)

          function onInputChange(d, i) {
            query = input.property("value")
            dispatch.input(query)
          }

          function onTextInputFocus(d, i) {
            dispatch.focus()
          }

          function onTextInputBlur(d, i) {
            dispatch.blur()
          }
        }

        function onKeyDown() {
          // IE11 supports key (the standard).  Chrome supports keyIdentifier
          switch (d3.event.key || d3.event.keyIdentifier) {

            case "Down": {
              dispatch.down()
              break
            }

            case "Up": {
              dispatch.up()
              break
            }

            case "Right": {
              dispatch.right()
              break
            }

            case "Enter":
            case "U+00BC":    // ,
            case "U+0009": {  // Tab
              suggestion && d3.event.preventDefault()
              dispatch.select()
              focused = false;
              break
            }

            case "U+001B": {  // Esc
              input.property("value", "")
              query = ""
              dispatch.input(query)
              break
            }
          }
        }

        function onClick() {
          if (!focused) dispatch.focus()
        }

        function updateFocus() {
          target.classed('is-active', focused)
          if (focused) {
            (document.activeElement != input.node()) && input.node().focus()
          } else {
            (document.activeElement == input.node()) && input.node().blur()
          }
        }

        function updateInputText() {
          input.property("value", query)
          ghost.text(
            suggestion && focused  ? label(suggestion)
          : !d.length && !query  ? prompt
          : ""
          )
        }

        function updateIconDisplay() {
          clear.style("display", d.length || query ? null : "none")
          loadingIcon.style("display", loading ? null : "none")
        }

        function createMissingElements() {
          ghost.enter()
              .append("p")
              .classed("ghost", true)

          input.enter()
              .append("input")
              .attr("type", "text")
              .classed("input-text", true)

          clear.enter()
              .append("i")
              .classed("btn-clear", true)
              .attr("title", "Clear")
              .on("click", dispatch.clear)

          loadingIcon.enter()
              .append("i")
              .classed("loading", true)
              .attr("title", "Loading")
        }

      }
    }
  }
)
