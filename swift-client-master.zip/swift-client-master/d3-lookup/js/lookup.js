define(
  [ "d3/d3" ]
, function(d3) {
    return function() {

      var dispatch = d3.dispatch("select", "deselect", "input", "focus")
        , dropdownList
        , textField
        , suggestions
        , label = string
        , query = ""
        , selected = []
        , loading = false
        , openOnStart = false
        , prompt = ""
        , allowFreeTextInput = true
        , focused
        
      function lookup(selection) {
        selection.each(
          function(d, i) {

            var lu = d3.select(this).classed("lookup", true)
              , tf = lu.selectAll(".text-field").data([0])
              , dd = lu.selectAll(".dropdown").data([0])

            d = d || []

            createMissingElements()
            draw()

            function draw() {

              suggestions
                  .options(d.filter(onlyUnselected))
                  .query(query)
                  .allowFreeTextInput(allowFreeTextInput)
                  .label(label)

              textField
                  .prompt(prompt)
                  .loading(loading)
                  .focused(focused)
                  .label(label)
                  .query(query)
                  .allowFreeTextInput(allowFreeTextInput)
                  .suggestion(suggestions.bestMatch())
                  .on("input", onInput)
                  .on("clear", onClear)
                  .on("select", onSelect)
                  .on("down", onDown)
                  .on("up", onUp)
                  .on("deselect", onDeselect)
                  .on("right", onRight)
                  .on("focus", onFocus)
                  .on("blur", onBlur)

              dropdownList
                  .loading(loading)
                  .openOnStart(openOnStart)
                  .focused(focused)
                  .suggestion(suggestions.selectedSuggestion())
                  .label(label)
                  .query(query)
                  .on("itemClick", onItemClick)
                  .on("itemHover", onItemHover)

              tf.datum(selected)
                  .call(textField)

              dd.datum(suggestions.data())
                  .on("mousedown.lookup-grouped", preventFocusLoss)
                  .call(dropdownList)
            }

            function createMissingElements() {
              tf.enter().append("div").classed("text-field", true)
              dd.enter().append("div").classed("dropdown", true)
            }

            function onInput(input) {
              query = input
              dispatch.input()
              draw()
            }

            function onClear() {
              query = ""
              selected = []
              dispatch.deselect()
              draw()
            } 

            function onSelect() {
              var selectedSuggestion = suggestions.selectedSuggestion()
                , element = selectedSuggestion || query

              if (!allowFreeTextInput && !selectedSuggestion) return
              if (!element) return
              
              var values = textField.afterSelect
                (
                  label(element) || element
                , focused
                , element
                , selected
                )

              selected = values.selected
              query = values.query
              focused = values.focused
              dispatch.select(element)
              draw()
            }

            function onDown() {
              suggestions.next()
              draw()
            }

            function onUp() {
              suggestions.prev()
              draw()
            }

            function onDeselect(d) {
              selected.splice(selected.indexOf(d), 1)
              dispatch.deselect(d)
              draw()
            }

            function onItemClick(d) {
              var values = textField.afterSelect
                (
                  label(d)
                , focused
                , d
                , selected
                )

              selected = values.selected
              query = values.query
              focused = values.focused
              dispatch.select(d)
              draw()
            }

            function onItemHover(d) {
              var old = suggestions.selectedSuggestion()
              suggestions.selectedSuggestion(d)
              if (old != d) draw()
            }

            function onRight() {
              var bestMatch
              if (!allowFreeTextInput) return
              bestMatch = suggestions.bestMatch()
              if (!bestMatch) return
              query = label(bestMatch)
              draw()
            }

            function onFocus() {
              focused = true
              dispatch.focus()
              draw()
            }

            function onBlur() {
              focused = false
              draw()
            }
          }
        )
      }

      lookup.suggestions = function(value)  {
        if (!arguments.length) return suggestions
        suggestions = value
        return lookup
      }

      lookup.dropdownList = function(value) {
        if (!arguments.length) return dropdownList
        dropdownList = value
        return lookup
      }

      lookup.textField = function(value) {
        if (!arguments.length) return textField
        textField = value
        return lookup
      }

      lookup.label = function(value) {
        if (!arguments.length) return label
        label = value
        return lookup
      }

      lookup.query = function(value) {
        if (!arguments.length) return query
        query = value
        return lookup
      }

      lookup.selected = function(value) {
        if (!arguments.length) return selected
        selected = value
        return lookup
      }

      lookup.prompt = function(value) {
        if (!arguments.length) return prompt
        prompt = value
        return lookup
      }

      lookup.loading = function(value) {
        if (!arguments.length) return loading
        loading = value
        return lookup
      }

      lookup.openOnStart = function(value) {
        if (!arguments.length) return openOnStart
        openOnStart = value
        return lookup
      }

      lookup.allowFreeTextInput = function(value) {
        if (!arguments.length) return allowFreeTextInput
        allowFreeTextInput = value
        return lookup
      }

      lookup.focused = function(value) {
        if (!arguments.length) return focused
        focused = value
        return lookup
      }

      return d3.rebind(lookup, dispatch, "on")

      function string(d) {
        return d
      }

      function onlyUnselected(d, i) {
        return textField.unselected(selected, d)
      }

      function preventFocusLoss() {
        d3.event.preventDefault()
      }
    }
  }
)
