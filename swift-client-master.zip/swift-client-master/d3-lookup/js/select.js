define(
  [ "d3" ]
, function(d3) {
    
    'use strict'

    return function() {

      var dispatch = d3.dispatch(
            "select"
          , "deselect"
          , "click"
          , "input"
          , "focus"
          , "blur"
          , "commit"
          )
        , dropdownList
        , textField
        , suggestions
        , label = string
        , query = ""
        , selected = []
        , loading = false
        , prompt = ""
        , focused 
        , ok = Function()
        
      function select(selection) {
        selection.each(
          function(d, i) {
            var sl = d3.select(this).classed("select", true)
              , tf = sl.selectAll(".text-field").data([0])
              , dd = sl.selectAll(".dropdown").data([0])

            d = d || []

            createMissingElements()
            draw()

            function draw() {

              suggestions
                  .options(d.map(updateDropdown))
                  .query(query)
                  .label(label)
                  .filter(all)

              textField
                  .prompt(prompt)
                  .loading(loading)
                  .focused(focused)
                  .label(label)
                  .query(query)
                  .suggestion(suggestions.bestMatch())
                  .on("click", onClick)
                  .on("select", onSelect)
                  .on("down", onDown)
                  .on("up", onUp)
                  .on("deselect", onDeselect)
                  .on("focus", onFocus)
                  .on("blur", onBlur)

              dropdownList
                  .loading(loading)
                  .focused(focused)
                  .openOnStart(true)
                  .suggestion(suggestions.selectedSuggestion())
                  .ok(ok)
                  .label(label)
                  .query(query)
                  .on("itemClick", onItemClick)
                  .on("itemHover", onItemHover)
                  .on("toggle", onToggle)

              tf.datum(selected)
                  .call(textField)

              dd.datum(suggestions.data())
                  .on("mousedown.select", preventFocusLoss)
                  .call(dropdownList)
                  .each(updateSize)
            }

            function updateSize (d) {
              if (!this.parentNode) return;
              var height = 0
                , width = 1
                , target = d3.select(this)
                , parent = d3.select(this.parentNode)

              if (!parent.classed('select-drilldown')
               && !parent.classed('select-drilldown-multiple'))
                  return;

              d3.select(this)
                .selectAll('ul:visible')
                .each(function(d){ 
                  height = this.offsetHeight > height 
                    ? this.offsetHeight 
                    : height 
                  width += this.offsetWidth - 1
                })
              d3.select(this)
                .style('height', height+'px')
                .style('width', width+'px')
            }

            function updateDropdown(option) {
              var isSelected = selected.some(function(s){
                return option == s
              })
              option.selected = isSelected
              return option
            }

            function createMissingElements() {
              tf.enter().append("div").classed("text-field", true)
              dd.enter().append("div").classed("dropdown", true)
            }

            function onToggle(d, to) {
              var children = [d].reduce(flatten, [])
              children.forEach(function(child){
                  !to ? selected = selected.filter(remove(child))
                : !selected.some(match(child)) ? selected.push(child)
                : []
              })
              
              draw()
            }

            function match(candidate) {
              return function(d){
                return d == candidate
              }
            }

            function remove(candidate) {
              return function(d) {
                return d != candidate
              }
            }

            function onClick() {
              focused = true
              dispatch.click()
              draw()
            }

            function onClear() {
              query = ""
              selected = []
              dispatch.deselect()
              draw()
            } 

            function onSelect() {
              var selectedSuggestion = suggestions.selectedSuggestion()
                , element = selectedSuggestion || query

              if (!selectedSuggestion) return
              if (!element) return

              var values = textField.afterSelect(
                    label(element)
                  , focused
                  , element
                  , selected
                  )
          
              selected = values.selected
              query = values.query
              focused = values.focused
              dispatch.select(element)
              draw()
            }

            function onDown() {
              d3.event.preventDefault()
              suggestions.next()
              draw()
            }

            function onUp() {
              d3.event.preventDefault()
              suggestions.prev()
              draw()
            }

            function onDeselect(d) {
              selected.splice(selected.indexOf(d), 1)
              dispatch.deselect(d)
              draw()
            }

            function onItemClick(d) {
              if (d.values && suggestions.groupingFunction()) return draw() 

              var values = textField.afterSelect(
                    label(d)
                  , focused
                  , d
                  , selected
                  )

              selected = values.selected
              query = values.query
              focused = values.focused
              dispatch.select(d)
              draw()
            }

            function onItemHover(d) {
              var old = suggestions.selectedSuggestion()
              suggestions.selectedSuggestion(d)
              if (old != d) draw()
            }

            function onFocus() {
              focused = true
              dispatch.focus()
              draw()
            }

            function onBlur(d) {
              focused = false
              selected = d || selected
              dispatch.blur(selected)
              draw()
            }
          }
        )
      }

      select.suggestions = function(value)  {
        if (!arguments.length) return suggestions
        suggestions = value
        return select
      }

      select.dropdownList = function(value) {
        if (!arguments.length) return dropdownList
        dropdownList = value
        return select
      }

      select.textField = function(value) {
        if (!arguments.length) return textField
        textField = value
        return select
      }

      select.label = function(value) {
        if (!arguments.length) return label
        label = value
        return select
      }

      select.query = function(value) {
        if (!arguments.length) return query
        query = value
        return select
      }

      select.selected = function(value) {
        if (!arguments.length) return selected
        selected = value
        return select
      }

      select.ok = function(value) {
        if (!arguments.length) return ok
        ok = value.bind(textField)
        return select
      }

      select.prompt = function(value) {
        if (!arguments.length) return prompt
        prompt = value
        return select
      }

      select.loading = function(value) {
        if (!arguments.length) return loading
        loading = value
        return select
      }

      select.focused = function(value) {
        if (!arguments.length) return focused
        focused = value
        return select
      }

      return d3.rebind(select, dispatch, "on")

      function flatten(prev, curr) { 
        return prev.concat(curr.values[0].values 
          ? curr.values.reduce(flatten, []) 
          : curr.values
          ) 
      }

      function string(d) {
        return d
      }

      function onlyUnselected(d, i) {
        return textField.unselected(selected, d)
      }

      function all(){
        return true
      }

      function preventFocusLoss() {
        d3.event.preventDefault()
      }
    }
  }
)
