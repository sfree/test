define(
  [
    "d3"
  , "./js/suggestions"
  , "./js/combo"
  , "./js/dropdown-list"
  , "./js/text-combo"
  , "./js/redispatcher"
  ]
, function(
    d3
  , createSuggestions
  , createLookup
  , createDropdownList
  , createTextInput
  , redispatcher
  ) {
    return function() {

      var dropdownList = createDropdownList()
        , suggestions = createSuggestions()
        , textField = createTextInput()
        , combo = createLookup()
              .dropdownList(dropdownList)
              .suggestions(suggestions)
              .textField(textField)
        , d = redispatcher()
            .proxy(combo, "select", "deselect", "input", "focus")

      function proxy(selection) { (selection || this).call(combo) }

      return d3.rebind(
        d3.rebind(
          d3.rebind(
            d3.rebind(
              proxy
            , combo
            , "allowFreeTextInput"
            , "focused"
            , "label"
            , "loading"
            , "openOnStart"
            , "prompt"
            , "query"
            , "selected"
            )
          , d
          , "on"
          )
        , dropdownList
        , "open"
        , "drawEmptyResults"
        , "drawDropdownSuggestion"
        )
      , suggestions
      , "filter"
      , "groupingFunction"
      )

    }
  }
)