Swift
=====

[Swift](https://neo-qa1.ubsdev.net/swift) is an application for simple release definition and fast automated deployment across environments. It makes it easy to define a release from a set of artifacts, to configure environmental properties, and to run automated release plans across a globalised server estate.

The technical solution consists of a web-based front-end developed with the [UBS Web SDK](http://goto/websdk) and a Spring MVC service layer that mediates a number of underlying tools, including [Apache ZooKeeper](http://zookeeper.apache.org/) for property management, [glu](https://github.com/linkedin/glu/wiki) for deployment and monitoring and [Sonatype Nexus](http://www.sonatype.org/nexus/) for artifact management.

The Swift GUI is backed by a comprehensive service API documented in the [NeoSwift/docs](https://github.ldn.swissbank.com/NeoSwift/docs/blob/master/README.md) repository.

Check out the [Swift Tutorial](http://confluence.swissbank.com/display/neo/Swift+Tutorial) for a short guide on requesting access and using swift to manage your deployments.

## For developers

In order to develop NeoSwift locally you'll need to execute the following steps:

### Node and Dave

Before you continue with the rest of the instructions make sure you've visited the [Web SDK](http://goto/websdk) website and followed the Get Started instructions in the end of the page.
In a nutshell you'll be asked to install [node.js](http://nodejs.org/) and dave. If you already have node just run the following command to get dave installed locally:

    curl -fsSkL goto/local-install-dave | sh

### Swift configuration

First of all, don't forget to `git clone git@github.ldn.swissbank.com:NeoSwift/swift-client.git`.  
Then create a `paths.json` under `swift-client` with the following content:

```json
 {
    "resources": "resources",
 	"/login-service": "http://deploy-dev.ldn.swissbank.com:10000/login-service",
    "/api": "http://deploy-dev.ldn.swissbank.com:10000/api"
 }
```

### Using a local server

If you have a Swift Server running locally make sure you edit the `endpoints.json` file under `resources` to match your workstation:

```json
{
 ...
    "swift-streaming": [
      "<YOUR_WORKSTATION>.ubsprod.msad.ubs.net:18622/swiftsockjs"
    ],
    "useSSL": false
 ...
}
```
and also the `paths.json` created earlier:
```json
{
 ...
    "/api": "http://<YOUR_WORKSTATION>.ubsprod.msad.ubs.net:18610/api"
 ...
}
```
To run a local Swift Server, see the [swift-server](https://github.ldn.swissbank.com/NeoSwift/swift-server) project.

### Running Swift

So you're almost there, now just

* On the `swift-client` directory run `dave run server`
* Login at `http://<your_hostname>.ubsprod.msad.ubs.net:8080/login`
* Open swift at `http://<hostname>.ubsprod.msad.ubs.net:8080/swift`

You're done. Have fun.

### Recommended Reading

* [Swift Coding Style Guide](https://github.ldn.swissbank.com/NeoSwift/docs/blob/master/README.md#code-style-guide)
* [Codebase Review I (June): Global Modules](https://github.ldn.swissbank.com/NeoSwift/swift-client/wiki/Codebase-Review-I-(June\):-Global-Modules)
