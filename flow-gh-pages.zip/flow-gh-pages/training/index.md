---
title: Training
subtitle:
  UBS offers a wide variety of training opportunities, including in-house training courses,
  conferences, special events, and a lively culture of "brown bag" presentations across teams.
layout: training
---

## UBS Agile

UBS has an active community of agile development enthusiasts who run many in-house training courses and often invite guest speakers. These events align closely with the practices described in UBS Flow. Find out more in the [UBS Agile Connections Group](https://connections.swissbank.com/groups/ubs-agile).

## Business University

[goto/university](http://goto/university)

## My Campus Online Learning

[goto/mycampus](http://goto/mycampus)

## Mindshares & Business Speaker Series

The London IT community runs a variety of [educational events](https://connections.swissbank.com/groups/place-calendar.jspa?containerType=700&container=1211), including their MindShare and Business Speaker Series of talks. Find out more in the [UK IT Connections Group](https://connections.swissbank.com/groups/uk-it).

## Safari Books Online

Free access to a wealth of technical books are available online.[Register here](http://techbus.safaribooksonline.com/?uicode=UBSCH).
