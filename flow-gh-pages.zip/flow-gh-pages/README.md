UBS Flow
========

The website for UBS Flow, published at: <http://goto/ubsflow>

## What is UBS Flow?

UBS Flow is a new way to develop software in UBS that aims to make the process efficient and fun. 
It combines a flexible methodology with collaborative tooling and in-house training. There are important control gates in place too, but UBS Flow tries to make these as straightforward as possible. UBS Flow is designed to evolve, through an open process that you can participate in.

## How to contribute

Read the [Writing a guide](https://github.ldn.swissbank.com/pages/OpenUBS/flow/guides/writing-a-guide.html) instructions.

Refer to the [Style guide](https://github.ldn.swissbank.com/pages/OpenUBS/flow/guides/style-guide.html) for tips about writing effective guides.

