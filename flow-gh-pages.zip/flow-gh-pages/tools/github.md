---
layout: tool

title: Use <em>GitHub</em> for collaborative coding

guide: github.html

benefits:

  - title: Store code securely
    text: Code is stored on-line in hosted Git repositories with scheduled back-ups. Access is protected by HTTPS or SSH with WebSSO authentication and ARP rights management. Access-right reviews take place in ARP.

  - title: Transparent development
    text: Watch repositories and follow developers to see all the relevant development activity taking place. View graphs of contributions, code frequency and impact for insights into the changing codebase.

  - title: Efficient workflow
    text: Prepare code changes then send a pull-request for review by teammates. Discuss and improve the proposed changes collaboratively. Only accept code that meets quality standards into the next release.

integration:

  - title: Synchronize Jira status
    from: github
    to: jira
    text: If a GitHub commit message contains a Jira reference, then change the status of a Jira issue accordingly.
    guide: 

  - title: Continuous integration
    from: github
    to: teamcity
    text: If code changes in a GitHub repository, then trigger a build in the TeamCity continuous integration server.
    guide: 

---

GitHub is a collaborative development tool for teams of all sizes and distributions.
Use it to store code securely and view the development activity taking place at any time.
Review and approve code contributions, and search and discover reusable code assets.
