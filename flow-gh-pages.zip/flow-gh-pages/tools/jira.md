---
layout: tool

title: Use <em>Jira</em> for project planning and delivery tracking

guide: jira.html

benefits:

  - title: Plan Software Delivery
    text: Create a per project backlog of issues and stories. Plan releases and sprints in a simple drag-and-drop interface.

  - title: Simple Tracking
    text: Track your projects from a simple story board view, with detailed pre-canned reports or with highly customisable reports.

  - title: Flexible Workflows
    text: Jira allows custom workflows to accomodate to the way the team likes to work.

integration:

  - title: Synchronize Jira status
    from: github
    to: jira
    text: If a GitHub commit message contains a Jira reference, then change the status of a Jira issue accordingly.
    guide: 

  - title: Raise Jira issues by email
    from: email
    to: jira
    text: You can conveniently create new issues and leave comments to existing ones by email.
    guide: 

---

Jira is an issue tracking tool that supports the planning and delivery of software projects. The Jira Agile plugin adds a planning and storyboard view to faciliate agile teams.
