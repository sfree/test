---
title: Use <em>ATTi</em> for requesting application accounts
subtitle: 
  Administration of Technical and Transferable Identities (Atti) is a portal for request application accounts in a range of systems including WebSSO and Active Directory.
layout: service
usage: mandatory
---

## How to access

ATTi is available at [goto/atti](http://goto/atti)

## When to access

When you require an application account (or service account) for accessing a system such as WebSSO or Active Directory.

## How to use

To request an application account, login and you will generally want to select "Technical User Identity for Application".

To review a request that's been raised login and select "Inspect requests assigned to me."

## Support

- [ATTi Support](http://goto/atti-help)
