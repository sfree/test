---
title: Google Chrome
subtitle: 
  UBS has a single-browser strategy, so Google Chrome is not allowed for most staff. However, some staff in software development teams need Google Chrome in order to develop and test web applications. A formal exception process is in place to accomodate this.
layout: service
usage: optional
---

## Do I need Google Chrome?

A significant portion of UBS clients access our applications using Google Chrome. If you are developing client-facing applications, you will therefore need to use Google Chrome to develop and test effectively.

If you are developing internal-only web applications, then you do not strictly need Google Chrome. However, you may be able to work more productively using it, because of the superior development tools it includes.

## How do I get Google Chrome?

You **must not** download Google Chrome directly from the internet. This is **forbidden** by UBS policy and will be detected by desktop scanning software. Similarly you **must not** download Google Chrome plug-ins from the internet. This is also **forbidden**.

Instead you must follow a request process described in this UBS Connections post:

- [How to request access to Google Chrome](https://connections.swissbank.com/groups/html-sdk/blog/2014/06/11/how-to-get-chrome-at-ubs-official-route)

If your request is approved, your desktop will be provisioned with a UBS-packaged version of Google Chrome that has had various features disabled for security reasons, such as auto-updating.
