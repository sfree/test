---
layout: tool

title: Use <em>Fortify</em> static code analysis for security issues

guide: static-code-analysis.html

benefits:

  - title: Detect security issues early
    text: Code is scanned during development process to detect common vulnerabilities, security issues and code quality issues.

  - title: Meet regulatory requirements and policy
    text: Some jurisdictions require regular security code scanning as part of the development process. Policy requires scanning for passwords in source code for all applications. For more details follor this [link](http://goto/security-static-analysis)

integration:

  - title: Continuous Integration
    from: teamcity
    to: fortify
    text: TeamCity runs Fortify scan on a regular basis.
    guide: 

---

Fortify is the approved tool for source code scanning.

Static analysis is an automated way of identifying security vulnerabilities in application source code without executing the application. The analysis makes use of several engines to analyse data flow, control flow, semantics, structure and configuration.



