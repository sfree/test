---
layout: service
title: Postman Pat
subtitle: Tool for testing APIs
usage: required
status: In-progress
author: Pooja Kulkarni
---

##What?

Postman helps you easily work with APIs. You can send the requests and get the response from APIs. The requests can also be saved in collections for future use. 

##Why
Postman provides you an interface to construct any kind of request quickly. You can easily input the four parts of HTTP requests (URL, method, headers and the body) from its interface.

##Who

**Quality Analysts**, **Developers** can use Postman to construct the request and to test the APIs.

##How 

Installation -

You can install Postman from chrome web store - http://www.getpostman.com/

Usage -

1.	On top of Postman webpage, choose tab Normal, then put the URL request (for example: https://neo-qa3.ubsdev.net/api/track/v1/even) in the textbox.

2.	Next to the URL textbox, from the dropdown list, you can choose the method (GET, POST, PUT etc.) to send the URL.

3.	Click URL params or Headers, then you can specify the URL or header name and value.

4.	Below the headers, you can input the body of the request. There are three types of body you can input. The form-data and x-www-form-urlencoded editors let you set key/value pairs for your data. The raw editor let you input anything.

5.	After sending the request, Postman response viewer returns the headers, the body and the status code so you can analyse the
API or the system. You can format the body of the response in JSON or XML format so that they are easier to look at. The raw view
returns the response body in text format. The Preview tab shows the response in a sandboxed iframe which shows you the look of a web
page. You can also get the details of the status by hovering over the status code. They are the HTTP status which you can use to analyse if the request, API or system behave correctly.

6.	Postman also provides the function for authentication. Based on the setting of your system, you can configure different authentication methods such as Basic Auth, Digest Auth and OAuth.

7.	On the left sidebar, all the requests are recorded in History so you can reuse them quickly. You can also set up Collections and group the requests into collections or sub-collections. Collections are listed in alphabetical order. 

