---
layout: service
title: Load Runner
subtitle: Performance and Load test your application with Load Runner
usage: required
status: done
author: Pooja Kulkarni
---

#What?

Load Runner is automated performance and test automation application for verifying system behavior and performance while 
generating actual load.

Load Runner comes with 4 applications within it :

- VuGen (Virtual user generator) for gernerating and editing scripts
- Controller for writing and orchestrating  test scenarios, like, how long the script should run, how the load is spread over time, what load has to be generated etc.
- Analysis : this gathers logs from different load generators and formats reports for visualisation of run data and monitoring data
- Load Generator : Generates load against the required application

Load runner can generate thousands of concurrent users against the apllication like real-life user loads while gathering all the important statistics from infrastructure components.

#Why?

Performance and Load testing is a key area for any quality assurance team. Before signing off a release, it is absolutely important to give detailed reports about how much load the application can handle, how the application behaves under high load and what is the behavior of infratructure components under various loads. 

Using these data, the business can make informed decisions about roll out plans for the apllication, keeping in mind the limiations if any.

#Who?

[Quality Analysts]({{ site.url }}/guides/quality-analyst.html) can use Load runner to performance and load testing of the application

#When?

Load testing can start at early stages of testing. A sanity load check has to be run at regular intervals as a healthcheck for apllications.

Detailed load testing can be planned depending on the complexity of the changes, or new features built.

#How?

- Load Runner VuGen can be requested from [IOPS](goto/IOPS) (This request will go for further approval, however)
- The controller has to be booked in advance by the teams, furhter information about booking is available [here](http://confluence.swissbank.com/display/SETS/LoadRunner+-+Controller+Booking#LoadRunner-ControllerBooking-Controllerdetails)
