---
layout: service
title: Charles
subtitle: 
usage: required
status: In-progress
author: Pooja Kulkarni
---

##What?

Charles is intended to be a dive-in piece of software. Start it up, it will attempt to automatically configure your browser so you’re up and running immediately. Start browsing the web and watch the results appear in Charles; click on them and take a look at what is recorded.
Features:

- Proxying
- Throttling
- Breakpoints
- SSL Proxying
- Map local

##Why?

- Charles is an HTTP Proxy / HTTP monitor / Reverse Proxy that enables a developer to view all the HTTP and SSL / HTTPS   traffic between their machine and the internet
- It includes requests, responses and HTTP headers (which contains cookies and caching information)
- It can be used to intercept the requests and tweak them and send it to server to check the response from the server
- It can be used to generate network Throttling to test connectivity and performance issues
- The bandwidth may be throttled to any arbitrary bytes per second. This enables any connection speed to be simulated.

##Who?

- Developers
- Testers

#When?

- By developers in development phase
- By QA while testing server responses
- Performance and Security testers  while measuring performance and security vulnerabilities           

#How?

You can get Charles proxy by registering it from goto/devtools.
1. Go browser, type goto/devtools
2. Enter Charles Proxy for the Product name to be searched
3. Register the product
4. Install the exe from the location provided

NOTE: You need to have PART access to install the .exe on your machine.
