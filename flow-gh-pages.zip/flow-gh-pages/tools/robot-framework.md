---
layout: service
title: Robot Framework
subtitle: Generic framework for cross platform and cross technology test automation
usage: required
status: done
author: Binith Krishnan
---

## What?

[Robot Framework](http://robotframework.org/) is an open source, general purpose automation framework for acceptance testing and acceptance test-driven development (ATDD).  Its testing capabilities can be extended by test libraries implemented either with Python or Java, and users can create new higher-level keywords from existing ones  

**Features**
 
- Platform and application independent
- Categorize and run tests implemented with any 3rd party tools which exposes an API
- [Tagging](http://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#tagging-test-cases) to group and select test cases to be executed.
- [Log](http://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#log-file) and [report](http://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#report-file) files in HTML format
- Data-driven and behavior-driven (BDD) approaches for writing tests in DSL (Domain Specific Language)
- An IDE - [RIDE](https://github.com/robotframework/RIDE)


**Examples**
- [Robot Framework Calculator Demo](https://bitbucket.org/robotframework/robotdemo/wiki/Home)
- [Web testing with Robot Framework and Selenium2Library](https://bitbucket.org/robotframework/webdemo/wiki/Home)

## Why?


- It can be used as the common tool for many different automation scenarios
- Better readability of test cases
- Can be used collaboratively by different stake holders like business, QA and Dev teams
- Exposes APIs for integration with tools like Jira, GitHub and TeamCity
- Availability of ready to use libraries for most common automation scenarios
- Custom automation scenarios can be implemented in Python, Java or [other programming languages](https://code.google.com/p/robotframework/wiki/RemoteLibrary).

## Who?


- [Business analysts]({{ site.url }}/guides/business-analyst.html) should write acceptance tests in DSL
- [Software engineers]({{ site.url }}/guides/software-engineer.html) should write component level tests and low level integration tests
- [Quality analysts]({{ site.url }}/guides/quality-analyst.html) should write end to end functional automation tests and verify the results

## When?


- By [Business analysts]({{ site.url }}/guides/business-analyst.html) during requirement gathering 
- By [Software engineers]({{ site.url }}/guides/software-engineer.html) during component level testing and integration tests
- By [Quality analysts]({{ site.url }}/guides/quality-analyst.html) for regression tests and throughout project lifecycle

## How?

1. Get Python 2.7 from goto/iops 
2. Install Robot Framework from [here](https://pypi.python.org/pypi/robotframework)



Following are some of the Robot Framework test libraries available for different test scenarios

|Scenario | Libraries | Example |
|------------|-----------|---------|
| Web | [Selenium WebDriver](https://github.com/rtomac/robotframework-selenium2library) | [Example](https://bitbucket.org/robotframework/webdemo/wiki/Home) 
| HTTP and REST | [Robot Framework Requests](https://github.com/bulkan/robotframework-requests) | [Example](https://github.com/bulkan/robotframework-requests/#readme) 
| SOAP | [Robot Framework Suds](https://github.com/ombre42/robotframework-sudslibrary) | [Example](http://ombre42.github.io/robotframework-sudslibrary/doc/SudsLibrary.html)
| Windows  | [Robot Framework AutoIt](http://code.google.com/p/robotframework-autoitlibrary/) | [Example](https://blog.codecentric.de/en/2014/02/robot-framework-testing-windows-applications/)
| Database  | [Robot Framework Database library](http://franz-see.github.io/Robotframework-Database-Library/) | [Example](http://franz-see.github.io/Robotframework-Database-Library/api/0.6/DatabaseLibrary.html)

[TeamCity]({{ site.url }}/tools/teamcity.html) is used to run automated test cases automatically when code changes in [GitHub]({{ site.url }}/tools/github.html) automation repositories.

## Good practices


- [How to write good automation test cases](https://code.google.com/p/robotframework/wiki/HowToWriteGoodTestCases)
- [ATDD with Robot Framework](http://wiki.robotframework.googlecode.com/hg/publications/ATDD_with_RobotFramework.pdf)

## Integration With other tools


- [API](http://robot-framework.readthedocs.org/en/latest) for integrating with other tools like TeamCity or GitHub
- [Jenkins plugin](https://wiki.jenkins-ci.org/display/JENKINS/Robot+Framework+Plugin)
- [IntelliJ plugin](http://plugins.jetbrains.com/plugin/7386?pr=)
- [Listener interface to catch live test events](http://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#using-listener-interface)

## Learn more


- [Detailed installation instructions](https://github.com/robotframework/robotframework/blob/master/INSTALL.rst)
- [Quick Start Guide](http://code.google.com/p/robotframework/wiki/QuickStartGuide)
- [Complete User Guide](http://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html)
- [Codecentric blogs](https://blog.codecentric.de/en/?s=Robot+Framework)
- [Test Libraries](http://robotframework.org/#test-libraries)
- [CERN's guide on Robot Framework](https://twiki.cern.ch/twiki/bin/view/EMI/RobotFrameworkAdvancedGuide)

