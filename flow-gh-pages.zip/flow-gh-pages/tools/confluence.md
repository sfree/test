---
title: Use <em>Confluence</em> for ad hoc documentation
subtitle: Confluence is a wiki product from Atlassian. It is provided as a managed service in UBS and can be used for storing and collaborating on documentation.
layout: service
usage: optional
status: in-review
---

##Benefits:

  - **Collaborate**
     Work together on documentation and let the community help you maintain it.


##Get Access

Lync is available with a choice of profiles depending on the features you intend to you.

- [Login to Confluence](http://confluence.swissbank.com/)
- [Create a new space](http://confluence.swissbank.com/spaces/createspace-start.action) to store your team/projects documentation

##Contact

- \#confluence - The Confluence user community, this is not a support group
- **#IMS_Confluence_Support** - Confluence support team
