---
layout: tools
title: Tools
---

<div>

  <h3>Platforms</h3>
  <ul>
    <li><a href="">iOS</a></li>
    <li><a href="">Java</a></li>
    <li><a href="">NodeJS</a></li>
    <li><a href="">Python</a></li>
    <li><a href="">Windows</a></li>
  </ul>

  <h3>Browsers</h3>
  <ul>
    <li><a href="">IE</a></li>
    <li><a href="">Chrome</a></li>
    <li><a href="">Firefox</a></li>
    <li><a href="">Safari</a></li>
  </ul>

  <h3>Communication</h3>
  <ul>
    <li><a href="">Connections</a></li>
    <li><a href="{{ site.tools }}/email.html">Email</a></li>
    <li><a href="{{ site.tools }}/lync.html">Lync</a></li>
    <li><a href="">MindAlign</a></li>
  </ul>

</div>

<div>

  <h3>Design</h3>
  <ul>
    <li><a href="">Creative Suite</a></li>
    <li><a href="">Visio</a></li>
  </ul>

  <h3>Development</h3>
  <ul>
    <li><a href="">Git</a></li>
    <li><a href="">Eclipse</a></li>
    <li><a href="">IntelliJ</a></li>
    <li><a href="">Jekyll</a></li>
    <li><a href="">SublimeText</a></li>
    <li><a href="">Visual Studio</a></li>
  </ul>

  <h3>Testing</h3>
  <ul>
    <li><a href="">Charles</a></li>
    <li><a href="">Fiddler</a></li>
    <li><a href="">jMeter</a></li>
	<li><a href="{{ site.tools }}/koo.html">Koo</a></li>
    <li><a href="">LoadRunner</a></li>
    <li><a href="">NEWT</a></li>
    <li><a href="">PostMan</a></li>
    <li><a href="">QualityCentre</a></li>
    <li><a href="">TestComplete</a></li>
    <li><a href="">Wireshark</a></li>
  </ul>

</div>

<div>

  <h3>SDKs &amp; APIs</h3>
  <ul>
    <li><a href="">iOS SDK</a></li>
    <li><a href="">Java SDK</a></li>
    <li><a href="http://goto/websdk">Web SDK</a></li>
    <li><a href="http://goto/api">UBS API</a></li>
  </ul>

  <h3>Core Services</h3>
  <ul>
    <li><a href="{{ site.tools }}/jira.html">Jira</a></li>
    <li><a href="{{ site.tools }}/github.html">GitHub</a></li>
	<li><a href="{{ site.tools }}/teamcity.html">TeamCity</a></li>
    <li><a href="">Nexus</a></li>
    <li><a href="{{ site.tools }}/swift.html">Swift</a></li>
    <li><a href="">Puppet</a></li>
  </ul>

  <h3>Extra Services</h3>
  <ul>
    <li><a href="">AppDynamics</a></li>
    <li><a href="">Autosys</a></li>
    <li><a href="">BlackDuck</a></li>
    <li><a href="">BlueOptima</a></li>
    <li><a href="{{ site.tools }}/confluence.html">Confluence</a></li>
    <li><a href="{{ site.tools }}/fortify.html">Fortify</a></li>
    <li><a href="">OpenView</a></li>
    <li><a href="">SonarCube</a></li>
    <li><a href="">Splunk</a></li>
  </ul>

</div>

<div>

  <h3>Institutional Tools</h3>
  <ul>
    <li><a href="">AccessIT</a></li>
    <li><a href="">ARC</a></li>
    <li><a href="">ARP</a></li>
    <li><a href="">ATTi</a></li>
    <li><a href="">BBS</a></li>
    <li><a href="">Beeline</a></li>
    <li><a href="">CDCI</a></li>
    <li><a href="">Carat</a></li>
    <li><a href="">EOS</a></li>
    <li><a href="">Extract</a></li>
    <li><a href="">GBC</a></li>
    <li><a href="">iSAC</a></li>
    <li><a href="">IOPS</a></li>
    <li><a href="">OBI Tool</a></li>
    <li><a href="">Optima</a></li>
    <li><a href="">PlanningIT</a></li>
    <li><a href="">ReleaseNow</a></li>
    <li><a href="">SEEM</a></li>
    <li><a href="">ServiceNow</a></li>
  </ul>

</div>
