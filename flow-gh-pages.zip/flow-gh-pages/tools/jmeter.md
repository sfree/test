---
layout: service
title: Jmeter
subtitle: Tool to perform load and stress testing
usage: required
status: In-progress
author: Saurav Santosh
---

## What?

JMeter is an open source load testing tool, written in pure Java and originally designed for testing Web Application but also expanded to other test functions. It can be used to simulate a heavy load on a server, group of servers, network or object to test its strength or to analyse overall performance under different load types. You can use it to make a graphical analysis of performance or to test your server/script/object behaviour under heavy concurrent load.

Supported protocol types:

- Web: HTTP,HTTPS
- SOAP
- FTP
- LDAP
- JDBC (Database)
- JMS (MOM)
- SMTP,POP3,IMAP
- NoSQL
- Shell scripts
- TCP


## Why?

- Can be used as a unit test tool for JDBC database connection, FTP, LDAP, WebServices,JMS, HTTP and generic TCP connections. 
- Can also be configured as a monitor, although this is typically considered an ad-hoc solution in lieu of advanced monitoring solutions. 
- Supports variable parameterization, assertions (response validation), per thread cookies, configuration variables and a variety of reports.


## Who?

- Both software engineers and Quality analysts can write load & stress test scripts as need be.
- Testers should verify the results and compare it with set benchmark.


## How and When?

JMeter can work with any system that have complaint Java implementation (Windows XP, Windows 7/8/8.1, Mac OSX etc. �).It can be installed by placing a request on [goto/devtools](goto/devtools) and then unzip the zip/tar file into the directory where you want JMeter to be installed.
 
This should be run after service developed is bit stable and has gone through a round of functional tests. The performance test results can be presented in form of table or graph.


**Learn more**

- [JMeter_Beginner's Guide Document](https://teams.ib.cnet.ubs.net/sites/f35/technical/Test/8.%20Non%20Functional%20Testing/7.%20NFR%20Performance%20and%20Capacity/JMeter_Beginners%20Guide.docx)
- [Jmeter User Manual](http://jmeter.apache.org/usermanual/)

