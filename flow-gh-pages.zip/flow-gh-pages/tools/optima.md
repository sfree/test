---
title: Use <em>Optima</em> for reviewing invoices
subtitle: 
  Optima is a tool used for reviewing and approving or rejecting invoices. If you have professional consultants on your team or you are involved in licensing vendor products, you may need to review and approve the payment of invoices to suppliers using Optima.
layout: service
usage: optional
---

## How to access

Optima is available at [goto/optima](http://goto/optima)

## When to access

If your role involves approval of invoices, you should review Optima on a weekly basis.

## How to use

You will find scanned copies of invoices within Optima, together with messages from other staff who have received and processed the invoices. 

You should review any invoices carefully, to ensure that the costs are as expected. You can then approve or reject each invoice and provide commentary. 

_Tip: it may help you to keep your own spreadsheet of expected day-rates and contract periods for your staff, so you can compare this to the invoices more easily._

**Warning: it is fairly common for invoices to be incorrectly routed, such that you may receive an invoice for a member of staff that does not work for you. In this case, you should reject the invoice and give the reason that you are the wrong person to review it.**
