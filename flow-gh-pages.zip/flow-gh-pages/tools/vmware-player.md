---
layout: service
title: VMware Player
subtitle: Virtual environment to simulate software under different operating systems
usage: required
status: done
author: Binith Krishnan
---

## What?

VMware Player is a virtualization software package supplied by [VMware](http://www.vmware.com).
Using VMware Player you can install, keep and use different flavours of Windows, Linux and Unix all under your own private desktop environment. In other words you can host different operating systems privately without depending on organizations's infrastructure

## Why?

Often, especially while simulating a real client/customer's environment there is a need to test -


- Same software on different operating systems
- Different versions of same software on same or different operating systems
- Look and feel of an application on different operating systems


Example : Simulate how a functionality of website might behave on Internet Explorer version 8 on Microsoft Windows7 and on Internet Explorer version 11 on Windows Vista

## Who?

- [Software engineers]({{ site.url }}/guides/software-engineer.html) 
- [Quality analysts]({{ site.url }}/guides/quality-analyst.html) 

## When?

- Simulate how software behaves under different operating systems 
- Use different versions of a software that is required for testing - for example different versions of Mozilla Firefox

## How?

1. Install VMWARE CLIENT PLAYER DTP-7 from [goto/iops](goto/iops)
2. Get the required SEEM exception from [goto/seem](goto/seem)
3. Download the required operating System image 
4. Obtain the required license for the oparating system image, if applicable
5. Install the image on your private VMWare Player



## Learn more


- [Features](http://www.vmware.com/uk/products/player)
- [FAQ](http://www.vmware.com/products/player/faqs/faqs)
- [supported OSs](https://www.vmware.com/support/ws5/doc/intro_supguest_ws.html)

