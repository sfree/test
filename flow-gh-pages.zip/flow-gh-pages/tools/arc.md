---
title: Use <em>ARC</em> for reviewing access to IT applications
subtitle: 
  Access Rights Certification (ARC) is an Investment Bank IT Access review tool.
layout: service
usage: mandatory
---

## How to access

Access IT is available at [goto/arc](http://goto/arc)

## When to access

When you are required to perform a review of access rights as a role owner or line manager of an employee moving roles. You will be notified by email if yoy're required to perform a review.

Annual reviews are now performed in [AccessIT]({{ site.tools }}/access-it) and at some point all reviews will be moved from ARC in to [AccessIT]({{ site.tools }}/access-it).

## How to use

You will be presented with a list of all the access that you need to review. You will need to either approve or revoke the access you are reviewing.

## Support

- [ARC Support](http://goto/arc-help)
