---
layout: tool

title: Use <em>TeamCity</em> for Continuous Integration

guide: teamcity.html

benefits:

  - title: Continuous Integration
    text: TeamCity can execute a build immediately that a user commits changes to a project so that issues relating to a broken build are identified immediately

  - title: Run automated tests, code coverage, profiling, etc.
    text: Once an application is built, teamCity can run a series of checks and report on the sucess or otherwise.  For example, it can report a build failure if the code coverage drops or unit tests fail.

  - title: Comprehensive Statistics Reports
    text: Statistics on any part of the build process can be recorded and tracked over time.

  - title: History
    text: Full history of builds, tests, coverage, etc. retained

  - title: Pre-Integrated and Extensible
    text: TeamCity is an all-in-one pre-integrated solution. Suitable for all platforms (Java, .NET or for mobile platforms).

  - title: For more details
    text: see <a href="https://www.jetbrains.com/teamcity/features/">https://www.jetbrains.com/teamcity/features/</a> </br> and <a href="https://connections.swissbank.com/groups/ibit-sdlc-convergence/blog/2014/11/10/teamcity-as-a-service">https://connections.swissbank.com/groups/ibit-sdlc-convergence/blog/2014/11/10/teamcity-as-a-service</a>

integration:

  - title: Identify changes in a build
    from: github
    to: teamcity
    text: TeamCity provides a full record of all changes in a build - detailing the user, the comment, the impacted files and the change details.
    guide: 

  - title: Instant view of build-specific information
    from: jira
    to: teamcity
    text: View build statistics within JIRA, track results of each build, easily acquire build change log with description of changes introduced
    guide: 

  - title: Automatically scan code for security vulnerabilities
    from: teamcity
    to: fortify
    text: TeamCity can run the Fortify Static Code Analysis tool each time code is changed or released and can upload the analysis report to the UBS <a href"https://fortify.swissbank.com/">Software Security Center</a> server for auditing.
    guide: 

---

TeamCity is a Continuous Integration tool.
