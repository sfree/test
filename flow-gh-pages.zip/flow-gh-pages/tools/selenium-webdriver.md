---
layout: service
title: Selenium WebDriver
subtitle: Browser Automation
usage: required
status: done
author: Binith Krishnan
---

## What?

[Selenium WebDriver](http://docs.seleniumhq.org/projects/webdriver/) is the the most popular tool for automating test cases which run in a browser. 


**Highlights**
 
- Open Source
- Works with all major browsers
- Fully implemented and supported in Python, Ruby, Java, and C#
- Well documented APIs
- Active community
- Native access to browser elements
- Backed by [W3C](https://dvcs.w3.org/hg/webdriver/raw-file/default/webdriver-spec.html)



**Examples**

- [Examples in different programming languages](http://docs.seleniumhq.org/docs/03_webdriver.jsp#introducing-the-selenium-webdriver-api-by-example)
- [Robot Framework](robotframework.org) based [example](https://bitbucket.org/robotframework/webdemo/wiki/Home)


## Why?


- Best open source choice for browser automation
- Supported by multiple programming languages and automation frameworks
- Supported by cloud infrastructures like  [Sauce Labs](saucelabs.com) and [BrowserStack](http://www.browserstack.com/)

## Who?


- [Software engineers]({{ site.url }}/guides/software-engineer.html) should write component level tests and low level integration tests
- [Quality analysts]({{ site.url }}/guides/quality-analyst.html) should write end to end functional automation tests and verify the results

## When?


- By [Software engineers]({{ site.url }}/guides/software-engineer.html) during component level testing and integration tests
- By [Quality analysts]({{ site.url }}/guides/quality-analyst.html) for regression tests and throughout project lifecycle

## How?

| Environment     | Source 
|-----------------|-----------
| Java   | [UBS internal](http://nldn4822pap.ldn.swissbank.com/user/register.aspx?search=selenium&category=any)
| Python | [Pypi](https://pypi.python.org/pypi/selenium)
| Robot Framework | [Pypi](https://github.com/rtomac/robotframework-selenium2library)


## Good practices


- [Page Object Model](https://code.google.com/p/selenium/wiki/PageObjects)
- [General best practices](http://docs.seleniumhq.org/docs/06_test_design_considerations.jsp)



## Learn more


- [Quick Start Guide](https://code.google.com/p/selenium/wiki/GettingStarted)
- [Official Documentation](http://docs.seleniumhq.org/docs/03_webdriver.jsp)
- [Martin Fowler on Page Objects](http://martinfowler.com/bliki/PageObject.html)
- [Architecture and history of Selenium](http://aosabook.org/en/selenium.html)
