---
layout: service
title: Quality Center 
subtitle: Repository for your test cases
usage: required
status: in-progress
author: Pooja Kulkarni
---

##What?

Quality Center is a Test management softwre from HP. Quality Center has many capabilities within it like requirement management, test management, defect management and reporting.

##Why?

Quality center has many features avaiable -

- Repository of tests cases
- Maintainance of historical test runs with all the test evidence
- Integration with other test autoamtion tools like QTP, Load Runner and Winrunner
- Report and graph generation for analysis of tracking test cycles
- Easy way of linking tests and defects to requirements thus providing test coverage of each of the requirement

##Who

This is generally used by **Quality Analysts** to maintain repository of test cases and test runs. 

##When?

Quality center can be used for various purposes.

- It can be used for complete release cycle including requirement gathering, testing and defect management
- Only as regression test cases repository and maintining historical regression test runs

##How

This can be ordered from IOPS(goto/IOPS). 

Once installed, this can be launched from [IE](http://qualitycenter.ldn.swissbank.com/qcbin/start_a.htm) OR using the desktop application

##Learn more 

[HP Quality Center](http://www8.hp.com/uk/en/software-solutions/quality-center-quality-management/index.html)
