---
title: UBS Connections
subtitle: 
  UBS Connections is our enterprise social network. It helps staff to collaborate with one another, across teams, departments, divisions and timezones. Users can publish documents, post commentry, ask questions, share ideas and much more. Make a habit of using Connections every day.
layout: service
usage: recommended
---

## What is Connections?

UBS Connections is an enterprise social network based on the Jive SBS product. Every staff member has access to UBS Connections and can use the tool to:

- Publish and read documents and commentary across diverse subjects
- Get help by asking technical questions to a broad community
- Follow staff that you're interested in to receive notifications of their activity
- Join groups of staff aligned to technology areas, projects and products
- "Like", rate and share the content you read within your network
- Share and vote on ideas to collectively improve the way we operate

## Getting Started

- Open [goto/connections](http://goto/connections) then bookmark it or make it your homepage.
- Explore the content you see and the profiles of other users. Follow interesting people. Join interesting groups.

## Relevance to Software Development

UBS Connections is a great tool for software development teams to:

- Engage in technical debate. See the [Collaborative Development Manifesto](https://connections.swissbank.com/docs/DOC-39478).
- Announce software releases. See the [Release Blog]({{ site.guides }}/release-blog.html) article.
- Share knowledge of new technologies and build communities of expertise.

You can create new groups within UBS Connections for your projects, services and technology interests.

## Learn more

You can learn more about UBS Connections here: 

- [UBS Connections User Guide]()
