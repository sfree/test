---
title: Use <em>MindAlign</em> for collaboration group chat.
subtitle: MindAlign is a desktop group chat tool. Collaborate in long lived chat channels.
layout: service
usage: required
status: in-review
---

##Benefits:

  - **Long Lived Chat Channel**
     Pop in to long lived chat channels to collaborate with a team or community.

##Get Access

MindAlign is setup as standard for most employees when they join the bank.

- [Request Lync for your desktop](http://goto/iops) if you need the software installing on a desktop. (Select MINDALIGN CHAT SYSTEM)
- [Order a MindAlign Account](http://bw.assist.ubs.com/node/24900) if you can't login 
- [Request a New Chat Channel](http://machatweb.swissbank.com/) to request a new channel
- [Administer an Existing Channel](http://chatcentral.swissbank.com/website/index.jsp)

MindAlign will eventually be decomissioned and replaced with [Lync Group Chat]({{ site.tools }}/lync.html)

##How to Use

To login you will need to prefix your username with ubsw\ for example ubsw\levyjo.
