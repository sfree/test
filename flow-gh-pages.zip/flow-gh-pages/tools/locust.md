---
layout: service
title: Locust 
subtitle: An open source load testing tool
usage: required
status: done
author: Binith Krishnan
---

## What?

Locust is a new generation load test tool written in Python. Locust is not thread bound, and hence can generate higher loads with less system resources 

## Why?

- When compared to more established load testing tools which use a GUI to define the tests locust tests are written directly in (Python) code which allows to easily represent complex user behaviours
- Uses an event based approach to generate load instead of thread-model
- Distributed and scalable to simulate millions of users
- Web interface for invoking tests and viewing statistics

## Who?

- [Software engineers]({{ site.url }}/guides/software-engineer.html) 
- [Quality analysts]({{ site.url }}/guides/quality-analyst.html) 

## When?

- Simulate high loads on a website
- Simulate high loads directly on a REST or SOAP API
- Simulate high loads on other network services

*High loads can be in terms on number of requests per second or number of simultaneous users or both*

## How?

1. Get Python 2.7 from goto/iops 
2. Install Locust from [here](https://pypi.python.org/pypi/locustio)

## Learn more

- [Official website](http://locust.io)
- [slideshow](https://speakerdeck.com/cgbystrom/load-testing-with-locust)

