---
title: Use <em>Access IT</em> for reviewing access
subtitle: 
  Access IT is used for performing annual reviews of employees access to IT systems. It is used to approve or revoke access that is reviewed.
layout: service
usage: mandatory
---

## How to access

Access IT is available at [goto/accessit](http://goto/acessit)

## When to access

When you are due to perform an annual review.

## How to use

You will be presented with a list of all the access that you need to review. You will need to either approve or revoke the access you are reviewing.

## Support

- [Support Articles in Assist](http://bw.assist.ubs.com/node/64623)
