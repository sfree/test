---
title: Use <em>Email</em> on your desktop or mobile device
subtitle: Corporate email is provided as a service based on Microsoft Exchange. Email can be accessed through Outlook on desktop, web mail in the browser, UBS Blackberry devices or using Good for Enterprise on your own iOs device
layout: service
usage: required
status: in-review
---

##Benefits:

  - **Web Mail**
     Quickly and easily access your email from a web browser

  - **Blackberry**
     Request a UBS Blackberry device to access your email on the go

  - **On your own device**
     Get the Good for Enterprise application on your own iOs device

##Desktop

Microsoft Outlook is install as standard on all UBS Desktops

- [Get Help](http://bw.assist.ubs.com/taxonomy/term/22973/) from USC

Web mail can also be accessed when on the UBS network:

- [http://goto/webmail](http://goto/webmail)

## Blackberry

UBS Blackberry devices are available order permanent members of staff.

- [Order a blackberry](http://goto/mobile-order)

##Good for Enterprise

Good for Enterprise offers employees access to their UBS email from their personal Apple iOs device.

- [Request a Good account](http://goto/good)