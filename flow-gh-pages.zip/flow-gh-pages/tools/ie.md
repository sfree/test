---
title: Internet Explorer
subtitle: 
  Internet Explorer 9 is the standard web browser for UBS. It is provisioned to all Windows desktops and supported by the User Service Centre.All web applications developed by teams in UBS must be compatible with this web browser.
layout: service
usage: recommended
---

## Internet Explorer 9

This is the current supported version. It will already be installed on your Windows desktop and can be accessed from the start-menu or by clicking on a hyperlink.

## Internet Explorer 11

Internet Explorer 11 is due to become the company standard web browser during 2015. It can already be requested in preview using [IOPS](http://goto/iops). Internet Explorer adds many new capabilities from the HTML5 standards.
