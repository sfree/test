---
title: Use <em>ARP</em> for request access to IB applications
subtitle:
  Access Request Portal (ARP) is an Investment Bank IT Access access request tool.
layout: service
usage: mandatory
---

## How to access

ARP is available at [goto/arp](http://goto/arp)

## When to access

If you need to request access to a system or application for yourself or another.

If you need to approve an access request as a line manager or role owner.

## How to use

To request access you need to search for the Asset (generally an application) and then the Access Right to use the application. This will then be sent for approval.

To review a request, login and decide to either approve or request a request.

## Support

- [ARP Support](http://goto/arp-help)
