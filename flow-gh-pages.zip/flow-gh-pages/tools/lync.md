---
title: Use <em>Lync</em> for collaboration with chat, screen sharing and video calls
subtitle: Lync is a desktop collaboration tool from Microsoft that is tightly integrated with Outlook and Windows. It support instant messaging, screen sharing, virtual whiteboards and voice/video calling. Collaborate with your global team.
layout: service
usage: required
status: in-review
---

##Benefits:

  - **Screen Sharing**
     Share your screen one to one or with a group to collaborate on an issues.

  - **Video Chat**
     Conduct meetings with video and voice for effective collaboration.

  - **Outlook integration**
     Break out of Outlook and continue an email conversation with a one to one chat.

##Get Access

Lync is available with a choice of profiles depending on the features you intend to you.

- [Check your profile](http://goto/mylync) if you already have Lync
- [Order a Lync account](https://snow.ubs.net/com.glideapp.servicecatalog_cat_item_view.do?sysparm_id=ced437b019c43000dc0baa41b781ce73]) if you want Lync
- [Order a headset/webcam for Lync](http://bw.assist.ubs.com/node/62162) 
- [Request Lync for your desktop](http://goto/iops) if you have a Lync account but need the software installing on a desktop. (Select Microsoft OCS Lync Client APP)
- [Set your Lync profile picture](http://goto/mylync)

##Group Chat

Lync group chat is currently being rolled out to replace [MindAlign]. It is not currently available for general use.
