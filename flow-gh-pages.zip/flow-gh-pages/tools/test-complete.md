---
layout: service
title: Test Complete
subtitle: Windows based Test automation platform for Desktop, Web and mobile 
usage: required
status: done
author: Binith Krishnan
---

## What?

[TestComplete](http://smartbear.com/products/qa-tools/automated-testing-tools/) is a commercial automation platform for the Windows platform. 
It has support for developing functional automation scenarios for -


- Native Windows applications
- Web applications with HTML5/Adobe Flex
- Android 
- iOS8

**Highlights**
 
- Good choice for developing automated tests for applications which uses Adobe Flex
- Support for most scenarios under the Windows environment
- Technical support from [smartbear](http://smartbear.com/) and possibility of integration with other smartbear tools
- [Recording tests](http://smartbear.com/products/qa-tools/automated-testing-tools/creating-automated-tests/automated-test-recording-engine/)


## Why?


- Supports automating applications with Adobe Flex content without any special development side support or automation specific environments
- Can be a good choice if the environment is limited to Windows alone


## Who?


- [Software engineers]({{ site.url }}/guides/software-engineer.html) should write component level tests and low level integration tests
- [Quality analysts]({{ site.url }}/guides/quality-analyst.html) should write end to end functional automation tests and verify the results

## When?


- By [Software engineers]({{ site.url }}/guides/software-engineer.html) during component level testing and integration tests
- By [Quality analysts]({{ site.url }}/guides/quality-analyst.html) for regression tests and throughout project lifecycle

## How?

Follow these [steps](https://github.ldn.swissbank.com/pages/DevOps/manual/testcomplete/index.html) to get access to TestComplete

*Note that TestComplete is a commercial tool which needs a [license](http://smartbear.com/products/qa-tools/automated-testing-tools/testcomplete-pricing/). There are options to adopt a floating license of a node-locked license. It is recommended to think about a licensing strategy and a cost-vs-benefit estimate before starting to use TestComplete*

## Good practices


[Best practices from smartbear](http://support.smartbear.com/articles/testcomplete/automated-testing-best-practices)


## Learn more


[TestComplete Articles](http://support.smartbear.com/articles/testcomplete/)  
