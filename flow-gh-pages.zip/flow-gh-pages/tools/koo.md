---
title: Koo
subtitle: 
  Desktop Apps Automation  
layout: service
usage: recommended
---

## What is Koo?
Koo is a simple UI Automation C# framework for WPF desktop applications. It is built on top of standard Windows Automation and WPF APIs. Think of it as LINQ to UI Automation.

## Why?
There is a certain lack of open-source and free tools for the desktop apps automation. You can use the low level UI Automation API, but it's verbose and hard to use. White Framework takes a step in the right direction, but its design still forces you to write a lot of custom code. Koo is closer to Selenium.

## Getting Started
- [API Examples](https://connections.swissbank.com/groups/koo/blog/2014/02/20/fluentkoo-documentation-by-example)
- [Download Binaries](http://w01b5st3:8080/repository/downloadAll/FluentKoo_CiBuild/.lastSuccessful)

## Learn more
- [Koo & BDD](https://connections.swissbank.com/groups/koo/blog/2014/02/20/introducing-fluentkoo)
- [TeamCity Setup](https://connections.swissbank.com/groups/koo/blog/2014/04/22/koo-and-teamcity)
- [Koo on Connections](https://connections.swissbank.com/groups/koo)
