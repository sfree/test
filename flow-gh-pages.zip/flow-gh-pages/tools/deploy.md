---
layout: tool

title: Use <em>UBS Deploy</em> for deploying applications

guide: ../../../UBSDeploy/guide/

benefits:

  - title: Faster releases
    text: Define releases from versioned software packages then click a button to deploy to an environment. Promote releases through to production with enforced segregation-of-duties and ReleaseNow integration. Deliver business value more quickly.

  - title: Fewer mistakes
    text: Deployment plans are calculated automatically. Application components are allocated to hosts and deployed automatically. Automation scripts replace error-prone manual steps.

  - title: Less repetition
    text: Complex yet repetetive manual processes are prone to human error. Swift automates these so human effort can be focused on more valuable work. 

integration:

  - title: Deployment of components
    from: nexus
    to: swift
    text: UBS Deploy watches the Nexus artifact repository for newly built application components and allows them to be deployed to your server.
    guide:  

  - title: Change window verification
    from: swift
    to: rnow
    text: If a deployment to production is requested, first verify that an associated change-window has been approved in ReleaseNow.
    guide:

---

UBS Deploy is a continuous delivery tool that streamlines the process of deploying application components and promoting releases from development to production in UBS.
