---
title: Use <em>IntelliJ IDEA</em> for software development.
subtitle: 
  IntelliJ Idea is a modern IDE that supports productive development of many languages including Java, Javascript, Flex & Groovy.
layout: service
usage: mandatory
---

## How to access

IntelliJ Idea is a modern IDE that supports productive development of many languages including Java, Javascript, Flex & Groovy.

IntelliJ is available in two flavours, the free community edition and the licensed Ultimate edition.

### Community Edition

Please order this verison if you don't require any of the feature of Ultimate. There is a comparison matrix here: https://www.jetbrains.com/idea/features/editions_comparison_matrix.html

InelliJ IDEA Community Edition can be order in [IOPS]({{ site.tools }}/iops). Just search for IntelliJ Idea Community and select the latest version.

### Ultimate Edition

IntelliJ Ultimate is a licensed product, please only order it if you need features that are not in the community edition.

We operate a license server for IntelliJ IDEA, this means that there is no lead time to using the product, once installed through [IOPS]({{ site.tools }}/iops) simply enter the license server URL _http://jetbrains.swissbank.com:8080/licenseServer/_ on startup.

InelliJ IDEA Ultimate Edition can be order in [IOPS]({{ site.tools }}/iops). Just search for IntelliJ Idea Ultimate and select the latest version.

##Community

[#intellij](http://machatweb.swissbank.com/machatweb/servlet/linkgenerate?cname=intellij&domain=UBS.MindAlign)

##FAQ

### Does IntelliJ Integrate with GitHub Enterprise?

Yes - The GitHub plugin that ships with IntelliJ can be configured to connect to GitHub Enterprise

### How do I import Maven projects in to IntelliJ?

IntelliJ natively understands Maven projects (POMS). Once you import a Maven project into IntelliJ you must always first run a Maven Compile (mvn compile) of the project and then ensure that you "Re-import projects"
