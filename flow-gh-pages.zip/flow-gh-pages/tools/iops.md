---
title: Use <em>IOPS</em> for ordering desktop software
subtitle: 
  Order software for your UBS desktop from IOPS and have in installed and updated automatically
layout: service
usage: recommended
---

## How to use

- Login to [goto/iops](http://goto/iops)
- Select you business division and location
- Select your machine ID
- Order the software you'd like

## Other actions

- You can order new hardware in IOPS
- You can setup a new machine by cloning the software from your old machine
