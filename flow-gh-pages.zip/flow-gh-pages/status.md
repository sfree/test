---
title: Status
subtitle: What we need to get done to finish the website
layout: guide
usage: required
status: done
---

## Unstarted

<ul>
{% for p in site.pages %}
  {% if p.layout == 'guide' and p.status == 'unstarted' %}
  <li>
    <a href="{{ site.guides }}{{ p.url }}">{{ p.title }}</a>
  </li>
  {% endif %}
{% endfor %}
</ul>

## In-Progress

<ul>
{% for p in site.pages %}
  {% if p.layout == 'guide' and p.status == 'in-progress' %}
  <li>
    <a href="{{ site.guides }}{{ p.url }}">{{ p.title }}</a>
  </li>
  {% endif %}
{% endfor %}
</ul>

## In-Review

<ul>
{% for p in site.pages %}
  {% if p.layout == 'guide' and p.status == 'in-review' %}
  <li>
    <a href="{{ site.guides }}{{ p.url }}">{{ p.title }}</a>
  </li>
  {% endif %}
{% endfor %}
</ul>

## Done

<ul>
{% for p in site.pages %}
  {% if p.layout == 'guide' and p.status == 'done' %}
  <li>
    <a href="{{ site.guides }}{{ p.url }}">{{ p.title }}</a>
  </li>
  {% endif %}
{% endfor %}
</ul>
