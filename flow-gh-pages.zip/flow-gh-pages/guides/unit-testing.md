---
layout: guide
title: Unit Testing
subtitle: Test the small units of programs to make sure they are fit for use
usage: required
status: done
author: Thomas Sugden
---

## What?

A unit test validates the correct behavior of a small unit of code, such as a Java class or JavaScript function. This typically consists of a series of test cases that examine specific behaviors of the code under test. 

- [Example Java unit test](https://github.ldn.swissbank.com/FedCore/core-server-restproxy/blob/master/src/test/java/com/ubs/api/restproxy/filter/rewrite/HeaderRewriteFilterTest.java)
- [Example JavaScript unit test](https://github.ldn.swissbank.com/components/base64/blob/master/tests/spec/base64-test.js)

A test case usually compares expected outcomes with actual outcomes by making assertions. There are different kinds of assertion, such as equality and null checks. Test cases often exercise boundary conditions and unhappy paths.

## Why?

- Catch bugs early in the development lifecycle
- Easy to write and understand
- Verify that refactoring hasn't changed behavior
- Validate correctness of code repeatedly and automatically
- Help others understand your code later
- Encourage the design of testable systems

## Who?

- [Software engineers]({{ site.url }}/guides/software-engineer.html) should write unit-tests and ensure they are passing.
- [Quality analysts]({{ site.url }}/guides/quality-analyst.html) may verify that unit-tests are in place and passing.

## When?

Unit-tests should be written when developing new code and always kept up-to-date when modifying existing code. Writing unit-tests early helps validate interface design, since the test-case will need to make use of the interface of the unit that is being tested. James Shore offers good advice in his [Red, Green, Refactor](http://www.jamesshore.com/Blog/Red-Green-Refactor.html) article.

## How?

We have prefered unit-testing libraries for different technologies:

| Technology | Libraries | Example |
|------------|-----------|---------|
| Java | [jUnit](http://junit.org/), [Mochito](http://code.google.com/p/mockito/) | [HeaderRewriteFilterTest.java](https://github.ldn.swissbank.com/FedCore/core-server-restproxy/blob/master/src/test/java/com/ubs/api/restproxy/filter/rewrite/HeaderRewriteFilterTest.java) |
| Flex | [FlexUnit](https://github.com/flexunit/flexunit) | - |
| JavaScript | [Mocha](http://visionmedia.github.io/mocha/), [Chai](http://chaijs.com/) | [base64-test.js](https://github.ldn.swissbank.com/components/base64/blob/master/tests/spec/base64-test.js) |
| ObjectiveC | - | [CreateConversationProcessTests.m](https://github.ldn.swissbank.com/FedMob/mobile-client-neotalk/blob/develop/NeoTalkTests/Backend/ProcessManager/TALKCreateConversationProcessTests.m) |

[TeamCity]({{ site.url }}/tools/teamcity.html) is used to run unit-tests automatically when code changes in [GitHub]({{ site.url }}/tools/github.html) repositories.

## Good practices

- Keep test [code clean and simple](http://misko.hevery.com/2008/11/04/clean-code-talks-unit-testing/) like you would application code.
- Don't be dogmatic; write tests that are genuinely valuable. 
- Replace badly written tests that are [brittle and expensive to maintain](http://en.wikipedia.org/wiki/Test-driven_development#Shortcomings).

**Michael Feather's rules**

A test is not a unit test if:

1. It talks to the database
2. It communicates across the network
3. It touches the file system
4. It can't run correctly at the same time as any of your other unit tests
5. You have to do special things to your environment (such as editing 
config files) to run it.

Tests that do these things aren't bad. Often they are worth writing, and they can be written in a unit test harness. However, it is important to be able to separate them from true unit tests so that we can keep a set of tests that we can run fast whenever we make our changes.

## Learn more

- [Unit Testing on Wikipedia](http://en.wikipedia.org/wiki/Unit_testing)
- [Red, Green, Refactor](http://www.jamesshore.com/Blog/Red-Green-Refactor.html)
- [Mock Roles, not Objects](http://jmock.org/oopsla2004.pdf)
- [Mocks aren't stubs](http://martinfowler.com/articles/mocksArentStubs.html)
