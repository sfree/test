---
title: Blogging
subtitle: 
  Write an internal blog to share your thoughts on technology and other relevant topics with the UBS IT community
layout: guide
status: done
---

Every member of staff can write a blog using UBS Connection. This is a good way to share your thoughts on technology and any other topics that may be relevant and interesting to your colleagues. A blog can be written in a more informal and personal style than other forms of technical writing, so you can have some fun in the process.

To create a blog post:

1. Open UBS Connections at <http://goto/connections>
2. Click the "Create" button at the top
3. Choose "New blog post"
4. Write your post
5. Click "Publish"

To increase your readership:

1. Tag your post with appropriate keywords
2. Mention relevant people and places in your post using the `@name` feature of Connections
3. Use the Share feature to distribute your post to people you think might be interested