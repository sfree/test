---
layout: guide
title: EBT (Evidence Based Testing)
subtitle: Evidence Based testing is part of the ODP Process. For each application tested, the database test identifies if there are potentially sensitive Clients Identifiers(CI) in the database and the application assessment analyzes how sensitive Client Identifying Data (CID) is protected from being visible to offshore users.
status: in-progress
author: Adrian Smith
---

##Objective

UBS has legal and regulatory requirements that it must comply with regarding client data disclosure for the various jurisdictions that it operates in. The EBT Services have been created to support these requirements by testing the disclosure compliance of client data residing in offshored or outsourced applications against the rules defined in the UBS Client Data Disclosure Table (CDT).

The EBT Services specifically provide database testing and application assessment services. For each application tested, the database test identifies if there are potentially sensitive Clients Identifiers (CI) in the database and the application assessment analyzes how sensitive Client Identifying Data (CID) is protected from being visible to offshore users.

The results of the EBT Services are used to determine the compliance of an application with respect to global legal and regulatory data disclosure rules and to support the offshoring / outsourcing decision making process (OBI request & approval process) by Group Offshoring and Outsourcing as well as Operational Risk Control.

To learn more about the previously mentioned <abbr title="Offshore Due-dilligence Process">ODP</abbr> Process visit [this guide](https://github.ldn.swissbank.com/pages/OpenUBS/flow/guides/odp.html) 
