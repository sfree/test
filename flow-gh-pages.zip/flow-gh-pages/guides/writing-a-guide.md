---
layout: guide
title: Writing a Guide
subtitle:
  The guides on this website are written collaboratively by the development community in UBS. Anyone can prepare a new guide or propose an improvement to an existing guide. This article explains how.
usage: recommended
status: done
---

## Prerequisites

Before contibuting, you need to have a GitHub Enterprise account. This is because the website is made using a publishing feature built into the product.

- [Get access to GitHub]({{ site.guides }}/github.html)

Once you have access to GitHub, there are two ways you can contribute, described below. You should also read the [Style Guide]({{ site.url }}/guides/style-guide.html) which explains the expected style of writing.

## The easy way

If you are not comfortable with the [Git]({{ site.tools }}/git.html) version-control system, the easiest way to contribute is simply to open an issue describing the change or containing the contents of a new guide.

- [Click here to open a new issue](https://github.ldn.swissbank.com/OpenUBS/flow/issues/new)  

The editorial team for the website will be happy to review your contribution. They may immediately accept and publish it or begin some discussion to reach a conclusion.

## The better way

If you are comfortable with [GitHub]({{ site.url/tools/github.html }}) and you expect to become a regular contributor, then you can use the [pull-request]({{ site.guides }}/pull-request.html) workflow instead, to prepare and send a contribution from your own personal copy of the website.

1. Browse to the [flow]({{ site.github }}/OpenUBS/flow) repository
2. Click the `fork` button and fork the project into your personal account in GitHub
3. Edit the `_config.yml` file in the root folder and change the highlighted URLs to reference your personal account

Now you can clone the repository to your local machine, modify the content and push changes into your fork. They will be automatically published to a personal version of the website at:

- `http://github.ldn.swissbank.com/pages/YOUR-GITHUB-USERNAME/flow`

When you are happy with the changes you have made you can send a [pull-request]({{ site.guides }}/pull-request.html). Remember to change the URLs in the `_config.yml` file back to their original form first.

The editorial team will receive and review all pull-requests. They may accept them and merge your changes immediately into the website, or begin some dialogue to get the contribution ready for merging.
