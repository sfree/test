---
title: ODP (Offshore Due-dilligence Process)
subtitle:
  Assures that all risks associated with Outsourcing and Offshoring arrangements are identified and reviewed, that compliance with all relevant laws and regulations is achieved and that all relevant control functions are identified and approve the outsourcing proposal.  The need for an OBI should be considered for every outsourcing and offshoring opportunity.
layout: guide
status: done
---

Learn about the ODP process on a dedicated website at [http://goto/odp](http://goto/odp)