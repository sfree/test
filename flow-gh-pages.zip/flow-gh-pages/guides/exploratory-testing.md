---
layout: guide
title: Exploratory Testing
subtitle: Learn and test your application simultaneously
status: in-progress
author: Pooja Kulkarni
---

##What

Exploratory testing a technique is where the test design and execution happens simulateously. Exploratory testing is sometimes confused with ad-hoc testing, which refers to improvised, impromptu bug searching.An exploratory test session will involve tacit constraints or mandates about what parts of the product to test, or what strategies to use. Testers can write down test **ideas** (not test cases) and use them in later test cycles. 

The tester here explores the applications, learns about it and creatively designs new tests to run. Thus, testers focus on emergent behaviour of the application as opposed to expected in scripted testing.

##Why

Scripted testing generally attempts to mechanise the testing process by putting all the ideas in a structured way into scripts. This is definately required in different phases and regression testing, however just following these inhibits the intellectual processes that allow testers to find important problems quickly. The more we can make testing intellectually rich and fluid, the more likely we will hit upon the right tests at the right time. That's where the power of exploratory testing comes in: the richness of this process is only limited by the breadth and depth of our imagination and our emerging insights into the nature of the product under test

##When

Exploratory testing is recommendedonce automated acceptance tests and some performance/benchmarkchecks have failed. This ensure that the build is stable and testers can spend some time on effective manual exploratory testing without bumping into some obvious errors and bugs.

Else, exploratory testing can be done when fucntionalities are unknown , as part of preparing scripted tests cases.

##Who

In theory, Anyone!

Developers, UX designers, QA, product owners can all get involved in exploratory testing. Its a fun way to know about new functionalities and give feedback.

However, generally QA perform exploratory testing as a means of finding bugs beyond the obvious

##How

This is a simple, manual testing activity. Testers can just start exploring the application then improvise and form a strategy of how or which direction they want the appplication to be explored.

Documentation here varies from jsut documenting the bugs to all the different flows tested.
