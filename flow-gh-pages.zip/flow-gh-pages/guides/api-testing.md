---
layout: guide
title: API Testing
subtitle: 
    Test your APIs for functional and non-functional behaviour
status: in-progress
author: Pooja Kulkarni
---

##What and Why?

API (Application Programming Interface) testing involves sending calls to API using a tool and validating the response recieved.

Ensuring that most business logic are being tested at the API tier allows time for more complete user interface testing, and not having to concentrate on testing every single business rule and path through the application near the end of the project. There are many further areas of API testing explained briefly below :

- Security Testing -To ensure easy and secure access is provided to the underlying services with authenticated and authorized requests to most of UBS API's
- Test for parameters (inputs or query parameter) and resources (paths to be appended to base URL) provided for the APIs
- Functional Testing - Verify the response structure and data content as per the design and expected values
- Ensure proper error handling is provided
- Stress/Reliability testing of API to determine the limits of ordinary operating condition as well as how it behaves when something goes wrong
- Usability testing, to ensure that the APi integrates well with the platforms its intended for

##Who and When?

**Developers** can run the unit tests for API. Please note that unit testing of API are different from functional testing of API. Unit testing of APIs are generally white box and verifies the code.

**Quality Analysts** can run the functional tests, Regression tests and load tests on APIs throughout the release cycles. 
Load/Performance testing of API is explained further in Non Functional testing guide


##How?

Manual tests can be performed by posting requests to API and checking the response using [Postman](http://www.getpostman.com/docs)
Business specific Language API tests can be written and automated using [Robot Framework](https://github.ldn.swissbank.com/pages/OpenUBS/flow/tools/robot-framework.html)




