---
title: CTO Design Review
subtitle: 
  The CTO (Chief Technology Office) Design Review process is designed to ensure appropriate CTO engagement with projects. It should be seen as a supplement to, rather than a replacement for, internal project or programme based design reviews. Its focus is on enterprise requirements that exist beyond the boundaries of a single application or programme.
usage: required
layout: guide
status: unstarted
author: unassigned
---

## Initiating CTO Engagement

The CTO Design process is driven by the status of a programme within eXtract, the UBS programme management and planning tool.  As a part of the eXtract process key programmes (referred to as Top Programmes) are required to undertake a funding review. A CTO questionnaire is completed at this stage and signed off by the CTO or delegate.

* [Read more about engaging with CTO](http://confluence.swissbank.com/display/EAF/CTO+Engagement+with+Programs#CTOEngagementwithPrograms-FundingReview)

## Architectural Significance

Once the funding review has been approved, the divisional CTO or delegate must assess the [architectural significance](http://confluence.swissbank.com/display/EAF/CTO+Engagement+with+Programs#CTOEngagementwithPrograms-ArchitecturalSignificance) of a programme. The result of this assessment will determine whether a design review is required and if so how detailed it will need to be.  The assessment is made based on a number of criteria and requires divisional CTO's to exercise judgement within the framework.

The classifications are:

- **LOW** architectural significance:  Design review not required
- **MEDIUM** architectural significance: Design Review Recommended.  Design Review Questionnaire completed by programme manager and reviewed by domain CTO. (goto/drq) 
- **HIGH** architectural significance: Design Review Mandatory. CTO sign off required with report of outcomes to CIO and CTO. 

For programmes of high architectural significance, a lead reviewer, lead architect, and CTO architect are assigned to conduct the review and produce outputs. 

- [Read more about Architectural Significance](http://confluence.swissbank.com/display/EAF/CTO+Engagement+with+Programs#CTOEngagementwithPrograms-ArchitecturalSignificance)

## Enterprise Requirements

A key component of the design review is its alignment to enterprise requirements.  A simple approach to reviewing this is to explore the detailed questions against each of the UBS Enterprise requirements listed at goto/enterpriserequirements.  If necessary/required, you can use the High Level Design Document, available in the [Template Library](http://confluence.swissbank.com/display/EAF/Templates+Library), to formally capture responses to these requirements although you will often find the requirements are already captured in existing design documents. 

## Good Practice

- Engage CTO early.  
- Discuss architecture significance ratings with the divisional CTO to ensure consistent ratings
- The Enterprise High Level Design document template can be used as a checklist to make sure that all enterprise requirements are satisfied. 

## Links and references

- [CTO Engagement intranet site](https://intranet.ubs.net/en/corporate-center/group-chief-operating-officer/group-technology/group-technology-cto/cto-engagement.html)
- [CTO Engagement confluence site](https://goto/cto-engagement)
- [Enterprise Requirements](https://goto/enterpriserequirements)
