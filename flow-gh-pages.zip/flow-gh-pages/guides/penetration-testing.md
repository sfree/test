---
layout: guide
title: Penetration Testing
subtitle: Regular testing for security vulnerabilities
frequency: quarterly
maturity: high
type: article
---

## What?

A penetration test is a system test designed to find and expose security vulnerabilites.

It is often performed by an external company without internal system knowledge. The aim to to try and break into the system or cause it to stop functioning in some way.

## Why?

- Find vulnerabilites before they can be exploited
- Ensure new vulnerabilites haven't been introduced by adding new application features
- Try to break our own systems before anyone else does, causing reputational or financial damage

## Who?

Either the internal UBS security penetration testing team, or a specialist external vendor.

## When?

Penetration tests should be performed regularly to ensure that new exploits haven't been introduced and that newly discovered attacks cannot be used.

We perform a penetration test on all external facing systems quarterly and additionally when any major technological or application change has occured to the system.

## How?

A penetration test usually looks at known exploits for the technologies in use and tries to use these against the system. The [OWASP Top Ten](https://www.owasp.org/index.php/Top_10_2013-Top_10) is a good example of the kinds of exploits that may be tested.

Some exploratory testing is also often performed to analyse how the system works and predict likely weaknesses.

Automated tools may also be used test against a set of known vulnerabilities. They often monitor network traffic or inspect source code to find vulnerabilites. [HP WebInspect](http://h20195.www2.hp.com/V2/GetDocument.aspx?docname=4AA1-5363ENW&&cc=us&lc=en) is an exmaple of such a tool

A report is produced at the end of a penetration test listing the issues that were found. These will then be categories based on the criticality and a remediation plan will be established.
