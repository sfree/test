---
title: Agile Product Development
subtitle:
  A product developmment methodology that combines user-experience design with agile development.
  It's particularly well-suited to projects that include front-end development and can scale to large 
  programmes with distributed teams.
layout: guide
status: done
---

## Phases

The methodology includes five distinct phases (click on each phase to learn more):

{% include phases.html %}

The phased approach helps to develop successful products by focussing initially on user needs and solution opportunities, then quickly validating these with prototyping, before delivering working software, measuring its effectiveness and iteratively improving it.

The methodology is quite flexible and can be used for developing entirely new products, or for developing new capabilities of an existing product. It can be applied to large programmes by arranging into specific product areas, then applying the methodology in parallel within each team.

The practices that are carried out during each phase can vary depending on the needs of the product. For instance, user-experience design practices may be applied more thoroughly to a client-facing application than a technical product.