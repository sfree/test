---
title: Versioning
subtitle:
  The artifacts that make up software systems need to be versioned, so that dependencies between components can be managed responsibly and builds can be reproduced reliably. This guide introduces the prefered versioning scheme, "semver", and tools available for applying it.
usage: required
layout: guide
status: done
---

The [Semantic Versioning 2.0](http://www.semver.org) standard, also known as "semver", is to be appled when versioning software artifacts. This versioning scheme helps us to understand the implications of a change in version number whenever a software artifact is updated. With this knowledge, we can better manage change and preserve the integrity of our systems.

## Summary of Semantic Versioning

The [Semantic Versioning 2.0](http://www.semver.org) standard uses a MAJOR.MINOR.PATCH structure for a version number. The following rules are applied to increments of the component parts of the version number:

- MAJOR version increments when you make incompatible API changes,
- MINOR version increments when you add functionality in a backwards-compatible manner, and
- PATCH version increments when you make backwards-compatible bug fixes.

Additional labels for pre-release and build metadata are available as extensions to the MAJOR.MINOR.PATCH format.

Please refer to the [Semantic Versioning Standard](http://semver.org/) for full details of the specification, including examples of how to apply it in specific situations.

## Why choose this versioning standard?

This [Semantic Versioning 2.0](http://www.semver.org) standard is chosen because:

1. It's well documented and prescribes clear meaning to the parts of a version number. 
2. It's widely used and well proven in the open-source community, making it also well known to developers.

## Tooling Support

### Build Tools

Most build tools are compatible with the Semantic Versioning standard. For example, the [Maven Release Plugin](http://maven.apache.org/maven-release/maven-release-plugin/) can manage version numbers. Similarly the [NPM Version Command](https://www.npmjs.org/doc/cli/npm-version.html) can be used for incrementing Node package versions.

### GitHub Enterprise

GitHub Enterprise recognises any tags on a repository that take the Semantic Versioning form, such as `v1.2.3`. These will be identified as releases and GitHub will then provide convenient browsing of the associated code changes. See the [Release your software](https://github.com/blog/1547-release-your-software) blog posts for details.