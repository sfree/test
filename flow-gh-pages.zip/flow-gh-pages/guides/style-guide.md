---
layout: guide
title: Style Guide
subtitle: 
  This page provides tips for writing effective guides. The purpose of a guide is to help accomplish something more easily in UBS. A guide might cover a technical practice like unit testing, a governance process like <abbr title="First Cut Requirements Assessment">FCRA</abbr>, or many other kinds of topic. When someone joins your team, you can use the guides to help bring them up-to-speed more quickly, or you might need a guide yourself when asked to carry out a new or unfamiliar process.
---

It's important that guides are well written. Here are some tips for writing effective guides:

- **Bite-sized** - keep it nice and short, so it can be read quickly, in 1-3 mins rather than 10 mins or more. If you can, fit it into a single page, though that won't always be possible.

- **Practical** - make sure it is genuinely helpful and relevant to work in UBS. Don't copy and paste from wikipedia (link instead where appropriate). Make it based on the current sitaution and not aspirational.

- **Plain English** - use simple terms and strive for clarity and conciseness. Keep to the point and avoid unnecessary diversions or editorial commentary. Avoid colloquialisms that might be unfamiliar to a global readership.

- **Flat structure** - try to keep to a single level of headings beneath the title, and avoid deeply nested structures.

- **Explain acronyms** - the first time an acronym is used, always explain it in full. Also, use the HTML `<abbr>` tag to mark-up acronyms unless they are universally understood, eg. markup <abbr title="First Cut Requirements Assessment">FCRA</abbr> or <abbr title="Minimum Enterprise Requirements">MERs</abbr> but not `UBS` or `GBP`.

- **Supported by tooling** - expain what tooling is available to help support our practices, and link to  appropriate resources. For example, the [Release planning]({{ site.guides }}/release-planning.html) guide links to the [Jira]({{ site.tools }}/)

- **What/why/who/when/how?** - a good guide is likely to answer these questions? What is the guide for? Why is it relevant? Who does it apply to? When is it needed? How do I do what is needed efficiently?

- **Reusable assets** - if there are reusable assets that will help someone follow the guide, provide links to them. For example, an example document or test-case.



Guides are written in mark-down. Read [How to write a guide]({{ site.guides }}/writing-a-guide.html) for more information.

