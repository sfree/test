---
layout: guide
title: Release Blog
subtitle: 
  Show pride in your work and be transparent by publishing a blog post in UBS Connections whenever your team completes a significant release. Rotate the responsibility amongst your team, including all roles.
usage: recommended
status: done
---

You can see the blogging releases practiced widely in the consumer IT industry, such as the blogs of [GitHub](https://github.com/blog/category/ship) and [LinkedIn](https://engineering.linkedin.com/blog). UBS has a large internal IT community, so we too can benefit from this:

- Raise awareness of achievements
- Invite constructive feedback from your network
- Stimulate collaboration across departments
- Improve technical writing across teams

Here are some examples published by teams in UBS:

- [Swift 2.8.0 Release](https://connections.swissbank.com/projects/swift/blog/2014/08/14/swift-280-release)
- [Web SDK Update: All About Components](https://connections.swissbank.com/groups/html-sdk/blog/2014/04/24/all-about-components)
- [Introducing STOMP over WebSocket Streaming APIs](https://connections.swissbank.com/groups/neo-development/blog/2014/05/16/introducing-stomp-over-websocket-streaming-apis)

Tag your blogs with **"shipped"** for easy discovery.
