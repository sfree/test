---
layout: toc
title: Guides
---

<div>

  <h3>Roles</h3>
  <ul>
    <li><a href="{{ site.guides }}/delivery-manager.html">Delivery Manager</a></li>
    <li><a href="{{ site.guides }}/information-architect.html">Information Architect</a></li>
    <li><a href="{{ site.guides }}/product-manager.html">Product Manager</a></li>
    <li><a href="{{ site.guides }}/quality-analyst.html">Quality Analyst</a></li>
    <li><a href="{{ site.guides }}/software-engineer.html">Software Engineer</a></li>
    <li><a href="{{ site.guides }}/visual-designer.html">Visual Designer</a></li>
    <li><a href="{{ site.guides }}/hiring-process.html">Hiring Process</a></li>
  </ul>

  <h3>Methodologies</h3>
  <ul>
    <li><a href="{{ side.guides }}/product-development.html">Product Development</a></li>
  </ul>

  <h3>Planning</h3>
  <ul>
    <li><a href="{{ site.guides }}/backlog.html">Backlog</a></li>
    <li><a href="{{ site.guides }}/capacity-planning.html">Capacity Planning</a></li>
    <li><a href="{{ site.guides }}/release-planning.html">Release Planning</a></li>
    <li><a href="{{ site.guides }}/sprints.html">Sprints</a></li>
  </ul>

  <h3>Design</h3>
  <ul>
    <li><a href="{{ site.guides }}/user-research.html">User Research</a></li>
    <li><a href="{{ site.guides }}/prototyping.html">Prototyping</a></li>
    <li><a href="{{ site.guides }}/design-specs.html">Design Specs</a></li>
  </ul>

</div>

<div>

  <h3>Development</h3>
  <ul>
    <li><a href="{{ site.guides }}/coding-standards.html">Coding Standards</a></li>
    <li><a href="{{ site.guides }}/commit-messages.html">Commit Messages</a></li>
    <li><a href="{{ site.guides }}/continuous-integration.html">Continuous Integration</a></li>
    <li><a href="{{ site.guides }}/lean-workflow.html">Lean Workflow</a></li>
    <li><a href="{{ site.guides }}/pull-requests.html">Pull Request</a></li>
    <li><a href="{{ site.guides }}/readmes.html">Readmes</a></li>
    <li><a href="{{ site.guides }}/standups.html">Standups</a></li>
    <li><a href="{{ site.guides }}/version-control.html">Version Control</a></li>
  </ul>

  <h3>Testing</h3>
  <ul>
    <li><a href="{{ site.guides }}/test-strategy.html">Test Strategy</a></li>
    <li><a href="{{ site.guides }}/api-testing.html">API Testing</a></li>
    <li><a href="{{ site.guides }}/cross-browser-testing.html">Cross-Browser Testing</a></li>
    <li><a href="{{ site.guides }}/exploratory-testing.html">Exploratory Testing</a></li>
    <li><a href="{{ site.guides }}/functional-testing.html">Functional Testing</a></li>
    <li><a href="{{ site.guides }}/non-functional-testing.html">Non-functional Testing</a></li>
    <li><a href="{{ site.guides }}/penetration-testing.html">Penetration Testing</a></li>
    <li><a href="{{ site.guides }}/regression-testing.html">Regression Testing</a></li>
    <li><a href="{{ site.guides }}/unit-testing.html">Unit Testing</a></li>
    <li><a href="{{ site.guides }}/usability-testing.html">Usability Testing</a></li>
  </ul>

</div>

<div>

  <h3>Environments</h3>
  <ul>
    <li><a href="">Network management</a></li>
    <li><a href="">Provisioning machines</a></li>
    <li><a href="">System administration</a></li>
  </ul>

  <h3>Releasing</h3>
  <ul>
    <li><a href="">Continuous Delivery</a></li>
    <li><a href="">Deployment Automation</a></li>
    <li><a href="">Post-Deployment Checks</a></li>
    <li><a href="{{ site.guides }}/release-blog.html">Release Blog</a></li>
    <li><a href="">Release Notes</a></li>
    <li><a href="">Release Management</a></li>
    <li><a href="">Semantic Versioning</a></li>
  </ul>

  <h3>Measuring</h3>
  <ul>
    <li><a href="{{ site.guides }}/burndown.html">Burn-down</a></li>
    <li><a href="{{ site.guides }}/static-code-analysis.html">Static Code Analysis</a></li>
    <li><a href="{{ site.guides }}/apm.md">Application Performance Monitoring</a></li>
    <li><a href="{{ site.guides }}/retrospective.html">Retrospective</a></li>
    <li><a href="">Show and tell</a></li>
    <li><a href="">Velocity</a></li>
    <li><a href="">Usage Analytics</a></li>
    <li><a href="{{ site.guides }}/ux-monitoring.md">UX Monitoring</a></li>
  </ul>

</div>

<div>

  <h3>Collaboration</h3>
  <ul>
    <li><a href="{{ site.guides }}/writing-a-guide.html">Writing a Guide</a></li>
    <li><a href="{{ site.guides }}/style-guide.html">Style Guide</a></li>
    <li><a href="{{ site.guides }}/blogging.html">Blogging</a></li>
  </ul>

  <h3>Governance</h3>
  <ul>
    <li><a href="{{ site.guides }}/audits.html">Audits</a></li>
    <li><a href="">Change Approval Board</a></li>
    <li><a href="{{ site.guides }}/cto-design-review.html">CTO Design Review</a></li>
    <li><a href="{{ site.guides }}/fcra.html"><abbr title="First Cut Requirements Assessment">FCRA</abbr></a></li>
    <li><a href="">Introducing Technology</a></li>
    <li><a href="{{ site.guides }}/mers.html"><abbr title="Minimum Enterprise Requirements">MERs</abbr></a></li>
    <li><a href="{{ site.guides }}/open-source.html">Open Source</a></li>
    <li><a href=""><abbr title="Outsourcing Business Initiative">OBI</abbr></a></li>
  </ul>

  <h3>Risk</h3>
  <ul>
    <li><a href=""><abbr title="Application Security Framework">ASF</abbr></a></li>
    <li><a href=""><abbr title="Evidence Based Testing">EBT</abbr></a></li>
    <li><a href=""><abbr title="Internal Control Assessment Process">ICAP</abbr></a></li>
    <li><a href=""><abbr title="Operational Risk Issue">ORIs</abbr></a></li>
    <li><a href="">Penetration Testing</a></li>
    <li><a href="">Risk Advice</a></li>
    <li><a href="">Risk Assessment</a></li>
    <li><a href="">SEEM Exceptions</a></li>
  </ul>

</div>
