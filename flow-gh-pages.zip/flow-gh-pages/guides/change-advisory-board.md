---
title: Change Advisory Board (CAB)
subtitle: 
    Change Approval Boards are part of a framework used at UBS to review and approve changes being made to our IT portfolio. This includes change to any production applications that software development teams have been working on. The purpose of the Change Approval Boards is to mitigate risk associated with deployment to production.
usage: required
layout: guide
---

## Change Approval

Before a change can be made in production, a ticket needs to be raised in Release Now to request approval. This initiates a workflow during which various stakeholders and responsible managers will be expected to review and approve or reject the change. 

These change requests are also reviewed by the Change Advisory Board, who will then invite the relevant parties to a regular <abbr title="Change Advisory Board">CAB</abbr> meeting, held over Lync on a weekly and sometimes daily basis.

## CAB Meetings

During a CAB meeting, a set of upcoming changes will be reviewed and decisions will be made to approve, reject or impose conditions on these changes. Change-related incidents may be discussed and actions may be assigned.

## More Information

Extensive documentation of the Change Approval Board Framework is available in the following document:

- [Release Management Taxonomy](https://teams.ib.cnet.ubs.net/sites/PSI-RM/ReleaseNow%20Documentation/Release%20Management%20Taxonomy%20Version%205%2000.pdf)