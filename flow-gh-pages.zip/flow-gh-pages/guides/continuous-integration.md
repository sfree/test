---
layout: guide
title: Continuous Integration is Really Good
subtitle: Integrating and testing your work frequently to find issues early
usage: required
status: in-review
author: Michael Hall
---

## What?

Continuous Integration is a practice where team members integrate work frequently (often several times a day).
The integration is verified by a Continuous Integration Server (e.g. [TeamCity]({{ site.url }}/tools/teamcity.html) or Bamboo)
which builds the code and runs [unit]({{ site.url }}/guides/unit-testing.html), [component]({{ site.url }}/guides/component-testing.html) and integration tests.

## Why?

- Discover integration issues early
- Ensure code quality by running tests on every commit/push
- Everyone can see what is happening in the project

## How?

- Ensure your code is buildable and testable
- Setup your build to run on every commit on [TeamCity]({{ site.url }}/tools/teamcity.html).

## Learn more

- [Continuous Integration on Wikipedia](http://en.wikipedia.org/wiki/Continuous_integration)
- [Continuous Integration by Martin Fowler](http://martinfowler.com/articles/continuousIntegration.html)
