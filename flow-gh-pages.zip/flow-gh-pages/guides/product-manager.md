---
title: Product Manager
subtitle:
  The Product Manager owns the end-to-end delivery of a product or service to end-users, from defining its key business requirements to measuring its impact and success. The Product Manager understands the wider product strategy and provides clear, prioritised requirements to the development team.
layout: guide
usage: required
status: in-review
author: Vitor Monteiro
---

## Responsibilities

A Product Manager has the following main responsibilities:

- Maintain a clear, prioritised list of requirements
- Defines requirements and success criteria for the team, explaining why the work is important
- Drive the feature kick-off, ensuring the target audience for the feature is represented
- Make scoping decisions (feature and story based) to deliver the most business value in the shortest time
- Provides access to users and business stakeholders for others in the development team
- Regularly review work and carry out acceptance testing to sign-off features
- Be available and accessible to answer any questions about the product
- Promote the product internally and seek feedback
- Be transparent about product development progress
- Assist the senior business stakeholders in defining commercial strategy
- Provides clear communication to, and pools feedback from, the wider user community
- Drive the product launch and support adoption
- Track realised benefit against original target

Success criteria
----------------

A successful product manager:

- Delivers features the users need.
- Delivers features that benefit users in sensible increments.
- Chooses features based on their value / return on investment.
- Aligns their product to the business and company strategy.
- Ensures their product is of high quality.
- Motivates the development team by providing a clear understanding of the end goal.
- Quickly answers questions about requirements.