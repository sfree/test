---
title: Network Management
subtitle: Networks Management refers to the activities, methods and procedures that pertain the maintenance and operation of networked systems. This involves ensuring smooth functioning of the network systems, implementing change as requested by the end user, timely repair and necessary upgrades to all network resources. It also involves maintaining an inventory and monitoring transmission lines, hubs, switches, routers and servers. 
layout: guide
usage: required
status: in-review
author: Bobeeta Chanian
---

##Services

Networks Management is an outsourced service provided by CSC partnered with <abbr>IS</abbr> (Infrastructure Services) that make available Network Services for UBS. Services and support are provided in the following areas: 

- Resolving network outages and incidents to SLA's in all production and non-production environments 
- Set-up of network devices such as LTM's, GTM's, Firewall Policies, Ports, VIPS and re-direction rules 
- Project work involving design and implementation of network topology's for environment build-outs across various UBS business streams
- Providing consultancy and guidance an application performance and impact on the network , tools that optimize network management.

##Workflow

The implementation of a network change is executed by a CSC networks engineer, but is tested by the application team leads. this is done through a ticketing system using <abbr>SNOW</abbr> (Service Now). The request is designed by the application team lead and is passed to the networks engineer for review and implementation. A SNOW ticket is generated to capture the requirements, track the approvals and the status of the request. The CSC engineer will raise a corresponding RNOW ticket to push the change through the CAB cycle.

The changes are split in two categories, **Operational Changes** and **Standard Changes**.

**Operational changes** are those that are very low risk and are repeatable. These are normally tasks such as housekeeping, a port rename, additions of a VIP or a Port range. A minimum of 48 hours' notice is required for this type of request, and there are no restrictions with regards to the time it can be implemented.

**Standard changes**  are those that involve a modification to the network and can be categorized as Low, Medium and High. This type of request must follow a more formal change and approval process, and requires a two week CAB cycle and the additional time taken to design the request before it can be implemented. The category of the request will dictate when it can be implemented. this is normally either EOD LDN, EOD STM or on the weekend depending on the risk category of the change.

##Requesting Load-Balancers, Firewall Rules and DNS

For most networking requests, the change request system SNOW is used to capture and schedule the request details.  
The following networking changes can be requested through SNOW:

- Firewall Rule
- Load Balancing
- Multicast
- Proxy Services
- DNS
- Switch Port

[goto/snow](http://goto/snow) **->** Service Catalog **->** Catalog **->** Network Services

Once a request is submitted, the system will generate a unique ID. This request is mailed to the CSC networks engineer to implement the request.
The engineer will respond in an e-mail with a RNOW ID summarizing the request and providing an implementation date. 
During the implementation, both parties should communicate with one another on the following MindAling channel:  **#CNSS_Support**

The change should be validated during the change window. 
All DNS requests are raised through SNOW, an e-mail, in addition to the SNOW request ID, must be sent to the IP Data team at **SH-CH-IPDNS-INDIA** for the implementation of the request.

To check on the status of the request, the application team members can access the following MindAlign channel:
 **# -IP Data Support** or **# DNS-India_Support**
