---
layout: guide
title: Get started with UBS GitHub Enterprise
subtitle: 
  This guide explains how to get access to the UBS GitHub Enterprise service, which provides source control and collaborative development features for your team.
usage: recommended
status: done
author: Thomas Sugden
---

## Requesting Access

Basic access to GitHub is controlled through ARP:

1. [Open ARP]({{ site.arp }})
2. Order the **login** access-right for the **GitHub Enter** asset

## Log-in to GitHub

Once your ARP request has been approved, log-in to GitHub at:

- <http://goto/github>

You must use your production WebSSO shortname and password.

## Set your email address

When you log-in for the first time, you will be prompted to enter your email address. Make sure you enter your standard UBS email address as shown in [OID](http://ldapquery.ibb.ubs.net:8150/sso_test/tools/query_oid.cgi/?server=oid&command=user) or your account will be disabled.

## Join an Organisation

Within GitHub, there are many organisations representing different departments and teams in UBS. To join a specific organisation, please ask an owner of the organisation to add you as a member.
