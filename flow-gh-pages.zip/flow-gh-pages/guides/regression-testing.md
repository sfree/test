---
layout: guide
title: Regression Testing
subtitle: Test existing functional and non functional features to uncover bugs due to any changes, enhancements or patch done
status: done
author: Pooja Kulkarni
---

##What?

Regression testing is carried out to ensure that any bug fixes, enhancement changes do not impact the previously working functionality

##Why?

- To ensure any new changes to not break existing funcionality
- To ensure bug fixes do not introduce unexpected changes or bugs

##Who and When?

A subset of regression suite should be selected as Sanity/Smoke pack which should be run at on deployment of new build. These should ideally be automated.

**Developers** should run this to ensure system stability and decide if further testing should continue or not.

**Quality Analysts** should do the final regression cycle and it is recommended to be carried out on stable, release builds.

##How?

The test suite for the final regression should be decided by Quality Analysts, with the help of developers. The follwing factors should be considered during impact analysis -

 - How the bug fix or the changes affects system
 - High visibility areas / Areas affecting clients
 - Core features of the product
  

##Best Practices

After every release, Quality analysts should analyse the regression tests to be written/scripted and update them

Ideally, in Agile environments, regression tests should be automated as much as possible to facilitate faster test cylces and sprints.
