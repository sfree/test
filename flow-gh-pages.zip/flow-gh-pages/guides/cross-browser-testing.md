---
layout: guide
title: Crossbrowser Testing
subtitle: Test your application for cross browser compatibility
usage: required
status: done
author: Pooja Kulkarni 
---


## What?

Cross browser testing is a type of compatibility testing designed to ensure that a web application behaves correctly (sometimes identically) in several different browsers and/or browser versions.

One of the main aspects of cross-browser testing to keep in mind is that CSS styles render differently across browsers/browser versions, especially in terms of what is supported and what is not. Older versions of Internet Explorer are generally the most affected by unsupported CSS elements and newer HTML tags.

## Why?

 - Ensure application is adaptable to constant new versions/upgrades to browsers
 - Application compatibilty with all agreed versions of browsers (with Business)
 - Ensuring that content displays/functions correctly in all applicable browsers will help to provide the best possible experience for end-users and expand future audience easily

## Who?

 - [Quality Analysts](https://github.ldn.swissbank.com/pages/ibit/sdlc/guides/quality-analyst.html) should perform this for every new functionality developed
 
## When?

 - This should be performed throughout the testing cycle, with most of the tests done at the earliest so that they do not cascade down to downstream environments

## How?

 - VMware with different images of browsers and operating systems
 
