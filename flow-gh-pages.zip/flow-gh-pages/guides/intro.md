---
title: Welcome!
subtitle: 
  UBS Flow is a new way to develop software in UBS that aims to make the process more efficient and fun. It combines a flexible methodology with collaborative tooling, practical guidance and in-house training. There are important controls in place too, but UBS Flow tries to make these as straightforward as possible. UBS Flow is designed to evolve, through an open process that you can participate in.
layout: guide
status: in-progress
---

## An integrated toolchain

UBS Flow provides a set of popular and well integrated tools to meet the needs of most development teams. The tools are compliant with enterprise policies and operated as managed services, so it's quick and easy to get set-up. Click a tool to find out more.

<table style="margin-bottom:24px;text-align:center; border:0px" class="phases">
  <tbody>
    <tr>
      <td style="border:0px; padding:0px">
        <a class="btn-figure" href="{{ site.url }}/tools/jira.html">
          <small>Plan releases in</small><br>
          Jira
        </a>
      </td>
       <td style="border:0px;padding:2px "><div class="arrow_right"></div></td>
      <td style="border:0px; padding:0px">
        <a class="btn-figure" href="{{ site.url }}/tools/github.html">
          <small>Push code into</small><br>
          GitHub
        </a>
      </td>
        <td style="border:0px;padding:2px "><div class="arrow_right"></div></td>
      <td style="border:0px; padding:0px">
        <a class="btn-figure" href="{{ site.url }}/tools/teamcity.html">
          <small>Build, test, analyse</small><br>
          TeamCity
        </a>
      </td>
      <td style="border:0px;padding:2px "><div class="arrow_right"></div></td>
      <td style="border:0px; padding:0px">
        <a class="btn-figure" href="https://github.ldn.swissbank.com/pages/DevOps/manual/nexus/index.html">
          <small>Store packages in</small><br>
          Nexus
        </a>
      </td>
        <td style="border:0px;padding:2px "><div class="arrow_right"></div></td>
      <td style="border:0px; padding:0px">
        <a class="btn-figure" href="{{ site.url }}/tools/deploy.html">
          <small>Deploy with</small><br>
          UBS Deploy
        </a>
      </td>
    </tr>
  </tbody>
</table>
The core tools above are supplemented by desktop software and an extended range of services for more specific needs. Browse the Tools menu to learn more about these.

## A flexible methodology

UBS Flow recommends a flexible product development methodology that combines practices from [Agile Development](http://en.wikipedia.org/wiki/Agile_software_development) with [User Experience Design](http://www.smashingmagazine.com/2010/10/05/what-is-user-experience-design-overview-tools-and-resources/). It has five distinct phases to take a product from initial ideas into production delivery, and eventually retirement. Click a phase to learn more.

{% include phases.html %}

**Note: some of the content of these pages needs to be updated to use roles from the Target Operating Model. However, the principles and guidance remains valid.**

Simple and practical guides are provided to describe the activities carried out during these phases. Many of these are useful even for teams that prefer to use alternative methodologies, such as [Waterfall](http://en.wikipedia.org/wiki/Waterfall_model). UBS Flow is not an all-or-nothing offering, so your team may be able to benefit from small parts of it.

## An open process of evolution

UBS Flow is made by the people who develop software in UBS. It's produced using an open and collaborative process that you can participate in. If you'd like to improve the way we make software, here are some starting points:

<table style="margin-bottom:24px;text-align:center;border:0px" class="phases">
  <tbody>
    <tr>
        <td style="border:0px; padding:0px">
        <a class="btn-figure" style="width:240px" href="https://connections.swissbank.com/groups/ubs-flow">
          Join the Connections Group<br>
          <small>for news and discussion</small>
        </a>
      </td>
     <td style="border:0px;padding:2px "><div class="arrow_right"></div></td>
      <td style="border:0px; padding:0px">
        <a class="btn-figure" style="width:240px" href="{{ site.url }}/guides/writing-a-guide.html">
          Write a Guide<br>
          <small>to improve UBS Flow</small>
        </a>
      </td>
    </tr>
  </tbody>
</table>
