---
title: Pull-Request
subtitle: Code review and collaborate between teams with GitHub
usage: recommended
layout: guide
status: started
author: Luke Stephenson
---

**Github pull requests** are a great way to propose code changes for new features and fixes. You may also contribute and collaborate with other teams through Github pull requests.  

Github Pull Requests are widely used by the open source community to collaborate on projects. Github pull requests bring all the benefits of code reviews and:
* Anyone can contribute to any project
* Anyone can review
* Everyone can learn from feedback provided

Agile projects may wish to conduct a design review at this stage, with the requestor talking through the design, allowing the code review to focus on the low level implementation details.

Here are some recommended connections blogs on collaborative development and pull requests at UBS:
* [Effective Code Reviews with GitHub Pull Requests](https://connections.swissbank.com/docs/DOC-35504)
* [GitHub Revolutionizes the Relationship with our Global Team](https://connections.swissbank.com/projects/git-and-github-community/blog/2013/10/10/github-revolutionizes-the-relationship-with-our-offshore-teams)
* [Github guide to using pull requests](https://help.github.com/articles/using-pull-requests/)
