---
title: Software Engineer
subtitle: Focused hands-on developer, engaged in producing high quality software
layout: guide
usage: required
status: in-review
author: Vitor Monteiro
---

Software Engineers should do what they're good at and love: develop good software.


Main responsibilities:
----------
- developing and testing a set of features per release
- make all changes transparent and seek code reviews using tools like [GitHub Pull Requests](https://help.github.com/articles/using-pull-requests)
- raise technical debt concerns and propose refactoring solutions
- participate in story breakdown and planning poker sessions
- make sure the software engineering team is documenting any changes to the system so it can be supported by others
- keep an eye on the team's releases and be pro-active in supporting your users
- be able to wear the Delivery Manager hat in a situation of need.


Good software engineers understand two key concepts of delivering high quality products:
- Dev complete is when the product is in production being used by the end-users
- Testing is a developer responsibility




