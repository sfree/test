---
title: Quality Analyst
subtitle: The firewall to every project
layout: guide
usage: required
status: in-review
author: Vitor Monteiro
---

Quality Analysts should be responsible for testing which is too specific or even so advanced that it wouldn't be productive for the Software Engineer to do it. Ideally a given feature will arrive at the hands of the Quality Analyst with most of the testing done, and then the latter will pick it up and make sure it is integrated into our continuous testing environment and has the necessary quality to make it through Production.

Main responsibilities
----------

The main responsibilities of the Quality Analyst are:

- to understand the technical aspects of the feature or release at hand
- to integrate the feature into our continuous delivery flow, so testing is mostly automatic going forward
- put in place automation and enforce the use of metrics that can evaluate performance throughout time
- produce a quality analysis report and sign-off or block the release
- work closely with the engineering team so testing can be done progressively while the features are being developed
- raise technical debt that could hinder automation and cause and overhead of manual testing (potentially blocking the release)
- put in place nfr automation to verify impact of releases on the speed of our services





