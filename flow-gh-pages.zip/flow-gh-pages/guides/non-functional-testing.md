---
layout: guide
title: Non-functional Testing
subtitle: Test load, stress and performance of a system or application
usage: required
status: In-progress
author: Saurav Santosh
---

## What?

**Load testing** is a type of activity which helps identifying the maximum operating capacity of an application before there is degradation of application performance. The process helps to identify bottlenecks which might impact operation capacity.

**Stress testing** is the process of determining the ability of a computer, network, program or device to maintain a certain level of effectiveness under unfavourable conditions. The process can involve quantitative tests done in a lab, such as measuring the frequency of errors or system crashes. 

**Performance testing** is testing that is performed, to determine how fast some aspect of a system performs under a particular workload. It can serve different purposes like it can demonstrate that the system meets performance criteria. It can compare two systems to find which performs better. Or it can measure what part of the system or workload causes the system to perform badly.


## Why?

Non Functional Requirements are essential to every program since

- They determine the performance boundaries for the application
- Define the overall qualities or attributes of the resulting system
- Determine the technical specifications of the product that will be delivered and help communicate the scalability characteristics of the application being designed and delivered
- Building blocks on which the rest of the Performance Engineering processes are built
- Plays a vital role in ensuring confidence with the product and its reputation


## Who and When?

This type of testing is generally performed in collaboration with performance testers and the development team.

Performance Testers/Quality Analysts responsibility is to liaise with the business sponsor, environment engineer, developers and gather requirement and technical facts. Use the information to define approach, build scenarios and writing various performance scripts 

## How?

Very rare but can be carried out manually but most often this is achieved using performance testing tools as part of the development tool or external software such as Loadrunner, Jmeter etc.


The tester must ensure that the following tasks are performed:

- Identify the performance-critical scenarios.
- Identify the workload profile for distributing the entire load among the key scenarios.
- Identify the metrics that you want to collect in order to verify them against your performance objectives.
- Design tests to simulate the load.
- Use tools to implement the load according to the designed tests, and capture the metrics.
- Analyse the metric data captured during the tests. 

**Tool References**

- [JMeter_Beginner's Guide Document](https://teams.ib.cnet.ubs.net/sites/f35/technical/Test/8.%20Non%20Functional%20Testing/7.%20NFR%20Performance%20and%20Capacity/JMeter_Beginners%20Guide.docx)
- [Jmeter User Manual](http://jmeter.apache.org/usermanual/)

