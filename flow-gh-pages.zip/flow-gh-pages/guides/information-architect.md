---
title: Information Architect
subtitle:
  Information Architects deal with the arrangement of information and functionality in software. They design intuitive user interfaces to support valuable user journeys. They recognise and formalise patterns to achieve consistency and efficient delivery.
layout: guide
usage: required
status: in-review
---

## Responsibilities

An Information Architect has the following main responsibilities:

- Understanding the user's needs through research and other activities
- Designing efficient user journeys to address these needs
- Producing sketches, wire-frames and other design artifacts
- Collaborating with visual designers and developers 


- to produce wireframes with the several user journeys, which can be quickly validate by stakeholders
- explain the user journeys to the rest of the team (potentially done alongside the [Product Managers]({{ site.guides }}/product-manager.html))
- pass the requirements along to the [design team][Product Managers]({{ site.guides }}/visual-designer.html) that will implement the journeys in a detailed graphical format
- provide validation from a UX point of view during the testing phase of the product
- document the wireframes and mention the why and how of the journey produced

It’s also important to understand that User Experience is not the same as Usability. UX deals with how a user feels when using a system, while Usability is about the user-friendliness and efficiency of the interface. Usability, without a doubt, is a big part of the user experience and plays a major role in experiences that are effective and pleasant, but then [human factors science](https://en.wikipedia.org/wiki/Human_factors_and_ergonomics), psychology, [information architecture](http://en.wikipedia.org/wiki/Information_architecture) and [user-centred design](http://en.wikipedia.org/wiki/User-centered_design) principles also play major roles.

## Success criteria

A successful information architect:

- Collaborates well with software engineers to understand the constraints of the available technologies and design experiences that respect these.



An Information Architect has to be an excellent communicator, due to the constant need to be interfacing with end-users, [Product Managers]({{ site.guides }}/product-manager.html), [Software Engineers]({{ site.guides }}/software-engineer.html) and [Quality Analysts]({{ site.guides }}/quality-analyst.html)