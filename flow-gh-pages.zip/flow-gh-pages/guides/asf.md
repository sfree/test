---
layout: guide
title: ASF (Application Security Framework)
subtitle: The Application Security Framework is a framework that is being created by Security IT to ensure that consistent application security controls are used across Group Technology.
status: in-progress
author: Adrian Smith
---

 The ASF includes information on when controls such as Source Code analysis, Source Code Review, Penetration Testing and Network Sharing are required and how these controls should be run in UBS for given applications.

##Penetration Testing 
This process is currently performed for all external facing applications on an annual basis and for other applications where required on a risk basis. Timelines for remediation of any identified issues are listed in the Security Patch Management policy.

##Fortify
Fortify is a code scanning tool supported by Security IT, is mandated for detection of passwords in cleartext for audit relevant applications. It is also required to be used for finding vulnerabilities in code for MAS critical applications. Use of Fortify is discretionary for other applications.

**External perimeter scanning** is performed by an external company on behalf of Security IT and any issues identified are again required to be resolved within the timelines listed in the Security Patch Management policy.
