---
title: Beta Phase
subtitle:
  The beta phase is about delivering and evolving a working version of the service for the first real users in a production environment. The team has the confidence to achieve this because they tested out options during the Alpha phase and considered what would be needed to build and operate the service. During the Beta, the service will be released and iteratively improved until it's performing well enough to go Live for all users.
layout: guide
---

Duration
--------

2 - 3 months

Objectives
----------

The objectives of the beta phase are to:

- deliver a fully working application that can be exposed to key stakeholders and hand picked clients
- meet the standards for [design]({{ site.guides }}/design-specs.html), development, testing and security
- ensure all compliance requirements are satisfied
- complete all system integration tasks
- resolve any outstanding technical, design or process related challenges
- begin automatically measuring the service against the KPIs
- test the beta release with real users and iteratively improve it until it is ready to go live

Team
----

The beta phase is an intensive period of teamwork, requiring a broad mix of skills to design, develop, test and deploy in rapid iterations. The makeup of the team depends on the specific requirements for the service and should have become clear during the [alpha phase]({{ site.guides }}/alpha.html).

An example delivery team for a beta could be:

- the [product manager]({{ site.guides }}/product-manager.html) to make product decisions and priority calls, keep the stakeholders engaged and begin measuring service performance against the KPIs
- business stakeholders to provide feedback and identify the beta users
- 4 [software engineers]({{ site.guides }}/software-engineer.html) to deliver user stories, complete releases and work with operators to ensure that service operation will be straightforward and where possible automated
- 1-2 [information architects]({{ site.guides }}/information-architect.html) to produce design specifications, digital assets and work on fit+finish tasks, as well as conducting user testing and occasional mini prototypes
- 1 [quality analyst]({{ site.guides }}/quality-analyst.html) to perform exploratory testing and work with developers to ensure suitable automated functional testing is in place
- 1 [delivery manager](people/delivery-manager), who may also be one of the developers, to ensure efficient collaboration within the team, track technical dependencies and clear any blockers

For larger programmes, it may be beneficial to arrange into multiple smaller teams during beta, though each should be capable of delivering a valuable portion of the service end-to-end.

Process
-------

The team should be following an agile development process during the beta phase, typically working in 2 week iterations and delivering user-stories from the backlog. Before each sprint, the  [delivery manager]({{ site.guides }}/delivery-manager.html) should run a [sprint planning]({{ site.guides }}/sprint.html) meeting, during which the priority order of the stories and expected scope for the iteration is established.

When a story is getting close to delivery, it can be defined in more detail. If this happens too soon, there is a higher chance of waste due to changing priorities. Definition can include further [UX design specification]({{ site.guides }}/design-specs.html), the addition of [acceptance tests]({{ site.guides }}/test-strategy.html) where expectations may be unclear, and a task breakdown or whiteboard sketch of the technical solution.

The team should continue to work closely together and to have daily [stand-up]({{ site.guides }}/standups.html) meetings, focussed on collaborating to complete stories in progress, so the next story from the backlog can be picked up. Developers write code and automated tests, UX designers produce any new digital assets and help with fit+finish, while [quality analysts]({{ site.guides }}/quality-analyst.html) work on quality control, ensuring the software is functioning correctly.

A story is complete when it has been signed off by the [product manager]({{ site.guides }}/product-manager.html) and [delivery-manager]({{ site.guides }}/delivery-manager.html) and preferably released into production. At times it may be necessary to group user stories up together to form larger releases, but small and frequent releasing is encouraged and results in a more automated release process that lowers risk while delivering value to users sooner.

The show and tell meetings should continue on a regular basis to demonstrate progress to stakeholders and interested parties. The [delivery manager]({{ site.guides }}/delivery-manager.html) should also schedule regular [retrospectives]({{ site.guides }}/retrospective.html) for the team to reflect on their performance and identify opportunities to improve their effectiveness, to be implemented in the following sprint.

At some stage during the beta phase, a call will be made by the [product manager]({{ site.guides }}/product-manager.html) to release the software to the beta user group. Ideally those people will be real end-users of the software. They may be identified together with the business stakeholders. They may be a friendly group of internal users who are keen to provide feedback and influence the solution. In any case, the sooner the system begins really being used for carrying out its intended purpose, the sooner that valuable feedback and measurements can be taken.

It is important to observe delivery efficiency carefully during the beta phase and to react and improve the team working processes throughout, to achieve optimal delivery. Will extra developers or designers really help deliver a service more quickly, or can people work together more smartly to achieve more? How can work be partitioned into discretely valuable pieces? Are there time or budget based constraints that influence team structure?

Once in the hand of real users, the team needs to prove they are good at improving a live system without disrupting the service. The service should continue to be improved in frequent iterations until the [product manager]({{ site.guides }}/product-manager.html) is
ready to make the service generally available to users by [going live]({{ site.guides }}/live.html).

Outputs
-------

The beta phase concludes when:

- you have delivered a end-to-end service to real users in production
- you have improved the beta repeatedly and are actively measuring its performance
- the service can be operated effectively while development continues and upgrades are applied
- the team is ready for the general release of the service

Learn more
----------

{% include phases.html %}