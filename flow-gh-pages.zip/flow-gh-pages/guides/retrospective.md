---
title: Retrospectives
subtitle: 
  Retrospectives are a great activity that enables developers to find, discuss and act on their day to day problems, inefficiencies and development frustrations. If used properly, retrospectives have the potential to progressively increase a team's productivity. Old problems are fixed, new ones arise, the environment changes and so retrospectives are the team's inner reflection on how to keep the boat afloat and sailing fast.
layout: guide
---

Objectives
----------

Identify, discuss and propose actions to solve the main productivity and morale offenders.

Team
----

The whole team should be involved in this activity. In every retrospective one team member should assume the role of moderator whose functions are:
- Timely conduct the retrospective through its several phases, as it is very easy in to go well beyond the defined time and lose focus
- Gather, document and make sure the retrospective actions are split equally among team members.

Preparation 
-----------

As the name implies in a retrospective all the teams members present and discuss what the team did well and what can be improved, either in the last iteration or since the last retrospective. 

One of the pitfalls of retrospectives is using the meeting to gather the discussion topics, which usually leads to very long and dull meetings. In order maximize the time discussing and gathering actions for the issues at hand, teams should already bring the materials to the retrospective. Each team member should think about roughly three good things that the team is doing well and three things which are causing pain, inefficiency and frustration to the team or to the individual. Find a practical format for writing the retrospective topics, post-its is a popular one since at some point it's easier if you can pick up the items individually and put them in a place everyone can read and reach. In addition to this, for non-collocated teams, tools like Lync's Whiteboard are a good way of keeping track of items, actions and votes.

The good things 
---------------

Thinking about what the team has improved is a great motivation exercise and should not be treated as a minor phase of the retrospective. Each team member reads his or her positive topics and hopefully this doesn't create a lot of debate, apart from the occasional nodding sign. The retrospective moderator should try to keep this phase as short as possible, because discussion can get very time consuming in the following phases.

The bad things
--------------

This is much similar to the previous phase, since each team member, one by one, reads their topics to the rest of the team. The big difference is that the retrospective moderator will pick up the post-it and put it in an area where all the items will be placed (a wall or a board). The moderator is encouraged to group items into buckets or clusters, as it's very common for items to be related and addressed simultaneously. For example, if Alice raises an issue related to the high load of support and Bob later says his code is getting messy because of the interruptions caused by support requests, then these are good candidates to group in one big topic (e.g. support).

It is of the utmost importance for the moderator to reduce discussion at this point to a bare minimum. As soon as a hot topic is raised, it's very likely team members will jump in with suggestions and added fact, which by itself can extend the retrospective for hours if not controlled. The last phase takes care of the discussions and actions.

The voting
----------

When all the items are in a board for display, it's time for each team member to vote on what he considers the most important issues to resolve. Each team member has 3 votes which need to be applied to 3 different topics. No discussion usually takes place at this point, as there should be absolute respect for the colleagues' views and opinions. 

Remember that some of the items the team member is voting on might be a group of several sub-items that were grouped together because they are related. For example, imagine Alice and Bob didn't group their two items. Although they are raising the same issue worded differently they risk not getting enough votes to address the support topic since four votes will be better than two in distinct items.

This phase ends when the moderator counts the votes on each item and names the three winners. This doesn't need to be taken too literally, as if there's a tie for third, you can potentially pick four items to discuss. If the fourth place is very close from the first three, you can also pick it up for review. Three is a round number that will allow you to properly discuss the matters and think about the actions for each one. If teams try to do this for 10 different items, they might see themselves lost in a long retrospective where everyone sooner or later doses off.

As all the agile activities you may adjust some parameters to match the process that works best for your team. Some teams might want to work only on the most voted item, unless there's time to pick up some more. 

Actions
-------

For each of the winning topics the team should discuss what's causing the problem and brainstorm on potential solutions. When the dust settles, come up with **concrete assignable actions** that can be evaluated in the next retrospective. 

This is the main goal of a retrospective: **a pragmatic set of actions that if addressed will most likely solve a problem which is damaging the team** in one way or another. A retrospective that generates no actions is also known as a waste of everyone's time. The same applies for retrospectives that generate actions but where these are not acted upon.

The retrospective moderator is then responsible for documenting the actions and monitoring their evolution until the next retrospective.