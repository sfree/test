---
layout: guide
title: Risk Assessments
subtitle: An IT Risk Assessment identifies, analyses and evaluates weaknesses of an Application, infrastructure or as a Service offering.
usage: recommended
status: in-progress
author: Adrian Smith
---

In UBS, a Technical Risk Assessment is the formal reviews of a proposed or existing system in order to identify risks considering technical, regulatory, legal, compliance, policy and operational risk aspects. The outcome of the assessment is a summary of the impact, likelihood and resulting ORF2-aligned risk rating. 
The report will also include recommended remediation actions. 

IT Risk Assessments can be requested from the IT Risk team. They may also be mandated as a condition of an OBI or other change initiative.

For more detailed information on the Risk Assessment process, how it supports the business and requesting an application for IT Risk Assessment follow this [link](https://intranet.ubs.net/en/corporate-center/group-chief-operating-officer/group-technology/it-risk/it-risk-assessments-applications-infrastructure.html).
