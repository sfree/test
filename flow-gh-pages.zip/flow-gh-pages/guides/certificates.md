---
title: Certificates
subtitle: 
 Certificates and certificate services from numerous vendors are used primarily to identify and authenticate a service, to encrypt files and make stronger data integrity. Certificates are used for both client and server authentication.
layout: guide
usage: required
status: in-review
author: Bobeeta Chanian
---


Many UBS intermediate and front facing components use SSL (known also as Trasport Security Layer) public key encryption technology for authentication encryption of data streams both inside and outside the UBS' networks.

With public key encryption, a public key and a private key are generated for a server, and data encrypted with the public key can only be decrypted using the corresponding private key and vice versa. 
The private key is carefully protected so that only the owner can decrypt data encrypted using the public key, and the public key is embedded in a digital certificate with additional information describing the details of the owner of the public key.

##Working with and Requesting Certificates

An application participating in an SSL connection is authenticated when the other party evaluates and accepts the application's digital certificate. Web browsers, servers, and other SSL-enabled applications generally accept as genuine any digital certificate that is signed by a trusted certificate authority and is otherwise valid (for example, not expired and carrying the hostname or Fully Qualified Domain Name matching the URL specified by the client).

Internally used certificates are signed by a UBS group root <abbr>CA</abbr> (Certificate Authorities), which gives the certificate trusted status across the internal network, depending on whether it is for production or test environments.
When a Certificate Signing Request (CSR) is made for an internal component for a test environment, a request is raised at the Zflow service.
Once the request has been processed, a signed certificate will be returned to the requester signed by the test UBS root CA (CN= Server CA Test 1), and ready to use as is or to incorporate into a keystore for use with Java applications.
Because Java comes with its own store of top level global root Certificate Authorities, it can only validate certificates signed by the test UBS root CA if a copy of the UBS root CA certificate itself has also been incorporated into the keystore created for use by Java applications.

There are some [documents](http://confluence.swissbank.com/display/EnvSupport/CERTS+on+NFR) and quick [summaries/tools](http://confluence.swissbank.com/display/EnvSupport/Quick+Cert+and+jks+generation) available to provide guidance on understanding certificate generation, renewal and offloading.

Virtually all of the certificate manipulation and verification can be done with openssl, and that also goes for certificate conversion where required, in case different formats of the certificate are required.

When a certificate is required for an external component such as external facing URL, the public certificate may be held on the Local/Global Traffic Monitor which process requests to the URL, so that the data stream can be decrypted at that point. On these occasions, a request to offload the (Verisign) signed certificate and key can be made to the networks team who will carry out the offloading task via a SNOW request.

Requests for *Verisign* signed certificates for external use must be approved by someone at ED level or above.

[This page](https://intranet.ubs.net/en/corporate-center/group-chief-operating-officer/group-technology/security-it/certificate-management/ca-certificates.html) also provides more details on the UBS Root CAs available, and also provides links to **[ZFlow](https://bw.zflow.it.ubs.com/)** and **[Verisign](https://intranet.ubs.net/en/corporate-center/group-chief-operating-officer/group-technology/security-it/certificate-management/ubs-verisign-server-certificate-administration.html)** (Premium SSL service).




