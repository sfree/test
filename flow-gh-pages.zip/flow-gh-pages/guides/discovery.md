---
title: Discovery Phase
subtitle: 
  Find out what your users need, what your constraints are and how to measure success.
  Learn about the needs of your users and the context for the project. Understand the 
  business goals and technical constraints. Start to identify solution opportunities 
  and form ideas about what the initial prototypes should explore.
layout: guide
---

## Duration

1 - 2 months

## Objectives

Find out who your users are:

- what are their needs?
- how do they use our services today?
- are they satisfied with our services?
- how could we better assist them with technology?
- how can user satisfaction be measured?

Find out about the business context:

- what is the business model?
- what are the main business transactions?
- who are the competititors and what are they up to?
- what processes are involved in day-to-day running of the business?
- what are the business targets and how is performance?
- are there changes in regulation that influence the business?
- are there any jurisdictional challenges?
- are there any relevant compliance regulations?
- what measurements can indicate success?
- are there already great ideas for innovation to be considered?

Find out about the technical constraints:

- what systems, technologies and infrastructure is currently in use?
- what do the interfaces of the system components look like?
- how are the existing systems developed and operated?
- where are there particular pain-points or limitations?
- are there special risk management considerations?
- how and where could newer or better technologies help?
- are there components due for replacement or decommissioning?

Team
----

The discovery phase only requires a small team, usually consisting of:

- the [product manager]({{ site.guides }}/product-manager.html) to coordinate the effort and make decisions
- business stakeholders to provide business context and access to users
- a [software engineer]({{ site.guides }}/software-engineer.html) to analyse the technical constraints and understand the options
- an [information architect]({{ site.guides }}/information-architect.html) to carry out user research and begin exploring design solutions

Process
-------

The discovery process usually takes 4-8 weeks, depending on the scale of the project, the complexity of existing services, and the appetite for innovation. 

During this time, there are many activities to carry out to gather information and gain understanding, including:

- introductory workshops with users and business stakeholders
- demos of existing services, including competitor offerings
- technical analysis of existing services and relevant technology
- whiteboard sessions to explore ideas collaboratively
- paper prototypes to try out ideas and get rapid feedback from users
- capturing the initial set of user stories

During the final week, you should be setting up the broad scope of a project and an initial set of user journies. At the end of discovery, a decision is made on whether to proceed to [Alpha]({{ site.guides }}/alpha.html).

Outputs
-------

You should complete the discovery phase with:

* the user journeys for the main application goals
* an understanding of existing services in UBS and those available from competitors
* an understanding of the team required to deliver the new or improved service
* some early sketches demonstrating some of the key user journeys
* a list of stakeholders and an understanding of their different needs and expectations
* a decision on whether to proceed to [Alpha]({{ site.guides }}/alpha.html)

Learn more
----------

{% include phases.html %}