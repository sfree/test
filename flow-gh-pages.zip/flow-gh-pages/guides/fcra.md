---
layout: guide
title: First Cut Requirements Assessment <span class="parenthisis">(</span><em>FCRA</em><span class="parenthisis">)</span>
subtitle: A process to help development teams better understand their policy obligations
usage: required
status: in-review
author: Ajay Kapur
---

First-Cut Requirements Assessment (FCRA) is an interpretation engine for all group level IT-relevant policies. Using it, application developers or SWC onwers can easily identify all relevant non-functional requirements (security and risk) and learn about appropriate solutions to fulfill those requirements. It also determines the criticality of applications based on ORC defined and GTEC agreed criteria.

- FCRA enables transparent decision making process during the entire lifecycle of an application and an objective comparison with other software solutions. It allows prioritization of Risk Management activities, and spells out non-functional requirements to be discussed at DPR and evidenced at PRR (as it is embedded in Quality Review).
- FCRA provides also Test Cases information per every MNFR and their results if available.

## Objective 

Integrate SDLC, Health-Check, FCRA and Quality Reviews to one process which will:

- Specify and agree non-functional requirements such as capacity, performance, logging, availability and other security-related topics (e.g. authentication & authorization, code scanning, penetration testing and more)
- Specify solution patterns to implement the requirements and provide evidence requirements
- Define consistent Group Technology wide understanding of application criticality

## Goals and Benefits

Deliver a sustainable and integrated solution approach to drive implementation of minimal non-functional requirements into any Software Development Lifecycle Methodology (agile or waterfall).

- Support IT Management in the Design Reviews by providing full overview of potential risks and minimal security requirements
- Enable the Production Assurance Function to efficiently and sustainably obtain applicable verification data from IT R&S to support the Production Readiness Review.
- Maintain dynamic non-functional requirements based on policies in response to ORI 89622 – Lack of non-functional requirements
- Allow for the Health-Check to only focus on compliance to procedural / SOX relevant controls
- Enable ORC to implement consistent Application Classification (criticality, confidentiality, integrity)  this classification can then be used for SOX, Health-Check, MORCS and other purposes

## Contact and Support Information

- [FCRA Tool](http://goto/fcra)
- E-mail contact: [sh-fcra-support@ubs.com](mailto:sh-fcra-support@ubs.com)
- [FCRA Assist page](http://bw.assist.ubs.com/taxonomy/term/24564)
- [FCRFA access instruction](htttps://teams.cc.cnet.ubs.net/sites/FCRA/blog/Lists/Posts/Post.aspx?ID=13)
- MindAlign contact: FCRA_Support
- Lukasz Ciahotny, Central Risk Services, UBS Krakow
