---
layout: guide
title: Readmes
subtitle:
  Every library, tool or application that we develop needs a good readme file. This is a simple, plain-text file that summarises the purpose of the code and how to use it.
status: done
---

A `README` file is the most essential form of technical documentation for any source-code repository. It explains in simple and concise terms the purpose of the code within the repository and how to use it. 

Readme files have been popularised in the open-source community, where every good project has a good readme file. Developers should expect to find the same kind of documentation for internal projects. 

When you create a new repository, start the readme file early, before you even begin coding. Don't spend time on other forms of documentation until you have a good readme.

## Why are readmes files important?

Readmes are great because they're easy to use, and equally easy to write and maintain. They're also self-contained, so when a developer clones a repository, they have the code and documentation together in one place.

Readmes are _user-centric_. They're written for the consumer of the code, but the exercise of writing a readme also helps the author to critique their own work. If a project can't be explained in simple terms and in plain-text format then perhaps the design is too complex?

## How to write a readme

1. Create a file named `README.md` in the base of your repository.
2. Explain the purpose of the code and how to use it in clear and concise terms.
3. Write the Readme using [Markdown](http://en.wikipedia.org/wiki/Markdown) notation.
4. Make the documentation example-driven and avoid unnecessary digressions.

## Example readme files

There are plenty of examples of good readme files in UBS, including:

- [REST API Example](https://github.ldn.swissbank.com/FedCore/rest-api-example)
- [WebSocket Adapter Framework](https://github.ldn.swissbank.com/FedCore/core-server-ws-api)
- [Article Component](https://github.ldn.swissbank.com/components/article)

As you can see, the style and structure varies, but all are easy to read and example-driven.

## Tool integration

GitHub Enterprise will pretty-print the `README.md` file when browsing to a repository page. Any markdown content will be rendered as styled HTML.

## Learn More

There are plenty of good external articles on the topic of readmes, including:

- [How to Write a Great Readme](http://robots.thoughtbot.com/how-to-write-a-great-readme)
- [How to Write a Readme Worth Reading](http://orchestrate.io/blog/2014/07/16/how-to-write-a-readme-worth-reading/)
- [Readme Driven Development](http://tom.preston-werner.com/2010/08/23/readme-driven-development.html)
