---
title: Commit Messages
subtitle: 
  All code commits must be accompanied by a clear and concise commit message. This is to provide a written record of the changes made to a codebase over time. Commit messages should also reference change tickets in Jira to create a correlation between requirements and development activity.
usage: required
layout: guide
---

## Conventions

There is not currently a centrally mandated convention for commit messages in UBS. However, there are some good practices described in the following blog post:

- [TJ Hollowaychuck's Git Conventions](https://medium.com/code-adventures/git-conventions-a940ee20862d)

## Linking Requirements to Code Commits

It is very important to reference change tickets, such as Jira user-stories or defects, within your commit messages. This forms a correlation between a requirement and the code changed to fulfil it. This may be needed for auditing purposes, and also supports code reviewing, debugging and analysis activities.

### Linking GitHub and Jira

_Roy to add instructions here for creating a link between a GitHub commit and a Jira ticket_

### Ensuring links are present

_Roy to add details on how to configure the Git command-line client to ensure the presence of a Jira ticket reference._