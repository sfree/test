---
title: Visual Designer
subtitle: Creating visually engaging and effective user views
layout: guide
usage: required
status: in-review
author: Vitor Monteiro
---

Visual Design involves the aesthetic representation of the user interface of any application. This includes elements like colour palettes, branding components, visual treatments, iconography and typography – amongst other things. Visual Designers seek to attract, inspire, create desires and motivate the users to respond to messages.

Depending on the nature of the project, Visual Designers aim to establish a Visual Language for the user interface which allows the interface to grow and provides a framework for the look and feel for future interface elements. This approach allows the design of an application to be managed as a single integrated process rather than a series of discrete and disjointed efforts.

Main responsibilities
---------------------

Designers have the following responsibilities within software development teams:

- designing application screens and user journeys through an application
- designing the visual elements of the user interface including colours, imagery, typography, use of whitespace
- consulting with developers to make sure their design concepts can be implemented within the technical and time constraints of the deliver.
- reviewing the implementation of design specifications and working closely with developers to ensure they have been done right.
- providing Design review during development and testing of the product

