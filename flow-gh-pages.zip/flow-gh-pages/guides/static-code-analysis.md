---
title: Static Code Analysis
subtitle: Automatic scan of application source code to identify security vulnerabilities without executing the application
usage: recommended
layout: guide
status: in-progress
author: Jonathan Levy
---

## What?

Static Code Analysis detects common vulnerabilities, potential security issues and code quality issues in application source code. It is performed by an automated tool using various analysis techniques. UBS has chosen [HP Fortify](../tools/fortify.html) as the group-wide approved static code analyzer tool.  

## Why?

UBS policy requires all applications to be scanned and checked for certain security issues, such as passwords hard-coded in source code. Regulatory bodies in some jurisdictions also require that code is scanned for security issues before being deployed to production. Besides for these fixed requirements, static code analysis can expose issues earlier in the development lifecycle when they are easier and cheaper to fix. 

## Who?

Development teams are responsible for scanning their codebase. The [Secure Development Services](http://goto/security-static-analysis) team can support developers in the process.

## When?

Scanning can be performed during or after active development of a particular feature or release. In general, all code must be scanned and audited before being deployed to production. In some specific cases, it may be sufficient to scan source code at regular pre-defined intervals; this needs to be agreed with IT Risk Management on a per application basis. 

## How?

### Onboarding a new application

Scan results from all UBS applications are collected on a central server called Software Security Centre (SSC). SSC is used to make the scan results available to other members of the development team, to consolidate the results for Production Assurance & Quality Review Framework purposes, and to enable Secure Development Services to provide you with assistance.

To prepare SSC for a new application, an Application Onboarding Request must be submitted. Please refer to [Application Onboarding](https://teams.ib.cnet.ubs.net/sites/appsec/SiteCollectionDocuments/Request_Application_On-Boarding.aspx). 

### Installing HP Fortify

The Fortify client is available for Windows workstations from [IOPS](http://goto/iops) and [DevTools](http://goto/devtools). It is available for Linux systems on <abbr title="Heterogeneous Universal File System">HUFS</abbr>. For more information on installing Fortify, please refer to [Download HP Fortify](https://teams.ib.cnet.ubs.net/sites/appsec/SiteCollectionDocuments/Download_HP_Fortify.aspx).

### Scanning as part of continuous integration

Static Code Analysis scans can be run on a build server and automatically uploaded to SSC as part of a continuous integration workflow. This is available on [TeamCity](../tools/teamcity.html) and other CI servers. More information about integrating Fortify into a build server can be found [here](https://teams.ib.cnet.ubs.net/sites/appsec/SiteCollectionDocuments/Download_HP_Fortify.aspx#buildserverintegration).

## Further Reference

Further detailed information about Static Code Analysis in UBS can be found on the [Secure Development Services](http://goto/security-static-analysis) site.



