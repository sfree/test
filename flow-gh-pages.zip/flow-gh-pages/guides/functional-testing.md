---
layout: guide
title: Functional Testing
subtitle: Test functionalities of a system or application
usage: required
status: In-progress
author: Saurav Santosh
---

## What?

**Functional testing** (also known as Black-box testing) verifies that each function of the software application operates in conformance with the requirement specification. All functionalities of the system is tested by providing appropriate input, verifying the output and comparing the actual results with the expected results.

This testing involves checking of user interface, APIs, database, security, client/ server applications and functionality of the Application under test. 

## Why?

The prime objective of Functional testing is checking the functionalities of the software system. It mainly concentrates on:

- **Mainline functions**:  Testing the main functions of an application
- **Basic Usability**: It involves basic usability testing of the system. It checks whether an user can freely navigate through the screens without any difficulties.
- **Accessibility**:  Checks the accessibility of the system for the user
- **Error Conditions**: Usage of testing techniques to check for error conditions.  It checks whether suitable error messages are displayed.



## Who and When?

To perform functional testing, Software tester or Quality Analyst typically creates a set of input/outcome relationships that verify whether each specification requirement is implemented correctly. At least one test case should be created for each entry in the specification document; preferably, these test cases should test the various boundary conditions for each entry.

The testing can be done either manually or using automation during testing phase.

## How?

In order to functionally test an application, following steps must be observed.

- Understand the Requirements
- Identify test input (test data)
- Evaluate the expected outcomes with the selected test input value
- Execute test cases 
- Comparison of actual and expected result


**Functional automation Tools**

- [Robot Framework](https://github.ldn.swissbank.com/pages/OpenUBS/flow/tools/robot-framework.html)
- [Test Complete](https://github.ldn.swissbank.com/pages/OpenUBS/flow/tools/test-complete.html) 


**Conclusion**
Functional testing is process of testing functionalities of the system and ensures that the system is working as per the functionalities specified in the business document. The goal of this testing is to check whether the system is functionally perfect!!
