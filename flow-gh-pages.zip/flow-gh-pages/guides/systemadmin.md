---
title: System Administration
subtitle: System administration is the design, installation, configuration and support of the servers. Small organisations may have just one system administrator, whereas large enterprises usually have a whole team of system administrators.
layout: guide
usage: required
status: in-review
author: Bobeeta Chanian
---

If you're responsible for looking after a collection of machines for any given environment, then you will need to be aware of how to expedite Systems Administration tasks, from keeping things ticking over nicely day-to-day, to managing infrastructure team requests to either intervene on system operation or help provide additional resources or applications for those systems.

##Basic Access-Hosts

For day-to-day activities, you will need to have the relevant accesses you need to work with the hosts and application accounts you are responsible for.
If you find you or a team member are short on access, then the best place to go to verify this is the [Unix Infotools page](http://infotools.swissbank.com/), which provides all the resources you need to query and confirm user and host permissioning in terms of Groups, Netgroups, Accounts, and Powerbroker roles.

If you take care of a large array of hosts, virtual or otherwise, you may want to use a tool such as [mRemoteNG](http://confluence.swissbank.com/display/EnvSupport/mRemoteNG) to allow you to organise and quickly switch between terminal sessions across these hosts.

##Infrastructure Service Teams and Requests (Unix)

Generally, System Administration tasks needing root/superuser access will be carried out by an Infrastructure Services (IS) team. For the most part you are likely to be interfacing with the unix support team.

If you find that you have a problem with one of your hosts, the quickest way to expedite investigation is to use the form at [My Assist](http://bw.assist.ubs.com/ticketform?check=27) to raise an Incident ticket to the Unix team (see 'Raise an Incident' button at the bottom of that page).
Once you've raised the ticket, chat on the MindAlign channel **#Global_Unix_Dev_Support**, where they will either expedite your request or escalate it to an L2 member of the team.

For other service requests, you can submit a ticket within ServiceNow (SNOW) . A list of Unix SNOW service catalog items with direct links is available on [this page](http://bw.assist.ubs.com/node/70124).
The assignment group for these in SNOW will be **'GTIS-GSC-GLOBAL-USD'** .
The storage related requests listed are taken care of by the Storage Helpdesk (MindAlign channel #Storage_Helpdesk), so if, for example, you see a mount or filesystem showing more space utilised than you can see visible data for, then it's likely you have excessive snapshot data on that filesystem, and the storage helpdesk are the team to take care of that problem.

**Email DLs**:    SH-GTIS-GSC-UnixGlobal-L2

##Infrastructure Service Teams and Requests (Database)

If you work with relational databases, you may need to raise an issue to the relevant DB Services team for that type of database.
There are online tools available for Oracle, Sybase and MSSQL, and they are conveniently all in one place [here](http://dssibdbservices.swissbank.com/twiki/bin/view/DBServices/ToolsMenu).
Oracle queries are handled at #Global_Oracle_Support. For Sybase and MSSQL, there is a consolidated MA channel (#Global_SybaseMSSQL_Support).

For Oracle and general DB services requests, there are documents and SNOW links and request types published [here](http://confluence.swissbank.com/display/CMSDDB/SNOW+Quicklinks+for+Database+services+%28Oracle%29) and [here](http://confluence.swissbank.com/display/CMSDDB/How+To+Raise+Service+Now+for+Database+Services+Catalogue).
The assignment group for these in SNOW will be one of 'GTIS-GSC-GLOBAL-DSD-Oracle', 'GTIS-GSC-GLOBAL-DSD-Sybase', or 'GTIS-GSC-GLOBAL-DSD-MSSQL'.
Requests submitted to these teams are expedited on a first in, first out (FIFO) basis.

You can check the progress of your SNOW ticket in the queue by entering the RITM ticket reference into the '[Where Am I](http://gscoe.swissbank.com/cgi-bin-sso/wami-dsd/wami.pl)' page.

**Email DLs**:    DL-GTIS-ISD-GSC-DSD-Oracle, DL-GTIS-ISD-GSC-DSD-Sybase, DL-GTIS-ISD-GSC-DSD-MSSQL
