---
layout: guide
title: Jira
subtitle: How to access the UBS managed service
usage: recommended
author: Ben London
status: done
---

## Requesting Access

All users with a WebSSO account can login to Jira.

To see the projects for your team you will need to request access in ARP:

1. [Open ARP]({{ site.arp }})
2. Search for your team's access-right for the **Jira** asset

## Log-in

- <https://flow-jira.ubs.net>

You must use your production WebSSO shortname and password.

## Set your avatar

Jira will use your avatar from [Connections]({{ site.connections }}). If you do not have an Avatar in Connections, please upload one.

## Migration

There is a dedicated migration service to help migrate your Jira projects from a legacy Jira instance on to this managed service. Please [get in touch](https://connections.swissbank.com/groups/ubs-flow) to migrate.

## Email Integration

You can create new JIRA issues and leave comments to existing ones by email. [Learn more](https://connections.swissbank.com/groups/ubs-flow/projects/jira-as-a-service)

