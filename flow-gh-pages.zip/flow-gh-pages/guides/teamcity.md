---
layout: guide
title: Get started with TeamCity
subtitle: 
  This guide explains how to get access to the UBS Flow TeamCity service, which provides continuous integration features for building, testing, analysing and packaging your application code.
---

## About the Service

We operate a TeamCity service that includes Linux, Windows and Mac build agents. Some agents afre available in shared pools, but teams should ideally provision their own agents, for [detals on TeamCity Agents](https://connections.swissbank.com/docs/DOC-51091).

The service is seamlessly integrated with GitHub Enterprise and Nexus, so TeamCity projects can be set-up automatically from GitHub repositories, and the resulting built artifacts can be deployed automatically into Nexus. However, alternative SCMs and Artifact Management services can optionally be used instead.


## Where

The user interface for TeamCity can be accessed here: 

- <http://cft-teamcity.ldn.swissbank.com>

You can log-in using your UBS email address and WebSSO password. Anyone can login and take a look around.

## Access

TeamCity can automatically builds snapshots of your projects whenever there are code commits. However, you will need special permission to run release builds in TeamCity. To request access to a set of projects please [get in touch](mailto:DL-Flow-Tools@ubs.com)/

## FAQ

### How do I create a TeamCity build for my Repository?

Please email [DL-Flow-Tools@ubs.com](mailto:DL-Flow-Tools@ubs.com) with the following details:

- **Project name** - The TeamCity Administrators can create "root level" projects, beneath which project administrators (usually the person requesting the project) can create sub projects and build configs.  The root level project tends to be generic and usally the name of the requesting team.
- **List of users** - Each user will need to login initially to [TeamCity](http://cft-teamcity.ldn.swissbank.com) to create their account.  Additional users can be permissioned by the project administrator
- **Agents**. Please setup your agents to point to `http://cft-teamcity.ldn.swissbank.com` and we will authorise.