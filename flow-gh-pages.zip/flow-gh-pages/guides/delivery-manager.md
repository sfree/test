---
title: Delivery Manager
subtitle: Work on the solution design, break down the work, shield the developers
layout: guide
usage: required
status: in-review
author: Vitor Monteiro
---

Delivery Managers, aka Dev Leads, aka Tech Leads need a very distinct set of skills as they are in the center of the delivery process interfacing with Product Managers, Information Architects, Visual Designers, Support, Security and most importantly the Software Engineering team.

Main responsibilities
----------

The Delivery Manager should be an "all-rounder" with a key sense of anticipating and acting on problems before they become an issue.

- to effectively shield the engineering from unnecessary meetings and disruptions
- on an agile environment, conduct a very short scrum meeting to raise blockers that need addressing
- mediate story breakdown and planning poker sessions
- participate and/or monitor the User Experience work to be able to help Product Management with prioritization
- maintain a one-team mentality with all the people from the several teams you interface with
- fill in any gaps necessary to get the job done
- spend as most of the time as possible coding without letting it interfere with the other tasks
- to coach, mentor and contribute to the software engineers career and aspirations

The challenge for the Delivery Manager is quite high, as task prioritization can become quite a feat. The "all-rounder" and "get-the-job-done" mentality can work against the delivery manager if parts of the organization overload the role.




