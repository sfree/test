---
title: Open Source
subtitle: 
  The open-source movement has revolutionised software development, producing some of the most popular software in the world, like the Linux operating system and Apache web-server. UBS makes extensive use of open-source technology, but its important to understand how to do so responsibly, since there are associated risks and rewards.
layout: guide
---

# Contents

1. Introduction to open-source
2. Using open-source technologies
3. Contributing to open-source projects

# 1. Introduction to open-source

Open source is a form of software where the source-code is published openly for all to see. This is in contrast to proprietary software, where the source-code is kept private by a vendor. UBS uses many open-source technologies, including Linux, Apache, Tomcat, Spring, Cassandra and jQuery.

- [Learn more about open-source in Wikipedia]()
- [Read a classic book on open-source]()

Open source software is published under a variety of different licenses, some of which allow UBS to use the software without license costs. However, some open-source licenses do still require commercial license agreements for use in enterprise situations, and others impose legal conditions that are unacceptable to UBS. For these reasons, approval must be granted for the use of specific open-source technologies.

- Apache 1 & 2, MIT and BSD licenses are generally acceptable
- GPL, LGPL and other "copyleft" licenses are generally unacceptable
- Commercial licenses are sometimes available for software otherwise published under unacceptable licenses

# Using open-source technologies

There is a simple process to get approval for the use of open source software (OSS).

- First you should review the list of [approved components](https://teams.cc.cnet.ubs.net/sites/GSAM/oss/Lists/OSS_CompApprovals/AllItems.aspx)
- If you need to get approval for a new piece of software you can fill in the Service Now form descried [here](https://connections.swissbank.com/docs/DOC-52668)


## Links and references

- [OSS Connections groups](https://connections.swissbank.com/docs/DOC-52668)
