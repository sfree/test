---
title: Audits
subtitle:
  Audits are regularly performed of both business and technology areas, including software development teams. Their purpose is to provide senior management and external regulators with an objective view of how risks are being managed. Issues identified by audits require prompt attention and action to remediate.
layout: guide
---

## Group Internal Audit (GIA)

Group Internal Audit (GIA) is a supervisory function within UBS, independent of business management and risk control. GIA annually perform a number of audits of both business and technology areas. Learn more at the GIA website: [http://goto/gia](http://goto/gia)

## External Auditor

In addition to audits conducted by GIA, an external auditor performs an annual certification of all relevant IT systems, as part of UBS's financial audit. This will include all [SOX (Sarbanes-Oxley)](http://en.wikipedia.org/wiki/Sarbanes%E2%80%93Oxley_Act) relevant applications. Some of this testing is performed on behalf of the external auditor by another external provider engaged by Compliance & Operational Risk Control.

The external auditors also produce annual, independent reports that are distributed to clients for certain products and services. Gaps identified during this process require attention, as UBS must provide remediation plans that are also shared with clients.

## External Regulators

There are also inspections on a cyclical basis from external regulators, such as the Monetary Authority of Singapore (MAS). Like other forms of audit, any gaps identified need attention.