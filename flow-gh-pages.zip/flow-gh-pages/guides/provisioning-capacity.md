---
layout: guide
title: Provisioning Capacity
subtitle: Provisioning Capacity is a set of actions required to prepare and make available machines and storage for operational use. Virtual and physical machine provisioning controls activities related to deploying and customizing virtual machines, configuring and staging physical servers into a data-centre. Storage provisioning is the process of assigning capacity to servers and virtual machines. 
usage: recommended
status: in-progress
author: Bobeeta Chanian
---


Provisioning of machines is carried out by IS ( Infrastructure Services). An ISL (Infrastructure Services Lead) is assigned to each department team to manage all aspects of capacity planning and commissioning. They are the point of contact that face-off with the team leads and the appropriate infrastructure team members to complete requests. The team lead maintains the relationship with the ISL.

There are separate processes for the provisioning of VM's, Physical Machines and storage.

##Provisioning Virtual Machines

The engagement is between the ISL and the application team lead, and the stream requirements are delivered to the ISL. Forward planning is encouraged to ensure capacity is available in good time. 
For completeness, and so the request can be tracked, the application team lead will fill in the IB Virtual Machine request form the [IBIT- ISL portal](https://connections.swissbank.com/groups/ib-isl) 

This will then be followed up with an e-mail where the application team lead will get the ISL to confirm the SLA for the build, configuration and readiness of the machines.

Teams can provide the ISL either with a model machine to copy the configuration, or a puppet manifest config that specifies the local configuration.
The ISL will raise a forecast (one per region per order) in the [Forecast Portal](http://gscoe.swissbank.com/htdocs-sso/FCP) 
This is reviewed and approved by ISDS (Infrastructure Solution Designs). A detailed design 'blueprint' is produced and reviewed ( in the UK and US) by a gatekeeper process before the ISL confirms the order. This order is then processed by the IRM team which ensures that tickets for specific tasks are created and completed.

The entire process can take from two to six weeks depending on the availability of the hardware. There is no CAPEX cost associated with a Virtual Machine.

Very large Virtual Machines may also need to go through an [exception approval process](https://teams.ib.cnet.ubs.net/sites/VISM/Lists/Exception_Approval_Process/AllItems.aspx). This needs to be completed with ISL support.

##Provisioning Physical Machines

The lead time for provisioning physical machines can take from six to nine months. The application delivery team will provide the ISL with their requirements for the new infrastructure through the [IBIT-ISL portal](https://conections.swissbank.com/groups/ib-isl).

As much information as possible must be populated into the request, from:

- The specification of the machines
- The location of where they must be placed and the security zones they need to be aligned to
- The storage and database requirements and any tree paths and sizes
- The net groups and powerbroker rules
- The local configuration
- The business justification to support the requirement and the impact of not supporting the change.

The ISL wil lcreate a deal deck for the review board to review and agree. For CTB purchases, the requirement gets populated into a system called **Extract** (this holds a view of infrastructure up to six months and beyond). For RTB purchases, email approval is required from the head of IB IT.

The design is reviewed by the ISD's to understand usage, systems and availability within data-centers.
The request is then submitted for financial approval with the business managers and IS leads.

One financial approval is obtained an order is raised within in EOS (shopping cart) to order the servers from the vendor. The process right through to approvals can take up to three months and the delivery of servers can also take up to three months.

Once the servers arrive, they are places in the required data center and aligned to the network, provisioned and made available with the correct configuration and net-groups which can take up to three months. 
The machines are tested with the application team members and then handed to the business.

The process of tracking the request can be done through GRS which is hardware request ticketing system with a nested structure.
