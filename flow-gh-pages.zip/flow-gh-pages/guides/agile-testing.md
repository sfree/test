---
layout: guide
title: Agile Testing
subtitle: 
  This page describes an agile testing strategy, including the guiding principles, the practices that should be applied, and how testing activities fit into the overall delivery process. More detailed guides are provides for each of the referenced testing activities.
status: in-progress
author: Pooja Kulkarni
---

## Principles

1. _Test early_ &mdash; test code as it is being developed to catch defects early; define acceptance tests that can be executed; collaborate with other disciplines from the start of delivery.
2. _Test often_ &mdash; test code repeatedly as it is developed and changed; use technologies to automate test runs and report generation; guard against regression with automated test suites.
3. _Test smartly_ &mdash; become skilled in technologies that improve testing; automate repetitive tests to reduce manual testing needs; focus manual efforts on the most demanding and thoughtful test activities.

## Practices

Our testing practices are categorised using a variation of the [Agile Testing Quadrants](http://www.exampler.com/old-blog/2003/08/21/#agile-testing-project-1):

<figure>
  <table class="agile-table1" style="border:0px">
    <tbody><tr>
  <td style="border:0px">&nbsp;</td>
     <th>Support development</th>
      <th>Critique project</th>
    </tr>
<tr style="background-color: #ffffff;">
      <th>Business facing</th>
      <td style="background-color:#ffffff"> 
        <a href="{{ site.url }}/guides/functional-testing.html">Functional testing</a><br>
      </td>
      <td style="background-color:#e6e6e6">
        <a href="{{ site.url }}/guides/exploratory-testing.html">Exploratory testing</a><br>
        <a href="{{ site.url }}/guides/show-and-tell.html">Show-and-tell</a><br>
        <a href="{{ site.url }}/guides/usability-testing.html">Usability testing</a>
     </td>
    </tr>
    <tr>
      <th>Technology facing</th>
      <td style="background-color:#ffffff">
        <a href="{{ site.url }}/guides/unit-testing.html">Unit testing</a><br>
        <a href="{{ site.url }}/guides/component-testing.html">Component testing</a><br>
        <a href="{{ site.url }}/guides/api-testing.html">API testing</a>
      </td>
      <td style="background-color:#fafafa">
        <a href="{{ site.url }}/guides/non-functional-testing.html">Non-functional testing</a>
       </td>
    </tr>
    <tr style="background-color:#ffffff">
      <td style="border:0px">
      </td><td colspan="2" style="border:0px; padding-top:25px">
        <span style="background-color:#ffffff">automated</span>
        <span style="background-color:#fafafa">partially-automated</span>
        <span style="background-color:#e6e6e6">manual</span>
      </td>
    </tr></tbody>
  </table>
</figure>


- _Business-facing_ tests validate the business functionality that software provides, while _technology-facing_ tests validate the workings of the technical solution.

- Some tests _support development_, helping teams make software that works as expected, while other tests _critique a project_, helping teams determine how their working software might be improved.

- Many kinds of tests can be automated effectively by skilled testers, while some kinds of tests demand thoughtful manual effort.

## Processes

We integrate testing practices into the end-to-end delivery process by aligning them with stages of the deployment pipeline: 

<figure>
  <table class="">
    <tbody><tr>
      <th style="padding:12px;" colspan="4">Commit Cycle</th>
    </tr>
    <tr>
      <td style="padding:12px;background-color:#ffffff">
        <a href="{{ site.url }}/guides/unit-testing.html">Unit testing</a><br>
            </td>
      <td style="padding:12px;background-color:#ffffff">
        <a href="{{ site.url }}/guides/component-testing.html">Component testing</a><br>
        <a href="{{ site.url }}/guides/api-testing.html">API testing</a><br>
        <a href="{{ site.url }}/guides/unit-testing.html">Functional testing</a><br>
     </td>
      <td style="padding:12px;background-color:#fafafa">
        <a href="{{ site.url }}/guides/non-functional-testing.html">Non-functional testing</a><br>
      </td>
      <td style="padding:12px;background-color:#e6e6e6">
        <a href="{{ site.url }}/guides/exploratory-testing.html">Exploratory testing</a><br>
        <a href="{{ site.url }}/guides/show-and-tells.html">Show-and-tells</a><br>
        <a href="{{ site.url }}/guides/usability-testing.html">Usability testing</a>
      </td>
    </tr>
  </tbody></table>
</figure>

- Tests that are easiest to develop and fastest to run happen soonest and most frequently. When they fail deployment cannot proceed to the next stage.

- Tests that are critical to releasing working software run as early as practical and in logical order. When they fail deployment cannot proceed to the next stage.

- Tests that are more subjective, time-consuming and manual run later and less often. When they fail, deployment may still proceed in some cases, and future work may be planned to improve.

There are other practices that complement these testing activities, but are more closely associated with other disciplines, such as UX prototyping and customer feedback surveys.

## A note on Regression Testing

Regression testing is not considered to be a specific test activity, but rather the ability to re-run an appropriate set of tests whenever software changes, to verify that regression has not occurred. As systems grow, the need for automated regression testing increases, otherwise productivity falls due to increasing amounts of time spent manually testing.

## Organisation

We include [Quality Analysts]({{ site.guides }}/quality-analysts.html) in cross-functional agile delivery teams. In addition to carrying out testing, QAs are involved in many of the team activities, such as story breakdowns, iteration planning, standup meetings and show-and-tells.

For a typical project with front-end and server-side components, a ratio of 1 quality analyst to 4 or 5 developers should be sufficient. A higher ratio may be needed if a project has accumulated technical debt, such as a reliance on extensive manual regression tests. The ratio may also be lower for some projects, depending on the level of testing needed beyond developer testing.

We advocate the use of Test Engineering teams to provide technical solutions and professional services to agile delivery teams. This could include packaging desktop testing software, developing systems of test automation and quality reporting, and assisting other teams with specialist testing tasks.
