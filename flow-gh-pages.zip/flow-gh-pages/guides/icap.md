---
layout: guide
title: ICAP (Internal Control Assessment Process)
subtitle: The Internal Control Assessment Process is part of the Operational Risk Framework (ORF2) which is how we manage and control operational risk at UBS. This ICAP is the assessment of the design and operating effectiveness of the internal control environment and is performed on a bi-annual basis.
status: in-progress
author: Adrian Smith
---

For Group Technology, we assess controls in core control areas such as Requirements Management, Access Management, Change Management etc. The relevant controls requiring assessment are listed in the Control Catalogue, maintained by IT Risk.

Learn more at the ORF website: [http://goto/orf](http://goto/orf)
