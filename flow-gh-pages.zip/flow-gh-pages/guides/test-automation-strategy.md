---
layout: guide
title: Test Automation Strategy
subtitle: 
  This page explains Agile automation pyramid and architecture
status: in-progress
author: Pooja Kulkarni
---

#Agile Automation Pyramid

![agileautomationpyramid](https://github.ldn.swissbank.com/github-enterprise-assets/0000/0192/0000/2859/d1e92072-95a4-11e4-850e-0cd0c342fd35.jpg)

Traditionally, most of the effort was used in developing UI centric test automation. This was mainly because testers were primarily writing tests, so the comfort level was mainly in functional tests and the tools mainly leveraged the same. Developers worked seperately with unit tests but almost never involved in automating business logic. This model can cause problems in long run as UI tests are unstable and brittle. One change in the font or button can fail hundred uunderlying tests. Also, this does not promote the one team appraoch.

Instead, if we can aim at the above model, where unit tests form a vast majority. API and component come next. If the architecture of application allows, most of the business logic can be verified at this level. At this level, the tests are much more robust and faster. QA and developers can write these tests together.

UI tests can be kept at minimun to verify the look and feel, and business logic which can be checked only from UI. 

Initially test automation was often a one tool operation. The agile approach is tool agnostic, however emphasises the tools can be different for different layer.

The below diagram explains further about tool agnostic, Test Driven Development approach (TDD).

#Test Architecture

![testarchitecture](https://github.ldn.swissbank.com/github-enterprise-assets/0000/0192/0000/2860/fd2973d6-95a4-11e4-88cd-bdc0f1f11e36.jpg)

This diagram shows the test architecture which can be used for Test Driven Development. Here, the tests are tool agnostic and are written in Domain Specific language. The tool in abstraction layer then translates them into relevant test scripts and calls the required tools like Selenium Websdriver for HTML UI testing, Test Complete for Flex UI testing, Robot Framework Requests Library for API testing, jmeter for Load testing etc.

Advantages -

- Simple, easily adaptable framework for anyone to use
- Tool agnostic approach : This model allows the tests to be decoupled with underlying technology used. In case of changing the tools and scripts, the test cases still remain the same. 
- Automated scripts serve as repository for test cases
- The abstration layer acts as one stop shop for calling all underlying tools and libraries. This helps in doing end to end testing for releases
