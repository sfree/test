---
layout: guide
title: Lean workflow
subtitle: Use features of Jira to implement a workflow that helps increase efficiency.
usage: recommended
status: in-review
author: Thomas Sugden
---

This guide describes a set of lean principles that can be supported by Jira Agile.

## Plan small frequent releases

Plan small and frequent release versions, prefering monthly to quarterly, and fortnightly to monthly. When working on a longer term goal, find a way to deliver value in smaller increments. This increases the chance of success.

## Define discretely valuable stories

Define stories that deliver discrete value and could be released separately. Prefer to release stories individually or in small coherent batches.

## Break stories into tasks

Break stories into tasks for all the work needed across roles. This includes design, development, testing and review tasks. Some example tasks:

- A coding task for a developer
- An acceptance testing task for a quality analyst
- A design review task for a UX designer

## Assign work that is ready to begin

Start work in priority order and assign ownership of stories or tasks when they are ready to be started. Use assignment as a hand-over between roles in the team. For example:

- A developer assigns a story to a QA person when it is ready for acceptance testing
- A QA person assigns a story back to a developer if it has failed acceptance testing
- A developer assigns a design review task to a UX designer when they have implemented a design spec

## View teamwork in 3 simple states

View your team's work using the default Jira agile board with these states:

- _"Unstarted"_ for work in the backlog
- _"In-progress"_ for work started but not yet done
- _"Done"_ means ready for deployment with no further change

## Flag stories that are blocked

If a story has been started, but progress stalls for whatever reason, mark the story as blocked and assign ownership to whoever will clear the blockage. A red flag will show in Jira beside the story.

## Clear blockages promptly

When a story is blocked, focus efforts on clearing the blockage and preventing future blockages from happening for a recurring reason. 

## Waiting for QA means blocked

If a story is waiting for the availability of another team member, such as a tester, then it is blocked. Try to keep the right balance of skills on your team to avoid this kind of blockage, and make smart use of automation.

## Limit work-in-progress

Set a work-in-progress limit in Jira so the "In-progress" lane turns red when your team has taken on too much in parallel. Limit this to one less, or no larger than, the number of developers on the team.

If the work-in-progress limit is reached, team members try to pick-up tasks from in-progress work-items instead of starting anything new. This helps deliver value sooner instead of building inventory.

## Fix defects promptly

When a defect is found that isn't part of an in-progress story undergoing acceptance testing, raise a new Issue of type Defect in Jira. This should be picked up by a developer in preference to starting any new task or story unless the defect is accepted.
