---
layout: guide
title: ORI (Operational Risk Inventory)
subtitle: The Operational Risk Inventory (ORI) is the primary repository for information on internal control deficiencies and remediation activities at UBS. ORI is an element of the Standard Operational Risk Tool (SORT) which is the group wide operational risk tool and enables consolidated reporting.
status: in-progress
author: Adrian Smith
---

Within Group Technology, there are two main types of control deficiencies:

- **Self-identified issues** (SII) disclosed by Business and Functional Management. These are stored in the SORT tool.
- **Issues identified by Group Internal Audit and External Audit**. These are stored in the CARAT tool.

For each issue, actions will be identified and also recorded in the relevant toolset. Action owners are expected to provide monthly updates on the progress of these actions in the SORT and CARAT tool.

For some Self-identified issues, management may choose not to remediate the item and the issue will be listed as Deferred in SORT.

Issues are rated on a severity scale from **1** (least material) to **5** (most material) based on the Financial and Non-Financial impact of the control deficiency.

If any member of staff is aware of a control deficiency that is not recorded in the risk inventory then they should raise this with either their management or IT Risk.
