---
layout: guide
title: SEEM (Security Exception Entry and Management)
subtitle: The SEEM system is a centralised repository for storing security exceptions within UBS. Any violations of IT policy must be recorded and approved in the SEEM system. If the violation is assessed as having a material impact, then an ORI may be required.
status: in-progress
author: Adrian Smith
---
## What is it?
Security Exception Entry and Management (SEEM)
A seem system allows GT staff to record and authorize exceptions to IT policy.  Examples of such requests include:
The need for a department to grant developer access to production for deployments – an activity that falls outside of IT Policy "1-S-002110 – Developer Update Access to Production" or the installation of non-standard hardware or software into a UBS environment.

## How does the process work?
SEEM comes with a built-in approval workflow. In all cases, an assessment of the details is made against ORF2 standards. For lower risk items (ORF2 rating 1 or 2) line manager approval is sufficient for request approval. For material risk ratings (3 or above), an ORI will be created to manage the risk.
By default requests will be approved for 1 year and require mitigating controls and action plans

## Where can I find more information?
[Raise a seem](https://seem.swissbank.com/SEEM/Home.aspx#summary)

[Help and manuals](http://confluence.swissbank.com/display/SEEM/Home)
