package com.ubs.idp.base.utils;

import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

public class TimeUtils {

    public static String now(String timeZone, String format) {
        return nowPlusDelta(timeZone, format, 0);
    }

    public static String nowPlusDelta(String timeZone, String format, int deltaHours) {
        String now = null;
        
        DateTime dtNow = new DateTime().withZone(DateTimeZone.forID(timeZone));
        
        if (deltaHours != 0) {
            dtNow = dtNow.plusHours(deltaHours);
        }
        
        now = dtNow.toString(format);
        
        return now;
    }

    /**
     * Returns a timestamp for today for the specifed timezone and format with the number
     * of delta days added/subtracted.
     * 
     * 
     * @param timeZone
     * @param format
     * @param deltaHours
     * @return
     */
    public static String nowPlusDeltaDays(String timeZone, String format, int deltaDays) {
        String now = null;
        
        DateTime dtNow = new DateTime().withZone(DateTimeZone.forID(timeZone));
        
        if (deltaDays != 0) {
            dtNow = dtNow.plusDays(deltaDays);
        }
        
        now = dtNow.toString(format);
        
        return now;
    }

    
    public static String tzDate(Date dateIn, String timeZone, String format) {
        DateTime dateTime = new DateTime(dateIn).withZone(DateTimeZone.forID(timeZone));
        
        return dateTime.toString(format);
    }
}