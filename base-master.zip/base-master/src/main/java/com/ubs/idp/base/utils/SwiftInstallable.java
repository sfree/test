package com.ubs.idp.base.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.MissingArgumentException;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;

/**
 * Helper class that should be extended if the application you are deploying is
 * to be installed by swift.
 * 
 * This class will extend the command line parameters of your application to
 * allow --swift option to be passed. If the application is then run with this
 * option it will automatically self extract the contents of the "swift"
 * directory in the jar which should contain custom swift scripts for deployment
 * 
 * The implementing class only needs to call <code>super( args )</code> with the
 * command line arguments. 
 * 
 * @author loverids
 * 
 */
public abstract class SwiftInstallable
{
	private static final String OPTION_HELP = "--help";
	private static final String OPTION_SWIFT = "unpackSwiftScripts";

	private static final String SWIFT_DIR = "swift";
	private static final String FILE_URI_PREFIX = "file:";
	
	protected CommandLine commandLine;
	protected Options options = new Options();
	protected String[] helpMe =	{ OPTION_HELP };

	
	/**
	 * The default constructor adds the <code>--swift</code> option to the 
	 * command line and then does a parse to see if it has been specified. If
	 * so, it does the swift file extraction from the jar and exits.
	 * @param args
	 */
	public SwiftInstallable(String[] args)
	{
		Option swift = new Option(null, OPTION_SWIFT, true, "When specified, the contents of this jars 'swift' directory will be extracted to the directory specified for this option");
		swift.setOptionalArg(true);
		options.addOption(swift);

		try
		{
			// Parse command line and check for the seift option
			CommandLineParser clp = new PosixParser();						
			CommandLine cmd = clp.parse(options, args);
						
			if( cmd.hasOption(OPTION_SWIFT) )
			{				
				doSwiftInstall(cmd.getOptionValue(OPTION_SWIFT));
				System.exit(0);
			}
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
	}


	/**
	 * Infers the jar file that this code is being run from and calls the extraction
	 * to extract the contents of the "swift" folder in the root of this jar
	 */
	public void doSwiftInstall( String targetDir )
	{
		try
		{
			// Extract the jar file path and trim off the characters 
			String jarFilePath = this.getClass().getProtectionDomain().getCodeSource().getLocation().getFile();
			if( jarFilePath.indexOf("!") != -1 )
			{
				jarFilePath = jarFilePath.substring(0,jarFilePath.indexOf("!"));
			}
			if( jarFilePath.startsWith(FILE_URI_PREFIX))
			{
				jarFilePath = jarFilePath.substring(FILE_URI_PREFIX.length()); 
			}
								
			File jarFile = new File(jarFilePath);
			
			// Default the target dir to the same dir as the jar file if not specified 
			if( targetDir == null || targetDir.trim().length() == 0 )
			{
				targetDir = jarFile.getParent();
			}
			
			File target = new File(targetDir);

			System.out.println("Extracting the 'swift' directory from " + jarFilePath + " to " + targetDir );
			extractFromJar(jarFile, SWIFT_DIR, target);
			
			System.out.println("DONE!");
			
			System.exit(0);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Extracts the contents of the specified path within the jar file to the target directory
	 * @param jarFile
	 * @param path
	 * @param target
	 * @throws IOException
	 */
	public static void extractFromJar(File jarFile, String path, File target) throws IOException
	{
		if (!jarFile.exists()) throw new FileNotFoundException("Could not find jar file " + jarFile);
		if (!target.exists() || !target.isDirectory()) throw new FileNotFoundException("Could not find target directory " + target);

		// Convert path to use forward slashes
		path = path.replace('\\', '/');

		JarFile jar = new java.util.jar.JarFile(jarFile);
		Enumeration<JarEntry> entries = jar.entries();
		while (entries.hasMoreElements())
		{
			JarEntry file = entries.nextElement();

			if (file.getName().startsWith(path))
			{
				System.out.println("Extracting " + file.getName());
				File f = new java.io.File(target + java.io.File.separator + file.getName());

				// if its a directory, create it
				if (file.isDirectory())
				{
					f.mkdir();
					continue;
				}

				InputStream is = jar.getInputStream(file); // get the input
															// stream
				FileOutputStream fos = new FileOutputStream(f);

				// write contents of 'is' to 'fos'
				while (is.available() > 0)
				{
					fos.write(is.read());
				}
				fos.close();
				is.close();
			}
		}

		jar.close();

	}

	
}
