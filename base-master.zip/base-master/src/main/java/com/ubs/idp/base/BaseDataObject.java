package com.ubs.idp.base;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Generic schemaless return object
 * TODO Support non-String keys 
 * 
 * @author paulmc
 * @author haniffsy 
 */
public class BaseDataObject implements DataObject {
	private Map<String, String> keys;
	private Map<String, Object> attributes;
	
	/**
	 * Make sure ready to receive keys and attrs
	 */
	public BaseDataObject() {
		this.setKeys(new LinkedHashMap<String,String>());
		this.setAttributes(new LinkedHashMap<String,Object>());
	}

	/* (non-Javadoc)
	 * @see com.ubs.idp.dating.domain.DataObject#addKey(java.lang.String)
	 */
	@Override
	public void addKey(String keyName, String keyValue) {
		// keys not-null from constructor
		keys.put(keyName,keyValue);
	}
	
	/**
	 * @param attrName The name of this attribute
	 * @param attrValue The attribute value
	 */
	public void addAttribute(String attrName, Object attrValue) {
		// attributes non-null from constructor
		attributes.put(attrName, attrValue);
	}
		
	
	/* (non-Javadoc)
	 * @see com.ubs.idp.dating.domain.DataObject#getKeys()
	 */
	@Override
	public Map<String, String> getKeys() {
		return keys;
	}

	/* (non-Javadoc)
	 * @see com.ubs.idp.dating.domain.DataObject#setKeys(java.util.List)
	 */
	@Override
	public void setKeys(Map<String, String> newKeys) {
		this.keys = newKeys;
	}

	/* (non-Javadoc)
	 * @see com.ubs.idp.dating.domain.DataObject#getAttributes()
	 */
	@Override
	public Map<String, Object> getAttributes() {
		return attributes;
	}

	/* (non-Javadoc)
	 * @see com.ubs.idp.dating.domain.DataObject#setAttributes(java.util.Map)
	 */
	@Override
	public void setAttributes(Map<String, Object> newAttributes) {
		this.attributes = newAttributes;
	}

	/* (non-Javadoc)
	 * @see com.ubs.idp.dating.domain.DataObject#getDeltas(com.ubs.idp.dating.domain.BaseDataObject)
	 */
	@Override
	public Map<String, Object> getDeltas(BaseDataObject compareWith) {
		

		if (null == compareWith)
			throw new IllegalArgumentException("You need to provide an object to compare with.");

		if (null == this.keys || !this.keys.equals(compareWith.keys))
			throw new IllegalStateException("You're comparing objects with different keys.");
		
		
		Map<String,Object> deltas = new LinkedHashMap<String,Object>();
		
		Map<String,Object> secondAttrs = compareWith.getAttributes();
		
		Set<String> firstCols = attributes.keySet();
		Set<String> secondCols = secondAttrs.keySet();
		
		for (String columnName : secondCols) {
			// do we have a matching column
			if (firstCols.contains(columnName)) {
				if (!attributes.get(columnName).equals(secondAttrs.get(columnName))) {
					deltas.put(columnName, secondAttrs.get(columnName));
				}
			}
			// add the new column to the deltas
			else {
				deltas.put(columnName, compareWith.getAttributes().get(columnName));
			}
		}	
			
		return deltas;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((keys == null) ? 0 : keys.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		BaseDataObject other = (BaseDataObject) obj;
		if (keys == null) {
			if (other.keys != null) return false;
		}
		else if (!keys.equals(other.keys)) return false;
		return true;
	}

	/**
	 * @return A JSON-like string representation of this object
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer buffy = new StringBuffer("BaseDataObject ");
		buffy.append("{");
		buffy.append("\"keys\":");
		buffy.append("[");
		for (String keyName : keys.keySet()) {
			buffy.append("{");
			buffy.append("\"name\":");
			buffy.append("\"");
			buffy.append(keyName);
			buffy.append("\"");
			buffy.append(",");
			buffy.append("\"value\":");
			buffy.append("\"");
			buffy.append(keys.get(keyName));
			buffy.append("\"");			
			buffy.append("}");
			buffy.append(",");
		}

		buffy = snipComma(buffy);
		buffy.append("]");
		buffy.append(", ");
		buffy.append("\"attributes\":");
		buffy.append("[");
		if (this.attributes != null) {
			Set<String> cellNames = this.attributes.keySet();
			for (String cell : cellNames) {
				buffy.append("{");
				buffy.append("\"attrName\":");
				buffy.append("\"");
				buffy.append(cell);
				buffy.append("\"");
				buffy.append(",");
				buffy.append("\"attrValue\":");
				buffy.append("\"");
				buffy.append(attributes.get(cell));
				buffy.append("\"");
				buffy.append("}");
				buffy.append("},");
			}
			buffy = snipComma(buffy);
		}
		buffy.append("]");
		buffy.append("}");
		return buffy.toString();
	}
	
	
	private StringBuffer snipComma(StringBuffer buffy) {
		if (buffy.charAt(buffy.length()-1) == ',')
			buffy.deleteCharAt(buffy.length()-1);
		return buffy;
	}

	
	
	
}