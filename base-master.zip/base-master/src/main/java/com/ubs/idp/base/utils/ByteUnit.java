package com.ubs.idp.base.utils;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;

public enum ByteUnit {

	// @formatter:off
	BYTES("b", "b", "byte") {
		public long convert(long sourceAmount, ByteUnit sourceUnit) { return sourceUnit.toBytes(sourceAmount); }
		public long toBytes(long amount) { return amount / C0; }
		public long toKilobytes(long amount) { return amount / C1; }
		public long toMegabytes(long amount) { return amount / C2; }
		public long toGigabytes(long amount) { return amount / C3; }
		public long toTerabytes(long amount) { return amount / C4; }
		public long toPetabytes(long amount) { return amount / C5; }
	}, 
	KILOBYTES("k", "kb", "kilobyte") {
		public long convert(long sourceAmount, ByteUnit sourceUnit) { return sourceUnit.toKilobytes(sourceAmount); }
		public long toBytes(long amount) { return x(amount, C1); }
		public long toKilobytes(long amount) { return amount / C0; }
		public long toMegabytes(long amount) { return amount / C1; }
		public long toGigabytes(long amount) { return amount / C2; }
		public long toTerabytes(long amount) { return amount / C3; }
		public long toPetabytes(long amount) { return amount / C4; }
	},
	MEGABYTES("m", "mb", "megabyte") {
		public long convert(long sourceAmount, ByteUnit sourceUnit) { return sourceUnit.toMegabytes(sourceAmount); }
		public long toBytes(long amount) { return x(amount, C2); }
		public long toKilobytes(long amount) { return x(amount, C1); }
		public long toMegabytes(long amount) { return amount / C0; }
		public long toGigabytes(long amount) { return amount / C1; }
		public long toTerabytes(long amount) { return amount / C2; }
		public long toPetabytes(long amount) { return amount / C3; }
	},
	GIGABYTES("g", "gb", "gigabyte") {
		public long convert(long sourceAmount, ByteUnit sourceUnit) { return sourceUnit.toGigabytes(sourceAmount); }
		public long toBytes(long amount) { return x(amount, C3); }
		public long toKilobytes(long amount) { return x(amount, C2); }
		public long toMegabytes(long amount) { return x(amount, C1); }
		public long toGigabytes(long amount) { return amount / C0; }
		public long toTerabytes(long amount) { return amount / C1; }
		public long toPetabytes(long amount) { return amount / C2; }
	} ,
	TERABYTES("t", "tb", "terabyte") {
		public long convert(long sourceAmount, ByteUnit sourceUnit) { return sourceUnit.toTerabytes(sourceAmount); }
		public long toBytes(long amount) { return x(amount, C4); }
		public long toKilobytes(long amount) { return x(amount, C3); }
		public long toMegabytes(long amount) { return x(amount, C2); }
		public long toGigabytes(long amount) { return x(amount, C1); }
		public long toTerabytes(long amount) { return amount / C0; }
		public long toPetabytes(long amount) { return amount / C1; }
	},
	PETABYTES("p", "pb", "petabyte") {
		public long convert(long sourceAmount, ByteUnit sourceUnit) { return sourceUnit.toPetabytes(sourceAmount); }
		public long toBytes(long amount) { return x(amount, C5); }
		public long toKilobytes(long amount) { return x(amount, C4); }
		public long toMegabytes(long amount) { return x(amount, C3); }
		public long toGigabytes(long amount) { return x(amount, C2); }
		public long toTerabytes(long amount) { return x(amount, C1); }
		public long toPetabytes(long amount) { return amount / C0; }
	};
	// @formatter:on

	private static final long C0 = 1L;

	private static final long C1 = C0 * 1000L;

	private static final long C2 = C1 * 1000L;

	private static final long C3 = C2 * 1000L;

	private static final long C4 = C3 * 1000L;

	private static final long C5 = C4 * 1000L;

	private static long x(long a, long m) {
		if (a > Long.MAX_VALUE / m) {
			return Long.MAX_VALUE;
		}
		if (a < -Long.MAX_VALUE / m) {
			return Long.MIN_VALUE;
		}
		return a * m;
	}

	private List<String> names;

	private ByteUnit(String... names) {
		this.names = Arrays.asList(names);
	}

	private boolean matches(String name) {
		return names.contains(name);
	}

	public static ByteUnit getByteUnit(String name) {
		if (name == null) {
			throw new NullPointerException("Unit cannot be null");
		}
		EnumSet<ByteUnit> units = EnumSet.allOf(ByteUnit.class);
		for (ByteUnit byteUnit : units) {
			if (byteUnit.matches(name.toLowerCase())) {
				return byteUnit;
			}
		}
		throw new IllegalArgumentException(String.format("%s is not a valid ByteUnit", name));
	}

	public abstract long convert(long sourceAmount, ByteUnit sourceUnit);

	public abstract long toBytes(long amount);

	public abstract long toKilobytes(long amount);

	public abstract long toMegabytes(long amount);

	public abstract long toGigabytes(long amount);

	public abstract long toTerabytes(long amount);

	public abstract long toPetabytes(long amount);

	@Override
	public String toString() {
		return names.get(1).toUpperCase();
	}

}
