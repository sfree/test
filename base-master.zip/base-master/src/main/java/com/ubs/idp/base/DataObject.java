package com.ubs.idp.base;

import java.util.Map;

public interface DataObject {

	/**
	 * @param The name of this primary key for this object
	 * @param key The primary key value
	 */
	public abstract void addKey(String keyName, String key);

	
	/**
	 * @param attrName The name of this attribute
	 * @param attrValue The attribute value
	 */
	public abstract void addAttribute(String attrName, Object attrValue);
	
	
	/**
	 * @return the key
	 */
	public abstract Map<String, String> getKeys();
	
	

	/**
	 * @param newKey
	 *            the key to set
	 */
	abstract void setKeys(Map<String, String> newKeys);

	/**
	 * @return the attributes
	 */
	public abstract Map<String, Object> getAttributes();

	/**
	 * @param newattributes
	 *            the attributes to set
	 */
	abstract void setAttributes(Map<String, Object> newAttributes);

	/**
	 * Compare this with another version of the object (i.e. one that shares the same
	 * id) and determine the differences between them (using the equals() method of the
	 * attribute values).
	 * @param comparedWith The object to compare with
	 * @return The columns that are different
	 */
	public abstract Map<String, Object> getDeltas(BaseDataObject compareWith);

}