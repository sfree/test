/**
Run StringEncryptTool as a 'Java Application'.  A simple Swing GUI will appear 
which allows for a plain text string to be entered.  The 'Encrypt' button will 
generate an AES-128 encrypted HEX encoded string.

The encrypted HEX string can then be used in a properties file for example.

In order to decrypt the string back to plain text, use: com.ubs.idp.encrypt.Crypto#decrypt
*/
package com.ubs.idp.encrypt.gui;