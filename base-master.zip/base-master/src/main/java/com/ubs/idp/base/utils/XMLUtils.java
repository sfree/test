package com.ubs.idp.base.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * Generic XML utility class
 * @author mcminnp
 */
public class XMLUtils {
	
	private static final String lineSep = System.getProperty("line.separator");
	
	/**
	 * Parse XML input string into W3C Document
	 * @param inputXML
	 * @return
	 * @throws Exception
	 */
	public static Document getXMLDocument(String inputXML) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(new InputSource(new StringReader(inputXML)));
		return doc;
	}
	
	/**
	 * Return XPath expression evaluator from factory
	 * @return
	 */
	public static XPath getXPathInstance() {
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();

		return xpath;
	}

	/**
	 * Query W3C Document based on XPath expression
	 * @param document
	 * @param xpathExpr
	 * @return
	 * @throws XPathExpressionException
	 */
	public static NodeList xpathQuery(Document document, String xpathExpr) throws XPathExpressionException {
		XPath xpath = getXPathInstance();

		NodeList nodes = (NodeList) xpath.evaluate(xpathExpr, document, XPathConstants.NODESET);
		
		return nodes;
	}
	
	/**
	 * Pretty print XML string data
	 * @param unformattedXml
	 * @return
	 */
	public static String prettyPrint(String unformattedXml) {
		try {
			Source xmlInput = new StreamSource(new StringReader(unformattedXml));
			StringWriter stringWriter = new StringWriter();
			StreamResult xmlOutput = new StreamResult(stringWriter);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			transformerFactory.setAttribute("indent-number", 4);

			Transformer transformer = transformerFactory.newTransformer(); 
			transformer.setOutputProperty(OutputKeys.STANDALONE, "yes");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");

			transformer.transform(xmlInput, xmlOutput);

			return xmlOutput.getWriter().toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Read in an XML file and return the string data
	 * @param pathName
	 * @return
	 * @throws Exception
	 */
	public static String readXMLFile(String pathName) throws Exception {
		BufferedReader bufferedReader = null;

		try {
			File xmlFile = new File(pathName);

			FileReader fileReader = new FileReader(xmlFile);
			bufferedReader = new BufferedReader(fileReader);

			String temp = "";
			String xml = "";

			while((temp = bufferedReader.readLine()) != null){
				xml += temp.trim();
				xml += lineSep;
			}
			
			return xml;
		} finally {
			if (bufferedReader != null) {
				try { bufferedReader.close(); } catch (IOException e) {}
			}
		}
	}
}
