package com.ubs.idp.base.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import org.springframework.util.Assert;

/**
 * Collection of file helper methods
 * 
 * @author loverids
 * 
 */
public class IdpFileUtils
{
	/**
	 * Move (copy+zip then delete) to directory
	 * 
	 * @param destinationDirFile
	 * @param fileToMove
	 * @return
	 * @throws IOException
	 * @throws FileNotFoundException
	 * @throws Exception
	 */
	public static String moveAndZip(File destinationDirFile, File fileToMove) throws FileNotFoundException, IOException
	{
		Assert.notNull(fileToMove, "File to archive not specified");
		return renameAndZip(fileToMove.getName(), destinationDirFile, fileToMove);
	}
	
	/**
	 * Move (copy+zip then delete) to directory
	 * 
	 * @param newFileName
	 * @param destinationDirFile
	 * @param fileToMove
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static String renameAndZip(String newFileName, File destinationDirFile, File fileToMove) throws FileNotFoundException, IOException
	{
		byte[] buffer = new byte[1024];
		int len;

		Assert.notNull(destinationDirFile, "Archive directory not specified");
		Assert.notNull(fileToMove, "File to archive not specified");

		String zipFileName = destinationDirFile.getAbsolutePath() + File.separator + newFileName + ".zip";

		try (FileInputStream in = new FileInputStream(fileToMove); FileOutputStream fos = new FileOutputStream(zipFileName); ZipOutputStream zos = new ZipOutputStream(fos);)
		{

			ZipEntry ze = new ZipEntry(newFileName);
			zos.putNextEntry(ze);

			while ((len = in.read(buffer)) > 0)
			{
				zos.write(buffer, 0, len);
			}

			// Close and delete!
			in.close();
			if (!fileToMove.delete())
			{
				throw new IOException("Failed to delete original file after zipping " + fileToMove);
			}
		}

		return zipFileName;
	}

	/**
	 * Zips up files and removes originals
	 * 
	 * @param destinationDirFile
	 * @param zipFileName
	 * @param filesToZip
	 * @return
	 * @throws IOException
	 * @throws FileNotFoundException
	 * @throws Exception
	 */
	public static File zipAndRemove(File destinationDirFile, String zipFileName, File[] filesToZip) throws FileNotFoundException, IOException
	{
		byte[] buffer = new byte[1024];
		int len;

		Assert.notNull(destinationDirFile, "Archive directory not specified");
		Assert.isTrue(filesToZip.length > 0, "No files specifed to archive");

		if( !zipFileName.toLowerCase().endsWith(".zip") )zipFileName += ".zip";
		zipFileName = destinationDirFile.getAbsolutePath() + File.separator + zipFileName;

		try( FileOutputStream fos = new FileOutputStream(zipFileName); 
				 ZipOutputStream zos = new ZipOutputStream(fos); )
		{
			for( File fileToZip : filesToZip)
			{
				try (FileInputStream in = new FileInputStream(fileToZip) )
				{
					ZipEntry ze = new ZipEntry(fileToZip.getName());
					zos.putNextEntry(ze);
		
					while ((len = in.read(buffer)) > 0)
					{
						zos.write(buffer, 0, len);
					}
		
					// Close and delete!
					in.close();
					if (!fileToZip.delete())
					{
						throw new IOException("Failed to delete original file after zipping " + fileToZip);
					}
				}
		
			}
		}
			
		return new File( zipFileName );
	}
	
	/**
	 * Unzips the specified file to the target directory and returns an array
	 * of all files that were extracted
	 * @param zipFile
	 * @param targetDir
	 * @return
	 * @throws IOException 
	 * @throws ZipException 
	 */
	public static File[] unzipFile( File file, File targetDir ) throws ZipException, IOException
	{
		List<File> unzippedFiles = new ArrayList<File>();
		try(ZipFile zipFile = new ZipFile(file);
			FileInputStream fis = new FileInputStream(file) )
		{
			Enumeration entries = zipFile.entries();
			while( entries.hasMoreElements()  )
			{
				ZipEntry entry = (ZipEntry)entries.nextElement();
				InputStream is = zipFile.getInputStream(entry);	
				
				File outputFile = new File(targetDir.getAbsolutePath() + File.separator + entry.getName());
				unzippedFiles.add(outputFile);
				OutputStream os = new FileOutputStream(outputFile );
	            
	            byte[] buffer = new byte[1024];
	            int bytesRead;
	            
	            //read from is to buffer
	            while((bytesRead = is.read(buffer)) !=-1){
	                os.write(buffer, 0, bytesRead);
	            }
	            is.close();
	            
	            //flush OutputStream to write any buffered data to file
	            os.flush();
	            os.close();
			}
		}
		
		return unzippedFiles.toArray(new File[]{});
	}

}
