package com.ubs.idp.base;

import java.util.Collection;

public interface IDtoWrapper {

	public Collection<IPayLoad> getPayload();
	
	public void setPayload(Collection<IPayLoad> payload);
}
