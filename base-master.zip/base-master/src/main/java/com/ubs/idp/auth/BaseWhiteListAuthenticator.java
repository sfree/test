package com.ubs.idp.auth;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Abstract base class to implement allow/deny access based IP address
 * @author mcminnp
 */
public abstract class BaseWhiteListAuthenticator {

    private static final String DENY_PREFIX = "deny.";
    private static final String ALLOW_PREFIX = "allow.";
    private static final String CLASSPATH_PREFIX = "classpath:";
    private static final String FILE_PREFIX = "file:";

    public static final String COMMAND_CFG_OPT = "idp.accessCfgFile";
    public static final String DEFAULT_CFG_PATH = CLASSPATH_PREFIX  + "access.properties";
    
    private List<String> allowList = new ArrayList<String>(); 
    private List<String> denyList = new ArrayList<String>();
    
    /* 
     * Remember hosts access to reduce logging
     */
    private Map<String, String> allowedHosts = new HashMap<String, String>();
    private Map<String, String> deniedHosts = new HashMap<String, String>();

    private Properties clientConfig = null;

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Bare bones constructor
     */
    public BaseWhiteListAuthenticator() {

        logger.info("Constructing client access rules...");

        String cfgFilePath = System.getProperty(COMMAND_CFG_OPT);

        if (cfgFilePath == null || cfgFilePath.length() == 0) {
            cfgFilePath = DEFAULT_CFG_PATH;
        }

        initClientConfig(cfgFilePath);
    }

    /**
     * Initialise access controls
     * @param cfgFileNameIn
     */
    private void initClientConfig(String cfgFileNameIn) {
        InputStream input = null;

        logger.info("Loading config from {}...", cfgFileNameIn);

        try {
            String cfgFileName;

            if (cfgFileNameIn.startsWith(CLASSPATH_PREFIX)) {
                cfgFileName = cfgFileNameIn.substring(CLASSPATH_PREFIX.length());

                logger.info("Loading config from classpath resource '{}'...", cfgFileName);

                input = getClass().getClassLoader().getResourceAsStream(cfgFileName);
            } else {
                if (cfgFileNameIn.startsWith(FILE_PREFIX)) {
                    cfgFileName = cfgFileNameIn.substring(FILE_PREFIX.length());
                } else {
                    cfgFileName = cfgFileNameIn;
                }

                logger.info("Loading config from file '{}'...", cfgFileName);

                input = new FileInputStream(cfgFileName);
            }

            // load a properties file

            clientConfig = new Properties();

            clientConfig.load(input);

            // Parse config
            
            for (Object key : clientConfig.keySet()) {
                Object value = clientConfig.get(key);
                logger.debug("Config [{}] : [{}]", key, value);
                
                String strKey = key.toString();

                if (strKey.startsWith(ALLOW_PREFIX)) {
                    logger.info("Add allow pattern of '{}'", value.toString());
                    addAllowPattern(value.toString());
                } else if (strKey.startsWith(DENY_PREFIX)) {
                    logger.info("Add deny pattern of '{}'", value.toString());
                    addDenyPattern(value.toString());
                } else {
                    logger.warn("Invalid '{}' key in properties file?", strKey);
                }
            }

        } catch (Exception ex) {
            logger.error("Error opening config file?", ex);
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    logger.error("Error closing config file?", e);
                }
            }
        }
    }

    /**
     * Allow pattern
     * @param pattern
     */
    private void addAllowPattern(String pattern) {
        logger.debug("Allow hosts by pattern '{}'", pattern);
        allowList.add(pattern);
    }

    /**
     * Deny pattern
     * @param pattern
     */
    private void addDenyPattern(String pattern) {
        logger.debug("Deny hosts by pattern '{}'", pattern);
        denyList.add(pattern);
    }
    
    /**
     * Check is remote host/ip is allowed
     * @param ipAddr
     * @param hostName
     * @return
     */
    private boolean isAllowed(String ipAddr, String hostName) {
        boolean allowed = false;
        
        logger.debug("Check 'allow' access for host '{}' (addr '{}')...", hostName, ipAddr);
        
        for(String pattern : allowList) {
            if (hostName.matches(pattern) || ipAddr.matches(pattern)) {
                allowed = true;
                break;
            }
        }
        
        return allowed;
    }
    
    /**
     * Check is remote host/ip is denied
     * @param ipAddr
     * @param hostName
     * @return
     */
    private boolean isDenied(String ipAddr, String hostName) {
        boolean denied = false;
        
        logger.debug("Check 'deny' access for host '{}' (addr '{}')...", hostName, ipAddr);
        
        for(String pattern : denyList) {
            if (hostName.matches(pattern) || ipAddr.matches(pattern)) {
                denied = true;
                break;
            }
        }

        return denied;
    }
    
    /**
     * Remember last access test result
     * @param ipAddr
     * @param hostName
     * @param allowed
     */
    private synchronized void saveHostAccess(String ipAddr, String hostName, boolean allowed) {
        if (allowed) {
            allowedHosts.put(ipAddr, hostName);
            logger.info("Access allowed for host '{}' (addr '{}')", hostName, ipAddr);
        } else {
            deniedHosts.put(ipAddr, hostName);
            logger.warn("Access denied for host '{}' (addr '{}')", hostName, ipAddr);
        }
    }

    public final boolean isAuthorized(String hostName, String ipAddr) {
        boolean authorised = false;
        
        if (allowList.size() == 0 && denyList.size() == 0) {
            logger.debug("No allow/deny list configured - allow access for host '{}' (addr '{}')", hostName, ipAddr);
            return true;
        }

        if (allowedHosts.containsKey(ipAddr)) {
            // Already been checked
            logger.debug("{} found in allowed hosts map", ipAddr);
            authorised = true;
        } else if (deniedHosts.containsKey(ipAddr)) {
            // Already been checked
            logger.warn("{} found in denied hosts map", ipAddr);
            authorised = false;
        } else {
            authorised = isAllowed(ipAddr, hostName) && !isDenied(ipAddr, hostName);
            
            saveHostAccess(ipAddr, hostName, authorised);
        }
        
        return authorised;
    }
}
