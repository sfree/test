package com.ubs.idp.base;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Used to identify boundaries that should be logged and measured with metrics.
 * Typical candidates for this are callouts/API's to DB's and other systems.
 * 
 * For example,
 * @IdpBoundary
 * @Service
 * @Transactional
 * public class Neo4jMetadataServiceImpl implements MetadataService {
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.TYPE })
public @interface IdpBoundary { 
    
    /**
     * Explicitly specify the name of the boundary.
     * @return the specified boundary name, if any
     */
    String value() default "";
}