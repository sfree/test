package com.ubs.idp.encrypt.cmd;

import com.ubs.idp.encrypt.Crypto;

/**
 * Simple command line interface to password encrypt/decrypt
 * @author mcminnp
 */
public class CryptoCli {

    private static final String ENCRYPT = "encrypt";
    private static final String DECRYPT = "decrypt";

    /**
     * @param args
     */
    public static void main(String[] args) {
        // KISS!
        if (args.length != 2) {
            usage();
        }
        
        String cmd = args[0];
        String valueIn = args[1];
        
        if (cmd.equalsIgnoreCase(ENCRYPT)) {
            System.out.println(Crypto.encrypt(valueIn));
        } else if (cmd.equalsIgnoreCase(DECRYPT)) {
            System.out.println(Crypto.decrypt(valueIn));
        } else {
            usage();
        } 
    }

    /**
     * Display usage and exit!
     */
    public static void usage() {
        System.err.println("Syntax:");
        System.err.println("java " + CryptoCli.class.getName() + "<" + ENCRYPT + "|" + DECRYPT + "> <string>");
        System.exit(1);
    }
}
