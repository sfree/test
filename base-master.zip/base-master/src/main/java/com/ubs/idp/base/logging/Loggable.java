package com.ubs.idp.base.logging;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Used to identify parameters that should be logged in the request object.
 * Typical candidates for logging should be parameters which identify the record/account that is being requested.
 * 
 * For example,
 * @Loggable
 * private String accountNumber;
 * 
 * This will cause the service log message to contain '[accountNumber="123456789"]'.
 * Multiple instance variables can be annotated with @Loggable and the will be separated in the log message using ','.
 * 
 * <b>Note.</b> It is at the discretion of the application developer to decide whether or not PCI compliance rules 
 * will be broken by applying to certain instance variables.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.PARAMETER, ElementType.FIELD, ElementType.METHOD })
public @interface Loggable { 
    
    /**
     * Explicitly specify the name of the loggable parameter.
     * @return the specified parameter name, if any
     */
    String value() default "";
}