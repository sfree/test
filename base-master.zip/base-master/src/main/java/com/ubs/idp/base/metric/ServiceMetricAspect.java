package com.ubs.idp.base.metric;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/**
 * Metric Aspect for Service components.
 */
@Aspect
public final class ServiceMetricAspect extends AbstractMetricAspect {

    public static final String COMPONENT_TYPE = "service";

    @Pointcut("execution(public * *(..))")
    public void isPublicMethod() {

        /* no implementation needed. */
    }

    @Pointcut("within(@org.springframework.stereotype.Controller *)")
    public void isController() {

        /* no implementation needed. */
    }

    @Pointcut("within(com.ubs.idp..*)")
    public void isIdp() {

        /* no implementation needed. */
    }

    @Pointcut("isIdp() && isController() && isPublicMethod()")
    public void isIdpControllerMethod() {

        /* no implementation needed. */
    }

    /**
     * @param wraps the AbstractMetricAspect#logDuration and provides an Around annotation.
     * @return result of proceed
     * @throws Throwable
     */
    @Around("isIdpControllerMethod()")
    @Override
    public Object logDuration(ProceedingJoinPoint joinPoint) throws Throwable {

        return super.logDuration(joinPoint);
    }

    @Override
    public String getComponentType() {

        return COMPONENT_TYPE;
    }
}
