package com.ubs.idp.base.logging;

import static com.ubs.idp.base.logging.ServiceMessageFactory.LOG_AFTER;
import static com.ubs.idp.base.logging.ServiceMessageFactory.LOG_BEFORE;
import static com.ubs.idp.base.logging.ServiceMessageFactory.LOG_EXCEPTION;
import static com.ubs.idp.base.logging.ServiceMessageFactory.createMessage;

import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.ubs.idp.base.logging.AbstractLoggingAspect;

/**
 * Logging Aspect for Service components.
 */
@Aspect
@Order(Ordered.HIGHEST_PRECEDENCE)
@Component
public class ServiceLoggingAspect extends AbstractLoggingAspect{

    @Pointcut("execution(public * *(..))")
    public void isPublicMethod() {

        /* no implementation needed. */
    }

    @Pointcut("within(@org.springframework.stereotype.Controller *)")
    public void isController() {

        /* no implementation needed. */
    }

    @Pointcut("within(com.ubs.idp..*)")
    public void isIdp() {

        /* no implementation needed. */
    }

    @Pointcut("isIdp() && isController() && isPublicMethod()")
    public void isIdpControllerMethod() {

        /* no implementation needed. */
    }

    /**
     * @param methodCall the call
     * @return result of proceed
     * @throws Throwable -
     */
    @Around("isIdpControllerMethod()")
    public Object logDuration(ProceedingJoinPoint methodCall) throws Throwable {

        return super.logDuration(methodCall);
    }
    
    protected String createMessageLogAfter(Signature signature, List<Object> params, long elapsed) {
        return createMessage(LOG_AFTER, signature.getDeclaringType().getSimpleName(), signature.getName(), params, elapsed);
    }
    
    protected String createMessageLogException(Signature signature, long elapsed, String exceptionMessage) {
        return createMessage(
                 LOG_EXCEPTION,
                 signature.getDeclaringType().getSimpleName(),
                 signature.getName(),
                 elapsed,
                 exceptionMessage);
    }
    
    protected String createMessageLogBefore(MethodSignature methodSignature, List<Object> params) {

        return createMessage(LOG_BEFORE, methodSignature.getDeclaringType().getSimpleName(), methodSignature
            .getName(), params);
    }
}
