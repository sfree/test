package com.ubs.idp.base;

// TODO: Move to metadata service?
public interface StaticValues {

    // Cassandra constants for processing empty values
    public static final String BLANK = "";
    public static final String SPACE = " ";
    public static final String BLANK_KEY = "BLANK";
    
	public static final String MAPPING_TABLE_NAME = "tableName";
	public static final String KEY_NAME_STRING = "keyName";
	public static final String KEY_VALUE_STRING = "keyValue";
	public static final String DATASET_IDENTIFIER = "datasetIdentifier";
	public static final String MAPPING_KEY = "mapping.key";
}
