package com.ubs.idp.base.logging;

import static com.ubs.idp.base.logging.JobMessageFactory.LOG_AFTER;
import static com.ubs.idp.base.logging.JobMessageFactory.LOG_BEFORE;
import static com.ubs.idp.base.logging.JobMessageFactory.LOG_EXCEPTION;
import static com.ubs.idp.base.logging.JobMessageFactory.createMessage;

import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.ubs.idp.base.logging.AbstractLoggingAspect;

/**
 * Logging Aspect for Job components.
 */
@Aspect
@Order(Ordered.HIGHEST_PRECEDENCE)
@Component
public class JobLoggingAspect extends AbstractLoggingAspect{

    @Pointcut("execution(public * *(..))")
    public void isPublicMethod() {

        /* no implementation needed. */
    }

    @Pointcut("execution(* org.springframework.batch.core.JobExecutionListener+.*(..))")
    public void isJobExecutionListener() {

        /* no implementation needed. */
    }

    @Pointcut("within(com.ubs.idp..*)")
    public void isIdp() {

        /* no implementation needed. */
    }

    @Pointcut("isIdp() && isJobExecutionListener() && isPublicMethod()")
    public void isIdpJobMethod() {

        /* no implementation needed. */
    }

    /**
     * @param methodCall the call
     * @return result of proceed
     * @throws Throwable -
     */
    @Around("isIdpJobMethod()")
    public Object logDuration(ProceedingJoinPoint methodCall) throws Throwable {

        return super.logDuration(methodCall);
    }
    
    protected String createMessageLogAfter(Signature signature, List<Object> params, long elapsed) {
        return createMessage(LOG_AFTER, signature.getDeclaringType().getSimpleName(), signature.getName(), params, elapsed);
    }
    
    protected String createMessageLogException(Signature signature, long elapsed, String exceptionMessage) {
        return createMessage(
                 LOG_EXCEPTION,
                 signature.getDeclaringType().getSimpleName(),
                 signature.getName(),
                 elapsed,
                 exceptionMessage);
    }
    
    protected String createMessageLogBefore(MethodSignature methodSignature, List<Object> params) {

        return createMessage(LOG_BEFORE, methodSignature.getDeclaringType().getSimpleName(), methodSignature
            .getName(), params);
    }
}
