package com.ubs.idp.encrypt;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public final class Crypto {

	private static final String ENCRYPT_ALGORITHM = "AES";
	private static final String HEX_PRIVATE_KEY = "d69403e2673e611d4cbd3fad6fd1788e";

	private Crypto() {
	}

	public static String encrypt(String strToEncrypt) {

	    if (strToEncrypt == null) {
	        throw new IllegalArgumentException("String to encrypt must not be null!");
	    } else if (strToEncrypt.length() == 0) {
            throw new IllegalArgumentException("String to encrypt must not be empty!");
        }
	    
		byte[] raw = toBytes(HEX_PRIVATE_KEY);
		SecretKeySpec skeySpec = new SecretKeySpec(raw, ENCRYPT_ALGORITHM);
		// Instantiate the cipher
		byte[] encrypted;
		try {
			Cipher cipher = Cipher.getInstance(ENCRYPT_ALGORITHM);
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
			encrypted = cipher.doFinal(strToEncrypt.getBytes());
		} catch (Exception e) {
			throw new EncryptionException("problem occurred whilst trying to encrypt!", e);
		}
		return toHex(encrypted);
	}

	public static String decrypt(String strToDecrypt) {

        if (strToDecrypt == null) {
            throw new IllegalArgumentException("String to decrypt must not be null!");
        } else if (strToDecrypt.length() == 0) {
            throw new IllegalArgumentException("String to decrypt must not be empty!");
        }

		byte[] key = toBytes(HEX_PRIVATE_KEY);
		SecretKeySpec keySpec = new SecretKeySpec(key, ENCRYPT_ALGORITHM);
		byte[] fromHex;
		try {
			// Instantiate the cipher
			Cipher cipher = Cipher.getInstance(ENCRYPT_ALGORITHM);
			cipher.init(Cipher.DECRYPT_MODE, keySpec);
			fromHex = cipher.doFinal(toBytes(strToDecrypt));
		} catch (Exception e) {
			throw new EncryptionException("problem occurred whilst trying to decrypt!", e);
		}
		return new String(fromHex);
	}

	private static String toHex(byte buf[]) {
		StringBuffer strbuf = new StringBuffer(buf.length * 2);
		for (int i = 0; i < buf.length; i++) {
			if (((int) buf[i] & 0xff) < 0x10) {
				strbuf.append("0");
			}
			strbuf.append(Long.toString((int) buf[i] & 0xff, 16));
		}
		return strbuf.toString();
	}

	private static byte[] toBytes(String hex) {
		byte[] bts = new byte[hex.length() / 2];
		for (int i = 0; i < bts.length; i++) {
			bts[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2 * i + 2),
					16);
		}
		return bts;
	}
}
