package com.ubs.idp.base.logging;

import static java.lang.System.currentTimeMillis;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.reflect.MethodSignature;
import org.joda.time.LocalDateTime;
import org.joda.time.base.AbstractPartial;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractLoggingAspect {

    private static final String GETTER_METHOD = "get";
    private static final String PACKAGE_PREFIX = "com.ubs.idp";
    private static final DateTimeFormatter DATETIME_FORMAT = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss");

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    protected abstract String createMessageLogBefore(MethodSignature methodSignature, List<Object> params);
    protected abstract String createMessageLogAfter(Signature signature, List<Object> params, long elapsed);
    protected abstract String createMessageLogException(Signature signature, long elapsed, String exceptionMessage);

    protected Object logDuration(ProceedingJoinPoint methodCall) throws Throwable {

        long start = currentTimeMillis();
        try {
            logger.info(createPreMessage(methodCall));
            Object o = methodCall.proceed();
            logger.info(createPostMessage(methodCall, o, start));
            return o;
        } catch (Throwable t) {
            logger.info(createExceptionMessage(methodCall, start, t.getMessage()));
            throw t;
        }
    }

    protected String createPostMessage(ProceedingJoinPoint methodCall, Object retrurnObject, long start) {

        String rc = "";
        try {
            long elapsed = currentTimeMillis() - start;

            MethodSignature methodSignature = (MethodSignature) methodCall.getSignature();
            Method method = methodSignature.getMethod();
            Class<?> returnType = method.getReturnType();
            List<Object> params = new ArrayList<Object>();
            if (method != null && retrurnObject != null) {
                extractReturnValues(method, returnType, retrurnObject, params);
            }
            rc = createMessageLogAfter(methodSignature, params, elapsed);
        } catch (Throwable t) {
            logger.warn("Trapped exception. Trying to create PRE message.  Continuing...", t);
        }
        return rc;
    }

    protected Object quoteStringArg(Class<?> type, final Object argVal) {

        StringBuffer sb = new StringBuffer();
        if (type != null && type == String.class) {
            sb.append('"');
            sb.append(argVal);
            sb.append('"');
        } else {
            sb.append(argVal);
        }
        return sb.toString();
    }
    
    String createExceptionMessage(ProceedingJoinPoint methodCall, long start, String exceptionMessage) {

        Signature signature = methodCall.getSignature();
        long elapsed = currentTimeMillis() - start;
        return createMessageLogException(signature, elapsed, exceptionMessage);
    }

    String createPreMessage(ProceedingJoinPoint methodCall) {

        String rc = "";
        try {
            MethodSignature methodSignature = (MethodSignature) methodCall.getSignature();
            Method method = methodSignature.getMethod();
            Class<?>[] parmTypes = methodSignature.getParameterTypes();
            Object[] args = methodCall.getArgs();
            List<Object> params = new ArrayList<Object>();
            if (method != null) {
                extractParamValues(method, parmTypes, args, params);
            }
            rc = createMessageLogBefore(methodSignature, params);
        } catch (Throwable t) {
            logger.warn("Trapped exception. Trying to create PRE message.  Continuing...", t);
        }
        return rc;
    }

    void extractReturnValues(Method method, Class<?> returnType, Object retrurnObject, List<Object> params) {

        Annotation[] annotations = method.getAnnotations();
        for (int i = 0; i < annotations.length; i++) {
            if (isLoggable(annotations[i])) {
                if (((Class<?>) returnType).isEnum()) {
                    addReturnValue(returnType, params, annotations[i], i, retrurnObject);
                } else if (isUBSClass(returnType)) {
                    params.addAll(extractLoggableFromObject(retrurnObject));
                } else {
                    addReturnValue(returnType, params, annotations[i], i, retrurnObject);
                }
            }
        }
    }

    void extractParamValues(Method method, Class<?>[] parmTypes, Object[] args, List<Object> params) {

        Annotation[][] paramAnnotations = method.getParameterAnnotations();
        for (int i = 0; i < paramAnnotations.length; i++) {
            Object argVal = args[i];
            if (isLoggable(paramAnnotations[i])) {
                if (((Class<?>) parmTypes[i]).isEnum()) {
                    addParamValue(parmTypes, params, paramAnnotations, i, argVal);
                } else if (isUBSClass(parmTypes[i])) {
                    params.addAll(extractLoggableFromObject(argVal));
                } else {
                    addParamValue(parmTypes, params, paramAnnotations, i, argVal);
                }
            }
        }
    }

    void addParamValue(Class<?>[] parmTypes, List<Object> params, Annotation[][] paramAnnotations, int i, Object argVal) {

        String name = getLoggableName(paramAnnotations[i]);
        if (name.isEmpty()) {
            params.add(quoteStringArg(parmTypes[i], argVal));
        } else {
            params.add(name + '=' + quoteStringArg(parmTypes[i], argVal));
        }
    }

    void addReturnValue(Class<?> returnType, List<Object> params, Annotation paramAnnotation, int i, Object argVal) {

        String name = getLoggableName(paramAnnotation);
        if (name.isEmpty()) {
            params.add(quoteStringArg(returnType, argVal));
        } else {
            params.add(name + '=' + quoteStringArg(returnType, argVal));
        }
    }

    boolean isLoggable(Annotation[] annotations) {

        for (Annotation annotation : annotations) {
            return isLoggable(annotation);
        }
        return false;
    }

    boolean isLoggable(Annotation annotation) {

        if (annotation.annotationType() == Loggable.class) {
            return true;
        }
        return false;
    }

    String getLoggableName(Annotation[] annotations) {

        for (Annotation annotation : annotations) {
            return getLoggableName(annotation);
        }
        return "";
    }

    String getLoggableName(Annotation annotation) {

        if (annotation.annotationType() == Loggable.class) {
            Loggable loggableAnnotation = (Loggable) annotation;
            return loggableAnnotation.value();
        }
        return "";
    }

    boolean isUBSClass(Class<?> clazz) {

        if (clazz != null && clazz.getPackage() != null
                && clazz.getPackage().getName().startsWith(PACKAGE_PREFIX)) {
            return true;
        }
        return false;
    }

    List<Object> extractLoggableFromObject(Object argVal) {

        List<Object> params = new ArrayList<Object>();
        Class<?> clazz = argVal.getClass();
        Field[] fields = clazz.getDeclaredFields();
        for (int j = 0; j < fields.length; j++) {
            if (fields[j].getAnnotation(Loggable.class) != null) {
                Loggable loggable = fields[j].getAnnotation(Loggable.class);
                String nameOverride = loggable.value();
                extractLoggableFromField(argVal, params, clazz, fields[j], nameOverride);
            }
        }
        return params;
    }

    void extractLoggableFromField(Object argVal, List<Object> params, Class<?> clazz, Field field, String nameOverride) {

        String fieldName = field.getName();
        Class<?> fieldType = field.getType();
        Method[] methods = clazz.getMethods();
        for (int i = 0; i < methods.length; i++) {
            if (methods[i].getName() != null && methods[i].getName().startsWith(GETTER_METHOD)) {
                String methodName = methods[i].getName();
                if (methodName.regionMatches(true, GETTER_METHOD.length(), fieldName, 0, fieldName.length())) {
                    retrieveValueByObjectGetter(argVal, fieldName, fieldType, methods[i], nameOverride, params);
                    break;
                }
            }
        }
    }

    void retrieveValueByObjectGetter(Object argVal, String fieldName, Class<?> fieldType, Method method,
            String nameOverride, List<Object> params) {

        try {
            Object rcVal = method.invoke(argVal, (Object[]) null);
            if (rcVal != null && fieldType.isEnum()) {
                StringBuffer sb = new StringBuffer();
                if (nameOverride != null && !nameOverride.isEmpty()) {
                    sb.append(nameOverride);
                } else {
                    sb.append(fieldName);
                }
                sb.append('=');
                sb.append(rcVal.toString());
                params.add(sb.toString());
            } else if (rcVal != null && (rcVal instanceof Calendar)) {
                StringBuffer sb = new StringBuffer();
                if (nameOverride != null && !nameOverride.isEmpty()) {
                    sb.append(nameOverride);
                } else {
                    sb.append(fieldName);
                }
                sb.append('=');
                LocalDateTime dateTime = new LocalDateTime(((Calendar)rcVal).getTimeInMillis());
                sb.append(dateTime.toString(DATETIME_FORMAT));
                params.add(sb.toString());
            } else if (rcVal != null && (rcVal instanceof Date)) {
                StringBuffer sb = new StringBuffer();
                if (nameOverride != null && !nameOverride.isEmpty()) {
                    sb.append(nameOverride);
                } else {
                    sb.append(fieldName);
                }
                sb.append('=');
                LocalDateTime dateTime = new LocalDateTime(((Date)rcVal).getTime());
                sb.append(dateTime.toString(DATETIME_FORMAT));
                params.add(sb.toString());
            } else if (rcVal != null && (rcVal instanceof AbstractPartial)) {
                StringBuffer sb = new StringBuffer();
                if (nameOverride != null && !nameOverride.isEmpty()) {
                    sb.append(nameOverride);
                } else {
                    sb.append(fieldName);
                }
                sb.append('=');
                sb.append(((AbstractPartial)rcVal).toString(DATETIME_FORMAT));
                params.add(sb.toString());
            } else if (rcVal != null && isUBSClass(rcVal.getClass())) { // check UBS classes
                params.addAll(extractLoggableFromObject(rcVal));
            } else {
                StringBuffer sb = new StringBuffer();
                if (nameOverride != null && !nameOverride.isEmpty()) {
                    sb.append(nameOverride);
                } else {
                    sb.append(fieldName);
                }
                sb.append('=');
                sb.append(quoteStringArg(fieldType, rcVal));
                params.add(sb.toString());
            }
        } catch (Throwable t) {
            logger.warn("Trapped exception whilst getting value from request object.  Continuing...", t);
        }
    }
}
