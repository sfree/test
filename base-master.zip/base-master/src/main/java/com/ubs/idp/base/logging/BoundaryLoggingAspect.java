package com.ubs.idp.base.logging;

import static com.ubs.idp.base.logging.BoundaryMessageFactory.LOG_AFTER;
import static com.ubs.idp.base.logging.BoundaryMessageFactory.LOG_BEFORE;
import static com.ubs.idp.base.logging.BoundaryMessageFactory.LOG_EXCEPTION;
import static com.ubs.idp.base.logging.BoundaryMessageFactory.createMessage;

import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.ubs.idp.base.logging.AbstractLoggingAspect;

/**
 * Logging Aspect for Boundary components.
 */
@Aspect
@Order(Ordered.LOWEST_PRECEDENCE)
@Component
public class BoundaryLoggingAspect extends AbstractLoggingAspect{

    @Pointcut("execution(public * *(..))")
    public void isPublicMethod() {

        /* no implementation needed. */
    }

    @Pointcut("within(@com.ubs.idp.base.IdpBoundary *)")
    public void isBeanAnnotatedWithIdpBoundary() {

        /* no implementation needed. */
    }

    @Pointcut("isBeanAnnotatedWithIdpBoundary() && isPublicMethod()")
    public void isIdpBoundaryMethod() {

        /* no implementation needed. */
    }

    /**
     * @param methodCall the call
     * @return result of proceed
     * @throws Throwable -
     */
    @Around("isIdpBoundaryMethod()")
    public Object logDuration(ProceedingJoinPoint methodCall) throws Throwable {

        return super.logDuration(methodCall);
    }
    
    protected String createMessageLogAfter(Signature signature, List<Object> params, long elapsed) {
        return createMessage(LOG_AFTER, signature.getDeclaringType().getSimpleName(), signature.getName(), params, elapsed);
    }
    
    protected String createMessageLogException(Signature signature, long elapsed, String exceptionMessage) {
        return createMessage(
                 LOG_EXCEPTION,
                 signature.getDeclaringType().getSimpleName(),
                 signature.getName(),
                 elapsed,
                 exceptionMessage);
    }
    
    protected String createMessageLogBefore(MethodSignature methodSignature, List<Object> params) {

        return createMessage(LOG_BEFORE, methodSignature.getDeclaringType().getSimpleName(), methodSignature
            .getName(), params);
    }
}
