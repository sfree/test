package com.ubs.idp.base;

public interface IPayLoad {

}
