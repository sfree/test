package com.ubs.idp.base.logging;

import java.util.Locale;

import org.springframework.context.support.ResourceBundleMessageSource;

public final class BoundaryMessageFactory {

    public static final String LOG_AFTER = "log.after";
    public static final String LOG_BEFORE = "log.before";
    public static final String LOG_EXCEPTION = "log.exception";
    
    private static final String MESSAGES_FILE = "idp-boundary-messages";

    private static final ResourceBundleMessageSource MESSAGE_SOURCE;

    static {
        MESSAGE_SOURCE = new ResourceBundleMessageSource();
        MESSAGE_SOURCE.setBasename(MESSAGES_FILE);
    }

    private BoundaryMessageFactory() {
    }

    /**
     * Retrieves a message from a properties file and creates a final message using the given parameters.
     * @param code The code to identify the message in the properties file.
     * @param params The parameters to be used in creating the message. Optional parameter.
     * @return A fully formatted message.
     */
    public static String createMessage(String code, Object... params) {

        return MESSAGE_SOURCE.getMessage(code, params, Locale.UK);
    }
}
