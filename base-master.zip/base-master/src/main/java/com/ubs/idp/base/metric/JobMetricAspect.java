package com.ubs.idp.base.metric;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/**
 * Metric Aspect for Job components.
 */
@Aspect
public final class JobMetricAspect extends AbstractMetricAspect {

    public static final String COMPONENT_TYPE = "job";

    @Pointcut("execution(public * *(..))")
    public void isPublicMethod() {

        /* no implementation needed. */
    }

    @Pointcut("execution(* org.springframework.batch.core.JobExecutionListener+.*(..))")
    public void isJobExecutionListener() {

        /* no implementation needed. */
    }

    @Pointcut("within(com.ubs.idp..*)")
    public void isIdp() {

        /* no implementation needed. */
    }

    @Pointcut("isIdp() && isJobExecutionListener() && isPublicMethod()")
    public void isIdpJobMethod() {

        /* no implementation needed. */
    }

    /**
     * @param wraps the AbstractMetricAspect#logDuration and provides an Around annotation.
     * @return result of proceed
     * @throws Throwable
     */
    @Around("isIdpJobMethod()")
    @Override
    public Object logDuration(ProceedingJoinPoint joinPoint) throws Throwable {

        return super.logDuration(joinPoint);
    }

    @Override
    public String getComponentType() {

        return COMPONENT_TYPE;
    }
}
