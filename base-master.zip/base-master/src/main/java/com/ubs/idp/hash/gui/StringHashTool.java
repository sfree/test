package com.ubs.idp.hash.gui;

import java.awt.Dimension;
import java.awt.Toolkit;

public class StringHashTool {

	public static void main(String[] args) {

		HashFrame frame = new HashFrame();
		frame.pack();
		frame.setSize(new Dimension(270, 180));
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screenSize.width / 2) - (frame.getSize().width / 2);
		int y = (screenSize.height / 2) - (frame.getSize().height / 2);
		frame.setLocation(x, y);
		frame.setVisible(true);
	}
}
