package com.ubs.idp.base.utils;

import java.io.UnsupportedEncodingException;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import org.apache.commons.codec.binary.Base64;

public class EncodingUtils
{
	private static final String UTF8_ENCODING = "UTF-8";

	private static final String ENCODED_STRING_PREFIX = "cb64:";

	private static final int MAX_UNCOMPRESSED_BUFFER_SIZE = 16384;

	private EncodingUtils() {
	}

	/**
	 * This method allows to compress and base64 encode the given input string
	 * value.
	 * 
	 * @param value
	 *            - string value to be processed (URL safe)
	 * @return compressed and base64'ed (URL safe) value
	 * @throws UnsupportedEncodingException
	 */
	public static String compressAndEncode(final String value)
			throws UnsupportedEncodingException {
		String result = null;
		if ( value != null && value.trim().length() > 0 ) {
			byte[] input = value.getBytes(UTF8_ENCODING);
			byte[] compressedDataRaw = new byte[input.length];

			// compress the source string to compressedDataRaw buffer
			Deflater compresser = new Deflater();
			compresser.setInput(input);
			compresser.finish();

			int compressedDataLength = compresser.deflate(compressedDataRaw);

			// copy the exact compressed data to compressedData buffer
			byte[] compressedData = new byte[compressedDataLength];
			System.arraycopy(compressedDataRaw, 0, compressedData, 0,
					compressedDataLength);

			// base64 encode of the compressed data
			Base64 b64encoder = new Base64(-1, null, true);

			result = ENCODED_STRING_PREFIX
					+ b64encoder.encodeToString(compressedData);
		}

		return result;
	}

	public static boolean isCompressedAndEncoded(final String value) {
		if (value != null && value.trim().length() > 0
				&& value.startsWith(ENCODED_STRING_PREFIX)) {
			return true;
		}
		return false;
	}

	/**
	 * This method allows to uncompress and base64 decode the given input string
	 * value.
	 * 
	 * @param value
	 *            - string value to be processed (URL safe)
	 * @return decompressed and base64 encoded (URL safe) value
	 * @throws UnsupportedEncodingException
	 */
	public static String uncompressAndDecode(final String value)
			throws UnsupportedEncodingException, DataFormatException {
		String result = null;
		if (value != null && value.trim().length() > 0
				&& value.startsWith(ENCODED_STRING_PREFIX)) {
			String data = value.substring(ENCODED_STRING_PREFIX.length());
			Base64 b64decoder = new Base64();
			byte[] compressedData = b64decoder.decode(data);

			// Decompress the bytes
			Inflater decompressor = new Inflater();
			decompressor.setInput(compressedData);
			byte[] uncompressedData = new byte[MAX_UNCOMPRESSED_BUFFER_SIZE];
			int resultLength = decompressor.inflate(uncompressedData);
			decompressor.end();

			// Decode the bytes into a String
			result = new String(uncompressedData, 0, resultLength,
					UTF8_ENCODING);
		} else {
			result = value;
		}

		return result;
	}


}
