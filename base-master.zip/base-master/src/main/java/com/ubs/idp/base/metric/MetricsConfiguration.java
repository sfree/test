package com.ubs.idp.base.metric;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.codahale.metrics.MetricFilter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.graphite.Graphite;
import com.codahale.metrics.graphite.GraphiteReporter;

@EnableAspectJAutoProxy(proxyTargetClass=true)
@Configuration("metricsConfiguration")
public class MetricsConfiguration {

    private static final String PREFIX = "idp.";
    private final Logger logger = LoggerFactory.getLogger(MetricsConfiguration.class);

    @Value("${component.name:unknown}")
    private String componentName;

    @Value("${environment:local}")
    private String environment;

    @Value("${graphite.hostname:}")
    private String graphiteHostname;

    @Value("${graphite.port:0}")
    private String graphitePort;

    @Bean(name = "metricRegistry")
    public MetricRegistry getMetricsRegistry() {
        return new MetricRegistry();
    }

    @Bean(name = "graphiteReporter")
    public boolean metricsConfiguration() throws Exception {

        boolean rc = false;
        logger.info("MetricsConfiguration ====================================");
        logger.info("componentName = " + componentName);
        logger.info("environment = " + environment);
        logger.info("graphiteHostname = " + graphiteHostname);
        logger.info("graphitePort = " + graphitePort);

        if (hasValue(graphiteHostname) && hasValue(graphitePort)) {
            Integer port = Integer.valueOf(graphitePort);
            logger.info("port = " + port);
            if (port > 0) {
                logger.info("prefix = " + createPrefix());
                Graphite graphite = new Graphite(new InetSocketAddress(graphiteHostname, port));
                GraphiteReporter reporter = GraphiteReporter.forRegistry(getMetricsRegistry())
                        .prefixedWith(createPrefix()).convertRatesTo(TimeUnit.SECONDS)
                        .convertDurationsTo(TimeUnit.MILLISECONDS).filter(MetricFilter.ALL).build(graphite);
                reporter.start(1, TimeUnit.MINUTES);
                rc = true;
            }
        }
        return rc;
    }

    String createPrefix() {

        String hostname = "unknownHost";
        try {
            String tmp = InetAddress.getLocalHost().getHostName();
            hostname = getSimpleHostname(tmp);
        } catch (Throwable e) {
            // Use default value
        }
        StringBuilder sb = new StringBuilder(PREFIX);
        sb.append(environment);
        sb.append(".");
        sb.append(componentName);
        sb.append(".");
        sb.append(hostname);
        return sb.toString();
    }

    // Re-implement these standard utility methods to keep dependencies down
    private boolean hasValue(String param) {

        return param != null && param.trim().length() > 0;
    }

    private boolean hasValue(Integer param) {

        return param != null;
    }

    String getSimpleHostname(String hostname) {

        if (hostname == null || hostname.isEmpty()) {
            return null;
        }
        if (hostname.contains(".")) {
            return StringUtils.substringAfterLast(hostname, ".");
        } else {
            return hostname;
        }
    }
}
