package com.ubs.idp.base.metric;

import static org.apache.commons.lang.StringUtils.isNotBlank;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;

/**
 * The base metric aspect to be extended by the component metric aspects.
 * @see http://metrics.codahale.com/manual/core/
 */
@Component
public abstract class AbstractMetricAspect {

    @Autowired
    @Qualifier("metricRegistry")
    private MetricRegistry metricRegistry;
    
    /**
     * Should return a String value that represents the type of component
     * that the aspect is reporting on. e.g. repository, client, etc.
     * @return String component type.
     */
    public abstract String getComponentType();

    /**
     * The log duration implementation. Implementing classes should declare
     * an @Around aspect and then delegate to this method.
     * @param joinPoint the call
     * @return result of proceed
     * @throws Throwable -
     */
    public Object logDuration(ProceedingJoinPoint joinPoint) throws Throwable {

        Timer timer = metricRegistry.timer(createMetricName(joinPoint));
        final Timer.Context context = timer.time();
        try {
            return joinPoint.proceed();
        } finally {
            context.stop();
        }
    }

    final String createMetricName(final JoinPoint joinPoint) {

        Signature signature = joinPoint.getSignature();
        return MetricRegistry.name(getComponentType(), getComponentName(joinPoint), signature.getName());
    }

    private String getComponentName(JoinPoint joinPoint) {

        String componentName;
        Service serviceAnnotation = joinPoint.getTarget().getClass().getAnnotation(Service.class);
        Controller controllerAnnotation = joinPoint.getTarget().getClass().getAnnotation(Controller.class);
        if (serviceAnnotation != null && isNotBlank(serviceAnnotation.value())) {
            componentName = serviceAnnotation.value().replace(',', '_');
        } else if (controllerAnnotation != null && isNotBlank(controllerAnnotation.value())) {
            componentName = controllerAnnotation.value().replace(',', '_');
        } else {
            Signature signature = joinPoint.getSignature();
            componentName = signature.getDeclaringType().getSimpleName();
        }
        return componentName;
    }
}
