package com.ubs.idp.base.metric;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/**
 * Metric Aspect for Boundary components.
 */
@Aspect
public final class BoundaryMetricAspect extends AbstractMetricAspect {

    public static final String COMPONENT_TYPE = "boundary";

    @Pointcut("execution(public * *(..))")
    public void isPublicMethod() {

        /* no implementation needed. */
    }

    @Pointcut("within(@com.ubs.idp.base.IdpBoundary *)")
    public void isBeanAnnotatedWithIdpBoundary() {

        /* no implementation needed. */
    }

    @Pointcut("isBeanAnnotatedWithIdpBoundary() && isPublicMethod()")
    public void isIdpBoundaryMethod() {

        /* no implementation needed. */
    }

    /**
     * @param wraps the AbstractMetricAspect#logDuration and provides an Around annotation.
     * @return result of proceed
     * @throws Throwable
     */
    @Around("isIdpBoundaryMethod()")
    @Override
    public Object logDuration(ProceedingJoinPoint joinPoint) throws Throwable {

        return super.logDuration(joinPoint);
    }

    @Override
    public String getComponentType() {

        return COMPONENT_TYPE;
    }
}
