package com.ubs.idp.encrypt.gui;

import static com.ubs.idp.encrypt.Crypto.encrypt;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EtchedBorder;

public class EncryptFrame extends JFrame {
	private static final String ENCRYPT = "Encrypt";
	private static final long serialVersionUID = 3206093459760846163L;
	private JPanel jContentPane = null;
	private JPanel jPanel = null;
	private JLabel jLabel = null;
	JButton m_encryptButton = new JButton(ENCRYPT);
	JTextField m_encryptedString = null;
	JTextField m_inputString = null;
	Action m_encryptAction = null;

	public EncryptFrame() {
		super("String Encrypt Tool");
		super.setResizable(false);

		try {
			UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		} catch (Exception e) {
			System.out.println("Error setting look and feel:" + e.getMessage());
		}

		try {
			setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			setContentPane(getJContentPane());
			m_encryptButton.addActionListener(generateAction(null));
			m_encryptButton.setActionCommand(ENCRYPT);
			exitListen();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public Action generateAction(Icon icon) {
		if (m_encryptAction == null) {
			m_encryptAction = (new AbstractAction("Encrypt String", icon) {
				private static final long serialVersionUID = 3206093459760846163L;

				public void actionPerformed(ActionEvent e) {
					try {
						if (m_inputString != null
								&& m_inputString.getText() != null
								&& !m_inputString.getText().isEmpty()) {
							m_encryptedString.setText(encrypt(m_inputString.getText()));
						} else {
							m_encryptedString.setText("Please provide string to encrypt!");
						}
					} catch (Exception ex) {
						m_encryptedString.setText(ex.getMessage());
					}
				}
			});
		}
		return m_encryptAction;
	}

	public void exitListen() {
		final EncryptFrame frame = this;
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				frame.exitWin(0);
			}
		});
	}

	public void exitWin(int status) {
		int rc = JOptionPane.showConfirmDialog(this,
				"Are you sure that you want to exit?\n", "Exit confirmation",
				JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
		if (rc == JOptionPane.YES_OPTION) {
			this.dispose();
			System.exit(0);
		}
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.gridheight = 1;
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridwidth = 2;
			gridBagConstraints.insets = new Insets(10, 0, 5, 0);
			gridBagConstraints.weightx = 3.0;
			gridBagConstraints.gridy = 0;
			jContentPane = new JPanel();
			jContentPane.setBorder(BorderFactory
					.createEtchedBorder(EtchedBorder.LOWERED));
			jContentPane.setLayout(new GridBagLayout());
			jContentPane.add(getJPanel());
			jLabel = new JLabel();
			jLabel.setText("String Encryption");
			jContentPane.add(jLabel, gridBagConstraints);

			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.fill = GridBagConstraints.HORIZONTAL;
			gridBagConstraints1.gridx = 1;
			gridBagConstraints1.weighty = 1.0;
			gridBagConstraints1.weightx = 2.0;
			gridBagConstraints1.gridwidth = 2;
			gridBagConstraints1.ipadx = 10;
			gridBagConstraints1.insets = new Insets(5, 10, 5, 10);
			gridBagConstraints1.anchor = GridBagConstraints.CENTER;
			gridBagConstraints1.gridheight = 1;
			gridBagConstraints1.gridy = 1;
			jContentPane.add(getInputTextPane(), gridBagConstraints1);

			GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
			gridBagConstraints2.gridy = 2;
			gridBagConstraints2.fill = GridBagConstraints.NONE;
			gridBagConstraints2.ipadx = 0;
			gridBagConstraints2.insets = new Insets(5, 0, 5, 0);
			gridBagConstraints2.gridx = 1;
			jContentPane.add(m_encryptButton, gridBagConstraints2);

			GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
			gridBagConstraints3.fill = GridBagConstraints.HORIZONTAL;
			gridBagConstraints3.gridx = 1;
			gridBagConstraints3.weighty = 1.0;
			gridBagConstraints3.weightx = 2.0;
			gridBagConstraints3.gridwidth = 2;
			gridBagConstraints3.ipadx = 10;
			gridBagConstraints3.insets = new Insets(5, 10, 5, 10);
			gridBagConstraints3.anchor = GridBagConstraints.CENTER;
			gridBagConstraints3.gridheight = 1;
			gridBagConstraints3.gridy = 3;
			jContentPane.add(getResultPane(), gridBagConstraints3);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
			gridBagConstraints11.gridy = 5;
			gridBagConstraints11.gridx = 3;
			jPanel = new JPanel();
			jPanel.setLayout(new GridBagLayout());
		}
		return jPanel;
	}

	/**
	 * This method initializes jTextPane
	 * 
	 * @return javax.swing.JTextPane
	 */
	private JTextField getResultPane() {
		if (m_encryptedString == null) {
			m_encryptedString = new JTextField();
			m_encryptedString.setText("output");
			m_encryptedString.setEditable(false);
			m_encryptedString.setBorder(BorderFactory
					.createEtchedBorder(EtchedBorder.LOWERED));
		}
		return m_encryptedString;
	}

	private JTextField getInputTextPane() {
		if (m_inputString == null) {
			m_inputString = new JTextField();
			m_inputString.setText("string to encrypt");
			m_inputString.setEditable(true);
			m_inputString.setBorder(BorderFactory
					.createEtchedBorder(EtchedBorder.LOWERED));
		}
		return m_inputString;
	}
}
