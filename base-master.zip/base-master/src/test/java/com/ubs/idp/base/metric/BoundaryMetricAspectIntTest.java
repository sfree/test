package com.ubs.idp.base.metric;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.slf4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.codahale.metrics.ConsoleReporter;
import com.ubs.idp.base.test.TestWithSomeLoggableParmsBoundary;

@RunWith(SpringJUnit4ClassRunner.class)
@PrepareForTest( { BoundaryMetricAspect.class, Logger.class })
@ContextConfiguration(locations = { "classpath:test-applicationContext.xml" })
public class BoundaryMetricAspectIntTest implements ApplicationContextAware {

    @Autowired
    private ApplicationContext context;

    @Autowired
    private TestWithSomeLoggableParmsBoundary boundarySomeLoggable;

    @Test
    @Ignore
    // need to fix this when have time
    public void metricTest() {

//        int noTimesToCallMethod = 5;
//
//        assertNotNull("context should not be null!", context);
//        BoundaryMetricAspect metricAspect = context.getBean(BoundaryMetricAspect.class);
//        assertNotNull("aspect should not be null!", metricAspect);
//        // Set up a ByteArrayOutputStream to write the reporter contents to.  
//        ByteArrayOutputStream baos = new ByteArrayOutputStream();
//        PrintStream ps = new PrintStream(baos, true);
//        ConsoleReporter reporter = new ConsoleReporter(ps);
//        MetricName metricName = new MetricName("boundary.TestWithSomeLoggableParmsBoundary",
//                "exampleQueryWithParametersAndPause", "requests");
//        
//        String key = "boundary.TestWithSomeLoggableParmsBoundary.exampleQueryWithParametersAndPause";
//
//        for (int i = 0; i < noTimesToCallMethod; i++) {
//            assertNotNull("TestWithSomeLoggableParmsBoundary should not be null!", boundarySomeLoggable);
//            boundarySomeLoggable.exampleQueryWithParametersAndPause(102345, "this string should NOT be visible",
//                    "you should SEE THIS string - it is @Loggable", 123456789L);
//        }
//        //        int sleepTimer = 1000;
//        //        try {
//        //            Thread.sleep(sleepTimer);
//        //        } catch (InterruptedException t) {
//        //            t.printStackTrace();
//        //        }
//        // Get the Timer from the Aspect.  This would normally be done using metrics reporters.
//        Timer timer = metricAspect.getTimer(key);
//        assertNotNull("timer should not be null!", timer);
//        reporter.processTimer(metricName, timer, ps);
//        assertNotNull("In memory byte stream should have been written to by the reporter!", baos);
//        assertTrue("timer does not have expected count value", baos.toString().contains(
//                "count = " + noTimesToCallMethod));
//        System.out.println("Byte array contents: " + baos.toString());
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

        this.context = applicationContext;
    }
}
