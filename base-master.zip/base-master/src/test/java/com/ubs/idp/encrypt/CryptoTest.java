package com.ubs.idp.encrypt;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class CryptoTest {

	@Rule
	public ExpectedException thrown = ExpectedException.none();
	
    @Test
    public void cryptoTest() throws Exception {

    	verifyEncryptDecrypt("secret");
    	verifyEncryptDecrypt("steve");
    	verifyEncryptDecrypt("Password");
    	verifyEncryptDecrypt("IDP");
    	verifyEncryptDecrypt("idp");
    }

	private void verifyEncryptDecrypt(String testString)
			throws NoSuchPaddingException, NoSuchAlgorithmException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
		String encryptedString = Crypto.encrypt(testString);
    	assertNotEquals("encrypted string should not be equal to the plain text", testString, encryptedString);
    	String plainText = Crypto.decrypt(encryptedString);
    	assertEquals("decrypted string should be equal to the plain text", testString, plainText);
	}
	
	@Test
    public void decryptEmptyStringTest() throws Exception {

		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("String to decrypt must not be empty!");
		Crypto.decrypt("");
    }
	
	@Test
    public void encryptEmptyStringTest() throws Exception {

		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("String to encrypt must not be empty!");
		Crypto.encrypt("");
    }
	
	@Test
    public void decryptNullTest() throws Exception {

		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("String to decrypt must not be null!");
		Crypto.decrypt(null);
    }
	
	@Test
    public void encryptNullTest() throws Exception {

		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("String to encrypt must not be null!");
		Crypto.encrypt(null);
    }
}
