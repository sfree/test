package com.ubs.idp.base.test;

import org.springframework.stereotype.Component;

import com.ubs.idp.base.IdpBoundary;

@IdpBoundary
@Component("testWithNoLoggagleParmsBoundary")
public class TestWithNoLoggableParmsBoundary {

    public void exampleQuery() {
        
    }

    public void exampleQueryWithParameters(int id, String str) {

    }
}
