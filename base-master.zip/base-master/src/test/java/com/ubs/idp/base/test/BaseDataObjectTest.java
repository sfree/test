package com.ubs.idp.base.test;

import static org.junit.Assert.*;

import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.base.BaseDataObject;
import com.ubs.idp.base.DataObject;

public class BaseDataObjectTest {

	private DataObject first;
	private BaseDataObject second;

	private String key1 = "1234";
	private String dupeKey1 = "1234";
	private String key2 = "1235";

	private Map<String,Object> attrs1;
	private Map<String,Object> dupeAttrs1;
	private Map<String,Object> attrs2;

	private static final String NAME_KEY = "name";
	private static final String DESCRIPTION_KEY = "description";

	@Before
	public void setUp() throws Exception {
		first = new BaseDataObject();
		second = new BaseDataObject();

		attrs1 = new LinkedHashMap<String,Object>();
		attrs1.put(NAME_KEY, "US");
		attrs1.put(DESCRIPTION_KEY, "United States of America");

		dupeAttrs1 = new LinkedHashMap<String,Object>();
		dupeAttrs1.put(NAME_KEY, "US");
		dupeAttrs1.put(DESCRIPTION_KEY, "United States of America");

		attrs2 = new LinkedHashMap<String,Object>();
		attrs2.put(NAME_KEY, "US");
		attrs2.put(DESCRIPTION_KEY, "United States");

		first.addKey(NAME_KEY,key1);
		first.setAttributes(attrs1);

	}


	@Test
	public void testGetDeltasNullSecond() {

		second = null;

		try {
			first.getDeltas(second);
		}
		catch(IllegalArgumentException e) {
			assertEquals("You need to provide an object to compare with.", e.getMessage());
		}
		catch(Exception e) {
			fail("Shouldn't have thrown this exception");
		}
	}

	@Test
	public void testGetDeltasNullFirstKey() {

		second.addKey(NAME_KEY,dupeKey1);
		second.setAttributes(dupeAttrs1);
		first.addKey(null, null);

		try {
			first.getDeltas(second);
		}
		catch(IllegalStateException e) {
			assertEquals("You're comparing objects with different keys.", e.getMessage());
		}
		catch(Exception e) {
			fail("Shouldn't have thrown this exception");
		}
	}

	@Test
	public void testGetDeltasDifferentKeys() {
		second.addKey(NAME_KEY,key2);
		second.setAttributes(dupeAttrs1);

		try {
			first.getDeltas(second);
		}
		catch(IllegalStateException e) {
			assertEquals("You're comparing objects with different keys.", e.getMessage());
		}
		catch(Exception e) {
			fail("Shouldn't have thrown this exception");
		}
	}

	@Test
	public void testGetDeltasSameKeyDifferentAttribute() {
		second.addKey(NAME_KEY,dupeKey1);
		second.setAttributes(attrs2);

		try {
			Map<String,Object> deltas = first.getDeltas(second);
			assertTrue(deltas.size() == 1);
			assertTrue(deltas.containsKey(DESCRIPTION_KEY));
			assertEquals("United States", deltas.get(DESCRIPTION_KEY));
		}
		catch(Exception e) {
			fail("Shouldn't have thrown this exception");
		}
	}

	@Test
	public void testGetDeltasSameKeySameAttributes() {
		second.addKey(NAME_KEY,dupeKey1);
		second.setAttributes(dupeAttrs1);

		try {
			Map<String,Object> deltas = first.getDeltas(second);
			assertTrue(deltas.isEmpty());
		}
		catch(Exception e) {
			fail("Shouldn't have thrown this exception");
		}
	}




}
