package com.ubs.idp.base.test;

import org.springframework.stereotype.Component;

import com.ubs.idp.base.IdpBoundary;
import com.ubs.idp.base.logging.Loggable;

@IdpBoundary
@Component("testWithSomeLoggableParmsBoundary")
public class TestWithSomeLoggableParmsBoundary {

    public void exampleQueryWithParameters(@Loggable int id, String str1, @Loggable String str2, long aLong) {
    }

    public @Loggable String exampleQueryWithParametersAndPause(@Loggable int id, @Loggable String str1, String str2, long aLong) {

        //        int variableSleep = RandomUtils.nextInt(10);
        //        try {
        //            Thread.sleep(variableSleep);
        //        } catch (InterruptedException e) {
        //            e.printStackTrace();
        //        }
    	return "rc string";
    }
}
