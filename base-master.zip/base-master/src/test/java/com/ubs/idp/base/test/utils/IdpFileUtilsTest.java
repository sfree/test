package com.ubs.idp.base.test.utils;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.base.utils.IdpFileUtils;

public class IdpFileUtilsTest
{
	@Before
	public void cleanUp() {
		File level2TestFile = new File("target/level1/level2/test.txt");
		
		level2TestFile.delete();
		
		File targetDir = new File("target");
		
		File[] targetFiles = targetDir.listFiles();
		
		for (File file : targetFiles) {
			if (file.getName().endsWith(".zip") || file.getName().endsWith(".txt")) {
				file.delete();
			}
		}
	}
	
	@Test
	public void testMoveAndZip() throws IOException
	{
		File srcFile = new File("target/test.txt");
		File targetZipDir = new File("target");
		File targetZip = new File("target/test.txt.zip");
		
		// Create a dummy file
		FileUtils.writeStringToFile(srcFile,"Hello",Charset.defaultCharset());		
		
		// Move and zip
		IdpFileUtils.moveAndZip(targetZipDir, srcFile);
		
		assertTrue("Source file not moved",!srcFile.exists());
		assertTrue("Target zip not created",targetZip.exists());
	}

	@Test
	public void testRenameAndZip() throws IOException
	{
		String newFileName = "test-rename.txt";
		File srcFile = new File("target/test.txt");
		File targetZipDir = new File("target");
		File targetZip = new File("target/" + newFileName + ".zip");
		
		// Create a dummy file
		FileUtils.writeStringToFile(srcFile,"Hello",Charset.defaultCharset());		
		
		// Move and zip
		IdpFileUtils.renameAndZip(newFileName, targetZipDir, srcFile);
		
		assertTrue("Source file not moved",!srcFile.exists());
		assertTrue("Target zip not created",targetZip.exists());
	}

	@Test
	public void testZipAndRemove() throws IOException
	{
		File srcFile1 = new File("target/test1.txt");
		File srcFile2 = new File("target/test2.txt");
		File srcFile3 = new File("target/test3.txt");
		File[] filesToZip = new File[]{srcFile1,srcFile2,srcFile3};
		File targetZipDir = new File("target");
		File targetZip = new File("target/test.txt.zip");
		
		// Create dummy files
		FileUtils.writeStringToFile(srcFile1,"Hello",Charset.defaultCharset());		
		FileUtils.writeStringToFile(srcFile2,"My",Charset.defaultCharset());		
		FileUtils.writeStringToFile(srcFile3,"Friends",Charset.defaultCharset());		
		
		// Move and zip
		IdpFileUtils.zipAndRemove(targetZipDir, targetZip.getName(), filesToZip);
		
		assertTrue("Source file1 not moved",!srcFile1.exists());
		assertTrue("Source file2 not moved",!srcFile2.exists());
		assertTrue("Source file3 not moved",!srcFile3.exists());
		assertTrue("Target zip not created",targetZip.exists());
		
		try(ZipInputStream zis = new ZipInputStream(new FileInputStream(targetZip));)
		{			
			int count = 0;
			while(zis.getNextEntry() != null )count ++;
			assertEquals("Incorrect file count in zip",filesToZip.length,count);
		}
		
		// Now unzip
		File[] unzippedFiles = IdpFileUtils.unzipFile(targetZip, targetZipDir);
		assertEquals("Wrong number of unzipped files",3,unzippedFiles.length);
		assertEquals("Wrong file name","test1.txt",unzippedFiles[0].getName());
		assertEquals("Wrong file name","test2.txt",unzippedFiles[1].getName());
		assertEquals("Wrong file name","test3.txt",unzippedFiles[2].getName());
		
	}
	
	@Test
	public void testCreateFileAndDirIfNotExists() throws IOException
	{
		File testFile = new File("target/level1/level2/test.txt");
		if( !testFile.exists() )
		{
			assertNotNull( testFile.getParentFile() );
			testFile.getParentFile().mkdirs();
		}
		
		assertTrue(testFile.createNewFile());
		//testFile.mkdirs();
		assertTrue("File not created",testFile.exists());
	}
}
