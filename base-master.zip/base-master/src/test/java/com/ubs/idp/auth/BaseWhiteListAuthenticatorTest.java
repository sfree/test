package com.ubs.idp.auth;

import static org.junit.Assert.*;

import org.junit.Test;

public class BaseWhiteListAuthenticatorTest {

	@Test
	public void isAuthorizedTest() {
		AuthTestClass authTestClass = new AuthTestClass();
		
		boolean isAuthorised = authTestClass.isAuthorized("localhost", "127.0.0.1");
		
		assertTrue("Unexpected auth result?!", isAuthorised);
	}

	@Test
	public void isNotAuthorizedTest() {
		AuthTestClass authTestClass = new AuthTestClass();
		
		boolean isAuthorised = authTestClass.isAuthorized("anotherhost", "192.168.0.1");
		
		assertFalse("Unexpected auth result?!", isAuthorised);
	}

	/**
	 * Basic implementation for JUnit testing
	 */
	private class AuthTestClass extends BaseWhiteListAuthenticator {
		public AuthTestClass () {
			super();
		}
	}
}
