package com.ubs.idp.base.logging;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Method;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.test.util.ReflectionTestUtils;

import com.ubs.idp.base.test.TestWithNoLoggableParmsBoundary;
import com.ubs.idp.base.test.TestWithSomeLoggableParmsBoundary;

public class BoundaryLoggingAspectTest {

    private BoundaryLoggingAspect testee;

    @Mock
    private ProceedingJoinPoint joinPoint;

    @Mock
    private MethodSignature methodSignature;

    @Mock
    private Logger logger;

    private Method methodWithNoParmms = null;
    private Method methodWithLoggableParms = null;
    private Method methodWithSomeLoggableParms = null;

    @Before
    public final void setup() {

        try {
            methodWithNoParmms = TestWithNoLoggableParmsBoundary.class.getMethod("exampleQuery", (Class<?>[]) null);
            methodWithLoggableParms =
                    TestWithNoLoggableParmsBoundary.class.getMethod("exampleQueryWithParameters", int.class, 
                    		String.class);
            methodWithSomeLoggableParms =
                    TestWithSomeLoggableParmsBoundary.class.getMethod("exampleQueryWithParameters", int.class,
                            String.class, String.class, long.class);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        MockitoAnnotations.initMocks(this);
        
        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(methodSignature.getDeclaringType()).thenReturn(this.getClass());
        when(joinPoint.getTarget()).thenReturn(this.getClass());
        when(methodSignature.getName()).thenReturn("testMethod");
        testee = new BoundaryLoggingAspect();
        ReflectionTestUtils.setField(testee, "logger", logger);
    }

    @Test
    public void beforeNoArgs() throws Throwable {

        testee.isPublicMethod();
        testee.isBeanAnnotatedWithIdpBoundary();
        testee.isIdpBoundaryMethod();
        
        String expectedString = "---> TestWithNoLoggableParmsBoundary exampleQuery() query sent []";

        when(methodSignature.getMethod()).thenReturn(methodWithNoParmms);
        when(joinPoint.getArgs()).thenReturn(null);
        when(methodSignature.getDeclaringType()).thenReturn(TestWithNoLoggableParmsBoundary.class);
        when(methodSignature.getName()).thenReturn("exampleQuery()");
        testee.logDuration(joinPoint);
        verify(logger).info(expectedString);
    }

    @Test
    public void beforeSingleArg() throws Throwable {

        when(methodSignature.getParameterTypes()).thenReturn(new Class<?>[] { int.class, String.class });
        when(methodSignature.getMethod()).thenReturn(methodWithLoggableParms);
        when(methodSignature.getName()).thenReturn("exampleQueryWithParameters()");
        when(methodSignature.getDeclaringType()).thenReturn(TestWithNoLoggableParmsBoundary.class);
        when(joinPoint.getArgs()).thenReturn(new Object[] { 10, "some arg" });
        testee.logDuration(joinPoint);
        verify(logger).info("---> TestWithNoLoggableParmsBoundary exampleQueryWithParameters() query sent []");
        // verify(logger).info(LOG_AFTER, methodName, "");
    }

    @Test
    public void beforeMultiArgs() throws Throwable {

        when(methodSignature.getMethod()).thenReturn(methodWithSomeLoggableParms);

        Object arg1 = new Integer(1234);
        Object arg2 = new String("this will NOT be visible");
        Object arg3 = new String("this will be visible");
        Object arg4 = new Long(1234567890);
        when(methodSignature.getParameterTypes()).thenReturn(
                new Class<?>[] { int.class, String.class, String.class, long.class });
        when(methodSignature.getName()).thenReturn("exampleQueryWithParameters()");
        when(methodSignature.getDeclaringType()).thenReturn(TestWithSomeLoggableParmsBoundary.class);
        when(joinPoint.getArgs()).thenReturn(new Object[] { arg1, arg2, arg3, arg4 });
        testee.logDuration(joinPoint);
        verify(logger).info("---> TestWithSomeLoggableParmsBoundary exampleQueryWithParameters() query sent [1234, \"" + arg3 + "\"]");
        // verify(logger).info(LOG_AFTER, methodName, "");
    }
}
