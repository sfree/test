package com.ubs.idp.base.metric;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;

@RunWith(PowerMockRunner.class)
public class AbstractMetricAspectTest {

    private AbstractMetricAspect testee;

    @Mock
    ProceedingJoinPoint preJoinPoint;

    @Mock
    Signature signature;

    private static final String TEST_RESP = "testResp";
    private MetricRegistry metricRegistry;
    
    @Before
    public void setUp() throws Exception {

        initMocks(this);
        testee = new AbstractMetricsAspectImpl();
        
        metricRegistry = new MetricRegistry();
        ReflectionTestUtils.setField(testee, "metricRegistry", metricRegistry); 
        
        when(preJoinPoint.getSignature()).thenReturn(signature);
        when(signature.getDeclaringType()).thenReturn(this.getClass());
        when(preJoinPoint.getTarget()).thenReturn(this.getClass());
        when(signature.getName()).thenReturn("testMethod");
        try {
            when(preJoinPoint.proceed()).thenReturn(TEST_RESP);
        } catch (Throwable t) {
            t.printStackTrace();
            fail();
        }
    }

    @Test
    public void getTimerTest() {

        Timer timer = metricRegistry.timer(testee.createMetricName(preJoinPoint));
//        Timer timer = testee.getTimer(preJoinPoint);
        assertNotNull(timer);
        Timer.Context ctx = timer.time();
        assertNotNull(ctx);
//        timer = testee.getTimer(preJoinPoint);
        timer = metricRegistry.timer(testee.createMetricName(preJoinPoint));
        assertNotNull(timer);
        ctx.stop();
        System.out.println("*** Timer test took = " + timer.getCount() + "ms");
    }

    @Test
    public void logDurationTest() {

        Object object = null;
        try {
            object = testee.logDuration(preJoinPoint);
        } catch (Throwable t) {
            t.printStackTrace();
            fail();
        }
        assertNotNull(object);
        assertEquals(TEST_RESP, object);
    }

    /**
     * Need to create implementation for testing abstract class.
     */
    class AbstractMetricsAspectImpl extends AbstractMetricAspect {

        @Override
        public String getComponentType() {

            return "TestComponent";
        }
    }
}
