package com.ubs.idp.base.logging;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.base.test.TestWithNoLoggableParmsBoundary;
import com.ubs.idp.base.test.TestWithSomeLoggableParmsBoundary;

@RunWith(SpringJUnit4ClassRunner.class)
@PrepareForTest( { BoundaryLoggingAspect.class, Logger.class })
@ContextConfiguration(locations = { "classpath:test-applicationContext.xml" })
public class BoundaryLoggingAspectIntTest {

    @Autowired
    private TestWithNoLoggableParmsBoundary boundaryNoLoggable;

    @Autowired 
    private TestWithSomeLoggableParmsBoundary boundarySomeLoggable;

    @Test
    public void logTest() {

        assertNotNull("TestWithNoLoggableParmsBoundary should not be null!", boundaryNoLoggable);
        assertNotNull("TestWithSomeLoggableParmsBoundary should not be null!", boundarySomeLoggable);
        boundaryNoLoggable.exampleQuery();
        boundaryNoLoggable.exampleQueryWithParameters(10, "a string value");
        boundarySomeLoggable.exampleQueryWithParameters(102345, "this string is @Loggable", "you should NOT SEE THIS string - it is not @Loggable", 123456789L);
    }
}
