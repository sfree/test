package com.ubs.idp.base.test.utils;

import static org.junit.Assert.*;

import javax.xml.xpath.XPath;

import org.junit.Before;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.ubs.idp.base.utils.XMLUtils;

public class XMLUtilsTest {
	
	private boolean isVerbose = false;
	
	@Before
	public void setUp() {
		if (System.getProperty("verbose") != null) {
			isVerbose = true;
		}
	}

	@Test
	public void testXMLToDocument() {
		String inputXML = "<root/>";
		
		try {
			Document doc = XMLUtils.getXMLDocument(inputXML);
			
			assertNotNull("Null W3C document?", doc);
		} catch (Exception e) {
			fail("Unexpected excpetion: " + e.getMessage());
		}
	}

	@Test
	public void testXMLPrettyPrint() {
		String inputXML = "<root><data>123</data></root>";
		String lineSep = System.getProperty("line.separator");
		String expectedXML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" + lineSep +
							 "<root>" + lineSep +
							 "    <data>123</data>" + lineSep +
							 "</root>" + lineSep;
		
		String outputXML = XMLUtils.prettyPrint(inputXML);
		
		if (isVerbose) {
			System.out.println("Output XML:\n" + outputXML);
		}
		
		assertEquals("XML format error?", expectedXML, outputXML);
	}
	
	@Test
	public void testXMLFileLoad() {
		String pathName = "src/test/resources/simpleData.xml";
		String lineSep = System.getProperty("line.separator");
		String expectedXML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" + lineSep +
							 "<root>" + lineSep +
							 "<data>123</data>" + lineSep +
							 "</root>" + lineSep;
		
		try {
			String inputXML = XMLUtils.readXMLFile(pathName);
			
			assertNotNull("Null XML string?", inputXML);
			
			if (isVerbose) {
				System.out.println("Output XML:\n" + inputXML);
			}
			
			assertEquals("XML format error?", expectedXML, inputXML);
		} catch (Exception e) {
			fail("Unexpected excpetion: " + e.getMessage());
		}
	}

	@Test
	public void testXPathQuery() {
		String inputXML = "<root><data>123</data></root>";
		
		try {
			Document doc = XMLUtils.getXMLDocument(inputXML);
			
			assertNotNull("Null W3C document?", doc);
			
			NodeList res = XMLUtils.xpathQuery(doc, "/root/data/text()");
			
			assertEquals("Invalid node count?", 1, res.getLength());
		} catch (Exception e) {
			fail("Unexpected excpetion: " + e.getMessage());
		}
	}
	
	@Test
	public void testXPathInstance() {
		XPath xpath = XMLUtils.getXPathInstance();
		
		assertNotNull("Null XPath?", xpath);
	}
}
