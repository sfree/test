package com.ubs.idp.base.utils;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ByteUnitTest {

	@Test
	public void shouldReturnLongMaxValue() {
		assertEquals(Long.MAX_VALUE, ByteUnit.BYTES.convert(Long.MAX_VALUE, ByteUnit.KILOBYTES));
	}

	@Test
	public void shouldReturnLongMinValue() {
		assertEquals(Long.MIN_VALUE, ByteUnit.BYTES.convert(-Long.MIN_VALUE, ByteUnit.KILOBYTES));
	}

	@Test
	public void shouldGetByteUnit() {
		assertEquals(ByteUnit.BYTES, ByteUnit.getByteUnit("byte"));
		assertEquals(ByteUnit.KILOBYTES, ByteUnit.getByteUnit("KB"));
		assertEquals(ByteUnit.MEGABYTES, ByteUnit.getByteUnit("MB"));
		assertEquals(ByteUnit.GIGABYTES, ByteUnit.getByteUnit("GB"));
		assertEquals(ByteUnit.TERABYTES, ByteUnit.getByteUnit("terabyte"));
		assertEquals(ByteUnit.PETABYTES, ByteUnit.getByteUnit("PETABYTE"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowIllegalArgumentException() {
		ByteUnit.getByteUnit("hello world!");
	}

	@Test(expected = NullPointerException.class)
	public void shouldThrowNullPointerException() {
		ByteUnit.getByteUnit(null);
	}

	@Test
	public void shouldConveretKilobytesIntoBytes() {
		assertEquals(1000L, ByteUnit.BYTES.convert(1, ByteUnit.KILOBYTES));
	}

	@Test
	public void shouldConveretMegabytesIntoKilobytes() {
		assertEquals(1000L, ByteUnit.KILOBYTES.convert(1, ByteUnit.MEGABYTES));
	}

	@Test
	public void shouldConveretGigabytesIntoMegabytes() {
		assertEquals(1000L, ByteUnit.MEGABYTES.convert(1, ByteUnit.GIGABYTES));
	}

	@Test
	public void shouldConveretTerabytesIntoGigabytes() {
		assertEquals(1000L, ByteUnit.GIGABYTES.convert(1, ByteUnit.TERABYTES));
	}

	@Test
	public void shouldConveretPetabytesIntoTerabytes() {
		assertEquals(1000L, ByteUnit.TERABYTES.convert(1, ByteUnit.PETABYTES));
	}

	@Test
	public void shouldConveretPetabytesIntoPetabytes() {
		assertEquals(1000L, ByteUnit.PETABYTES.convert(1000, ByteUnit.PETABYTES));
	}

	@Test
	public void shouldReturnBytes() {
		assertEquals(1L, ByteUnit.BYTES.toBytes(1));
		assertEquals(1000L, ByteUnit.KILOBYTES.toBytes(1));
		assertEquals(1000000L, ByteUnit.MEGABYTES.toBytes(1));
		assertEquals(1000000000L, ByteUnit.GIGABYTES.toBytes(1));
		assertEquals(1000000000000L, ByteUnit.TERABYTES.toBytes(1));
		assertEquals(1000000000000000L, ByteUnit.PETABYTES.toBytes(1));
	}

	@Test
	public void shouldReturnKilobytes() {
		assertEquals(0L, ByteUnit.BYTES.toKilobytes(1));
		assertEquals(1L, ByteUnit.KILOBYTES.toKilobytes(1));
		assertEquals(1000L, ByteUnit.MEGABYTES.toKilobytes(1));
		assertEquals(1000000L, ByteUnit.GIGABYTES.toKilobytes(1));
		assertEquals(1000000000L, ByteUnit.TERABYTES.toKilobytes(1));
		assertEquals(1000000000000L, ByteUnit.PETABYTES.toKilobytes(1));
	}

	@Test
	public void shouldReturnMegabytes() {
		assertEquals(0L, ByteUnit.BYTES.toMegabytes(1));
		assertEquals(0L, ByteUnit.KILOBYTES.toMegabytes(1));
		assertEquals(1L, ByteUnit.MEGABYTES.toMegabytes(1));
		assertEquals(1000L, ByteUnit.GIGABYTES.toMegabytes(1));
		assertEquals(1000000L, ByteUnit.TERABYTES.toMegabytes(1));
		assertEquals(1000000000L, ByteUnit.PETABYTES.toMegabytes(1));
	}

	@Test
	public void shouldReturnGigabytes() {
		assertEquals(0L, ByteUnit.BYTES.toGigabytes(1));
		assertEquals(0L, ByteUnit.KILOBYTES.toGigabytes(1));
		assertEquals(0L, ByteUnit.MEGABYTES.toGigabytes(1));
		assertEquals(1L, ByteUnit.GIGABYTES.toGigabytes(1));
		assertEquals(1000L, ByteUnit.TERABYTES.toGigabytes(1));
		assertEquals(1000000L, ByteUnit.PETABYTES.toGigabytes(1));
	}

	@Test
	public void shouldReturnTerabytes() {
		assertEquals(0L, ByteUnit.BYTES.toTerabytes(1));
		assertEquals(0L, ByteUnit.KILOBYTES.toTerabytes(1));
		assertEquals(0L, ByteUnit.MEGABYTES.toTerabytes(1));
		assertEquals(0L, ByteUnit.GIGABYTES.toTerabytes(1));
		assertEquals(1L, ByteUnit.TERABYTES.toTerabytes(1));
		assertEquals(1000L, ByteUnit.PETABYTES.toTerabytes(1));
	}

	@Test
	public void shouldReturnPetabytes() {
		assertEquals(0L, ByteUnit.BYTES.toPetabytes(1));
		assertEquals(0L, ByteUnit.KILOBYTES.toPetabytes(1));
		assertEquals(0L, ByteUnit.MEGABYTES.toPetabytes(1));
		assertEquals(0L, ByteUnit.GIGABYTES.toPetabytes(1));
		assertEquals(0L, ByteUnit.TERABYTES.toPetabytes(1));
		assertEquals(1L, ByteUnit.PETABYTES.toPetabytes(1));
	}

}
