package com.ubs.idp.base.metric;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.codahale.metrics.MetricRegistry;

@RunWith(PowerMockRunner.class)
public class BoundaryMetricAspectTest {

    private BoundaryMetricAspect testee;

    @Mock
    ProceedingJoinPoint preJoinPoint;

    @Mock
    Signature signature;

    private static final String TEST_RESP = "testResp";
    private MetricRegistry metricRegistry;

    @Before
    public void setUp() throws Exception {

        initMocks(this);
        testee = new BoundaryMetricAspect();
        
        metricRegistry = new MetricRegistry();
        ReflectionTestUtils.setField(testee, "metricRegistry", metricRegistry); 
        
        when(preJoinPoint.getSignature()).thenReturn(signature);
        when(signature.getDeclaringType()).thenReturn(this.getClass());
        when(preJoinPoint.getTarget()).thenReturn(this.getClass());
        when(signature.getName()).thenReturn("testMethod");
        try {
            when(preJoinPoint.proceed()).thenReturn(TEST_RESP);
        } catch (Throwable t) {
            t.printStackTrace();
            fail();
        }
    }

    @Test
    public void getTimerTest() {

        String componentType = testee.getComponentType();
        assertEquals(BoundaryMetricAspect.COMPONENT_TYPE, componentType);
    }

    @Test
    public void logDurationTest() {

        Object object = null;
        try {
            testee.isBeanAnnotatedWithIdpBoundary();
            testee.isPublicMethod();
            testee.isIdpBoundaryMethod();
            object = testee.logDuration(preJoinPoint);
        } catch (Throwable t) {
            t.printStackTrace();
            fail();
        }
        assertNotNull(object);
        assertEquals(TEST_RESP, object);
    }
}
