package com.ubs.idp.hash.gui;

import static org.junit.Assert.assertEquals;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class HashFrameTest {

	@Rule
	public ExpectedException thrown = ExpectedException.none();
	
    @Test
    public void hashingTest() throws Exception {
    	HashFrame hashFrame = new HashFrame();
    	// http://md5.gromweb.com/
    	assertEquals("generated hash is not what was expected for \"secret\"", "5ebe2294ecd0e0f08eab7690d2a6ee69", hashFrame.generateHashedString("secret"));
    	assertEquals("generated hash is not what was expected for \"steve\"", "d69403e2673e611d4cbd3fad6fd1788e", hashFrame.generateHashedString("steve"));
    	assertEquals("generated hash is not what was expected for \"Password\"", "dc647eb65e6711e155375218212b3964", hashFrame.generateHashedString("Password"));
    	assertEquals("generated hash is not what was expected for \"IDP\"", "e7d6664d8b9329d6f3a6655ddf269648", hashFrame.generateHashedString("IDP"));
    	assertEquals("generated hash is not what was expected for \"idp\"", "5b41dd08733372bb8d68ab7fbe38b9ab", hashFrame.generateHashedString("idp"));
    }
    
    @Test
    public void cryptoEmptyStringTest() throws Exception {

    	thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("String to hash must not be empty!");
		
    	HashFrame hashFrame = new HashFrame();
    	hashFrame.generateHashedString("");

    }
	
	@Test
    public void cryptoNullTest() throws Exception {

		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("String to hash must not be null!");
		
		HashFrame hashFrame = new HashFrame();
		hashFrame.generateHashedString(null);
    }
}
