package com.ubs.idp.base.metric;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-applicationContext.xml" })
public class MetricsConfigurationWithPropertiesTest {

    @Autowired
    private MetricsConfiguration config;
    
    @Test
    public void shouldConfigForGraphiteWhenAllValuesProvided() throws Exception {
        
        assertTrue(config.createPrefix().startsWith("idp.zzz.example-service."));
    }
}
