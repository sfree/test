package com.ubs.idp.base.logging;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.reflect.MethodSignature;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.internal.matchers.Null;

public class TestLoggingAspect {

    private static final String RC = "OK";

    class ComplexTypesClass {

        @Loggable
        private Calendar calendar = Calendar.getInstance();

        @Loggable
        private Date date = new Date();

        @Loggable
        private LocalDateTime jodaDateTime = new LocalDateTime();

        public Calendar getCalendar() {

            return calendar;
        }

        public Date getDate() {

            return date;
        }

        public LocalDateTime getJodaDateTime() {

            return jodaDateTime;
        }
    }

    class TestClass extends AbstractLoggingAspect {

        @Loggable
        private String stringValue = "value";

        @Loggable("id")
        private int intValue = 123456789;

        @Override
        protected String createMessageLogAfter(Signature signature, List<Object> params, long elapsed) {

            StringBuffer sb = new StringBuffer();
            if (params != null) {
                for (int i = 0; i < params.size(); i++) {
                    sb.append(params.get(i));
                    if (i + 1 < params.size()) {
                        sb.append(", ");
                    }
                }
            }
            return sb.toString();
        }

        @Override
        protected String createMessageLogBefore(MethodSignature methodSignature, List<Object> params) {

            StringBuffer sb = new StringBuffer();
            if (params != null) {
                for (int i = 0; i < params.size(); i++) {
                    sb.append(params.get(i));
                    if (i + 1 < params.size()) {
                        sb.append(", ");
                    }
                }
            }
            return sb.toString();
        }

        @Override
        protected String createMessageLogException(Signature signature, long elapsed, String exceptionMessage) {

            return exceptionMessage;
        }

        public String getStringValue() {

            return stringValue;
        }

        public int getIntValue() {

            return intValue;
        }

        public @Loggable
        TestClass aBusinessMethodWithAliasAndReturn(@Loggable("aliasName") String id) {

            return this;
        }

        public String aBusinessMethodWithAlias(@Loggable("aliasName") String id) {

            return "OK";
        }

        public void aBusinessMethod(@Loggable String id) {

        }

        public void aBusinessMethodWithNoLoggable(String id, @Deprecated int accNo) {

        }

        public @Loggable
        ComplexTypesClass aBusinessMethodWithComplexParamAndReturn(@Loggable("aliasName") ComplexTypesClass id) {

            return new ComplexTypesClass();
        }
    }

    private TestClass testClass;

    @Mock
    private ProceedingJoinPoint proceedingJoinPointMock;
    @Mock
    private MethodSignature methodSignatureMock;

    @Before
    public void setup() {

        initMocks(this);
        testClass = new TestClass();
    }

    @Test
    public void testCreatePreMessageWithComplexLoggableParam() throws SecurityException, NoSuchMethodException {

        Method method = TestClass.class.getMethod("aBusinessMethodWithComplexParamAndReturn", ComplexTypesClass.class);
        Object[] args = new Object[1];
        args[0] = new ComplexTypesClass();
        when(proceedingJoinPointMock.getSignature()).thenReturn(methodSignatureMock);
        when(proceedingJoinPointMock.getArgs()).thenReturn(args);
        when(methodSignatureMock.getMethod()).thenReturn(method);
        when(methodSignatureMock.getParameterTypes()).thenReturn(method.getParameterTypes());

        String rc = testClass.createPreMessage(proceedingJoinPointMock);
        assertNotNull(rc);
        assertTrue(rc.contains("calendar"));
        assertTrue(rc.contains("date"));
        assertTrue(rc.contains("jodaDateTime"));
        System.out.println(rc);
    }

    @Test
    public void testCreatePostMessageWithComplexLoggableReturn() throws SecurityException, NoSuchMethodException {

        Method method = TestClass.class.getMethod("aBusinessMethodWithComplexParamAndReturn", ComplexTypesClass.class);
        Object[] args = new Object[1];
        args[0] = new ComplexTypesClass();
        when(proceedingJoinPointMock.getSignature()).thenReturn(methodSignatureMock);
        when(proceedingJoinPointMock.getArgs()).thenReturn(args);
        when(methodSignatureMock.getMethod()).thenReturn(method);
        when(methodSignatureMock.getParameterTypes()).thenReturn(method.getParameterTypes());

        ComplexTypesClass complex = new ComplexTypesClass();
        String rc = testClass.createPostMessage(proceedingJoinPointMock, complex, System.currentTimeMillis());
        assertNotNull(rc);
        assertTrue(rc.contains("calendar"));
        assertTrue(rc.contains("date"));
        assertTrue(rc.contains("jodaDateTime"));
        System.out.println(rc);
    }

    @Test
    public void testCreatePreMessage() throws SecurityException, NoSuchMethodException {

        Method method = TestClass.class.getMethod("aBusinessMethod", String.class);
        Object[] args = new Object[1];
        args[0] = "id string";
        when(proceedingJoinPointMock.getSignature()).thenReturn(methodSignatureMock);
        when(proceedingJoinPointMock.getArgs()).thenReturn(args);
        when(methodSignatureMock.getMethod()).thenReturn(method);
        when(methodSignatureMock.getParameterTypes()).thenReturn(method.getParameterTypes());

        String rc = testClass.createPreMessage(proceedingJoinPointMock);
        assertEquals('\"' + (String) args[0] + '\"', rc);
    }

    @Test
    public void testCreatePostMessageWithLoggableReturn() throws SecurityException, NoSuchMethodException {

        Method method = TestClass.class.getMethod("aBusinessMethodWithAliasAndReturn", String.class);
        Object[] args = new Object[1];
        args[0] = "id string";
        when(proceedingJoinPointMock.getSignature()).thenReturn(methodSignatureMock);
        when(proceedingJoinPointMock.getArgs()).thenReturn(args);
        when(methodSignatureMock.getMethod()).thenReturn(method);
        when(methodSignatureMock.getParameterTypes()).thenReturn(method.getParameterTypes());

        String rc = testClass.createPostMessage(proceedingJoinPointMock, testClass, System.currentTimeMillis());
        assertEquals("stringValue=\"value\", id=123456789", rc);
    }

    @Test
    public void testCreatePostMessageWithAVoidReturn() throws SecurityException, NoSuchMethodException {

        Method method = TestClass.class.getMethod("aBusinessMethod", String.class);
        Object[] args = new Object[1];
        args[0] = "id string";
        when(proceedingJoinPointMock.getSignature()).thenReturn(methodSignatureMock);
        when(proceedingJoinPointMock.getArgs()).thenReturn(args);
        when(methodSignatureMock.getMethod()).thenReturn(method);
        when(methodSignatureMock.getParameterTypes()).thenReturn(method.getParameterTypes());

        String rc = testClass.createPostMessage(proceedingJoinPointMock, testClass, System.currentTimeMillis());
        assertEquals("", rc);
    }

    @Test
    public void testCreateExceptionMessage() throws SecurityException, NoSuchMethodException {

        when(proceedingJoinPointMock.getSignature()).thenReturn(methodSignatureMock);

        String rc = testClass.createExceptionMessage(proceedingJoinPointMock, System.currentTimeMillis(), RC);
        assertEquals(RC, rc);
    }

    @Test
    public void testQuoteString() {

        int testInt = 1234567890;
        String testString = "a string value";

        Object rc = testClass.quoteStringArg(int.class, testInt);
        assertEquals(String.valueOf(testInt), rc);

        Object str = testClass.quoteStringArg(String.class, testString);
        assertEquals('\"' + testString + '\"', str);

        rc = testClass.quoteStringArg(null, testInt);
        assertEquals(String.valueOf(testInt), rc);
    }

    @Test
    public void testRetrieveValueByObjectGetterForInt() throws Exception {

        String fieldName = "intValue";
        Class<?> fieldType = int.class;
        String nameOverride = null;
        List<Object> params = new ArrayList<Object>();

        Method method = TestClass.class.getMethod("getIntValue");
        testClass.retrieveValueByObjectGetter(testClass, fieldName, fieldType, method, nameOverride, params);
        assertEquals(fieldName + '=' + testClass.getIntValue(), params.get(0));
    }

    @Test
    public void testRetrieveValueByObjectGetterForString() throws Exception {

        String fieldName = "stringValue";
        Class<?> fieldType = String.class;
        String nameOverride = "";
        List<Object> params = new ArrayList<Object>();

        Method method = TestClass.class.getMethod("getStringValue");
        testClass.retrieveValueByObjectGetter(testClass, fieldName, fieldType, method, nameOverride, params);
        assertEquals(fieldName + "=\"" + testClass.getStringValue() + '\"', params.get(0));
    }

    @Test
    public void testRetrieveValueByObjectGetterForStringOverrideFieldName() throws Exception {

        String fieldName = "stringValue";
        Class<?> fieldType = String.class;
        String nameOverride = "aliasName";
        List<Object> params = new ArrayList<Object>();

        Method method = TestClass.class.getMethod("getStringValue");
        testClass.retrieveValueByObjectGetter(testClass, fieldName, fieldType, method, nameOverride, params);
        assertEquals(nameOverride + "=\"" + testClass.getStringValue() + '\"', params.get(0));
    }

    @Test
    public void testExtractLoggableFromObject() {

        String fieldName = "stringValue";

        List<Object> rc = testClass.extractLoggableFromObject(testClass);
        assertNotNull(rc);
        assertSame(rc.size(), 2);

        Object o = rc.get(0);
        assertNotNull(o);
        assertEquals(fieldName + "=\"" + testClass.getStringValue() + '\"', o);
    }
    
    @Test 
    public void testIsMediaClanClass() {
        
        assertTrue(testClass.isUBSClass(this.getClass()));
        assertFalse(testClass.isUBSClass(String.class));
        assertFalse(testClass.isUBSClass(Null.class));
    }

    @Test
    public void testGetLoggableNameWithAlias() throws SecurityException, NoSuchMethodException {

        Method method = TestClass.class.getMethod("aBusinessMethodWithAlias", String.class);
        Annotation[][] paramAnnotations = method.getParameterAnnotations();

        String rc = testClass.getLoggableName(paramAnnotations[0]);
        assertNotNull(rc);
        assertEquals("aliasName", rc);
    }

    @Test
    public void testGetLoggableNameDefault() throws SecurityException, NoSuchMethodException {

        Method method = TestClass.class.getMethod("aBusinessMethod", String.class);
        Annotation[][] paramAnnotations = method.getParameterAnnotations();

        String rc = testClass.getLoggableName(paramAnnotations[0]);
        assertNotNull(rc);
        assertEquals("", rc);
    }

    @Test
    public void testGetLoggableNameWithNoLoggable() throws SecurityException, NoSuchMethodException {

        Method method = TestClass.class.getMethod("aBusinessMethodWithNoLoggable", String.class, int.class);
        Annotation[][] paramAnnotations = method.getParameterAnnotations();

        String rc = testClass.getLoggableName(paramAnnotations[0]);
        assertNotNull(rc);
        assertEquals("", rc);

        rc = testClass.getLoggableName(paramAnnotations[1]);
        assertNotNull(rc);
        assertEquals("", rc);
    }

    @Test
    public void testGetLoggableNameWithEmptyParams() throws SecurityException, NoSuchMethodException {

        Annotation[][] emptyParamAnnotations = new Annotation[1][0];

        String rc = testClass.getLoggableName(emptyParamAnnotations[0]);
        assertNotNull(rc);
        assertEquals("", rc);
    }

    @Test
    public void testPositiveIsLoggableWithAlias() throws SecurityException, NoSuchMethodException {

        Method method = TestClass.class.getMethod("aBusinessMethodWithAlias", String.class);
        Annotation[][] paramAnnotations = method.getParameterAnnotations();

        assertTrue(testClass.isLoggable(paramAnnotations[0]));
    }

    @Test
    public void testPositiveIsLoggableDefault() throws SecurityException, NoSuchMethodException {

        Method method = TestClass.class.getMethod("aBusinessMethod", String.class);
        Annotation[][] paramAnnotations = method.getParameterAnnotations();

        assertTrue(testClass.isLoggable(paramAnnotations[0]));
    }

    @Test
    public void testNegativeIsLoggable() throws SecurityException, NoSuchMethodException {

        Method method = TestClass.class.getMethod("aBusinessMethodWithNoLoggable", String.class, int.class);
        Annotation[][] paramAnnotations = method.getParameterAnnotations();

        assertFalse(testClass.isLoggable(paramAnnotations[0]));
        assertFalse(testClass.isLoggable(paramAnnotations[1]));
    }
}
