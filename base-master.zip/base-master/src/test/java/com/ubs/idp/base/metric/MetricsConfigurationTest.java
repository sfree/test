package com.ubs.idp.base.metric;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.MockitoAnnotations.initMocks;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
public class MetricsConfigurationTest {

    private MetricsConfiguration testee;

    @Before
    public void setUp() throws Exception {

        initMocks(this);
        testee = new MetricsConfiguration();
    }

    @Test
    public void getSimpleHostname() {

        String expectedResult = "myhostname";
        String hostname = "com.swissbank.ldn." + expectedResult;

        String rc = testee.getSimpleHostname(null);
        assertNull(rc);
        rc = testee.getSimpleHostname("");
        assertNull(rc);
        rc = testee.getSimpleHostname(hostname);
        assertEquals(expectedResult, rc);
        rc = testee.getSimpleHostname(expectedResult);
        assertEquals(expectedResult, rc);
    }
}
