base
====

Base classes/utilities for use in IDP components

