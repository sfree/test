parent
======

parent idp pom which contains common dependencies,plugins and repos

TeamCity 
https://cft-teamcity.ldn.swissbank.com/project.html?projectId=Distribution_Idp_Parent&tab=projectOverview
