swift-neo-scripts-parent
========================
Common parent project for Neo Scripts.  Looks after merging the swift-neo-base-scripts into the child script project
