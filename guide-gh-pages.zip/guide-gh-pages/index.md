---
title: UBS Deploy
layout: home
---

<div class="banner">
  <h1>
    Deploy with the click of a button using <em>UBS Deploy</em>
  </h1>
  <a class="btn btn-primary" href="{{ site.url }}/docs/intro">
    Read More
  </a>
</div>

<div class="tile3">
  <div>
    <h2>Modern user-experience</h2>
    <p>
      UBS Deploy is a modern, light-weight web application that is designed to be intuitive to use.
    </p>
  </div>
  <div>
    <h2>Compliant</h2>
    <p>
      UBS Deploy is compliant with UBS change management and segregation of duty policies, leaving you to focus on delivering software.
    </p>
  </div>
  <div>
    <h2>Deploy fast</h2>
    <p>
      UBS Deploy allows you to deploy your applications fast and in a repeatable way through all your environments.
    </p>
  </div>
</div>
