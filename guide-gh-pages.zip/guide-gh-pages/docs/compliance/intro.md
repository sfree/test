---
title: Compliance
layout: docs
---

UBS Deploy helps your team ensure that you meet a number of compliance points around release and change management.

The details of each of these controls and how UBS Deploy enforces their compliance is detailed on the subsequent pages.

The definition of the Change Management (CM) policies can be [found here](https://teams.cc.cnet.ubs.net/sites/ORF2%20-%20Group%20Technology/ICAP/Control%20Catalogue/Forms/AllItems.aspx?RootFolder=https%3a%2f%2fteams%2ecc%2ecnet%2eubs%2enet%2fsites%2fORF2%20-%20Group%20Technology%2fICAP%2fControl%20Catalogue%2fCurrent%20Control%20Catalogue).
