---
title: CM9
layout: docs
---

CM9 states that the version deployed to production must be identical to the version tested and signed off for release.

## Control

> "Version of the tested and approved code/services is checked against the version that is released to production to assure the two are identical. This is to ensure appropriate version control during change / release management."

> "Checks are performed to ensure that tested and approved code/services are the same as the version that is released to production. Any deviations are immediately corrected."

## Enforcement

TBC
