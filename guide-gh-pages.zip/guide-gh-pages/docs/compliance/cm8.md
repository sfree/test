---
title: CM8
layout: docs
---

CM8 states that approval must be obtained before deployment of software to production.

## Control

> "All Standard Changes must be fully approved before implementation to the production environment to ensure that all relevant parties agree to the change."

## Enforcement

UBS Deploy enforces that all changes must have a linked Release Now (RNOW) before they can be deployed to production.

To deploy to production the linked RNOW ticket must:

- be approved
- be within the change window
- link to the UBS Deploy release in the RNOW links section
