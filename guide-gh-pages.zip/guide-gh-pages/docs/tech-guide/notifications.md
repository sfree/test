---
title: Notifications
layout: docs
---

UBS Deploy supports event notifications through a variety of channels.

## Email Notifications

You can choose to **watch** a release, which will subscribe you to receive email updates.
You can opt to receive emails notifications of:
- Modifications to the release definition
- Deployments of the release to any environment

![How to watch a release]({{ site.url }}/assets/png/watch_release.png)

The creator of a release is automatically subscribed to receive email notifications.

## MindAlign Notifications

UBS Deploy supports MindAlign notifications of deployments.

This has to be manually configured, [please contact us]({{site.baseurl}}/docs/intro/contact.html) to have this configured for your organisation.

We will look to make this self-service in future.

## Web Hooks

Swift supports web hooks which are calls to a REST service when a deployment occurs.

The API is [described here](https://github.ldn.swissbank.com/UBSDeploy/docs/blob/master/api/webhook.md).

To register a web hook [please contact us]({{site.baseurl}}/docs/intro/contact.html)
