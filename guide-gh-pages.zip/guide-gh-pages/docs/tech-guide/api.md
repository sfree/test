---
title: API
layout: docs
---

UBS Deploy has a REST API that can be used for performing most actions that can be performed in the UBS Deploy user interface.

The API is often used as part of a continuous deployment process. For example in a build server to automatically deploy artifcts once they have been compiled and tested.

## Authorisation

To invoke a UBS Deploy REST API, you will need to pass a cookie named 'LWSTOKEN' with a sign-on token obtained from the <abbr title="Logon Web Service">LWS</abbr> logon service. [DS API User Guide (LWS) PDF](http://bw.docweb.ubs.com/doc/livelink/32538948/1.%20DS%20API%20User%20Guide.pdf.pdf?func=docfetcher.fetchdoc&nodeid=32538948).

## Technical accounts 

If you are calling the UBS Deploy APIs as part of an automated process it is recommened that you use a techincal account for authorisation.

Technical accounts can be requested in [ATTI](http://goto/ATTI). 

Details on how to raise an ATTI technical acount can be found [here](http://bw.docweb.ubs.com/doc/livelink/36972760/OID%20Service%20Account%20Creation%20Steps.pdf.pdf?func=docfetcher.fetchdoc&nodeid=36972760)

When raising the request, for technical accounts that connect with deploy.ubsdev.net and deploy.ubstest.net, please use MAN-UAT OID. For production please use PROD. 

Once you have an account, the account will need to be entitled to invoked the required APIs. Some read only APIs require no entitlements, however the account must still be authenticated. 

## Available APIs

All of the available APIs are [documented here](https://github.ldn.swissbank.com/UBSDeploy/docs/blob/master/README.md)

## Links

- [Reference Java implementation](https://github.ldn.swissbank.com/idp/swift-java-client)
