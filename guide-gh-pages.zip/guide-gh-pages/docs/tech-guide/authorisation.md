---
title: Authorisation
layout: docs
---

Entitlements (also known as access rights) for UBS Deploy are created and requested using the [Access Request Portal (ARP)](http://goto/arp). 

## Basic Entitlements 

All UBS Deploy users should have one and only one of the basic access rights corresponding to their role in their organisation. These entitle the user to perform deployments, start/stop processes, modify configuration, view/save properties and view logs of any software component in an environment associated with that role, unless the component or host has been restricted with an [additional entitlement](#additional-entitlements). 

For example there may be three roles in an organisation:  
- `UBSDeploy-OrgName-DEV` 
- `UBSDeploy-OrgName-QA`
- `UBSDeploy-OrgName-PROD`. 


*Segregation of Duties* requirements state that access to perform deployments in or make changes to non-production and production environments are mutually exclusive. If you accidentally obtain access to multiple roles, UBS Deploy will not allow you to operate on any environment. You will need to create a request in ARP which removes the additional role. 


## <a name="additional-entitlements">Additional Entitlements</a> 

Specific *components* or *hosts* in an environment can be restricted by additional entitlements. A user who does not have the necessary additional entitlement will not be able to perform operations on the specified components/hosts. 

An additional entitlement is represented as an ARP group with a name beginning with `UBSDeploy-`. The rest of the group name can be anything, but by convention should be of the form:  

```
UBSDeploy-<APPLICATION-NAME>-<ENVIRONMENT-GROUP>-<ENTITLEMENT-DESCRIPTION> 
```
For example: `UBSDeploy-NEO-DEV-CID` 

Each additional entitlement must have an associated admin group in ARP of the same name but suffixed with `-ADMIN`. For example: `UBSDeploy-NEO-DEV-CID-ADMIN` 

- *User membership* is managed through ARP 
- *Host/component membership* is managed through UBS Deploy, by members of the `<group-name>-ADMIN` group 


### Further Reference

- [ARP Help](https://intranet.ubs.net/en/corporate-center/group-chief-operating-officer/group-technology/security-it/access-request-portal-helppage.html)
- [Legacy Swift Entitlements Documenation](http://confluence.swissbank.com/display/neo/Swift+Entitlements)
- [Legacy Swift Security Technical Documentation](http://confluence.swissbank.com/display/neo/Swift+Security)
