---
title: Release Now
layout: docs
---

UBS Deploy integrates with [Release Now (RNOW)](http://goto/snow) to ensure all required approvals have been received before allowing any production deployment. 

## Production checks 

This rules will block production deployment:

- The RNOW change request must be APPROVED. If deployment without approval is required, the change request type should be Emergency or Break-Fix.

These rules will require explicit confirmation from the user for deployment to continue:

- The UBS Deploy release is not linked to a RNOW change request.
- The RNOW change request is not linked to the UBS Deploy release.
- The RNOW change request is emergency or break-fix and not approved.
- The RNOW change request is outside its implementation window. This allows for deployments with unexpected delays to be completed.
- RNOW is down. This ensures that if there is an RNOW outage / upgrade, this doesn't block all deployments through UBS Deploy.

The user will first receive a warning when attempting a production deployment. 
![RNOW warning]({{ site.url }}/assets/png/rnow_warning.png)

If the user attempts to complete the production deployment, confirmation will be required. 
![RNOW confirmation]({{ site.url }}/assets/png/rnow_confirmation.png)

All rules are validated for rollback in production environments, however if any rules fail, the rollback will still be allowed provided the deployer acknowledges the warning.  This allows for rollbacks after the RNOW change request has been marked as completed.

### Linking 

Developers link releases to RNOW change requests so that the production deployment checks can be performed. This can be done by clicking the 'Edit' button on the release screen.

Once linked to a change request, the UBS Deploy release definition screen provides convenient visibility of the change request status. 
![Release RNOW link]({{ site.url }}/assets/png/release_link_rnow.png)

### Further Reference

- [JIRA feature to allow rollbacks with Closed change request](https://flow-jira.ubs.net/browse/SWIFT-297)

