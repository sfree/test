---
title: Nexus
layout: docs
---

[Sonatype Nexus](http://www.sonatype.org/nexus/category/nexus-proclm/) is the artifact repository that UBS Deploy sources artifacts from. Sonatype Nexus enforces the immutability of artifact versions.

# Architecture

Nexus will be deployed globally to create a highly resilient and performant service.

Nexus is currently deployed in Hayes and Ironwood and rollout to the following global footprint is under way.

![Nexus Architecture Diagram]({{ site.url }}/assets/png/nexus_architecture.png)

Rollout to the Swiss Secure Zone and the Singapore Secure Zone will be done as a second phase.

# Workflow

When an artifact is uploaded to Nexus it will be automatically distributed to the regional Nexus proxies (read nodes). This will make deployment faster because UBS Deploy will download artifacts from the Nexus proxy nearest to your application server during deployment.

# Artifact Upload

Each team using UBS Deploy has a repository set up in Nexus. The repository will store artifacts (mostly binary files) that will subsequently be deployed by UBS Deploy.

It is recommended that artifacts are uploaded by a service account as part of an automated build process.

Artifact upload can be performed using any of the following methods:

- [Upload using the Maven deploy plugin](https://support.sonatype.com/entries/21283268-Configure-Maven-to-Deploy-to-Nexus)
- [Upload using the Nexus REST API](http://books.sonatype.com/nexus-book/reference/using-sect-uploading.html)
- [Manual upload in the Nexus interface](http://books.sonatype.com/nexus-book/reference/using-sect-uploading.html)

Upload as part of an automated build pipeline is recommended so the last option of manual upload is not recommended.

# Artifact Immutability

All release artifacts in Nexus are immutable, this means that once you have uploaded a given version you cannot re-upload that same version.

# UBS Deploy Integration

UBS Deploy follows the Nexus RSS feed to discover deployable artifacts. 
UBS Deploy queries Nexus rest APIs to discover available versions for those artifacts.

Each organisation on UBS Deploy needs to provide the following information

| Parameter | Description | Example |
| :-- | :-- | :-- |
| contentUrl | Endpoint used to download artifacts | http://cft-nexus.ldn.swissbank.com:8081<br>**/nexus/service/local/artifact/maven/content** |
| searchUrl | Rest endpoint used to determine available versions of an artifact | http://cft-nexus.ldn.swissbank.com:8081<br>**/nexus/service/local/lucene/search** |
| repository | The repository in Nexus that the organisations artifacts are uploaded to | g-ged-releases-and-snapshots |
| packaging | The packaging used for deployable artifacts. (Optional) | tar.gz |
| classifier | The classifier applied to deployable artifacts.  The packaging and classifier prevent UBS Deploy from displaying libraries which are not intended for deployment. (Optional) | dist |

And the following for artifacts to be detected in the RSS feed

| Parameter | Description | Example |
| :-- | :-- | :-- |
| pollerUrl | The Nexus RSS Feed | http://cft-nexus.ldn.swissbank.com:8081<br>**/nexus/service/local/feeds/recentlyDeployedArtifacts** |
| pollerUsername | The RSS feed requires a Nexus account to view | swift_app |
| pollerPassword | | <hidden> |
| pollerRepositories | The Nexus repositories the artifacts are uploaded to. | int-ged-releases, int-ged-snapshots |

Artifacts can be manually registered if the RSS feed is not configured or failed to detect an artifact.

```
https://deploy.ubs.net/api/lookup/register/<organisation>/<group>/<artifact>
```
 
Discontinued artifacts can be removed from the UBS Deploy search results by hitting the rest API with a DELETE request.

```
https://deploy.ubs.net/api/lookup/deregister/<organisation>/<group>/<artifact>
```
