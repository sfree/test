---
title: Environments
layout: docs
---

There are two public environments for UBS Deploy.

## Production

This is the live UBS Deploy environment where all deployments happen from. It is supported by the eSupport GPS team.

- URL: <https://deploy.ubs.net>
- Environment Support: [#eSupport](http://chatcentral.swissbank.com/website/do/launch?channelID=44456)
- WebSSO Environment: [Production](http://goto/arp)

## UAT

The UAT environment is where onboarding and migration of new applications happens, in addition to the final testing of upcoming releases of the UBS Deploy tool itself.

- URL: <https://deploy.ubstest.net>
- Environment Support: [#ubs-deploy](http://chatcentral.swissbank.com/website/do/launch?channelID=49587)
- WebSSO Environment: [MAN-UAT](https://arpmanuat.swissbank.com)
