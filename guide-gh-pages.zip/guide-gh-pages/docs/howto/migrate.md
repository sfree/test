---
title: Migrate an Application
layout: docs
---

Migration to UBS Deploy is happening in waves.

All applications in scope will be placed in a migration wave. If you would like to be part of an early wave please reach out to <DL-DTI-PMO@ubs.com> with details of your application.

The Migration Process
---------------------

We have a migration team to assist with migration of applications on to UBS Deploy.

The migration team will:

- Perform an assessment of your application to decide how to proceed with migration
- Work hand in hand with your development and GPS team to migrate on to the tool
- Identify any gaps in the UBS Deploy product to support your application and schedule feature development to close out these gaps
