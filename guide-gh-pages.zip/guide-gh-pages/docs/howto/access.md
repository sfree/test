---
title: Get Access
layout: docs
---

You can access UBS Deploy at this URL: **<https://deploy.ubs.net>**

## Account

To login you will need a production WebSSO account. This will give you a read-only view of UBS Deploy.

If you do not have a WebSSO account you can request one in [Service Now](https://snow.ubs.net/com.glideapp.servicecatalog_cat_item_view.do?sysparm_id=c32841c010111000dc0bb8a1e6e967f7)

If you need to set or reset your Web SSO password you can do so in the [Password Management Tool](http://goto/password)

## Browser

To access UBS Deploy you need one of the following browsers:

- Google Chrome - [Available by exception](https://connections.swissbank.com/groups/html-sdk/blog/2014/06/11/how-to-get-chrome-at-ubs-official-route)
- Internet Explorer 11 - [Available in pilot](https://connections.swissbank.com/groups/ie11-early-adopter-community/blog/2013/12/30/ie11-is-coming-for-early-adopters)

## Permissions

By default you will have a read-only view of UBS Deploy.

To use the tool for deployments you need to be granted a specific role within your organisation by [requesting access in ARP]({{site.baseurl}}/docs/tech-guide/authorisation.html).
