---
title: Onboard a New Application
layout: docs
---

All new applications within scope should use UBS Deploy from the start. 

Please reach out to <DL-DTI-PMO@ubs.com> with details of your application and we will schedule time in the next onboarding wave to get your team onboard.
