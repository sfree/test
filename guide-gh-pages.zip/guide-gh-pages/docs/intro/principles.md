---
title: Principles
layout: docs
---

UBS Deploy has the following guiding principles:

<span style="color:#e51e26; font-size: 16pt">_Transparent_</span>&nbsp;&nbsp;&nbsp;&nbsp; Deployment and changes happening in your environment should be transparent and visible.

<span style="color:#e51e26; font-size: 16pt">_Usable_</span>&nbsp;&nbsp;&nbsp;&nbsp; You should enjoy using UBS Deploy and find it easy to use.

<span style="color:#e51e26; font-size: 16pt">_Automate Everything_</span>&nbsp;&nbsp;&nbsp;&nbsp; Deployments should be fully automated with no manual steps.

<span style="color:#e51e26; font-size: 16pt">_Repeatable_</span>&nbsp;&nbsp;&nbsp;&nbsp; Deployments should be repeatable through all environments.

<span style="color:#e51e26; font-size: 16pt">_Self Service_</span>&nbsp;&nbsp;&nbsp;&nbsp; UBS Deploy should be self service.

<span style="color:#e51e26; font-size: 16pt">_Fast_</span>&nbsp;&nbsp;&nbsp;&nbsp; Most deployments should take under a minute.

