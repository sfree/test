---
title: About
layout: docs
---

UBS Deploy is the deployment tool of the future for UBS.

## Scope

All applications that are deployed to production in the Investment Bank or are deploy to IB production infrastructure (FRDS, O&CS, Global AM, IS, GPS) are in scope for UBS Deploy.

UBS developed application and third party applications are both in scope.

Deployed to Windows and Linux are both in scope, Solaris is not in scope.

## Timeline

Migration on to UBS Deploy will take place through to the end of 2017. By the end of the programme all applications within scope will need to be migrated on to UBS Deploy.
