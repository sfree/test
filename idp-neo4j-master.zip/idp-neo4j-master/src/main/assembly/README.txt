This distribution is a modification by the IDP team of Neo4J 2.1.0-M01

Contains
- Neo4J 2.1.0-M01 (http://www.neo4j.org/download_thanks?edition=community&release=2.1.0-M01&platform=unix)
