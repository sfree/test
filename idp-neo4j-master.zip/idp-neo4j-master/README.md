idp-neo4j
=========

Use the Maven assembly plugin in order to generate a tarball (distribution) containing the IDP Neo4J distribution 

    mvn assembly:assembly 
---
