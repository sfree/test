package com.ubs.idp.test.orchestrator;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-context2.xml", "classpath:FileReaderCassandraWriterJob.xml" })
public class EquityTLTest extends FileReaderCassandraWriterJobTest
{
    static {
        System.setProperty("environment", "equitytl");
    }
    
    @Test
    public void testHappyPath() throws Exception {
    	
    	filename = "EQUITYTL.txt";
    	compareFilename = "EQUITYTL_COMPARE.csv";
    	statementCompareFilename = "EQUITYTL_COMPARE_STATEMENTS.txt";
    	
    	jobLaunch();
    }
} 