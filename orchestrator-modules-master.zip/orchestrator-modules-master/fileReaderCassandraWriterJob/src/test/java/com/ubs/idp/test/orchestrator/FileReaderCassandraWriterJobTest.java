package com.ubs.idp.test.orchestrator;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

import junitx.framework.FileAssert;

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.neo4j.kernel.impl.util.FileUtils;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.metadata.client.Neo4jUtils;

@RunWith(SpringJUnit4ClassRunner.class)
public abstract class FileReaderCassandraWriterJobTest 
{
	public final static String TARGET_DIR = "target";
	public final static String DATA_FILES_DIR = "src/test/resources/dataFiles";
	public final static String COMPARE_FILES_DIR = "src/test/resources/compareFiles";
	public final static String CASSANDRA_OUTPUT_FILENAME = "CassandraRecords.txt";
	public final static String CASSANDRA_STATEMENTS_OUTPUT_FILENAME = "CassandraStatements.txt";
	
    @Autowired
    protected JobLauncherTestUtils jobLauncherTestUtils;
    
    @Autowired 
    protected CassandraAndMetadataStub stubInitialiser;
 
    @Value("${file.stageDir}")
    protected String stageDirPath;

    @Value("${file.archiveDir}")
    protected String archiveDirPath;

    @Value("${file.baseDir}")
    protected String baseDirPath;

    @Value("${file.errorDir}")
    protected String errorDirPath;
    
    @Autowired
    Neo4jUtils neo4jUtils;
    
    private File outputFile = new File(TARGET_DIR + File.separator + CASSANDRA_OUTPUT_FILENAME);
    private File statementOutputFile = new File(TARGET_DIR + File.separator + CASSANDRA_STATEMENTS_OUTPUT_FILENAME );
    
    protected String filename;
    
    protected String compareFilename;
    
    protected String statementCompareFilename;

    static {
        System.setProperty("xd.props.dir", "src/test/resources");
    }
    
    @Before
    public void initTests() throws FileNotFoundException
    {    	    	
    	// Set the output files    	
    	stubInitialiser.setOutputFile(outputFile);
    	stubInitialiser.setStatementOutputFile(statementOutputFile);
    	
    	// Initialise the directories
    	File stageDir = new File(stageDirPath);
    	if( !stageDir.exists() )
    	{
    		assertTrue("Failed to create stage directory", stageDir.mkdirs() );
    	}

    	File archiveDir = new File(archiveDirPath);
    	if( !archiveDir.exists() )
    	{
    		assertTrue("Failed to create archvie directory", archiveDir.mkdirs() );
    	}

    	File baseDir = new File(baseDirPath);
    	if( !baseDir.exists() )
    	{
    		assertTrue("Failed to create base directory", baseDir.mkdirs() );
    	}

    	File errorDir = new File(errorDirPath);
    	if( !errorDir.exists() )
    	{
    		assertTrue("Failed to create error directory", errorDir.mkdirs() );
    	}
    }
    
    @After
    public void cleanup()
    {
    	stubInitialiser.closeFiles();    	
    	neo4jUtils.shutdownDatabase();
    }
    
    public void jobLaunch() throws Exception 
    {   	
    	File compareFile = new File( COMPARE_FILES_DIR + File.separator + compareFilename);
    	File statementCompareFile = new File( COMPARE_FILES_DIR + File.separator + statementCompareFilename);
    	File srcFile = new File(DATA_FILES_DIR + File.separator + filename );
    	File targetFile = new File(baseDirPath + File.separator + filename );
    			
    	// Copy our test file to the drop dir
    	FileUtils.copyFile(srcFile, targetFile);
    	assertTrue( targetFile.exists() );
    	
        // testing a job
    	JobExecution jobExecution = jobLauncherTestUtils.launchJob(getJobParameters(targetFile));
        assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
        
        // Check we archived the file ok
        File archiveFile = new File(archiveDirPath + File.separator + filename + ".zip");
        assertTrue("Could not find " + archiveFile, archiveFile.exists());
        
        // Check the statement parameters that were executed
        FileAssert.assertEquals(compareFile, stubInitialiser.getOutputFile());
        FileAssert.assertEquals(statementCompareFile, stubInitialiser.getStatementOutputFile());  
        
    }
    
    /**
     * Set up job execution to emulate file poller stream
     * @return
     */
    protected JobParameters getJobParameters( File targetFile ) {

        String filename = targetFile.getAbsolutePath();

        JobParameter absoluteFilePath = new JobParameter(filename);

        Map<String, JobParameter>jobParameterMap = new HashMap<String, JobParameter>();

        jobParameterMap.put("absoluteFilePath", absoluteFilePath);

        JobParameters jobParameters = new JobParameters(jobParameterMap);

        return jobParameters;
    }
    
    

}