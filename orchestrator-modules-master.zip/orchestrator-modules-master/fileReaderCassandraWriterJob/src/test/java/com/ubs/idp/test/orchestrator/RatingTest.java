package com.ubs.idp.test.orchestrator;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-context3.xml", "classpath:FileReaderCassandraWriterJob.xml" })
public class RatingTest extends FileReaderCassandraWriterJobTest
{
    static {
        System.setProperty("environment", "rating");
    }
    
    @Test
    public void testHappyPath() throws Exception {
    	
    	filename = "RATING.txt";
    	compareFilename = "RATING_COMPARE.csv";
    	statementCompareFilename = "RATING_COMPARE_STATEMENTS.txt";
    	jobLaunch();
    }
    
    @Test
    public void testFileWithErrors() throws Exception {
    	filename = "RATING_WITH_ERRORS.txt";
    	compareFilename = "RATING_COMPARE.csv";
    	statementCompareFilename = "RATING_COMPARE_STATEMENTS.txt";
    	jobLaunch();

    }	

    @Test
    public void testWithLargeFile() throws Exception {
    	filename = "RATING_PLUS_100_RECORDS.txt";
    	compareFilename = "RATING_COMPARE_PLUS_100_RECORDS.csv";
    	statementCompareFilename = "RATING_COMPARE_PLUS_100_STATEMENTS.txt";
    	jobLaunch();

    }	
} 