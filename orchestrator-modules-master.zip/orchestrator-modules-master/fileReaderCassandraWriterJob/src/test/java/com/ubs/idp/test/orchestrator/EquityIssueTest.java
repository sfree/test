package com.ubs.idp.test.orchestrator;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration(locations = { "classpath:test-context1.xml", "classpath:FileReaderCassandraWriterJob.xml" })
public class EquityIssueTest extends FileReaderCassandraWriterJobTest
{
    static {
        System.setProperty("environment", "equityissue");
    }
    
    @Test
    public void testHappyPath() throws Exception {
    	
    	filename = "EQUITYISSUE.txt";
    	compareFilename = "EQUITYISSUE_COMPARE.csv";
    	statementCompareFilename = "EQUITYISSUE_COMPARE_STATEMENTS.txt";
    	jobLaunch();
    }
} 