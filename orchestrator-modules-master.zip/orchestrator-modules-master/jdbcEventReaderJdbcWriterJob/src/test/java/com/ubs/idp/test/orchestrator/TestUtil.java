package com.ubs.idp.test.orchestrator;

import org.springframework.jdbc.datasource.SimpleDriverDataSource;

public class TestUtil {

    private SimpleDriverDataSource dataSource ;

    public void setDataSource(SimpleDriverDataSource dataSource) {
        this.dataSource = dataSource;
    }
    public SimpleDriverDataSource getDataSource() {
        return dataSource;
    }
}
