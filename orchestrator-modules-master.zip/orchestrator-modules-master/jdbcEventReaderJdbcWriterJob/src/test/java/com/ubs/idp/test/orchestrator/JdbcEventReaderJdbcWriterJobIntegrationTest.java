package com.ubs.idp.test.orchestrator;

import com.ubs.idp.connectors.jdbc.JDBCConfigProxyImpl;
import com.ubs.idp.metadata.client.MetadataService;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:test-context.xml",
                                                         "classpath:jdbcEventReaderJdbcWriterJob.xml" })
public class JdbcEventReaderJdbcWriterJobIntegrationTest {

    public static final String EVENT_COUNT_SQL = "Select count(*) from IDP_MFEVENTS";
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private JobLauncherTestUtils jobLauncherTestUtils;

    @Autowired
    private MetadataService mds;

    @Autowired
    ApplicationContext context;

    @Before
    public void setUp() throws Exception {

        JDBCConfigProxyImpl jdbcProxy = (JDBCConfigProxyImpl) context.getBean("jdbcProxy");
        jdbcTemplate = new JdbcTemplate(jdbcProxy.getDataSource());
        jdbcTemplate.execute("truncate table IDP_MFEVENTS");
    }
    
    @Ignore
    @Test    
    public void testDatabaseConnectionDetails() throws Exception {

        String sql = mds.getPropertyMapOfServiceImplementation("GetMaxEventidSql").get("service_sql");
        assertNotNull(sql);
        sql = mds.getPropertyMapOfServiceImplementation("GetMaxEventidSql").get("service_sql");
    }

    @Ignore
    @Test    
    public void launchJob() throws Exception {

        List<Integer> beforePollerEvent = jdbcTemplate.queryForList(EVENT_COUNT_SQL, Integer.class);
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    jobLauncherTestUtils.launchJob(new JobParameters());
                } catch (Exception e) {
                    throw new RuntimeException("Test Failed");
                }
                countDownLatch.countDown();
            }
        });
        //stop the job after 15 seconds
        countDownLatch.await(15, TimeUnit.SECONDS);
        List<Integer> afterPollerEvent = jdbcTemplate.queryForList("Select count(*) from IDP_MFEVENTS", Integer.class);
        assertThat("Should have higher event count after job run", 
        		afterPollerEvent.get(0), greaterThan(beforePollerEvent.get(0)));
    }
}