CREATE TABLE teventqueue (
neventid          INTEGER PRIMARY KEY,
cconsol           INTEGER,
ccode2            VARCHAR(10),
cpropagation   INTEGER,
rpcId                INTEGER,
dlast                DATE,
cmode             VARCHAR(5),
ctable              INTEGER,
chostserver     VARCHAR(6));
