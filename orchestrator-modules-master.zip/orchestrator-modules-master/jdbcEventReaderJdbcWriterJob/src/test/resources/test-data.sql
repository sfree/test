insert into teventqueue values (21,7121300,'2000160',79, 24,	'2014-07-23',  'AMD',	292,	'MFLDN');
insert into teventqueue values (22,85379,'0980222',82, 149,	'2014-07-23',  'AMD',	149,	'MFLDN');
insert into teventqueue values (23,5942,'2000168',80, 24,	'2014-07-23',  'DEL',	159,	'MFLDN');
insert into teventqueue values (24,888932,'888932',137, 24,	'2014-07-23',  'AMD',	292,	'MFLDN');
insert into teventqueue values (25,888932,'888932',138, 24,	'2014-07-23',  'AMD',	292,	'MFLDN');
insert into teventqueue values (26,888932,'888932',83, 24,	'2014-07-23',  'AMD',	292,	'MFLDN');