package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:multiFileArchiver.xml", "classpath:test-context2.xml"})
public class MultiFileArchiverSinkDefaultFilenameTest {

	@Autowired
	FeedCache feedCache;
	
	private static File srcFile1 = new File("target/TestFile-01-BONDISSUE.txt");
	private static File srcFile2 = new File("target/TestFile-02-BONDISSUE.txt");
	private static File zipFile = new File("target/TestFile-01-BONDISSUE.txt.zip");
	private static File zipFile2 = new File("target/TestFile-02-BONDISSUE.txt.zip");
	
	@BeforeClass
	public static void clearFilesStart()
	{
		if( srcFile1.exists() )srcFile1.delete();
		if( srcFile2.exists() )srcFile2.delete();
		if( zipFile.exists() )zipFile.delete();
		if( zipFile2.exists() )zipFile2.delete();
	}

	@Before	
	public void clearFiles()
	{
		if( srcFile1.exists() )srcFile1.delete();
		if( srcFile2.exists() )srcFile2.delete();
		if( zipFile.exists() )zipFile.delete();
		if( zipFile2.exists() )zipFile2.delete();
	}

	
	@Test
	public void testFeedPollingNoFiles() throws Exception 
	{		
		feedCache.entries.clear();
		
		assertEquals(0,feedCache.entries.size());
	}
	
	@Test
	public void testFeedPollingOneFile() throws Exception 
	{			
		feedCache.entries.clear();
		
		// Create a single file
		File srcFile1 = new File("target/TestFile-01-BONDISSUE.txt");
		FileUtils.writeStringToFile(srcFile1,"Hello");		

		assertEquals(0,feedCache.entries.size());
	}

	@Test
	public void testFeedPollingAllFiles() throws Exception 
	{
		feedCache.entries.clear();

		FileUtils.writeStringToFile(srcFile1,"Hello");		

		File returnedFile = feedCache.entries.poll(10, TimeUnit.SECONDS); 
		
		assertTrue( "Zip file1 not created",zipFile.exists());
		assertEquals( zipFile.getName(), returnedFile.getName() );
		
		assertNotNull("Zip file1 not created",returnedFile);
		assertTrue("Source file1 not removed",!srcFile1.exists());

		// Run it twice to prove the second filename gets used as a prefix for the zip filename
		FileUtils.writeStringToFile(srcFile2,"Hello");		

		returnedFile = feedCache.entries.poll(10, TimeUnit.SECONDS); 
		
		assertTrue( "Zip file2 not created",zipFile2.exists());
		assertEquals( zipFile2.getName(), returnedFile.getName() );
		
		assertNotNull("Zip file2 not created",returnedFile);
		assertTrue("Source file2 not removed",!srcFile2.exists());

		
	}

}