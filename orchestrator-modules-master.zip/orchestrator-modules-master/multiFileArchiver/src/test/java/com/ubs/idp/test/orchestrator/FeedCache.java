package com.ubs.idp.test.orchestrator;

import java.io.File;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

public class FeedCache {

	final BlockingDeque<File> entries = new LinkedBlockingDeque<File>(99);

	public void add(File entry) {
		entries.add(entry);
	}
}