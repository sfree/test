package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.base.utils.IdpFileUtils;
import com.ubs.idp.orchestrator.modules.MultiFileArchiver;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:multiFileArchiver.xml", "classpath:test-context.xml"})
public class MultiFileArchiverSinkTest {

	
	@Autowired
	FeedCache feedCache;
	
	@Autowired
	MultiFileArchiver archiver;
	
	private static File srcFile1 = new File("target/TestFile-01-file1.txt");
	private static File srcFile2 = new File("target/TestFile-01-file2.txt");
	private static File srcFile3 = new File("target/TestFile-01-file3.txt");
	private static File zipFile = new File("target/FileArchive.zip");
	private static String concatFilename = "concat.txt";
	private static File targetDir = new File("target");
	
	@BeforeClass
	public static void clearFilesStart()
	{
		if( srcFile1.exists() )srcFile1.delete();
		if( srcFile2.exists() )srcFile2.delete();
		if( srcFile3.exists() )srcFile3.delete();
		if( zipFile.exists() )zipFile.delete();
		File concatFile = new File( targetDir.getAbsolutePath() + File.separator + concatFilename );
		if( concatFile.exists() )concatFile.delete();		
	}

	@Before	
	public void clearFiles()
	{
		clearFilesStart();
	}

	
	@Test
	public void testFeedPollingNoFiles() throws Exception 
	{		
		feedCache.entries.clear();

		
		assertEquals(0,feedCache.entries.size());
	}
	
	@Test
	public void testFeedPollingOneFile() throws Exception 
	{	
		archiver.setNumberOfFiles(1);

		feedCache.entries.clear();
		
		// Create a single file
		File srcFile1 = new File("target/TestFile-01-file1.txt");
		FileUtils.writeStringToFile(srcFile1,"Hello");		

		assertEquals(0,feedCache.entries.size());
	}

	@Test
	public void testFeedPollingAllFiles() throws Exception 
	{
		archiver.setNumberOfFiles(3);
		feedCache.entries.clear();

		FileUtils.writeStringToFile(srcFile1,"Hello");		
		FileUtils.writeStringToFile(srcFile2,"Hello");		
		FileUtils.writeStringToFile(srcFile3,"Hello");		

		File returnedFile = feedCache.entries.poll(10, TimeUnit.SECONDS); 
		assertNotNull("Zip file not created",returnedFile);
		assertTrue("Source file1 not removed",!srcFile1.exists());
		assertTrue("Source file2 not removed",!srcFile2.exists());
		assertTrue("Source file3 not removed",!srcFile3.exists());		
	}
	
	@Test
	public void testFileConcat() throws Exception
	{
		archiver.setNumberOfFiles(3);

		archiver.setConcatFiles(true);
		archiver.setConcatAddNewLine(true);
		archiver.setConcatFilename(concatFilename);
		archiver.setConcatSkipSubsequentHeaders(false);
		
		FileUtils.writeStringToFile(srcFile1,"Hello");		
		FileUtils.writeStringToFile(srcFile2,"World");		
		FileUtils.writeStringToFile(srcFile3,"Alright?");		
		
		File returnedFile = feedCache.entries.poll(10, TimeUnit.SECONDS); 
		assertNotNull("Zip file not created",returnedFile);
		
		assertTrue("Source file1 not removed",!srcFile1.exists());
		assertTrue("Source file2 not removed",!srcFile2.exists());
		assertTrue("Source file3 not removed",!srcFile3.exists());		

		File[] zippedFiles = IdpFileUtils.unzipFile(returnedFile,targetDir);
		assertEquals("Should only be one file",1,zippedFiles.length);
		
		BufferedReader br = new BufferedReader( new InputStreamReader(new FileInputStream(zippedFiles[0])));
		assertEquals("Wrong input for line 1","Hello",br.readLine());
		assertEquals("Wrong input for line 2","World",br.readLine());
		assertEquals("Wrong input for line 3","Alright?",br.readLine());
		br.close();
	}

	@Test
	public void testFileConcatNoNewLine() throws Exception
	{
		archiver.setNumberOfFiles(3);

		archiver.setConcatFiles(true);
		archiver.setConcatAddNewLine(false);
		archiver.setConcatFilename(concatFilename);
		archiver.setConcatSkipSubsequentHeaders(false);

		
		FileUtils.writeStringToFile(srcFile1,"Hello");		
		FileUtils.writeStringToFile(srcFile2,"World");		
		FileUtils.writeStringToFile(srcFile3,"Alright?");		
		
		File returnedFile = feedCache.entries.poll(10, TimeUnit.SECONDS); 
		assertNotNull("Zip file not created",returnedFile);
		
		assertTrue("Source file1 not removed",!srcFile1.exists());
		assertTrue("Source file2 not removed",!srcFile2.exists());
		assertTrue("Source file3 not removed",!srcFile3.exists());		

		File[] zippedFiles = IdpFileUtils.unzipFile(returnedFile,targetDir);
		assertEquals("Should only be one file",1,zippedFiles.length);
		
		BufferedReader br = new BufferedReader( new InputStreamReader(new FileInputStream(zippedFiles[0])));
		assertEquals("Wrong input for line 1","HelloWorldAlright?",br.readLine());
		br.close();
	}

	@Test
	public void testFileConcatRemoveHeader() throws Exception
	{
		archiver.setNumberOfFiles(3);

		archiver.setConcatFiles(true);
		archiver.setConcatAddNewLine(true);
		archiver.setConcatFilename(concatFilename);
		archiver.setConcatSkipSubsequentHeaders(true);
		
		FileUtils.writeStringToFile(srcFile1,"HEADER\nHello");		
		FileUtils.writeStringToFile(srcFile2,"HEADER\nWorld");		
		FileUtils.writeStringToFile(srcFile3,"HEADER\nAlright?");		
		
		File returnedFile = feedCache.entries.poll(10, TimeUnit.SECONDS); 
		assertNotNull("Zip file not created",returnedFile);
		
		assertTrue("Source file1 not removed",!srcFile1.exists());
		assertTrue("Source file2 not removed",!srcFile2.exists());
		assertTrue("Source file3 not removed",!srcFile3.exists());		

		assertTrue("Source file1 NO_HEADER not removed",!new File(srcFile1.getAbsolutePath() + MultiFileArchiver.NO_HEADER_SUFFIX).exists());
		assertTrue("Source file2 NO_HEADER not removed",!new File(srcFile2.getAbsolutePath() + MultiFileArchiver.NO_HEADER_SUFFIX).exists());
		assertTrue("Source file3 NO_HEADER not removed",!new File(srcFile3.getAbsolutePath() + MultiFileArchiver.NO_HEADER_SUFFIX).exists());		

		
		File[] zippedFiles = IdpFileUtils.unzipFile(returnedFile,targetDir);
		assertEquals("Should only be one file",1,zippedFiles.length);
		
		BufferedReader br = new BufferedReader( new InputStreamReader(new FileInputStream(zippedFiles[0])));
		assertEquals("Wrong input for line 1","HEADER",br.readLine());
		assertEquals("Wrong input for line 2","Hello",br.readLine());
		assertEquals("Wrong input for line 3","World",br.readLine());
		assertEquals("Wrong input for line 4","Alright?",br.readLine());
		br.close();
	}

	
}