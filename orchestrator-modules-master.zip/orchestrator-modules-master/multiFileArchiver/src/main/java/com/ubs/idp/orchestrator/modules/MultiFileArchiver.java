package com.ubs.idp.orchestrator.modules;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.core.MessageSource;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.util.Assert;

import com.ubs.idp.base.utils.IdpFileUtils;

/**
 * Spring Integration channel adapter that waits for all files up to a
 * configured number matching a file prefix to have appeared in a directory.
 * 
 * When all files are there, they are archived and passed to the output
 * 
 * @author loverids
 * 
 */
public class MultiFileArchiver implements MessageSource<File>
{
	public final static String OS_SYS_PROP = "os.name";
	public final static String TEMP_DIR_PROP = "java.io.tempdir";
	public final static String NEW_LINE_FILENAME = "newline.txt";
	public final static String NO_HEADER_SUFFIX = "_NOHEADER";
	
	
	public final static String TIMESTAMP_PLACEHOLDER = "%TIMESTAMP%";

	private static Logger logger = LoggerFactory.getLogger(MultiFileArchiver.class);

	/**
	 * The directory to scan for the files in the zip
	 */
	private File directory;

	/**
	 * The file pattern that all the files must match to be archived
	 */
	private String pattern;

	/**
	 * The output directory to write the archive file to
	 */
	private File outputDirectory;

	/**
	 * The filename prefix of the archive file
	 */
	private String outputArchivePrefix;

	/**
	 * The number of files that must match the prefix before being archived
	 * together
	 */
	private int numberOfFiles;

	/**
	 * If this flag is set then all the files will be concatenated into a single
	 * file before being added to the zip
	 */
	private boolean concatFiles = false;

	/**
	 * If the concatFiles flag is set then this is the filename the files will
	 * be concatenated to
	 */
	private String concatFilename;

	/**
	 * If set to true, a new line is added between concatenated files
	 */
	private boolean concatAddNewLine = true;

	/**
	 * If set to true, the original files will be deleted after the
	 * concatenation
	 */
	private boolean concatDeleteOriginals = true;

	/**
	 * The date time format for the %TIMESTAMP% property placeholder in
	 * filenames
	 */
	private String dateTimeFormat;

	/**
	 * If set to true all files after the first file to be concatenated will
	 * have the header removed
	 */
	private boolean concatSkipSubsequentHeaders = false;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.integration.core.MessageSource#receive()
	 */
	@Override
	public Message<File> receive()
	{
		logger.debug("Polling directory {} for files matching pattern {}", directory, pattern);

		String dateTime = new SimpleDateFormat(dateTimeFormat).format(new Date());

		File[] matchedFiles = getFilesMatchingPrefix();

		// Do we have enough files?
		if (matchedFiles != null && matchedFiles.length == numberOfFiles)
		{
			String filename = null;
			try
			{
				// Perform concatenation into a single file

				if (concatFiles)
				{
					concatFilename = concatFilename.replace(TIMESTAMP_PLACEHOLDER, dateTime);
					matchedFiles = new File[] { concatAllFiles(matchedFiles) };
				}

				// If there is no prefix specified then we use the filename of
				// the first matched file
				if (outputArchivePrefix == null || outputArchivePrefix.isEmpty())
				{
					filename = matchedFiles[0].getName();
				}
				else
				{
					filename = outputArchivePrefix;
				}

				filename = filename.replace(TIMESTAMP_PLACEHOLDER, dateTime);

				logger.debug("Creating archive {}/{}.zip for files {}", outputDirectory, filename, matchedFiles);

				// If so zip them up and return them
				File zipFile = IdpFileUtils.zipAndRemove(outputDirectory, filename, matchedFiles);
				return MessageBuilder.withPayload(zipFile).build();
			}
			catch (Exception ex)
			{
				throw new RuntimeException("The following error occurred attempting to archive files " + matchedFiles + " to " + outputDirectory + File.separator + filename + ".zip:" + ex, ex);
			}
		}
		else if (matchedFiles != null)
		{
			logger.debug("Found {} of {} files with pattern {} to be archived. Waiting...", matchedFiles.length, numberOfFiles, pattern);
		}

		return null;
	}

	/**
	 * Concatenates the contents of all the specified files into a single file
	 * 
	 * @param files
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private File concatAllFiles(File[] files) throws IOException, InterruptedException
	{
		File concatFile = new File(files[0].getAbsoluteFile().getParent() + File.separator + concatFilename);
		boolean ignoreNewLine = false;
		
		logger.info("Concatenating files together into {}", concatFile);

		FileChannel fromFileChannel = null;
		RandomAccessFile fromFile = null;
		RandomAccessFile toFile = new RandomAccessFile(concatFile.getAbsolutePath(), "rw");
		FileChannel toFileChannel = toFile.getChannel();

		try
		{
			for (int i = 0; i < files.length ; i++ )
			{
				File file = files[ i ];
				if( concatSkipSubsequentHeaders && i > 0 )
				{
					file = removeHeaderFromFile(file);
					ignoreNewLine = true;
				}
				
				fromFile = new RandomAccessFile(file.getAbsolutePath(), "rw");
				fromFileChannel = fromFile.getChannel();

				toFileChannel.transferFrom(fromFileChannel, toFileChannel.size(), fromFileChannel.size());

				if (concatAddNewLine)
				{
					if (!(ignoreNewLine && i > 0))
					{
						FileUtils.write(concatFile, "\n", true);
					}
				}

				fromFile.close();
				fromFileChannel.close();				
			}
		}
		catch (Exception e)
		{
			throw new RuntimeException("Error occurred concatenating file " + Arrays.asList(files) + ":" + e, e);
		}
		finally
		{
			toFile.close();
			fromFile.close();
			toFileChannel.close();
			fromFileChannel.close();
		}

		toFile.close();
		toFileChannel.close();

		
		/* Issues have arisen running this on some windows machines where the
		 * exec command does not like redirects. Uncomment this code
		 * to test the java concat vs OS native
		/*
		 * if( System.getProperty(OS_SYS_PROP).toLowerCase().contains("windows")
		 * ) { concatFilesWindows( files, concatFile ); } else {
		 * concatFilesUnix( files, concatFile ); }
		 */

		if (concatDeleteOriginals)
		{
			deleteFiles(files);
		}

		return concatFile;
	}

	/**
	 * Deletes all the specified files
	 * 
	 * @param files
	 * @return
	 */
	private boolean deleteFiles(File[] files)
	{
		boolean allFilesDeleted = true;
		for (File file : files)
		{
			if (!file.delete())
			{
				allFilesDeleted = false;
			}
			
			// Check for _NOHEADER files as well
			File noHeaderFile = new File( file.getAbsolutePath() + NO_HEADER_SUFFIX );
			if( noHeaderFile.exists() && !noHeaderFile.delete() )
			{
				allFilesDeleted = false;
			}			
		}

		return allFilesDeleted;
	}

	private void concatFilesWindows(File[] files, File targetFile) throws IOException
	{
		// Create a file with a new line in to add to the concat if specified
		File targetDir = targetFile.getParentFile();
		File newLineFile = new File(targetDir.getAbsolutePath() + File.separator + NEW_LINE_FILENAME);
		FileUtils.writeStringToFile(newLineFile, "\n");
		boolean ignoreNewLine = false;

		// Remove the header from subsequent files if needed
		if (concatSkipSubsequentHeaders)
		{
			for (int i = 1; i < files.length; i++)
			{
				files[i] = removeHeaderFromFileWindows(files[i]);
			}

			// 'More' command actually adds a new line so we can turn it off if
			// its set
			ignoreNewLine = true;
		}

		List<String> args = new ArrayList<String>();

		args.add("cmd");
		args.add("/c");
		args.add("copy");
		args.add("/b");
		for (int i = 0; i < files.length; i++)
		{
			args.add(files[i].getAbsolutePath());
			args.add("+");

			if (concatAddNewLine)
			{
				if (!(ignoreNewLine && i > 0))
				{
					args.add(newLineFile.getAbsolutePath());
					args.add("+");
				}
			}
		}
		// Remove the last '+'
		args.remove(args.size() - 1);

		args.add(targetFile.getAbsolutePath());

		executeCommand(args);

		if (newLineFile.exists())
		{
			newLineFile.delete();
		}
	}

	private File removeHeaderFromFile(File file) throws Exception
	{
		File output = new File(file.getAbsolutePath() + NO_HEADER_SUFFIX);

		PrintStream ps = new PrintStream(output);
		BufferedReader br = new BufferedReader(new FileReader(file));

		String line;

		// Biff header
		br.readLine();

		// Xfer the rest
		while ((line = br.readLine()) != null)
		{
			ps.println(line);
		}
		br.close();
		ps.close();
		
		return output;
	}


	/**
	 * Removes the header from the specified file in windows
	 * 
	 * @param files
	 * @return
	 * @throws IOException
	 */
	private File removeHeaderFromFileWindows(File file) throws IOException
	{
		File newFile = new File(file.getAbsolutePath() + "_NOHEADER");

		List<String> args = new ArrayList<String>();
		args.add("cmd");
		args.add("/c");
		args.add("more");
		args.add("+1");
		args.add(file.getAbsolutePath());
		args.add(">");
		args.add(newFile.getAbsolutePath());

		executeCommand(args);

		if (!file.delete())
		{
			logger.warn("Failed to delete file {} after creating new file {} with the header removed", file, newFile);
		}

		return newFile;
	}

	/**
	 * Removes the header from the specified file in windows
	 * 
	 * @param files
	 * @return
	 * @throws IOException
	 */
	private File removeHeaderFromFileUnix(File file) throws IOException
	{
		File newFile = new File(file.getAbsolutePath() + "_NOHEADER");

		List<String> args = new ArrayList<String>();

		args.add("/bin/sh");
		args.add("-c");
		args.add("tail -n +2 " + file.getAbsolutePath() + " > " + newFile.getAbsolutePath());
		executeCommand(args);

		if (!file.delete())
		{
			logger.warn("Failed to delete file {} after creating new file {} with the header removed", file, newFile);
		}

		return newFile;
	}

	private void concatFilesUnix(File[] files, File targetFile) throws IOException
	{
		// Create a file with a new line in to add to the concat if specified
		File targetDir = targetFile.getParentFile();
		File newLineFile = new File(targetDir.getAbsolutePath() + File.separator + NEW_LINE_FILENAME);
		FileUtils.writeStringToFile(newLineFile, "\n");

		// Remove the header from subsequent files if needed
		if (concatSkipSubsequentHeaders)
		{
			for (int i = 1; i < files.length; i++)
			{
				files[i] = removeHeaderFromFileUnix(files[i]);
			}
		}

		List<String> args = new ArrayList<String>();

		args.add("/bin/sh");
		args.add("-c");
		String command = "cat ";

		for (File file : files)
		{
			command += file.getAbsolutePath() + " ";
			if (concatAddNewLine)
			{
				command += newLineFile.getAbsolutePath() + " ";
			}
		}
		// args.add(">");
		command += "> ";
		command += targetFile.getAbsolutePath() + " ";
		args.add(command);

		executeCommand(args);

		if (newLineFile.exists())
		{
			newLineFile.delete();
		}
	}

	private void executeCommand(List<String> commandArgs) throws IOException
	{
		logger.info("Calling external command {} ", commandArgs);
		Process process = Runtime.getRuntime().exec(commandArgs.toArray(new String[] {}));

		try (BufferedReader br = new BufferedReader(new InputStreamReader(process.getErrorStream()));)
		{
			int exitCode = process.waitFor();
			logger.info("External command process returned exit code {}", exitCode);
			if (exitCode != 0)
			{
				String errorMessage = "";
				String line = "";
				while ((line = br.readLine()) != null)
				{
					errorMessage += line;
				}
				br.close();

				throw new RuntimeException("The external command process returned an unexpected exit code of " + exitCode + ". Reason: " + errorMessage);
			}
		}
		catch (InterruptedException e)
		{
			throw new RuntimeException("The external command process was interrupted before it could finish: " + e, e);
		}

	}

	/**
	 * Returns all files that match the prefix in the configured directory
	 * 
	 * @return
	 */
	private File[] getFilesMatchingPrefix()
	{
		FileFilter fileFilter = new WildcardFileFilter(pattern);
		File[] files = directory.listFiles(fileFilter);
		Arrays.sort(files);
		return files;
	}

	public File getDirectory()
	{
		return directory;
	}

	public void setDirectory(File directory)
	{
		Assert.isTrue(directory.exists(), "Directory " + directory + " does not exist!");
		Assert.isTrue(directory.isDirectory(), directory + " is not a valid directory");

		this.directory = directory;
	}

	public String getOutputArchivePrefix()
	{
		return outputArchivePrefix;
	}

	public void setOutputArchivePrefix(String outputArchivePrefix)
	{
		this.outputArchivePrefix = outputArchivePrefix;
	}

	public int getNumberOfFiles()
	{
		return numberOfFiles;
	}

	public void setNumberOfFiles(int numberOfFiles)
	{
		this.numberOfFiles = numberOfFiles;
	}

	public static Logger getLogger()
	{
		return logger;
	}

	public static void setLogger(Logger logger)
	{
		MultiFileArchiver.logger = logger;
	}

	public File getOutputDirectory()
	{
		return outputDirectory;
	}

	public void setOutputDirectory(File outputDirectory)
	{
		Assert.isTrue(outputDirectory.exists(), "Directory " + outputDirectory + " does not exist!");
		Assert.isTrue(outputDirectory.isDirectory(), outputDirectory + " is not a valid directory");

		this.outputDirectory = outputDirectory;
	}

	public String getPattern()
	{
		return pattern;
	}

	public void setPattern(String pattern)
	{
		this.pattern = pattern;
	}

	public boolean isConcatFiles()
	{
		return concatFiles;
	}

	public void setConcatFiles(boolean concatFiles)
	{
		this.concatFiles = concatFiles;
	}

	public String getConcatFilename()
	{
		return concatFilename;
	}

	public void setConcatFilename(String concatFilename)
	{
		this.concatFilename = concatFilename;
	}

	public boolean isConcatAddNewLine()
	{
		return concatAddNewLine;
	}

	public void setConcatAddNewLine(boolean concatAddNewLine)
	{
		this.concatAddNewLine = concatAddNewLine;
	}

	public boolean isConcatDeleteOriginals()
	{
		return concatDeleteOriginals;
	}

	public void setConcatDeleteOriginals(boolean concatDeleteOriginals)
	{
		this.concatDeleteOriginals = concatDeleteOriginals;
	}

	public boolean isConcatSkipSubsequentHeaders()
	{
		return concatSkipSubsequentHeaders;
	}

	public void setConcatSkipSubsequentHeaders(boolean concatSkipSubsequentHeaders)
	{
		this.concatSkipSubsequentHeaders = concatSkipSubsequentHeaders;
	}

	public String getDateTimeFormat()
	{
		return dateTimeFormat;
	}

	public void setDateTimeFormat(String dateTimeFormat)
	{
		this.dateTimeFormat = dateTimeFormat;
	}

}

