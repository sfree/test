package com.ubs.idp.orchestrator.modules;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class PaulPlay {

	private static final int FLUSH_LIMIT = 5000;

	public static void main(String[] args) {
		try {
			generateFuckoffGretBigFile();
			StripHeader();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void generateFuckoffGretBigFile() throws Exception {
		
		System.out.println("Create output file...");
		
		File output = new File("target/paulplay.txt");
		
		FileWriter fw = new FileWriter(output);
		
		for (int idx = 0 ; idx < 10000000 ; idx++) {
			fw.write("This is a slightly longer line and it's index is " + idx + "\n");
			
			if ((idx % FLUSH_LIMIT) == 0) {
				fw.flush();
			}
		}

		fw.flush();
		
		fw.close();
	}

	private static void StripHeader() throws Exception {
		System.out.println("Strip header...");

		File input = new File("target/paulplay.txt");
		File output = new File("target/paulplay.txt.noHeader.txt");
		
		long start = System.currentTimeMillis();
		
		FileWriter fw = new FileWriter(output);
		BufferedReader br = new BufferedReader(new FileReader(input));

		String line;
		
		// Biff header
		br.readLine();
		
		int idx = 0;
		
		// Xfer the rest
	    while((line = br.readLine()) != null) {
	        // process the line.
	    	fw.write(line + "\n");
			
			if ((idx % FLUSH_LIMIT) == 0) {
				fw.flush();
			}

	    	idx++;
	    }

	    fw.flush();

	    br.close();
		fw.close();

		long fin = System.currentTimeMillis();
		
		System.out.println("Time to process: " + (fin - start) + "mSec");

	}
	
	
}
