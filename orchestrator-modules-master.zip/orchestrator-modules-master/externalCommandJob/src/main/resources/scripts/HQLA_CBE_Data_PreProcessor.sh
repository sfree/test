##########################################################
#     Preprocess HQLA and CBE data file by
#     1. unzipping the original file
#     2. Replace comma with tab in the unzipped file
#     3. Move unzipped file to drop directory
#     4. Move the original zip to archive directory
##########################################################


# zip file to be processed
zipFileName=$1

shift

#destination to copy the processed file
destinationFolder=$1

tempFileExt=Temp_

 for fname in $(unzip -Z -1 "$zipFileName"); do

       tempFileName=$tempFileExt$fname

       unzip "$zipFileName" "$fname"

      sed ':a;s/^\(\([^"]*,\?\|"[^",]*",\?\)*"[^",]*\),/\1~/;ta' $fname | sed 's/,/\t/g' | sed 's/~/,/g' > $tempFileName

      rm $fname
      mv $tempFileName $destinationFolder/drop/$fname
  done

mv $zipFileName $destinationFolder/inbound/
