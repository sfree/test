#!/bin/bash

# SCP (secure copy) file(s) and move to archive

# source files
sourceFile=$1

shift

# destination to scp to
destination=$1

shift

# folder to archive to
archiveFolder=$1

# scp files
scp $sourceFile $destination

# move files to archive
mv $sourceFile $archiveFolder
