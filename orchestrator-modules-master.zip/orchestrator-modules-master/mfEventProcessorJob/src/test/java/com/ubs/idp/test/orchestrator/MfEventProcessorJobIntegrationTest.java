package com.ubs.idp.test.orchestrator;

import com.ubs.idp.connectors.jdbc.JDBCConfigProxyImpl;
import com.ubs.idp.metadata.client.MetadataService;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:test-context.xml",
                                                         "classpath:MFEventProcessorJob.xml" })
public class MfEventProcessorJobIntegrationTest {

    private JdbcTemplate jdbcTemplate;

    @Autowired
    ApplicationContext applicationContext;

    @Autowired
    private JobLauncherTestUtils jobLauncherTestUtils;

    private MetadataService mds;

    @Before
    public void setUp() throws Exception {
        JDBCConfigProxyImpl jdbcProxy = (JDBCConfigProxyImpl) applicationContext.getBean("jdbcProxy");
        jdbcTemplate = new JdbcTemplate(jdbcProxy.getDataSource());
        jdbcTemplate.execute("delete from IDP_OUTBOUND_MESSAGES where neventid in (21,22,23,24,25,26)");
    }

    @Ignore
    @Test
    public void testDatabaseConnectionDetails() throws Exception {

        String sql = mds.getSQLQueryForDataset("MFEventData");
        assertNotNull( sql );
    }

    @Ignore
    @Test
    public void launchJob() throws Exception {
        JobExecution jobExecution = jobLauncherTestUtils.launchJob(new JobParameters());
        assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
    }
}