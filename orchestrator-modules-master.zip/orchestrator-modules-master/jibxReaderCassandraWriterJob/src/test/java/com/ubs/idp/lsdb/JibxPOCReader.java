package com.ubs.idp.lsdb;

import java.io.FileInputStream;
import java.io.IOException;

import javax.xml.transform.stream.StreamSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.oxm.jibx.JibxMarshaller;
import org.springframework.stereotype.Component;

import com.ubs.idp.lsdb.model.BankUnit;

/**
 * Proof of concept JiBX reader
 * @author mcnamars
 */
@Component("jibxReader")
public class JibxPOCReader {

	@Autowired
	@Qualifier("jibxMarshaller")
	private JibxMarshaller jibxMarshaller;

	public BankUnit parseXmlFile(String filename) throws IOException {
		FileInputStream fis = null;

		try {
			fis = new FileInputStream(filename);
			StreamSource ss = new StreamSource(fis);
			return (BankUnit) jibxMarshaller.unmarshal(ss);
		} finally {
			if (fis != null) {
				fis.close();
			}
		}
	}
}
