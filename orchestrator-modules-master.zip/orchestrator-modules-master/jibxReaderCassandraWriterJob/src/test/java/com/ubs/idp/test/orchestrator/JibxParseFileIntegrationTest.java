package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.lsdb.JibxPOCReader;
import com.ubs.idp.lsdb.model.BankUnit;
import com.ubs.idp.lsdb.model.Company;
import com.ubs.idp.lsdb.model.Name;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:jibx-integration-context.xml" })
public class JibxParseFileIntegrationTest {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(JibxParseFileIntegrationTest.class);
	private static final String TEST_XML_FILE = "src/test/resources/xml/LSDB_BankUnit_sample.xml";

	@Autowired
	@Qualifier("jibxReader")
	private JibxPOCReader jibxReader;

	@Test
	public void testFileParsing() throws IOException {

		BankUnit bankUnit = jibxReader.parseXmlFile(TEST_XML_FILE);
		int noGcrs = 0;
		int withGcrs = 0;
		assertNotNull("BankUnit should not be null", bankUnit);

		List<Company> companies = bankUnit.getCompanyList();
		assertNotNull("List of Companies should not be null", companies);
		assertTrue("There should be 96 companies", companies.size() == 96);

		// print outs for sanity - could turned to debug
		for (Company company : companies) {
			assertNotNull("Comapny should not be null", company);
			LOGGER.debug("Company id> {}", company.getId());

			List<Name> names = company.getNameList();
			assertNotNull("Company should have a Name", names);
			for (Name name : names) {
				LOGGER.debug("Company name> {}", name.getContent());
				LOGGER.debug("Company name actaul?> {}", name.isActual());
				LOGGER.debug("Company name type id> {}", name.getTypeId());
				LOGGER.debug("Company name type> {}", name.getTypeName());
				LOGGER.debug("Company name start date> {}", name.getStartDate());
			}
			if (company.getGcrs() != null) {
				withGcrs++;
				assertNotNull("if Company has GCRS then the GCRS code should be populated", company.getGcrs().getGcrsCode());
				LOGGER.debug("gcrs code> {}", company.getGcrs().getGcrsCode());
				LOGGER.debug("fcrs code> {}", company.getGcrs().getFcrsCode());
			} else {
				noGcrs++;
			}
			LOGGER.debug("");
		}
		LOGGER.debug("Companies with GCRS: {}", withGcrs);
		LOGGER.debug("Companies without GCRS: {}", noGcrs);
		assertEquals(38, withGcrs);
		assertEquals(58, noGcrs);
	}
}
