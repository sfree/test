package com.ubs.idp.test.orchestrator;

import java.io.File;
import java.util.Arrays;

import org.mockito.Mockito;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.Statement;
import com.ubs.idp.metadata.model.JDBCChannel;
import com.ubs.idp.stubs.jdbc.DummyJdbcDriver;

@Component
public class JDBCAndMetadataStub extends CustomBeanFactoryPostProcessor
{	
	public final static String MOCK_QUERY = "MOCK QUERY";
	
	@Override
	public void initialiseMocks() 
	{
		rowsIterator = getCassandraReaderResultsetIterator();

		// Mock all MDS calls made by the job definition
		Mockito.when(mdsStub.getDelimiter(Mockito.anyString())).thenReturn("\t");
		Mockito.when(mdsStub.getAttributeNamesForDataset("LEGALENTITY.LEM")).thenReturn(Arrays.asList("PARTY_ID","STATUS","PARTY_NAME","CTRY_DOMICILE_ISO","CTRY_INCORP_ISO","PARTY_TYPE","IMED_PARENT_PARTY_ID","IMED_PARENT_PARTY_NAME","IMED_PARENT_CTRY_DOMICILE_ISO","IMED_PARENT_CTRY_INCORP_ISO","ULT_PARENT_PARTY_ID","ULT_PARENT_PARTY_NAME","ULT_PARENT_CTRY_DOMICILE_ISO","ULT_PARENT_CTRY_INCORP_ISO","INDUSTRY_SECTOR","INDUSTRY_GROUP","INDUSTRY_SUBGROUP","IMMEDIATE_BBG_ID","IMMEDIATE_BBG_NAME","ULTIMATE_BBG_ID","ULTIMATE_BBG_NAME"));
		Mockito.when(mdsStub.getTableIdForDataset("LEGALENTITY.LEM")).thenReturn("ISSUER");
		Mockito.when(mdsStub.getSQLQueryForDataset("LEGALENTITY.LEM")).thenReturn(MOCK_QUERY);
		Mockito.when(mdsStub.getSQLDeltaQueryForDataset("LEGALENTITY.LEM")).thenReturn(MOCK_QUERY);

		initialiseJdbcMockReader();
		
		// Simulate the fetch from JDBC
		Mockito.when(cqlProxy.getPrepareStatement( Mockito.anyString()) ).thenReturn(stmt);
		Mockito.when(resultset.iterator() ).thenReturn( rowsIterator );
		Mockito.when(stmt.bind() ).thenReturn(boundStatement);
		Mockito.when(cqlProxy.executeStatement( Mockito.any(Statement.class) ) ).thenReturn(resultset);						
		Mockito.when(cassandraSessionHelper.getProxy()).thenReturn(cqlProxy);
	}
	
	private void initialiseJdbcMockReader()
	{
		JDBCChannel mockChannel = new JDBCChannel();
		mockChannel.driverClass="com.ubs.idp.stubs.jdbc.DummyJdbcDriver";		
		mockChannel.password="e7c20722dcd6fbecb4d2851141642152";
		mockChannel.username="test";
		mockChannel.url="test";
		mockChannel.querySQL="test";
		
		Mockito.when(mdsStub.getDatabaseDetailsForDataset("LEGALENTITY.LEM")).thenReturn(mockChannel);
	}
	
	public void initialiseTest( File dataFile )
	{
		DummyJdbcDriver.addResultsFileToQueryMap(MOCK_QUERY, dataFile);
	}
	

	
}
