package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.metadata.client.MetadataService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:test-context.xml",
        "classpath:JDBCReaderFileWriterJob.xml" })
/* Turning these off as they get run as part of the current build
 * configuration. As we have changed this module to be a jar so 
 * that the unit tests are run.
 */
@Ignore 
public class JDBCReaderFileWriter_BondPricing_JobIntegrationTest extends BaseJobTest {

    @Autowired
    private JobLauncherTestUtils jobLauncherTestUtils;

    @Autowired
    private MetadataService mds;

    
    public JDBCReaderFileWriter_BondPricing_JobIntegrationTest() {
        super("BONDPRICING", "txt");
    }

   // @Test
    @Ignore
    public void testDatabaseConnectionDetails() throws Exception {
        String sql = mds.getSQLQueryForDataset("BONDPRICING");
        assertNotNull( sql );
    }
    
    //@Test
    @Ignore
    public void launchJob() throws Exception {

        // testing a job
        jobExecution = jobLauncherTestUtils.launchJob(getJobParameters());
        assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
    }
}
