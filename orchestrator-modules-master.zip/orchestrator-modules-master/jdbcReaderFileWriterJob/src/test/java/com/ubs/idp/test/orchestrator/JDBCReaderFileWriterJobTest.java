package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.metadata.client.Neo4jUtils;

@RunWith(SpringJUnit4ClassRunner.class)
public abstract class JDBCReaderFileWriterJobTest
{
	@Autowired
	protected JobLauncherTestUtils jobLauncherTestUtils;

	@Value("${file.stageDir}")
	protected String stageDirPath;

	@Value("${file.archiveDir}")
	protected String archiveDirPath;

	@Value("${file.baseDir}")
	protected String baseDirPath;

	@Value("${filePrefix}")
	protected String filePrefix;

	@Value("${testDataFile}")
	protected Resource testDataFile;

	@Value("${compareFile}")
	protected Resource compareFileResource;

	@Autowired
	ApplicationContext context;
	
    @Autowired
    Neo4jUtils neo4jUtils;
    
    @Autowired
    JDBCAndMetadataStub stubInitialiser;

	@Before
	public void initTests() throws IOException
	{
		// Initialise the directories
		File stageDir = new File(stageDirPath);
		if (!stageDir.exists())
		{
			assertTrue("Failed to create stage directory", stageDir.mkdirs());
		}
		FileUtils.cleanDirectory(stageDir);

		File archiveDir = new File(archiveDirPath);
		if (!archiveDir.exists())
		{
			assertTrue("Failed to create archvie directory", archiveDir.mkdirs());
		}
		FileUtils.cleanDirectory(archiveDir);

		File baseDir = new File(baseDirPath);
		if (!baseDir.exists())
		{
			assertTrue("Failed to create base directory", baseDir.mkdirs());
		}
		FileUtils.cleanDirectory(baseDir);
		
		
		stubInitialiser.initialiseTest(testDataFile.getFile());
	}

    @After
    public void cleanup()
    {
    	neo4jUtils.shutdownDatabase();
    }
}