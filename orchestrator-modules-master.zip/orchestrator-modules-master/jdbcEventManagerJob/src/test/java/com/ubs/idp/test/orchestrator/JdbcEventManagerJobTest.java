package com.ubs.idp.test.orchestrator;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.env.PropertySource;

public class JdbcEventManagerJobTest {

	private AbstractApplicationContext appContext;

	@Ignore
	@Test
	public void run() throws Exception {
		appContext = new ClassPathXmlApplicationContext(
				new String[] {"test-context.xml", "JdbcEventManagerJob.xml"}, false
				);
		appContext.getEnvironment().getPropertySources().addLast(
				new CustomPropertySource()
				);
		appContext.refresh();
		JobLauncherTestUtils jobLauncherTestUtils = (JobLauncherTestUtils) appContext.getBean("jobLauncherTestUtils");
		jobLauncherTestUtils.launchJob(new JobParameters());
	}

	private static class CustomPropertySource extends PropertySource<String> {

		public CustomPropertySource() {super("custom");}

		@Override
		public String getProperty(String name) {
			if (name.equals("environment")) {
				return "DEV";
			}
			return null;
		}
	}

}
