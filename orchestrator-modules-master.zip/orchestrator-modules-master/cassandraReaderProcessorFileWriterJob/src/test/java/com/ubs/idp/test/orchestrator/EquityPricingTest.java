package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import junitx.framework.FileAssert;

import org.junit.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration(locations = { "classpath:test-context2.xml", "classpath:CassandraReaderProcessorFileWriterJob.xml" })
public class EquityPricingTest extends CassandraReaderProcessorFileWriterJobTest
{
    static {
        System.setProperty("environment", "equity");
    }
    
	@Test
	public void launchJob() throws Exception
	{
		File compareFile = compareFileResource.getFile();

		// testing a job
		JobExecution jobExecution = jobLauncherTestUtils.launchJob();
		assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
		
		String dateString = new SimpleDateFormat("yyyyMMdd").format(new Date());

		File exportFile = new File(baseDirPath + File.separator + filePrefix + "-" + dateString + ".csv");
		assertTrue("Could not find " + exportFile, exportFile.exists());

		FileAssert.assertEquals(compareFile, exportFile);
	}
} 