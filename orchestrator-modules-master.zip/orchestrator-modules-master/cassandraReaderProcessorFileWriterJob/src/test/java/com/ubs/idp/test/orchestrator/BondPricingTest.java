package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import junitx.framework.FileAssert;

import org.junit.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration(locations = { "classpath:test-context1.xml", "classpath:CassandraReaderProcessorFileWriterJob.xml" })
public class BondPricingTest extends CassandraReaderProcessorFileWriterJobTest
{
    static {
        System.setProperty("environment", "bondpricing");
    }
    
	@Test
	public void launchJob() throws Exception
	{
		File compareFile = compareFileResource.getFile();

		// testing a job
		JobExecution jobExecution = jobLauncherTestUtils.launchJob( getJobParameters() );
		assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
		
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_YEAR, -1);
		String dateString = new SimpleDateFormat("yyyyMMdd").format(cal.getTime());

		File exportFile = new File(baseDirPath + File.separator + filePrefix + "-" + dateString + ".csv");
		assertTrue("Could not find " + exportFile, exportFile.exists());

		FileAssert.assertEquals(compareFile, exportFile);
	}
	
	private JobParameters getJobParameters()
	{
        //testing a job

        JobParameter priceDate = new JobParameter("20101112");
        JobParameter deltaDays = new JobParameter("-1");

        Map<String, JobParameter>jobParameterMap = new HashMap<String, JobParameter>();

        jobParameterMap.put("priceDate", priceDate);
        jobParameterMap.put("deltaDays", deltaDays);

        JobParameters jobParameters = new JobParameters(jobParameterMap);

        return jobParameters;
	}
} 