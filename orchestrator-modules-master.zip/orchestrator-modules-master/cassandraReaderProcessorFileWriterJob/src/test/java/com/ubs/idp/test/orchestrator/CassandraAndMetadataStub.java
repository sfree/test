package com.ubs.idp.test.orchestrator;

import java.util.Arrays;

import org.mockito.Mockito;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.Statement;

@Component
public class CassandraAndMetadataStub extends CustomBeanFactoryPostProcessor
{
	@Override
	public void initialiseMocks()
	{
		rowsIterator = getCassandraReaderResultsetIterator();
		
		// Mock all MDS calls made by the job definition
		Mockito.when(mdsStub.getTransformerRulesetsForDatasets("EQUITY.IDP","EQUITYISSUE.TAR")).thenReturn(Arrays.asList("com.ubs.idp.orchestrator.processor.rules.treasuryar.IssueActiveRecordFilterRule"));
		Mockito.when(mdsStub.getTransformerRulesetsForDatasets("EQUITY.IDP","EQUITYTL.TAR")).thenReturn(Arrays.asList("com.ubs.idp.orchestrator.processor.rules.treasuryar.TradingLineActiveRecordFilterRule"));
		Mockito.when(mdsStub.getDelimiter(Mockito.anyString())).thenReturn("\t");
		Mockito.when(mdsStub.getAttributeNamesForDataset("EQUITYTL.TAR")).thenReturn(Arrays.asList("issue.ubsId","tL.ubsId","tL.sedol","tL.quotationType","tL.exchange","tL.currency","tL.tradeCountry","tL.countryOfRegistration","tL.opol","tL.opolInd","tL.ric"));
		Mockito.when(mdsStub.getAttributeNamesForDataset("EQUITYISSUE.TAR")).thenReturn(Arrays.asList("issue.ubsId","issue.isin","issue.cusip","issue.valoren","issue.cins","issue.common","issue.wertpapier","issue.assetClass","issue.assetType","issue.securityType"));
		Mockito.when(mdsStub.getAttributeNamesForDataset("EQUITY.IDP")).thenReturn(Arrays.asList("issue.issueDate","issue.sharesOutstanding","issue.sharesOutstandingDate","issue.rule144A3c7Ind","issue.votesPerShare","tL.portfolioMarginableCode","tL.illiquidStock","tL.bbCompositeExchange","basket.divisor","basket.numOfConstituents","settle.dtcEligible","issuer.ubsPartnerId","issuer.ubsId","undl.tlUbsId","undl.issueUbsId","undl.assetClass","undl.majorVersion","undl.lastUpdatedTime","undl.bbTicker","undl.sedol","issue.standardMarketSize","issue.isOfQuality","tL.settleCalendar","issue.shortName","settle.settleCalendar","issue.amountOutstanding","issue.fosProductGroup","issue.nikkeiStockType","issue.tseIndustryCode","issue.issueName/kanji","issue.shortName/kanji","issue.nikkeiIndustryCode","issue.frenchTransactionTax","tL.firstTradeDate","tL.indicativeNavRic","tL.pmNavSymbol","tL.risklessPrincipal","tL.nikkeiInvTrustType","tL.maxTradableQuantity","tL.maxTradableLot","equity.stockSplitDate","issue.fosGovtClass","issue.hasListing","issue.fosCalcCode","issue.amountOutstandingDate","issue.fos","issue.isStopTrade","issue.lastUpdatedTime","issue.majorVersion","issue.active","issue.status","issue.isoCfi","issue.assetClass","issue.assetType","issue.securityType","issue.bbSecurityType","issue.cusip","issue.common","issue.isin","issue.valoren","issue.wertpapier","issue.securityFormType","issue.nominalCurrency","issue.restrictedListCode","issue.cins","issue.restrictedOffTime","issue.restrictedOnTime","issue.nominalValueOfUnit","issue.mifidLiquidStk","issue.ubsTradable","issue.mifidTradeRep","issue.stdMarketSize","issue.mifidAvgDailyTurnover","issue.mifidAvgDailyTurnoverCcy","issue.mifidMarket","issue.mifidStdMktSizeCurrency","issue.mifidMostrelvMktCurrency","issue.issueName","issue.restrictedClass","issue.restrictedForResearch","issue.restrictionPriority","issue.restrictedForSales","issue.restrictedForTrading","issue.restrictedForPADealing","issue.restrictionComment","issue.sharesPerDepositoryReceipt","issue.regSInd","issue.rule144AInd","issue.adpClassification","issue.taxableCode","issue.quick","issue.adrPerShare","issue.isMultipleShare","issue.bbPrimSecCompExchange","issue.bbPrimSecPrimExchange","issue.ftaClass","issue.ubsId","tL.countryUbsId","tL.majorVersion","tL.lastUpdatedTime","tL.active","tL.status","tL.tickSize","tL.tidm","tL.exchange","tL.currency","tL.lotSize","tL.bbUnique","tL.sedol","tL.quotationType","tL.ticker","tL.tradeCountry","tL.bbTicker","tL.ric","tL.bbTickerExchange","tL.localCode","tL.bbSecurity","tL.roundLotSize","tL.ubsMarketMaker","tL.coltMn","tL.cubsInstrCode","tL.tradingLineName","tL.bbExchange","tL.isdaRegion","tL.opol","tL.regShoCatA","tL.euronext","tL.regShoCatB","tL.consolidatedThresholdInd","tL.etbExternal","tL.etbInternal","tL.whenIssuedFlag","tL.ipoFlag","tL.lastTradeDate","tL.marketSegment","tL.consolidatedListingInd","tL.opolInd","tL.bbCurrency","tL.ricOfIntInd","tL.pinkQuotable","tL.marketSettleVenue","tL.mifidFungibleId","tL.pmSymbol","tL.isdaRelExchCode","tL.isdaRelRtrsExchCode","tL.mifidMktSettleVenueName","tL.mifidubsMostLiquidVenue","tL.dmlMnemonic","tL.traxInd","tL.freeFloatPercent","tL.quoteLotSize","tL.normalMarketSize","tL.calendar","tL.orderRoutingRule","tL.countryOfRegistration","tL.fiiRestrictionInd","tL.auctionSession","tL.t13","tL.isOptionable","tL.relativeIndex","tL.adpId","tL.marginableCode","tL.occMarginableCode","tL.earningsPerShare","tL.bbPrimaryExchange","tL.lniClass","tL.takeoverMarker","tL.takeoverDate","tL.quick","tL.ubsId","equity.lastUpdatedTime","equity.majorVersion","equity.dividendCurrency","equity.dividendPerShare","equity.dividendType","equity.dividendFrequency","equity.dividendPayDate","equity.dividendRecordDate","equity.dividendDeclaredDate","equity.dividendExDate","equity.ipoDate","settle.majorVersion","settle.lastUpdatedTime","settle.seaqReportingInd","settle.crestInd","settle.firstSettleDate","settle.lastSettleDate","settle.ptmLevyApplicable","settle.euroclearInd","settle.stampInd","settle.crestStampDutyInd","settle.calendar","settle.date","issuer.lastUpdatedTime","issuer.majorVersion","issuer.issuerName","issuer.countryOfIncorporation","issuer.cconsol","issuer.bbCompany","issuer.icbIndustry","issuer.icbSector","issuer.icbSubsector","issuer.icbSupersector","issuer.fidbCode","issuer.countryOfDomicile","issuer.countryOfRisk","issuer.ubsPartyId","event.majorVersion","event.lastUpdatedTime"));

		Mockito.when(mdsStub.getTransformerRulesetsForDatasets("BONDPRICING","BONDPRICING.TAR")).thenReturn(Arrays.asList("com.ubs.idp.orchestrator.processor.rules.treasuryar.PriceDateFilterRule"));
		Mockito.when(mdsStub.getDelimiter(Mockito.anyString())).thenReturn("\t");
		Mockito.when(mdsStub.getAttributeNamesForDataset("BONDPRICING")).thenReturn(Arrays.asList("INSTR_ID","ACCRUED","ACCRUED_DAYS","ASM","ASM_CURVE_ID","ASSUMED_INFLATION","BPV","BREAK_EVEN_ACTUAL","BREAK_EVEN_INSTR_ID","BREAK_EVEN_SIMPLE","BRK_EVEN_NUM_A","BRK_EVEN_NUM_B","BRK_EVEN_SPREAD_A","BRK_EVEN_SPREAD_B","BRK_EVEN_UNIT_A","BRK_EVEN_UNIT_B","CALC_UPDATED","CALC_UPDATED_USER","CLEAN_PRICE","CONVEXITY","CREATED","CREATED_USER","DIRTY_PRICE","DISCOUNT_MARGIN","GAMMA","INDEX_RATIO","ISPRD","ISPRD_CURVE_ID","MCDURATION","MOD_DURATION","OAS","OAS_CURVE_ID","ORIGINAL_PRICE_SRCE","PRICED_TO","PRICED_TO_DATE","PRICE_DATE","PRICE_GRP","PRICE_ROLLED","PRICE_ROLLED_DATE","PRICE_SRCE","PRICE_TYPE","PRINCIPAL_RETURN","QUOTE_IND","REAL_NOMINAL","SETTLEMENT_DATE","SPRD","SPRD_CURVE_ID","SPRD_INSTR_ID","TOTAL_RETURN","UPDATED","UPDATED_USER","VDR_PRICE_QUAL","YIELD","YIELD_FREQ_NUM","YIELD_FREQ_UNIT","YIELD_TAX_BASIS","YIELD_TO_CALL","YIELD_TO_MATURITY","YIELD_TO_PUT","YVO1","ZSPRD","ZSPRD_CURVE_ID"));
		Mockito.when(mdsStub.getAttributeNamesForDataset("BONDPRICING.TAR")).thenReturn(Arrays.asList("INSTR_ID","PRICE_SRCE","PRICE_DATE","PRICE_TYPE","PRICE_GRP","CLEAN_PRICE","DIRTY_PRICE"));

		
		// Simulate the fetch from cassandra
		Mockito.when(cqlProxy.getPrepareStatement( Mockito.anyString()) ).thenReturn(stmt);
		Mockito.when(resultset.iterator() ).thenReturn( rowsIterator );
		Mockito.when(stmt.bind() ).thenReturn(boundStatement);
		Mockito.when(cqlProxy.executeStatement( Mockito.any(Statement.class) ) ).thenReturn(resultset);						
		Mockito.when(cassandraSessionHelper.getProxy()).thenReturn(cqlProxy);

	}
}
