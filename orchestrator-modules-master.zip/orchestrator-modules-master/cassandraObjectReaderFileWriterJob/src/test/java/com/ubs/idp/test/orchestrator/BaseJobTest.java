package com.ubs.idp.test.orchestrator;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.junit.After;
import org.junit.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.util.StringUtils;

public abstract class BaseJobTest {

    protected String workingDir;
    protected JobExecution jobExecution;
    protected String fileName;
    protected String fileSuffix;

    private ResourceBundle cfg = ResourceBundle.getBundle("test");

    private Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * Main constructor
     * @param fileName
     * @param fileSuffix
     */
    public BaseJobTest(String fileName, String fileSuffix) {
        this.fileName = fileName;
        this.fileSuffix = fileSuffix;

        logger.debug("Base job test configured for file name '{}.{}'", fileName, fileSuffix);
    }

    /**
     * Pre-test processing
     */
    @Before
    public void beforeTest() {
        workingDir = System.getProperty("user.dir");
        logger.debug("Working dir set to '{}'", workingDir);
    }

    /**
     * Post test processing
     */
    @After
    public void afterTest() {
        // If we have a job execution context check for timestamped files
        // to move

        if (jobExecution != null) {
            ExecutionContext ctx = jobExecution.getExecutionContext();

            if (ctx.containsKey("timestamp")) {

                String baseDir = cfg.getString("file.baseDir"); 

                // Fetch timestamp from batch listener
                String timestamp = ctx.getString("timestamp");

                // If we have one, check for timestamped files to move
                if (!StringUtils.isEmpty(timestamp)) {
                    // Rename timestamped file
                    String filename = String.format("%s/%s/%s-%s.%s", workingDir, baseDir, fileName, timestamp, fileSuffix);
                    String newFilename = String.format("%s/%s/%s.%s", workingDir, baseDir, fileName, fileSuffix);

                    File testOut = new File(filename);
                    File newTestOut = new File(newFilename);

                    newTestOut.delete();

                    int retry = 0;
                    while (!testOut.renameTo(newTestOut) && retry < 10) {
                        System.out.println("Rename failed - sleeping...");

                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            // Do nothing
                        }
                        retry++;
                    }
                }
            }
        }
    }

    /**
     * Set up job execution to emulate file poller stream
     * @return
     */
    protected JobParameters getJobParameters() {

        String baseDir = cfg.getString("file.baseDir"); 

        //testing a job

        String filename = String.format("%s/%s/%s.%s", workingDir, baseDir, fileName, fileSuffix);

        JobParameter absoluteFilePath = new JobParameter(filename);

        Map<String, JobParameter>jobParameterMap = new HashMap<String, JobParameter>();

        jobParameterMap.put("absoluteFilePath", absoluteFilePath);

        JobParameters jobParameters = new JobParameters(jobParameterMap);

        return jobParameters;
    }
}
