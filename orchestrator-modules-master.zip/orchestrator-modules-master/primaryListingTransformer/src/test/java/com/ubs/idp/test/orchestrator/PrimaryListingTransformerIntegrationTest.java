package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import junitx.framework.FileAssert;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.neo4j.kernel.impl.util.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.orchestrator.transformers.PrimaryListingTransformer;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:test-context.xml"})
public class PrimaryListingTransformerIntegrationTest  {
	
	@Autowired
	SenderGateway gateway;	
	
	@Autowired
	PrimaryListingTransformer primaryListingTransformer;
	
	@Before
	public void clearOutputFiles() throws IOException
	{
		String[] dirs = {"target/archive","target/errors/","target/drop","target/stage"};
		for( String dir : dirs )
		{
			File[] files = new File(dir).listFiles();
			if( files != null )
			{
				for( File file : files )
				{
					if( file.exists() )file.delete();
				}
			}
			
			// Remove the stage dir
			if( dir.equals("target/stage") )
			{
				new File(dir).delete();
			}
		}
	}

	
	@Test
	public void testTransformer() throws IOException {

		String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		
		// Copy our test files to target as they get deleted and archived in the transform
		File sourceFile = new File("./src/test/resources/EQUITY.txt");
		File triggerFile = new File("target/drop/EQUITY_UNSORTED_" + timestamp + ".txt");
		File archivedFile = new File("target/archive/EQUITY_UNSORTED.txt.zip");
		File compareFile = new File("src/test/resources/data/COMPARE_EQUITY.txt");
		FileUtils.copyFile(sourceFile,triggerFile);
				
		File transformedFile = gateway.sendTestMessage(triggerFile);			
		
		assertNotNull("No output file",transformedFile);
		assertEquals("Transformed file in wrong dir",new File("target/drop"),transformedFile.getParentFile());
		assertEquals("Wrong filename for transformed file","EQUITY_TRANSFORMED_" + timestamp + ".txt",transformedFile.getName());

		
		String[] sortedFiles = new File("target/stage").list(new FilenameFilter()
		{
			
			@Override
			public boolean accept(File dir, String name)
			{
				return name.startsWith("EQUITY_SORTED");
			}
		});
		assertTrue("Sorted file not moved",sortedFiles.length == 0);
		assertTrue("Original file not moved",!triggerFile.exists());
		assertNotNull("Original file not archived",archivedFile.exists());
	
		// Verify the contents
		FileAssert.assertEquals(compareFile, transformedFile);
	}

	@Test
	public void testTransformerNoData() throws IOException {

		String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		
		// Copy our test files to target as they get deleted and archived in the transform
		File dropDir = new File("./target/drop/");
		File sourceFile = new File("./src/test/resources/EQUITYNODATA.txt");
		File triggerFile = new File("target/drop/EQUITY_UNSORTED_" + timestamp + ".txt");
		File archivedFile = new File("target/archive/EQUITY_UNSORTED_" + timestamp + ".txt.zip");
		FileUtils.copyFile(sourceFile,triggerFile);
		
		File transformedFile = gateway.sendTestMessage(triggerFile);
		
		assertNotNull("No output file",transformedFile);
		assertEquals("Transformed file in wrong dir",new File("target/drop"),transformedFile.getParentFile());
		assertEquals("Wrong filename for transformed file","EQUITY_UNSORTED_" + timestamp + ".txt",transformedFile.getName());
		
		String[] sortedFiles = new File("target/stage").list(new FilenameFilter()
		{			
			@Override
			public boolean accept(File dir, String name)
			{
				return name.startsWith("RATING_SORTED");
			}
		});
		assertNull("Sorted file should not be present",sortedFiles);
		assertTrue("Original file not moved",!triggerFile.exists());
		assertTrue("Original file not archived",archivedFile.exists());
	}

	@Test
	public void testParallelTransformer() throws IOException {

		int fileCount = 10;
		
		// Copy our test files to target as they get deleted and archived in the transform
		File dropDir = new File("./target/drop/");
		File sourceFile = new File("./src/test/resources/EQUITY.txt");
		File compareFile = new File("src/test/resources/data/COMPARE_EQUITY.txt");

		for( int i = 0; i < fileCount; i ++ )
		{
			File triggerFile = new File("target/drop/EQUITY_UNSORTED_" + i + ".txt");
			if( !dropDir.exists() )
			{
				assertTrue(dropDir.mkdirs());
			}		
			FileUtils.copyFile(sourceFile,triggerFile);
		}
		
		ExecutorService executor = Executors.newFixedThreadPool(5);
        for (int i = 0; i < fileCount; i++) 
        {
            Runnable worker = new WorkerThread(new File("target/drop/EQUITY_UNSORTED_" + i + ".txt"));
            executor.execute(worker);
        }
        executor.shutdown();
        while (!executor.isTerminated()) {
        }		
        
        String[] dirs = {"target/archive","target/drop"};
		for( String dir : dirs )
		{
			File[] files = new File(dir).listFiles();
			assertEquals("Wrong number of files in " + dir + " dir",fileCount,files.length);
			
			if( dir.equals("target/drop") )
			{
				for( File transformedFile : files )
				{
					// Verify the contents
					FileAssert.assertEquals(compareFile, transformedFile);
				}
			}
		}        
		
		
	}
	
	public class WorkerThread implements Runnable 
	{
		File file;
		
		public WorkerThread( File file )
		{
			this.file = file;
		}
		
		@Override
		public void run()
		{
			File transformedFile = gateway.sendTestMessage(file);			
			
			assertNotNull("No output file",transformedFile);
		}
		
	}

	

}