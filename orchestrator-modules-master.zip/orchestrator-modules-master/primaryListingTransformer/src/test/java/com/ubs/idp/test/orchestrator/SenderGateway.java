package com.ubs.idp.test.orchestrator;

import java.io.File;

import org.springframework.integration.annotation.Gateway;

public interface SenderGateway
{
	@Gateway(requestChannel="input",replyChannel="output")
	public File sendTestMessage( File file );
}
