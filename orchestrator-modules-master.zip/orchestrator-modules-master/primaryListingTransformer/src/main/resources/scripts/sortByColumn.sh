#!/bin/bash
# works on comma and tab delimited files
# arguments are the key column numbers (1 based order)
# by which the file is to be sorted
# arguments are InputFile, OutputFile, delimiter, col1, col2, col3...keyN

shift $((OPTIND -1))
totNumArgs=$#

tempDir=$1
shift
fileName=$1
shift
outFileName=$1
shift
delimiter=$1
shift
finalKey=""
for ((i=1; i<=$totNumArgs-4; i++))
do
finalkey+="$finalKey -k$1,$1"
shift
done
echo "Sorting: " $fileName " | To: " $outFileName 
echo " Delim: " $delimiter " | Key:  " $finalkey
if [ "$delimiter" == "\t" ]
then
	tail -n +2 $fileName | sort -T $tempDir -t$'\t' $finalkey > $outFileName
else	
	tail -n +2 $fileName | sort -T $tempDir -t"$delimiter" $finalkey > $outFileName
fi

