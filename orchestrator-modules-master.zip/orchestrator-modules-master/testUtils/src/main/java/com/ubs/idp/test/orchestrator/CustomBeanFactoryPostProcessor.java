package com.ubs.idp.test.orchestrator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.ubs.idp.connectors.cassandra.CassandraConfig;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;
import com.ubs.idp.metadata.client.MetadataService;

/**
 * Base class that can be extended to provide a Metadata Service and Cassandra
 * stub to be used in unit testing XD job modules
 * 
 * Child classes need only implement initialiseMocks and setup mocks for metadata service
 * calls and Cassandra query executions 
 *  
 * @author loverids
 *
 */
@Component
public abstract class CustomBeanFactoryPostProcessor implements BeanFactoryPostProcessor, InitializingBean
{
	private static Logger logger = LoggerFactory.getLogger(CustomBeanFactoryPostProcessor.class);
	
    @Mock
    protected MetadataService mdsStub;    
	
    @Mock
    protected CassandraConfig cassandraConfig;
    
    @Mock
    protected CassandraSessionHelper cassandraSessionHelper;
    
    @Mock
    protected CassandraCqlProxy cqlProxy;

    @Mock
    protected ResultSet resultset;
    
    @Mock
    protected PreparedStatement stmt;
    
    @Mock 
    protected BoundStatement boundStatement;
    
    @Mock
    protected Iterator<Row> rowsIterator;
       
    @Mock
    protected Row mockRow;
    
    /**
     * A file that can be used to return mock cassandra rows
     * for a cassandra item reader
     */
    protected Resource cassandraReaderDataFile;

    /**
     * Determines if a header needs to be skipped when reading test data
     * to be mocked as a cassandra read
     */
    protected boolean skipHeader;
    

    /**
     * Register our mock objects and injecting them into the context 
     */
	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException
	{
		beanFactory.registerSingleton("neo4jMetadataService", mdsStub);
		beanFactory.registerSingleton("cassandraConfig", cassandraConfig);
		beanFactory.registerSingleton("cassandraSessionHelper", cassandraSessionHelper);
	}

	@Override
	public void afterPropertiesSet() throws Exception
	{
		MockitoAnnotations.initMocks(this);
		
		rowsIterator = getCassandraReaderResultsetIterator();
		
		initialiseMocks();
	}
	
	/**
	 * Called as part of the setup. Implementers need to 
	 * initialise all mock calls within this method
	 */
	public abstract void initialiseMocks();
	
	/**
	 * Loads the test file into memory and returns an iterator
	 * of mock rows that return a line from the file
	 * @return
	 */
	protected Iterator<Row> getCassandraReaderResultsetIterator()
	{		
		List<Row> lines = new ArrayList<Row>();
		
		if( cassandraReaderDataFile != null )
		{		
			// Open the test file for reading
			try
			(	
				InputStream is = cassandraReaderDataFile.getInputStream();
				BufferedReader br = new BufferedReader( new InputStreamReader(is));
			)
			{
				logger.debug("Initialising cassandra mock data from {}",cassandraReaderDataFile.getFile().getAbsolutePath());
				if( skipHeader )br.readLine();
				
				String line = null;
				while( (line = br.readLine()) != null )
				{
					logger.debug("Return line {}",line);					
					Row row = Mockito.mock(Row.class);
					Mockito.when(row.getString("value") ).thenReturn(line);
					lines.add(row);
				}
			}
			catch (IOException e)
			{
				throw new RuntimeException("Error occured reading testfile",e);
			}		
		}
		
		return lines.iterator();
	}


	public Resource getCassandraReaderDataFile()
	{
		return cassandraReaderDataFile;
	}

	public void setCassandraReaderDataFile(Resource cassandraReaderDataFile)
	{
		try
		{
			logger.debug("Setting cassandra mock file to {}",cassandraReaderDataFile.getFile().getAbsolutePath());
		}
		catch (IOException e)
		{
			throw new RuntimeException(e);
		}
		this.cassandraReaderDataFile = cassandraReaderDataFile;
	}

	public boolean isSkipHeader()
	{
		return skipHeader;
	}

	public void setSkipHeader(boolean skipHeader)
	{
		logger.debug("Setting skipHeader flag to {}",skipHeader);
		this.skipHeader = skipHeader;
	}

}
