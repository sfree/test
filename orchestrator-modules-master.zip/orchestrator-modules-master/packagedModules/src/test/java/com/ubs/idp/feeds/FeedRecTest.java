package com.ubs.idp.feeds;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Perform a reconciliation of create/destroy DSL statements
 * @author mcminnp
 */
public class FeedRecTest {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Test
	public void createDestroyRec() throws IOException {
		File feedDir = new File("src/main/resources/feeds");

		Map<String, String> createStreams = new HashMap<String, String>();
		Map<String, String> createJobs = new HashMap<String, String>();
		Map<String, String> destroyStreams = new HashMap<String, String>();
		Map<String, String> destroyJobs = new HashMap<String, String>();

		// Parse statements in files
		processFiles(feedDir, createStreams, createJobs, destroyStreams, destroyJobs);
		
		// Compare
		
		int errors = 0;
		
		errors += doRec("Stream", createStreams, destroyStreams);
		errors += doRec("Job", createJobs, destroyJobs);
		
		assertTrue("Mismatch on feed DSL - see log for details!", errors == 0);
	}
	
	/**
	 * Compare two create/destroy maps
	 * @param type
	 * @param createMap
	 * @param destroyMap
	 * @return
	 */
	private int doRec(String type, Map<String, String> createMap, Map<String, String> destroyMap) {
		
		int errors = 0;

		// Create items NOT in destroy 
		
		for (String key : createMap.keySet()) {
			if (!destroyMap.containsKey(key)) {
				errors++;
				logger.error("{} '{}' created in '{}' is never destroyed!", type, key, createMap.get(key));
			}
		}

		// Destroy items NOT in create 
		
		for (String key : destroyMap.keySet()) {
			if (!createMap.containsKey(key)) {
				errors++;
				logger.error("{} '{}' destroyed in '{}' is never created!", type, key, destroyMap.get(key));
			}
		}
		
		return errors;
	}

	/**
	 * Iterate over DSL/DDL files
	 * @param feedDir
	 * @param createStreams
	 * @param createJobs
	 * @param destroyStreams
	 * @param destroyJobs
	 * @throws IOException
	 */
	private void processFiles(File feedDir, Map<String, String> createStreams, Map<String, String> createJobs, Map<String, String> destroyStreams, Map<String, String> destroyJobs) throws IOException {
		File[] files = feedDir.listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) {
				if (name.toLowerCase().matches("create.*\\.d.l") ||
					name.toLowerCase().matches("destroy.*\\.d.l")) {
					return true;
				} else {
					return false;
				}
			}
		});

		for (File file : files) {
			processFile(file, createStreams, createJobs, destroyStreams, destroyJobs);
		}
	}
		
	/**
	 * Pull out create/destroy into maps
	 * @param file
	 * @param streamMap
	 * @param jobMap
	 * @throws IOException 
	 */
	private void processFile(File file, Map<String, String> createStreams, Map<String, String> createJobs, Map<String, String> destroyStreams, Map<String, String> destroyJobs) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(file));

		String line;

		while ((line = br.readLine()) != null) {
			processLine(file.getName(), line, createStreams, createJobs, destroyStreams,
					destroyJobs);
		}
		
		br.close();
	}

	/**
	 * Process individual line
	 * @param fileName
	 * @param line
	 * @param createStreams
	 * @param createJobs
	 * @param destroyStreams
	 * @param destroyJobs
	 */
	private void processLine(String fileName, String line,
			Map<String, String> createStreams, Map<String, String> createJobs,
			Map<String, String> destroyStreams, Map<String, String> destroyJobs) {
		line = line.trim();
		
		if (!line.startsWith("#") && line.length() > 0) {
			String[] parts = line.split(" ");
			
			String itemName = parts[2];
			
			if (itemName.equalsIgnoreCase("--name")) {
				itemName = parts[3];
			}
			
			if (parts[0].equalsIgnoreCase("job")) {
				if (parts[1].equalsIgnoreCase("create")) {
					// Create job
					createJobs.put(itemName, fileName);
				} else if (parts[1].equalsIgnoreCase("destroy")) {
					// Destroy job
					destroyJobs.put(itemName, fileName);
				}
			} else if (parts[0].equalsIgnoreCase("stream")) {
				if (parts[1].equalsIgnoreCase("create")) {
					// Create stream
					createStreams.put(itemName, fileName);
				} else if (parts[1].equalsIgnoreCase("destroy")) {
					// Destroy stream
					destroyStreams.put(itemName, fileName);
				}
			}
		}
	}

}
