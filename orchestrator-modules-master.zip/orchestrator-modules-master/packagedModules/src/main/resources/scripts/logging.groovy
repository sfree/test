import groovy.util.logging.*

@Slf4j
public class Logger 
{
	public static debug( String message )
	{
		log.debug(message)		
	}

	public static info( String message )
	{
		log.info(message)		
	}

	public static warn( String message )
	{
		log.warn(message)		
	}

	public static error( String message )
	{
		log.error(message)		
	}

}

