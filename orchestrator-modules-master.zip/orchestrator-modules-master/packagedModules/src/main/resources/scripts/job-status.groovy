import groovy.util.logging.*

// TODO: Havent figured how to import this block of code into another script just yet without using absolute paths
// so for now, as its our only groovy script I've included it at the top here

@Slf4j
public class Logger 
{
	public static debug( String message )
	{
		log.debug(message)		
	}

	public static info( String message )
	{
		log.info(message)		
	}

	public static warn( String message )
	{
		log.warn(message)		
	}

	public static error( String message )
	{
		log.error(message)		
	}

}

Logger.debug("Groovy script payload:" + payload)

def jobStatus = payload.getStatus().toString();
def jobId = payload.getId();
boolean jobCompleted = jobStatus.equals('COMPLETED') ? true : false

Logger.debug("Job status:" + jobStatus)
Logger.debug("Job Id:" + jobId)
Logger.debug("Job Completed?:" + jobCompleted)

if (!jobCompleted) {
  Logger.info("Returning null from groovy script")
  return null
}

def returnPayload = "{\"jobStatus\":\"${jobStatus}\",\"jobId\":\"${jobId}\"}"
Logger.info("Returning " + returnPayload + " from groovy script")
return returnPayload
