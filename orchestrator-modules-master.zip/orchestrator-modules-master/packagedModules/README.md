# IDP Orchestrator Modules

## Manual Tasks

The main deployment of the Orchestrator modules is via Swift and/or SRLWeb.

There are, however, some tasks which currently need to be executed manually. These steps will need to be added to the deployment run book.

### GCRS Hierarchy

The GCRS hierarchy column family needs to be created from a cqlsh script using the ```createGCRSHierarchy.cql``` provided under:

    src/main/resources/feeds
