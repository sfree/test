#!/bin/bash
# works on comma and tab delimited files
# arguments are the key column numbers (1 based order)
# by which the file is to be sorted
# arguments are InputFile, OutputFile, delimiter, col1, col2, col3...keyN
# Bond pricing data key field numbers used on 2-26 and 3_13 are the following:
# To sort on price_date, instrument_id, price_srce and price_type (columns 1,36,40,41)
# command would be ->>   bash sortByColumn.sh InputFileName OutputFileName , 1 36 40 41  


shift $((OPTIND -1))
totNumArgs=$#

tempDir=$1
shift
fileName=$1
shift
outFileName=$1
shift
delimiter=$1
shift
finalKey=""

for ((i=1; i<=$totNumArgs-4; i++))
do
key=$1
finalkey+="$finalKey -k$((key+1)),$((key+1))"
shift
done
echo "Sorting: " $fileName " | To: " $outFileName 
echo " Delim: " $delimiter " | Key:  " $finalkey
if [ "$delimiter" == "\t" ]
then
	(head -n 1 $fileName && tail -n +2 $fileName | sort -s -T $tempDir -t$'\t' $finalkey) > $outFileName
else	
	(head -n 1 $fileName && tail -n +2 $fileName | sort -s -T $tempDir -t"$delimiter" $finalkey) > $outFileName
fi