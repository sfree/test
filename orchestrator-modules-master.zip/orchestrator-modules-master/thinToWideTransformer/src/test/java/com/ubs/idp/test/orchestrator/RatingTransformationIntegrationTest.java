package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import junitx.framework.FileAssert;

import org.junit.Test;
import org.neo4j.kernel.impl.util.FileUtils;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;


public class RatingTransformationIntegrationTest extends ThinToWideTransformerIntegrationTest
{

	public RatingTransformationIntegrationTest()
	{
		super("RATING");
	}
	
	@Test
	public void testTransformerNoData() throws Exception {

		String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		String fileName = "RATINGNODATA_NEW_" + timestamp;
		
		File sourceFile = new File("./src/test/resources/RATINGNODATA" + FILE_SUFFIX);
		File triggerFile = new File("target/drop/" + fileName + FILE_SUFFIX );
		File archivedFile = new File("target/archive/" + fileName + FILE_SUFFIX + ".zip");
		File sortedFile = new File("target/stage/RATINGNODATA_SORTED_" + timestamp + FILE_SUFFIX );
		FileUtils.copyFile(sourceFile,triggerFile);
		
    	
        // testing a job
        JobExecution jobExecution = jobLauncherTestUtils.launchJob(getJobParameters(triggerFile));
        assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());

		File transformedFile = new File("target/drop/RATINGNODATA_TRANSFORMED_" + timestamp + FILE_SUFFIX );

		assertTrue("No transformed file produces",transformedFile.exists());
		assertTrue("Sorted file not removed",!sortedFile.exists());
		assertTrue("Original file not moved",!triggerFile.exists());
		assertTrue("Original file not archived",archivedFile.exists());
		
		String[] expected = {"Fitch_event.lastUpdatedTime","Moodys_event.lastUpdatedTime","SandP_event.lastUpdatedTime","Fitch_issueRating.lastUpdatedTime","Moodys_issueRating.lastUpdatedTime","SandP_issueRating.lastUpdatedTime","issueRating.isProvisional","Fitch_issueRating.code","Moodys_issueRating.code","SandP_issueRating.code","Fitch_issueRating.rawCode","Moodys_issueRating.rawCode","SandP_issueRating.rawCode","issueRating.structuredFinanceInd","issueRating.endorsementInd","issueRating.recordType","Fitch_issueRating.validDate","Moodys_issueRating.validDate","SandP_issueRating.validDate","Fitch_issueRating.ratingGroup","Moodys_issueRating.ratingGroup","SandP_issueRating.ratingGroup","issueRating.ratingType","issueRating.currencyType","Fitch_event.majorVersion","Moodys_event.majorVersion","SandP_event.majorVersion","issue.majorVersion","issue.active","issue.isoCfi","issue.assetClass","issue.assetType","issue.nominalCurrency","issue.ubsTradable","issue.ubsIsoCfi","issue.ubsId"};
		logger.info("Verifying data");
		
		try( BufferedReader br = new BufferedReader( new InputStreamReader(new FileInputStream(transformedFile))) )
		{
			// Read in the header
			String header = br.readLine();
			
			// Tokenize the columns based on the delimiter
			String[] columns = header.split("\t");
			
			assertEquals("Column count incorrect",expected.length,columns.length);
			assertArrayEquals("Header columns not equal", expected,columns);
			
			assertNull("Did not expect any data", br.readLine() );
		}
	}
		
	
	@Test
	public void testParallelTransformer() throws IOException {

		int fileCount = 5;
		
		// Copy our test files to target as they get deleted and archived in the transform
		File dropDir = new File("./target/drop/");
		File sourceFile = new File("./src/test/resources/RATING" + FILE_SUFFIX);
		File compareFile = new File("src/test/resources/data/COMPARE_RATING.csv");		

		
		for( int i = 0; i < fileCount; i ++ )
		{
			File triggerFile = new File("target/drop/RATING_NEW_" + i + FILE_SUFFIX);
			if( !dropDir.exists() )
			{
				assertTrue(dropDir.mkdirs());
			}		
			FileUtils.copyFile(sourceFile,triggerFile);
		}
		
		ExecutorService executor = Executors.newFixedThreadPool(5);
        for (int i = 0; i < fileCount; i++) 
        {
            Runnable worker = new WorkerThread(new File("target/drop/RATING_NEW_" + i + FILE_SUFFIX));
            executor.execute(worker);
        }
        executor.shutdown();
        while (!executor.isTerminated()) {
        }		
        
        String[] dirs = {"target/archive","target/drop"};
		for( String dir : dirs )
		{
			File[] files = new File(dir).listFiles();
			assertEquals("Wrong number of files in " + dir + " dir",fileCount,files.length);
			
			if( dir.equals("target/drop") )
			{
				for( File file : files )
				{
					logger.info("Verifying data");
					FileAssert.assertEquals("Files dont match",compareFile,file);
				}
			}
			
		}        
		
		
	}
	
	public class WorkerThread implements Runnable 
	{
		File file;
		
		public WorkerThread( File file )
		{
			this.file = file;
		}
		
		@Override
		public void run()
		{
			try
			{				
				JobExecution jobExecution = jobLauncherTestUtils.launchJob(getJobParameters(file));
				assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
			}
			catch (Exception e)
			{
				logger.error("Error occurred running job: {}",e,e); 
			}
	    }
		
	}


}
