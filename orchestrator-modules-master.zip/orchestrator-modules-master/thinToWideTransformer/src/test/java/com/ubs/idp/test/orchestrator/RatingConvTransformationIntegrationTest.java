package com.ubs.idp.test.orchestrator;

public class RatingConvTransformationIntegrationTest extends ThinToWideTransformerIntegrationTest {

	public RatingConvTransformationIntegrationTest() {
		super("RATING_CONV");
	}

}
