package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junitx.framework.FileAssert;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.neo4j.kernel.impl.util.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:test-context.xml",
        "classpath:ThinToWideTransformer.xml" })
public abstract class ThinToWideTransformerIntegrationTest {

	protected static Logger logger = LoggerFactory.getLogger(ThinToWideTransformerIntegrationTest.class);
	
	public final static String FILE_SUFFIX = ".csv";
	
	public final static List<String> DATASETS_TO_TEST = Arrays.asList("RATING","BONDPRICING");

	protected String dataset;	
	
    @Autowired
    protected JobLauncherTestUtils jobLauncherTestUtils;
    
    public ThinToWideTransformerIntegrationTest(String datasetName )
    {
    	dataset = datasetName;
    	System.setProperty("datasetName", datasetName);
    }

	@Before
	public void clearOutputFiles() throws IOException
	{
		String[] dirs = {"target/archive","target/errors/","target/drop","target/stage"};
		for( String dir : dirs )
		{
			File[] files = new File(dir).listFiles();
			if( files != null )
			{
				for( File file : files )
				{
					if( file.exists() )file.delete();
				}
			}
			
			// Make sure the dirs exist
			new File(dir).mkdirs();
		}
		
		// Copy the sort scripts to the target dir
		//File sortScript = new File("./src/main/resources/scripts/sortByColumn.bat");
		//File targetSourceScript = new File("target/modules/job/ThinToWideTransformer/scripts/sortByColumn.bat");
    	//FileUtils.copyFile(sortScript,targetSourceScript);
	}
			    
	@Test
    public void testTransformer() throws Exception 
    {
		String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
    	String fileName = dataset + "_NEW_" + timestamp;
    	
		File sourceFile = new File("./src/test/resources/" + dataset + FILE_SUFFIX);
		File triggerFile = new File("target/drop/" + fileName + FILE_SUFFIX );
		File archivedFile = new File("target/archive/" + fileName + FILE_SUFFIX + ".zip");
		File sortedFile = new File("target/stage/" + dataset + "_SORTED_" + timestamp + "." + FILE_SUFFIX );
		File compareFile = new File("src/test/resources/data/COMPARE_" + dataset + FILE_SUFFIX);		
		
		FileUtils.copyFile(sourceFile,triggerFile);
		
        // testing a job
        JobExecution jobExecution = jobLauncherTestUtils.launchJob(getJobParameters(triggerFile));
        assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
        
		File transformedFile = new File("target/drop/" + dataset + "_TRANSFORMED_" + timestamp + ".csv" );

		assertTrue("No transformed file produced",transformedFile.exists());
		assertTrue("Sorted file not removed",!sortedFile.exists());
		assertTrue("Original file not moved",!triggerFile.exists());
		assertTrue("Original file not archived",archivedFile.exists());
		
		logger.info("Verifying data");
		FileAssert.assertEquals("Files dont match",compareFile,transformedFile);
    }
    

    /**
     * Set up job execution for multiple filesto emulate file poller stream
     * @return
     */
	protected JobParameters getJobParameters(File file) {

        JobParameter absoluteFilePath = new JobParameter(file.getAbsolutePath());

        Map<String, JobParameter>jobParameterMap = new HashMap<String, JobParameter>();

        jobParameterMap.put("absoluteFilePath", absoluteFilePath);        

        JobParameters localJobParameters = new JobParameters(jobParameterMap);
        
        return localJobParameters;
    }


}