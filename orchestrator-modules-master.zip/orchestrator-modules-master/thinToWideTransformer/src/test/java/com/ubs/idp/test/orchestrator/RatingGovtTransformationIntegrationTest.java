package com.ubs.idp.test.orchestrator;

public class RatingGovtTransformationIntegrationTest extends ThinToWideTransformerIntegrationTest {

	public RatingGovtTransformationIntegrationTest() {
		// super("RATING");
		super("RATING_GOVT");
	}

}
