package com.ubs.idp.test.orchestrator;


public class BondPricingTransformationIntegrationTest extends ThinToWideTransformerIntegrationTest
{

	public BondPricingTransformationIntegrationTest()
	{
		super("BONDPRICING");
	}

}
