package com.ubs.idp.test.orchestrator;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

public abstract class BaseJobTest {

    protected String workingDir;
    protected JobExecution jobExecution;
    
    @Value("${filePrefix}")
    protected String filePrefix;
    protected String fileSuffix;

    @Value("${file.baseDir}")
    private String baseDir;


    
    
    //protected ResourceBundle cfg = ResourceBundle.getBundle("test");

    private Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * Main constructor
     * @param fileSuffix
     */
    public BaseJobTest(String fileSuffix) {
        this.fileSuffix = fileSuffix;

        logger.debug("Base job test configured for file name '{}.{}'", filePrefix, fileSuffix);
    }

    /**
     * Pre-test processing
     */
    @Before
    public void beforeTest() {
        workingDir = System.getProperty("user.dir");
        logger.debug("Working dir set to '{}'", workingDir);
    }

    /**
     * Post test processing
     */
    @After
    public void afterTest() {
        // If we have a job execution context check for timestamped files
        // to move

        if (jobExecution != null) {
            ExecutionContext ctx = jobExecution.getExecutionContext();

            if (ctx.containsKey("timestamp")) {
                
                // Fetch timestamp from batch listener
                String timestamp = ctx.getString("timestamp");

                // If we have one, check for timestamped files to move
                if (!StringUtils.isEmpty(timestamp)) {
                    // Rename timestamped file
                    String filename = String.format("%s/%s/%s-%s.%s", workingDir, baseDir, filePrefix, timestamp, fileSuffix);
                    String newFilename = String.format("%s/%s/%s.%s", workingDir, baseDir, filePrefix, fileSuffix);

                    File testOut = new File(filename);
                    File newTestOut = new File(newFilename);

                    newTestOut.delete();

                    int retry = 0;
                    while (!testOut.renameTo(newTestOut) && retry < 10) {
                        System.out.println("Rename failed - sleeping...");

                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            // Do nothing
                        }
                        retry++;
                    }
                }
            }
        }
    }

    /**
     * Backwards compatibility
     * @return
     */
    protected JobParameters getJobParameters() {
        return getJobParameters(null);
    }

    /**
     * Set up job execution to emulate file poller stream
     * @param userParams
     * @return
     */
    protected JobParameters getJobParameters(Map<String, Object> userParams) {

        // Emulate file poller param

        String filename = String.format("%s/%s/%s.%s", workingDir, baseDir, filePrefix, fileSuffix);

        JobParameter absoluteFilePath = new JobParameter(filename);

        Map<String, JobParameter>jobParameterMap = new HashMap<String, JobParameter>();

        jobParameterMap.put("absoluteFilePath", absoluteFilePath);
        
        // Add user-defined params
        
        if (userParams != null) {
            for (String key : userParams.keySet()) {
                Object value = userParams.get(key);
                JobParameter param;
                
                // Only support Strings and Longs for now
                if (value instanceof String) {
                    param = new JobParameter(value.toString());
                } else if (value instanceof Long) {
                    param = new JobParameter((Long) value);
                } else {
                    throw new IllegalArgumentException("Invalid object type in param map '" + value.getClass() + "'");
                }
                
                jobParameterMap.put(key, param);
            }
        }

        JobParameters jobParameters = new JobParameters(jobParameterMap);

        return jobParameters;
    }
}
