package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import junitx.framework.FileAssert;

import org.junit.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration(locations = { "classpath:test-context1.xml", "classpath:HTTPReaderFileWriterJob.xml" })
public class EqPricingEODLoadTest extends HTTPReaderFileWriterJobTest
{
    static {
        System.setProperty("environment", "eqpricingeod");
    }
    
	@Test
	public void testDefaultDeltaDays() throws Exception
	{
		File compareFile = compareFileResource.getFile();

		// testing a job
		JobExecution jobExecution = jobLauncherTestUtils.launchJob();
		assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
		
		File exportFile = new File(baseDirPath + File.separator + jobExecution.getExecutionContext().getString("filename")  );
		assertTrue("Could not find " + exportFile, exportFile.exists());

		FileAssert.assertEquals(compareFile, exportFile);
	}

	
} 