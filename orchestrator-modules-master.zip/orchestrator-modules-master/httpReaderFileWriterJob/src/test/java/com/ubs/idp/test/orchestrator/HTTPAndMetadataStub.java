package com.ubs.idp.test.orchestrator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.stereotype.Component;

import com.ubs.idp.connectors.spring.batch.readers.HTTPSourceReader;

@Component
public class HTTPAndMetadataStub extends CustomBeanFactoryPostProcessor
{
    @Mock
    protected HTTPSourceReader httpSourceReader;

	private BufferedReader br;
    
	@Override
	public void initialiseMocks()
	{
		// Mock all MDS calls made by the job definition
		Mockito.when(mdsStub.getDelimiter(Mockito.anyString())).thenReturn("\t");
		Mockito.when(mdsStub.getAttributeNamesForDataset("EQPRICINGEOD")).thenReturn(Arrays.asList("eod.tlUbsId","eod.exchange","eod.assetClass","eod.tradeIndicator","eod.quoteIndicator","adjustmentFactor.splitVolumeMultiplier","adjustmentFactor.effectiveDate","adjustmentFactor.dividendPriceAdjust","adjustmentFactor.splitPriceMultiplier","priceDate","priceSource","ask.price","ask.currency","ask.lastUpdatedTime","bid.price","bid.currency","bid.lastUpdatedTime","close.price","close.currency","close.lastUpdatedTime","volume.value","volume.currency","volume.lastUpdatedTime","openInterest.value","openInterest.currency","openInterest.lastUpdatedTime","adv5.value","adv5.currency","adv5.lastUpdatedTime","adv20.value","adv20.currency","adv20.lastUpdatedTime","netAssetValue.price","netAssetValue.currency","netAssetValue.lastUpdatedTime","adv30.value","adv30.currency","adv30.lastUpdatedTime","adv60.value","adv60.currency","adv60.lastUpdatedTime","adv90.value","adv90.currency","adv90.lastUpdatedTime","open.price","open.currency","open.lastUpdatedTime","high.price","high.currency","high.lastUpdatedTime","low.price","low.currency","low.lastUpdatedTime","marketCapitalization.price","marketCapitalization.currency","marketCapitalization.lastUpdatedTime","stopHigh.price","stopHigh.currency","stopHigh.lastUpdatedTime","stopLow.price","stopLow.currency","stopLow.lastUpdatedTime","exchangeClose.price","exchangeClose.currency","exchangeClose.lastUpdatedTime","base.price","base.currency","base.lastUpdatedTime","settlement.price","settlement.currency","settlement.lastUpdatedTime","low52weeks.price","low52weeks.currency","low52weeks.lastUpdatedTime","high52weeks.price","high52weeks.currency","high52weeks.lastUpdatedTime"));
		Mockito.when(mdsStub.getSourceAuthenticationUriForDataset("EQPRICINGEOD")).thenReturn("localhost");
		
		try
		{
			// Simulate the fetch from http
			Mockito.when(httpSourceReader.read() ).thenAnswer(new Answer<String>(){
				@Override
				public String answer(InvocationOnMock invocation) 
				{	
					try
					{
						return br.readLine();
					}
					catch (Exception e)
					{
						throw new RuntimeException("Error occured reading from mock test file:" + e,e);
					}					
				}
			});
			
			Mockito.doAnswer(new Answer<Void>(){
				@Override
				public Void answer(InvocationOnMock invocation) 
				{	
					try
					{
						br = new BufferedReader(new InputStreamReader( cassandraReaderDataFile.getInputStream()));
					}
					catch (Exception e)
					{
						throw new RuntimeException("Error occured opening mock test file:" + e,e);
					}
					return null;
				}
			}).when(httpSourceReader).open(Mockito.any(ExecutionContext.class));

			Mockito.doAnswer(new Answer<Void>(){
				@Override
				public Void answer(InvocationOnMock invocation) 
				{	
					try
					{
						if( br != null )
						{
							br.close();
						}
					}
					catch (Exception e)
					{
						throw new RuntimeException("Error occured closing mock test file:" + e,e);
					}
					return null;
				}
			}).when(httpSourceReader).close();

			
			Mockito.when(httpSourceReader.getRowCount() ).thenReturn(100L);
			Mockito.when(httpSourceReader.isConnected() ).thenReturn(true);
		}
		catch (Exception e)
		{
			throw new RuntimeException("Error occured reading from mock test file:" + e,e);
		}
	}
		
    /**
     * Register our mock objects and injecting them into the context 
     */
	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException
	{
		super.postProcessBeanFactory(beanFactory);
		beanFactory.registerSingleton("itemReader", httpSourceReader);		
	}

}
