Prepping The Environment To Run The Job
=======================================
To install and use this job definition, we need to ensure a couple of
pre-requisites are in place:

1. The idp.properties file (from common/src/main/resources) should be
   deployed in <xd.home>/modules/common
   
2. The DEV.properties file (currently in this project under src/main/resources) should
   be deployed to <xd.home>/config
   
TODO: These contain env-specific data and will need to be customised for each environment.
      Ultimately these will be replaced by Zookeeper
      
The base directory of the installed job definition includes a Windows and a Unix
install script. In subsequent releases this and the above properties will be covered
using a separate deployment module.