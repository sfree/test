package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import junitx.framework.FileAssert;

import org.apache.commons.io.FileUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration(locations = { "classpath:test-context1.xml", "classpath:CassandraReaderFileWriterJob.xml" })
//@Ignore
public class UltrabondExportTest extends CassandraReaderFileWriterJobTest
{
	private static Logger logger = LoggerFactory.getLogger(UltrabondExportTest.class);
	
    static {
        System.setProperty("environment", "ultrabond");
    }
    
	@Test
	public void testForSpecificDay() throws Exception
	{
		File compareFile = compareFileResource.getFile();

		// testing a job
		JobExecution jobExecution = jobLauncherTestUtils.launchJob( getJobParameters() );
		assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
		
		String dateString = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		File exportFile = new File(baseDirPath + File.separator + filePrefix + "-" + dateString + ".csv");
		
		logger.debug("Comparing received file " + exportFile.getAbsolutePath() + " with " + compareFile.getAbsolutePath() );
		
		assertTrue("Could not find " + exportFile, exportFile.exists());

		FileAssert.assertEquals(compareFile, exportFile);
	}

	@Ignore
	@Test
	public void testDefaultDeltaDays() throws Exception
	{
		File compareFile = compareFileResource.getFile();

		// testing a job
		JobExecution jobExecution = jobLauncherTestUtils.launchJob();
		assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
		
		String dateString = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		File exportFile = new File(baseDirPath + File.separator + filePrefix + "-" + dateString + ".csv");
		
		logger.debug("Comparing received file " + exportFile.getAbsolutePath() + " with " + compareFile.getAbsolutePath() );
		
		assertTrue("Could not find " + exportFile, exportFile.exists());

		logger.debug("Received file size={}",exportFile.length() ); 
		logger.debug("Received file contents={}",FileUtils.readFileToString(exportFile) );
		logger.debug("Compare file size={}",compareFile.length() ); 
		logger.debug("Compare file contents={}",FileUtils.readFileToString(compareFile) );
		
		FileAssert.assertEquals(compareFile, exportFile);
	}

	
	private JobParameters getJobParameters()
	{
        //testing a job

        JobParameter deltaDays = new JobParameter("0");

        Map<String, JobParameter>jobParameterMap = new HashMap<String, JobParameter>();

        jobParameterMap.put("deltaDays", deltaDays);

        JobParameters jobParameters = new JobParameters(jobParameterMap);

        return jobParameters;
	}
} 
