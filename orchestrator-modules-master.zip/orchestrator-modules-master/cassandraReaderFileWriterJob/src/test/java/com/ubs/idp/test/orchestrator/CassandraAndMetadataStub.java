package com.ubs.idp.test.orchestrator;

import java.util.Arrays;

import org.mockito.Mockito;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.Statement;

@Component
public class CassandraAndMetadataStub extends CustomBeanFactoryPostProcessor
{	
	@Override
	public void initialiseMocks()
	{
		rowsIterator = getCassandraReaderResultsetIterator();

		// Mock all MDS calls made by the job definition
		Mockito.when(mdsStub.getDelimiter(Mockito.anyString())).thenReturn("\t");
		Mockito.when(mdsStub.getAttributeNamesForDataset("Ultrabond")).thenReturn(Arrays.asList("KEY","COLLATERAL_TYPE","TRANCHE_NAME","DELINQUENCY_30_PLUS","DELINQUENCY_60_PLUS","DELINQUENCY_90_PLUS","FORECLOSURE","REAL_ESTATE_OWNED","CREDIT_SUPPORT","P_RATIO","issue.issueDate","WALA","coupon.couponType","FICO","WAL","PREPAYMENT_VALUE","PREPAYMENT_TYPE","GEOGRAPHIC_LOCATION","MTG_CREDIT_ENHANCEMENT","DISCOUNT_MARGIN","TIER","POOL_MATURITY","issue.bbTicker","coupon.currentCouponRate","PAY_DELAY","CURRENT_FACTOR","ORIGINAL_SUPPORT","issue.issueSize","SENIORITY_TYPE","CURRENT_SUBORDINATION","issue.assetType","DEAL_ISSUER","ORIGINAL_DEAL_BALANCE","CURRENT_DEAL_BALANCE","DEAL_CATEGORY","MTG_GEN_TICKER","FITCH_CURRENT","MOODYS_CURRENT","S_AND_P_CURRENT","FITCH_ORIG","MOODYS_ORIG","S_AND_P_ORIG","UNDERLYING_SECURITY_TYPE","MBS_ASSET_CLASS","LIEN","issue.isin","issue.cusip","issue.nominalCurrency","ISSUER_NAME","MFCCONSOL","issue.issueName","SECURITY_TYPE","INTERNAL_RATING","MTG_TRANCHE_TYP_LONG"));
		Mockito.when(mdsStub.getTableIdForDataset("Ultrabond")).thenReturn("Ultrabond");
		Mockito.when(mdsStub.getAttributeNamesForDataset("Ultrabond.TAR")).thenReturn(Arrays.asList("COLLATERAL_TYPE","coupon.couponType","coupon.currentCouponRate","CREDIT_SUPPORT","CURRENT_DEAL_BALANCE","CURRENT_FACTOR","CURRENT_SUBORDINATION","DEAL_CATEGORY","DEAL_ISSUER","DELINQUENCY_30_PLUS","DELINQUENCY_60_PLUS","DELINQUENCY_90_PLUS","DISCOUNT_MARGIN","FICO","FITCH_CURRENT","FITCH_ORIG","FORECLOSURE","GEOGRAPHIC_LOCATION","INTERNAL_RATING","issue.assetType","issue.bbTicker","issue.cusip","issue.isin","issue.issueDate","issue.issueName","issue.issueSize","issue.nominalCurrency","ISSUER_NAME","KEY","LIEN","MBS_ASSET_CLASS","MFCCONSOL","MOODYS_CURRENT","MOODYS_ORIG","MTG_CREDIT_ENHANCEMENT","MTG_GEN_TICKER","MTG_TRANCHE_TYP_LONG","ORIGINAL_DEAL_BALANCE","ORIGINAL_SUPPORT","P_RATIO","PAY_DELAY","POOL_MATURITY","PREPAYMENT_TYPE","PREPAYMENT_VALUE","REAL_ESTATE_OWNED","S_AND_P_CURRENT","S_AND_P_ORIG","SECURITY_TYPE","SENIORITY_TYPE","TIER","TRANCHE_NAME","UNDERLYING_SECURITY_TYPE","WAL","WALA"));

		// Simulate the fetch from cassandra
		Mockito.when(cqlProxy.getPrepareStatement( Mockito.anyString()) ).thenReturn(stmt);
		Mockito.when(resultset.iterator() ).thenReturn( rowsIterator );
		Mockito.when(stmt.bind() ).thenReturn(boundStatement);
		Mockito.when(cqlProxy.executeStatement( Mockito.any(Statement.class) ) ).thenReturn(resultset);						
		Mockito.when(cassandraSessionHelper.getProxy()).thenReturn(cqlProxy);
	}
}
