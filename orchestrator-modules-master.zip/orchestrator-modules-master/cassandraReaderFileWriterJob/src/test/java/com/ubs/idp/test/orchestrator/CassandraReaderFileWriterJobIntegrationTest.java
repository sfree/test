package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertEquals;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.metadata.client.MetadataService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:test-context.xml",
        "classpath:CassandraReaderFileWriterJob.xml" })
/* Turning these off as they get run as part of the current build
 * configuration. As we have changed this module to be a jar so 
 * that the unit tests are run.
 */
@Ignore 
public class CassandraReaderFileWriterJobIntegrationTest extends BaseJobTest {
	

    @Autowired
    private JobLauncherTestUtils jobLauncherTestUtils;

    @Autowired
    private MetadataService mds;

    
    public CassandraReaderFileWriterJobIntegrationTest() {
        super("AccountsAndRXM", "csv");
    }
    
    @Test
   // @Ignore
    public void launchJob() throws Exception {

        // testing a job
        jobExecution = jobLauncherTestUtils.launchJob(getJobParameters());
        assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
    }
}