package com.ubs.idp.test.orchestrator;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;

@Component
public class CassandraAndMetadataStub extends CustomBeanFactoryPostProcessor
{    
	private static Logger logger = LoggerFactory.getLogger(CassandraAndMetadataStub.class); 
	
    private PrintStream cassandraRecordsOutput;
    private PrintStream cassandraStatementOutput;

    public File outputFile;
    public File statementOutputFile;
    
	@Override
	public void finalize()
	{
		closeFiles();
	}


	public File getOutputFile()
	{
		return outputFile;
	}

	public File getStatementOutputFile()
	{
		return statementOutputFile;
	}

	public void setOutputFile(File outputFile) throws FileNotFoundException
	{
		this.outputFile = outputFile;
		closeRecordsFile();
		
		cassandraRecordsOutput = new PrintStream(outputFile);
	}

	public void setStatementOutputFile(File statementOutputFile) throws FileNotFoundException
	{
		this.statementOutputFile = statementOutputFile;
		closeStatementsFile();
		
		cassandraStatementOutput = new PrintStream(statementOutputFile);
	}

	
	public void closeFiles()
	{
		closeRecordsFile();
		closeStatementsFile();
	}
	
	public void closeRecordsFile()
	{
		if( cassandraRecordsOutput  != null )
		{
			cassandraRecordsOutput.close();
		}				
	}
	
	public void closeStatementsFile()
	{
		if( cassandraStatementOutput  != null )
		{
			cassandraStatementOutput.close();
		}				
	}


	@Override
	public void initialiseMocks()
	{
		initialiseMDSMocks();
		
		Mockito.when(cassandraSessionHelper.getProxy()).thenReturn(cqlProxy);
		
		// Create a custom statement that preserves the statement parameters
		Mockito.when( cqlProxy.getPrepareStatement( Mockito.anyString()) ).thenAnswer(new Answer<PreparedStatement>(){

			@Override
			public PreparedStatement answer(InvocationOnMock invocation) throws Throwable
			{
				if( invocation.getArguments() != null && 
					invocation.getArguments().length > 0 )
				{
					cassandraStatementOutput.println( invocation.getArguments()[0] );
					cassandraStatementOutput.flush();
				}
				
				// Create a new unique mock bound statement
				BoundStatement boundStatement = Mockito.mock(BoundStatement.class);
				Mockito.when( boundStatement.setString(Mockito.anyInt(), Mockito.anyString() )).then(new Answer<Void>(){

					// Save each parameter that gets added to each statement so that
					// we preserve a list of insert statements for the test run which can
					// be used for comparison
					@Override
					public Void answer(InvocationOnMock invocation) throws Throwable
					{	
						for( StackTraceElement stack : Thread.currentThread().getStackTrace() )
						{
							if( stack.getMethodName().equals("assembleMainInsert") )
							{
								int paramNumber = (Integer)invocation.getArguments()[0];
								String record = (String)invocation.getArguments()[1];
								
								if( paramNumber == 2 && !record.isEmpty() )
								{
									logger.info("Writing cassandra record to output '{}'",record);
									cassandraRecordsOutput.println(record);
									cassandraRecordsOutput.flush();
								}
							}
						}
						
						return null;
					}
				});
								
				PreparedStatement stmt = Mockito.mock(PreparedStatement.class);
				Mockito.when( stmt.bind() ).thenReturn(boundStatement);
				
				return stmt;
			}
		});
		
		// Enable the old row fetch to return data from our test file
		Mockito.when(cqlProxy.executeQuery( Mockito.anyString() ) ).thenAnswer(new Answer<List<Map<String,Object>>>(){

			@Override
			public List<Map<String, Object>> answer(InvocationOnMock invocation) throws Throwable
			{
				List<Map<String, Object>> data = new ArrayList<Map<String,Object>>();
				
				Map<String,Object> row1 = new HashMap<String,Object>();
				Map<String,Object> row2 = new HashMap<String,Object>();
				Map<String,Object> row3 = new HashMap<String,Object>();
				
				row1.put("key","RATING_Moodys_LT_LT_LOCL_10000443");
				row1.put("value","20130311022414000	20110129172044000	0	WR	WR			RATING	20021016	Moodys	LT	LT	LOCL	2	8	1	DCFSFR	BOND	CONVERTIBLE	USD	Y	DCFSFRCU	10000443");

				row2.put("key","RATING_SandP_STANDARD_LT_LOCL_10000443");
				row2.put("value","20130311022414000	20110129172044000	0	NR	NR			RATING	20020829	SandP	STANDARD	LT	LOCL	2	8	1	DCFSFR	BOND	CONVERTIBLE	USD	Y	DCFSFRCU	10000443");

				row3.put("key","RATING_BBMoodys_ST_ST_UTD_19981972");
				row3.put("value","20140612200414000	20131004051750000	0	P-1	P-1			RATING	20131003	BBMoodys	ST	ST	UTD	7	8	0	DYR-FR	BOND	MONEY_MARKET	USD		DYR-FRCB	19981972");
				
				data.add(row1);
				data.add(row2);
				data.add(row3);
				
				return data;
						
			}
			
		});			
	}
	
	
	private void initialiseMDSMocks()
	{
		// Mock all MDS calls made by the job definition
		Mockito.when(mdsStub.getDelimiter(Mockito.anyString())).thenReturn("\t");
		
		intialiseRatingDatasetMocks();
		intialiseEquityDatasetMocks();
	}
	
	private void intialiseRatingDatasetMocks()
	{
		Mockito.when(mdsStub.getTableIdForDataset("RATING")).thenReturn("RATING_LATEST_RAW");
		Mockito.when(mdsStub.getDatasetKeyAttributePositions("RATING")).thenReturn(Arrays.asList(7,9,10,11,12,22));
		Mockito.when(mdsStub.getAttributeNamesForDataset("RATING")).thenReturn(Arrays.asList("event.lastUpdatedTime","issueRating.lastUpdatedTime","issueRating.isProvisional","issueRating.code","issueRating.rawCode","issueRating.structuredFinanceInd","issueRating.endorsementInd","issueRating.recordType","issueRating.validDate","issueRating.ratingAgency","issueRating.ratingGroup","issueRating.ratingType","issueRating.currencyType","event.majorVersion","issue.majorVersion","issue.active","issue.isoCfi","issue.assetClass","issue.assetType","issue.nominalCurrency","issue.ubsTradable","issue.ubsIsoCfi","issue.ubsId"));
		Mockito.when(mdsStub.getQueryableAttributePositionsForDataset("RATING")).thenReturn(Arrays.asList(22));
		Mockito.when(mdsStub.getTransformerRulesetsForDatasets("RATING","RATING")).thenReturn(Arrays.asList("com.ubs.idp.orchestrator.processor.rules.treasuryar.RatingBlankRowFilterRule"));

	}

	private void intialiseEquityDatasetMocks()
	{
		Mockito.when(mdsStub.getDatasetKeyAttributePositions("EQUITYTL")).thenReturn(Arrays.asList(83));
		Mockito.when(mdsStub.getAttributeNamesForDataset("EQUITY")).thenReturn(Arrays.asList("issue.issueDate","issue.sharesOutstanding","issue.sharesOutstandingDate","issue.rule144A3c7Ind","issue.votesPerShare","tL.portfolioMarginableCode","tL.illiquidStock","tL.bbCompositeExchange","basket.divisor","basket.numOfConstituents","settle.dtcEligible","issuer.ubsPartnerId","issuer.ubsId","undl.tlUbsId","undl.issueUbsId","undl.assetClass","undl.majorVersion","undl.lastUpdatedTime","undl.bbTicker","undl.sedol","issue.standardMarketSize","issue.isOfQuality","tL.settleCalendar","issue.shortName","settle.settleCalendar","issue.amountOutstanding","issue.fosProductGroup","issue.nikkeiStockType","issue.tseIndustryCode","issue.issueName/kanji","issue.shortName/kanji","issue.nikkeiIndustryCode","issue.frenchTransactionTax","tL.firstTradeDate","tL.indicativeNavRic","tL.pmNavSymbol","tL.risklessPrincipal","tL.nikkeiInvTrustType","tL.maxTradableQuantity","tL.maxTradableLot","equity.stockSplitDate","issue.fosGovtClass","issue.hasListing","issue.fosCalcCode","issue.amountOutstandingDate","issue.fos","issue.isStopTrade","issue.lastUpdatedTime","issue.majorVersion","issue.active","issue.status","issue.isoCfi","issue.assetClass","issue.assetType","issue.securityType","issue.bbSecurityType","issue.cusip","issue.common","issue.isin","issue.valoren","issue.wertpapier","issue.securityFormType","issue.nominalCurrency","issue.restrictedListCode","issue.cins","issue.restrictedOffTime","issue.restrictedOnTime","issue.nominalValueOfUnit","issue.mifidLiquidStk","issue.ubsTradable","issue.mifidTradeRep","issue.stdMarketSize","issue.mifidAvgDailyTurnover","issue.mifidAvgDailyTurnoverCcy","issue.mifidMarket","issue.mifidStdMktSizeCurrency","issue.mifidMostrelvMktCurrency","issue.issueName","issue.restrictedClass","issue.restrictedForResearch","issue.restrictionPriority","issue.restrictedForSales","issue.restrictedForTrading","issue.restrictedForPADealing","issue.restrictionComment","issue.sharesPerDepositoryReceipt","issue.regSInd","issue.rule144AInd","issue.adpClassification","issue.taxableCode","issue.quick","issue.adrPerShare","issue.isMultipleShare","issue.bbPrimSecCompExchange","issue.bbPrimSecPrimExchange","issue.ftaClass","issue.ubsId","tL.countryUbsId","tL.majorVersion","tL.lastUpdatedTime","tL.active","tL.status","tL.tickSize","tL.tidm","tL.exchange","tL.currency","tL.lotSize","tL.bbUnique","tL.sedol","tL.quotationType","tL.ticker","tL.tradeCountry","tL.bbTicker","tL.ric","tL.bbTickerExchange","tL.localCode","tL.bbSecurity","tL.roundLotSize","tL.ubsMarketMaker","tL.coltMn","tL.cubsInstrCode","tL.tradingLineName","tL.bbExchange","tL.isdaRegion","tL.opol","tL.regShoCatA","tL.euronext","tL.regShoCatB","tL.consolidatedThresholdInd","tL.etbExternal","tL.etbInternal","tL.whenIssuedFlag","tL.ipoFlag","tL.lastTradeDate","tL.marketSegment","tL.consolidatedListingInd","tL.opolInd","tL.bbCurrency","tL.ricOfIntInd","tL.pinkQuotable","tL.marketSettleVenue","tL.mifidFungibleId","tL.pmSymbol","tL.isdaRelExchCode","tL.isdaRelRtrsExchCode","tL.mifidMktSettleVenueName","tL.mifidubsMostLiquidVenue","tL.dmlMnemonic","tL.traxInd","tL.freeFloatPercent","tL.quoteLotSize","tL.normalMarketSize","tL.calendar","tL.orderRoutingRule","tL.countryOfRegistration","tL.fiiRestrictionInd","tL.auctionSession","tL.t13","tL.isOptionable","tL.relativeIndex","tL.adpId","tL.marginableCode","tL.occMarginableCode","tL.earningsPerShare","tL.bbPrimaryExchange","tL.lniClass","tL.takeoverMarker","tL.takeoverDate","tL.quick","tL.ubsId","equity.lastUpdatedTime","equity.majorVersion","equity.dividendCurrency","equity.dividendPerShare","equity.dividendType","equity.dividendFrequency","equity.dividendPayDate","equity.dividendRecordDate","equity.dividendDeclaredDate","equity.dividendExDate","equity.ipoDate","settle.majorVersion","settle.lastUpdatedTime","settle.seaqReportingInd","settle.crestInd","settle.firstSettleDate","settle.lastSettleDate","settle.ptmLevyApplicable","settle.euroclearInd","settle.stampInd","settle.crestStampDutyInd","settle.calendar","settle.date","issuer.lastUpdatedTime","issuer.majorVersion","issuer.issuerName","issuer.countryOfIncorporation","issuer.cconsol","issuer.bbCompany","issuer.icbIndustry","issuer.icbSector","issuer.icbSubsector","issuer.icbSupersector","issuer.fidbCode","issuer.countryOfDomicile","issuer.countryOfRisk","issuer.ubsPartyId","event.majorVersion","event.lastUpdatedTime"));
		Mockito.when(mdsStub.getAttributeNamesForDataset("EQUITYTL")).thenReturn(Arrays.asList("tL.portfolioMarginableCode","tL.illiquidStock","tL.bbCompositeExchange","tL.settleCalendar","tL.firstTradeDate","tL.indicativeNavRic","tL.pmNavSymbol","tL.risklessPrincipal","tL.nikkeiInvTrustType","tL.maxTradableQuantity","tL.maxTradableLot","tL.countryUbsId","tL.majorVersion","tL.lastUpdatedTime","tL.active","tL.status","tL.tickSize","tL.tidm","tL.exchange","tL.currency","tL.lotSize","tL.bbUnique","tL.sedol","tL.quotationType","tL.ticker","tL.tradeCountry","tL.bbTicker","tL.ric","tL.bbTickerExchange","tL.localCode","tL.bbSecurity","tL.roundLotSize","tL.ubsMarketMaker","tL.coltMn","tL.cubsInstrCode","tL.tradingLineName","tL.bbExchange","tL.isdaRegion","tL.opol","tL.regShoCatA","tL.euronext","tL.regShoCatB","tL.consolidatedThresholdInd","tL.etbExternal","tL.etbInternal","tL.whenIssuedFlag","tL.ipoFlag","tL.lastTradeDate","tL.marketSegment","tL.consolidatedListingInd","tL.opolInd","tL.bbCurrency","tL.ricOfIntInd","tL.pinkQuotable","tL.marketSettleVenue","tL.mifidFungibleId","tL.pmSymbol","tL.isdaRelExchCode","tL.isdaRelRtrsExchCode","tL.mifidMktSettleVenueName","tL.mifidubsMostLiquidVenue","tL.dmlMnemonic","tL.traxInd","tL.freeFloatPercent","tL.quoteLotSize","tL.normalMarketSize","tL.calendar","tL.orderRoutingRule","tL.countryOfRegistration","tL.fiiRestrictionInd","tL.auctionSession","tL.t13","tL.isOptionable","tL.relativeIndex","tL.adpId","tL.marginableCode","tL.occMarginableCode","tL.earningsPerShare","tL.bbPrimaryExchange","tL.lniClass","tL.takeoverMarker","tL.takeoverDate","tL.quick","tL.ubsId","issue.ubsId","issue.majorVersion","event.majorVersion","issue.lastUpdatedTime","event.lastUpdatedTime"));
		Mockito.when(mdsStub.getQueryableAttributePositionsForDataset("EQUITYTL")).thenReturn(Arrays.asList(18, 22, 24, 83, 84));

		Mockito.when(mdsStub.getDatasetKeyAttributePositions("EQUITYISSUE")).thenReturn(Arrays.asList(100));
		Mockito.when(mdsStub.getAttributeNamesForDataset("EQUITYISSUE")).thenReturn(Arrays.asList("issue.issueDate","issuer.cconsol","issuer.lastUpdatedTime","issuer.majorVersion","issuer.issuerName","issuer.countryOfIncorporation","issuer.bbCompany","issuer.icbIndustry","issuer.icbSector","issuer.icbSubsector","issuer.icbSupersector","issuer.fidbCode","issuer.countryOfDomicile","issuer.countryOfRisk","issuer.ubsPartyId","issuer.ubsPartnerId","issuer.ubsId","issue.sharesOutstanding","issue.sharesOutstandingDate","issue.rule144A3c7Ind","issue.votesPerShare","basket.divisor","basket.numOfConstituents","settle.dtcEligible","undl.tlUbsId","undl.issueUbsId","undl.assetClass","undl.majorVersion","undl.lastUpdatedTime","undl.bbTicker","undl.sedol","issue.standardMarketSize","issue.isOfQuality","issue.shortName","settle.settleCalendar","issue.amountOutstanding","issue.fosProductGroup","issue.nikkeiStockType","issue.tseIndustryCode","issue.issueName/kanji","issue.shortName/kanji","issue.nikkeiIndustryCode","issue.frenchTransactionTax","equity.stockSplitDate","issue.fosGovtClass","issue.hasListing","issue.fosCalcCode","issue.amountOutstandingDate","issue.fos","issue.isStopTrade","issue.lastUpdatedTime","issue.majorVersion","issue.active","issue.status","issue.isoCfi","issue.assetClass","issue.assetType","issue.securityType","issue.bbSecurityType","issue.cusip","issue.common","issue.isin","issue.valoren","issue.wertpapier","issue.securityFormType","issue.nominalCurrency","issue.restrictedListCode","issue.cins","issue.restrictedOffTime","issue.restrictedOnTime","issue.nominalValueOfUnit","issue.mifidLiquidStk","issue.ubsTradable","issue.mifidTradeRep","issue.stdMarketSize","issue.mifidAvgDailyTurnover","issue.mifidAvgDailyTurnoverCcy","issue.mifidMarket","issue.mifidStdMktSizeCurrency","issue.mifidMostrelvMktCurrency","issue.issueName","issue.restrictedClass","issue.restrictedForResearch","issue.restrictionPriority","issue.restrictedForSales","issue.restrictedForTrading","issue.restrictedForPADealing","issue.restrictionComment","issue.sharesPerDepositoryReceipt","issue.regSInd","issue.rule144AInd","issue.adpClassification","issue.taxableCode","issue.quick","issue.adrPerShare","issue.isMultipleShare","issue.bbPrimSecCompExchange","issue.bbPrimSecPrimExchange","issue.ftaClass","issue.ubsId","equity.lastUpdatedTime","equity.majorVersion","equity.dividendCurrency","equity.dividendPerShare","equity.dividendType","equity.dividendFrequency","equity.dividendPayDate","equity.dividendRecordDate","equity.dividendDeclaredDate","equity.dividendExDate","equity.ipoDate","settle.majorVersion","settle.lastUpdatedTime","settle.seaqReportingInd","settle.crestInd","settle.firstSettleDate","settle.lastSettleDate","settle.ptmLevyApplicable","settle.euroclearInd","settle.stampInd","settle.crestStampDutyInd","settle.calendar","settle.date","event.majorVersion","event.lastUpdatedTime"));
		Mockito.when(mdsStub.getQueryableAttributePositionsForDataset("EQUITYISSUE")).thenReturn(Arrays.asList(31, 60, 62, 100));
	}

}
