package com.ubs.idp.test.orchestrator;

import static org.junit.Assert.assertEquals;

import java.io.File;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-context1.xml", "classpath:FileReaderProcessorCassandraWriterJob.xml" })
public class RatingTest extends FileReaderProcessorCassandraWriterJobTest
{
    static {
        System.setProperty("environment", "rating");
    }
    
    @Test
    public void testHappyPath() throws Exception {
    	
    	filename = "RATING.txt";
    	compareFilename = "RATING_COMPARE.csv";
    	statementCompareFilename = "RATING_COMPARE_STATEMENTS.txt";
    	jobLaunch();
    }
    
    @Test
    public void testFileWithErrors() throws Exception {
    	filename = "RATING_WITH_ERRORS.txt";
    	compareFilename = "RATING_COMPARE.csv";
    	statementCompareFilename = "RATING_COMPARE_STATEMENTS.txt";

    	jobLaunch();

    	// Make sure there are no error files
    	assertEquals("Unexpected error file",0,new File(errorDirPath).list().length );
    }	

    @Test
    public void testWithLargeFile() throws Exception {
    	filename = "RATING_PLUS_100_RECORDS.txt";
    	compareFilename = "RATING_COMPARE_PLUS_100_RECORDS.csv";
    	statementCompareFilename = "RATING_COMPARE_STATEMENTS.txt";

    	jobLaunch();

    }	
} 