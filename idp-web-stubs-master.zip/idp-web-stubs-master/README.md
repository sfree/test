idp-web-stubs
=============

A collection of end point stubs to be used for testing HTTP endpoints
