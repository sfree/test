drop table TEST if exists;
create table TEST(dataIn VARCHAR(20));