package com.ubs.idp.orchestrator.tasklets;

import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class JdbcEventManagerTaskletTest {
	
	private NamedParameterJdbcTemplate mockedJdbcTemplate;
	private DataSource mockedDataSource;
	private JdbcEventManagerTasklet eventManager;
	
	@Before
	public void setup() {
		
		eventManager = new JdbcEventManagerTasklet();
		mockedJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		mockedDataSource = mock(DataSource.class);
		
		eventManager.setJdbcTemplate(mockedJdbcTemplate);
		eventManager.setDataSource(mockedDataSource);
		eventManager.setFindBulkUpdateQuery("testQuery");
		eventManager.setDeprioritizeQuery("testQuery");
		eventManager.setCsvStreams("BPS");
		
		List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
		Map<String, Object> row1 = new HashMap<String, Object>();
		row1.put("STREAM", "BPS");
		row1.put("MINUTE_SLICE", new BigDecimal(1));
		Map<String, Object> row2 = new HashMap<String, Object>();
		row2.put("STREAM", "ICI");
		row2.put("MINUTE_SLICE", new BigDecimal(3));
		rows.add(row1);
		rows.add(row2);
		when(mockedJdbcTemplate.queryForList(any(String.class), any(MapSqlParameterSource.class))).thenReturn(rows);
		when(mockedJdbcTemplate.update(any(String.class), any(MapSqlParameterSource.class))).thenReturn(1);
	}

	@Test
	public void executeTest() throws Exception {
		eventManager.afterPropertiesSet();
		eventManager.init();
		eventManager.setJdbcTemplate(mockedJdbcTemplate);
		RepeatStatus status = eventManager.execute(null, null);
		
		Assert.assertEquals(RepeatStatus.FINISHED, status);
	}

}
