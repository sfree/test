package com.ubs.idp.connector;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Map;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.datastax.driver.core.ConsistencyLevel;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:cassandra-test-context.xml" })
public class CassandraCqlProxyTest {
    
    public static final String TEST_TABLE = CassandraCqlProxyTest.class.getSimpleName().toLowerCase();
    public static final String CREATE_TABLE_DDL = "create table " + TEST_TABLE + " (key text primary key, data text) with compact storage;";
    public static final String DROP_TABLE_DDL = "drop table " + TEST_TABLE + ";";
    public static final String INSERT_DATA_CQL = "insert into " + TEST_TABLE + " (key, data) values (':key', ':data');";
    public static final String SELECT_COUNT_CQL = "select count(*) from " + TEST_TABLE + ";";
    
	@Autowired
	@Qualifier("cassandraSessionHelper")
	private CassandraSessionHelper cassandraSessionHelper;

	@Test
	@Ignore
	public void simpleConnectTest() {
	    
	    CassandraCqlProxy cassandraCqlProxy = cassandraSessionHelper.getProxy();

		assertTrue("Failed to connect!", cassandraCqlProxy.isConnected());
	}
    
    @Test
    @Ignore
    public void createInsertDeleteDropTest() {
        
        CassandraCqlProxy cassandraCqlProxy = cassandraSessionHelper.getProxy();
        
        assertTrue("Failed to connect!", cassandraCqlProxy.isConnected());

        // Create table
        
        cassandraCqlProxy.executeStatement(CREATE_TABLE_DDL, ConsistencyLevel.ALL);

        // Insert Nx rows and read them back (consistent write)
        
        final int nRows = 10;

        for(int i = 0 ; i < nRows ; i++) {
            String cql = INSERT_DATA_CQL
                            .replace(":key", "KeyA" + i)
                            .replace(":data", "Data item " + i);
            
            cassandraCqlProxy.executeStatement(cql, ConsistencyLevel.ALL);
        }
        
        List<Map<String, Object>> res = cassandraCqlProxy.executeQuery(SELECT_COUNT_CQL);
        
        // Insert Nx rows and read them back (eventually consistent write)

        for(int i = 0 ; i < nRows ; i++) {
            String cql = INSERT_DATA_CQL
                            .replace(":key", "KeyB" + i)
                            .replace(":data", "Data item " + i);
            
            cassandraCqlProxy.executeStatement(cql);
        }
        
        // Throw away read (manual testing of dropping nodes in cluster)
        
        cassandraCqlProxy.executeQuery(SELECT_COUNT_CQL);
        
        // Tidy up and shut down (manually re-start any nodes stopped above before attempting a ConsistencyLevel.ALL statement)

        cassandraCqlProxy.executeStatement(DROP_TABLE_DDL, ConsistencyLevel.ALL);
        
        // Check results
        
        assertNotNull("Null result?", res);
        assertEquals("Unexpected row count?", 1, res.size());
        
        Map<String, Object> row = res.get(0);
        
        assertNotNull("Null entry in results?", row);
        assertEquals("Unexpected row value count?", 1, row.size());
        
        int count = Integer.parseInt(row.get("count").toString());
        
        assertEquals("Unexpected row count?", nRows, count);
    }
}
