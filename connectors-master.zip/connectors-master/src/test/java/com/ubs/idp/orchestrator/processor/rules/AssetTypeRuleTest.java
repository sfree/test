package com.ubs.idp.orchestrator.processor.rules;

import static com.ubs.idp.orchestrator.processor.rules.AssetTypeRuleTest.InputBuilder.newInput;
import static com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate.BLOOMBERG_INDUSTRY_GROUP;
import static com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate.BLOOMBERG_INDUSTRY_SUBGROUP;
import static com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate.BLOOMBERG_SECURITY_TYPE;
import static com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate.BLOOMBERG_YELLOW_KEY;
import static com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate.COLLATERAL_TYPE;
import static com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate.DERIVED_ASSET_TYPE;
import static com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate.MARKET_ISSUE_TYPE;
import static com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate.UBS_CFI_CODE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.AssetTypeRule;

public class AssetTypeRuleTest {

	private AssetTypeRule rule;

	@Before
	public void setUp() throws Exception {
		rule = new AssetTypeRule();
	}

	@Test
	public void testForUS75970QAH39() throws Exception {
		Map<String, Object> results = rule.process(newInput().withIsin("US75970QAH39")
				.withCfiCode("DBSAF-CU").withBbSecurityType("ABS Home").withBbYellowKey("Mtge")
				.withCollateralType("ASSET BACKED").build());

		verifyEquals(results, "ABS");
	}

	/*
	 * If bbg yellowkey is 'Govt' and bbg industry group is 'Sovereign' and bbg industry subgroup is
	 * 'Sovereign' then asset type is 'Government'
	 */
	@Test
	public void shouldDeriveGovernment() throws Exception {
		Map<String, Object> results = rule.process(newInput().withBbYellowKey("Govt")
				.withBbIndustryGroup("Sovereign").withBbIndustrySubgroup("Sovereign").build());
		verifyEquals(results, "Government");
	}

	@Test
	public void shouldNotDeriveGovernment() throws Exception {
		Map<String, Object> results = rule.process(newInput().withBbYellowKey("Govt1")
				.withBbIndustryGroup("Sovereign").withBbIndustrySubgroup("Sovereign").build());
		verifyNotEquals(results, "Government");

		results = rule.process(newInput().withBbYellowKey("Govt").withBbIndustryGroup("Sovereign1")
				.withBbIndustrySubgroup("Sovereign").build());
		verifyNotEquals(results, "Government");

		results = rule.process(newInput().withBbYellowKey("Govt").withBbIndustryGroup("Sovereign")
				.withBbIndustrySubgroup("Sovereign1").build());
		verifyNotEquals(results, "Government");
	}

	/*
	 * If UBS cfi code 1th char is 'D' and 7th char is not 'G' and 4th char is 'R' then asset type
	 * is 'MBS'
	 */
	@Test
	public void shouldDeriveMbsUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("D--R----").build());
		verifyEquals(results, "MBS");
	}

	@Test
	public void shouldNotDeriveMbsUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("D--R--G-").build());
		verifyNotEquals(results, "MBS");
	}

	/*
	 * If UBS cfi code 1th char is 'D' and 7th char is not 'G' and 4th char is 'A' then asset type
	 * is 'ABS'
	 */
	@Test
	public void shouldDeriveAbsUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("D--A----").build());
		verifyEquals(results, "ABS");
	}

	@Test
	public void shouldNotDeriveAbsUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("D--A--G-").build());
		verifyNotEquals(results, "ABS");
	}

	/*
	 * If bbg yellowkey is 'Mtge' and collateral type is like '%MORTGAGE%BACKED%' then asset type is
	 * 'MBS'
	 */
	@Test
	public void shouldDeriveMbsUsingCollType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withBbYellowKey("Mtge")
				.withCollateralType("MORTGAGE BACKED").build());
		verifyEquals(results, "MBS");
	}

	@Test
	public void shouldNotDeriveMbs() throws Exception {
		Map<String, Object> results = rule.process(newInput().withBbYellowKey("Mtge")
				.withCollateralType(null).build());
		verifyNotEquals(results, "MBS");

		results = rule.process(newInput().withBbYellowKey("Mtge")
				.withCollateralType("MORTGAGE B4CK3D").build());
		verifyNotEquals(results, "MBS");
	}

	/*
	 * If bbg yellowkey is 'Mtge' and collateral type is like '%ASSET%BACKED%' then asset type is
	 * 'ABS'
	 */
	@Test
	public void shouldDeriveAbsUsingCollType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withBbYellowKey("Mtge")
				.withCollateralType("ASSET BACKED").build());
		verifyEquals(results, "ABS");
	}

	@Test
	public void shouldNotDeriveAbs() throws Exception {
		Map<String, Object> results = rule.process(newInput().withBbYellowKey("Mtge")
				.withCollateralType(null).build());
		verifyNotEquals(results, "ABS");

		results = rule.process(newInput().withBbYellowKey("Mtge")
				.withCollateralType("ASSET B4CK3D").build());
		verifyNotEquals(results, "ABS");
	}

	/*
	 * If UBS cfi code 1th char is 'D' and 7th char is 'G' then asset type is 'Government'
	 */
	@Test
	public void shouldDeriveGovernmentUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("D-----G-").build());
		verifyEquals(results, "Government");
	}

	/*
	 * If collateral type is like '%JUMBO%PFANDBRIEFE%' then asset type is 'Jumbo Pfandbrief'
	 */
	@Test
	public void shouldDeriveJumboPfandbriefUsingCollType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCollateralType(
				"JUMBO PFANDBRIEFE").build());
		verifyEquals(results, "Jumbo Pfandbrief");
	}

	/*
	 * If collateral type is like '%PFANDBRIEFE%' then asset type is 'Pfandbrief'
	 */
	@Test
	public void shouldDerivePfandbriefUsingCollType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCollateralType("PFANDBRIEFE")
				.build());
		verifyEquals(results, "Pfandbrief");
	}

	/*
	 * If UBS cfi code 1th char is 'D' and 7th char is 'D' then asset type is 'Certificates of
	 * Deposit'
	 */
	@Test
	public void shouldDeriveCertOfDepositUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("D-----D-").build());
		verifyEquals(results, "Certificates of Deposit");
	}

	/*
	 * If UBS cfi code starts with 'DY' and (collateral type is like '%CERT%OF%DEPOSIT%' or
	 * '%DEPOSIT%NOTES%') then asset type is 'Certificates of Deposit'
	 */
	@Test
	public void shouldDeriveCertOfDepositUsingCollType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("DY------")
				.withCollateralType("CERT OF DEPOSIT").build());
		verifyEquals(results, "Certificates of Deposit");

		results = rule.process(newInput().withCfiCode("DY------")
				.withCollateralType("DEPOSIT NOTES").build());
		verifyEquals(results, "Certificates of Deposit");
	}

	@Test
	public void shouldNotDeriveCertOfDepositUsingCollType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("DY------")
				.withCollateralType(null).build());
		verifyNotEquals(results, "Certificates of Deposit");

		results = rule.process(newInput().withCfiCode("DY------")
				.withCollateralType("C3RT 0F D3P0S1T").build());
		verifyNotEquals(results, "Certificates of Deposit");

		results = rule.process(newInput().withCfiCode("DY------")
				.withCollateralType("D3P0S1T N0T3S").build());
		verifyNotEquals(results, "Certificates of Deposit");
	}

	/*
	 * If market issue type is 'MoneyMarket' then asset type is 'Commercial Paper'
	 */
	@Test
	public void shouldDeriveCommercialPaperUsingMarketType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withMarketIssueType("MoneyMarket")
				.build());
		verifyEquals(results, "Commercial Paper");
	}

	/*
	 * If UBS cfi code starts with 'DY' and (collateral type is not like '%CERT%OF%DEPOSIT%' or
	 * '%DEPOSIT%NOTES%') then asset type is 'Commercial Paper'
	 */
	@Test
	public void shouldDeriveCommercialPaperUsingCollType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("DY------")
				.withCollateralType("COMMERCIAL PAPER").build());
		verifyEquals(results, "Commercial Paper");
	}

	@Test
	public void shouldNotDeriveCommercialPaperUsingCollType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("DY------")
				.withCollateralType(null).build());
		verifyNotEquals(results, "Commercial Paper");

		results = rule.process(newInput().withCfiCode("DY------")
				.withCollateralType("CERT OF DEPOSIT").build());
		verifyNotEquals(results, "Commercial Paper");

		results = rule.process(newInput().withCfiCode("DY------")
				.withCollateralType("DEPOSIT NOTES").build());
		verifyNotEquals(results, "Commercial Paper");
	}

	/*
	 * If UBS cfi code starts with 'DC' then asset type is 'Corporate'
	 */
	@Test
	public void shouldDeriveCorporateUsingCfi1() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("DC------").build());
		verifyEquals(results, "Corporate");
	}

	/*
	 * If UBS cfi code 1th char is 'D' and 7th char is one of 'C', 'M', 'I', 'E' or 'K' then asset
	 * type is 'Corporate'
	 */
	@Test
	public void shouldDeriveCorporateUsingCfi2() throws Exception {
		for (String elem : Arrays.asList("C", "M", "I", "E", "K")) {
			Map<String, Object> results = rule.process(newInput().withCfiCode(
					String.format("D-----%s-", elem)).build());
			verifyEquals(results, "Corporate");
		}
	}

	/*
	 * If UBS cfi code 1th char is 'D' and 7th char is 'S' then asset type is 'Supranational'
	 */
	@Test
	public void shouldDeriveSupranationalUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("D-----S-").build());
		verifyEquals(results, "Supranational");
	}

	@Test
	public void shouldNotDeriveSupranationalUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("D-----X-").build());
		verifyNotEquals(results, "Supranational");
	}

	/*
	 * If UBS cfi code 1th char is 'D' and 7th char is 'L' then asset type is 'Municipal'
	 */
	@Test
	public void shouldDeriveMunicipalUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("D-----L-").build());
		verifyEquals(results, "Municipal");
	}

	@Test
	public void shouldNotDeriveMunicipalUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("D-----X-").build());
		verifyNotEquals(results, "Municipal");
	}

	/*
	 * If UBS cfi code 1th char is 'D' and 7th char is 'A' then asset type is 'Agency'
	 */
	@Test
	public void shouldDeriveAgencyUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("D-----A-").build());
		verifyEquals(results, "Agency");
	}

	@Test
	public void shouldNotDeriveAgencyUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("D-----X-").build());
		verifyNotEquals(results, "Agency");
	}

	/*
	 * If bbg security type is one of 'GDR', 'EDR' or 'REIT' then asset type is bbg security type
	 */
	@Test
	public void shouldDeriveGdrUsingSecType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withBbSecurityType("GDR").build());
		verifyEquals(results, "GDR");
	}

	@Test
	public void shouldDeriveEdrUsingSecType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withBbSecurityType("EDR").build());
		verifyEquals(results, "EDR");
	}

	@Test
	public void shouldDeriveReitUsingSecType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withBbSecurityType("REIT").build());
		verifyEquals(results, "REIT");
	}

	/*
	 * If bbg security type is one of 'ADR', 'BDR' or 'IDR' then asset type is 'ADR'
	 */
	@Test
	public void shouldDeriveAdrUsingSecType() throws Exception {
		for (String elem : Arrays.asList("ADR", "BDR", "IDR")) {
			Map<String, Object> results = rule.process(newInput().withBbSecurityType(elem).build());
			verifyEquals(results, "ADR");
		}
	}

	@Test
	public void shouldNotDeriveAdrUsingSecType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withBbSecurityType(null).build());
		verifyNotEquals(results, "ADR");

		results = rule.process(newInput().withBbSecurityType("ADRBDR").build());
		verifyNotEquals(results, "ADR");
	}

	/*
	 * If bbg security type is 'PREFERENCE' (case insensitive) then asset type is 'Preference'
	 */
	@Test
	public void shouldDerivePreferenceUsingSecType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withBbSecurityType("PREFERENCE")
				.build());
		verifyEquals(results, "Preference");

		results = rule.process(newInput().withBbSecurityType("Preference").build());
		verifyEquals(results, "Preference");

		results = rule.process(newInput().withBbSecurityType("PrEfErEnCe").build());
		verifyEquals(results, "Preference");
	}

	/*
	 * If bbg security type is one of 'ETF', 'ETN' or 'ETC' then asset type is 'ETF'
	 */
	@Test
	public void shouldDeriveEtfUsingSecType() throws Exception {
		for (String elem : Arrays.asList("ETF", "ETN", "ETC")) {
			Map<String, Object> results = rule.process(newInput().withBbSecurityType(elem).build());
			verifyEquals(results, "ETF");
		}
	}

	@Test
	public void shouldNotDeriveEtfUsingSecType() throws Exception {
		Map<String, Object> results = rule.process(newInput().withBbSecurityType(null).build());
		verifyNotEquals(results, "ETF");

		results = rule.process(newInput().withBbSecurityType("ETFETN").build());
		verifyNotEquals(results, "ETF");
	}

	/*
	 * If UBS cfi code 5th char is 'A' then asset type is 'ADR'
	 */
	@Test
	public void shouldDeriveAdrUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("----A---").build());
		verifyEquals(results, "ADR");
	}

	/*
	 * If UBS cfi code starts with 'EP' then asset type is 'Preference'
	 */
	@Test
	public void shouldDerivePreferenceUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("EP------").build());
		verifyEquals(results, "Preference");
	}

	/*
	 * If UBS cfi code starts with 'EC' then asset type is 'Convertible Preference Shares'
	 */
	@Test
	public void shouldDeriveConvPrefSharesUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("EC------").build());
		verifyEquals(results, "Convertible Preference Shares");
	}

	/*
	 * If UBS cfi code starts with 'EU' then asset type is 'UIT'
	 */
	@Test
	public void shouldDeriveUitUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("EU------").build());
		verifyEquals(results, "UIT");
	}

	/*
	 * If UBS cfi code starts with 'RM' then asset type is 'Rights'
	 */
	@Test
	public void shouldDeriveRightsUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("RM------").build());
		verifyEquals(results, "Rights");
	}

	/*
	 * If UBS cfi code starts with 'RW' or 'MM' then asset type is 'Warrant'
	 */
	@Test
	public void shouldDeriveWarrantUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("RW------").build());
		verifyEquals(results, "Warrant");
		results = rule.process(newInput().withCfiCode("MM------").build());
		verifyEquals(results, "Warrant");
	}

	/*
	 * If UBS cfi code starts with 'ES' or 'EM' then asset type is 'Common Equity'
	 */
	@Test
	public void shouldDeriveCommonEquityUsingCfi() throws Exception {
		Map<String, Object> results = rule.process(newInput().withCfiCode("ES------").build());
		verifyEquals(results, "Common Equity");
		results = rule.process(newInput().withCfiCode("EM------").build());
		verifyEquals(results, "Common Equity");
	}

	@Test
	public void shouldDeriveUnknown() throws Exception {
		Map<String, Object> results = rule.process(newInput().build());
		verifyEquals(results, "Unknown");
	}

	private void verifyEquals(Map<String, Object> results, String expected) {
		assertNotNull(results.get(DERIVED_ASSET_TYPE));
		assertEquals(expected, results.get(DERIVED_ASSET_TYPE));
	}

	private void verifyNotEquals(Map<String, Object> results, String... expected) {
		assertNotNull(results.get(DERIVED_ASSET_TYPE));
		for (String elem : expected) {
			assertNotEquals(elem, results.get(DERIVED_ASSET_TYPE));
		}
	}

	static class InputBuilder {

		private Map<String, Object> input;

		public InputBuilder() {
			input = new HashMap<>();
			// Assume a default CFI code is set
			input.put(UBS_CFI_CODE, "--------");
		}

		public static InputBuilder newInput() {
			return new InputBuilder();
		}

		public InputBuilder withIsin(String isin) {
			input.put("issue.isin", isin);
			return this;
		}

		public InputBuilder withBbYellowKey(String bbYellowKey) {
			input.put(BLOOMBERG_YELLOW_KEY, bbYellowKey);
			return this;
		}

		public InputBuilder withBbIndustryGroup(String bbIndustryGroup) {
			input.put(BLOOMBERG_INDUSTRY_GROUP, bbIndustryGroup);
			return this;
		}

		public InputBuilder withBbIndustrySubgroup(String bbIndustrySubgroup) {
			input.put(BLOOMBERG_INDUSTRY_SUBGROUP, bbIndustrySubgroup);
			return this;
		}

		public InputBuilder withCfiCode(String cfiCode) {
			if (cfiCode.length() != 8) {
				throw new IllegalArgumentException("UBS CFI Code needs to be 8 characters long");
			}
			input.put(UBS_CFI_CODE, cfiCode);
			return this;
		}

		public InputBuilder withCollateralType(String collateralType) {
			input.put(COLLATERAL_TYPE, collateralType);
			return this;
		}

		public InputBuilder withMarketIssueType(String marketIssueType) {
			input.put(MARKET_ISSUE_TYPE, marketIssueType);
			return this;
		}

		public InputBuilder withBbSecurityType(String bbSecurityType) {
			input.put(BLOOMBERG_SECURITY_TYPE, bbSecurityType);
			return this;
		}

		public Map<String, Object> build() {
			return input;
		}
	}
}
