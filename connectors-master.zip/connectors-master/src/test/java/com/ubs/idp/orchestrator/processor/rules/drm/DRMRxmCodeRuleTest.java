package com.ubs.idp.orchestrator.processor.rules.drm;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;

public class DRMRxmCodeRuleTest {

    private DRMRxmCodeRule rule;

    private CassandraSessionHelper helper;

    private CassandraCqlProxy proxy;

    private BoundStatement boundStmt1;

    @Before
    public void setUp() throws Exception {
        rule = new DRMRxmCodeRule();
        helper = mock(CassandraSessionHelper.class);
        ReflectionTestUtils.setField(rule, "cassandraSessionHelper", helper);
    }

    @SuppressWarnings("unchecked")
    private void setupCassandraProxy() {
        proxy = mock(CassandraCqlProxy.class);
        ReflectionTestUtils.setField(rule, "proxy", proxy);

        PreparedStatement preparedStmt1 = mock(PreparedStatement.class);
        when(proxy.getPrepareStatement(anyString())).thenReturn(preparedStmt1);

        boundStmt1 = mock(BoundStatement.class);
        when(preparedStmt1.bind("100076")).thenReturn(boundStmt1);
        when(preparedStmt1.bind("2022351")).thenReturn(boundStmt1);

        ResultSet rs = mock(ResultSet.class);
        when(proxy.executeStatement(boundStmt1)).thenReturn(rs);

        Row row = mock(Row.class);
        List<Row> rows = Arrays.asList(row);
        when(rs.iterator()).thenReturn(rows.iterator(), rows.iterator());

        // Return CConsol followed by the actual data
        when(row.getString(0))
                .thenReturn(
                        "2022351",
                        "2022351\tE\t1\t390\tB60912\t\t2013-01-09 08:15:14.65\t2064-06-08 00:00:00.0\t175959\t2015-01-20 13:50:27.642");
    }

    @Test
    public void shouldDeriveRXM() throws Exception {
        setupCassandraProxy();
        Map<String, Object> input = new HashMap<>();
        input.put("ISSUER_ID", "100076");
        Map<String, Object> output = rule.process(input);
        assertEquals("B60912", output.get("RXM"));
        verify(proxy, times(2)).getPrepareStatement(anyString());
        verify(proxy, times(2)).executeStatement(boundStmt1);
        verifyNoMoreInteractions(proxy);
    }

    @Test
    public void shouldReturnCachedRXM() throws Exception {
        shouldDeriveRXM();
        setupCassandraProxy();

        Map<String, Object> input = new HashMap<>();
        input.put("ISSUER_ID", "100076");
        Map<String, Object> output = rule.process(input);
        assertEquals("B60912", output.get("RXM"));
        verifyZeroInteractions(proxy);
    }

    @Test
    public void shouldInitialiseProxy() {
        rule.init();
        verify(helper).getProxy();
        verifyNoMoreInteractions(helper);
    }

}
