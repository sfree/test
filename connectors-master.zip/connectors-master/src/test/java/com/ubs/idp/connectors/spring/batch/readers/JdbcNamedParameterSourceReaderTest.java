package com.ubs.idp.connectors.spring.batch.readers;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class JdbcNamedParameterSourceReaderTest {

    @InjectMocks private JdbcNamedParameterSourceReader<String> jdbcNamedParameterSourceReader;
    @Mock private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @Mock ExecutionContext executionContext;

    @Before
    public void setUp() throws Exception {
        jdbcNamedParameterSourceReader = new JdbcNamedParameterSourceReader<>();
        MockitoAnnotations.initMocks(this);
    }

    private ArrayList<Object> getSourceData() {
        ArrayList<Object> events = new ArrayList<Object>();
        events.add("Item one");
        return events;
    }
    
    @Test
    public void afterPropertiesSetTest() throws Exception {
    	jdbcNamedParameterSourceReader.afterPropertiesSet();
    }
    
    @Test
    public void openTest() throws Exception {
    	Map<String, Object> parameters = new HashMap<String, Object>();
    	RowMapper rowMapper = mock(RowMapper.class);
    	DataSource mockedDataSource = mock(DataSource.class);
    	List list = mock(List.class);
    	
    	jdbcNamedParameterSourceReader.setQuerySql("testQuery");
    	jdbcNamedParameterSourceReader.setParameters(parameters);
    	jdbcNamedParameterSourceReader.setRowMapper(rowMapper);
    	jdbcNamedParameterSourceReader.setDataSource(mockedDataSource);
    	
    	when(namedParameterJdbcTemplate.query("testQuery", parameters,
                rowMapper)).thenReturn(list);
    	
    	jdbcNamedParameterSourceReader.init();
    	jdbcNamedParameterSourceReader.setNamedParameterJdbcTemplate(namedParameterJdbcTemplate);
    	jdbcNamedParameterSourceReader.open(executionContext);
    	verify(list).iterator();
    	
    }

    @Test
    public void should_provide_one_item_on_read() throws Exception {

        when(namedParameterJdbcTemplate.query(anyString(), any(HashMap.class),
                any(RowMapper.class))).thenReturn(getSourceData());
        jdbcNamedParameterSourceReader.open(executionContext);
        String row = jdbcNamedParameterSourceReader.read();
        assertThat("Source should not be null'", row, notNullValue());
        assertThat("Source should be 'Item one'", row, is("Item one"));
        assertThat("Source item size should be 1", jdbcNamedParameterSourceReader.getRowCount(), is(1l));
    }

    @Test
    public void should_provide_more_than_one_item_on_read() throws Exception {
        ArrayList<Object> sourceData = getSourceData();
        sourceData.add("Item two");
        when(namedParameterJdbcTemplate.query(anyString(), any(HashMap.class),
                any(RowMapper.class))).thenReturn(sourceData);
        jdbcNamedParameterSourceReader.open(executionContext);
        String row = jdbcNamedParameterSourceReader.read();
        assertThat("Source should not be null'", row, notNullValue());
        assertThat("Source should be 'Item one'", row, is("Item one"));
        assertThat("Source item size should be 1", jdbcNamedParameterSourceReader.getRowCount(), is(1l));
        row = jdbcNamedParameterSourceReader.read();
        assertThat("Source should be 'Item two'", row, is("Item two"));
        assertThat("Source item size should be 2", jdbcNamedParameterSourceReader.getRowCount(), is(2l));
    }

    @Test
    public void should_not_provide_source_on_read() throws Exception {
        jdbcNamedParameterSourceReader.open(executionContext);
        ArrayList<Object> sourceData = getSourceData();
        sourceData.clear();
        when(namedParameterJdbcTemplate.query(anyString(), any(HashMap.class),
                any(RowMapper.class))).thenReturn(sourceData);
        String row = jdbcNamedParameterSourceReader.read();
        assertThat("Source should be null", row, nullValue());
        assertThat("Source item size should be 0", jdbcNamedParameterSourceReader.getRowCount(), is(0l));
    }
}
