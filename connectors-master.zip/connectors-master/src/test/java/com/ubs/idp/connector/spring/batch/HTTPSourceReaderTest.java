package com.ubs.idp.connector.spring.batch;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.item.ExecutionContext;

import com.ubs.idp.connectors.HttpClientWrapper;
import com.ubs.idp.connectors.spring.batch.readers.HTTPSourceReader;

public class HTTPSourceReaderTest {

    private static final String VALID_TEST_FILE_URI = "src/test/resources/indextestfile.txt";
    private static final String INVALID_TEST_FILE_URI = "src/test/resources/nosuchfile.txt";
    
    @Mock
    HttpClientWrapper httpClient;
    
    InputStreamReader inputStreamValid = null;

    @Before
    public void setUp() throws Exception {
        // Initialise the mocks
        MockitoAnnotations.initMocks(this);
        
        InputStream inputStream = new FileInputStream(VALID_TEST_FILE_URI);
        inputStreamValid = new InputStreamReader(inputStream);
        
        when(httpClient.getInput(VALID_TEST_FILE_URI)).thenReturn(inputStreamValid);
        when(httpClient.getInput(INVALID_TEST_FILE_URI)).thenThrow(new FileNotFoundException("FileNotFoundException: Not sure this test is that useful"));
    }
    
    @After
    public void tearDown() {
        if (inputStreamValid != null) {
            try { inputStreamValid.close(); } catch (IOException e) {}
        }
    }

    @Test
    public void testNoUri() {
        HTTPSourceReader reader = setupReader();
        
        try {
            reader.init();
            reader.read();
            
            fail("Should not get here!");
        } catch (Exception e) {
            assertEquals(HTTPSourceReader.ERROR_NO_URI, e.getMessage());
        }
    }

    @Test
    public void testInvalidUri() {
        HTTPSourceReader reader = setupReader();
        
        try {
            reader.setUri(INVALID_TEST_FILE_URI);

            reader.init();
            
            reader.open(new ExecutionContext());

            String res = reader.read();
            
            fail("Should not get here! (res=" + res + ")");
        } catch (Exception e) {
            // Exception should be thrown
        }
    }

    @Test
    public void testNoInit() {
        HTTPSourceReader reader = setupReader();
        
        try {
            reader.setUri(VALID_TEST_FILE_URI);
            
            // Read should auto-init now
            reader.read();

            fail("Should not get here!");
        } catch (Exception e) {
        }
    }

    @Test
    public void readOneRowTest() {
        HTTPSourceReader reader = setupReader();
        
        try {
            reader.setUri(VALID_TEST_FILE_URI);
            
            reader.init();
            
            reader.open(new ExecutionContext());
            
            String res = reader.read();
            
            assertNotNull("Invalid row data?", res);
            
            assertTrue("Unexpected reader ready state?", reader.isConnected());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception: " + e.getClass().getName());
        }
    }
    
    @Test
    public void readAllRowsTest() {
        HTTPSourceReader reader = setupReader();
        
        try {
            reader.setUri(VALID_TEST_FILE_URI);
            
            reader.init();
            
            reader.open(new ExecutionContext());
            
            int rowCount = 0;
            
            while(reader.read() != null) {
                rowCount++;
            }
            
            assertEquals("Local row count incorrect?", 31731, rowCount);
            assertEquals("Reader row count incorrect?", 31731, reader.getRowCount());
            
            assertFalse("Unexpected reader ready state?", reader.isConnected());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception: " + e.getClass().getName());
        }
    }
    
    @Test
    public void skipHeaderRowTest() {
        HTTPSourceReader reader = setupReader();
        
        try {
            reader.setUri(VALID_TEST_FILE_URI);
            reader.setSkipHeader(true);
            
            reader.init();
            
            reader.open(new ExecutionContext());
            
            int rowCount = 0;
            
            while(reader.read() != null) {
                rowCount ++;
            }
            
            assertEquals(31730, rowCount);
            assertEquals(31730, reader.getRowCount());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception: " + e.getClass().getName());
        }
    }
    
    private HTTPSourceReader setupReader() {
        HTTPSourceReader reader = new HTTPSourceReader(httpClient);
        
        reader.setUsername("JUnit");
        reader.setAppKey("JUnit");
        reader.setRcasEnv(HttpClientWrapper.RCAS_ENV_UAT);
        
        return reader;
    }
}
