package com.ubs.idp.orchestrator.processor.rules.treasuryar;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class PriceDateFilterRuleTest
{
	private PriceDateFilterRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new PriceDateFilterRule();
	}
	
	@Test
	public void shouldReturnRecord() throws Exception {
		
		inputFields = new HashMap<String,Object>();
		inputFields.put("PRICE_DATE",new SimpleDateFormat("yyyyMMdd").format(new Date(System.currentTimeMillis())));
		assertNotNull( rule.process(inputFields));
	}

	@Test
	public void shouldNotReturnRecord() throws Exception {
		
		inputFields = new HashMap<String,Object>();
		inputFields.put("PRICE_DATE","20130412");
		assertNull( rule.process(inputFields));
	}

	@Test
	public void shouldReturnRecordsWithParameters() throws Exception {
		
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("priceDate", "20130412");
		
		inputFields = new HashMap<String,Object>();
		inputFields.put("PRICE_DATE","20130412");
		assertNotNull( rule.process(inputFields,params));
	}

	@Test
	public void shouldNotReturnRecordsWithParameters() throws Exception {
		
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("priceDate", "20130411");
		
		inputFields = new HashMap<String,Object>();
		inputFields.put("PRICE_DATE","20130412");
		assertNull( rule.process(inputFields,params));
	}

}
