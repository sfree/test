package com.ubs.idp.orchestrator.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class FileActionHandlerTest {
    
    public static final String testFileName = "FileMoveTaskletTest.txt";
    public static final String newFileName = "NewFileNameTest.txt";
    public static final String timestampedFileName = "FileMoveTaskletTest--.txt"; // See date format below ("-")
    public static final String testOutDirName = "FileMoveTaskletTestOut";
    
    private File testOutputDir;
    private File testInputFile;
    private File testOutputFile;
    private File testOutputTimestampedFile;
    private File testRenamedFile;
    
    @Before
    public void setUp() throws Exception {
        String baseDir = System.getProperty("user.dir") + File.separator + "target" + File.separator;
        
        String testFilePath = baseDir + testFileName;
        String testOutputDirPath = baseDir + testOutDirName;
        String testOutputFilePath = testOutputDirPath + File.separator + testFileName;
        String testRenamedFilePath = testOutputDirPath + File.separator + newFileName;
        String testTimestampedFilePath = testOutputDirPath + File.separator + timestampedFileName;
        
        testOutputDir = new File(testOutputDirPath);
        testInputFile = new File(testFilePath);
        testOutputFile = new File(testOutputFilePath);
        testRenamedFile = new File(testRenamedFilePath);
        testOutputTimestampedFile = new File(testTimestampedFilePath);
        
        // Pre-delete output from old test run
        cleanup();
        
        // Create output folder
        
        assertTrue("Failed to create output directory? ('" + testOutputDir.getAbsolutePath() + "')", testOutputDir.mkdir());
        
    	testInputFile = createTestFile(testInputFile);
        
        assertTrue("Failed to access test output directory?", testInputFile.exists());
    }
    
    @After
    public void tearDown() {
        cleanup();
    }
    
    @Test
    public void testNoZip() throws IOException {
        
    	FileActionHandler fileActionHandler = new FileActionHandler();

        fileActionHandler.move(testInputFile, testOutputDir, null, false);
        
        assertTrue("Failed to find output file? (" + testOutputFile.getAbsolutePath() + ")", testOutputFile.exists());
        assertFalse("Input file still present?", testInputFile.exists());
    }
    
    @Test
    public void testRenameNoZip() throws IOException {
        
    	FileActionHandler fileActionHandler = new FileActionHandler();

        fileActionHandler.move(testInputFile, testOutputDir, newFileName, false);
        
        assertTrue("Failed to find output file? (" + testRenamedFile.getAbsolutePath() + ")", testRenamedFile.exists());
        assertFalse("Input file still present?", testInputFile.exists());
    }
    
    @Test
    public void testProcessMoveNoZip() throws IOException {
        
    	Resource targetDirectory = new FileSystemResource(testOutputDir);
    	Resource inputFile = new FileSystemResource(testInputFile);
    	
    	FileActionHandler fileActionHandler = new FileActionHandler();

    	fileActionHandler.setInputFile(inputFile);
    	fileActionHandler.setAction(FileActionHandler.ACTION_MOVE);
    	fileActionHandler.setTargetDirectory(targetDirectory);
    	
    	fileActionHandler.setTimestampFormat("-");
    	
        fileActionHandler.processFile();
        
        assertTrue("Failed to find output file? (" + testOutputTimestampedFile.getAbsolutePath() + ")", testOutputTimestampedFile.exists());
        assertFalse("Input file still present?", testInputFile.exists());
    }
    
    @Test
    public void testProcessMoveNoTargetDir() throws IOException {
    	
    	Resource inputFile = new FileSystemResource(testInputFile);

    	FileActionHandler fileActionHandler = new FileActionHandler();

    	fileActionHandler.setInputFile(inputFile);
    	fileActionHandler.setAction(FileActionHandler.ACTION_MOVE);
    	
    	try {
	        fileActionHandler.processFile();
	        
	        fail("Should NOT get here!");
    	} catch(IllegalArgumentException ex) {
    		assertEquals("Unexpected exception message?", "No target directory specified?", ex.getMessage());
    	}
    }
    
    @Test
    public void testProcessMoveNoInputFile() throws IOException {
    	
    	FileActionHandler fileActionHandler = new FileActionHandler();

    	fileActionHandler.setAction(FileActionHandler.ACTION_MOVE);
    	
    	try {
	        fileActionHandler.processFile();
	        
	        fail("Should NOT get here!");
    	} catch(IllegalArgumentException ex) {
    		assertEquals("Unexpected exception message?", "No file provided?", ex.getMessage());
    	}
    }
    
    @Test
    public void testProcessMoveNoAction() throws IOException {
    	
    	Resource inputFile = new FileSystemResource(testInputFile);

    	FileActionHandler fileActionHandler = new FileActionHandler();
    	
    	try {
        	fileActionHandler.setInputFile(inputFile);

        	fileActionHandler.processFile();
	        
	        fail("Should NOT get here!");
    	} catch(IllegalArgumentException ex) {
    		assertEquals("Unexpected exception message?", "No action provided?", ex.getMessage());
    	}
    }
    
    @Test
    public void testWithZip() throws FileNotFoundException, IOException {
        
    	FileActionHandler fileActionHandler = new FileActionHandler();

        // Zipping appends a ".zip" extension
        testOutputFile = new File(testOutputFile.getAbsolutePath() + ".zip");
        
        fileActionHandler.move(testInputFile, testOutputDir, null, true);
        
        assertTrue("Failed to find output file? (" + testOutputFile.getAbsolutePath() + ")", testOutputFile.exists());
        assertFalse("Input file still present?", testInputFile.exists());
    }
    
    @Test
    public void testRenameWithZip() throws FileNotFoundException, IOException {
        
    	FileActionHandler fileActionHandler = new FileActionHandler();

        // Zipping appends a ".zip" extension
        File testOutputFile = new File(testRenamedFile.getAbsolutePath() + ".zip");
        
        fileActionHandler.move(testInputFile, testOutputDir, newFileName, true);
        
        assertTrue("Failed to find output file? (" + testOutputFile.getAbsolutePath() + ")", testOutputFile.exists());
        assertFalse("Input file still present?", testInputFile.exists());
    }
    
    @Test
    public void testDeleteFile() throws IOException {
        
    	FileActionHandler fileActionHandler = new FileActionHandler();

        fileActionHandler.deleteFile(testInputFile);
        
        assertFalse("Input file still present?", testInputFile.exists());
    }
    
    @Test
    public void testProcessDeleteFile() throws IOException {
    	Resource inputFile = new FileSystemResource(testInputFile);

    	FileActionHandler fileActionHandler = new FileActionHandler();

    	fileActionHandler.setInputFile(inputFile);
    	fileActionHandler.setAction(FileActionHandler.ACTION_DELETE);
    	
        fileActionHandler.processFile();
        
        assertFalse("Input file still present?", testInputFile.exists());
    }

    protected File createTestFile(File testFile) throws Exception {
        if (testFile.exists()) {
            testFile.delete();
        }

        assertTrue("Failed to create test file '" + testFile.getAbsolutePath() + "'?", testFile.createNewFile());
        assertTrue("Failed to create test file '" + testFile.getAbsolutePath() + "'?", testFile.exists());
        
        FileOutputStream fos = new FileOutputStream(testFile);
        
        fos.write("JUnit Test Data".getBytes("UTF-8"));
        fos.close();
        
        return testFile;
    }

    protected void cleanup() {
        if (testOutputDir.exists()) {
            File[] testFiles = testOutputDir.listFiles();
            
            for(File file : testFiles) {
                assertTrue("Failed to delete test file?", file.delete());
            }
            
            assertTrue("Failed to delete output directory?", testOutputDir.delete());
        }
    }

}
