package com.ubs.idp.orchestrator.processor.rules;

import static com.ubs.idp.orchestrator.processor.rules.DSCurrencyRuleTest.InputBuilder.newInput;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ErrorCollector;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.ubs.idp.domainRegistry.DomainRegistry;
import com.ubs.idp.domainRegistry.common.DomainKey;

@RunWith(MockitoJUnitRunner.class)
public class DSCurrencyRuleTest {

	private static final Long ISSUE_DOMAIN_KEY = ThreadLocalRandom.current().nextLong(0, 250);

	private static final Long CTRY_DOMAIN_KEY = ThreadLocalRandom.current().nextLong(0, 250);

	@Rule
	public ErrorCollector collector = new ErrorCollector();

	@Mock(name = "domainRegistry")
	private DomainRegistry mockDomainRegistry;

	@InjectMocks
	@Resource
	private DSCurrencyRule rule;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);

		// Mock the domain registry
		mockDomainKey(ISSUE_DOMAIN_KEY, "Instrument", "THB");
		mockDomainKey(CTRY_DOMAIN_KEY, "Country", "THB");
		mockDomainKey(ISSUE_DOMAIN_KEY, "Instrument", null);
		mockDomainKey(CTRY_DOMAIN_KEY, "Country", null);
	}

	private void mockDomainKey(Long value, String domain, String isoCode) {
		DomainKey domainKey = new DomainKey();
		domainKey.setDomainKey(value);
		when(mockDomainRegistry.createDomainKey(domain, isoCode))
				.thenReturn(domainKey);
		when(mockDomainRegistry.createDomainKey(domain, "DSCURRENCY", "DSCURRENCY.IDP", isoCode))
				.thenReturn(domainKey);

	}

	@Test
	public void shouldDeriveAllAttributes() throws Exception {
		Map<String, Object> results = rule.process(newInput().withIsoCode("THB").build());
		collector.checkThat((Long) results.get("issue.ubsId"), equalTo(ISSUE_DOMAIN_KEY));
		collector.checkThat((Long) results.get("tL.countryUbsId"), equalTo(CTRY_DOMAIN_KEY));
		collector.checkThat((String) results.get(DerivationRuleTemplate.DERIVED_DSCURRENCY_ISSUE_ISIN), equalTo("CASH - THB"));
		collector.checkThat((String) results.get(DerivationRuleTemplate.DERIVED_DSCURRENCY_ISSUE_CUSIP), equalTo("CASH - THB"));
		collector.checkThat((String) results.get(DerivationRuleTemplate.DERIVED_DSCURRENCY_ISSUE_SEDOL), equalTo("CASH - THB"));
		collector.checkThat((String) results.get(DerivationRuleTemplate.DERIVED_DSCURRENCY_ISSUE_BONDISSUERTYPE), equalTo("CASH"));
		collector.checkThat((String) results.get(DerivationRuleTemplate.DERIVED_DSCURRENCY_ISSUEFACTOR), equalTo("1"));
		collector.checkThat((String) results.get(DerivationRuleTemplate.DERIVED_DSCURRENCY_VALUEFACTOR), equalTo("1"));
		collector.checkThat((String) results.get("issue.issueSize"), equalTo("0"));
		collector.checkThat((String) results.get(DerivationRuleTemplate.DERIVED_DSCURRENCY_MINDENOMINATION), equalTo("1000"));
		collector.checkThat((String) results.get(DerivationRuleTemplate.DERIVED_DSCURRENCY_COUPON_CURRENTCOUPONRATE), equalTo("0"));
		verify(mockDomainRegistry).createDomainKey("Instrument", "THB");
		verify(mockDomainRegistry)
				.createDomainKey("Country", "DSCURRENCY", "DSCURRENCY.IDP", "THB");
		verifyNoMoreInteractions(mockDomainRegistry);
	}

	@Test
	@Ignore("It seems wrong to return rows without derived isin/cusop/sedol, raised IDP-705 to address this")
	public void shouldNotDeriveAnythingForNull() throws Exception {
		Map<String, Object> results = rule.process(newInput().withIsoCode(null).build());
		collector.checkThat((Long) results.get("issue.ubsId"), nullValue());
		collector.checkThat((Long) results.get("tL.countryUbsId"), nullValue());
		collector.checkThat((String) results.get("derived.isin"), nullValue());
		collector.checkThat((String) results.get("derived.cusip"), nullValue());
		collector.checkThat((String) results.get("derived.sedol"), nullValue());
		collector.checkThat((String) results.get("derived.bondIssuerType"), nullValue());
		collector.checkThat((String) results.get("derived.issueFactor"), nullValue());
		collector.checkThat((String) results.get("derived.valueFactor"), nullValue());
		collector.checkThat((String) results.get("derived.issueSize"), nullValue());
		collector.checkThat((String) results.get("derived.minDenomination"), nullValue());
		collector.checkThat((String) results.get("derived.currentCouponRate"), nullValue());
		verifyZeroInteractions(mockDomainRegistry);
	}

	static class InputBuilder {

		private Map<String, Object> input = new HashMap<>();

		public static InputBuilder newInput() {
			return new InputBuilder();
		}

		public InputBuilder withIsoCode(String isoCode) {
			input.put("isoCode", isoCode);
			return this;
		}

		public Map<String, Object> build() {
			return input;
		}
	}

}
