package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;
import com.ubs.idp.orchestrator.processor.rules.FIAssetTypeRule;

/**
 * Tests for the Fixed Income Asset Type derivation rules
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Fixed Income Asset Type definition section)
 * @author haniffsy
 */
public class FIAssetTypeRulePrincipalStripDerivationTest {

	private FIAssetTypeRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new FIAssetTypeRule();
		inputFields = new HashMap<String,Object>();
	}
	
	
	// Principal Strip
	
	/*
	 * If is strip principal 
	 * or issuer country is US and short name is STRIP PRINC 
	 * or matches (STRIP*PRINCIPAL*|COUPON*STRIP*|CPN*STRIP*|PRIN*STRIP*) 
	 * or short name equals "RESOLUTION FUNDING PRINCIPAL STRIP" 
	 * or bbTicker one of CANRDC,FRTRR,JGBP,NETHRR,OLOR,ITALYP,KOREAP,DBRR,SP,SPGBR,SGBR,SPX,BTPSR,TGR,UKTR,
	 */
	
	@Test
	public void shouldDerivePrincipalStripIfStripTypePrincipal() {
		inputFields.put(DerivationRuleTemplate.STRIP_TYPE, "Principal");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfShortNameStripPrincAndIssuerCountryUS() {
		inputFields.put(DerivationRuleTemplate.SHORT_NAME, "STRIP PRINC");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	
	@Test
	public void shouldDerivePrincipalStripIfShortNameMatchesStripStarPrincipalStar() {
		inputFields.put(DerivationRuleTemplate.SHORT_NAME, "BLAH STRIP BLAH PRINCIPAL BLAH");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDerivePrincipalStripIfShortNameMatchesCouponStarStripStar() {
		inputFields.put(DerivationRuleTemplate.SHORT_NAME, "BLAH COUPON BLAH STRIP BLAH");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfShortNameMatchesCpnStarStripStar() {
		inputFields.put(DerivationRuleTemplate.SHORT_NAME, "BLAH CPN BLAH STRIP BLAH");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfShortNameMatchesPrinStarStripStar() {
		inputFields.put(DerivationRuleTemplate.SHORT_NAME, "BLAH PRIN BLAH STRIP BLAH");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsCANRDC() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "CANRDC");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsFRTRR() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FRTRR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsJGBP() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "JGBP");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsNETHRR() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "NETHRR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsOLOR() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "OLOR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsITALYP() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "ITALYP");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDerivePrincipalStripIfTickerIsKOREAP() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "KOREAP");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDerivePrincipalStripIfTickerIsDBRR() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "DBRR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsSP() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SP");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsSPGBR() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SPGBR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsSGBR() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SGBR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsSPX() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SPX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsBTPSR() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BTPSR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsTGR() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "TGR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfTickerIsUKTR() {
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "UKTR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDerivePrincipalStripIfShortNameIsResolutionFundingPrincipalStrip() {
		inputFields.put(DerivationRuleTemplate.SHORT_NAME, "RESOLUTION FUNDING PRINCIPAL STRIP");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Principal Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
}
