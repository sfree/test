package com.ubs.idp.connector;

import com.ubs.idp.connectors.cassandra.CassandraConfig;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;

public class CassandraConfigTest {

	private CassandraConfig config;

	@Before
	public void setup() {
		config = new CassandraConfig();
		ReflectionTestUtils.setField(config, "cassandraPassword", "ecbd77cb12f9e1ed1c2a444df5366d57");
	}

	@Test
	public void testDecrypt() {

		assertEquals("ecbd77cb12f9e1ed1c2a444df5366d57", config.getCassandraPassword());
		assertEquals("foobar", config.getDecryptedCassandraPassword());
	}
}
