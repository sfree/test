package com.ubs.idp.orchestrator.processor;


//import com.ubs.idp.connectors.sybase.SybaseSQLProxy;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyMap;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.mock;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ubs.idp.connectors.spring.batch.writers.AccountEventResultSetWriter;
import com.ubs.idp.orchestrator.util.MetaDataRetrieverUtil;
import com.ubs.idp.orchestrator.util.MfLocation;

import org.hamcrest.MatcherAssert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import com.ubs.idp.metadata.client.MetadataService;

public class AccountEventResultSetProcessorTest {

    @InjectMocks private AccountEventResultSetProcessor mfEventResultSetProcessor;
    @Mock private MetadataService mds;
    @Mock private SimpleJdbcCall simpleJdbcCall;
    @Mock private SimpleDriverDataSource simpleDriverDataSource;
    @Mock private Connection connection;
    @Mock private DatabaseMetaData databaseMetaData;
    @Mock private DataSourceUtils dataSourceUtils;
    @Mock private MetaDataRetrieverUtil metaDataRetrieverUtil;
    @Mock private StepExecution stepExecution;
    @Mock private ExecutionContext executionContext;
    @Mock private JobExecution jobExecution;

    @SuppressWarnings("unchecked")
	@Before public void setUp() throws Exception {

        mfEventResultSetProcessor = spy(new AccountEventResultSetProcessor());
        
        MockitoAnnotations.initMocks(this);    
        mfEventResultSetProcessor.setLocationBasedDataSources(getLocationBaseDataSources());
        when(mds.getStoredProcedureDetails(anyString())).thenReturn(getStoredProcDetails());
        when(mds.getOrderedDatasetDetails(anyString())).thenReturn(getOrderedDatasetDetails());
        when(mds.getDataSetDetails(anyString())).thenReturn(getDataSetDetails());
        doReturn(simpleJdbcCall)
                .when(mfEventResultSetProcessor)
                .getLocationBasedMfSimpleJdbcCall(anyString());

        when(simpleJdbcCall.withProcedureName(anyString())).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.withoutProcedureColumnMetaDataAccess()).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.useInParameterNames(anyString(),
                anyString(), anyString(), anyString())).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.declareParameters(any(SqlParameter.class),
                any(SqlParameter.class), any(SqlParameter.class), any(SqlParameter.class))).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.returningResultSet(anyString(), any(AccountEventResultSetProcessor.ResultSetMapper.class))).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.execute(anyMap())).thenReturn(getSPOutput());
        when(mds.getAttributeNamesForDataset("result1")).thenReturn(Arrays.asList("cconsol"));
    }


    private HashMap<String, SimpleDriverDataSource> getLocationBaseDataSources() {
        HashMap<String, SimpleDriverDataSource> locationBasedDataSources = new HashMap<>();
        locationBasedDataSources.put(MfLocation.STAMFORD.name(), simpleDriverDataSource);
        return locationBasedDataSources;
    }


    private HashMap<String, Object> getSPOutput() {
        HashMap<String, Object> resultSetOutput = new HashMap<>();
        ArrayList<Map<String, String>> resultItems = new ArrayList<>();
        HashMap<String, String> columnsValues = new HashMap<>();
        columnsValues.put("cconsol", "123456");
        resultItems.add(columnsValues);
        resultSetOutput.put("result1", resultItems);
        return resultSetOutput;
    }

    private Map<String, Map<String, Map<String, Object>>> getStoredProcDetails() {
        Map<String, Map<String, Map<String, Object>>> stringMapMap = new HashMap<>();
        HashMap<String, Map<String, Object>> columns = new HashMap<>();
        HashMap<String, Object> columnDetails = new HashMap<>();
        columnDetails.put("name", "cconsol");
        columnDetails.put("position", 1);

        columnDetails.put("type", "VARCHAR");

        columns.put("cconsole", columnDetails);
        columns.put("code1", columnDetails);
        columns.put("code2", columnDetails);
        columns.put("code3", columnDetails);
        stringMapMap.put("get_Adp_Address", columns);
        return stringMapMap;
    }

    private Map<String, List<String>> getDataSetDetails() {
        Map<String, List<String>> dataSetDetails = new HashMap<>();
        dataSetDetails.put("result1", Arrays.asList("cconsol, code1, code2, code3, code4"));
        return dataSetDetails;
    }
    
    private List<Map<String, String>> getOrderedDatasetDetails() {
        List<Map<String,String>> datasetlist = new ArrayList<Map<String, String>>();
    	Map<String, String> dataSetDetails = new HashMap<>();
        dataSetDetails.put("result1", "result1");
        datasetlist.add(dataSetDetails);
        return datasetlist;
    }

    @Test public void testProcess() throws Exception {

        Map<String, Object> mfEvent = getMfEvent("79");
        List<AccountEventResultSetWriter.AccountEventResultSets> mfEventData = mfEventResultSetProcessor.process(mfEvent);
        assertThat(mfEventData.size(), is(1));
        MatcherAssert.assertThat(mfEventData.get(0).getResultSets().keySet().iterator().next(), is("result1"));
        MatcherAssert.assertThat(mfEventData.get(0).getResultSets().entrySet().iterator().next().getValue().entrySet().iterator().next().getKey(), is("cconsol"));
        MatcherAssert.assertThat(mfEventData.get(0).getResultSets().entrySet().iterator().next().getValue().entrySet().iterator().next().getValue(), is("123456"));
    }

    private Map<String, Object> getMfEvent(String procId) {

        Map<String, Object> mfEvent = new HashMap<>();
        mfEvent.put("DOWNSTREAM_SP_ID", procId);
        mfEvent.put("account_id", "123456");
        mfEvent.put("account_code", "123456");
        mfEvent.put("ID", 3L);
        mfEvent.put("RETRYCOUNT", 0L);
        mfEvent.put("mf_host", MfLocation.STAMFORD.name());
        mfEvent.put("LOA_CLASSIFICATION",3L);
        return mfEvent;
    }
    
    @Test    
    public void testValidateResultSetData(){
    	Map<String, Object> resultSetData=new HashMap<String, Object>();
    	mfEventResultSetProcessor.setItemProcessorEnvironment(getMfEvent("79"));
    	Map<String, String> resultSetMetaData = new HashMap<String, String>();
    	resultSetMetaData.put("cconsol","123456");
    	List<Map<String, String>> resultSetDataList = new ArrayList<Map<String, String>>();
    	resultSetDataList.add(resultSetMetaData);
    	resultSetData.put("result1",resultSetDataList);
    	mfEventResultSetProcessor.validateResultSetData(resultSetData);
    	assertFalse(mfEventResultSetProcessor.isResultInValid());
    	
    	resultSetData = new HashMap<String, Object>();
    	mfEventResultSetProcessor.setItemProcessorEnvironment(getMfEvent("79"));
    	resultSetMetaData = new HashMap<String, String>();
    	resultSetMetaData.put("code1","123456");
    	resultSetDataList = new ArrayList<Map<String, String>>();
    	resultSetDataList.add(resultSetMetaData);
    	resultSetData.put("result1",resultSetDataList);
    	boolean thrownValidationEx = false;
    	try {
    		mfEventResultSetProcessor.validateResultSetData(resultSetData);
    	}
    	catch(ValidationException ex) {
    		thrownValidationEx = true;
    	}
    	
    	assertFalse(thrownValidationEx);

    }
    
    @Test
    public void testAfterStep() {
    	mfEventResultSetProcessor.setResultInValid(false);
    	
    	when(stepExecution.getJobExecution()).thenReturn(jobExecution);
    	when(jobExecution.getExecutionContext()).thenReturn(executionContext);
    	
    	mfEventResultSetProcessor.afterStep(stepExecution);
    	
    	verify(executionContext).put("id", 0l);
    	verify(executionContext).put("propCode", null);
    	verify(executionContext).put("retryCount", 0);
    	verify(executionContext).put("isEventInValid", false);
    }
    
    @Test
    public void testAfterPropertiesSet() throws Exception {
    	Map<String, Map<String, Map<String, Object>>> storedProc = new HashMap<String, Map<String, Map<String, Object>>>();
    	mfEventResultSetProcessor.setStoredProc(storedProc);
    	mfEventResultSetProcessor.afterPropertiesSet();
    }
    
    @Test
    public void testResultSetMapperMapRow() throws SQLException {
    	List<String> list = new ArrayList<String>();
    	list.add(0, "column1");
    	list.add(1, "column2");
    	list.add(2, "column3");
    	AccountEventResultSetProcessor.ResultSetMapper resultSetMapper = 
    			new AccountEventResultSetProcessor.ResultSetMapper("1", list);
    	ResultSet resultSet = mock(ResultSet.class);
    	ResultSetMetaData metaData = mock(ResultSetMetaData.class);
    	when(resultSet.getMetaData()).thenReturn(metaData);
    	when(resultSet.getObject(1)).thenReturn("one");
    	when(resultSet.getObject(2)).thenReturn(null);
    	when(resultSet.getObject(3)).thenReturn(null);
    	when(metaData.getColumnCount()).thenReturn(3);
    	when(metaData.getColumnType(1)).thenReturn(Types.INTEGER);
    	when(metaData.getColumnType(2)).thenReturn(Types.BIT);
    	when(metaData.getColumnType(3)).thenReturn(Types.INTEGER);
    	assertEquals("one", resultSetMapper.mapRow(resultSet, 1).get("column1"));
    	assertEquals("", resultSetMapper.mapRow(resultSet, 1).get("column2"));
    	assertEquals("", resultSetMapper.mapRow(resultSet, 1).get("column3"));
    }
    
    @Test
    public void testGetBitValue() {
    	List<String> list = new ArrayList<String>();
    	list.add(0, "column1");
    	AccountEventResultSetProcessor.ResultSetMapper resultSetMapper = 
    			new AccountEventResultSetProcessor.ResultSetMapper("1", list);
    	assertEquals("1", resultSetMapper.getBitValue(true));
    	assertEquals("0", resultSetMapper.getBitValue(false));
    	assertEquals("", resultSetMapper.getBitValue(null));
    }
    
    
}
