package com.ubs.idp.orchestrator.processor.rules.treasuryar;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class RatingBlankRowFilterRuleTest
{
	private RatingBlankRowFilterRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new RatingBlankRowFilterRule();
	}
	
	@Test
	public void shouldReturnRecord() throws Exception {
		
		inputFields = new HashMap<String,Object>();
		inputFields.put("issue.ubsId","1000255");
		assertNotNull( rule.process(inputFields));
	}

	@Test
	public void shouldNotReturnRecord() throws Exception {
		
		inputFields = new HashMap<String,Object>();
		inputFields.put("issue.ubsId","-9996");
		assertNull( rule.process(inputFields));
	}

}
