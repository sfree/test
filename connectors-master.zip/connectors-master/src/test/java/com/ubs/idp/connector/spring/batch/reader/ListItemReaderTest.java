package com.ubs.idp.connector.spring.batch.reader;

import static org.junit.Assert.fail;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.connectors.spring.batch.readers.ListItemReader;

public class ListItemReaderTest {
	
	StepExecution stepExecution;
	ExecutionContext executionContext;

	@Before
	public void setUp() throws Exception {	
		
		JobExecution jobExecution = new JobExecution(1L);
		executionContext = new ExecutionContext();
		executionContext.put("index", 0);
		jobExecution.setExecutionContext(executionContext);
		stepExecution = new StepExecution("step2", jobExecution);
	}

	@RunWith(SpringJUnit4ClassRunner.class)
	@Configuration
	static class ContextConfiguration {
		@Bean(name = "eventListReader")
		@Qualifier(value = "com.ubs.idp.connectors.spring.batch.writers.ListItemReader")
		public ListItemReader getEventListReaderer() {
			ListItemReader eventListReader = new ListItemReader();
			return eventListReader;
		}

		@Bean(name = "listOfItems")
		@Qualifier(value = "java.util.ArrayList")
		public ArrayList<Integer> getListOfItems() {
			ArrayList<Integer> listOfItems = new ArrayList<Integer>();
			listOfItems.add(1);
			listOfItems.add(2);
			return listOfItems;
		}

	}
	
	@Test
	public void testRead() {

		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(
				ContextConfiguration.class);
		ListItemReader reader = ctx.getBean(ListItemReader.class);
		@SuppressWarnings("unchecked")
		ArrayList<Object> listOfItems = ctx.getBean(ArrayList.class);
		reader.setListOfItems(listOfItems);
		try {
			reader.afterPropertiesSet();
			reader.open(executionContext);
			reader.getIndex(stepExecution);
			reader.read();
			reader.read();
			reader.setIndex(stepExecution);
			reader.update(executionContext);
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
			fail("Unexpected exception: " + e.getClass().getName());
		}
		Assert.assertEquals(1, executionContext.getInt("index"));
		ctx.close();
	}

}
