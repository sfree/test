package com.ubs.idp.orchestrator.comparators;

import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junitx.framework.FileAssert;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import com.ubs.idp.connectors.spring.batch.utils.BaseCassandraComparator;
import com.ubs.idp.connectors.spring.batch.writers.BaseCassandraItemWriter.InputItem;
import com.ubs.idp.connectors.spring.batch.writers.CassandraItemWriter;

/**
 * Parameterized Tester to test all comparators by providing a input and compare file
 * to run the test against
 * 
 * @author loverids
 *
 */
@RunWith(Parameterized.class)
public class AllComparatorTest
{
	public final static String DATA_FILES_DIR = "src/test/resources/data-files";
	public final static String COMPARE_FILES_DIR = "src/test/resources/compare-files";
	public final static String OUTPUT_DIR = "target";
	
	protected BaseCassandraComparator comparator;
	protected String delimiter;
	protected String dataFileName;
	protected String compareFilename;
	protected String outputFilename;
	protected String[] keyColumns;
	
	/**
	 * Define all our test cases here. Each object in the array matches the constructor
	 * parameters
	 * @return
	 */
	@Parameterized.Parameters
	public static Collection<Object[]> testCases() {
		return Arrays.asList(new Object[][]{
				{EquityIssueLatestRecordComparator.class,"\t","EQUITY.csv","EQUITY_ISSUE_COMPARE.csv","EQUITY_ISSUE_OUT.csv",new String[]{"issue.ubsId"}},
				{EquityTLLatestRecordComparator.class,"\t","EQUITY.csv","EQUITY_TL_COMPARE.csv","EQUITY_TL_OUT.csv",new String[]{"tL.ubsId"}},
				{RatingLatestRecordComparator.class,"\t","RATING.csv","RATING_COMPARE.csv","RATING_OUT.csv",new String[]{"issue.ubsId","issueRating.recordType","issueRating.ratingAgency","issueRating.ratingGroup","issueRating.ratingType","issueRating.currencyType"}},
				{BondTLLatestRecordComparator.class,"\t","BONDTL.csv","BONDTL_COMPARE.csv","BONDTL_OUT.csv",new String[]{"tL.ubsId"}}
		});
	}

	
	public AllComparatorTest( Class<BaseCassandraComparator> comparatorClass,
												  String delimiter,
												  String dataFileName,
												  String compareFilename,
												  String outputFilename,
												  String[] keyColumns) throws InstantiationException, IllegalAccessException
	{
		comparator = comparatorClass.newInstance();
		this.delimiter = delimiter;
		this.dataFileName = dataFileName;
		this.compareFilename = compareFilename;
		this.outputFilename = outputFilename;
		this.keyColumns = keyColumns;
	}
		
	@Test
	public void comparatorTester() throws Exception 
	{
		doSort(delimiter,dataFileName,compareFilename,outputFilename,keyColumns);
	}
	
	/**
	 * Reads in the header line of a file and builds a map of each column header
	 * and its position
	 * @param file
	 * @return
	 */
	protected Map<String,Integer> buildAttributePositionMapFromFile( File file, String delimiter )
	{
		Map<String,Integer> map = new HashMap<String,Integer>();
		try(BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file))))
		{
			String header = br.readLine();
			String[] cols = header.split(delimiter);
			for(int index = 0; index < cols.length; index ++ )
			{
				map.put( cols[index].trim(), index);
			}
			
			br.close();
		}
		catch( Exception ex )
		{
			throw new RuntimeException(ex);
		}
		return map;
	}
	
	/**
	 * Converts data lines into input items that the comparator can use
	 * @param lines
	 * @param delimiter
	 * @return
	 */
	protected List<InputItem> convertLinesToInputItems( List<String> lines, String delimiter, String[] keyColumns, Map<String,Integer> attributePositionMap )
	{
		List<InputItem> inputItems = new ArrayList<InputItem>();
				
		for( String line : lines )
		{
			String[] fields = line.split(delimiter);
			String key = "";
			for( String keyColumn : keyColumns )
			{
				key += fields[ attributePositionMap.get(keyColumn) ];
			}
			
			inputItems.add( new CassandraItemWriter().new InputItem(key, fields, line));
		}
		
		return inputItems;
	}
	
	/**
	 * Executes the test by reading in the input dataFile, executing the a sort by
	 * using the specified comparator and writing the results to the output file
	 * that is compared against the specifed compareFile
	 * @param delimiter
	 * @param dataFile
	 * @param compareFile
	 * @param outputFile
	 * @throws IOException
	 */
	protected void doSort(String delimiter, String dataFileName, String compareFileName, String outputFilename, String[] keyColumns) throws IOException
	{
		File dataFile = new File(DATA_FILES_DIR + File.separator + dataFileName);
		File compareFile = new File(COMPARE_FILES_DIR + File.separator + compareFileName);
		File outputFile = new File(OUTPUT_DIR + File.separator + outputFilename);		
		if( outputFile.exists() )
		{
			assertTrue(outputFile.delete());
		}
		
		Map<String,Integer> attributePositionMap = buildAttributePositionMapFromFile(dataFile, delimiter);
		comparator.setAttributePositionMap(attributePositionMap);

		// Read the test file in
		List<String> lines = FileUtils.readLines(dataFile);
		
		// Remove header
		lines.remove(0);		
		List<InputItem> inputItems = convertLinesToInputItems(lines, delimiter, keyColumns, attributePositionMap);
		
		// Sort with comparator
		Collections.sort(inputItems, comparator);
		
		// Write new list to file
		List<String> keyLinesWritten = new ArrayList<String>();
		for( InputItem inputItem : inputItems )
		{
			if( !keyLinesWritten.contains(inputItem.getKeyValue()) )
			{			 
				FileUtils.write(outputFile, inputItem.getLine() + "\n", true);
				keyLinesWritten.add(inputItem.getKeyValue());
			}
		}
		
		// Compare
		FileAssert.assertEquals(compareFile, outputFile);
	}
}
