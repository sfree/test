package com.ubs.idp.connector.spring.batch.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.ubs.idp.connectors.spring.batch.utils.BaseCassandraComparator;
import com.ubs.idp.connectors.spring.batch.writers.BaseCassandraItemWriter.InputItem;

/**
 * Date comparator for input items that expects the second field
 * to be a date 
 * @author loverids
 *
 */
public class DateComparator extends BaseCassandraComparator
{
	public final static String ATTR_NAME = "bar";  
	
	@Override
	public String[] getAttributeCompareOrder()
	{
		return new String[]{ATTR_NAME};
	}

	@Override
	public Comparable<?> castValueToType(String attrName, String value) throws ParseException
	{
		return new SimpleDateFormat("yyyyMMdd").parse(value);
	}

}