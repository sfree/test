package com.ubs.idp.orchestrator.processor.rules.rddh.rating;

import static com.ubs.idp.orchestrator.processor.rules.rddh.rating.RatingPreProcessorFilterRuleTest.InputBuilder.newInput;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class RatingPreProcessorFilterRuleTest {

	private RatingPreProcessorFilterRule rule;

	@Before
	public void setUp() throws Exception {
		rule = new RatingPreProcessorFilterRule();
	}

	@Test
	public void shouldAcceptLongTermFitchRating() throws Exception {
		Map<String, Object> results = rule.process(newInput().withRecordType("RATING")
				.withRatingType("LT").withRatingAgency("Fitch").build());
		assertNotNull("Record should be returned", results);
	}

	@Test
	public void shouldAcceptLongTermDMSIFitchRating() throws Exception {
		Map<String, Object> results = rule.process(newInput().withRecordType("RATING")
				.withRatingType("LT").withRatingAgency("DMSI_Fitch").build());
		assertNotNull("Record should be returned", results);
	}

	@Test
	public void shouldAcceptLongTermMoodysRating() throws Exception {
		Map<String, Object> results = rule.process(newInput().withRecordType("RATING")
				.withRatingType("LT").withRatingAgency("Moodys").build());
		assertNotNull("Record should be returned", results);
	}

	@Test
	public void shouldAcceptLongTermDMSIMoodysRating() throws Exception {
		Map<String, Object> results = rule.process(newInput().withRecordType("RATING")
				.withRatingType("LT").withRatingAgency("DMSI_Moodys").build());
		assertNotNull("Record should be returned", results);
	}

	@Test
	public void shouldAcceptLongTermSandPRating() throws Exception {
		Map<String, Object> results = rule.process(newInput().withRecordType("RATING")
				.withRatingType("LT").withRatingAgency("SandP").build());
		assertNotNull("Record should be returned", results);
	}

	@Test
	public void shouldAcceptLongTermDMSISandPRating() throws Exception {
		Map<String, Object> results = rule.process(newInput().withRecordType("RATING")
				.withRatingType("LT").withRatingAgency("DMSI_SandP").build());
		assertNotNull("Record should be returned", results);
	}

	@Test
	public void shouldRejectWatchlist() throws Exception {
		Map<String, Object> results = rule.process(newInput().withRecordType("WATCHLIST")
				.withRatingType("LT").withRatingAgency("Fitch").build());
		assertNull("Record should NOT be returned", results);
	}

	@Test
	public void shouldRejectOutlook() throws Exception {
		Map<String, Object> results = rule.process(newInput().withRecordType("OUTLOOK")
				.withRatingType("LT").withRatingAgency("Fitch").build());
		assertNull("Record should NOT be returned", results);
	}

	@Test
	public void shouldRejectNonLongTerm() throws Exception {
		Map<String, Object> results = rule.process(newInput().withRecordType("RATING")
				.withRatingType("UT").withRatingAgency("Fitch").build());
		assertNull("Record should NOT be returned", results);
	}

	@Test
	public void shouldRejectInvalidAgency() throws Exception {
		Map<String, Object> results = rule.process(newInput().withRecordType("RATING")
				.withRatingType("LT").withRatingAgency("Bob").build());
		assertNull("Record should NOT be returned", results);
	}

	@Test
	public void shouldRejectNullValues() throws Exception {
		Map<String, Object> results = rule.process(newInput().withRecordType("RATING")
				.withRatingType("LT").withRatingAgency(null).build());
		assertNull("Record should NOT be returned", results);

		results = rule.process(newInput().withRecordType("RATING").withRatingType(null)
				.withRatingAgency("Fitch").build());
		assertNull("Record should NOT be returned", results);

		results = rule.process(newInput().withRecordType(null).withRatingType("LT")
				.withRatingAgency("Fitch").build());
		assertNull("Record should NOT be returned", results);
	}

	static class InputBuilder {

		private Map<String, Object> input = new HashMap<>();

		public static InputBuilder newInput() {
			return new InputBuilder();
		}

		public InputBuilder withRecordType(String recordType) {
			input.put("issueRating.recordType", recordType);
			return this;
		}

		public InputBuilder withRatingType(String ratingType) {
			input.put("issueRating.ratingType", ratingType);
			return this;
		}

		public InputBuilder withRatingAgency(String ratingAgency) {
			input.put("issueRating.ratingAgency", ratingAgency);
			return this;
		}

		public Map<String, Object> build() {
			return input;
		}
	}

}
