package com.ubs.idp.connector;

import static org.junit.Assert.*;

import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.connectors.cassandra.CassandraDataObject;

import java.util.Date;

public class CassandraDataObjectTest {

	private CassandraDataObject cdo;

	private static final String NAME_KEY = "name";
	private static final String NAME_KEY_VALUE = "US";
	private static final String DATE_KEY = "date";
	private static final String DATE_KEY_VALUE = "2014-01-01";

	private static final Long ATTR_LONG = new Long(1001L);
	private static final Integer ATTR_INT = new Integer(1000);
	private static final Date ATTR_DATE = new Date();
	private static final String ATTR_STRING = "Hello";
	private static final String TABLE_NAME = "domain_holidays";
	private static final String ATTR_NAME = "my_attr";
	private static final String ATTR_OTHER_NAME = "my_other_attr";


	private Map<String,String> multipleKeys;
	private Map<String,String> singleKey;
	private Map<String,String> emptyKeys;
	private Map<String,String> nullKeys;

	@Before
	public void setUp() throws Exception {

		multipleKeys = new LinkedHashMap<String,String>();
		multipleKeys.put(NAME_KEY,NAME_KEY_VALUE);
		multipleKeys.put(DATE_KEY,DATE_KEY_VALUE);

		singleKey = new LinkedHashMap<String,String>();
		singleKey.put(NAME_KEY,NAME_KEY_VALUE);

		emptyKeys = new LinkedHashMap<String,String>();

		nullKeys = null;

		cdo = new CassandraDataObject();
	}

	@Test
	public void testInsertStatementNoTable() {
		try {
			cdo.setTableName(null);
			cdo.setKeys(multipleKeys);
			cdo.insertStatement();
			fail("Should have thrown an ISE");
		}
		catch (IllegalStateException e) {
			assertEquals("Can't create an insert statement without the Cassandra table to insert in to",e.getMessage());
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("Shouldn't have thrown this exception");
		}
	}


	@Test
	public void testInsertStatementNullKeys() {
		try {
			cdo.setTableName(TABLE_NAME);
			cdo.setKeys(nullKeys);
			cdo.insertStatement();
			fail("Should have thrown an ISE");
		}
		catch (IllegalStateException e) {
			assertEquals("Can't create an insert statement without primary keys",e.getMessage());
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("Shouldn't have thrown this exception");
		}
	}


	@Test
	public void testInsertStatementNoKeys() {
		try {
			cdo.setTableName(TABLE_NAME);
			cdo.setKeys(emptyKeys);
			cdo.insertStatement();
			fail("Should have thrown an ISE");
		}
		catch (IllegalStateException e) {
			assertEquals("Can't create an insert statement without primary keys",e.getMessage());
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("Shouldn't have thrown this exception");
		}
	}

	@Test
	public void testInsertStatementSingleKeyNoAttrs() {
		try {
			cdo.setTableName(TABLE_NAME);
			cdo.setKeys(singleKey);
			String insert = cdo.insertStatement();
			assertEquals("INSERT INTO "+TABLE_NAME+" ("+NAME_KEY+") VALUES('"+NAME_KEY_VALUE+"')",insert);
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("Shouldn't have thrown this exception");
		}

	}


	@Test
	public void testInsertStatementMultipleKeys() {
		try {
			cdo.setTableName(TABLE_NAME);
			cdo.setKeys(multipleKeys);
			String insert = cdo.insertStatement();
			assertEquals("INSERT INTO "+TABLE_NAME+" ("+NAME_KEY+","+DATE_KEY+") VALUES('"+NAME_KEY_VALUE+"','"+DATE_KEY_VALUE+"')",insert);
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("Shouldn't have thrown this exception");
		}
	}

	@Test
	public void testInsertStatementStringAttr() {
		try {
			cdo.setTableName(TABLE_NAME);
			cdo.setKeys(singleKey);
			cdo.addAttribute(ATTR_NAME, ATTR_STRING);
			String insert = cdo.insertStatement();
			assertEquals("INSERT INTO "+TABLE_NAME+" ("+NAME_KEY+","+ATTR_NAME+") VALUES('"+NAME_KEY_VALUE+"','"+ATTR_STRING+"')",insert);
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("Shouldn't have thrown this exception");
		}
	}


	@Test
	public void testInsertStatementDateAttr() {
		try {
			cdo.setTableName(TABLE_NAME);
			cdo.setKeys(singleKey);
			cdo.addAttribute(ATTR_NAME, ATTR_DATE);
			String insert = cdo.insertStatement();
			assertEquals("INSERT INTO "+TABLE_NAME+" ("+NAME_KEY+","+ATTR_NAME+") VALUES('"+NAME_KEY_VALUE+"','"+ATTR_DATE+"')",insert);
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("Shouldn't have thrown this exception");
		}
	}


	@Test
	public void testInsertStatementLongAttr() {
		try {
			cdo.setTableName(TABLE_NAME);
			cdo.setKeys(singleKey);
			cdo.addAttribute(ATTR_NAME, ATTR_LONG);
			String insert = cdo.insertStatement();
			assertEquals("INSERT INTO "+TABLE_NAME+" ("+NAME_KEY+","+ATTR_NAME+") VALUES('"+NAME_KEY_VALUE+"',"+ATTR_LONG+")",insert);
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("Shouldn't have thrown this exception");
		}
	}


	@Test
	public void testInsertStatementIntAttr() {
		try {
			cdo.setTableName(TABLE_NAME);
			cdo.setKeys(singleKey);
			cdo.addAttribute(ATTR_NAME, ATTR_INT);
			String insert = cdo.insertStatement();
			assertEquals("INSERT INTO "+TABLE_NAME+" ("+NAME_KEY+","+ATTR_NAME+") VALUES('"+NAME_KEY_VALUE+"',"+ATTR_INT+")",insert);
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("Shouldn't have thrown this exception");
		}
	}

	@Test
	public void testInsertStatementMultipleAttrs() {
		try {
			cdo.setTableName(TABLE_NAME);
			cdo.setKeys(singleKey);
			cdo.addAttribute(ATTR_NAME, ATTR_STRING);
			cdo.addAttribute(ATTR_OTHER_NAME, ATTR_INT);
			String insert = cdo.insertStatement();
			assertEquals("INSERT INTO "+TABLE_NAME+" ("+NAME_KEY+","+ATTR_NAME+","+ATTR_OTHER_NAME+") VALUES('"+NAME_KEY_VALUE+"',"+"'"+ATTR_STRING+"',"+ATTR_INT+")",insert);
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("Shouldn't have thrown this exception");
		}
	}

	@Test
	public void testInsertStatementWithKeysAndAttributes() {
		cdo.setTableName(TABLE_NAME);
		cdo.addKey(NAME_KEY, NAME_KEY_VALUE);
		cdo.addAttribute(NAME_KEY, NAME_KEY_VALUE);
		cdo.addAttribute(ATTR_NAME, ATTR_STRING);
		cdo.addAttribute(ATTR_OTHER_NAME, ATTR_INT);
		String insert = cdo.insertStatement();
		assertEquals("INSERT INTO "+TABLE_NAME+" ("+NAME_KEY+","+ATTR_NAME+","+ATTR_OTHER_NAME+") VALUES('"+NAME_KEY_VALUE+"',"+"'"+ATTR_STRING+"',"+ATTR_INT+")",insert);

	}

}
