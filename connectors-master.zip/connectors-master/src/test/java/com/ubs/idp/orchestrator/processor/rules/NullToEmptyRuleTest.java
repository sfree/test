package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class NullToEmptyRuleTest {

    private NullToEmptyRule rule;

    @Before
    public void setUp() throws Exception {
        rule = new NullToEmptyRule();
    }

    @Test
    public void testProcess() throws Exception {
        Map<String, Object> inputFields = new HashMap<>();
        inputFields.put("A", null);
        inputFields.put("B", "");
        inputFields.put("C", "null");
        inputFields.put("D", "Null");
        inputFields.put("E", "NULL");
        inputFields.put("F", " null ");
        inputFields.put("G", " Null ");
        inputFields.put("H", " NULL ");
        inputFields.put("I", "Not a Null Value");

        Map<String, Object> results = rule.process(inputFields);
        assertEquals("", results.get("A"));
        assertEquals("", results.get("B"));
        assertEquals("", results.get("C"));
        assertEquals("", results.get("D"));
        assertEquals("", results.get("E"));
        assertEquals("", results.get("F"));
        assertEquals("", results.get("G"));
        assertEquals("", results.get("H"));
        assertEquals("Not a Null Value", results.get("I"));
    }

}
