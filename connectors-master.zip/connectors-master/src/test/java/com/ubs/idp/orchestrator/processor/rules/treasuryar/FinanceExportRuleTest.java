package com.ubs.idp.orchestrator.processor.rules.treasuryar;

import static org.junit.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class FinanceExportRuleTest
{
	private FinanceExportRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new FinanceExportRule();
	}
	
	@Test
	public void shouldSetTodaysDate() throws Exception {
		
		String date = new SimpleDateFormat(FinanceExportRule.BUSINESS_DATE_FORMAT).format(new Date());
		inputFields = new HashMap<String,Object>();
		inputFields.put("ISSUE_UBSID","123");
		assertEquals(date,	rule.process(inputFields).get(FinanceExportRule.BUSINESS_DATE_ATTR_NAME));
	}
}
