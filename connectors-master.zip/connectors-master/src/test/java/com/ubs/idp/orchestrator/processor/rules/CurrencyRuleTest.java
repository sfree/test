package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.ubs.idp.domainRegistry.DomainRegistry;
import com.ubs.idp.domainRegistry.common.DomainKey;
import com.ubs.idp.orchestrator.processor.rules.CurrencyRule;

@RunWith(MockitoJUnitRunner.class)
public class CurrencyRuleTest
{
	private Map<String,Object> inputFields;
	
	@Mock(name="domainRegistry")
	DomainRegistry mockDomainRegistry;	
	
	@InjectMocks
	@Resource
	CurrencyRule rule;

	@Before
	public void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);
		inputFields = new HashMap<String,Object>();
		
		// Mock the domain registry
		DomainKey domainKey = new DomainKey();
		domainKey.setDomainKey(100L);
		Mockito.when(mockDomainRegistry.createDomainKey("Currency", "CURRENCY", "CURRENCY.IDP", "UAE Dirham") ).thenReturn(domainKey);
	}

	@Test	
	public void testDeriveMajorCCYCode() {
		inputFields.put(CurrencyRule.MAJOR_CCY_CODE, "AED");
		inputFields.put(CurrencyRule.ISO_NAME, "UAE Dirham");
		
		Map<String,Object> results = rule.derive(inputFields);
		
		assertEquals(100L,results.get(CurrencyRule.DERIVED_UBS_ID));
		assertEquals("AED",results.get(CurrencyRule.DERIVED_CCY_CODE));
		assertEquals(false,results.get(CurrencyRule.DERIVED_IS_MINOR_CCY_CODE));
	}

	@Test	
	public void testDeriveMajorMinorCCYCode() {
		inputFields.put(CurrencyRule.MAJOR_CCY_CODE, "BWP");
		inputFields.put(CurrencyRule.MINOR_CCY_CODE, "BWX");
		inputFields.put(CurrencyRule.ISO_NAME, "UAE Dirham");
		
		Map<String,Object> results = rule.derive(inputFields);
		
		assertEquals(100L,results.get(CurrencyRule.DERIVED_UBS_ID));
		assertEquals("BWP-BWX",results.get(CurrencyRule.DERIVED_CCY_CODE));
		assertEquals(true,results.get(CurrencyRule.DERIVED_IS_MINOR_CCY_CODE));
	}

}
