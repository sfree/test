package com.ubs.idp.connector.spring.batch;

import static org.junit.Assert.*;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.item.ExecutionContext;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;
import com.ubs.idp.connectors.spring.batch.exceptions.BadRowException;
import com.ubs.idp.connectors.spring.batch.readers.CassandraItemReader;

/**
 * JUnit for Cassandra reader
 * @author mcminnp
 */
public class CassandraItemReaderTest {
    
    private static final String PRIMARY_CF = "JUnit"; 

    private static final String PRIMARY_CF_ATTRNAMES[] = {"id", "name", "number", "desc"};
    private static final String INVALID_CF_ATTRNAMES[] = {"id", "name", "number", "desc", "doesNotExist"};
    
    private static final String PRIMARY_DATA_ROW1 = "1\tfoo\t123\tabc";
    private static final String PRIMARY_DATA_ROW2 = "2\tbar\t456\tdef";
    
    @Mock
    CassandraCqlProxy cqlProxy;

    @Mock
    PreparedStatement preparedStateMent;
    
    @Mock
    BoundStatement boundStatement;

    @Mock
    CassandraSessionHelper cassandraSessionHelper;
    
    @Mock
    ResultSet primaryDataRS;
    
    @Mock
    Row primaryDataRow1;

    @Mock
    Row primaryDataRow2;
    
    @InjectMocks
    CassandraItemReader reader;

    @Before
    public void setUp() throws Exception {
        
        reader = setupReader();
        
        // Initialise the mocks
        MockitoAnnotations.initMocks(this);

        // TODO: Implement!

        // Primary data
        
        List<Row> primaryDataRows = new ArrayList<Row>();
        
        primaryDataRows.add(primaryDataRow1);
        primaryDataRows.add(primaryDataRow2);
                
        Iterator<Row> rowIt = primaryDataRows.iterator();

        when(primaryDataRow1.getString("value")).thenReturn(PRIMARY_DATA_ROW1);
        when(primaryDataRow2.getString("value")).thenReturn(PRIMARY_DATA_ROW2);
        when(primaryDataRS.iterator()).thenReturn(rowIt);
        when(cqlProxy.getPrepareStatement(Matchers.anyString())).thenReturn(preparedStateMent);
        when(preparedStateMent.bind()).thenReturn(boundStatement);
        when(cassandraSessionHelper.getProxy()).thenReturn(cqlProxy);

        when(cqlProxy.executeStatement(boundStatement)).thenReturn(primaryDataRS);
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void getPrimaryRowsTest() {
        
        try {
            ExecutionContext ctx = new ExecutionContext();
            
            reader.setColumnFamily(PRIMARY_CF);
            reader.setAttributeNames(PRIMARY_CF_ATTRNAMES);

            reader.afterPropertiesSet();
            
            reader.open(ctx);
            
            int rowCount = 0;
            while(reader.read() != null) {
                rowCount ++;
            }
            
            assertEquals(2, rowCount);
            assertEquals(2, reader.getRowCount());
            
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception: " + e.getClass().getName());
        }
    }

    @Test
    public void badRowTest() {
        
        BadRowException brx = null;
        
        try {
            ExecutionContext ctx = new ExecutionContext();
            
            reader.setColumnFamily(PRIMARY_CF);
            reader.setAttributeNames(INVALID_CF_ATTRNAMES);

            reader.afterPropertiesSet();
            
            reader.open(ctx);
            
            while((reader.read()) != null) {
            }
            
            fail("Should NOT get here!");
        } catch (BadRowException e) {
            brx = e;
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception: " + e.getClass().getName());
        } finally {
            reader.close();
        }
        
        assertNotNull("Did not receive BadRowExecption?", brx);
    }
    
    /**
     * Set up the Cassandra reader
     * @return
     */
    private CassandraItemReader setupReader() {
        
        CassandraItemReader reader = new CassandraItemReader();
                
        return reader;
    }
}