package com.ubs.idp.orchestrator.tasklets;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class CallExternalCmdTaskletTest 
{
	
	@Test
	public void testNoCommandArgs()
	{
		CallExternalCmdTasklet tasklet = new CallExternalCmdTasklet();
		
		try
		{
			tasklet.execute(null, null);
		}
		catch (Exception e)
		{
			assertEquals("Wrong exception message","External command must be set",e.getMessage());
			return;
		}
		fail("Expected exception to be thrown");
	}

	@Test
	public void testNonExistentCommand() 
	{
		CallExternalCmdTasklet tasklet = new CallExternalCmdTasklet();
		try
		{
			tasklet.setCommand("BLAH");
			tasklet.execute(null, null);
		}
		catch (Exception e)
		{
			assertTrue("Wrong exception message",e.getMessage().contains("Cannot run program \"BLAH\""));
			return;
		}
		fail("Expected exception to be thrown");
	}

	@Test
	public void testCommandNoArgs() throws Exception
	{
		CallExternalCmdTasklet tasklet = new CallExternalCmdTasklet();
		
		// Windows
		if( System.getProperty("os.name").toLowerCase().contains("windows") )
		{
			tasklet.setCommand("src/test/resources/test_dir");	
		}
		// Unix
		else
		{
			tasklet.setCommand("ls");
		}
		tasklet.execute(null, null);
	}
	
	@Test
	public void testCommand() throws Exception
	{		
		File targetFile = new File("target/text.xml");
		CallExternalCmdTasklet tasklet = new CallExternalCmdTasklet();
		
		// Windows
		if( System.getProperty("os.name").toLowerCase().contains("windows") )
		{
			tasklet.setCommand(new File("src/test/resources/test_copy.bat").getAbsolutePath());	
		}
		// Unix
		else
		{
			tasklet.setCommand("cp");
		}
		
		tasklet.setWorkingDir(new File("."));
		
		// Test the copy command is executed by copying the logback file to target
		List<Object> cmdList = new ArrayList<Object>();
		cmdList.add(new File("src/test/resources/logback-test.xml").getAbsolutePath());
		cmdList.add(targetFile.getAbsolutePath());		
		tasklet.setCommandArgs(cmdList);
		tasklet.execute(null, null);
		
		assertTrue("Script not called as file has not been copied",targetFile.exists());		
	}
	

}
