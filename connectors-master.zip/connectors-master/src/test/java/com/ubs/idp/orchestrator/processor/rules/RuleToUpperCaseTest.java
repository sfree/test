package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class RuleToUpperCaseTest {

	private RuleToUpperCase rule;

	@Before
	public void setUp() throws Exception {
		rule = new RuleToUpperCase();
	}

	@Test
	public void shouldConvertToUppercase() throws Exception {
		assertEquals("DARTH VADER", rule.process("Darth Vader"));
		assertEquals("DARTH VADER", rule.process("dArTh VaDeR"));
	}

	@Test
	public void shouldNotFailForEmptyString() throws Exception {
		assertEquals("", rule.process(""));
	}

	@Test
	@Ignore("Implementation needs to be fixed, raised IDP-706")
	public void shouldNotFailForNull() throws Exception {
		assertEquals("", rule.process(null));
	}

}
