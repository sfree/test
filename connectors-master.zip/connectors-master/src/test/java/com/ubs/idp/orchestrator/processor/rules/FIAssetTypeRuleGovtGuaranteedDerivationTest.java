package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;
import com.ubs.idp.orchestrator.processor.rules.FIAssetTypeRule;

/**
 * Tests for the Fixed Income Asset Type derivation rules
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Fixed Income Asset Type definition section)
 * @author haniffsy
 */
public class FIAssetTypeRuleGovtGuaranteedDerivationTest {

	private FIAssetTypeRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new FIAssetTypeRule();
		inputFields = new HashMap<String,Object>();
	}
	
	
	// Govt Guaranteed
	
	
	/*
	 * if bbCollateralType match (GOVT*GUARANTEED*|GOVT*LIQUID*GTD*)
	 */
	
	@Test
	public void shouldDeriveGovtGuaranteedsIfBBCollateralTypeMatchesGovtStarGuaranteed() {
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH GOVT BLAH GUARANTEED BLAH");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Govt Guaranteed",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		
	}
	
	@Test
	public void shouldDeriveGovtGuaranteedsIfBBCollateralTypeMatchesGovtStarLiquidStarGTD() {
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH GOVT BLAH LIQUID BLAH GTD BLAH");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Govt Guaranteed",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		
	}
	
}
