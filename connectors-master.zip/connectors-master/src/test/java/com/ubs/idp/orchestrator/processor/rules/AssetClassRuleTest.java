package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.AssetClassRule;
import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;

/**
 * Tests for the Asset Class derivation rules
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Asset Class definition section)
 * @author haniffsy
 */
public class AssetClassRuleTest {

	private AssetClassRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new AssetClassRule();
		inputFields = new HashMap<String,Object>();

	}
	

	// Fixed Income derivation
	
	/*
	 * IF Asset Type IN 
	 * 	["Corporate","Government","Supranational","Municipal","Agency",
	 * 	"MBS","ABS","Pfandbrief","Jumbo Pfandbrief"] 
	 * OR
	 * IF CFI(1) == D AND CIF(2) != Y
	 */
	
	@Test	
	public void shouldDeriveFixedIncomeIfAssetTypeCorporate() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Corporate");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Fixed Income",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveFixedIncomeIfAssetTypeGovernment() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Government");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Fixed Income",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}

	@Test	
	public void shouldDeriveFixedIncomeIfAssetTypeSupranational() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Supranational");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Fixed Income",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveFixedIncomeIfAssetTypeMunicipal() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Municipal");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Fixed Income",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveFixedIncomeIfAssetTypeAgency() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Agency");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Fixed Income",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}	
	
	@Test	
	public void shouldDeriveFixedIncomeIfAssetTypeMBS() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "MBS");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Fixed Income",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}	

	@Test	
	public void shouldDeriveFixedIncomeIfAssetTypeABS() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "ABS");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Fixed Income",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}	
	
	@Test	
	public void shouldDeriveFixedIncomeIfAssetTypePfandbrief() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Pfandbrief");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Fixed Income",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}	

	@Test	
	public void shouldDeriveFixedIncomeIfAssetTypeJumboPfandbrief() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Jumbo Pfandbrief");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Fixed Income",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}	
	
	@Test	
	public void shouldDeriveFixedIncomeIfCFIStartsWithDAndCFISecondNotY() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "DXXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Fixed Income",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}	

	@Test	
	public void shouldNotDeriveFixedIncomeIfCFIStartsWithDAndCFISecondIsY() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "DYXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertFalse("Fixed Income".equals(results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS)));
	}	
	

	// Equity derivation
	
	/*
	 * IF Asset Type IN 
	 * 	["Common Equity","UIT","ADR","ETF","Preference","REIT",
	 * 	"GDR","EDR","Convertible Preference Shares"] 
	 * OR
	 * IF CFI(1) == E
	 */
	
	@Test	
	public void shouldDeriveEquityIfAssetTypeCommonEquity() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Common Equity");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Equity",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveEquityIfAssetTypeUIT() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "UIT");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Equity",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveEquityIfAssetTypeADR() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "ADR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Equity",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveEquityIfAssetTypeETF() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "ETF");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Equity",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveEquityIfAssetTypePreference() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Preference");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Equity",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveEquityIfAssetTypeREIT() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "REIT");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Equity",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveEquityIfAssetTypeGDR() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "GDR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Equity",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveEquityIfAssetTypeEDR() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "EDR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Equity",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveEquityIfAssetTypeConvertiblePreferenceShares() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Convertible Preference Shares");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Equity",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	
	@Test	
	public void shouldDeriveEquityIfCFIStartsWithE() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "EXXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Equity",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}	
	
	@Test	
	public void shouldNotDeriveEquityIfCFIDoesNotStartsWithE() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "DXXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertFalse("Equity".equals(results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS)));
	}	
	
	

	// Money Market Derivation
	
	/*
	 * IF Asset Type IN 
	 * 	["Commercial Paper","Certificates of Deposit"]
	 * OR
	 *  IF CFI(1,2) == DY
	 */
	
	@Test	
	public void shouldDeriveMoneyMarketIfAssetTypeCommercialPaper() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Commercial Paper");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Money Market",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveMoneyMarketIfAssetTypeCertificatesOfDeposit() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Certificates of Deposit");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Money Market",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}

	@Test	
	public void shouldDeriveMoneyMarketIfCFIStartsWithDY() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "DYXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Money Market",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}	
	
	@Test	
	public void shouldNotDeriveMoneyMarketIfCFIDoesNotStartsWithDY() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "DXXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertFalse("Money Market".equals(results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS)));
	}
	
	
	// Warrants derived
	
	/*
	 * IF CFI(1,2) == RW 
	 * OR 
	 * IF CFI(1,2) == MM
	 */
	
	@Test	
	public void shouldDeriveWarrantsIfCFICodeStartsWithRW() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "RWXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Warrants",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveWarrantsIfCFICodeStartsWithMM() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "MMXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Warrants",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldNotDeriveWarrantsIfCFIDoesNotStartsWithRWOrMM() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "RMXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertFalse("Warrants".equals(results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS)));
	}
	
	// Futures derived
	
	/*
	 * IF CFI(1) == F
	 */
	
	@Test	
	public void shouldDeriveFuturesIfCFICodeStartsWithF() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "FXXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Futures",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}

	// Options derived
	
	/*
	 * IF CFI(1) == O
	 */
	
	@Test	
	public void shouldDeriveOptionIfCFICodeStartsWithO() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "OXXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Option",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	
	// Other derived
	
	/*
	 * IF CFI(1,2) == RM
	 * OR
	 * IF CFI(1) == M AND CFI(2) != M
	 */
	
	@Test	
	public void shouldDeriveOtherIfCFICodeStartsWithRM() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "RMXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Other",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldDeriveOtherIfCFICodeStartsWithMAndCFISecondNotM() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "MOXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertEquals("Other",results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
	}
	
	@Test	
	public void shouldNotDeriveOtherIfCFICodeStartsWithMAndCFISecondIsM() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "MMXXXXXX");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertFalse("Other".equals(results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS)));
	}
		
	@Test	
	public void shouldDeriveWhenUbsIsoCfiNotPresent() {
		inputFields.put(DerivationRuleTemplate.CFI_CODE, "ESNUFR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_ASSET_CLASS));
		assertTrue("Equity".equals(results.get(DerivationRuleTemplate.DERIVED_ASSET_CLASS)));
	}
	
}
