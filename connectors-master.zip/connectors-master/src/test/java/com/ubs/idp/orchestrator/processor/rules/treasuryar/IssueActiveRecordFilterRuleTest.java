package com.ubs.idp.orchestrator.processor.rules.treasuryar;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class IssueActiveRecordFilterRuleTest
{
	private IssueActiveRecordFilterRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new IssueActiveRecordFilterRule();
	}
	
	@Test
	public void shouldReturnRecord() throws Exception {
		
		inputFields = new HashMap<String,Object>();
		inputFields.put("issue.active","true");
		assertNotNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("issue.active","yes");
		assertNotNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("issue.active","Y");
		assertNotNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("issue.active","1");
		assertNotNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("issue.active","T");
		assertNotNull( rule.process(inputFields));
	}

	@Test
	public void shouldNotReturnRecord() throws Exception {
		
		inputFields = new HashMap<String,Object>();
		inputFields.put("issue.active","false");
		assertNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("issue.active","no");
		assertNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("issue.active","N");
		assertNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("issue.active","0");
		assertNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("issue.active","F");
		assertNull( rule.process(inputFields));
	}

}
