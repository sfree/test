package com.ubs.idp.connector.spring.batch.readers.xml;

import static org.junit.Assert.fail;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.oxm.jibx.JibxMarshaller;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.StringUtils;

import com.ubs.idp.connectors.spring.batch.exceptions.BadRowException;
import com.ubs.idp.connectors.spring.batch.readers.xml.FileToObjectReader;
import com.ubs.idp.connectors.spring.batch.readers.xml.parsers.LSDBObjectParser;
import com.ubs.idp.connectors.spring.batch.readers.xml.parsers.ObjectHierarchyParser;
import com.ubs.idp.lsdb.model.Company;

/**
 * JUnit for JiBX reader
 * 
 * @author mcnamars
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:jibx-integration-context.xml" })
public class FileToObjectReaderTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileToObjectReaderTest.class);
    private static final String TEST_XML_FILE = "src/test/resources/xml/LSDB_BankUnit_sample.xml";

    private FileToObjectReader testee;

    @Mock
    ExecutionContext executionContext;

    @Autowired
    @Qualifier("jibxMarshaller")
    private JibxMarshaller jibxMarshaller;
    
    private ObjectHierarchyParser<Company> parser = new LSDBObjectParser(); 

    @Before
    public void setUp() throws Exception {

        initMocks(this);

        testee = new FileToObjectReader();
        ReflectionTestUtils.setField(parser, "jibxMarshaller", jibxMarshaller);
        ReflectionTestUtils.setField(testee, "parser", parser);
        testee.setFilename(TEST_XML_FILE);
    }

    @After
    public void tearDown() {

        testee.close();
        testee = null;
    }

    @Test
    public void testGetFilename() {

        assertEquals("filename should match", TEST_XML_FILE, testee.getFilename());
    }

    @Test
    public void openXmlParseAndFirstRecordTest() throws Exception {

        testee.open(executionContext);

        Company company = (Company)testee.read();

        assertEquals("LSDB ID mismatch", "39", company.getId());
    }

    @Test
    public void openXmlParseAndDetectEmptyGcrsTest() throws Exception {

        testee.open(executionContext);

        Company company = null;
        do {
            try {
                company = (Company)testee.read();
                if (company != null) {
                    if (company.getGcrs() != null) {
                        
                        if(StringUtils.isEmpty(company.getGcrs().getGcrsCode())) {
                            fail("company id: " + company.getId() + " has GCRS but had no code!");
                        } 
                    }
                }
            } catch (BadRowException e) {
            }
        } while (company != null);
    }
    
    @Test
    public void processXmlFileAndCheckCountsTest() throws Exception {

        int rowCount = 0;
        int skipCount = 0;
        int gcsCount = 0;
        int subcatCount = 0;
        int parentCount = 0;

        testee.open(executionContext);

        Company company = null;
        do {
            try {
                company = (Company)testee.read();
                if (company != null) {
                    rowCount++;

                    if (company.getGcrs() != null && !StringUtils.isEmpty(company.getGcrs().getGcrsCode())) {
                        gcsCount++;
                    }

                    if (company.getGeneral() != null &&
                        company.getGeneral().getEntityType() != null &&
                        !StringUtils.isEmpty(company.getGeneral().getEntityType().getSubCategoryCode())) {
                        subcatCount++;
                    }
                    
                    if (company.getParents() != null) {
                        parentCount += company.getParents().size();
                        
                        List<Company> legalParents = company.getLegalParents();
                        assertNotNull("Failed to get legal parent for company id: " + company.getId() + ", name: " + company.getRegisteredName(), legalParents);
                        assertEquals("should only be one legal parent.", 1, legalParents.size());
                    }
                }
            } catch (BadRowException e) {
                skipCount++;
                LOGGER.debug("bad row! {}, {} ", skipCount, e.getMessage());
            }
        } while (company != null);

        assertEquals("Unexpected skip count?", 0, skipCount);
        assertEquals("Unexpected row (company) count?", 39, rowCount);
        assertEquals("Unexpected GCRS code count", 39, gcsCount);
        assertEquals("Unexpected sub-category code count?", 39, subcatCount);
        assertEquals("Unexpected parent count?", 2, parentCount);
    }
}