package com.ubs.idp.connectors.jdbc;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;

import org.junit.Before;
import org.junit.Test;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.test.util.ReflectionTestUtils;

public class JDBCConfigProxyImplTest {
	
	private JDBCConfigProxyImpl jdbcConfigProxyImp;
	private SimpleDriverDataSource mockedBean;
	private PreparedStatement mockedPreparedStmt;

	@Before
	public void setUp() throws Exception {
		mockedBean = mock(SimpleDriverDataSource.class);
		mockedPreparedStmt = mock(PreparedStatement.class);
	}
	
	@Test
	public void getDataSourceTest() throws Exception {
		jdbcConfigProxyImp = new JDBCConfigProxyImpl();
		
		JDBCConfig jdbcConfig = new JDBCConfig();
		ReflectionTestUtils.setField(jdbcConfig, "jdbcPassword", "5b5b4d12bac9f6d323ba53804d23f74e");
		ReflectionTestUtils.setField(jdbcConfig, "jdbcUser", "testUserName");
		ReflectionTestUtils.setField(jdbcConfig, "jdbcUrl", "testUrl");
		ReflectionTestUtils.setField(jdbcConfig, "jdbcDriver", "oracle.jdbc.driver.OracleDriver");
		jdbcConfigProxyImp.setJdbcConfig(jdbcConfig);
		jdbcConfigProxyImp.getJdbcConfig();
		SimpleDriverDataSource dataSource = jdbcConfigProxyImp.getDataSource();
		assertEquals("testUserName", dataSource.getUsername());
		assertEquals("testUrl", dataSource.getUrl());
		
		jdbcConfig = new JDBCConfig();
		ReflectionTestUtils.setField(jdbcConfig, "jdbcDriver", "");
		ReflectionTestUtils.setField(jdbcConfig, "jdbcPassword", "5b5b4d12bac9f6d323ba53804d23f74e");
		jdbcConfigProxyImp.setJdbcConfig(jdbcConfig);
		jdbcConfigProxyImp.afterPropertiesSet();
		
	}
	
	@Test
	public void checkConnectionTest() throws SQLException {
		jdbcConfigProxyImp = new JDBCConfigProxyImpl();
		jdbcConfigProxyImp.setBean(mockedBean);
		
		when(mockedBean.getConnection()).thenReturn(null);
		assertFalse(jdbcConfigProxyImp.isConnected());
		
		FakeConnection conn = new FakeConnection();
		when(mockedBean.getConnection()).thenReturn(conn);
		assertTrue(jdbcConfigProxyImp.isConnected());
		
		when(mockedBean.getConnection()).thenThrow(new SQLException());
		assertFalse(jdbcConfigProxyImp.isConnected());
	}
	
	@Test
	public void sqlQueryBuilderTest() throws SQLException {
		ArrayList<String> list = new ArrayList<String>();
		list.add("INT");
		list.add("STRING");
		list.add("LONG");
		list.add("BIGDECIMAL");
		list.add("NOTHING");
		list.add("INT");
		
		Map<Integer,String> map = new HashMap<Integer,String>();
		map.put(1, "1");
		map.put(2, "one");
		map.put(3, "1111222212");
		map.put(4, "1000000000");
		map.put(5, "1000000000");
		
		jdbcConfigProxyImp = new JDBCConfigProxyImpl();
		jdbcConfigProxyImp.sqlQueryBuilder(mockedPreparedStmt, list, map);
		verify(mockedPreparedStmt).setString(2, "one");
		verify(mockedPreparedStmt).setInt(1, 1);
		verify(mockedPreparedStmt).setLong(3, 1111222212l);
		verify(mockedPreparedStmt).setBigDecimal(4, new BigDecimal(1000000000));
		
	}
	
	@Test
	public void executeSelectTest() throws SQLException {
		ArrayList<String> list = new ArrayList<String>();
		list.add("INT");
		list.add("STRING");
		list.add("LONG");
		list.add("BIGDECIMAL");
		
		Map<Integer,String> map = new HashMap<Integer,String>();
		map.put(1, "1");
		map.put(2, "one");
		map.put(3, "1111222212");
		map.put(4, "1000000000");
		
		Connection mockedConn = mock(Connection.class);
		when(mockedBean.getConnection()).thenReturn(mockedConn);
		when(mockedConn.prepareStatement("testingSQL")).thenReturn(mockedPreparedStmt);
		ResultSet rs = mock(ResultSet.class);
		when(mockedPreparedStmt.executeQuery()).thenReturn(rs);
		ResultSetMetaData mockedMetaData = mock(ResultSetMetaData.class);
		when(rs.getMetaData()).thenReturn(mockedMetaData);
		when(mockedMetaData.getColumnCount()).thenReturn(1);
		when(mockedMetaData.getColumnName(1)).thenReturn("one");
		when(rs.getObject(1)).thenReturn("oneValue");
		when(rs.next()).thenReturn(true, false);
		
		jdbcConfigProxyImp = new JDBCConfigProxyImpl();
		jdbcConfigProxyImp.setBean(mockedBean);
		List<Map<String,Object>> result = jdbcConfigProxyImp.executeSelect("testingSQL", list, map);
		assertEquals("oneValue", result.get(0).get("one"));
		
		when(rs.next()).thenReturn(false);
		jdbcConfigProxyImp = new JDBCConfigProxyImpl();
		jdbcConfigProxyImp.setBean(mockedBean);
		jdbcConfigProxyImp.executeSelect("testingSQL", list, map);
		
		when(mockedBean.getConnection()).thenThrow(new SQLException());
		jdbcConfigProxyImp = new JDBCConfigProxyImpl();
		jdbcConfigProxyImp.setBean(mockedBean);
		jdbcConfigProxyImp.executeSelect("testingSQL", list, map);
	}
	
	@Test
	public void executeDMLTest() throws SQLException {
		ArrayList<String> list = new ArrayList<String>();
		list.add("INT");
		list.add("STRING");
		list.add("LONG");
		list.add("BIGDECIMAL");
		Map<Integer,String> map = new HashMap<Integer,String>();
		map.put(1, "1");
		map.put(2, "one");
		map.put(3, "1111222212");
		map.put(4, "1000000000");
		Connection mockedConn = mock(Connection.class);
		when(mockedBean.getConnection()).thenReturn(mockedConn);
		when(mockedConn.prepareStatement("testingSQL")).thenReturn(mockedPreparedStmt);
		when(mockedPreparedStmt.executeUpdate()).thenReturn(1);
		
		jdbcConfigProxyImp = new JDBCConfigProxyImpl();
		jdbcConfigProxyImp.setBean(mockedBean);
		assertTrue(jdbcConfigProxyImp.executeDML("testingSQL", list, map));
		
		when(mockedPreparedStmt.executeUpdate()).thenReturn(0);
		jdbcConfigProxyImp = new JDBCConfigProxyImpl();
		jdbcConfigProxyImp.setBean(mockedBean);
		assertFalse(jdbcConfigProxyImp.executeDML("testingSQL", list, map));
		
		mockedConn = mock(Connection.class);
		when(mockedBean.getConnection()).thenReturn(mockedConn);
		when(mockedConn.prepareStatement("testingSQL")).thenReturn(null);
		jdbcConfigProxyImp = new JDBCConfigProxyImpl();
		jdbcConfigProxyImp.setBean(mockedBean);
		assertFalse(jdbcConfigProxyImp.executeDML("testingSQL", list, map));
		verify(mockedConn).close();
		
		when(mockedBean.getConnection()).thenThrow(new SQLException());
		jdbcConfigProxyImp = new JDBCConfigProxyImpl();
		jdbcConfigProxyImp.setBean(mockedBean);
		assertFalse(jdbcConfigProxyImp.executeDML("testingSQL", list, map));
	}
	
	
	class FakeConnection implements Connection {

		@Override
		public <T> T unwrap(Class<T> iface) throws SQLException {
			return null;
		}

		@Override
		public boolean isWrapperFor(Class<?> iface) throws SQLException {
			return false;
		}

		@Override
		public Statement createStatement() throws SQLException {
			return null;
		}

		@Override
		public PreparedStatement prepareStatement(String sql)
				throws SQLException {
			return null;
		}

		@Override
		public CallableStatement prepareCall(String sql) throws SQLException {
			return null;
		}

		@Override
		public String nativeSQL(String sql) throws SQLException {
			return null;
		}

		@Override
		public void setAutoCommit(boolean autoCommit) throws SQLException {
			
		}

		@Override
		public boolean getAutoCommit() throws SQLException {
			return false;
		}

		@Override
		public void commit() throws SQLException {
			
		}

		@Override
		public void rollback() throws SQLException {
			
		}

		@Override
		public void close() throws SQLException {
			
		}

		@Override
		public boolean isClosed() throws SQLException {
			return false;
		}

		@Override
		public DatabaseMetaData getMetaData() throws SQLException {
			return null;
		}

		@Override
		public void setReadOnly(boolean readOnly) throws SQLException {
			
		}

		@Override
		public boolean isReadOnly() throws SQLException {
			return false;
		}

		@Override
		public void setCatalog(String catalog) throws SQLException {
			
		}

		@Override
		public String getCatalog() throws SQLException {
			return null;
		}

		@Override
		public void setTransactionIsolation(int level) throws SQLException {
			
		}

		@Override
		public int getTransactionIsolation() throws SQLException {
			return 0;
		}

		@Override
		public SQLWarning getWarnings() throws SQLException {
			return null;
		}

		@Override
		public void clearWarnings() throws SQLException {
			
		}

		@Override
		public Statement createStatement(int resultSetType,
				int resultSetConcurrency) throws SQLException {
			return null;
		}

		@Override
		public PreparedStatement prepareStatement(String sql,
				int resultSetType, int resultSetConcurrency)
				throws SQLException {
			return null;
		}

		@Override
		public CallableStatement prepareCall(String sql, int resultSetType,
				int resultSetConcurrency) throws SQLException {
			return null;
		}

		@Override
		public Map<String, Class<?>> getTypeMap() throws SQLException {
			return null;
		}

		@Override
		public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
			
		}

		@Override
		public void setHoldability(int holdability) throws SQLException {
			
		}

		@Override
		public int getHoldability() throws SQLException {
			return 0;
		}

		@Override
		public Savepoint setSavepoint() throws SQLException {
			return null;
		}

		@Override
		public Savepoint setSavepoint(String name) throws SQLException {
			return null;
		}

		@Override
		public void rollback(Savepoint savepoint) throws SQLException {
			
		}

		@Override
		public void releaseSavepoint(Savepoint savepoint) throws SQLException {
		}

		@Override
		public Statement createStatement(int resultSetType,
				int resultSetConcurrency, int resultSetHoldability)
				throws SQLException {
			return null;
		}

		@Override
		public PreparedStatement prepareStatement(String sql,
				int resultSetType, int resultSetConcurrency,
				int resultSetHoldability) throws SQLException {
			return null;
		}

		@Override
		public CallableStatement prepareCall(String sql, int resultSetType,
				int resultSetConcurrency, int resultSetHoldability)
				throws SQLException {
			return null;
		}

		@Override
		public PreparedStatement prepareStatement(String sql,
				int autoGeneratedKeys) throws SQLException {
			return null;
		}

		@Override
		public PreparedStatement prepareStatement(String sql,
				int[] columnIndexes) throws SQLException {
			return null;
		}

		@Override
		public PreparedStatement prepareStatement(String sql,
				String[] columnNames) throws SQLException {
			return null;
		}

		@Override
		public Clob createClob() throws SQLException {
			return null;
		}

		@Override
		public Blob createBlob() throws SQLException {
			return null;
		}

		@Override
		public NClob createNClob() throws SQLException {
			return null;
		}

		@Override
		public SQLXML createSQLXML() throws SQLException {
			return null;
		}

		@Override
		public boolean isValid(int timeout) throws SQLException {
			return false;
		}

		@Override
		public void setClientInfo(String name, String value)
				throws SQLClientInfoException {
		}

		@Override
		public void setClientInfo(Properties properties)
				throws SQLClientInfoException {
		}

		@Override
		public String getClientInfo(String name) throws SQLException {
			return null;
		}

		@Override
		public Properties getClientInfo() throws SQLException {
			return null;
		}

		@Override
		public Array createArrayOf(String typeName, Object[] elements)
				throws SQLException {
			return null;
		}

		@Override
		public Struct createStruct(String typeName, Object[] attributes)
				throws SQLException {
			return null;
		}

		@Override
		public void setSchema(String schema) throws SQLException {
		}

		@Override
		public String getSchema() throws SQLException {
			return null;
		}

		@Override
		public void abort(Executor executor) throws SQLException {
		}

		@Override
		public void setNetworkTimeout(Executor executor, int milliseconds)
				throws SQLException {			
		}

		@Override
		public int getNetworkTimeout() throws SQLException {
			return 0;
		}
	}

}
