package com.ubs.idp.connector.spring.batch.utils;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.ubs.idp.connectors.spring.batch.utils.TokenPreprocessor;

public class TokenPreprocessorTest {

    @Test
    public void test() {
        TokenPreprocessor processor = new TokenPreprocessor();
        
        Map<String, String> tokenMap = new HashMap<String, String>();
        
        tokenMap.put("foo", "bar");
        
        String testValueIn = "Replace '${foo}' with 'bar'";
        String expectedResult = "Replace 'bar' with 'bar'";
        
        processor.setTokenMap(tokenMap);
        
        String testValueOut = processor.preProcess(testValueIn);
        
        assertEquals("Unexpected result from token pre-processor", expectedResult, testValueOut);
    }
}
