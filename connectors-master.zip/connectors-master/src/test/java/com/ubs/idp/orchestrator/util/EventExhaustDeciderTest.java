/**
 * 
 */
package com.ubs.idp.orchestrator.util;

import static org.junit.Assert.*;

import java.util.Collections;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.item.ExecutionContext;


public class EventExhaustDeciderTest {

	private JobExecution jobExecution;
	private StepExecution stepExecution1;
	private StepExecution stepExecution2;
	private StepExecution stepExecution3;
	private StepExecution stepExecution4;
	private StepExecution stepExecution5;
	private ExecutionContext executionContext1;
	private ExecutionContext executionContext2;
	private ExecutionContext executionContext3;
	private ExecutionContext executionContext4;
	private ExecutionContext executionContext5;

	private EventExhaustDecider eventExhaustDecider;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		eventExhaustDecider = new EventExhaustDecider();
		jobExecution = new JobExecution(1l);
		stepExecution1 = new StepExecution("step1", jobExecution);
		stepExecution2 = new StepExecution("step2", jobExecution);
		stepExecution3 = new StepExecution("step3", jobExecution);
		stepExecution4 = new StepExecution("step4", jobExecution);
		stepExecution5 = new StepExecution("step5", jobExecution);
		jobExecution.addStepExecutions(Collections
				.singletonList(stepExecution1));
		jobExecution.addStepExecutions(Collections
				.singletonList(stepExecution2));
		jobExecution.addStepExecutions(Collections
				.singletonList(stepExecution3));
		jobExecution.addStepExecutions(Collections
				.singletonList(stepExecution4));
		jobExecution.addStepExecutions(Collections
				.singletonList(stepExecution5));

		executionContext1 = new ExecutionContext();
		executionContext1.put("ItemsListSize", 5);
		executionContext1.put("index", 0);
		executionContext2 = new ExecutionContext();
		executionContext2.put("ItemsListSize", 5);
		executionContext2.put("index", 5);
		executionContext3 = new ExecutionContext();
		executionContext3.put("ItemsListSize",5);
		executionContext3.put("index", 4);
		executionContext4 = new ExecutionContext();
		executionContext4.put("ItemsListSize", 5);
		executionContext4.put("index", 6);
		executionContext5 = new ExecutionContext();
		executionContext5.put("ItemsListSize", 0);
		executionContext5.put("index", 0);

	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		  jobExecution=null;
		  stepExecution1=null;
		  stepExecution2=null;
		  stepExecution3=null;
		  stepExecution4=null;
		  stepExecution5=null;
		  executionContext1=null;
		  executionContext2=null;
		  executionContext3=null;
		  executionContext4=null;
		  executionContext5=null;
	}

	/**
	 * Test method for
	 * {@link com.ubs.idp.orchestrator.util.EventExhaustDecider#decide(org.springframework.batch.core.JobExecution, org.springframework.batch.core.StepExecution)}
	 * .
	 */
	@Test
	public void testDecide() {

		jobExecution.setExecutionContext(executionContext5);
		Assert.assertEquals(FlowExecutionStatus.COMPLETED.toString(),
				eventExhaustDecider.decide(jobExecution, stepExecution1)
						.toString());

		jobExecution.setExecutionContext(executionContext2);
		Assert.assertEquals(FlowExecutionStatus.COMPLETED.toString(),
				eventExhaustDecider.decide(jobExecution, stepExecution5)
						.toString());

		jobExecution.setExecutionContext(executionContext3);
		Assert.assertEquals(FlowExecutionStatus.UNKNOWN.toString(),
				eventExhaustDecider.decide(jobExecution, stepExecution4)
						.toString());

		jobExecution.setExecutionContext(executionContext4);
		Assert.assertEquals(FlowExecutionStatus.COMPLETED.toString(),
				eventExhaustDecider.decide(jobExecution, stepExecution3)
						.toString());

	}

}
