package com.ubs.idp.connector.spring.batch.readers.xml.parsers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.stream.StreamSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.oxm.jibx.JibxMarshaller;
import org.springframework.test.util.ReflectionTestUtils;

import com.ubs.idp.connectors.spring.batch.readers.xml.parsers.LSDBObjectParser;
import com.ubs.idp.lsdb.model.BankUnit;
import com.ubs.idp.lsdb.model.Company;
import com.ubs.idp.lsdb.model.EntityType;
import com.ubs.idp.lsdb.model.GCRS;
import com.ubs.idp.lsdb.model.General;
import com.ubs.idp.lsdb.model.Holding;
import com.ubs.idp.lsdb.model.Name;

/**
 * JUnit for JiBX reader
 * 
 * @author mcnamars
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(JibxMarshaller.class)
public class LSDBObjectParserTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(LSDBObjectParserTest.class);
    private static final String LEGAL_STRUCTURE_ID = "1";
    private static final String TEST_XML_FILE = "src/test/resources/xml/LSDB_BankUnit_sample.xml";
    
    private JibxMarshaller jibxMarshallerMock;

    private LSDBObjectParser testee;

    @Before
    public void setUp() throws Exception {

        initMocks(this);
        jibxMarshallerMock = PowerMockito.mock(JibxMarshaller.class);
        testee = new LSDBObjectParser();
        ReflectionTestUtils.setField(testee, "jibxMarshaller", jibxMarshallerMock);
    }

    @After
    public void tearDown() {

        testee.close();
        testee = null;
    }

    @Test
    public void noCompanyTest() throws Exception {

        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(new BankUnit());

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNull(companies);
    }

    /**
     *     |
     *     * company
     */
    @Test
    public void createCompanyHierarchy_A_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_A_Test()");
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(createCompanyHierarchy_A());

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(1, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else {
                fail("expected company id '1'");
            }
        }
    }

    /**
     *     |
     *     * branch(1)
     */
    @Test
    public void createCompanyHierarchy_A2_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_A_Test()");
        
        BankUnit bankUnit = createCompanyHierarchy_A();
        
        // Mark as branch
        setCompanySubCategoryCode(bankUnit, "1", EntityType.BRANCH_CODE_BS);
        
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(bankUnit);

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(1, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else {
                fail("expected company id '1'");
            }
        }
    }

    /**
     *     *(1) *(2)
     *      \   /
     *       \ /
     *        * company (3)
     */
    @Test
    public void createCompanyHierarchy_B_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_B_Test()");
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(createCompanyHierarchy_B());

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(3, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("3")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getLegalParents().size());
                assertEquals(2, company.getParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "1", company.getLegalParents().get(0).getId());
            }
        }
    }
    
    /**
     *     *(1) *(2)
     *      \   /
     *       \ /
     *        * branch (3)
     */
    @Test
    public void createCompanyHierarchy_B2_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_B_Test()");
        
        BankUnit bankUnit = createCompanyHierarchy_B();
        
        // Mark company 3 as a branch
        setCompanySubCategoryCode(bankUnit, "3", EntityType.BRANCH_CODE_BR);
        
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(bankUnit);

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(3, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("3")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "1", company.getLegalParents().get(0).getId());
            }
        }
    }

    /**
     *   *legal(1)
     *    \
     *     *branch(2) *legal(3)
     *      \   /
     *       \ /
     *        * company(4)
     */
    @Test
    public void createCompanyHierarchy_C_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_C_Test()");
        
        BankUnit bankUnit = createCompanyHierarchy_C();
        
        // Make company 2 a branch resulting in legal parent of company 3
        
        setCompanySubCategoryCode(bankUnit, "2", EntityType.BRANCH_CODE_BR);
        
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(bankUnit);

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(4, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "1", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("3")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("4")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "3", company.getLegalParents().get(0).getId());
            }
        }
    }

    /**
     *   *legal(1)
     *    \
     *     *branch(2) *branch(3)
     *      \   /
     *       \ /
     *        * branch(4)
     */
    @Test
    public void createCompanyHierarchy_C1_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_C_Test()");
        
        BankUnit bankUnit = createCompanyHierarchy_C();

        // Mark companies 2, 3 and 4 as a branch to force legal parent of 1
        
        setCompanySubCategoryCode(bankUnit, "2", EntityType.BRANCH_CODE_BR);
        setCompanySubCategoryCode(bankUnit, "3", EntityType.BRANCH_CODE_BS);
        setCompanySubCategoryCode(bankUnit, "4", EntityType.BRANCH_CODE_BS);

        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(bankUnit);

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(4, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company legalParent : company.getLegalParents()) {
                    assertEquals("the legal parent should have an id of '1'", "1", legalParent.getId());
                }
            } else if (company.getId().equals("3")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("4")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "1", company.getLegalParents().get(0).getId());
            }
        }
    }
    
    /**
     *   *legal(1)
     *    \
     *     *branch(2) *legal(3)
     *      \   /
     *       \ /
     *        * branch(4)
     */
    @Test
    public void createCompanyHierarchy_C2_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_C_Test()");
        
        BankUnit bankUnit = createCompanyHierarchy_C();

        // Mark companies 2 and 4 as a branch to force legal parent of 3
        
        setCompanySubCategoryCode(bankUnit, "2", EntityType.BRANCH_CODE_BR);
        setCompanySubCategoryCode(bankUnit, "4", EntityType.BRANCH_CODE_BS);

        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(bankUnit);

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(4, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company legalParent : company.getLegalParents()) {
                    assertEquals("the legal parent should have an id of '1'", "1", legalParent.getId());
                }
            } else if (company.getId().equals("3")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("4")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "3", company.getLegalParents().get(0).getId());
            }
        }
    }
    
    /**
     *     * legal(1)
     *     |
     *     * immediate(2)
     *     |
     *     * company(3)
     */
    @Test
    public void createCompanyHierarchy_D_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_D_Test()");
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(createCompanyHierarchy_D());

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(3, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company legalParent : company.getLegalParents()) {
                    assertEquals("the legal parent should have an id of '1'", "1", legalParent.getId());
                }
            } else if (company.getId().equals("3")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '2'", "2", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "2", company.getLegalParents().get(0).getId());
            }
        }
    }
    
    /**
     *     * legal(1)
     *     |
     *     * immediate(2)
     *     |
     *     * branch(3)
     */
    @Test
    public void createCompanyHierarchy_D2_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_D_Test()");
        
        BankUnit bankUnit = createCompanyHierarchy_D();
        
        // Mark company 2 as a branch
        setCompanySubCategoryCode(bankUnit, "2", EntityType.BRANCH_CODE_BR);
        
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(bankUnit);

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(3, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company legalParent : company.getLegalParents()) {
                    assertEquals("the legal parent should have an id of '1'", "1", legalParent.getId());
                }
            } else if (company.getId().equals("3")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '2'", "2", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company legalParent : company.getLegalParents()) {
                    assertEquals("the legal parent should have an id of '1'", "1", legalParent.getId());
                }
            }
        }
    }
    
    /**
     *     * legal(1)
     *     |
     *     * immediate(2)
     *     |
     *     * immediate(3)
     *     |
     *     * company(4)
     */
    @Test
    public void createCompanyHierarchy_E_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_E_Test()");
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(createCompanyHierarchy_E());

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(4, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company legalParent : company.getLegalParents()) {
                    assertEquals("the legal parent should have an id of '1'", "1", legalParent.getId());
                }
            } else if (company.getId().equals("3")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals("the immediate parent should have an id of '2'", "2", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "2", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("4")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals("the immediate parent should have an id of '3'", "3", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "3", company.getLegalParents().get(0).getId());
            }
        }
    }
    
    /**
     *     * legal(1)
     *     |
     *     * immediate(2)
     *     |
     *     * branch (3)
     *     |
     *     * company(4)
     */
    @Test
    public void createCompanyHierarchy_E2_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_E_Test()");
        
        BankUnit bankUnit = createCompanyHierarchy_E();
        
        // Mark intermediate company as branch (probably un-realsitic)
        
        setCompanySubCategoryCode(bankUnit, "3", EntityType.BRANCH_CODE_BR);
        
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(bankUnit);

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(4, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "1", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("3")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals("the immediate parent should have an id of '2'", "2", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "2", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("4")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals("the immediate parent should have an id of '3'", "3", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "2", company.getLegalParents().get(0).getId());
            }
        }
    }

    /**
     *        * legal(1)
     *       / \
     *      /   \
     *     *i(2) *branch(3)
     *      \   /
     *       \ /
     *        * company(4)
     */
    @Test
    public void createCompanyHierarchy_F_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_F_Test()");
        
        BankUnit bankUnit = createCompanyHierarchy_F();
        
        // Make company 3 a branch to make 2 the legal parent of 4
        
        setCompanySubCategoryCode(bankUnit, "3", EntityType.BRANCH_CODE_BR);
        
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(bankUnit);

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(4, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "1", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("3")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "1", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("4")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parent ID?", "2", company.getLegalParents().get(0).getId());
            }
        }
    }
    
    /**
     *        * legal(1)
     *       / \
     *      /   \
     *     *i(2) *i(3)
     *      \   /
     *       \ /
     *        * branch(4)
     */
    @Test
    public void createCompanyHierarchy_F2_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_F_Test()");
        
        BankUnit bankUnit = createCompanyHierarchy_F();
        
        // Mark company 3 as branch (makes 2 legal parent of 4)
        
        setCompanySubCategoryCode(bankUnit, "3", EntityType.BRANCH_CODE_BR);
        
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(bankUnit);

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(4, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "1", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("3")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "1", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("4")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "2", company.getLegalParents().get(0).getId());
            }
        }
    }

    /**
     *        * legal(1)
     *       / \
     *      /   \    
     *     *i(2) *i(3)
     *     |     |
     *     *i(4) *i(5) / 60%
     *      \   /
     *       \ /
     *        * company(6)
     */
    @Test
    public void createCompanyHierarchy_G_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_G_Test()");
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(createCompanyHierarchy_G());

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(6, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company legalParent : company.getLegalParents()) {
                    assertEquals("the legal parent should have an id of '1'", "1", legalParent.getId());
                }
            } else if (company.getId().equals("3")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company legalParent : company.getLegalParents()) {
                    assertEquals("the legal parent should have an id of '1'", "1", legalParent.getId());
                }
            } else if (company.getId().equals("4")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '2'", "2", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "2", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("5")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '3'", "3", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "3", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("6")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "4", company.getLegalParents().get(0).getId());
            }
        }
    }

    /**
     *  *legal(1)       *legal(7) 
     *  |              /
     *  |             /
     *  *i(2) *l(3)  *i(6)
     *   \     \    /
     *    \     \  /
     *     *i(4) *i(5)
     *      \   /
     *       \ /
     *        * company(8)
     */
    @Test
    public void createCompanyHierarchy_H_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_H_Test()");
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(createCompanyHierarchy_H());

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(8, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "1", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("3")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("4")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '2'", "2", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "2", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("5")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company parent : company.getParents()) {
                    if (!"3".equals(parent.getId()) && !"6".equals(parent.getId())) {
                        fail("the immediate parent should have an id of '3' || '6'");
                    }
                }
                assertEquals("Invalid legal parentID?", "3", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("7")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("6")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "7", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("8")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company parent : company.getParents()) {
                    if (!"4".equals(parent.getId()) && !"5".equals(parent.getId())) {
                        fail("the immediate parent should have an id of '4' || '5'");
                    }
                }
                assertEquals("Invalid legal parentID?", "4", company.getLegalParents().get(0).getId());
            }
        }
    }

    /**
     *  *legal(1)       *legal(7) 
     *  |              /
     *  |             /
     *  *i(2) *l(3)  *i(6)
     *   \     \    /
     *    \     \  /
     *     *i(4) *branch(5)
     *      \   /
     *       \ /
     *        * company(8)
     */
    @Test
    public void createCompanyHierarchy_H2_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_H_Test()");
        
        BankUnit bankUnit = createCompanyHierarchy_H();
        
        // Mark company 5 as branch
        
        setCompanySubCategoryCode(bankUnit, "5", EntityType.BRANCH_CODE_BS);
        
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(bankUnit);

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(8, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '1'", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company legalParent : company.getLegalParents()) {
                    assertEquals("the legal parent should have an id of '1'", "1", legalParent.getId());
                }
            } else if (company.getId().equals("3")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("4")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertEquals("the immediate parent should have an id of '2'", "2", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "2", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("5")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company parent : company.getParents()) {
                    if (!"3".equals(parent.getId()) && !"6".equals(parent.getId())) {
                        fail("the immediate parent should have an id of '3' || '6'");
                    }
                }
                assertEquals("Invalid legal parentID?", "3", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("7")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("6")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "7", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("8")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                for (Company parent : company.getParents()) {
                    if (!"4".equals(parent.getId()) && !"5".equals(parent.getId())) {
                        fail("the immediate parent should have an id of '4' || '5'");
                    }
                }
                assertEquals("Invalid legal parentID?", "4", company.getLegalParents().get(0).getId());
            }
        }
    }
    
    /**
     *        * legal(1)
     *        |
     *        * i(2)
     *       / \
     *      /   \
     *     *i(3) *i(4)
     *      \   /
     *       \ /
     *        * company(5)
     */
    @Test
    public void createCompanyHierarchy_I_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_I_Test()");
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(createCompanyHierarchy_I());

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(5, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNull("Unexpected immediate parents?", company.getParents());
                assertNull("Unexpected legal parents?", company.getLegalParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals("Invalid immediate parent ID?", "1", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "1", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("3")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals("Invalid immediate parent ID?", "2", company.getParents().get(0).getId());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "2", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("4")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "2", company.getLegalParents().get(0).getId());
            } else if (company.getId().equals("5")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
                assertEquals("Invalid legal parentID?", "3", company.getLegalParents().get(0).getId());
            }
        }
    }

    /**
     *        * company(1)
     *       / \
     *      /   \
     *     *i(2) *i(3)
     *      \   /
     *       \ /
     *        * company(1)
     */
    @Test
    public void createCompanyHierarchy_InvalidA_Test() throws Exception {

        LOGGER.debug("running test createCompanyHierarchy_InvalidA_Test()");
        when(jibxMarshallerMock.unmarshal(any(StreamSource.class))).thenReturn(createCompanyHierarchy_InvalidA());

        List<Company> companies = testee.parseData(TEST_XML_FILE);
        assertNotNull(companies);
        assertEquals(3, companies.size());

        for (Company company : companies) {

            if (company.getId().equals("1")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(2, company.getParents().size());
                assertTrue("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("2")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
                assertEquals(1, company.getLegalParents().size());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
            } else if (company.getId().equals("3")) {
                assertNotNull("Missing immediate parents?", company.getParents());
                assertFalse("Invalid mutiple parent flag?", company.getMultiParent());
                assertNotNull("Missing legal parents?", company.getLegalParents());
                assertEquals(1, company.getParents().size());
            }
        }
    }

    /**
     *     |
     *     * company(1)
     */
    private BankUnit createCompanyHierarchy_A() {

        BankUnit bankUnit = new BankUnit();

        List<Company> companies = new ArrayList<Company>();
        Company company = createCompany("company", "1", "gcrs_1");
        companies.add(company);
        bankUnit.setCompanyList(companies);

        return bankUnit;
    }

    /**
     *     *(1) *(2)
     *      \   /
     *       \ /
     *        * company
     */
    private BankUnit createCompanyHierarchy_B() {

        BankUnit bankUnit = new BankUnit();

        List<Company> companies = new ArrayList<Company>();
        Company legalParent1 = createCompany("immediateLegalParent", "1", "gcrs_1");
        Company legalParent2 = createCompany("immediateLegalParent", "2", "gcrs_2");

        Company company = createCompany("company", "3", "gcrs_3");
        List<Holding> holdings = new ArrayList<Holding>();
        holdings.add(createHolding("1", 50f));
        holdings.add(createHolding("2", 50f));
        company.setHoldings(holdings);

        companies.add(legalParent1);
        companies.add(legalParent2);
        companies.add(company);
        bankUnit.setCompanyList(companies);

        return bankUnit;
    }
    
    /**
     *   *legal(1)
     *    \
     *     *i(2) *i/legal(3)
     *      \   /
     *       \ /
     *        * company(4)
     */
    private BankUnit createCompanyHierarchy_C() {

        BankUnit bankUnit = new BankUnit();

        List<Company> companies = new ArrayList<Company>();

        Company legalParent = createCompany("legalParent", "1", "gcrs_1");
        Company immediateLegalParent = createCompany("immediateLegalParent", "3", "gcrs_3");

        Company immediateParent = createCompany("immediateParent", "2", "gcrs_2");
        immediateParent.setHoldings(createSingleHolding("1", 100f));

        Company company = createCompany("company", "4", "gcrs_4");
        List<Holding> holdings = new ArrayList<Holding>();
        holdings.add(createHolding("2", 50f));
        holdings.add(createHolding("3", 50f));
        company.setHoldings(holdings);

        companies.add(legalParent);
        companies.add(immediateLegalParent);
        companies.add(immediateParent);
        companies.add(company);
        bankUnit.setCompanyList(companies);

        return bankUnit;
    }

    /**
     *     * legal(1)
     *     |
     *     * immediate(2)
     *     |
     *     * company(3)
     */
    private BankUnit createCompanyHierarchy_D() {

        BankUnit bankUnit = new BankUnit();

        List<Company> companies = new ArrayList<Company>();

        Company legalParent = createCompany("legalParent", "1", "gcrs_1");

        Company immediateParent = createCompany("immediateParent", "2", "gcrs_2");
        immediateParent.setHoldings(createSingleHolding("1", 100f));

        Company company = createCompany("company", "3", "gcrs_3");
        company.setHoldings(createSingleHolding("2", 100f));

        companies.add(immediateParent);
        companies.add(legalParent);
        companies.add(company);

        bankUnit.setCompanyList(companies);

        return bankUnit;
    }

    /**
     *     * legal(1)
     *     |
     *     * immediate(2)
     *     |
     *     * immediate(3)
     *     |
     *     * company(4)
     */
    private BankUnit createCompanyHierarchy_E() {

        BankUnit bankUnit = new BankUnit();

        List<Company> companies = new ArrayList<Company>();

        Company legalParent = createCompany("legalParent", "1", "gcrs_1");

        Company immediateParent1 = createCompany("immediateParent1", "2", "gcrs_2");
        immediateParent1.setHoldings(createSingleHolding("1", 100f));

        Company immediateParent2 = createCompany("immediateParent2", "3", "gcrs_3");
        immediateParent2.setHoldings(createSingleHolding("2", 100f));

        Company company = createCompany("company", "4", "gcrs_4");
        company.setHoldings(createSingleHolding("3", 100f));

        companies.add(immediateParent1);
        companies.add(legalParent);
        companies.add(immediateParent2);
        companies.add(company);

        bankUnit.setCompanyList(companies);

        return bankUnit;
    }

    /**
     *        * legal(1)
     *       / \
     *      /   \
     *     *i(2) *i(3)
     *      \   /
     *       \ /
     *        * company(4)
     */
    private BankUnit createCompanyHierarchy_F() {

        BankUnit bankUnit = new BankUnit();

        List<Company> companies = new ArrayList<Company>();

        Company legalParent = createCompany("legalParent", "1", "gcrs_1");

        Company immediateParent1 = createCompany("immediateParent1", "2", "gcrs_2");
        immediateParent1.setHoldings(createSingleHolding("1", 100f));

        Company immediateParent2 = createCompany("immediateParent2", "3", "gcrs_3");
        immediateParent2.setHoldings(createSingleHolding("1", 100f));

        Company company = createCompany("company", "4", "gcrs_4");
        List<Holding> holdings = new ArrayList<Holding>();
        holdings.add(createHolding("2", 50f));
        holdings.add(createHolding("3", 50f));
        company.setHoldings(holdings);

        companies.add(immediateParent1);
        companies.add(legalParent);
        companies.add(immediateParent2);
        companies.add(company);

        bankUnit.setCompanyList(companies);

        return bankUnit;
    }

    /**
     *        * legal(1)
     *       / \
     *      /   \    
     *     *i(2) *i(3)
     *     |     |
     *     *i(4) *i(5) / 60%
     *      \   /
     *       \ /
     *        * company(6)
     */
    private BankUnit createCompanyHierarchy_G() {

        BankUnit bankUnit = new BankUnit();

        List<Company> companies = new ArrayList<Company>();

        Company legalParent = createCompany("legalParent", "1", "gcrs_1");

        Company immediateParent1 = createCompany("immediateParent1", "2", "gcrs_2");
        immediateParent1.setHoldings(createSingleHolding("1", 100f));

        Company immediateParent2 = createCompany("immediateParent2", "3", "gcrs_3");
        immediateParent2.setHoldings(createSingleHolding("1", 100f));

        Company immediateParent3 = createCompany("immediateParent3", "4", "gcrs_4");
        immediateParent3.setHoldings(createSingleHolding("2", 100f));

        Company immediateParent4 = createCompany("immediateParent4", "5", "gcrs_5");
        immediateParent4.setHoldings(createSingleHolding("3", 100f));

        Company company = createCompany("company", "6", "gcrs_4");
        List<Holding> holdings = new ArrayList<Holding>();
        holdings.add(createHolding("4", 40f));
        holdings.add(createHolding("5", 60f));
        company.setHoldings(holdings);

        companies.add(immediateParent3);
        companies.add(immediateParent4);
        companies.add(immediateParent1);
        companies.add(legalParent);
        companies.add(immediateParent2);
        companies.add(company);

        bankUnit.setCompanyList(companies);

        return bankUnit;
    }

    /**
     *  *legal(1)       *legal(7) 
     *  |              /
     *  |             /
     *  *i(2) *l(3)  *i(6)
     *   \     \    /
     *    \     \  /
     *     *i(4) *i(5)
     *      \   /
     *       \ /
     *        * company(8)
     */
    private BankUnit createCompanyHierarchy_H() {

        BankUnit bankUnit = new BankUnit();

        List<Company> companies = new ArrayList<Company>();

        Company legalParent1 = createCompany("legalParent", "1", "gcrs_1");

        Company immediateParent1 = createCompany("immediateParent1", "2", "gcrs_2");
        immediateParent1.setHoldings(createSingleHolding("1", 100f));

        Company legalParent2 = createCompany("legalParent2", "3", "gcrs_3");

        Company immediateParent3 = createCompany("immediateParent3", "4", "gcrs_4");
        immediateParent3.setHoldings(createSingleHolding("2", 100f));

        Company immediateParent4 = createCompany("immediateParent4", "5", "gcrs_5");
        List<Holding> holdings = new ArrayList<Holding>();
        holdings.add(createHolding("3", 40f));
        holdings.add(createHolding("6", 60f));
        immediateParent4.setHoldings(holdings);

        Company legalParent3 = createCompany("legalParent3", "7", "gcrs_7");

        Company immediateParent2 = createCompany("immediateParent5", "6", "gcrs_6");
        immediateParent2.setHoldings(createSingleHolding("7", 100f));

        Company company = createCompany("company", "8", "gcrs_8");
        holdings = new ArrayList<Holding>();
        holdings.add(createHolding("4", 40f));
        holdings.add(createHolding("5", 60f));
        company.setHoldings(holdings);

        companies.add(immediateParent2);
        companies.add(immediateParent3);
        companies.add(immediateParent1);
        companies.add(legalParent1);
        companies.add(legalParent2);
        companies.add(immediateParent4);
        companies.add(legalParent3);
        companies.add(company);

        bankUnit.setCompanyList(companies);

        return bankUnit;
    }

    /**
     *        * legal(1)
     *        |
     *        * i(2)
     *       / \
     *      /   \
     *     *i(3) *i(4)
     *      \   /
     *       \ /
     *        * company(5)
     */
    private BankUnit createCompanyHierarchy_I() {

        BankUnit bankUnit = new BankUnit();

        List<Company> companies = new ArrayList<Company>();

        Company legalParent = createCompany("legalParent", "1", "gcrs_1");

        Company immediateParent1 = createCompany("immediateParent1", "2", "gcrs_2");
        immediateParent1.setHoldings(createSingleHolding("1", 100f));

        Company immediateParent2 = createCompany("immediateParent2", "3", "gcrs_3");
        immediateParent2.setHoldings(createSingleHolding("2", 50f));

        Company immediateParent3 = createCompany("immediateParent3", "4", "gcrs_4");
        immediateParent3.setHoldings(createSingleHolding("2", 50f));

        Company company = createCompany("company", "5", "gcrs_5");
        List<Holding> holdings = new ArrayList<Holding>();
        holdings.add(createHolding("3", 50f));
        holdings.add(createHolding("4", 50f));
        company.setHoldings(holdings);

        companies.add(immediateParent1);
        companies.add(legalParent);
        companies.add(immediateParent2);
        companies.add(immediateParent3);
        companies.add(company);

        bankUnit.setCompanyList(companies);

        return bankUnit;
    }

    /**
     *        * company(1)
     *       / \
     *      /   \
     *     *i(2) *i(3)
     *      \   /
     *       \ /
     *        * company(1)
     */
    private BankUnit createCompanyHierarchy_InvalidA() {

        BankUnit bankUnit = new BankUnit();

        List<Company> companies = new ArrayList<Company>();

        Company legalParent = createCompany("legalParent", "1", "gcrs_1");

        Company immediateParent1 = createCompany("immediateParent1", "2", "gcrs_2");
        immediateParent1.setHoldings(createSingleHolding("1", 100f));

        Company immediateParent2 = createCompany("immediateParent2", "3", "gcrs_3");
        immediateParent2.setHoldings(createSingleHolding("1", 100f));

        List<Holding> holdings = new ArrayList<Holding>();
        holdings.add(createHolding("2", 50f));
        holdings.add(createHolding("3", 50f));
        legalParent.setHoldings(holdings);

        companies.add(immediateParent1);
        companies.add(legalParent);
        companies.add(immediateParent2);

        bankUnit.setCompanyList(companies);

        return bankUnit;
    }
    
    private Company createCompany(String companyName, String id, String gcrsCode) {
        Company company = new Company();
        company.setId(id);
        List<Name> names = new ArrayList<Name>();
        Name name = new Name();
        name.setContent(companyName);
        names.add(name);
        company.setNameList(names);
        GCRS gcrs = new GCRS();
        gcrs.setGcrsCode(gcrsCode);
        company.setGcrs(gcrs);
        return company;
    }
    
    private void setCompanySubCategoryCode(BankUnit bankUnit, String id, String subCategoryCode) {
        List<Company> companies = bankUnit.getCompanyList();
        for (Company company : companies) {
            if (company.getId().equals(id)) {
                setCompanySubCategoryCode(company, subCategoryCode);
            }
        }
    }
    
    private void setCompanySubCategoryCode(Company company, String subCategoryCode) {
        General general = new General();
        EntityType entityType = new EntityType();
        entityType.setSubCategoryCode(subCategoryCode);
        general.setEntityType(entityType);
        company.setGeneral(general);
    }

    private Holding createHolding(String id, Float percentage) {
        Holding holding = new Holding();
        holding.setId(id);
        holding.setPercentage(percentage);
        holding.setStartDate("2000-11-03");
        holding.setTypeId(LEGAL_STRUCTURE_ID);
        holding.setTypeName("Legal Structure");
        return holding;
    }

    private List<Holding> createSingleHolding(String id, Float percentage) {
        List<Holding> holdings = new ArrayList<Holding>();
        Holding holding = new Holding();
        holding.setId(id);
        holding.setPercentage(percentage);
        holding.setStartDate("2000-11-03");
        holding.setTypeId(LEGAL_STRUCTURE_ID);
        holding.setTypeName("Legal Structure");
        holdings.add(holding);
        return holdings;
    }
}