package com.ubs.idp.orchestrator.aggregators;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.springframework.util.StringUtils;

/**
 * @author mcminnp
 */
public class FieldMapAggregatorTest {

    public FieldMapAggregator setupAggregator(String[] fieldNames) throws Exception {
        FieldMapAggregator aggregator = new FieldMapAggregator();
        
        aggregator.setNames(fieldNames);

        aggregator.afterPropertiesSet();

        return aggregator;
    }

    @Test
    public void aggregateTestHappyPath() {

        try {
            Map<String, Object> inputData = new HashMap<String, Object>();
            String[] fieldNames = {"foo", "bar"};

            inputData.put("foo", "bar");
            inputData.put("bar", "foo");
            
            String expectedResult = "bar\tfoo";

            FieldMapAggregator aggregator = setupAggregator(fieldNames);
            
            String res = aggregator.aggregate(inputData);

            assertFalse("Null/empty response from aggretaor?", StringUtils.isEmpty(res));
            
            assertEquals("Incorrect output?", expectedResult, res);
        } catch(Exception ex) {
            fail("Unexpected exeption");
        }
    }

    @Test
    public void aggregateTestInvalidFieldNameNotStrict() {

        try {
            Map<String, Object> inputData = new HashMap<String, Object>();
            String[] fieldNames = {"foo", "invalidField", "bar"};

            inputData.put("foo", "bar");
            inputData.put("bar", "foo");

            FieldMapAggregator aggregator = setupAggregator(fieldNames);
            
            aggregator.setStrict(false);
            
            String expectedResult = "bar\t\tfoo";
            
            String res = aggregator.aggregate(inputData);

            assertEquals("Incorrect output?", expectedResult, res);
        } catch(Exception ex) {
            fail("Unexpected exception: " + ex.getMessage());
        }
    }

    @Test
    public void aggregateTestInvalidFieldNameStrict() {

        try {
            Map<String, Object> inputData = new HashMap<String, Object>();
            String[] fieldNames = {"foo", "bar", "foobar"};

            inputData.put("foo", "bar");
            inputData.put("bar", "foo");

            FieldMapAggregator aggregator = setupAggregator(fieldNames);
            
            aggregator.aggregate(inputData);

            fail("Should NOT get here!");
        } catch(Exception ex) {
            String expectedExceptionMessage = "Failed to get input value for field 'foobar'?";
            assertEquals("Unexpected exeption?", expectedExceptionMessage, ex.getMessage());
        }
    }
}
