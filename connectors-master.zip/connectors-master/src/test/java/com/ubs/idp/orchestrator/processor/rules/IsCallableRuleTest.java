package com.ubs.idp.orchestrator.processor.rules;

import static com.ubs.idp.orchestrator.processor.rules.IsCallableRuleTest.InputBuilder.newInput;
import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class IsCallableRuleTest {

	private IsCallableRule rule;

	@Before
	public void setUp() throws Exception {
		rule = new IsCallableRule();
	}

	@Test
	public void callableShouldDeriveToY() throws Exception {
		verifyEquals("Y", "CALLABLE");
	}

	@Test
	public void inWholeShouldDeriveToY() throws Exception {
		verifyEquals("Y", "INWHOLE");
	}

	@Test
	public void partialShouldDeriveToY() throws Exception {
		verifyEquals("Y", "PARTIAL");
	}

	@Test
	public void fullShouldDeriveToY() throws Exception {
		verifyEquals("Y", "FULL");
	}

	@Test
	public void noCallShouldDeriveToN() throws Exception {
		verifyEquals("N", "NO CALL");
	}

	@Test
	public void nullShouldDeriveToN() throws Exception {
		verifyEquals("N", null);
	}

	@Test
	public void emptyShouldDeriveToN() throws Exception {
		verifyEquals("N", "");
	}

	private void verifyEquals(String expected, String callType) throws Exception {
		assertEquals(expected,
				rule.process(newInput().withCallType(callType).build()).get("derived.isCallable"));
	}

	static class InputBuilder {

		private Map<String, Object> input = new HashMap<>();

		public static InputBuilder newInput() {
			return new InputBuilder();
		}

		public InputBuilder withCallType(String callType) {
			input.put("bond.callOptionType", callType);
			return this;
		}

		public Map<String, Object> build() {
			return input;
		}
	}

}
