package com.ubs.idp.orchestrator.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class AccountEventConstantsTest {
	
	@Test
	public void testValues() {
		AccountEventConstants constants = new AccountEventConstants();
		assertNotNull(constants);
		assertEquals(AccountEventConstants.EVENT_MF_HOST, "MF_HOST");
		assertEquals(AccountEventConstants.EVENT_ID, "ID");
		assertEquals(AccountEventConstants.EVENT_NEVENT_ID, "NEVENTID");
		assertEquals(AccountEventConstants.EVENT_ACCOUNT_ID, "ACCOUNT_ID");
		assertEquals(AccountEventConstants.EVENT_ACCOUNT_CODE, "ACCOUNT_CODE");
		assertEquals(AccountEventConstants.EVENT_DOWNSTREAM_SP_ID, "DOWNSTREAM_SP_ID");
		assertEquals(AccountEventConstants.EVENT_RETRY_COUNT, "RETRYCOUNT");
		assertEquals(AccountEventConstants.XML_RAW_MESSAGE_NAME, "RAW_MESSAGE");
		assertEquals(AccountEventConstants.XML_OUTBOUND_MESSAGE_NAME, "OUTBOUND_MESSAGE");
		
		assertEquals(AccountEventConstants.RESULT_SET_IDP_ID, "idpid");
		assertEquals(AccountEventConstants.RESULT_SET_ID, "resultsetid");
		
		assertEquals(AccountEventConstants.RESULT_SET_TYPE, "resultsettype");
		assertEquals(AccountEventConstants.RESULT_SET_NO_ID, "resultsetno");
		assertEquals(AccountEventConstants.RESULT_SET_ROW_ID, "recordno");
		assertEquals(AccountEventConstants.RESULT_SET_MAP_ID, "resultsetmap");
		
		assertEquals(AccountEventConstants.RESULT_SET_TRANSFORMED_MAP_ID, "transformed_resultsetmap");
		assertEquals(AccountEventConstants.DOWNSTREAM_SP_ID, "downstream_sp_id");
		assertEquals(AccountEventConstants.DATA_TYPE, "data_type");
		assertEquals(AccountEventConstants.PROPAGATION_SERVICE_IMPL_PREFIX, "PropagationStoredProc");
		assertEquals(AccountEventConstants.CONSUMER_VIEW_PREFIX, "PropagationStoredProc");
		assertEquals(AccountEventConstants.DOWNSTREAM_SYSTEM, "downstream_system");
	}

}
