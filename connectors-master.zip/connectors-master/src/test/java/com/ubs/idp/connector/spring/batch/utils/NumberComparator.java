package com.ubs.idp.connector.spring.batch.utils;

import java.text.ParseException;

import com.ubs.idp.connectors.spring.batch.utils.BaseCassandraComparator;
import com.ubs.idp.connectors.spring.batch.writers.BaseCassandraItemWriter.InputItem;

/**
 * Number comparator for input items that expects the second field
 * to be a number 
 * @author loverids
 *
 */
public class NumberComparator extends BaseCassandraComparator
{
	public final static String ATTR_NAME = "bar";  


	@Override
	public String[] getAttributeCompareOrder()
	{
		return new String[]{ATTR_NAME};
	}

	@Override
	public Comparable<?> castValueToType(String attrName, String value) throws ParseException
	{
		return new Integer(value);
	}
}