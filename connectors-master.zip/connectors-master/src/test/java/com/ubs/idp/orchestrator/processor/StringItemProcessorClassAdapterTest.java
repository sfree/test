package com.ubs.idp.orchestrator.processor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.powermock.reflect.Whitebox;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.util.StringUtils;

public class StringItemProcessorClassAdapterTest {

    private static final String DATA_FILES_DIR = "src/test/resources/data-files/";

    private StringItemProcessorClassAdapter adapter;

    private static final List<String> INPUT_FIELDS = Arrays.asList("A", "B", "C", "D");

    private static final List<String> OUTPUT_FIELDS = Arrays.asList("A", "B", "C", "D");

    private static final String TEST_LINE = " 1 \t2\t3\t4";

    @Before
    public void setUp() throws Exception {
        adapter = new StringItemProcessorClassAdapter();
    }

    @Test(expected = IllegalArgumentException.class)
    public void testProcess_MissingInputField() throws Exception {
        adapter.setOutputFieldNames(OUTPUT_FIELDS);
        adapter.afterPropertiesSet();
    }

    @Test(expected = IllegalArgumentException.class)
    public void testProcess_MissingOutputField() throws Exception {
        adapter.setInputFieldNames(INPUT_FIELDS);
        adapter.afterPropertiesSet();
    }

    @Test
    public void testProcess_EmptyLine() throws Exception {
        assertNull(adapter.process(" "));
    }

    @Test
    public void testProcess_EmptyProcessorList() throws Exception {
        adapter.setProcessorClassList(new ArrayList<String>());
        assertEquals(TEST_LINE, adapter.process(TEST_LINE));
        adapter.setProcessorClassList(null);
        assertEquals(TEST_LINE, adapter.process(TEST_LINE));
    }

    @Test
    public void testProcess_RejectItem() throws Exception {
        ApplicationContext ctx = mock(ApplicationContext.class);
        AutowireCapableBeanFactory bf = mock(AutowireCapableBeanFactory.class);
        when(ctx.getAutowireCapableBeanFactory()).thenReturn(bf);
        adapter.setApplicationContext(ctx);
        adapter.setProcessorClassList(Arrays
                .asList("com.ubs.idp.orchestrator.processor.RejectingItemRule"));
        adapter.setInputFieldNames(INPUT_FIELDS);
        adapter.setOutputFieldNames(OUTPUT_FIELDS);
        assertNull(adapter.process(TEST_LINE));
    }

    @Test
    public void testProcess_AcceptItem() throws Exception {
        ApplicationContext ctx = mock(ApplicationContext.class);
        AutowireCapableBeanFactory bf = mock(AutowireCapableBeanFactory.class);
        when(ctx.getAutowireCapableBeanFactory()).thenReturn(bf);
        adapter.setApplicationContext(ctx);
        adapter.setProcessorClassList(Arrays
                .asList("com.ubs.idp.orchestrator.processor.AcceptingItemRule"));
        adapter.setInputFieldNames(INPUT_FIELDS);
        adapter.setOutputFieldNames(OUTPUT_FIELDS);
        adapter.setOutputFieldSeparator("-");
        adapter.setTrimFieldValues(true);
        assertEquals("1-2-3-4", adapter.process(TEST_LINE));
    }

    private ItemProcessor<String, String> testGetOrCreateItemProcessor(ApplicationContext ctx)
            throws Exception {
        ItemProcessor<String, String> ip = Whitebox.invokeMethod(adapter,
                "getOrCreateItemProcessor", "com.ubs.idp.orchestrator.processor.AcceptingItemRule");
        assertNotNull(ip);
        return ip;
    }

    @Test
    public void testGetOrCreateItemProcessor() throws Exception {
        ApplicationContext ctx = mock(ApplicationContext.class);
        AutowireCapableBeanFactory bf = mock(AutowireCapableBeanFactory.class);
        when(ctx.getAutowireCapableBeanFactory()).thenReturn(bf);
        adapter.setApplicationContext(ctx);
        ItemProcessor<String, String> ip = testGetOrCreateItemProcessor(ctx);
        verify(bf).autowireBean(eq(ip));
        verifyNoMoreInteractions(bf);
    }

    @Test
    public void testGetOrCreateItemProcessor_Cached() throws Exception {
        ApplicationContext ctx = mock(ApplicationContext.class);
        AutowireCapableBeanFactory bf = mock(AutowireCapableBeanFactory.class);
        when(ctx.getAutowireCapableBeanFactory()).thenReturn(bf);
        adapter.setApplicationContext(ctx);
        ItemProcessor<String, String> ip1 = testGetOrCreateItemProcessor(ctx);
        ItemProcessor<String, String> ip2 = testGetOrCreateItemProcessor(ctx);
        verify(bf).autowireBean(eq(ip1));
        verifyNoMoreInteractions(bf);
        assertTrue(ip1 == ip2);
    }

    @Test
    public void testFormatResults() throws Exception {
        adapter.setOutputFieldNames(OUTPUT_FIELDS);
        adapter.setOutputFieldSeparator("|");

        Map<String, Object> values = new HashMap<>();
        values.put("A", "A");
        values.put("B", null);
        values.put("C", "");
        values.put("D", "NULL");
        assertEquals("A|||NULL", Whitebox.invokeMethod(adapter, "formatResults", values));
    }

    private void assertHeader(List<String> header) {
        for (String elem : header) {
            assertFalse("Empty header element found!", StringUtils.isEmpty(elem));
        }
    }

    private List<String> extractHeader(String headerRow, String delimiter, int splitLimit) {
        List<String> header = Arrays.asList(headerRow.split(String.format("\\Q%s\\E", delimiter),
                splitLimit));
        assertHeader(header);
        return header;
    }

    private void testMapInput(String fileName, String delimiter, int splitLimit, int skipLines)
            throws Exception {
        try (BufferedReader reader = new BufferedReader(new FileReader(Paths.get(
                DATA_FILES_DIR + fileName).toFile()))) {
            List<String> fields = extractHeader(reader.readLine(), delimiter, splitLimit);
            for (int i = 0; i < skipLines; i++) {
                reader.readLine();
            }
            adapter.setInputFieldNames(fields);
            adapter.setInputFieldSeparator(delimiter);
            adapter.setSplitLimit(splitLimit);
            Map<String, Object> result = Whitebox.invokeMethod(adapter, "mapInputs",
                    reader.readLine());
            assertNotNull(result);
            assertTrue(result.size() > 0);
        }
    }

    @Test
    public void testMapInput_TabSeparated_NegativeSplitLimit() throws Exception {
        testMapInput("tab_separated.txt", "\t", -1, 0);
    }

    @Test
    public void testMapInput_CommaSeparated_NegativeSplitLimit() throws Exception {
        testMapInput("comma_separated.txt", ",", -1, 0);
    }

    @Test
    public void testMapInput_PipeSeparated_ZeroSplitLimit() throws Exception {
        testMapInput("pipe_separated.txt", "|", 0, 1);
    }

}
