package com.ubs.idp.orchestrator.listeners;

import static org.junit.Assert.*;
import static org.mockito.MockitoAnnotations.initMocks;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ItemSkipFileWriterListenerTest {
    
    private static final String OK_ERROR_DIR = "target/skipTest";
    private static final String OK_ERROR_FILE = "target/skipTest/junit.out";

    @Before
    public void setUp() {
        cleanUp();
        
        initMocks(this);
    }

    @After
    public void tearDown() {
        cleanUp();
    }
    
    private void cleanUp() {
        // Pre-delete dir etc.
        File errorFile = new File(OK_ERROR_FILE);
        File errorDir = new File(OK_ERROR_DIR);
        
        errorFile.delete();
        errorDir.delete();
    }

    @Test
    public void testSuccessfulSkip() {
        ItemSkipFileWriterListener listener = new ItemSkipFileWriterListener();
        
        Map<String, String> exceptionFileMap = new HashMap<String, String>();
        
        exceptionFileMap.put(ItemSkipFileWriterListener.DEFAULT_MAPPING, OK_ERROR_FILE);
        
        listener.setExceptionFileMap(exceptionFileMap);
        
        listener.onSkipInWrite("JUnit Test", new Throwable("JUnit Test"));
        
        File check = new File(OK_ERROR_FILE);
        
        assertTrue("Failed to locate error file '" + check.getAbsolutePath() + "'?", check.exists());
        
        assertTrue("File '" + check.getAbsolutePath() + "' is empty?", check.length() > 0);
    }

    @Test
    public void testBadDirSkip() {

        String badFileName = null;
        
        // Note that we are trying to verify handling (logging) of the
        // inability to log the bad row to the required dir/file
        // Hence using a path that should fail on Unix (TC build agent) and local PC
        
        if (File.separator.equals("/")) {
            // Unix
            badFileName = "/dev/null/skipTest/junit.out";
        } else {
            // Windows
            badFileName = "invalidFolderName:/skipTest/junit.out";
        }
        
        ItemSkipFileWriterListener listener = new ItemSkipFileWriterListener();
        
        Map<String, String> exceptionFileMap = new HashMap<String, String>();
        
        exceptionFileMap.put(ItemSkipFileWriterListener.DEFAULT_MAPPING, badFileName);
        
        listener.setExceptionFileMap(exceptionFileMap);
        
        listener.onSkipInWrite("JUnit Test", new Throwable("JUnit Test"));
        
        File check = new File(badFileName);
        
        assertFalse("Locate invalid error file '" + check.getAbsolutePath() + "'?", check.exists());
    }
}
