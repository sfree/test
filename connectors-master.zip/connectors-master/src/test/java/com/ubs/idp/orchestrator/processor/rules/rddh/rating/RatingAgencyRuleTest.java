package com.ubs.idp.orchestrator.processor.rules.rddh.rating;

import static com.ubs.idp.orchestrator.processor.rules.rddh.rating.RatingAgencyRuleTest.InputBuilder.newInput;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class RatingAgencyRuleTest {

	private RatingAgencyRule rule;

	@Before
	public void setUp() throws Exception {
		rule = new RatingAgencyRule();
	}

	private Map<String, Object> newInputFor(String agency, String stdRawCode, String dmsiRawCode) {
		Map<String, Object> input = newInput(agency).withLastUpdatedTime("19700101000000000")
				.withRatingLastUpdatedTime("19700101000000000").withCode("AAA")
				.withRawCode(stdRawCode).withValidDate("19700101").withRatingGroup("LT")
				.withMajorVersion("1").build();
		input.putAll(newInput("DMSI_" + agency).withLastUpdatedTime("20140101000000000")
				.withRatingLastUpdatedTime("20140101000000000").withCode("BBB")
				.withRawCode(dmsiRawCode).withValidDate("20140101").withRatingGroup("LT")
				.withMajorVersion("2").build());
		return input;
	}

	public void shouldNotFallBack(String agency, String stdRawCode, String dmsiRawCode)
			throws Exception {
		Map<String, Object> results = rule.process(newInputFor(agency, stdRawCode, dmsiRawCode));
		verifyEquals(results, "derived." + agency + "_event.lastUpdatedTime", "19700101000000000");
		verifyEquals(results, "derived." + agency + "_issueRating.lastUpdatedTime",
				"19700101000000000");
		verifyEquals(results, "derived." + agency + "_issueRating.code", "AAA");
		verifyEquals(results, "derived." + agency + "_issueRating.rawCode", stdRawCode);
		verifyEquals(results, "derived." + agency + "_issueRating.validDate", "19700101");
		verifyEquals(results, "derived." + agency + "_issueRating.ratingGroup", "LT");
		verifyEquals(results, "derived." + agency + "_event.majorVersion", "1");
	}

	public void shouldFallBack(String agency, String stdRawCode, String dmsiRawCode)
			throws Exception {
		Map<String, Object> results = rule.process(newInputFor(agency, null, dmsiRawCode));
		verifyEquals(results, "derived." + agency + "_event.lastUpdatedTime", "20140101000000000");
		verifyEquals(results, "derived." + agency + "_issueRating.lastUpdatedTime",
				"20140101000000000");
		verifyEquals(results, "derived." + agency + "_issueRating.code", "BBB");
		verifyEquals(results, "derived." + agency + "_issueRating.rawCode", dmsiRawCode);
		verifyEquals(results, "derived." + agency + "_issueRating.validDate", "20140101");
		verifyEquals(results, "derived." + agency + "_issueRating.ratingGroup", "LT");
		verifyEquals(results, "derived." + agency + "_event.majorVersion", "2");
	}

	/*
	 * Tests for Fitch
	 */
	@Test
	public void shouldUseFitch() throws Exception {
		shouldNotFallBack("Fitch", "AAA", "BBB");
	}

	@Test
	public void shouldUseFitchBecauseDmsiFitchIsNull() throws Exception {
		shouldNotFallBack("Fitch", "AAA", null);
	}

	@Test
	public void shouldUseDmsiFitchRating() throws Exception {
		shouldFallBack("Fitch", null, "BBB");
	}

	/*
	 * Tests for Moodys
	 */
	@Test
	public void shouldUseMoodys() throws Exception {
		shouldNotFallBack("Moodys", "Aaa", "Baa2");
	}

	@Test
	public void shouldUseMoodysBecauseDmsiMoodysIsNull() throws Exception {
		shouldNotFallBack("Moodys", "Aaa", null);
	}

	@Test
	public void shouldUseDmsiMoodysRating() throws Exception {
		shouldFallBack("Moodys", null, "Baa2");
	}

	/*
	 * Tests for SandP
	 */
	@Test
	public void shouldUseSandP() throws Exception {
		shouldNotFallBack("SandP", "AAA", "BBB");
	}

	@Test
	public void shouldUseSandPBecauseDmsiSandPIsNull() throws Exception {
		shouldNotFallBack("SandP", "AAA", null);
	}

	@Test
	public void shouldUseDmsiSandPRating() throws Exception {
		shouldFallBack("SandP", null, "BBB");
	}

	private void verifyEquals(Map<String, Object> results, String attribute, String expected) {
		assertNotNull(results.get(attribute));
		assertEquals(expected, results.get(attribute));
	}

	static class InputBuilder {

		private Map<String, Object> input = new HashMap<>();

		private String prefix;

		private InputBuilder(String prefix) {
			this.prefix = "derived." + prefix;
		}

		public static InputBuilder newInput(String prefix) {
			return new InputBuilder(prefix);
		}

		public InputBuilder withLastUpdatedTime(String recordType) {
			input.put(prefix + "_event.lastUpdatedTime", recordType);
			return this;
		}

		public InputBuilder withRatingLastUpdatedTime(String recordType) {
			input.put(prefix + "_issueRating.lastUpdatedTime", recordType);
			return this;
		}

		public InputBuilder withCode(String recordType) {
			input.put(prefix + "_issueRating.code", recordType);
			return this;
		}

		public InputBuilder withRawCode(String recordType) {
			input.put(prefix + "_issueRating.rawCode", recordType);
			return this;
		}

		public InputBuilder withValidDate(String recordType) {
			input.put(prefix + "_issueRating.validDate", recordType);
			return this;
		}

		public InputBuilder withRatingGroup(String recordType) {
			input.put(prefix + "_issueRating.ratingGroup", recordType);
			return this;
		}

		public InputBuilder withMajorVersion(String recordType) {
			input.put(prefix + "_event.majorVersion", recordType);
			return this;
		}

		public Map<String, Object> build() {
			return input;
		}
	}

}
