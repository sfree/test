package com.ubs.idp.metadata.service.stub;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.ubs.idp.base.logging.Loggable;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.model.JDBCChannel;
import com.ubs.idp.metadata.model.JMSChannel;
import com.ubs.idp.metadata.model.JoinRelation;

@Service("metadataServiceStub")
public class MetadataServiceStub implements MetadataService
{
    private String testSQL = null;
    
    /**
     * @return the testSQL
     */
    public String getTestSQL() {
        return testSQL;
    }

    /**
     * @param testSQL the testSQL to set
     */
    public void setTestSQL(String testSQL) {
        this.testSQL = testSQL;
    }

    /************ MetadataService Methods *************/

    @Override
    public String getSQLQueryForDataset(String datasetId){
        return this.testSQL;
    }
    

    @Override
    public List<Integer> getDatasetKeyAttributePositions(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getAttributeNamesForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getAttributeIdsForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public JDBCChannel getDatabaseDetailsForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Map<String, Integer> getAttributePositionsForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getDelimiter(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }



    @Override
    public List<String> getAttributeNamesForPhysicalDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Map<String, List<String>> getAllDatasetAndAttributeNames()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getSourceUrlsForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getJobNamesForDataset(String datasetId) {
        return null;
    }

    @Override
    public String getSourceDeltaUrlForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Map<String, List<String>> getSourceUrlsForAllDatasets()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getRolesForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }


    @Override
    public List<Integer> getQueryableAttributePositionsForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }



    @Override
    public List<JoinRelation> getJoinRelationsForView(String viewId)
    {
        // TODO Auto-generated method stub
        return null;
    }



    @Override
    public String getPrimarySourceUrlForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getTransformerRulesetsForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getAttributeXpathsForPhysicalDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Map<String, String> getNamespacesForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Map<String, List<JoinRelation>> getAllRelations()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getSourceAuthenticationUriForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getUrlForChannel(String channelId, boolean isDelta)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getUrlForChannel(String channelId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getJoinKeysForDatasetIds(String datasetId, String datasetId2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getTableIdForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String generateSQLInsertForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<JoinRelation> getJoinRelationsForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getDatasetKeyAttributeNames(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getThinToWidePivotColumnForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getThinToWideTargetPivotValuesForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getThinToWideColumnsAssociatedWithPivotForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getTransformerPreProcessorRulesetsForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Integer> getThinToWideKeyColumnPositionsForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getThinToWideKeyColumnsForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getPredicatesForDatasetInJoinRelation(String joinRelaionId, String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean getUnionAllForView(String viewId)
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isView(String datasetId)
    {
        // TODO Auto-generated method stub
        return false;
    }

    /**
     * Returns Service Implementations for given service
     *
     * @param serviceId
     * @return
     */
    @Override
    public List<String> getServiceImplementations(String serviceId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * Returns data set details for given service implementation
     *
     * @param serviceImplId
     * @return
     */
    @Override
    public Map<String, List<String>> getDataSetDetails(String serviceImplId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * Returns required data set attributes for given service implementation
     *
     * @param serviceImplId
     * @return
     */
    @Override
    public Map<String, String> getRequiredDataSetAttributes(String serviceImplId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * Returns stored procedure details for given service implementation
     *
     * @param serviceImplId
     * @return
     */
    @Override
    public Map<String, Map<String, Map<String, Object>>> getStoredProcedureDetails(String serviceImplId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * Returns JMS channel details for given service
     *
     * @param service
     * @return
     */
    @Override
    public JMSChannel getJMSChannelDetails(String service) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
    
    /**
     * Returns all Service Implementations for a given source
     *
     * @param sourceId
     * @return
     */
    @Override
    public List<String> getAllServiceImplementationsForSource(String sourceId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public JDBCChannel getJdbcChannelDetailsWithId(String channelId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Map<String,Map<String, String>> getDataSetTransformationMappings(String serviceImplId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public List<Map<String, String>> getDataSetFilterAttributes(String dataSetId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public String getChannelWithViewId(String viewId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map<String, String> getPropertyMapOfServiceImplementation(
            String serviceImplementationId) {
        // TODO Auto-generated method stub      
        return null;        
    }

    @Override
    public List<String> getAllDatasets()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Map<String, String> getPhysicalDatasetAttributeNamesAndTypes(String datasetId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * Returns a Map <K,V> of Ordered DataSetId's for a given service implementation. 
     * The ordering is done on basis of data set position.
     *  Key is DatasetID and Value is datasetName.
     * @param serviceImplId
     * @return
     */
    @Override  
    public  List<Map<String,String>>  getOrderedDatasetDetails(@Loggable String serviceImplId) {
        return null; // TODO Auto-generated method stub
    }
    
    public Map getTransformationMappingforView(String viewId) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getSQLDeltaQueryForDataset(String datasetId)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getTransformerRulesetsForDatasets(String srcDataset, String targetDataset)
    {
        // TODO Auto-generated method stub
        return null;
    }

	@Override
	public String getXsltStylesheetForView(String viewId) {
		// TODO Auto-generated method stub
		return null;
	}
}