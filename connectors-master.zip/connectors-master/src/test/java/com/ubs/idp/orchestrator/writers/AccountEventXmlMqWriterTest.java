
package com.ubs.idp.orchestrator.writers;
import com.ubs.idp.orchestrator.util.MetaDataRetrieverUtil;

import static com.ubs.idp.orchestrator.util.AccountEventConstants.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.TextMessage;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class AccountEventXmlMqWriterTest {

    @InjectMocks
    private AccountEventXmlMqWriter accountEventXmlMqWriter;
    @Mock
    private MetaDataRetrieverUtil metaDataRetrieverUtil;
    @Mock
    private JmsTemplate jmsTemplate;
    private Session session;
    private TextMessage mockTextMessage;

    @Before
    public void setUp() throws JMSException {
        accountEventXmlMqWriter = new AccountEventXmlMqWriter();
        MockitoAnnotations.initMocks(this);
        jmsTemplate = mock(JmsTemplate.class);
        session = mock(Session.class);
        mockTextMessage = mock(TextMessage.class);
        
        when(metaDataRetrieverUtil.getJmsTemplateForView(anyString())).thenReturn(jmsTemplate);
        when(session.createTextMessage("TestMessage")).thenReturn(mockTextMessage);
        when(session.createTextMessage("")).thenReturn(mockTextMessage);
    }

    @Test
    public void sendMessageTest() throws Exception {
    	List<Map<String, Object>> accountEventResultSets = Collections.singletonList(createMap());    	
    	accountEventXmlMqWriter.write(accountEventResultSets);
        Mockito.verify(jmsTemplate).send(any(MessageCreator.class));
    }
    
    @Test
	public void createMessageTest() throws Exception {
    	Map<String, Object> map = createMap();
    	TextMessage message = (TextMessage) accountEventXmlMqWriter.createMessage(map).createMessage(session);
    	verify(message).setJMSCorrelationID("765");
    	verify(message).setJMSType("134");
    	
    	map.put(XML_OUTBOUND_MESSAGE_NAME, null);
    	map.put(EVENT_ID, "769");
    	map.put(EVENT_DOWNSTREAM_SP_ID, "19");
    	message = (TextMessage) accountEventXmlMqWriter.createMessage(map).createMessage(session);
    	verify(message).setJMSCorrelationID("769");
    	verify(message).setJMSType("19");
	}
    
    @Test
	public void afterPropertiesSetTest() throws Exception {
    	accountEventXmlMqWriter.afterPropertiesSet();
	}
    
    private Map<String, Object> createMap() {
    	Map<String, Object> map = new HashMap<String, Object>();
    	map.put(XML_OUTBOUND_MESSAGE_NAME, "TestMessage");
    	map.put(EVENT_ID, "765");
    	map.put(EVENT_DOWNSTREAM_SP_ID, "134");
    	return map;
    }
    
}
