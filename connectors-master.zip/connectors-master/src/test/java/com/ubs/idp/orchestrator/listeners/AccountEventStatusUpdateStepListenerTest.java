package com.ubs.idp.orchestrator.listeners;

import com.ubs.idp.orchestrator.listeners.AccountEventStatusUpdateStepListener;
import com.ubs.idp.orchestrator.util.AccountEventStatus;
import com.ubs.idp.orchestrator.util.AccountEventJdbcStatusUpdateUtil;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;

import java.util.Collections;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.verify;


public class AccountEventStatusUpdateStepListenerTest {

    @InjectMocks private AccountEventStatusUpdateStepListener accountEventStatusUpdateStepListener;

    @Mock private AccountEventJdbcStatusUpdateUtil accountEventJdbcStatusUpdateUtil;

    @Before public void setUp() {

        accountEventStatusUpdateStepListener = new AccountEventStatusUpdateStepListener();
        MockitoAnnotations.initMocks(this);

    }

    @Test public void should_call_for_PROCESSED_status_update() throws Exception {

        ExitStatus exitStatus = accountEventStatusUpdateStepListener.afterStep(getStepExecution(ExitStatus.COMPLETED, "step4"));
        verify(accountEventJdbcStatusUpdateUtil).updateStatus("COMPLETED", AccountEventStatus.PROCESSED, 1l, "79", 5,false,"");
        assertThat(exitStatus.getExitCode(), is(ExitStatus.COMPLETED.getExitCode()));
    }

    @Test public void should_call_for_PUBLISHED_status_update() throws Exception {

        ExitStatus exitStatus = accountEventStatusUpdateStepListener.afterStep(getStepExecution(ExitStatus.COMPLETED, "step5"));
        verify(accountEventJdbcStatusUpdateUtil).updateStatus("COMPLETED", AccountEventStatus.PUBLISHED, 1l, "79", 5,false,"");
        assertThat(exitStatus.getExitCode(), is(ExitStatus.COMPLETED.getExitCode()));
    }

    @Test
    public void should_call_for_FATAL_status_update() throws Exception {
    	StepExecution stepExecution=getStepExecution(ExitStatus.FAILED, "step4");
    	stepExecution.getJobExecution().getExecutionContext().put("isEventInValid", true);
        ExitStatus exitStatus = accountEventStatusUpdateStepListener.afterStep(stepExecution);
        verify(accountEventJdbcStatusUpdateUtil).updateStatus("FAILED", AccountEventStatus.FATAL, 1l, "79", 5,true,"Validation Exception");
        assertThat(exitStatus.getExitCode(), is(ExitStatus.FAILED.getExitCode()));
    }
    
    @Test
    public void should_call_for_UNPROCESSED_status_update() throws Exception {
    	StepExecution stepExecution=getStepExecution(ExitStatus.FAILED, "step4");
    	stepExecution.addFailureException(new Exception("MQ Exception"));
        ExitStatus exitStatus = accountEventStatusUpdateStepListener.afterStep(stepExecution);
        verify(accountEventJdbcStatusUpdateUtil).updateStatus("FAILED", AccountEventStatus.UNPROCESSED, 1l, "79", 5,false,"MQ Exception");
        verify(accountEventJdbcStatusUpdateUtil).deleteJDBCXMLRecordForEventIdpID( 1l,new Long("3"));
        verify(accountEventJdbcStatusUpdateUtil).deleteCassandraRSRecordsForEventIdpID( 1l,new Long("3"));
        assertThat(exitStatus.getExitCode(), is(ExitStatus.FAILED.getExitCode()));
    }


    private StepExecution getStepExecution(ExitStatus status, String stepName) {

        JobExecution jobExecution = new JobExecution(1l);
        StepExecution stepExecution1 = new StepExecution(stepName, jobExecution);
        jobExecution.addStepExecutions(Collections.singletonList(stepExecution1));
        ExecutionContext executionContext = new ExecutionContext();
        executionContext.put("id", 1l);
        executionContext.put("retryCount", 5);
        executionContext.put("propCode", "79");
        executionContext.put("isEventInValid", false);
        executionContext.put("loaType", new Long("3"));
        jobExecution.setExecutionContext(executionContext);
        StepExecution stepExecution = new StepExecution("A", jobExecution);
        stepExecution.setExitStatus(status);
        return stepExecution;
    }
}
