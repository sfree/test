package com.ubs.idp.connector.spring.batch.utils;

import com.ubs.idp.connectors.spring.batch.writers.CassandraItemWriter;

import java.util.ArrayList;
import java.util.List;

public final class ItemWriterUtil {

    public static final String JUNIT_CF = "JUNIT_CF";
    public static final String FIELD_SEPARATOR = ",";

    private ItemWriterUtil(){}

    public static CassandraItemWriter getCassandraItemWriter() {

        CassandraItemWriter writer = new CassandraItemWriter();

        List<String> attributeNames = new ArrayList<>();
        List<Integer> keyAttributePositions = new ArrayList<>();
        List<Integer> queryableAttributePositions = new ArrayList<>();
        attributeNames.add("foo");
        attributeNames.add("bar");
        keyAttributePositions.add(0);
        queryableAttributePositions.add(0);
        writer.setAttributeNames(attributeNames);
        writer.setDatasetName(JUNIT_CF);
        writer.setFieldSeparator(FIELD_SEPARATOR);
        writer.setKeyAttributePositions(keyAttributePositions);
        writer.setQueryableAttributePositions(queryableAttributePositions);
        return writer;
    }
}
