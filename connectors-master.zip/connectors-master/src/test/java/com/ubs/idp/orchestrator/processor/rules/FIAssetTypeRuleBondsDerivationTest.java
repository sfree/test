package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;
import com.ubs.idp.orchestrator.processor.rules.FIAssetTypeRule;

/**
 * Tests for the Fixed Income Asset Type derivation rules for Bonds derivation
 * If cfi 7th char is G 
 * and Bloomberg Collateral Type match ("MORTGAGE*BACKED|"ASSET*BACKED)
 * and (bbTicker one of RAGB,BGB,CAN,DGB,RFGB,FRTR,BKO,OBL,DBR,HKGB,IRISH,ICTZ,BTPS,JGB,KOREA,NDFB,LGB,NETHER,NZGB,NGB,SIGB,SPGB,SGB,SWISS,UKT 
 * or difference between maturity and issue date is more than 10 year) * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Fixed Income Asset Type definition section)
 * @author haniffsy
 */
public class FIAssetTypeRuleBondsDerivationTest {

	private FIAssetTypeRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new FIAssetTypeRule();
		inputFields = new HashMap<String,Object>();
	}
	
	// Bonds
	
	
	// CFI(7) == G AND bbgCollateralType MATCHES MORTGAGE*BACKED AND ticker IN [...]
	
	// (bbTicker one of RAGB,BGB,CAN,DGB,RFGB,FRTR,BKO,OBL,DBR,HKGB,IRISH,ICTZ,BTPS,JGB,KOREA,NDFB,LGB,NETHER,NZGB,NGB,SIGB,SPGB,SGB,SWISS,UKT 

	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerRAGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH  BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "RAGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerBGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerCAN() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "CAN");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerDGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "DGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerRFGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH  BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "RFGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerFRTR() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH  BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FRTR");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerBKO() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BKO");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerOBL() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "OBL");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerDBR() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "DBR");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerHKGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH  BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "HKGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerIRISH() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "IRISH");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerICTZ() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH  BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "ICTZ");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerBTPS() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH  BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BTPS");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerJGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "JGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerKOREA() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "KOREA");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerNDFB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH  BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "NDFB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerLGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "LGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerNETHER() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH GAGE BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "NETHER");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerNZGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH  BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "NZGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerNGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "NGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerSIGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH  BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SIGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerSPGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH MORTE BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SPGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerSGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerSWISS() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SWISS");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerUKT() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "UKT");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	// CFI(7) == G AND bbgCollateralType MATCHES ASSET*BACKED AND ticker IN [...]
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerRAGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "RAGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerBGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerCAN() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "CAN");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerDGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH  BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "DGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerRFGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "RFGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerFRTR() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FRTR");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerBKO() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BKO");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeMatchesNotAssetBackedAndTickerOBL() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "OBL");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerDBR() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "DBR");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerHKGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "HKGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerIRISH() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "IRISH");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerICTZ() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "ICTZ");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerBTPS() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BTPS");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerJGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "JGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerKOREA() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "KOREA");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerNDFB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "NDFB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerLGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH  BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "LGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerNETHER() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "NETHER");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerNZGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "NZGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerNGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "NGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerSIGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SIGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerSPGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SPGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerSGB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SGB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerSWISS() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SWISS");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerUKT() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "UKT");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	
	// IF CFI(7) == G AND bbgCollateralType MATCH MORTGAGE*BACKED AND issuerCountry == US AND maturity - issue > 120 months

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndIssueToMaturityLess12Mo() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.ISSUE_DATE, "20130410");
		inputFields.put(DerivationRuleTemplate.MATURITY_DATE, "20240910");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldNotDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndIssueToMaturityMore12Mo() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.ISSUE_DATE, "20130410");
		inputFields.put(DerivationRuleTemplate.MATURITY_DATE, "20130510");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertFalse("Bond".equals(results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE)));
	}		

	
	// IF CFI(7) == G AND bbgCollateralType MATCH MORTGAGE*BACKED AND issuerCountry == US AND maturity - issue > 12 months and < 120 months

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndIssueToMaturityLess12Mo() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.ISSUE_DATE, "20130410");
		inputFields.put(DerivationRuleTemplate.MATURITY_DATE, "20240910");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bond",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldNotDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndIssueToMaturityMore12Mo() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.ISSUE_DATE, "20130410");
		inputFields.put(DerivationRuleTemplate.MATURITY_DATE, "20130510");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertFalse("Bond".equals(results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE)));
	}
	
}
