package com.ubs.idp.orchestrator.tasklets;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class JdbcEventPollerTaskletTest {
	
	private JdbcTemplate mockedJdbcTemplate;
	
	private ChunkContext mockedChunkContext;
	private StepContext mockedStepContext;
	private StepExecution mockedStepExecution;
	private JobExecution mockedJobExecution;
	private ExecutionContext mockedExecutionContext;
	
	private JdbcEventPollerTasklet poller;
	
	@Before
	public void setup() {
		mockedJdbcTemplate = mock(JdbcTemplate.class);
		
		mockedChunkContext = mock(ChunkContext.class);
		mockedStepContext = mock(StepContext.class);
		mockedStepExecution = mock(StepExecution.class);
		mockedJobExecution = mock(JobExecution.class);
		mockedExecutionContext = mock(ExecutionContext.class);
		
		poller = new JdbcEventPollerTasklet();
		
		when(mockedJdbcTemplate.queryForObject("testQuery", BigDecimal.class)).thenReturn(new BigDecimal(123));
		when(mockedJdbcTemplate.queryForObject("testNullQuery", BigDecimal.class)).thenReturn(null);
		
		when(mockedStepExecution.getJobExecution()).thenReturn(mockedJobExecution);
		when(mockedStepContext.getStepExecution()).thenReturn(mockedStepExecution);
		when(mockedChunkContext.getStepContext()).thenReturn(mockedStepContext);
		
		when(mockedJobExecution.getExecutionContext()).thenReturn(mockedExecutionContext);
	}

	@Test
	public void executeTest() throws Exception {
		
		poller.setJdbcTemplate(mockedJdbcTemplate);
		
		poller.setQuery("testQuery");
		poller.execute(null, mockedChunkContext);
		assertEquals(new BigDecimal(123), poller.getMaxEventId());
		
		poller.setQuery("testNullQuery");
		poller.execute(null, mockedChunkContext);
		assertEquals(BigDecimal.ZERO, poller.getMaxEventId());
		
	}
	
	@Test
	public void afterPropertiesSetTest() throws Exception {
		poller.setQuery("testQuery");
		poller.afterPropertiesSet();
	}

}
