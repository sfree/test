package com.ubs.idp.connector;

import com.ubs.idp.connectors.HttpClientWrapper;
import com.ubs.idp.connectors.spring.batch.readers.HTTPSourceReader;
import org.springframework.batch.item.ExecutionContext;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 * This is intentionally NOT a unit test - it's just to exercise the
 * RCAS-based SSO access to HTTP resources (typ: RDDH)
 * @author mcminnp
 */
public class TestHTTPGet {
    
    public static final int MAX_TOTAL_CONNECTIONS = 100;
    public static final int MAX_HOST_CONNECTIONS = 100;

    /**
     * @param args
     */
    public static void main(String[] args) {
        doSSOTest();
    }

    public static void doSSOTest() {
        HTTPSourceReader reader = new HTTPSourceReader();

        String appKey       = "RCAS_Filegen";
        String userApp      = "filegen";
        String ssoUsername  = "sso_filegentest";
        String ssoPassword  = "89e8e8a2b1b6e53e8481ae6855d8f7aa";
        String userName     = "sso_filegentest";
        String host         = "xstm1489vdap";

        boolean forceUAT1 = false;
        
        String uri = "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?" +
                "issue.assetClass=EQUITY_INDEX&" +
                "user.host=" + host + "&" +
                "user.domain=ubsw&" +
                "user.app=" + userApp + "&" +
                "user.name=" + userName + "&" +
                "rddh.requesttype=TEXT&" +
                "fields=cb64:eJxtUttOwzAM_aFqP1EmhEAgbQOJx1zcYcilxM5Y_540Tbcu60vq27F9fIpEETZR0pNuMNuCCLg16dP0EOyGfAwKGn7Z9HY_WOnNaFvx7cMHBELvCjBB-L3XgkEf0EKDTsP5tjABp1HJUDEEcGooaCTfdjgmkLTYgdme1VfrNVzy6K7ZY-nGQWhofXQchjJQedsb4LxxQFWiLtq3rvWOGDmCY1pUe0JO_bZdB4rxBA9iQovslcJ1dmrRcVxYuCMsOOw4UMVDyj0k6sjDYejnYH0kmFvN3NP7KmxufbfIpFrZNTvEgmOR7yRMzDgpD6h-IExhHoePB5xiOf_u8DfOzDSekiShePldLCzlJxjj_55hPDtxiDad4DH42Fe_RpW8qFMn1gS6h65KVRfeS1U3WhGtLrryv41fLvEPYX1Axg";

/*        uri       = "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?" +
        		"issue.assetClass=EQUITY_INDEX&" +
        		"user.app=filegen&" +
        		"user.host=xstm1489vdap&" +
        		"user.domain=ubsw&" +
        		"user.name=sso_filegentest&" +
        		"rddh.requesttype=TEXT&" +
        		"fields=cb64:eJxtUttOwzAM_aFqP1EmhEAgbQOJx1zcYcilxM5Y_540Tbcu60vq27F9fIpEETZR0pNuMNuCCLg16dP0EOyGfAwKGn7Z9HY_WOnNaFvx7cMHBELvCjBB-L3XgkEf0EKDTsP5tjABp1HJUDEEcGooaCTfdjgmkLTYgdme1VfrNVzy6K7ZY-nGQWhofXQchjJQedsb4LxxQFWiLtq3rvWOGDmCY1pUe0JO_bZdB4rxBA9iQovslcJ1dmrRcVxYuCMsOOw4UMVDyj0k6sjDYejnYH0kmFvN3NP7KmxufbfIpFrZNTvEgmOR7yRMzDgpD6h-IExhHoePB5xiOf_u8DfOzDSekiShePldLCzlJxjj_55hPDtxiDad4DH42Fe_RpW8qFMn1gS6h65KVRfeS1U3WhGtLrryv41fLvEPYX1Axg";
        
        uri = "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?" +
        		"issue.assetClass=EQUITY_INDEX&" +
        		"user.app=filegen&" +
        		"user.host=xstm1489vdap&" +
        		"user.domain=ubsw&" +
        		"user.name=sso_filegentest&" +
        		"rddh.requesttype=TEXT&" +
        		"fields=issue.ubsId,issue.assetClass,perm.source,tL.pmSymbol,tL.majorVersion,issue.lastUpdatedTime,index.majorVersion,tL.ubsId,tL.currency,issue.isoCfi,tL.isdaRelExchCode,issue.isin,tL.isdaRegion,tL.tradeCountry,index.complete,tL.ric,index.numOfConstituents,index.compositionEffectiveDate,tL.active,index.lastUpdatedTime,index.constituentsExchange,tL.isdaRelRtrsExchCode,issue.bbSecurityType,issue.majorVersion,tL.exchange,issue.issueName,tL.lastUpdatedTime,issue.active,issue.status,perm.value,tL.bbTicker,perm.type,tL.ticker,tL.bbUnique,index.divisor,index.indexType,issue.bbYellowKey,instrumentGroup.majorVersion,instrumentGroup.complete,instrumentGroup.numOfConstituents,instrumentGroup.compositionEffectiveDate,instrumentGroup.lastUpdatedTime,instrumentGroup.constituentsExchange,instrumentGroup.divisor,instrumentGroup.indexType";
        //  issue.ubsId,issue.assetClass,perm.source,tL.pmSymbol,tL.majorVersion,issue.lastUpdatedTime,index.majorVersion,tL.ubsId,tL.currency,issue.isoCfi,tL.isdaRelExchCode,issue.isin,tL.isdaRegion,tL.tradeCountry,index.complete,tL.ric,index.numOfConstituents,index.compositionEffectiveDate,tL.active,index.lastUpdatedTime,index.constituentsExchange,tL.isdaRelRtrsExchCode,issue.bbSecurityType,issue.majorVersion,tL.exchange,issue.issueName,tL.lastUpdatedTime,issue.active,issue.status,perm.value,tL.bbTicker,perm.type,tL.ticker,tL.bbUnique,index.divisor,index.indexType,issue.bbYellowKey,instrumentGroup.majorVersion,instrumentGroup.complete,instrumentGroup.numOfConstituents,instrumentGroup.compositionEffectiveDate,instrumentGroup.lastUpdatedTime,instrumentGroup.constituentsExchange,instrumentGroup.divisor,instrumentGroup.indexType
        //  issue.ubsId,issue.assetClass,perm.source,tL.pmSymbol,tL.majorVersion,issue.lastUpdatedTime,index.majorVersion,tL.ubsId,tL.currency,issue.isoCfi,tL.isdaRelExchCode,issue.isin,tL.isdaRegion,tL.tradeCountry,index.complete,tL.ric,index.numOfConstituents,index.compositionEffectiveDate,tL.active,index.lastUpdatedTime,index.constituentsExchange,tL.isdaRelRtrsExchCode,issue.bbSecurityType,issue.majorVersion,tL.exchange,issue.issueName,tL.lastUpdatedTime,issue.active,issue.status,perm.value,tL.bbTicker,perm.type,tL.ticker,tL.bbUnique,index.divisor,index.indexType,issue.bbYellowKey,instrumentGroup.majorVersion,instrumentGroup.complete,instrumentGroup.numOfConstituents,instrumentGroup.compositionEffectiveDate,instrumentGroup.lastUpdatedTime,instrumentGroup.constituentsExchange,instrumentGroup.divisor,instrumentGroup.indexType        
        uri = "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?" +
        		"issue.assetClass=EQUITY&" +
        		"user.app=filegen&" +
        		"user.host=xstm1489vdap&" +
        		"user.domain=ubsw&" +
        		"user.name=sso_filegentest&" +
        		"rddh.requesttype=TEXT&" +
        		"fields=cb64:eJx1V9tu2zgQ_aHAi6IF9jnrJEWAZJ3aTt8pamSzpkiFFzfar9_Dm0TL7ksinpE45JkzFwtrPa1E-PvAHN3Fp5U9MkN24511TLVCHf6EV98YL-nLt2_3X_nfz6rN4Fk7sm9kduHDO_eyGrRxnZZCvzJzEIo1kta6jSYhpfjwot05zU8BaJq17gdthaPHT35k6kB3DbMncqtWnIXVpiyV7zfdWivrhPOknL2z5JykVev4oxQHATfpRGblG_vGjFNkntsKw8KrVq6cfJ8X0VytmcW-a4l_ad2zX9r8JGOFVgmBzb0PLWhp96KnBDbNXvATmbSy1GpZCA08MtOCDdxjJ_4rbAq76X54JoUbAxXpOmsmKbw-RQNk_svgJd_25lus116561h22r4Z3Xruvhvth4wqcTqRiCHYj0M5jbOEmHrrzBijJWbVBP9_nZj6JZanukDTvjc26QwpftwbpizjDjzu2We4cSeMdYDbpMugD5yeMyfO8HneCh7l1ON5N_YNGMXSCHuSZHExobgYWASL6_PewHm8FdCefYbdgwDBs3KZ6Ap-0e6OIEg3IkzgYzcgGpXgQeB3fc5ySNCR2RcBEdYkIxy8uu9VOC53nKhFCIZ4_YwshZXQCwFmBzxQNOvL-XlTve5KQCopV0AVc0vcG1y-gppmdw1yb0VRD9d9Px1EWFEez0xqxDmvfpNxAxsEmYWrJ236amele1QIufYmaGQsdYagIMHBQ6C6YpYLZa_e2XRdRVeFqwrOjn4y6WnTvSvhCr2iE3CTqtIpgygWRSL1azFYWxom5q-TOr53f0bIhRz33ih9nji4aVtPt47mtGGN7ODlFF0sWErva1yX5BmvLMxT6l4RU0tiRhGZLVlihh8XNggP2aZD-G59tUMxurldoGvOkwvT2_0DofJdGeEKDaFHfb9oR2gvDxTbhDbjljiJwU1fHnZzMyodakZYO8T7gqxQWSbpOvY5daaEQAL8NH1lppZW6Hz10olBUo02DZjpkTKhjU0dbGEL_xa2zrE6Cqk5oTbxUDnM-F7WF8mP9bJEAMrFIHSQVAnw5HCTKMr43PbhP5UTBDdFKmFL7cqrTYPE-PBps9jC8PDhtYvElbLqUqMLTyEf1unI6fv9ZDOpehfosfIuNUfK55FgLjjxK2zWvswnAjEpI15Z3pdr6V5VugRYwjxgylYu6e1FqKT7uHvtWNiWbemQudRD7ihQ0FGvmbuPNHmjFX26C8s_ybOyGGsS-Ueo8qhlG4QWvnJw5Mio1I-wfFbz8veR1HMIdPsk2SGeZNDlMYT0ogn2qabQIabBwnHuPdltuEJ-xCRVBRXsbzocIRsHoU4_QhxDQatchFniJ6kU8VhPnryKo1SS39DPjTeRJwOf0ziXoK0ztoZTYTrV-5d4RFMIKspWKrqT-7aXr4rQW5JwEMzPfHrMD_QkNXNISZ45CaqkSigKfYXJqhwH3sqUFJgyLZmt9oG8rU8s5GTbdEET0FEqD3EwEdu5IOVTMB9XO8we-TX35WtiYTMESyEX5TiOMPiO4pyDElSyeTkQa86vp2TUYIVjXgzVqZgwM14kkhKpioTDIEFCP4kUmBopukr1LSUVzpPnnmVFyfBF4clYmMhbMDoJbYFP513gsXAssCcD4OYmbIwHXsAo-gjhLcsDcQmnN22PnzWKpIvLPEpfXDFjSzamqZt9oO9j6s25l3Ee-la1jhNtkn3tKex6jQ6uf6HzeD9g6ORRPNkQShCXUEG1M2p7Pyw97wL44N1YG4roy8-jafY0twdMc2PCNGl6MPP4YOZseVYIBbiouimsqUiVZfpdx9Q47ceb8sugglD60dFrANq8xgac7QJFEWnmzl2d7QFjHhfy2rDFz4bFz8MxJMEZ9WQh9ggtqPofpq7cOw";
        
        // Full primary URL (that's failing in XD)
        uri = "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&issue.assetType=MISC&messageLevel=tL&tL.active=1&user.app=filegen&user.host=xstm1489vdap&user.domain=ubsw&user.name=sso_filegentest&rddh.requesttype=TEXT&fields=cb64:eJyNWduS4ygS_aGJntiI-QGX3TXh2Kq2p1zdEfOIBJJpI1ADctn99Xu4SKBLrfxiiZMpSPIOti9fStVJq-_fC7Onf9iXLw35qfQPpg1X0o0FMfZ7S4ll9J03zEGktPzq34wltjPuzXLauCe7lWcia08tO62ZLO9-GmVP_Hf4iFEl3MuvTuF7rPN-b1mYpLww7d80oWwbRHNjzUv_AEJf0lRdYV6JvjD7SuKH3FDyxuoovGrDSprVp7PaErvxMnZaSXazI8qTl1hJowQPuz1rZs5K0L30imG2-HqzTEsi4nAv05C36lmQOmjQSXRidcOk7aWIkxTFNlMKdnWoMEskts3p3hRB4rAP8RXq3CrKMujNapPDDa84dYpQxr7wXx2nP5jsPIk24lWyRsmgPal0Q0RQWK_BkggmKdFh917fh8op0MAENqqRdKV7PTHTewU3J0YMtEijGeA83JiOzfwloCOvClD0ojCIjhQG3KhtxXs2Y5jdYlaTA95j4qcMfsbtPYOK4jQHy87wtn9XTTMIwg3vX69EKFgnjj6Yti1pOTxrvNQzFJnNLFXD4QaDZQMK77EwMPTwAmV6a8XFuTQznkNVZerKcJnBcaEfRHTsUH2X3EYCDPCOiCGFSCr4lwmhPv7L7sM28fuNDJP53x3sNFsz13ZCsek3ZhjR5XlCg02PmiunmaWvTnCxxemcyFzWS6TjZseImBOx1Ba2c4GV7cI7czaGNGXaVn1y8RVHnWD_-euvTUK4OVT_dFhrEP5MjLNYWty5d-6S7NZyfc9UhzShbaZawzQftlwqIcCqiRg5rRwpLOSMvXvPuIiUCMkytxI3z52seW7o3Nd3zBIuGB2I7yGlxqGS1K-hs0UqZdI-4VO_4BXMlJq3NgVrUQTKEOa0a5r7NgspD-xTKCFDWNU6Ew-SKnXJwiAkDcSyFZP8ELFpJolwxbVBdnXvXi8Rpl3MV3E8JLZ-3EdnHIeH86RNneNClRfV2SNMqOi3rlnEU-jp5YSnFzKeDs6pk6PolHL3slS6VXEPPTXUo36I4qGalsj7MF-JGkQ744pkguAPVukcgKrnWAvZRijKSJHsk8m2Q9opuZgT3ri59CDWOBJt77Apu0KrYwUEaKoqFHOxVBrG1cWGNPHCZUhfgLwPeN_yLhDblAREm7WaVQxmp6epsV0kfDGgE5rC4G91jZUmVPEayRaBlvksmLZElBlCGqeMQ2dRwaTPZq7gl-Xr0ufcxVcQM1v2qBVFgf0bzU3rqy1t9yk7_YMmidGNgeOhWTiSvj26pRSGD7zYaATKzH9Sxv_zQuTPPnsNyWqEVi44zhBNGuLT7Du5LUxjCT4iA8ESzf8gAg0MfLBz-t3TL5Pxn4YJ9B9rXCWzyCWrc53VBfV5jY1Rs8qjinWeomigLE5XGYkLQk7WJbugv3iAreJ2XTpSrCv_J0HCQNle3yoT9SMbqBA566KVZy6Ly7SljmU189xp9GSVzpLbED6jnL3tM_uaEA0p1_eNetmydT1SIrk5P7CkXleOrskqDzfNOhO6eXI3_AHGm0SuX_cBTX5zse4DDeM10evLOi9gtwfU1ipUudWAFdY0j675-wHDPxAVqMjWcF6s20tSOPoDpsBZ8BFHQj967h4IR7SW10fCtpC1oFjXFz5udhyl2rfJNEDT0uzBUWnOSuaTqxWuZQ23BkuUvIX09I8zk773pP6cHOXAu-2PARGCVFeIcRSIXt_oR_wJbH3hRq5tfQsbaWHijd1x45uTHn_thOXDuSzuyfpu2Wcaj1TuTPU6g9HKXkZrSIMWE934E0FLHXdd4nhocXgw6R4jsCObkWfeNJRMSvMwGxhOQodxQeRlG6bKdti6_PeEYcAw_5m9dfJgdVqoB9-ZbsbIJpyv43onuEKJLTL6TfU7xGGSN13j-xH0n9qr25-lZuSEoglFB5QEyFuiHhh1ND2YuqswD84OKExmR-5bJV17OGinEorYI4Et7jMgWziBODyjNAT4zpmgr8yeFc0Av8rgGB56c3dJ8DvX489R3-En-FkznH7gRGPuAU7srQuq2dwjNDGX6OcjOF9hiZg-DaVzQ3-i88jDZEvMGar5AOXp7trFwF2WGofcNxx_M4DRvbQJg5e0yDsvStbhmBNNRZts0tFyCLZWyY0XZbbnJWKSv-9sD_Jfp8n4SRv5x_bCWU5s8rPwgH6tKub9fAyHC4DE5dwreY6DDu0kYI3LHZpZ115EauJGzGDCdCZcJKS9UVYRZJ4F4dozR-Sz29Tl3UnIE_wJZww9EddBy2wW7mB_C7QJdwa5S0y7qWVSv-tNXWtWg2-zzEE-pWe5H1mFNW28B-oV33Z2UW0TPIuczk6t0ifrOTJO6vBcZGsXKF2fLV39UR-jtB4cclbqIhwefqWIVHlITjEvdwSRziFN3QmEW4R0tmCMtcGn-68wA0dMZpz-XLsJsbqb4lv_nsMtk3CzOR4eg4rGYuRxukzJt-aUddR0s7yFSss3VvGby08jJSU4nwz4s9uJJ472pyUy-dDYT6b5DPfRkYHhzD2WI2ATIV7YlWlS58u_8AqR306QZ6HUsGyLWsPQcPdjdtvxK6cQLXn4J6TJ-u4eNeTdKTa3zZSUTxUer0ra81dJc9cVosUcfRafSZWzJjRKhMzkO74QjD4PhVifkeaRNGEIgHXXlU_3OVmlcP_kU_Mp3V_ChpZqRvPVdglWV-7GJBaIGYef8P_JMs1oD7JGoy1oNtzPuv9z5nQ0YNsBC_k3XJnZaBA_8KflbJz9YRLp_uravy9ewA2XxJGdy_AW_qeLh3HD-pvG_n-nXx2-GjzR55qYivKM5v5nQ2i7lmF8YX5h8n-0MxHn";
  */
        // Force to UAT1
        
        if (forceUAT1) {
            uri += "&rddh.env=uat1";
        }

        reader.setAppKey(appKey);
        reader.setUri(uri);
        reader.setAuthUri("http://rddh-inst-uat.stm.swissbank.com:11105");
        reader.setUsername(ssoUsername);
        reader.setPassword(ssoPassword);
        reader.setRcasEnv(HttpClientWrapper.RCAS_ENV_UAT);
        reader.setSkipHeader(true);
        
        try {
            ExecutionContext executionContext = new ExecutionContext();
            
            reader.init();
            
            FileWriter fos = new FileWriter("TestHTTPGet.out");
            BufferedWriter writer = new BufferedWriter(fos);
            
            reader.open(executionContext);
            
            String res;
            int lineCount = 0;
            
            System.out.println("Reading data...");
            
            while((res = reader.read()) != null) {
                writer.write(res);
                writer.newLine();
                
                lineCount++;
                
                if (lineCount % 1000 == 0) {
                    System.out.print("#");
                    System.out.flush();
                }
            }
            
            reader.close();
            
            fos.close();
            
            System.out.println("\nDone - read " + lineCount + " lines!");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
