package com.ubs.idp.orchestrator.util;

import com.ubs.idp.connectors.spring.batch.writers.AccountEventResultSetWriter;
import org.junit.Before;
import org.junit.Test;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.util.HashMap;

import static com.ubs.idp.orchestrator.util.AccountEventConstants.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;

public class MapBasedSqlParameterSourceProviderTest {

    public static final String DUMMY_MESSAGE = "<A></A>";
    private MapBasedSqlParameterSourceProvider mapBasedSqlParameterSourceProvider;

    @Before
    public void setUp() {
        mapBasedSqlParameterSourceProvider = new MapBasedSqlParameterSourceProvider();
    }

    @Test
    public void should_have_and_provide() throws Exception {

        AccountEventResultSetWriter.AccountEventResultSets accountEventResultSets = getMfSpResult();
        SqlParameterSource sqlParameterSource = mapBasedSqlParameterSourceProvider.createSqlParameterSource(accountEventResultSets);
        assertThat(sqlParameterSource.hasValue(XML_OUTBOUND_MESSAGE_NAME), is(true));
        assertThat((String) sqlParameterSource.getValue(XML_OUTBOUND_MESSAGE_NAME), is(DUMMY_MESSAGE));
    }
    @Test
    public void should_not_provide() throws Exception {

        AccountEventResultSetWriter.AccountEventResultSets accountEventResultSets = getMfSpResult();
        SqlParameterSource sqlParameterSource = mapBasedSqlParameterSourceProvider.createSqlParameterSource(accountEventResultSets);
        assertThat(sqlParameterSource.hasValue("ABC"), is(false));
        assertThat((String) sqlParameterSource.getValue("ABC"), not(DUMMY_MESSAGE));
    }

    private AccountEventResultSetWriter.AccountEventResultSets getMfSpResult() {
        AccountEventResultSetWriter.AccountEventResultSets accountEventResultSets = new AccountEventResultSetWriter.AccountEventResultSets();
        HashMap<String, Object> eventsMap = new HashMap<>();
        eventsMap.put(XML_OUTBOUND_MESSAGE_NAME, DUMMY_MESSAGE);
        accountEventResultSets.setMappedEvent(eventsMap);
        return accountEventResultSets;
    }
}
