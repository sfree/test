package com.ubs.idp.connector.spring.batch.formatters;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Ignore;
import org.junit.Test;

import com.ubs.idp.connectors.spring.batch.formatters.ArrayAndMapFormatFormatter;

public class ArrayAndMapFormatFormatterTest {

    @Test
    public void passThroughTestString() {
        ArrayAndMapFormatFormatter formatter = new ArrayAndMapFormatFormatter();
        
        String valueIn = "foobar";
        
        String valueOut = formatter.formatField(valueIn);
        
        assertEquals("Unexpected output value?", valueIn, valueOut);
    }
    
    @Test
    public void passThroughTestList() {
        ArrayAndMapFormatFormatter formatter = new ArrayAndMapFormatFormatter();
        
        String expectedOutput = "[foo, bar]";
        List<String> listIn = new ArrayList<>();
        
        listIn.add("foo");
        listIn.add("bar");
        
        String valueOut = formatter.formatField(listIn);
        
        assertEquals("Unexpected output value?", expectedOutput, valueOut);
    }
    
    @Test
    public void listSeparatorTest() {
        ArrayAndMapFormatFormatter formatter = new ArrayAndMapFormatFormatter();
        
        formatter.setListSeparator(":");
        
        String expectedOutput = "[foo:bar]";
        List<String> listIn = new ArrayList<>();
        
        listIn.add("foo");
        listIn.add("bar");
        
        String valueOut = formatter.formatField(listIn);
        
        assertEquals("Unexpected output value?", expectedOutput, valueOut);
    }
    
    @Test
    public void passThroughTestMap() {
        ArrayAndMapFormatFormatter formatter = new ArrayAndMapFormatFormatter();
        
        String expectedOutput = "{foo=bar, bar=foo}";
        Map<String, String> mapIn = new HashMap<String, String>();
        
        mapIn.put("foo", "bar");
        mapIn.put("bar", "foo");
        
        String valueOut = formatter.formatField(mapIn);
        
        assertEquals("Unexpected output value?", expectedOutput, valueOut);
    }
    
    @Test
    public void nameValueSeparatorTestMap() {
        ArrayAndMapFormatFormatter formatter = new ArrayAndMapFormatFormatter();
        
        formatter.setNameValueSeparator(":");
        
        String expectedOutput = "{foo:bar,bar:foo}";
        Map<String, String> mapIn = new HashMap<String, String>();
        
        mapIn.put("foo", "bar");
        mapIn.put("bar", "foo");
        
        String valueOut = formatter.formatField(mapIn);
        
        assertEquals("Unexpected output value?", expectedOutput, valueOut);
    }
    
    @Test
    public void nameValueAndListSeparatorTestMap() {
        ArrayAndMapFormatFormatter formatter = new ArrayAndMapFormatFormatter();
        
        formatter.setNameValueSeparator(":");
        formatter.setListSeparator("|");
        
        String expectedOutput = "{foo:bar|bar:foo}";
        Map<String, String> mapIn = new HashMap<String, String>();
        
        mapIn.put("foo", "bar");
        mapIn.put("bar", "foo");
        
        String valueOut = formatter.formatField(mapIn);
        
        assertEquals("Unexpected output value?", expectedOutput, valueOut);
    }
    
    @Test
    public void listSeparatorTestMap() {
        ArrayAndMapFormatFormatter formatter = new ArrayAndMapFormatFormatter();
        
        formatter.setListSeparator(":");
        
        String expectedOutput = "[foo:bar]";
        List<String> listIn = new ArrayList<>();
        
        listIn.add("foo");
        listIn.add("bar");
        
        String valueOut = formatter.formatField(listIn);
        
        assertEquals("Unexpected output value?", expectedOutput, valueOut);
    }

}
