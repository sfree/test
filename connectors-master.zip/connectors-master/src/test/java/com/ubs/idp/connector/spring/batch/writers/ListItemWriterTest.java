/**
 * 
 */
package com.ubs.idp.connector.spring.batch.writers;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.connectors.spring.batch.writers.ListItemWriter;

/**
 * @author valechak
 * 
 */
public class ListItemWriterTest {

	StepExecution stepExecution;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		JobExecution jobExecution = new JobExecution(1L);
		ExecutionContext executionContext = new ExecutionContext();
		executionContext.put("index", 0);
		executionContext.put("ItemsListSize", 10);
		jobExecution.setExecutionContext(executionContext);
		stepExecution = new StepExecution("Step1", jobExecution);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@RunWith(SpringJUnit4ClassRunner.class)
	@Configuration
	static class ContextConfiguration {
		@Bean(name = "eventListWriter")
		@Qualifier(value = "com.ubs.idp.connectors.spring.batch.writers.ListItemWriter")
		public ListItemWriter getEventListWriter() {
			ListItemWriter eventListWriter = new ListItemWriter();
			return eventListWriter;
		}

		@Bean(name = "listOfItems")
		@Qualifier(value = "java.util.ArrayList")
		public ArrayList<Integer> getListOfItems() {
			ArrayList<Integer> listOfItems = new ArrayList<Integer>();
			return listOfItems;
		}

	}

	/**
	 * Test method for
	 * {@link com.ubs.idp.connectors.spring.batch.writers.ListItemWriter#write(java.util.List)}
	 * .
	 */
	@Test
	public void testWrite() {

		ApplicationContext ctx = new AnnotationConfigApplicationContext(
				ContextConfiguration.class);
		ListItemWriter writer = ctx.getBean(ListItemWriter.class);
		try {
			writer.init();
			writer.beforeStep(stepExecution);
			List<Object> listOfObjects = new ArrayList<Object>();
			listOfObjects.add(1);
			writer.write(listOfObjects);
			writer.afterStep(stepExecution);
		} catch (Exception e) {
			e.printStackTrace();
			fail("Unexpected exception: " + e.getClass().getName());
		}

	}

}
