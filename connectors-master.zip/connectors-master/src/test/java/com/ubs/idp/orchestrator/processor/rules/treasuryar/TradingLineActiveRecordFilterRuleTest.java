package com.ubs.idp.orchestrator.processor.rules.treasuryar;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class TradingLineActiveRecordFilterRuleTest
{
	private TradingLineActiveRecordFilterRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new TradingLineActiveRecordFilterRule();
	}
	
	@Test
	public void shouldReturnRecord() throws Exception {
		
		inputFields = new HashMap<String,Object>();
		inputFields.put("tL.active","true");
		assertNotNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("tL.active","yes");
		assertNotNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("tL.active","Y");
		assertNotNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("tL.active","1");
		assertNotNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("tL.active","T");
		assertNotNull( rule.process(inputFields));
	}

	@Test
	public void shouldNotReturnRecord() throws Exception {
		
		inputFields = new HashMap<String,Object>();
		inputFields.put("tL.active","false");
		assertNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("tL.active","no");
		assertNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("tL.active","N");
		assertNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("tL.active","0");
		assertNull( rule.process(inputFields));

		inputFields = new HashMap<String,Object>();
		inputFields.put("tL.active","F");
		assertNull( rule.process(inputFields));
	}

}
