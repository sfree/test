package com.ubs.idp.orchestrator.processor.rules.mf.accountsandrxm;

import static com.ubs.idp.orchestrator.processor.rules.mf.accountsandrxm.AccountsAndRXMMappingRuleTest.InputBuilder.newInput;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ErrorCollector;

public class AccountsAndRXMMappingRuleTest {

	@Rule
	public ErrorCollector collector = new ErrorCollector();

	private AccountsAndRXMMappingRule rule;

	@Before
	public void setUp() throws Exception {
		rule = new AccountsAndRXMMappingRule();
	}

	@Test
	public void shouldPopulateAllAttributes() throws Exception {
		Map<String, Object> results = rule.process(newInput().withGlCconsol("1142774")
				.withClass("D").withFactive("1").withCPType("510").withRXM("B97032")
				.withReverseEntity("2175").withValidFrom("2013-06-10 06:23:54.0")
				.withValidTo("2064-06-08 00:00:00.0").withLemId("132451").build());
		collector.checkThat((String) results.get("accId"), equalTo("1142774"));
		collector.checkThat((String) results.get("clientClassification"), equalTo("D"));
		collector.checkThat((String) results.get("activeFlag"), equalTo("1"));
		collector.checkThat((String) results.get("counterpartyType"), equalTo("510"));
		collector.checkThat((String) results.get("rxmCode"), equalTo("B97032"));
		collector.checkThat((String) results.get("riskEntity"), equalTo("2175"));
		collector.checkThat((String) results.get("validFrom"), equalTo("2013-06-10 06:23:54.0"));
		collector.checkThat((String) results.get("validTo"), equalTo("2064-06-08 00:00:00.0"));
		collector.checkThat((String) results.get("lemid"), equalTo("132451"));
	}

	@Test
	public void shouldDeriveTransactionDate() throws Exception {
		Map<String, Object> results = rule.process(newInput().build());
		assertNotNull("No results map?", results);
		assertTrue("Empty results map?", results.size() > 0);
		Object derivedTransactionDate = results.get("derived.transactionDate");
        assertNotNull("No derived.transactionDate?", derivedTransactionDate);
		assertTrue(inRange(derivedTransactionDate.toString()));
	}

	private boolean inRange(String date) {
		DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS")
				.withZoneUTC();
		DateTime actualDate = formatter.parseDateTime(date);
		return actualDate.isAfter(DateTime.now().minusSeconds(5)) && actualDate.isBeforeNow();
	}

	static class InputBuilder {

		private Map<String, Object> input = new HashMap<>();

		public static InputBuilder newInput() {
			return new InputBuilder();
		}

		public InputBuilder withGlCconsol(String glCconsol) {
			input.put("GLcconsol", glCconsol);
			return this;
		}

		public InputBuilder withClass(String clazz) {
			input.put("Class", clazz);
			return this;
		}

		public InputBuilder withFactive(String factive) {
			input.put("Factive", factive);
			return this;
		}

		public InputBuilder withCPType(String cpType) {
			input.put("CPType", cpType);
			return this;
		}

		public InputBuilder withRXM(String rxm) {
			input.put("RXM", rxm);
			return this;
		}

		public InputBuilder withReverseEntity(String reverseEntity) {
			input.put("ReverseEntity", reverseEntity);
			return this;
		}

		public InputBuilder withValidFrom(String validFrom) {
			input.put("ValidFrom", validFrom);
			return this;
		}

		public InputBuilder withValidTo(String validTo) {
			input.put("ValidTo", validTo);
			return this;
		}
		
		public InputBuilder withLemId(String lemId) {
            input.put("lemid", lemId);
            return this;
        }

		public Map<String, Object> build() {
			return input;
		}
	}

}
