package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.CouponTypeRule;
import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;

/**
 * @author haniffsy
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT 
 * (Calculated fields / Coupon Type (Fixed income coupon Type for SSP) section
 */
public class CouponTypeTest {
	
	private CouponTypeRule rule;
	private Map<String,Object> inputFields;
	
	private static final String UNRECOGNIZED_COUPON_TYPE_VALUE = "asdasd";

	@Before
	public void setUp() throws Exception {
		rule = new CouponTypeRule();
		inputFields = new HashMap<String,Object>();
	}

	@Test
	@Ignore // TODO: Need to define rule
	public void shouldReturnXXXXWhenCouponTypeNotRecognised() {
		
		inputFields.put(DerivationRuleTemplate.COUPON_TYPE, UNRECOGNIZED_COUPON_TYPE_VALUE);
		Map<String,Object> results = rule.derive(inputFields);
		
		fail("Need to define what happens when the coupon type is unrecognized");
	}	
	
	
	@Test
	@Ignore // TODO: Need to define rule
	public void shouldReturnCTAUWhenCouponTypeXXX() {
		fail("Need to define the coupon type test for Martini Value == Auction");
	}	

	
	@Test
	public void shouldReturnCTFXWhenCouponTypeFixed() {
		inputFields.put(DerivationRuleTemplate.COUPON_TYPE, CouponTypeRule.FIXED);
		Map<String,Object> results = rule.derive(inputFields);
		assertTrue(results.containsKey(CouponTypeRule.DERIVED_COUPON_TYPE));
		assertEquals("CTFX", results.get(CouponTypeRule.DERIVED_COUPON_TYPE));
	}
	
	@Test
	public void shouldReturnCTFLWhenCouponTypeFloating() {
		inputFields.put(DerivationRuleTemplate.COUPON_TYPE, CouponTypeRule.FLOATING);
		Map<String,Object> results = rule.derive(inputFields);
		assertTrue(results.containsKey(CouponTypeRule.DERIVED_COUPON_TYPE));
		assertEquals("CTFL", results.get(CouponTypeRule.DERIVED_COUPON_TYPE));
	}	

	@Test
	public void shouldReturnCTZEWhenCouponTypeZero() {
		inputFields.put(DerivationRuleTemplate.COUPON_TYPE, CouponTypeRule.ZERO);
		Map<String,Object> results = rule.derive(inputFields);
		assertTrue(results.containsKey(CouponTypeRule.DERIVED_COUPON_TYPE));
		assertEquals("CTZE", results.get(CouponTypeRule.DERIVED_COUPON_TYPE));
	}	
	
	@Test
	public void shouldReturnCTVAWhenCouponTypeFixedFloat() {
		inputFields.put(DerivationRuleTemplate.COUPON_TYPE, CouponTypeRule.FIXEDFLOAT);
		Map<String,Object> results = rule.derive(inputFields);
		assertTrue(results.containsKey(CouponTypeRule.DERIVED_COUPON_TYPE));
		assertEquals("CTVA", results.get(CouponTypeRule.DERIVED_COUPON_TYPE));
	}	

	@Test
	public void shouldReturnCTSTWhenCouponTypeStepped() {
		inputFields.put(DerivationRuleTemplate.COUPON_TYPE, CouponTypeRule.STEPPED);
		Map<String,Object> results = rule.derive(inputFields);
		assertTrue(results.containsKey(CouponTypeRule.DERIVED_COUPON_TYPE));
		assertEquals("CTST", results.get(CouponTypeRule.DERIVED_COUPON_TYPE));
	}	
	
	@Test
	public void shouldReturnCTOLWhenCouponTypeIndexLinked() {
		inputFields.put(DerivationRuleTemplate.COUPON_TYPE, CouponTypeRule.INDEXLINKED);
		Map<String,Object> results = rule.derive(inputFields);
		assertTrue(results.containsKey(CouponTypeRule.DERIVED_COUPON_TYPE));
		assertEquals("CTIL", results.get(CouponTypeRule.DERIVED_COUPON_TYPE));
	}	
	
	
	@Test
	@Ignore // TODO: Need to define rule
	public void shouldReturnCTCOWhenCouponTypeXXX() {
		fail("Need to define the coupon type test for Martini Value == Compound");
	}	
	
	
}
