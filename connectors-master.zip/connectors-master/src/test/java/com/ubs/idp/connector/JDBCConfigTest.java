package com.ubs.idp.connector;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.ubs.idp.connectors.jdbc.JDBCConfig;

public class JDBCConfigTest {
	
	private JDBCConfig config;

	@Before
	public void setup() {
		config = new JDBCConfig();
		ReflectionTestUtils.setField(config, "jdbcPassword", "5b5b4d12bac9f6d323ba53804d23f74e");
	}

	@Test
	public void testDecrypt() {

		assertEquals("5b5b4d12bac9f6d323ba53804d23f74e", config.getJdbcPassword());
		assertEquals("rod2", config.getDecryptedJDBCPassword());
	}

}
