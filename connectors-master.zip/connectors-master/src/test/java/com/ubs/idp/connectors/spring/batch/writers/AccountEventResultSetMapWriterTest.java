package com.ubs.idp.connectors.spring.batch.writers;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.PreparedStatement;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.*;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class AccountEventResultSetMapWriterTest {

    @InjectMocks private AccountEventResultSetMapWriter accountEventResultSetMapWriter;
    @Mock private CassandraCqlProxy proxy;
    @Mock private PreparedStatement preparedStatement;

    @Before
    public void setUp() throws Exception {
        accountEventResultSetMapWriter = new AccountEventResultSetMapWriter();
        MockitoAnnotations.initMocks(this);
        when(proxy.getPrepareStatement(anyString())).thenReturn(preparedStatement);
    }

    @Test
    public void testWrite() throws Exception {

        List<AccountEventResultSetWriter.AccountEventResultSets> accountEventResultSets =
                Collections.singletonList(getAccountEventResultSets());
        accountEventResultSetMapWriter.write(accountEventResultSets);
        verify(proxy).executeStatement(any(BatchStatement.class));
    }

    private AccountEventResultSetWriter.AccountEventResultSets getAccountEventResultSets() {

        AccountEventResultSetWriter.AccountEventResultSets accountEventResultSets = new AccountEventResultSetWriter.AccountEventResultSets();

        Map<Integer, Map<Integer, Map<String, String>>> resultSetsMaps = new HashMap<>();
        Map<Integer, Map<String, String>> resultSetsMap = new HashMap<>();
        Map<String, String> eventMap = new HashMap<>();
        eventMap.put("cconsol", "123456");
        resultSetsMap.put(1, eventMap);
        resultSetsMaps.put(1, resultSetsMap);
        accountEventResultSets.setResultSetsMap(resultSetsMaps);
        accountEventResultSets.setTransformedResultSetsMap(resultSetsMaps);
        HashMap<String, Object> mappedEvent = new HashMap<>();
        mappedEvent.put("downstream_sp_id", "79");
        accountEventResultSets.setMappedEvent(mappedEvent);
        return accountEventResultSets;
    }
}
