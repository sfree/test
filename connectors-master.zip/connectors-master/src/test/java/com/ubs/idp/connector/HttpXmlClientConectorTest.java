package com.ubs.idp.connector;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.messaging.support.GenericMessage;

import com.ubs.idp.connectors.HttpXmlClientConnector;

@RunWith(MockitoJUnitRunner.class)
public class HttpXmlClientConectorTest {
    
    private static final String VALID_TEST_URL = "file:src/test/resources/sampleData.xml";
    
    @Before
    public void setup() {
        Map<String, Object> res = new HashMap<String, Object>();
        
        res.put(HttpXmlClientConnector.OPERATION_GET_CURRENT, VALID_TEST_URL);
    }

	@Test
	public void executeHttpXmlClientConectorTest(){

		HttpXmlClientConnector connector = new HttpXmlClientConnector();

		connector.setUrl(VALID_TEST_URL);

		GenericMessage message = connector.execute(null);

        Assert.assertNotNull(message.getPayload());
	}
}
