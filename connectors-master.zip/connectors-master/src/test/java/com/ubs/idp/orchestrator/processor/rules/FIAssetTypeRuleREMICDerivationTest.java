package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;
import com.ubs.idp.orchestrator.processor.rules.FIAssetTypeRule;

/**
 * Tests for the Fixed Income Asset Type derivation rules
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Fixed Income Asset Type definition section)
 * @author haniffsy
 */
public class FIAssetTypeRuleREMICDerivationTest {

	private FIAssetTypeRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new FIAssetTypeRule();
		inputFields = new HashMap<String,Object>();
	}
	
	// REMIC Derivation
	
	/*
	 * If asset type is one of ABS, MBS or Agency 
	 * and bloomber ticker is one of GNR, FNR, FHR
	 */
	
	@Test
	public void shouldDeriveREMICIfAssetTypeABSAndBBTickerGNR() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "ABS");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "GNR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("REMIC - Real Estate Mortgage Conduit",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveREMICIfAssetTypeABSAndBBTickerFNR() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "ABS");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FNR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("REMIC - Real Estate Mortgage Conduit",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveREMICIfAssetTypeABSAndBBTickerFHR() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "ABS");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FHR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("REMIC - Real Estate Mortgage Conduit",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	
	@Test
	public void shouldDeriveREMICIfAssetTypeMBSAndBBTickerGNR() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "MBS");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "GNR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("REMIC - Real Estate Mortgage Conduit",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveREMICIfAssetTypeMBSAndBBTickerFNR() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "MBS");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FNR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("REMIC - Real Estate Mortgage Conduit",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveREMICIfAssetTypeMBSAndBBTickerFHR() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "MBS");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FHR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("REMIC - Real Estate Mortgage Conduit",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	

	
	@Test
	public void shouldDerivREMICIfAssetTypeAgencyAndBBTickerGNR() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Agency");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "GNR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("REMIC - Real Estate Mortgage Conduit",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveREMICIfAssetTypeAgencyAndBBTickerFNR() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Agency");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FNR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("REMIC - Real Estate Mortgage Conduit",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveREMICIfAssetTypeAgencyAndBBTickerFHR() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Agency");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FHR");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("REMIC - Real Estate Mortgage Conduit",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	
}
