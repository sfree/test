package com.ubs.idp.connector.spring.batch;

import com.ubs.idp.connectors.HttpClientWrapper;
import com.ubs.idp.connectors.spring.batch.readers.HTTPSourceReader;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.batch.item.ExecutionContext;

import java.io.InputStreamReader;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

/**
 * Tests the HTTP reader by mocking the input stream
 * to generate a timeout
 * @author loverids
 *
 */
public class HTTPSourceReaderStreamTest {

    private static final String VALID_TEST_FILE_URI = "src/test/resources/indextestfile.txt";

    @Mock
    HttpClientWrapper httpClient;
    
    @Mock
    InputStreamReader inputStream;
    
    @Before
    public void setUp() throws Exception {
        // Initialise the mocks
        MockitoAnnotations.initMocks(this);
        
        when(inputStream.read( (char[])Mockito.any(),Mockito.anyInt(),Mockito.anyInt())).thenAnswer(new Answer<Integer>()
		{
			@Override
			public Integer answer(InvocationOnMock invocation) throws Throwable
			{
				Thread.sleep(10000);
				return 1;
			}
        	
		});
        when(httpClient.getInput(VALID_TEST_FILE_URI)).thenReturn(inputStream);       
    }
    
    @Test
    public void readOneRowTest() {
        HTTPSourceReader reader = setupReader();
        
        try {
            reader.setUri(VALID_TEST_FILE_URI);
            
            reader.init();
            reader.setReadTimeout(1000);
            
            reader.open(new ExecutionContext());
            
            reader.read();
        } catch (Exception e) {
            assertEquals("Wrong exception message","Timed out reading line. Failed to receive a response after 1000ms",e.getMessage());
            return;
        }
        fail("Expected a timeout exception");
    }

    private HTTPSourceReader setupReader() {
        HTTPSourceReader reader = new HTTPSourceReader(httpClient);
        
        reader.setUsername("JUnit");
        reader.setAppKey("JUnit");
        reader.setRcasEnv(HttpClientWrapper.RCAS_ENV_UAT);
        
        return reader;
    }
    
}
