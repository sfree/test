package com.ubs.idp.orchestrator.util;

import com.ubs.idp.connectors.jdbc.JDBCConfigProxyImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.ExitStatus;

import java.util.Arrays;
import java.util.HashMap;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class AccountEventJdbcStatusUpdateUtilTest {

    public static final long EVENT_ID = 12345678l;
    @InjectMocks private AccountEventJdbcStatusUpdateUtil accountEventJdbcStatusUpdateUtil;
    @Mock private JDBCConfigProxyImpl jdbcProxy;
    @Mock private MetaDataRetrieverUtil metaDataRetrieverUtil;

    @Before
    public void setUp() throws Exception {
        accountEventJdbcStatusUpdateUtil = new AccountEventJdbcStatusUpdateUtil();
        accountEventJdbcStatusUpdateUtil.setProperties(new HashMap<String, String>());
        MockitoAnnotations.initMocks(this);
        when(metaDataRetrieverUtil.getRetryCount(anyString())).thenReturn(5);
    }

    @Test
    public void should_not_update_status() throws Exception {
        accountEventJdbcStatusUpdateUtil.updateStatus(ExitStatus.EXECUTING.getExitCode(),
                AccountEventStatus.FATAL, EVENT_ID, "", 1, true,"");
        HashMap<Integer, String> data = new HashMap<>();
        data.put(1, "FATAL");
        data.put(2, "");
        data.put(3, "12345678");        
        //should not update status/execute update
        verify(jdbcProxy, times(0)).executeDML(null, Arrays.asList("STRING","STRING","INT"), data);
    }

    @Test
    public void should_update_status_for_validation_fatal_error() throws Exception {
        accountEventJdbcStatusUpdateUtil.updateStatus(ExitStatus.FAILED.getExitCode(),
                AccountEventStatus.FATAL, EVENT_ID, "", 1, true,"Validation Exception");
        HashMap<Integer, String> data = new HashMap<>();
        data.put(1, "FATAL");
        data.put(2, "Validation Exception");
        data.put(3, "12345678");
        verify(jdbcProxy).executeDML(null, Arrays.asList("STRING","STRING","INT"), data);
    }

    @Test
    public void should_update_status_retryCount_for_fatal_error() throws Exception {
        accountEventJdbcStatusUpdateUtil.updateStatus(ExitStatus.FAILED.getExitCode(),
                AccountEventStatus.UNPROCESSED, EVENT_ID, "", 2, false,"MQ Exception");
        HashMap<Integer, String> data = new HashMap<>();
        data.put(1, "UNPROCESSED");
        data.put(2, "3");
        data.put(3, "MQ Exception");
        data.put(4, "12345678");
        verify(jdbcProxy).executeDML(null, Arrays.asList("STRING","INT","STRING","INT"), data);
    }

    @Test
    public void should_update_status_processed() throws Exception {
        accountEventJdbcStatusUpdateUtil.updateStatus(ExitStatus.COMPLETED.getExitCode(),
                AccountEventStatus.PROCESSED, EVENT_ID, "", 2, false,"");
        HashMap<Integer, String> data = new HashMap<>();
        data.put(1, AccountEventStatus.PROCESSED.name());
        data.put(2, "12345678");
        verify(jdbcProxy).executeDML(null, Arrays.asList("STRING","INT"), data);
    }

    @Test
    public void should_update_status_published() throws Exception {
        accountEventJdbcStatusUpdateUtil.updateStatus(ExitStatus.COMPLETED.getExitCode(),
                AccountEventStatus.PUBLISHED, EVENT_ID, "", 2, false,"");
        HashMap<Integer, String> data = new HashMap<>();
        data.put(1, AccountEventStatus.PUBLISHED.name());
        data.put(2, "12345678");
        verify(jdbcProxy).executeDML(null, Arrays.asList("STRING","INT"), data);
    }
}
