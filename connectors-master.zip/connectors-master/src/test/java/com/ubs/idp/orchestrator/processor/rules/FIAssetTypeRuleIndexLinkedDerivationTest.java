package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;
import com.ubs.idp.orchestrator.processor.rules.FIAssetTypeRule;

/**
 * Tests for the Fixed Income Asset Type derivation rules
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Fixed Income Asset Type definition section)
 * @author haniffsy
 */
public class FIAssetTypeRuleIndexLinkedDerivationTest {

	private FIAssetTypeRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new FIAssetTypeRule();
		inputFields = new HashMap<String,Object>();
	}
	
	
	// Index Linked
	
	/*
	 * If cfi 7th char is G 
	 * and coupont type is IndexLined
	 */
	
	@Test
	public void shouldDeriveIndexLinkedIfCFISevenIsGAndCouponTypeIndexLinked() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COUPON_TYPE, "IndexLinked");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Index Linked",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		
	}
	
	
	
}
