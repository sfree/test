package com.ubs.idp.connector.spring.batch;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.ubs.idp.connector.spring.batch.utils.DateComparator;
import com.ubs.idp.connector.spring.batch.utils.ItemWriterUtil;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.spring.batch.utils.BaseCassandraComparator;
import com.ubs.idp.connectors.spring.batch.writers.CassandraItemWriter;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.*;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

import static com.ubs.idp.connector.spring.batch.utils.ItemWriterUtil.*;

// TODO: Not sure we need to escape single quotes in bound statements...

public class CassandraItemWriterTest {

    @Mock(name="cassandraCqlProxy")
    CassandraCqlProxy cqlProxy;
    
    @Mock
    PreparedStatement preparedStateMent;
    
    @Mock
    BoundStatement boundStatement;
    
    @InjectMocks
    CassandraItemWriter writer;

    @Before
    public void setUp() throws Exception {
        
        writer = ItemWriterUtil.getCassandraItemWriter();
        
        // Initialise the mocks
        MockitoAnnotations.initMocks(this);
        
        
        when(cqlProxy.addColumnFamilyIfNeeded(JUNIT_CF)).thenReturn(true);
        when(cqlProxy.getPrepareStatement(Matchers.anyString())).thenReturn(preparedStateMent);
        when(preparedStateMent.bind()).thenReturn(boundStatement);
    }
    

    
    @Test
    public void testWriteKeyWithEscape() {
        List<String> output = new ArrayList<String>();
        
        try {
            output.add("X',Y");
            writer.write(output);
            
            // Verify that "X'" becomes "X''"
            verify(boundStatement, times(2)).setString(Matchers.eq(0), Matchers.contains("X'"));
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Unexpected exception: " + ex.getMessage());
        }
    }
    
    @Test
    public void testWriteValueWithEscape() {
        List<String> output = new ArrayList<String>();
        
        try {
            output.add("X,Y'");
            writer.write(output);
            
            // Verify that "Y'" becomes "Y''" - note no leading quote
            verify(boundStatement).setString(Matchers.eq(2), Matchers.contains("Y'"));
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Unexpected exception: " + ex.getMessage());
        }
    }
    
    @Test
    public void testWriteValueLaterTimestampAsc() {
        List<String> output = new ArrayList<String>();

        // Setup a date comparator in the writer
        writer.setLatestRecordComparator(new DateComparator() );
        
        try {
            output.add("DATE,20141015");
            output.add("DATE,20141016");
            writer.write(output);
            
            // Verify data
            verify(boundStatement).setString(Matchers.eq(2), Matchers.contains("20141016"));
            verify(boundStatement,never() ).setString(Matchers.eq(2), Matchers.contains("20141015"));
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Unexpected exception: " + ex.getMessage());
        }
    }

    @Test
    public void testWriteValueLaterTimestampDesc() {
        List<String> output = new ArrayList<String>();

        // Setup a date comparator in the writer
        writer.setLatestRecordComparator(new DateComparator() );
        
        try {
            output.add("DATE,20141016");
            output.add("DATE,20141015");
            writer.write(output);
            
            // Verify data
            verify(boundStatement).setString(Matchers.eq(2), Matchers.contains("20141016"));
            verify(boundStatement,never() ).setString(Matchers.eq(2), Matchers.contains("20141015"));
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Unexpected exception: " + ex.getMessage());
        }
    }

    @Test
    public void testWriteValueLaterTimestampWithOldRows() {
        List<String> output = new ArrayList<String>();

        // Init mocks for the old row query
        String getOldRowsQuery = "select * from \"JUNIT_CF\" where key in ('DATE');";
        when(cqlProxy.executeQuery(getOldRowsQuery)).thenReturn(getOldRows());
        
        // Setup a date comparator in the writer
        writer.setLatestRecordComparator(new DateComparator() );
        
        try {
            output.add("DATE,20141015");
            writer.write(output);
            
            // Verify data
            verify(boundStatement).setString(Matchers.eq(2), Matchers.contains("20141015"));
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Unexpected exception: " + ex.getMessage());
        }
    }

    @Test
    public void testWriteValueEarlierTimestampWithOldRows() throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        List<String> output = new ArrayList<String>();

        // Init mocks for the old row query
        String getOldRowsQuery = "select * from \"JUNIT_CF\" where key in ('DATE');";
        when(cqlProxy.executeQuery(getOldRowsQuery)).thenReturn(getOldRows());
        
        // Setup a date comparator in the writer
        writer.setLatestRecordComparatorClass( (Class<BaseCassandraComparator>)Class.forName("com.ubs.idp.connector.spring.batch.utils.DateComparator") );
        
        try {
            output.add("DATE,20141013");
            writer.write(output);
            
            // Verify data
            verify(boundStatement,never()).setString(Matchers.eq(2), Matchers.contains("20141013"));
            // Check DOES DO old key lookup
            verify(cqlProxy).executeQuery(Matchers.contains("where key in"));
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Unexpected exception: " + ex.getMessage());
        }
    }

    @Test
    public void testWriteValueIntegerComparatorWithAttribtueNamesAsc() throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        List<String> output = new ArrayList<String>();
        
        writer.setAttributeNames(Arrays.asList("foo","bar") );
        
        // Setup a date comparator in the writer
        writer.setLatestRecordComparatorClass( (Class<BaseCassandraComparator>)Class.forName("com.ubs.idp.connector.spring.batch.utils.NumberComparator") );
        
        try {
            output.add("NUMBER,1");
            output.add("NUMBER,2");
            writer.write(output);
            
            // Verify that data
            verify(boundStatement).setString(Matchers.eq(2), Matchers.contains("2"));
            verify(boundStatement,never()).setString(Matchers.eq(2), Matchers.contains("1"));
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Unexpected exception: " + ex.getMessage());
        }
    }

    @Test
    public void testWriteValueIntegerComparatorWithAttribtueNamesDesc() throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        List<String> output = new ArrayList<String>();
        
        // Setup a date comparator in the writer
        writer.setLatestRecordComparatorClass( (Class<BaseCassandraComparator>)Class.forName("com.ubs.idp.connector.spring.batch.utils.NumberComparator") );

        writer.setAttributeNames(Arrays.asList("foo","bar") );
        
        try {
            output.add("NUMBER,2");
            output.add("NUMBER,1");
            writer.write(output);
            
            // Verify that data
            verify(boundStatement).setString(Matchers.eq(2), Matchers.contains("2"));
            verify(boundStatement,never()).setString(Matchers.eq(2), Matchers.contains("1"));
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Unexpected exception: " + ex.getMessage());
        }
    }

    @Test
    public void testWriteValueEarlierTimestampWithLoadOnly() throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        List<String> output = new ArrayList<String>();

        // Init mocks for the old row query
        String getOldRowsQuery = "select * from \"JUNIT_CF\" where key in ('DATE');";
        when(cqlProxy.executeQuery(getOldRowsQuery)).thenReturn(getOldRows());

        // Set loadOnly
        writer.setLoadOnly(true);
        
        // Setup a date comparator in the writer
        writer.setLatestRecordComparatorClass((Class<BaseCassandraComparator>)Class.forName("com.ubs.idp.connector.spring.batch.utils.DateComparator"));
        
        try {
            output.add("DATE,20141013");
            writer.write(output);
            
            // Verify that data
            verify(boundStatement).setString(Matchers.eq(2), Matchers.contains("20141013"));
            
            // Check NO old key lookup
            verify(cqlProxy, never()).executeQuery(Matchers.contains("where key in"));
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Unexpected exception: " + ex.getMessage());
        }
    }
    
    /**
     * Returns old row data
     * @return
     */
    private List<Map<String, Object>> getOldRows()
    {
        List<Map<String, Object>> oldRows = new ArrayList<Map<String, Object>>();
        Map<String,Object> oldRow1 = new HashMap<String,Object>();
        
        oldRow1.put("key","DATE");
        oldRow1.put("value","DATE"+FIELD_SEPARATOR+"20141014");
        
        oldRows.add(oldRow1);

        return oldRows;
    }
}