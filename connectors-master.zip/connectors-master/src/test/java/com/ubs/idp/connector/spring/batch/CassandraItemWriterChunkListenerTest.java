package com.ubs.idp.connector.spring.batch;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.ubs.idp.connector.spring.batch.utils.ItemWriterUtil;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.spring.batch.exceptions.BadRowException;
import com.ubs.idp.connectors.spring.batch.writers.BaseCassandraItemWriter;
import com.ubs.idp.connectors.spring.batch.writers.CassandraItemWriter;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.*;
import org.springframework.batch.core.job.SimpleJob;
import org.springframework.batch.core.repository.dao.MapExecutionContextDao;
import org.springframework.batch.core.repository.dao.MapJobExecutionDao;
import org.springframework.batch.core.repository.dao.MapJobInstanceDao;
import org.springframework.batch.core.repository.dao.MapStepExecutionDao;
import org.springframework.batch.core.repository.support.SimpleJobRepository;
import org.springframework.batch.core.step.AbstractStep;
import org.springframework.batch.core.step.factory.FaultTolerantStepFactoryBean;
import org.springframework.batch.core.step.factory.SimpleStepFactoryBean;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.support.ListItemReader;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;

import java.util.*;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static com.ubs.idp.connector.spring.batch.utils.ItemWriterUtil.*;

public class CassandraItemWriterChunkListenerTest {

    @Mock(name="cassandraCqlProxy")
    CassandraCqlProxy cqlProxy;
    @Mock PreparedStatement preparedStateMent;
    @Mock BoundStatement boundStatement;
    @Mock Map<String,BaseCassandraItemWriter.InputItem> writeChunkCache;

    private SimpleJobRepository repository = new SimpleJobRepository(
            new MapJobInstanceDao(),
            new MapJobExecutionDao(),
            new MapStepExecutionDao(),
            new MapExecutionContextDao());

    private SimpleJob job = new SimpleJob();
    @InjectMocks private CassandraItemWriter writer;

    @Before public void setUp() throws Exception {

        writer = ItemWriterUtil.getCassandraItemWriter();
        MockitoAnnotations.initMocks(this);
        when(cqlProxy.addColumnFamilyIfNeeded(JUNIT_CF)).thenReturn(true);
        when(cqlProxy.getPrepareStatement(Matchers.anyString())).thenReturn(preparedStateMent);
        when(preparedStateMent.bind()).thenReturn(boundStatement);
        job.setJobRepository(repository);
        job.setBeanName("simpleJob");
    }

    @Test public void should_pass_with_only_one_chunk() throws Exception {

        String[] items = new String[]{"1,2", "2,2", "3,2", "4,2", "52", "62", "72"};
        int commitInterval = 8;
        SimpleStepFactoryBean<String, String> factory = getStepFactory(items);
        factory.setCommitInterval(commitInterval);
        AbstractStep step = (AbstractStep) factory.getObject();
        job.setSteps(Collections.singletonList((Step) step));
        JobExecution jobExecution = repository.createJobExecution(job.getName(), new JobParameters());
        job.execute(jobExecution);
        assertWriteAndWriteSkipCounts(jobExecution);
        // Even if there are bad items in the chunk but clear on the cache should be
        // when all the records are processed in the chunk
        verify(writeChunkCache, times(1)).clear();
    }

    @Test public void should_pass_with_bad_rows_over_number_of_chunks() throws Exception {

        String[] items = new String[] {"12", "2,2", "3,2", "4,2", "52", "6,2", "72"};
        SimpleStepFactoryBean<String, String> factory1 = getStepFactory(items);
        factory1.setCommitInterval(2);
        AbstractStep step1 = (AbstractStep) factory1.getObject();
        job.setSteps(Collections.singletonList((Step) step1));
        JobExecution jobExecution1 = repository.createJobExecution(job.getName(), new JobParameters());
        job.execute(jobExecution1);
        assertWriteAndWriteSkipCounts(jobExecution1);
        verify(writeChunkCache, times(4)).clear();
    }

    private void assertWriteAndWriteSkipCounts(JobExecution jobExecution) {

        StepExecution stepExecution = (StepExecution)jobExecution.getStepExecutions().toArray()[0];
        int readCount = stepExecution.getReadCount();
        int writeCount = stepExecution.getWriteCount();
        int writeSkipCount = stepExecution.getWriteSkipCount();
        assertThat(readCount, is(writeCount + writeSkipCount));
        assertThat("Read count should be equal to write and write skip count: ", readCount, is(writeCount + writeSkipCount));
    }

    private SimpleStepFactoryBean<String, String> getStepFactory(String... args) throws Exception {

        FaultTolerantStepFactoryBean factory = new FaultTolerantStepFactoryBean<>();
        List<String> items = new ArrayList<>();
        items.addAll(Arrays.asList(args));
        ItemReader<String> reader = new ListItemReader<>(items);
        factory.setSkipLimit(5);
        factory.setItemReader(reader);
        factory.setItemWriter(writer);
        factory.setJobRepository(repository);
        factory.setTransactionManager(new ResourcelessTransactionManager());
        factory.setBeanName("stepName");
        Map<Class, Boolean> skippableExceptions = new HashMap();
        skippableExceptions.put(BadRowException.class, Boolean.TRUE);
        factory.setSkippableExceptionClasses(skippableExceptions);
        return factory;
    }
}