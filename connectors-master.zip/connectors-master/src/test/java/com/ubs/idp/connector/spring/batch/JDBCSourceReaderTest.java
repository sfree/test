package com.ubs.idp.connector.spring.batch;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import com.ubs.idp.connectors.spring.batch.readers.JDBCSourceReader;

/**
 * JUnit for JDBC source reader
 * @author mcminnp
 */
public class JDBCSourceReaderTest {
    
    private static final String JUNIT_TEST_SOURCE_ID  = "JUnitSource";
    private static final String JUNIT_TEST_SELECT_SQL = "select * from TEST";

    @Before
    public void setUp() throws Exception {        
        // Initialise the mocks
        MockitoAnnotations.initMocks(this);
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void getOneRowTest() {
        JDBCSourceReader reader = setupReader();
        
        try {
            ExecutionContext ctx = new ExecutionContext();
            
            reader.init();
            
            reader.open(ctx);
            
            int rowCount = 0;
            Object res;
            
            while((res = reader.read()) != null) {
                rowCount ++;
            }
            
            assertEquals(1, rowCount);
            assertEquals(1, reader.getRowCount());
            
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception: " + e.getClass().getName());
        } finally {
            if (reader != null) {
                EmbeddedDatabase embeddedDatabase =(EmbeddedDatabase) reader.getDataSource();
                
                if (embeddedDatabase != null) {
                    embeddedDatabase.shutdown();
                }
            }
        }
    }
    
    /**
     * Set up the JDBC reader
     * @return
     */
    private JDBCSourceReader setupReader() {
        JDBCSourceReader reader = new JDBCSourceReader();
        
        reader.setQuerySql(JUNIT_TEST_SELECT_SQL);
        
        DataSource ds = setupDataSource();
        
        reader.setDataSource(ds);
                
        RowMapper<Object> rowMapper = new BasicRowMapper();
        
        reader.setRowMapper(rowMapper);
        
        reader.setSourceIdentifier(JUNIT_TEST_SOURCE_ID);

        return reader;
    }
    
    /**
     * Create and return an embedded HSQL db
     * @return
     */
    public DataSource setupDataSource() {
        EmbeddedDatabase embeddedDatabase = new EmbeddedDatabaseBuilder()
            .setType(EmbeddedDatabaseType.HSQL)
            .addScript("classpath:schema.sql")
            .addScript("classpath:test-data.sql")
            .build();
        
        return embeddedDatabase;
    }
}
