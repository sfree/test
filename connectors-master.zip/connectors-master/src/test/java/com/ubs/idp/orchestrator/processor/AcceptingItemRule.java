package com.ubs.idp.orchestrator.processor;

import java.util.Map;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.InitializingBean;

public class AcceptingItemRule implements ItemProcessor<Map<String, Object>, Map<String, Object>>,
        InitializingBean {

    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        return item;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
    }

}
