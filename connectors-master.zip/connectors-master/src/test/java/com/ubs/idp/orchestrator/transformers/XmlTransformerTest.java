package com.ubs.idp.orchestrator.transformers;

import static org.junit.Assert.*;

import javax.xml.transform.TransformerException;

import org.junit.Before;
import org.junit.Test;

public class XmlTransformerTest {
	
	private String inXml;
	private String xslt;
	private String expectedXml;

	@Before
	public void setup() {
		inXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "\n"
				+ "<catalog>" + "\n"
				+ "  <cd>" + "\n"
				+ "    <title>Empire Burlesque</title>" + "\n"
				+ "    <artist>Bob Dylan</artist>" + "\n"
				+ "    <country>USA</country>" + "\n"
				+ "    <company>Columbia</company>" + "\n"
				+ "    <price>10.90</price>" + "\n"
				+ "    <year>1985</year>" + "\n"
				+ "  </cd>" + "\n"
				+ "</catalog>" + "\n";
		xslt = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "\n"
				+ "<xsl:stylesheet version=\"1.0\" "
				+ "xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">" + "\n"
				+ "<xsl:template match=\"/\">" + "\n"
				+ "  <html>" + "\n"
				+ "  <body>" + "\n"
				+ "  <h2>My CD Collection</h2>" + "\n"
				+ "  <table border=\"1\">" + "\n"
				+ "    <tr bgcolor=\"#9acd32\">" + "\n"
				+ "      <th>Title</th>" + "\n"
				+ "      <th>Artist</th>" + "\n"
				+ "    </tr>" + "\n"
				+ "    <xsl:for-each select=\"catalog/cd\">" + "\n"
				+ "      <tr>" + "\n"
				+ "        <td><xsl:value-of select=\"title\"/></td>" + "\n"
				+ "        <td><xsl:value-of select=\"artist\"/></td>" + "\n"
				+ "      </tr>" + "\n"
				+ "    </xsl:for-each>" + "\n"
				+ "  </table>" + "\n"
				+ "  </body>" + "\n"
				+ "  </html>" + "\n"
				+ "</xsl:template>" + "\n"
				+ "</xsl:stylesheet>" + "\n";
		expectedXml = "<html>"
				+ "<body>"
				+ "<h2>My CD Collection</h2>"
				+ "<table border=\"1\">"
				+ "<tr bgcolor=\"#9acd32\">"
				+ "<th>Title</th><th>Artist</th>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>Empire Burlesque</td><td>Bob Dylan</td>"
				+ "</tr>"
				+ "</table>"
				+ "</body>"
				+ "</html>";
	}
	
	@Test
	public void testXsltTransformation() throws TransformerException {
		
		XsltTransformer xsltTransformer = new XsltTransformer(xslt);
		String output = xsltTransformer.transformXmlMessage(inXml);
		output = output.replace("\n", "").replace("\r", "");
		assertEquals(expectedXml, output);
		
		output = xsltTransformer.transformXmlMessage(null);
		assertNull(output);
	}
	
	@Test
	public void testDefaultTransformation() throws Exception {
		
		DefaultXmlTransformer defaultTransformer = new DefaultXmlTransformer();
		String output = defaultTransformer.transformXmlMessage(inXml);
		assertEquals(inXml, output);
		
		output = defaultTransformer.transformXmlMessage(null);
		assertNull(output);
	}

}
