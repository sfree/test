package com.ubs.idp.connector.spring.batch;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:test-context.xml",
        "classpath:jobs/CassandraItemWriterAndIndexerJob.xml"
        })
public class CassandraItemWriterAndIndexerJobTest {

    
    @Autowired
    private JobLauncherTestUtils jobLauncherTestUtils;

    static {
        System.setProperty("environment", "DEV");
    }
    
    @Before
    public void setUp() {
        assertNotNull(jobLauncherTestUtils);
    }

    @Test
    public void launchJob() throws Exception {
    }
}
