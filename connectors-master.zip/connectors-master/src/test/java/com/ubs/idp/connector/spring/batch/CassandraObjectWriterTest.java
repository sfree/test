package com.ubs.idp.connector.spring.batch;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;
import com.ubs.idp.connectors.spring.batch.writers.CassandraObjectWriter;
import com.ubs.idp.lsdb.model.Company;
import com.ubs.idp.lsdb.model.GCRS;
import com.ubs.idp.lsdb.model.Holding;

public class CassandraObjectWriterTest {

    private static final String GCRS_PARENT2 = "GCRSP2";
    private static final String GCRS_PARENT1 = "GCRSP1";
    private static final String GCRS_CHILD = "GCRS1";
    private static final String DUMMY_CF = "CF";
    private static final String NULL_KEY = "NULL";

    List<Object> companies = null;
    List<String> mappings = null;
    
    Company parent1 = null;
    Company parent2 = null;
    Company child = null;

    @Mock
    CassandraCqlProxy cqlProxy;

    @Mock
    CassandraSessionHelper cassandraSessionHelper;

    @InjectMocks
    CassandraObjectWriter writer;

    @Before
    public void setupTestData() throws Exception {

        MockitoAnnotations.initMocks(this);

        companies = new ArrayList<>();
        List<Company> parents = new ArrayList<>();
        List<String>columnNames = new ArrayList<>();

        // Set up test data

        child = createCompany(GCRS_CHILD, "Child", "Parent1", new Float(0.17));
        parent1 = createCompany(GCRS_PARENT1, "Parent1");
        parent2 = createCompany(GCRS_PARENT2, "Parent2");

        companies.add(child);
        companies.add(parent1);
        companies.add(parent2);

        parents.add(parent1);
        parents.add(parent2);

        child.setParents(parents);

        // Set up mappings

        mappings = new ArrayList<>();

        mappings.add("gcrs.gcrsCode");
        mappings.add("parents.gcrs.gcrsCode");
        mappings.add("parents.gcrs.gcrsCode, parents.id");
        mappings.add("general.entityType.subCategoryCode");
        mappings.add("parents.gcrs.gcrsCode, parents.percentageHolding[id]");
        mappings.add("now()");
        mappings.add("currentTimeMillis()");

        // Set up attr (column) names
        
        columnNames.add("gcrsCode");
        columnNames.add("mfParentGcrsCodes");
        columnNames.add("immediateParentLsdbIds");
        columnNames.add("subcategory");
        columnNames.add("immediateParentOwnershipPercentages");
        columnNames.add("timestamp1");
        columnNames.add("timestamp2");
        
        writer.setMappings(mappings);
        writer.setColumnFamily(DUMMY_CF);
        writer.setColumnNames(columnNames);
        
        writer.afterPropertiesSet();
    }

    /**
     * Simple parsing test
     * @throws Exception
     */
    @Test
    public void parsingTest () throws Exception {
        Map<Object, Integer> bindMap = new HashMap<Object, Integer>();
        DummyBinder binder = new DummyBinder(bindMap);

        writer.processMappings(child, binder);

        assertEquals("Unexpected bind count?", mappings.size(), binder.getBindCount());
        assertEquals("Unexpected bind map size?", mappings.size(), bindMap.size());
        
        // 1st mapping should have been for "gcrs.gcrsCode" i.e.: GCRS_CHILD
        assertEquals("Unexpected binding position?", 0, bindMap.get(GCRS_CHILD).intValue());
    }

    /**
     * Create skeleton company for testing
     * @param gcrsCode
     * @param id
     * @return
     */
    private Company createCompany(String gcrsCode, String id) {

        return createCompany(gcrsCode, id, null, null);
    }

    private Company createCompany(String gcrsCode, String id, String parentId, Float percentage) {
        Company res = new Company();
        GCRS gcrs = new GCRS();

        gcrs.setGcrsCode(gcrsCode);

        res.setGcrs(gcrs);
        res.setId(id);

        if (parentId != null) {
            Holding holding = new Holding();
            holding.setId(parentId);
            holding.setPercentage(percentage);
        }
        return res;
    }
    
    /**
     * Dummy binder
     * @author mcminnp
     */
    public class DummyBinder implements CassandraObjectWriter.ValueBinder {

        private int bindCount = 0;
        private Map<Object, Integer> bindMap;

        public DummyBinder(Map<Object, Integer> bindMap) {
            this.bindMap = bindMap;
        }

        @Override
        public void bindValue(Object value, int bindVarIdx) {
            String key;

            if (value != null) {
                key = value.toString();
            } else {
                key = NULL_KEY;
            }

            bindMap.put(key, new Integer(bindVarIdx));
            bindCount++;
        }

        public int getBindCount() {
            return bindCount;
        }
    }
}
