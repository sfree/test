package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;
import com.ubs.idp.orchestrator.processor.rules.FIAssetTypeRule;

/**
 * Tests for the Fixed Income Asset Type derivation rules for Bills derivation
 * If cfi 7th char id G 
 * and Bloomberg Collateral Type match ("MORTGAGE*BACKED|"ASSET*BACKED) 
 * and 
 * ( 
 * 	bbCollateral Type is BILLS 
 *   or bbTicker is one of RATB,BGTB,CTB,DGTB,RTFB,BTF,BUBILL,HKTB,IRTB,BOTS,JGTB,SKFB,DTB,NZTB,NGTB,SITB,SGLT,SWTB,SWNBK,SWISTB,UKTB 
 *   or issuerCountry is US and time between issueDate and maturityDate maximum 12 months long
 * ) 
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Fixed Income Asset Type definition section)
 * @author haniffsy
 */
public class FIAssetTypeRuleBillsDerivationTest {

	private FIAssetTypeRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new FIAssetTypeRule();
		inputFields = new HashMap<String,Object>();
	}
	
	// Bills
	
	/*
	 * FIXME
	 * This test below will always fail as Collateral Type can't match MORTGAGE*BACKED and BILLS
	 * at the same time. 
	 * It's been left in as this is what is currently specified (which in turn is copied from
	 * the current code in Martini).
	 * See David Cifer's comments at:
	 * http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
	 * in Fixed Income Asset Type # Bills section.
	 * 
	 * TODO Follow up with David Cifer to find the correct rules for this derivation
	 */
	@Test
	@Ignore // TODO: Correct rule
	public void shouldDeriveBillsIfCFISevenIsGAndCollateralTypeMatchesMortgageBackedAndBills() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
	
		// FIXME
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BILLS");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH MORTGAGE BLAH BACKED BLAH");
		
		
		Map<String,Object> results = rule.derive(inputFields);
		
		fail("Need to correct specification for whatever this case is supposed to be");
		
		
		// assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		// assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	// CFI(7) == G AND bbgCollateralType MATCHES MORTGAGE*BACKED AND ticker IN [...]
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerRATB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "RATB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerBGTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BGTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerCTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "CTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerDGTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "DGTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerRTFB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "RTFB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerBTF() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BTF");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerBUBILL() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BUBILL");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerHKTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "HKTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerIRTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "IRTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerBOTS() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BOTS");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerJGTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "JGTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerSKFB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SKFB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerDTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "DGTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerNZTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "NZTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerSITB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SITB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerSGLT() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SGLT");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerSWTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH  BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SWTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeMatchesMortgageBackedAndTickerSWNBK() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SWNBK");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndTickerUKTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "UKTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	

	
	// CFI(7) == G AND bbgCollateralType MATCHES ASSET*BACKED AND ticker IN [...]
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerRATB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "RATB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerBGTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BGTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerCTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "CTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerDGTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "DGTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerRTFB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "RTFB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerBTF() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BTF");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerBUBILL() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BUBILL");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerHKTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "HKTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerIRTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "IRTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerBOTS() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BOTS");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerJGTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "JGTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerSKFB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SKFB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerDTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "DGTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerNZTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "NZTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerSITB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SITB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerSGLT() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SGLT");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerSWTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SWTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerSWNBK() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "SWNBK");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerUKTB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "UKTB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	
	// IF CFI(7) == G AND bbgCollateralType MATCH MORTGAGE*BACKED AND issuerCountry == US AND maturity - issue < 12 months

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndIssueToMaturityLess12Mo() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.ISSUE_DATE, "20130410");
		inputFields.put(DerivationRuleTemplate.MATURITY_DATE, "20130910");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldNotDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndIssueToMaturityMore12Mo() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.ISSUE_DATE, "20130410");
		inputFields.put(DerivationRuleTemplate.MATURITY_DATE, "20140510");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertFalse("Bills".equals(results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE)));
	}		

	
	// IF CFI(7) == G AND bbgCollateralType MATCH ASSET*BACKED AND issuerCountry == US AND maturity - issue < 12 months

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndIssueToMaturityLess12Mo() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.ISSUE_DATE, "20130410");
		inputFields.put(DerivationRuleTemplate.MATURITY_DATE, "20130910");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Bills",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldNotDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndIssueToMaturityMore12Mo() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.ISSUE_DATE, "20130410");
		inputFields.put(DerivationRuleTemplate.MATURITY_DATE, "20140510");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertFalse("Bills".equals(results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE)));
	}
	
}
