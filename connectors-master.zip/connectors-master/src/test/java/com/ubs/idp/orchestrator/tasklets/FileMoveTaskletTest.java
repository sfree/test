package com.ubs.idp.orchestrator.tasklets;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class FileMoveTaskletTest {
    
    public static final String testFileName = "FileMoveTaskletTest.txt";
    public static final String testOutDirName = "FileMoveTaskletTestOut";

    private String testFilePath;
    private String testOutputDirPath;
    private String testOutputFilePath;
    
    private File testOutputDir;
    private File testFile;
    private File testOutputFile;

    private Resource testOutputDirResource;
    private Resource testInputFileResource;
    
    @Before
    public void setUp() {
        String baseDir = System.getProperty("user.dir") + File.separator + "target" + File.separator;
        
        testFilePath = baseDir + testFileName;
        testOutputDirPath = baseDir + testOutDirName;
        testOutputFilePath = testOutputDirPath + File.separator + testFileName;
        
        testOutputDir = new File(testOutputDirPath);
        testFile = new File(testFilePath);
        testOutputFile = new File(testOutputFilePath);
        
        // Pre-delete output from old test run
        cleanup();
        
        // Create output folder
        
        assertTrue("Failed to create output directory? ('" + testOutputDir.getAbsolutePath() + "')", testOutputDir.mkdir());
        
        testOutputDirResource = new FileSystemResource(testOutputDir);
        testInputFileResource = null;
        
        try {
            testInputFileResource = createTestFile(testFile);
        } catch (Exception e) {
            assertNull("Should not get here!", e);
        }
        
        assertTrue("Failed to access test output directory?", testOutputDirResource.exists());
    }
    
    @After
    public void tearDown() {
        cleanup();
    }
    
    @Test
    public void testNoZip() throws IOException {
        
        FileMoveTasklet tasklet = new FileMoveTasklet();
        
        tasklet.setDestinationDirectory(testOutputDirResource);
        
        tasklet.setFile(testInputFileResource);
        
        try {
            tasklet.execute(null, null);
            
            assertTrue("Failed to find output file?", testOutputFile.exists());
            assertFalse("Input file still present?", testFile.exists());
        } catch (Exception e) {
            fail("Should not get here: " + e.getMessage());
        }
    }
    
    @Test
    public void testWithZip() {
        
        FileMoveTasklet tasklet = new FileMoveTasklet();
        
        tasklet.setDestinationDirectory(testOutputDirResource);
        tasklet.setFile(testInputFileResource);
        tasklet.setZip(true);
        
        try {
            tasklet.execute(null, null);
            
            // Zipping appends a ".zip" extension
            testOutputFile = new File(testOutputFile.getAbsolutePath() + ".zip");
            
            assertTrue("Failed to find output file?", testOutputFile.exists());
            assertFalse("Input file still present?", testFile.exists());
        } catch (Exception e) {
            fail("Should not get here: " + e.getMessage());
        }
    }

    protected Resource createTestFile(File testFile) throws Exception {
        if (testFile.exists()) {
            testFile.delete();
        }

        assertTrue("Failed to create test file '" + testFile.getAbsolutePath() + "'?", testFile.createNewFile());
        assertTrue("Failed to create test file '" + testFile.getAbsolutePath() + "'?", testFile.exists());
        
        FileOutputStream fos = new FileOutputStream(testFile);
        
        fos.write("JUnit Test Data".getBytes("UTF-8"));
        fos.close();
        
        Resource testFileResource = new FileSystemResource(testFile);
        
        return testFileResource;
    }

    protected void cleanup() {
        if (testOutputDir.exists()) {
            File[] testFiles = testOutputDir.listFiles();
            
            for(File file : testFiles) {
                assertTrue("Failed to delete test file?", file.delete());
            }
            
            assertTrue("Failed to delete output directory?", testOutputDir.delete());
        }
    }
}
