package com.ubs.idp.connector.spring.batch;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class BasicRowMapper implements RowMapper<Object> {
    public String delimiter = ",";

    @Override
    public String mapRow(ResultSet result, int arg1) throws SQLException {
        
        StringBuilder buffer = null;
        String temp =  null;
                
        temp = null;
        buffer = new StringBuilder();                
    
        for (int i = 0 ; i < result.getMetaData().getColumnCount() ; i++) {
            String fieldName = result.getMetaData().getColumnName(i+1);
            
            temp = result.getString(fieldName);
            buffer.append(fieldName + "=");
            temp = (temp != null) ? temp + delimiter : ",";
            buffer.append(temp);
        }
        
        return buffer.toString();
    }
}