package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;

@RunWith(MockitoJUnitRunner.class)
public class DerivationRuleTemplateTest {

	@Mock
	private DerivationRuleTemplate testObject;
	
	private Map<String,Object> nullMap;
	private Map<String,Object> emptyMap;
	private Map<String,Object> validMap;
	
	
	@Before
	public void setUp() throws Exception {
		nullMap = null;
		emptyMap = new HashMap<String,Object>();
		validMap = new HashMap<String,Object>();
		validMap.put("greeting", "Hello, World!");
	}

	@Test
	public void testNullInput() {
		Map<String, Object> results = testObject.derive(nullMap);
		assertNotNull(results);
		assertTrue(results.isEmpty());
	}

	@Test
	public void testEmptyInput() {
		Map<String, Object> results = testObject.derive(emptyMap);
		assertNotNull(results);
		assertTrue(results.isEmpty());
	}
	
	@Test
	public void testValidInput() {
		Map<String, Object> results = testObject.derive(validMap);
		assertNotNull(results);
		assertFalse(results.isEmpty());
		assertEquals(validMap,results);
	}


}
