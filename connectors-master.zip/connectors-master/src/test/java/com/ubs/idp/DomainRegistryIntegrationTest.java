package com.ubs.idp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;
import com.ubs.idp.domainRegistry.DomainRegistry;
import com.ubs.idp.domainRegistry.DomainRegistryImpl;
import com.ubs.idp.domainRegistry.common.DomainKey;

@Ignore // These are integration tests and shouldn't run as part of the build
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:cassandra-test-context.xml"})
public class DomainRegistryIntegrationTest  {

    private static final Logger logger = LoggerFactory.getLogger(DomainRegistryIntegrationTest.class);

    @Autowired
    @Qualifier("domainRegistry")
    private DomainRegistry domainRegistry;	
    
    @Autowired
    @Qualifier("cassandraSessionHelper")
    private CassandraSessionHelper cassandraSessionHelper;
    
    private CassandraCqlProxy proxy;

    @Before
    public void setup() {
        proxy = cassandraSessionHelper.getProxy();
    }
    
    @Test
    public void testCreateDomainKey(){

        String domain = "Instrument";
        String dataset = "UltraBond";
        String  physicalNodeId ="2";
        String primaryKey ="123456789";

        DomainKey key = domainRegistry.createDomainKey(domain,dataset,physicalNodeId,primaryKey);		 
        logger.info("New Key Created --- "+key.toString());
        assertNotNull("Null key?", key);

        key = domainRegistry.lookUpDomainKey(domain,dataset,physicalNodeId,primaryKey);
        logger.info("Lookup Key --- "+key.toString());
        assertNotNull("Null key?", key);

        primaryKey ="987654321";
        key = domainRegistry.createDomainKey(domain,dataset,physicalNodeId,primaryKey);
        logger.info("Existing domainkey --- "+key.toString());
        assertNotNull("Null key?", key);

        key = domainRegistry.lookUpDomainKey(domain,dataset,physicalNodeId,primaryKey);
        logger.info("Existing domainkey --- "+key.toString());
        assertNotNull("Null key?", key);

        Set<String> setOfPKeys = new HashSet<String>();

        setOfPKeys.add("23415");
        setOfPKeys.add("324111");
        setOfPKeys.add("1293929");
        setOfPKeys.add("93883822992");
        setOfPKeys.add("9929292");
        setOfPKeys.add("8wuwuu21");

        Set<DomainKey> keySet = domainRegistry.createDomainKey(domain, dataset, physicalNodeId, setOfPKeys);
        assertNotNull("Null keyset?", keySet);
        assertEquals("Unexpected key count?", setOfPKeys.size(), keySet.size());

        for (DomainKey domainKey : keySet) {

            logger.info("Batch created domainkey --- "+domainKey.toString());
        }

        Map<String,DomainKey> keyMap = domainRegistry.lookUpDomainKey(domain, dataset, physicalNodeId, setOfPKeys);
        assertNotNull("Null keymap?", keyMap);
        assertEquals("Unexpected key count?", setOfPKeys.size(), keyMap.size());

        for (DomainKey domainKey : keyMap.values()) {

            logger.info("Batch lockup domainkey --- "+domainKey.toString());
        }
    }

    @Test
    @Ignore // Ignoring this test as this class is really an integration tests as
    		// it connects to an existing cassandra instance each time (DEV) and there
    		// is no initialisation or cleardown
    public void testCreateDomainOnlyKey(){

        String domain = "Instrument";
        String primaryKey ="123456789";

        DomainKey key = domainRegistry.createDomainKey(domain,primaryKey);		 
        logger.info("New Key Created --- "+key.toString());
        assertNotNull("Null key?", key);

        key = domainRegistry.lookUpDomainKey(domain,DomainRegistryImpl.DATASET_PLACEHOLDER,DomainRegistryImpl.DATASET_PLACEHOLDER,primaryKey);
        logger.info("Lookup Key --- "+key.toString());
        assertNotNull("Null key?", key);

        primaryKey ="987654321";
        key = domainRegistry.createDomainKey(domain,primaryKey);
        logger.info("Existing domainkey --- "+key.toString());
        assertNotNull("Null key?", key);

        key = domainRegistry.lookUpDomainKey(domain,DomainRegistryImpl.DATASET_PLACEHOLDER,DomainRegistryImpl.DATASET_PLACEHOLDER,primaryKey);
        logger.info("Existing domainkey --- "+key.toString());
        assertNotNull("Null key?", key);

        Set<String> setOfPKeys = new HashSet<String>();

        setOfPKeys.add("23415");
        setOfPKeys.add("324111");
        setOfPKeys.add("1293929");
        setOfPKeys.add("93883822992");
        setOfPKeys.add("9929292");
        setOfPKeys.add("8wuwuu21");

        Set<DomainKey> keySet = domainRegistry.createDomainKey(domain, setOfPKeys);
        assertNotNull("Null keyset?", keySet);
        assertEquals("Unexpected key count?", setOfPKeys.size(), keySet.size());

        for (DomainKey domainKey : keySet) {

            logger.info("Batch created domainkey --- "+domainKey.toString());
        }

        Map<String,DomainKey> keyMap = domainRegistry.lookUpDomainKey(domain, DomainRegistryImpl.DATASET_PLACEHOLDER,DomainRegistryImpl.DATASET_PLACEHOLDER, setOfPKeys);
        assertNotNull("Null keymap?", keyMap);
        assertEquals("Unexpected key count?", setOfPKeys.size(), keyMap.size());

        for (DomainKey domainKey : keyMap.values()) {

            logger.info("Batch lockup domainkey --- "+domainKey.toString());
        }
    }

    
    /**
     * Spin off 20x threads each requesting 50K -ve IDs (total = 1 million)
     * To ensure that the test IS loading Cassandra properly, you need to truncate
     * the "DomainRegistry" CF first.
     * 
     * Use this same test to confirm no duplicate -ve IDs by exporting the DomainRegistry. Note: reduce load (blockSize=5000) to allow cqlsh export.
     * COPY "IDP"."DomainRegistry" (domain, dataset, physicalNodeId, primaryKey, domainkey) TO './DomainRegistry_local.txt' WITH DELIMITER = '\t' AND HEADER='true';
     * Ensure these scripts return blank (no dupes):
     * grep $'Currency\tCURRENCY\t\CURRENCY.IDP' DomainRegistry_local.txt | awk -F $'\t' '{print $5}' | sort | uniq -d
     * grep $'Country\tDSCURRENCY\t\DSCURRENCY.IDP' DomainRegistry_local.txt | awk -F $'\t' '{print $5}' | sort | uniq -d
     * grep $'Instrument\t\t' DomainRegistry_local.txt | awk -F $'\t' '{print $5}' | sort | uniq -d
     * 
     * Leaving this test disabled on check-in.
     */
    @Test
    @Ignore
    public void loadTestCreateDomainKey(){

        int nThreads = 20;
        int blockSize = 50000;
        
        ExecutorService executor = Executors.newFixedThreadPool(nThreads);
        List<String> errorList = Collections.synchronizedList(new ArrayList<String>());

        for (int i = 0; i < nThreads; i++) {
            executor.execute(new IDAllocationWorker(executor, i, blockSize, errorList));
        }
        
        executor.shutdown();
        
        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            fail("Unexpected exception!?");
        }
        
        assertEquals("Unexpected errors?", 0, errorList.size());
    }

    private synchronized void hashMark() {
        System.out.print("#");
        System.out.flush();
    }
    
    private final class IDAllocationWorker implements Runnable {

        private ExecutorService executor;
        private int threadNum;
        private int blockSize;
        private List<String> errorList;

        public IDAllocationWorker(ExecutorService executor, int threadNum, int blockSize, List<String> errorList) {
            this.threadNum = threadNum;
            this.blockSize = blockSize;
            this.errorList = errorList;
            this.executor = executor;
        }

        public void run() {
            String DOMAIN = "Instrument";
            String primaryKey;

            int startValue = blockSize * threadNum;

            for (int i = 0 ; i < blockSize && errorList.size() == 0 ; i++) {

                if ((i % 1000) == 0) {
                    hashMark();
                }

                primaryKey = (startValue + i) + "";

                DomainKey key = domainRegistry.createDomainKey(DOMAIN, primaryKey);

                if (key == null) {
                    String errorMsg = "Null key for primaryKey '" + primaryKey + "'?";
                    System.err.println("\n" + errorMsg);
                    errorList.add(errorMsg);
                    executor.shutdownNow();
                }
            }
        }
    }
}
