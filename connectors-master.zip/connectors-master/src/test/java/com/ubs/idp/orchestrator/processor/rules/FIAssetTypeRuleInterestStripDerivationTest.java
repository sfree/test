package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;
import com.ubs.idp.orchestrator.processor.rules.FIAssetTypeRule;

/**
 * Tests for the Fixed Income Asset Type derivation rules
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Fixed Income Asset Type definition section)
 * @author haniffsy
 */
public class FIAssetTypeRuleInterestStripDerivationTest {

	private FIAssetTypeRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new FIAssetTypeRule();
		inputFields = new HashMap<String,Object>();
	}
	
	
	// Interest Strip
	
	/*
	 * If strip coupon 
	 * or short name equals "STRIPS" and issuer country is "US" 
	 * or short name matches STRIP*INTEREST* 
	 * or short name equals "RESOLUTION FUNDING STRIP"
	 */
	
	
	@Test
	public void shouldDeriveInterestStripIfStripTypeCoupon() {
		inputFields.put(DerivationRuleTemplate.STRIP_TYPE, "Coupon");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Interest Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveInterestStripIfShortNameStripsAndIssuerCountryUS() {
		inputFields.put(DerivationRuleTemplate.SHORT_NAME, "STRIPS");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Interest Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	
	@Test
	public void shouldDeriveInterestStripIfShortNameMatchesStripStarInterestStar() {
		inputFields.put(DerivationRuleTemplate.SHORT_NAME, "BLAH STRIP BLAH INTEREST BLAH");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Interest Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveInterestStripIfShortNameIsResolutionFundingStrip() {
		inputFields.put(DerivationRuleTemplate.SHORT_NAME, "RESOLUTION FUNDING STRIP");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Interest Strip",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
}
