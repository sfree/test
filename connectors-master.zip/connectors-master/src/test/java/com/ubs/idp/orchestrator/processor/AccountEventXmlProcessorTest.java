package com.ubs.idp.orchestrator.processor;

import static com.ubs.idp.orchestrator.util.AccountEventConstants.DATA_TYPE;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.DOWNSTREAM_SP_ID;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.DOWNSTREAM_SYSTEM;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.EVENT_ID;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.PROPAGATION_SERVICE_IMPL_PREFIX;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.RESULT_SET_IDP_ID;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.RESULT_SET_TYPE;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.XML_OUTBOUND_MESSAGE_NAME;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;




import com.ubs.idp.connectors.spring.batch.writers.AccountEventResultSetWriter;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.orchestrator.parser.Message;
import com.ubs.idp.orchestrator.transformers.DefaultXmlTransformer;
import com.ubs.idp.orchestrator.transformers.XmlTransformer;

public class AccountEventXmlProcessorTest {

	private AccountEventXmlProcessor accountEventXmlProcessor;
	@Mock
	private static MetadataService mds;

	@RunWith(SpringJUnit4ClassRunner.class)
	@Configuration
	@ComponentScan(value = {
			"com.ubs.idp.orchestrator.processor.AccountEventXmlProcessor",
			"org.springframework.oxm.jaxb.*" })
	static class ContextConfiguration {

		@Bean(name = "jaxb2Marshaller")
		public Jaxb2Marshaller marshaller() {
			Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
			marshaller.setClassesToBeBound(Message.class);
			return marshaller;
		}

		@Bean(name = "accountEventXmlProcessor")
		@Qualifier(value = "com.ubs.idp.orchestrator.processor.AccountEventXmlProcessor")
		public AccountEventXmlProcessor accountEventXmlProcessor() {
			return new AccountEventXmlProcessor();
		}

		@Bean(name = "mdsClient")
		@Qualifier(value = "com.ubs.idp.metadata.client.MetadataService")
		public MetadataService mds() {
			return mds;
		}
		
		@Bean(name = "transformStrategy")
		@Qualifier(value = "java.util.HashMap")
		public HashMap<String, XmlTransformer> transformStrategy() {
			HashMap<String, XmlTransformer> strategyMap = new HashMap<String, XmlTransformer>();
			strategyMap.put("80", new DefaultXmlTransformer());
			return strategyMap;
		}

	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		Map<String, Map<String, String>> transformationMappings = getTransformationMappingsOfView();
		when(mds.getTransformationMappingforView("ConsumerView80")).thenReturn(
				transformationMappings);
		Map<String, String> propertyMap = new HashMap<String, String>();
		propertyMap.put(DATA_TYPE, "ADDRESS");
		propertyMap.put(DOWNSTREAM_SYSTEM, "ADP");
		when(
				mds.getPropertyMapOfServiceImplementation(PROPAGATION_SERVICE_IMPL_PREFIX
						+ "80")).thenReturn(propertyMap);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testProcess() throws Exception {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(
				ContextConfiguration.class);
		accountEventXmlProcessor = ctx.getBean(AccountEventXmlProcessor.class);
		AccountEventResultSetWriter.AccountEventResultSets accountEventResultSets = getAccountEventResultSets();
		AccountEventResultSetWriter.AccountEventResultSets eventResultSets = accountEventXmlProcessor
				.process(accountEventResultSets);
		String expectedXML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
				+ "<Message xsi:schemaLocation=\"urn:idp:consumer:idp_message.xsd\" xmlns=\"urn:idp:consumer\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<Header><MessageID>458996</MessageID><MessageType>Address</MessageType><SystemID>80</SystemID><SourceSystem>BPS</SourceSystem></Header>"
				+ "<PayloadData><ResultSets><ResultSet type=\"address\"><Records><Record><Fields><Field><Name>Custody_Account</Name><LegacyName>custody_acct</LegacyName><Value></Value></Field><Field><Name>Number_Of_Statements</Name><LegacyName>stmnt_no</LegacyName><Value>0</Value></Field><Field><Name>ADP_Branch_Number</Name><LegacyName>com_br_num</LegacyName><Value>200</Value></Field><Field><Name>ADP_Account_Number</Name><LegacyName>com_ac_num</LegacyName><Value>04351</Value></Field><Field><Name>Swift_Code</Name><LegacyName>swift_code</LegacyName><Value></Value></Field><Field><Name>Action</Name><LegacyName>com_action</LegacyName><Value>3</Value></Field><Field><Name>Number_Of_Confirms</Name><LegacyName>conf_no</LegacyName><Value>0</Value></Field><Field><Name>ADP_Communication_Method</Name><LegacyName>swift_ind</LegacyName><Value></Value></Field><Field><Name>IP_Free_Text_Line_1</Name><LegacyName>na_line_1</LegacyName><Value>[5942      ] taddress1</Value></Field><Field><Name>IP_Free_Text_Line_2</Name><LegacyName>na_line_2</LegacyName><Value>[5942      ] taddress2</Value></Field><Field><Name>IP_Free_Text_Line_3</Name><LegacyName>na_line_3</LegacyName><Value>[5942      ] taddress3</Value></Field><Field><Name>Electronic_Communication_Line_2</Name><LegacyName>swift_addr2</LegacyName><Value>------------------------------</Value></Field><Field><Name>IP_Free_Text_Line_6</Name><LegacyName>na_line_6</LegacyName><Value>[5942      ] taddress6</Value></Field><Field><Name>Electronic_Communication_Line_1</Name><LegacyName>swift_addr1</LegacyName><Value>------------------------------</Value></Field><Field><Name>IP_Free_Text_Line_5</Name><LegacyName>na_line_5</LegacyName><Value>[5942      ] taddress5</Value></Field><Field><Name>IP_Free_Text_Line_4</Name><LegacyName>na_line_4</LegacyName><Value>[5942      ] taddress4</Value></Field><Field><Name>ADP_Client_Number</Name><LegacyName>com_cl_num</LegacyName><Value>16</Value></Field><Field><Name>DTC_ID</Name><LegacyName>ip_dtc_id</LegacyName><Value>00050</Value></Field><Field><Name>DTC_Agent_Bank_ID</Name><LegacyName>ip_agt_bnk</LegacyName><Value>00050</Value></Field><Field><Name>Rte_Ofc</Name><LegacyName>rte_ofc</LegacyName><Value>200</Value></Field><Field><Name>Duplicate_Principle_1099</Name><LegacyName>1099_yr</LegacyName><Value>-</Value></Field><Field><Name>Electronic_Communication_Number</Name><LegacyName>swift_id</LegacyName><Value></Value></Field><Field><Name>Interested_Party_ID</Name><LegacyName>com_rec_id2</LegacyName><Value>8</Value></Field><Field><Name>UBS_MF_GL</Name><LegacyName>cconsol</LegacyName><Value>5942</Value></Field><Field><Name>Language</Name><LegacyName>language</LegacyName><Value>E</Value></Field><Field><Name>DTC_Internal_Account_Number</Name><LegacyName>ip_cust_nbr</LegacyName><Value>050</Value></Field></Fields></Record></Records></ResultSet></ResultSets></PayloadData></Message>";
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		String firstNameDoc1 = "";
		Object firstNameDoc2 = "";
		try {
			builder = factory.newDocumentBuilder();
			// Document doc1 = builder.parse( new InputSource(new
			// ByteArrayInputStream(expectedXML.getBytes("utf-8"))) );
			Document doc2 = builder.parse(new InputSource(
					new ByteArrayInputStream(accountEventResultSets
							.getMappedEvent().get(XML_OUTBOUND_MESSAGE_NAME).toString()
							.getBytes("utf-8"))));
			XPath xPath = XPathFactory.newInstance().newXPath();
			String path1 = "/Message/Header/MessageID";
			String path2 = "/Message/PayloadData/ResultSets/ResultSet[@type='address']/Records/Record/Fields/Field/Value[text()='UBS_MF_GL']";
			firstNameDoc1 = xPath.compile(path1).evaluate(doc2);
			// need to write more xpaths for comparison of xml content
		} catch (Exception e) {
			e.printStackTrace();
		}
		Assert.assertEquals("comapring message id", firstNameDoc1, "458996");

	}

	private AccountEventResultSetWriter.AccountEventResultSets getAccountEventResultSets() {

		AccountEventResultSetWriter.AccountEventResultSets accountEventResultSets = new AccountEventResultSetWriter.AccountEventResultSets();

		Map<Integer, Map<Integer, Map<String, String>>> transformedResultSetsMaps = new HashMap<>();
		Map<Integer, Map<String, String>> resultSetsMap = new HashMap<>();
		Map<String, String> eventMap = new HashMap<>();
		setDataInEventMap(eventMap);
		resultSetsMap.put(1, eventMap);
		transformedResultSetsMaps.put(1, resultSetsMap);
		accountEventResultSets
				.setTransformedResultSetsMap(transformedResultSetsMaps);
		HashMap<String, Object> mappedEvent = new HashMap<>();
		mappedEvent.put(DOWNSTREAM_SP_ID, "80");
		mappedEvent.put(EVENT_ID, "458996");
		mappedEvent.put(RESULT_SET_TYPE, "Address");
		mappedEvent.put(RESULT_SET_IDP_ID, 458996);
		accountEventResultSets.setMappedEvent(mappedEvent);
		Map<Integer, String> uniqueResultMap = new HashMap<Integer, String>();
		uniqueResultMap.put(1, "Address");
		accountEventResultSets.setUniqueResultsetType(uniqueResultMap);
		return accountEventResultSets;
	}

	private Map<String, Map<String, String>> getTransformationMappingsOfView() {
		Map<String, Map<String, String>> transformationMappings = new HashMap();
		Map<String, String> transformationMapping = new HashMap();
		transformationMapping.put("UBS_MF_GL", "cconsol");
		transformationMapping.put("ADP_Client_Number", "com_cl_num");
		transformationMapping.put("ADP_Branch_Number", "com_br_num");
		transformationMapping.put("ADP_Account_Number", "com_ac_num");
		transformationMapping.put("Action", "com_action");
		transformationMapping.put("Rte_Ofc", "rte_ofc");
		transformationMapping.put("Interested_Party_ID", "com_rec_id2");
		transformationMapping.put("DTC_ID", "ip_dtc_id");
		transformationMapping.put("DTC_Agent_Bank_ID", "ip_agt_bnk");
		transformationMapping.put("DTC_Internal_Account_Number", "ip_cust_nbr");
		transformationMapping.put("Number_Of_Confirms", "conf_no");
		transformationMapping.put("Number_Of_Statements", "stmnt_no");
		transformationMapping.put("Language", "language");
		transformationMapping.put("Duplicate_Principle_1099", "1099_yr");
		transformationMapping.put("ADP_Communication_Method", "swift_ind");
		transformationMapping
				.put("Electronic_Communication_Number", "swift_id");
		transformationMapping.put("Electronic_Communication_Line_1",
				"swift_addr1");
		transformationMapping.put("Electronic_Communication_Line_2",
				"swift_addr2");
		transformationMapping.put("IP_Free_Text_Line_1", "na_line_1");
		transformationMapping.put("IP_Free_Text_Line_2", "na_line_2");
		transformationMapping.put("IP_Free_Text_Line_3", "na_line_3");
		transformationMapping.put("IP_Free_Text_Line_4", "na_line_4");
		transformationMapping.put("IP_Free_Text_Line_5", "na_line_5");
		transformationMapping.put("IP_Free_Text_Line_6", "na_line_6");
		transformationMapping.put("Custody_Account", "custody_acct");
		transformationMapping.put("Swift_Code", "swift_code");
		transformationMappings.put("Address", transformationMapping);
		return transformationMappings;

	}

	private void setDataInEventMap(Map<String, String> eventMap) {
		eventMap.put("UBS_MF_GL", "5942");
		eventMap.put("ADP_Client_Number", "16");
		eventMap.put("ADP_Branch_Number", "200");
		eventMap.put("ADP_Account_Number", "04351");
		eventMap.put("Action", "3");
		eventMap.put("Rte_Ofc", "200");
		eventMap.put("Interested_Party_ID", "8");
		eventMap.put("DTC_ID", "00050");
		eventMap.put("DTC_Agent_Bank_ID", "00050");
		eventMap.put("DTC_Internal_Account_Number", "050");
		eventMap.put("Number_Of_Confirms", "0");
		eventMap.put("Number_Of_Statements", "0");
		eventMap.put("Language", "E");
		eventMap.put("Duplicate_Principle_1099", "-");
		eventMap.put("ADP_Communication_Method", "");
		eventMap.put("Electronic_Communication_Number", "");
		eventMap.put("Electronic_Communication_Line_1",
				"------------------------------");
		eventMap.put("Electronic_Communication_Line_2",
				"------------------------------");
		eventMap.put("IP_Free_Text_Line_1", "[5942      ] taddress1");
		eventMap.put("IP_Free_Text_Line_2", "[5942      ] taddress2");
		eventMap.put("IP_Free_Text_Line_3", "[5942      ] taddress3");
		eventMap.put("IP_Free_Text_Line_4", "[5942      ] taddress4");
		eventMap.put("IP_Free_Text_Line_5", "[5942      ] taddress5");
		eventMap.put("IP_Free_Text_Line_6", "[5942      ] taddress6");
		eventMap.put("Custody_Account", "");
		eventMap.put("Swift_Code", "");
	}

}
