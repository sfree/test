/**
 * 
 */
package com.ubs.idp.connector.spring.batch.reader;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.ubs.idp.connectors.cassandra.CassandraConfig;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxyImpl;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;
import com.ubs.idp.connectors.spring.batch.readers.AccountEventCassandraItemReader;
import com.ubs.idp.connectors.spring.batch.writers.AccountEventResultSetWriter;


/**
 * @author valechak
 * 
 */
public class AccountEventCassandraItemReaderTest {

	private static final String cql = "Select * from mf_sp_resultsets where idpid=";
	private static final long IDPID = 12345L;
	private static final String RESULTSETID = "RS11";
	private static final String ACCOUNT_CODE = "22222";
	private static final String ACCOUNT_ID = "33333";
	//private static final String CREATED_TIMESTAMP = "1\tfoo\t123\tabc";
	private static final String DOWNSTREAM_SP_ID = "79";
	private static final long NEVENTID = 56789L;
	private static final int RECORDNO = 1;
	private static final Map<String,String> RESULTSETMAP = new HashMap<String,String>();
	private static final Map<String,String> TRANSFORMED_RESULTSETMAP =new HashMap<String,String>();
	private static final int RESULTSETNO = 1;
	private static final String RESULTSETTYPE = "cleint";

	@Mock
	CassandraCqlProxy cqlProxy;
	
	CassandraSessionHelper cassandraSessionHelper;

	CassandraConfig cassandraConfig;

	@Mock
	static ResultSet resultSet;

	@Mock
	Row resultSetRow1;
	
	@Mock
	Session session;

	@InjectMocks
	AccountEventCassandraItemReader reader;
	
	@RunWith(SpringJUnit4ClassRunner.class)
	@Configuration
	static class ContextConfiguration {
		@Bean(name = "spResult")
		@Qualifier(value = " com.ubs.idp.connectors.spring.batch.writers.AccountEventResultSetWriter.AccountEventResultSets")
		public AccountEventResultSetWriter.AccountEventResultSets getSpResult() {
			AccountEventResultSetWriter.AccountEventResultSets spResult = new AccountEventResultSetWriter.AccountEventResultSets();
			return spResult;
		}
		
		@Bean(name = "cassandraItemReader")
		@Qualifier(value = "com.ubs.idp.connectors.spring.batch.readers.AccountEventCassandraItemReader")
		public AccountEventCassandraItemReader getCassandraItemReader() {
			AccountEventCassandraItemReader spResult = new AccountEventCassandraItemReader();
			return spResult;
		}
		
		@Bean(name = "cassandraSessionHelper")
		@Qualifier(value = "com.ubs.idp.connectors.cassandra.CassandraSessionHelper")
		public CassandraSessionHelper getCassandraSessionHelper() {
			CassandraSessionHelper cassandraSessionHelper = new CassandraSessionHelper(){
				@Override
				public CassandraCqlProxy getProxy() {			
					return new CassandraCqlProxyImpl(new CassandraConfig()){						
						public ResultSet executeStatement(String cqlStatement, ConsistencyLevel consistencyLevel) {							
							return resultSet;
						}
					};
				}	
			};
			return cassandraSessionHelper;
		}
		
		@Bean(name = "cassandraConfig")
		@Qualifier(value = "com.ubs.idp.connectors.cassandra.CassandraConfig")
		public CassandraConfig getCassandraConfig() {	
			return new CassandraConfig(){
				
			};
		}
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		reader = setupReader();
		reader.setCql(cql);
		// Initialise the mocks
		MockitoAnnotations.initMocks(this);
		reader.setColumnsAndTypes(getcolumnsAndTypes());
		reader.setFieldSeparator(DelimitedLineTokenizer.DELIMITER_TAB);
		reader.setAttributeNames("one,two");
		assertEquals("two", reader.getAttributeNames()[1]);
		String [] attr = {"one", "two"};
		reader.setAttributeNames(attr);
		assertEquals("two", reader.getAttributeNames()[1]);
		List<Row> primaryDataRows = new ArrayList<Row>();
		primaryDataRows.add(resultSetRow1);
		Iterator<Row> rowIt = primaryDataRows.iterator();
		RESULTSETMAP.put("field1", "value1");
		RESULTSETMAP.put("field2", "value1");
		RESULTSETMAP.put("field3", "value1");
		when(resultSetRow1.getLong("idpid")).thenReturn(IDPID);
		when(resultSetRow1.getString("resultsetid")).thenReturn(RESULTSETID);
		when(resultSetRow1.getString("account_code")).thenReturn(ACCOUNT_CODE);
		when(resultSetRow1.getString("account_id")).thenReturn(ACCOUNT_ID);
		//when(resultSetRow1.getString("created_timestamp")).thenReturn(CREATED_TIMESTAMP);
		when(resultSetRow1.getString("downstream_sp_id")).thenReturn(DOWNSTREAM_SP_ID);
		when(resultSetRow1.getLong("neventid")).thenReturn(NEVENTID);
		when(resultSetRow1.getInt("recordno")).thenReturn(RECORDNO);
		when(resultSetRow1.getMap("resultsetmap", String.class, String.class)).thenReturn(RESULTSETMAP);
		when(resultSetRow1.getMap("transformed_resultsetmap", String.class, String.class)).thenReturn(TRANSFORMED_RESULTSETMAP);
		when(resultSetRow1.getInt("resultsetno")).thenReturn(RESULTSETNO);
		when(resultSetRow1.getString("resultsettype")).thenReturn(RESULTSETTYPE);
		when(resultSet.iterator()).thenReturn(rowIt);
		when(cqlProxy.executeStatement(cql+"0;")).thenReturn(resultSet);
	}

	private Map<String, String> getcolumnsAndTypes() {
		// TODO Auto-generated method stub
		HashMap<String,String> columnsAndTypes=new HashMap<String,String>();
		columnsAndTypes.put("idpid", "bigint");
		columnsAndTypes.put("resultsetid", "text");
		columnsAndTypes.put("account_code", "text");
		columnsAndTypes.put("account_id", "text");
		columnsAndTypes.put("created_timestamp", "timestamp");
		columnsAndTypes.put("downstream_sp_id", "text");
		columnsAndTypes.put("neventid", "bigint");
		columnsAndTypes.put("recordno", "int");
		columnsAndTypes.put("resultsetmap", "map<text, text>");
		columnsAndTypes.put("transformed_resultsetmap", "map<text, text>");
		columnsAndTypes.put("resultsetno", "int");
		columnsAndTypes.put("resultsettype", "text");
		columnsAndTypes.put("test", "notexist");
		
		return columnsAndTypes;
	}

	@Test
	public void testCassandraItemReader() {
        
        try {
            ExecutionContext ctx = new ExecutionContext();
            reader.afterPropertiesSet();
            reader.open(ctx);
            int rowCount = 0;
            while(reader.read() != null) {
                rowCount ++;
            }
            
            assertEquals(1, rowCount);
            assertEquals(1, reader.getRowCount());
            assertEquals(cql, reader.getCql());
            
            reader.update(ctx);
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception: " + e.getClass().getName());
        }
    }

	/**
	 * Set up the Cassandra reader
	 * 
	 * @return
	 */
	private AccountEventCassandraItemReader setupReader() {		
		ApplicationContext ctx = new AnnotationConfigApplicationContext(
				ContextConfiguration.class);
		reader = ctx.getBean(AccountEventCassandraItemReader.class);
		return reader;
	}

}
