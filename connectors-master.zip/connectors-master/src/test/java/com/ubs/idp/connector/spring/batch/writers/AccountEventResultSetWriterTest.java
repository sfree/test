package com.ubs.idp.connector.spring.batch.writers;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.PreparedStatement;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.spring.batch.writers.AccountEventResultSetWriter;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class AccountEventResultSetWriterTest {

    @InjectMocks
    private AccountEventResultSetWriter accountEventResultSetWriter;
    @Mock
    CassandraCqlProxy proxy;
    @Mock
    PreparedStatement preparedStatement;
    public static final String DOWNSTREAM_SP_ID = "downstream_sp_id";

    @Before
    public void setUp() {
        accountEventResultSetWriter = new AccountEventResultSetWriter();
        MockitoAnnotations.initMocks(this);
        when(proxy.getPrepareStatement(anyString())).thenReturn(preparedStatement);
    }

    @Test
    public void testWrite() throws Exception {
    	accountEventResultSetWriter.setQuery("testQuery");
        accountEventResultSetWriter.write(getMfEventsToWrite());
        verify(proxy).executeStatement(any(BatchStatement.class));
        
    }

    private List<List<AccountEventResultSetWriter.AccountEventResultSets>> getMfEventsToWrite() {

        AccountEventResultSetWriter.AccountEventResultSets mfEventData = new AccountEventResultSetWriter.AccountEventResultSets();
        mfEventData.setMappedEvent(getMfEvent("SP79"));
        HashMap<String, Map<String, String>> resultSets = new HashMap<>();
        HashMap<String, String> cols = new HashMap<>();
        cols.put("cconsol", "123456");
        resultSets.put("result1", cols);
        mfEventData.setResultSets(resultSets);
        Map<Integer, String> map = new HashMap<Integer, String>();
        map.put(1, "one");
        mfEventData.setUniqueResultsetType(map);
        assertEquals("one", mfEventData.getUniqueResultsetType().get(1));
        assertNull(mfEventData.getResultSetsMap());
        return Collections.singletonList(Collections.singletonList(mfEventData));
    }

    private Map<String, Object> getMfEvent(String procId) {

        Map<String, Object> mfEvent = new HashMap<>();
        mfEvent.put(DOWNSTREAM_SP_ID, procId);
        mfEvent.put(AccountEventResultSetWriter.EVENT_ID, 1l);
        mfEvent.put(AccountEventResultSetWriter.EVENT_ACCOUNT_ID, "123456");
        mfEvent.put(AccountEventResultSetWriter.EVENT_ACCOUNT_CODE, "123456");
        mfEvent.put(AccountEventResultSetWriter.EVENT_MF_HOST, "MFSTM");
        mfEvent.put(AccountEventResultSetWriter.EVENT_RETRY_COUNT, 2l);
        return mfEvent;
    }
}
