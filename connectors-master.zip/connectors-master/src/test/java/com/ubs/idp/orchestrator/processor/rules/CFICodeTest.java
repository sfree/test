package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.CFICode;

public class CFICodeTest {
	
	private CFICode cfi;

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testAtPositionNullCode() {
		cfi = new CFICode(null);
		String result = cfi.atPosition(1);
		assertNull(result);
	}

	@Test
	public void testAtPositionPositionTooLarge() {
		cfi = new CFICode("ABCDEFGH");
		String result = cfi.atPosition(9);
		assertNull(result);
	}
	
	@Test
	public void testAtPositionPositionTooSmall() {
		cfi = new CFICode("ABCDEFGH");
		String result = cfi.atPosition(0);
		assertNull(result);
	}

	
	@Test
	public void testAtPositionPositionThree() {
		cfi = new CFICode("ABCDEFGH");
		String result = cfi.atPosition(3);
		assertEquals("C",result);
	}
	
	
	@Test
	public void testMatchesAtPositionNullInputs() {
		cfi = new CFICode("ABCDEFGH");
		String[] matches = null;
		assertFalse(cfi.matchesAtPosition(3, matches));
	}
	
	@Test
	public void testMatchesAtPositionEmptyInputs() {
		cfi = new CFICode("ABCDEFGH");
		String[] matches = new String[0];
		assertFalse(cfi.matchesAtPosition(3, matches));
	}

	@Test
	public void testMatchesAtPositionNullString() {
		cfi = new CFICode("ABCDEFGH");
		String[] matches = new String[1];
		matches[0] = null;
		assertFalse(cfi.matchesAtPosition(3, matches));
	}
	
	
	@Test
	public void testMatchesAtPositionNullResultingPosition() {
		cfi = new CFICode("ABCDEFGH");
		String[] matches = {"C"};
		assertFalse(cfi.matchesAtPosition(10, matches));
	}
	
	@Test
	public void testMatchesAtPositionShouldNotMatch() {
		cfi = new CFICode("ABCDEFGH");
		String[] matches = {"A","B","D"};
		assertFalse(cfi.matchesAtPosition(3, matches));
	}
	
	@Test
	public void testMatchesAtPositionShouldMatch() {
		cfi = new CFICode("ABCDEFGH");
		String[] matches = {"A","C","D"};
		assertTrue(cfi.matchesAtPosition(3, matches));
	}
	
	@Test
	public void testMatchesAtPositionOneItem() {
		cfi = new CFICode("ABCDEFGH");
		String[] matches = {"C"};
		assertTrue(cfi.matchesAtPosition(3, matches));
	}

}
