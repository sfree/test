package com.ubs.idp.orchestrator.processor;

import com.ubs.idp.connectors.spring.batch.writers.AccountEventResultSetWriter;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.orchestrator.util.MetaDataRetrieverUtil;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static com.ubs.idp.orchestrator.util.AccountEventConstants.*;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

public class AccountEventResultSetMapTransformerTest {

    @InjectMocks private AccountEventResultSetMapTransformer accountEventResultSetMapTransformer;
    @Mock private MetaDataRetrieverUtil metaDataRetrieverUtil;
    @Mock private MetadataService mds;


    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        accountEventResultSetMapTransformer.setMetaDataRetrieverUtil(metaDataRetrieverUtil);
        Map<String, Map<String, String>> transformationMappings = new HashMap();
        Map<String, String> transformationMapping = new HashMap();
        transformationMapping.put("cconsol", "UBS_MF_GL");
        transformationMappings.put("client", transformationMapping);
        when(mds.getDataSetTransformationMappings(anyString())).thenReturn(transformationMappings);
    }

    @Test
    public void testProcess() throws Exception {

        AccountEventResultSetWriter.AccountEventResultSets accountEventResultSets = getAccountEventResultSets();
        AccountEventResultSetWriter.AccountEventResultSets eventResultSets = accountEventResultSetMapTransformer.process(accountEventResultSets);
        assertThat(eventResultSets.getTransformedResultSetsMap().get(1).get(1).size(), is(1));
        assertThat(eventResultSets.getTransformedResultSetsMap().get(1).get(1).get("UBS_MF_GL"), is("123456"));
    }

    private AccountEventResultSetWriter.AccountEventResultSets getAccountEventResultSets() {

        AccountEventResultSetWriter.AccountEventResultSets accountEventResultSets = new AccountEventResultSetWriter.AccountEventResultSets();

        Map<Integer, Map<Integer, Map<String, String>>> resultSetsMaps = new HashMap<>();
        Map<Integer, Map<String, String>> resultSetsMap = new HashMap<>();
        Map<String, String> eventMap = new HashMap<>();
        eventMap.put("cconsol", "123456");
        resultSetsMap.put(1, eventMap);
        resultSetsMaps.put(1, resultSetsMap);
        accountEventResultSets.setResultSetsMap(resultSetsMaps);
        HashMap<String, Object> mappedEvent = new HashMap<>();
        mappedEvent.put(DOWNSTREAM_SP_ID, "79");
        accountEventResultSets.setMappedEvent(mappedEvent);
        return accountEventResultSets;
    }
}
