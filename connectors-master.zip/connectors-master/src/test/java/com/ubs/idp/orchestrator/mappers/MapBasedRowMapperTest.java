package com.ubs.idp.orchestrator.mappers;

import com.ubs.idp.orchestrator.mappers.MapBasedRowMapper;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import java.sql.*;
import java.util.*;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isA;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

public class MapBasedRowMapperTest {
	@InjectMocks
	private MapBasedRowMapper mapBasedRowMapper;
	@Mock
	ResultSet resultSet;
	private Timestamp timestamp = new Timestamp(System.currentTimeMillis()); 

	@Before
	public void setUp() throws SQLException {
		mapBasedRowMapper = new MapBasedRowMapper();
		MockitoAnnotations.initMocks(this);
		mapBasedRowMapper.setColumnsAndTypes(getColumnsAndTypes());
		when(resultSet.getString(anyString())).thenReturn("Output");
		when(resultSet.getLong(anyString())).thenReturn(1l);
		when(resultSet.getInt(anyString())).thenReturn(1);
		when(resultSet.getTimestamp(anyString())).thenReturn(timestamp);
	}

	private Map<String, String> getColumnsAndTypes() {
		Map<String, String> columnsAndTypes = new HashMap<>();
		columnsAndTypes.put(EVENT_ID, "NUMBER");
		columnsAndTypes.put(EVENT_ACCOUNT_ID, "VARCHAR2");
		columnsAndTypes.put("cconsol", "int");
		columnsAndTypes.put("cpropagation", "tinyint");
		columnsAndTypes.put("dlast", "datetime");
		columnsAndTypes.put("cmode", "char");
		return columnsAndTypes;
	}

	@Test
	public void should_map_number_columns() throws Exception {
		Map<String, Object> mappedAttributes = mapBasedRowMapper.mapRow(
				resultSet, 1);
		assertThat("Should map attributes", mappedAttributes.size(), is(6));
		assertThat((Long) mappedAttributes.get(EVENT_ID), is(1l));
		assertThat((Integer) mappedAttributes.get("cconsol"), is(1));
	}

	@Test
	public void should_map_Date_columns() throws Exception {
		Map<String, Object> mappedAttributes = mapBasedRowMapper.mapRow(
				resultSet, 1);
		assertThat("Should map attributes", mappedAttributes.size(), is(6));
		assertThat((Timestamp) mappedAttributes.get("dlast"),
				isA(Timestamp.class));
	}

	@Test
	public void should_map_varchar_columns() throws Exception {
		Map<String, Object> mappedAttributes = mapBasedRowMapper.mapRow(
				resultSet, 1);
		assertThat("Should map attributes", mappedAttributes.size(), is(6));
		assertThat((String) mappedAttributes.get(EVENT_ACCOUNT_ID),
				is("Output"));
		assertThat((String) mappedAttributes.get("cmode"), is("Output"));
	}
}