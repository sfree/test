package com.ubs.idp.orchestrator.util;

import com.ubs.idp.metadata.client.MetadataService;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jms.core.JmsTemplate;

import java.util.*;

import static junit.framework.Assert.assertNotNull;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;

public class MetaDataRetrieverUtilTest {

    @InjectMocks private MetaDataRetrieverUtil metaDataRetrieverUtil;
    @Mock private MetadataService mds;
    @Mock JmsTemplate jmsTemplate;

    @Before public void setUp() throws Exception{
        metaDataRetrieverUtil = new MetaDataRetrieverUtil();
        MockitoAnnotations.initMocks(this);
        metaDataRetrieverUtil.setJmsChannels(getJmsChannels());
        //metaDataRetrieverUtil.setServiceImplementations(Collections.singletonList("ServiceImplementation79"));
        when(mds.getDataSetFilterAttributes(anyString())).thenReturn(getFilterAttributes());
        when(mds.getChannelWithViewId(anyString())).thenReturn("bps");
    }

    private HashMap<String, JmsTemplate> getJmsChannels() {
        HashMap<String, JmsTemplate> templateHashMap = new HashMap<>();
        templateHashMap.put("bps", jmsTemplate);
        return templateHashMap;
    }

    @Test
    public void testGetPropCodes() throws Exception {

        List<Integer> serviceCodes = metaDataRetrieverUtil.getPropCodes();
        assertThat("Total prop codes ", serviceCodes.size(), is(2));
        assertThat("Prop code for ADP 79 Service: ", serviceCodes.get(0), is(79));
        assertThat("Prop code for ADP 80 Service: ", serviceCodes.get(1), is(80));
    }

    @Test
    public void testGetRetryCount() throws Exception {

        Integer retryCount = metaDataRetrieverUtil.getRetryCount("79");
        assertThat("Retry count of prop code 79: ", retryCount, is(5));
        retryCount = metaDataRetrieverUtil.getRetryCount("80");
        assertThat("Retry count of prop code 80: ", retryCount, is(8));
    }

    @Test
     public void should_return_bps_jmsTemplate() {

        JmsTemplate jmsTemplateForView = metaDataRetrieverUtil.getJmsTemplateForView(anyString());
        assertNotNull(jmsTemplateForView);
    }

    List<Map<String, String>> getFilterAttributes() {

        List<Map<String, String>> list = new ArrayList<>();
        list.add(getAttributeMap("79", "5"));
        list.add(getAttributeMap("80", "8"));
        return list;
    }

    private Map<String, String> getAttributeMap(String serviceCode, String retryCount) {

        Map<String, String> maps = new HashMap<>();
        maps.put("propCode", serviceCode);
        maps.put("maxRetryCount", retryCount);
        return maps;
    }
}
