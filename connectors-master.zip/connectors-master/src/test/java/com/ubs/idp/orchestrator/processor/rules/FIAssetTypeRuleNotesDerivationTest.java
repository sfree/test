package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;
import com.ubs.idp.orchestrator.processor.rules.FIAssetTypeRule;

/**
 * Tests for the Fixed Income Asset Type derivation rules for Notes derivation
 * If cfi 7th char is G 
 * and Bloomberg Collateral Type match ("MORTGAGE*BACKED|"ASSET*BACKED) 
 * and ( bbTicker one of BTNS,THA,DBSB,FSDB,CCTS or issuerContry is US and month difference between issueDate and maturityDate is greater than 12 but less then 120 month (1 - 10 year) 
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Fixed Income Asset Type definition section)
 * @author haniffsy
 */
public class FIAssetTypeRuleNotesDerivationTest {

	private FIAssetTypeRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new FIAssetTypeRule();
		inputFields = new HashMap<String,Object>();
	}
	
	// Notes
	
	
	// CFI(7) == G AND bbgCollateralType MATCHES MORTGAGE*BACKED AND ticker IN [...]
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeMatchesNotMortgageBackedAndTickerBTNS() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BTNS");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Notes",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeMatchesNotMortgageBackedAndTickerTHA() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "THA");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Notes",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeMatchesNotMortgageBackedAndTickerDBSB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "DBSB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Notes",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeMatchesNotMortgageBackedAndTickerFSDB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FSDB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Notes",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeMatchesNotMortgageBackedAndTickerCCTS() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "CCTS");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Notes",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	

	
	// CFI(7) == G AND bbgCollateralType MATCHES ASSET*BACKED AND ticker IN [...]
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerBTNS() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "BTNS");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Notes",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerTHA() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "THA");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Notes",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerDBSB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "DBSB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Notes",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerFSDB() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FSDB");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Notes",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndTickerCCTS() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "CCTS");
		
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Notes",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	// IF CFI(7) == G AND bbgCollateralType MATCH MORTGAGE*BACKED AND issuerCountry == US AND maturity - issue > 12 months and < 120 months

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeMatchesNotMortgageBackedAndIssueToMaturityLess12Mo() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.ISSUE_DATE, "20130410");
		inputFields.put(DerivationRuleTemplate.MATURITY_DATE, "20140910");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Notes",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldNotDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesMortgageBackedAndIssueToMaturityMore12Mo() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.ISSUE_DATE, "20130410");
		inputFields.put(DerivationRuleTemplate.MATURITY_DATE, "20130510");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertFalse("Notes".equals(results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE)));
	}		

	
	// IF CFI(7) == G AND bbgCollateralType MATCH MORTGAGE*BACKED AND issuerCountry == US AND maturity - issue > 12 months and < 120 months

	@Test
	public void shouldDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndIssueToMaturityLess12Mo() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.ISSUE_DATE, "20130410");
		inputFields.put(DerivationRuleTemplate.MATURITY_DATE, "20140910");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Notes",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	
	
	@Test
	public void shouldNotDeriveBillsIfCFI7IsGAndCollateralTypeNotMatchesAssetBackedAndIssueToMaturityMore12Mo() {
		inputFields.put(DerivationRuleTemplate.UBS_CFI_CODE, "XXXXXXGX");
		inputFields.put(DerivationRuleTemplate.COLLATERAL_TYPE, "BLAH BLAH BACKED BLAH");
		inputFields.put(DerivationRuleTemplate.ISSUE_DATE, "20130410");
		inputFields.put(DerivationRuleTemplate.MATURITY_DATE, "20130510");
		inputFields.put(DerivationRuleTemplate.ISSUER_COUNTRY, "US");
		
		Map<String,Object> results = rule.derive(inputFields);

		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertFalse("Notes".equals(results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE)));
	}
	
}
