package com.ubs.idp.orchestrator.processor;

import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.file.transform.DefaultFieldSet;
import org.springframework.batch.item.file.transform.FieldSet;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.springframework.test.util.MatcherAssertionErrors.assertThat;

public class FieldSetToKeyValueProcessorTest {


    private FieldSetToKeyValueProcessor fieldSetToKeyValueProcessor;
    private FieldSet rawFieldSet;

    @Before
    public void setUp() throws Exception {
        fieldSetToKeyValueProcessor = new FieldSetToKeyValueProcessor();
        fieldSetToKeyValueProcessor.setDatasetName("bondprice");
        fieldSetToKeyValueProcessor.setKeyField("instr_id");

        rawFieldSet = new DefaultFieldSet(new String[]{"10414997", "BOND", "USD", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "97.261131", "", "2014-03-13 22:49:08", "ETL_BATCH", "", "", "", "", "", "", "", "", "", "", "EJV", "", "", "2014-03-13 00:00:00", "PGMD", "", "", "PSRD", "PTEU", "", "", "", "", "", "", "", "", "2014-03-13 22:49:08", "ETL_BATCH", "", ".964539", "", "", "", ".964539", ".964539", "", "", "", "", "USEC", "0", "2003-04-14 13:13:04", "2003-04-14 13:13:04"},
                new String[]{"instr_id", "instr_type", "instr_ccy", "accrued", "accrued_days", "asm", "asm_curve_id", "assumed_inflation", "bpv", "break_even_actual", "break_even_instr_id", "break_even_simple", "brk_even_num_a", "brk_even_num_b", "brk_even_spread_a", "brk_even_spread_b", "brk_even_unit_a", "brk_even_unit_b", "calc_updated", "calc_updated_user", "clean_price", "convexity", "created", "created_user", "dirty_price", "discount_margin", "gamma", "index_ratio", "isprd", "isprd_curve_id", "mcduration", "mod_duration", "oas", "oas_curve_id", "original_price_srce", "priced_to", "priced_to_date", "price_date", "price_grp", "price_rolled", "price_rolled_date", "price_srce", "price_type", "principal_return", "quote_ind", "real_nominal", "settlement_date", "sprd", "sprd_curve_id", "sprd_instr_id", "total_return", "updated", "updated_user", "vdr_price_qual", "yield", "yield_freq_num", "yield_freq_unit", "yield_tax_basis", "yield_to_call", "yield_to_maturity", "yield_to_put", "yvo1", "zsprd", "zsprd_curve_id", "seniority_type", "amt_outstand", "amt_outstand_created", "amt_outstand_updated"});


    }

    @Test
    public void testProcess() throws Exception {
        FieldSet outputFieldSet = fieldSetToKeyValueProcessor.process(rawFieldSet);

        assertThat(outputFieldSet, is(notNullValue()));
        assertThat(outputFieldSet.readString("key"), is(notNullValue()));
        assertThat(outputFieldSet.readString("column1"), is(notNullValue()));
        assertThat(outputFieldSet.readString("value"), is(notNullValue()));
    }

}
