package com.ubs.idp.orchestrator.mappers;

import static org.junit.Assert.assertEquals;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class SubsetLineMapperTest
{
	private SubSetLineMapper lineMapper = new SubSetLineMapper();
	
	@Rule
	public ExpectedException expectedException = ExpectedException.none();
	
	@Test
	public void shouldProduceSubset() throws Exception
	{
		lineMapper.setSupersetAttributeNames(new String[]{"A","B","C"});
		lineMapper.setSubsetAttributeNames(new String[]{"A","B"});
		lineMapper.setDelimiter(",");		
		String line = "1,2,3";		
		assertEquals("Mapper failed","1,2",lineMapper.mapLine(line, 1));

		lineMapper.setSubsetAttributeNames(new String[]{"B","C"});
		assertEquals("Mapper failed","2,3",lineMapper.mapLine(line, 1));

		lineMapper.setSubsetAttributeNames(new String[]{"A","C"});
		assertEquals("Mapper failed","1,3",lineMapper.mapLine(line, 1));

		lineMapper.setSubsetAttributeNames(new String[]{"A"});
		assertEquals("Mapper failed","1",lineMapper.mapLine(line, 1));

		lineMapper.setSubsetAttributeNames(new String[]{"C"});
		assertEquals("Mapper failed","3",lineMapper.mapLine(line, 1));

	}

	@Test
	public void shouldPassthrough() throws Exception
	{
		lineMapper.setSupersetAttributeNames(new String[]{"A","B","C"});
		lineMapper.setSubsetAttributeNames(new String[]{"A","B","C"});
		lineMapper.setDelimiter(",");		
		String line = "1,2,3";		
		assertEquals("Mapper failed","1,2,3",lineMapper.mapLine(line, 1));
	}

	@Test
	public void shouldThrowException() throws Exception
	{
		lineMapper.setSupersetAttributeNames(new String[]{"A","B","C"});
		lineMapper.setSubsetAttributeNames(new String[]{"A","B","D"});
		lineMapper.setDelimiter(",");		
		String line = "1,2,3";
		
		expectedException.expect(RuntimeException.class);
		expectedException.expectMessage("The attribute name 'D' does not exist in the passed in line '1,2,3' with attributes '[A, B, C]'");
		
		lineMapper.mapLine(line, 1);
	}

}
