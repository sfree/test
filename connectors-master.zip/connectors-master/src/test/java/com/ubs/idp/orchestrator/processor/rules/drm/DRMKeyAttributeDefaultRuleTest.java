package com.ubs.idp.orchestrator.processor.rules.drm;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class DRMKeyAttributeDefaultRuleTest {

    private DRMKeyAttributeDefaultRule rule;

    @Before
    public void setUp() throws Exception {
        rule = new DRMKeyAttributeDefaultRule();
    }

    @Test
    public void shouldNotChangeAnything() throws Exception {
        Map<String, Object> result = rule.process(InputBuilder.newInput().withRatingType("SNPICR")
                .withRatingTerm("LT").withRatingCurrency("FOREIGN").build());
        assertEquals("SNPICR", result.get("RATING_TYPE"));
        assertEquals("LT", result.get("RATING_TERM"));
        assertEquals("FOREIGN", result.get("RATING_CURRENCY"));
    }

    @Test
    public void shouldDeriveEmptyToNA() throws Exception {
        Map<String, Object> result = rule.process(InputBuilder.newInput().withRatingType("")
                .withRatingTerm("").withRatingCurrency("").build());
        assertEquals("NA", result.get("RATING_TYPE"));
        assertEquals("NA", result.get("RATING_TERM"));
        assertEquals("NA", result.get("RATING_CURRENCY"));
    }

    @Test
    public void shouldDeriveBlankToNA() throws Exception {
        Map<String, Object> result = rule.process(InputBuilder.newInput().withRatingType(" ")
                .withRatingTerm("  ").withRatingCurrency("   ").build());
        assertEquals("NA", result.get("RATING_TYPE"));
        assertEquals("NA", result.get("RATING_TERM"));
        assertEquals("NA", result.get("RATING_CURRENCY"));
    }

    @Test
    public void shouldDeriveNullToNA() throws Exception {
        Map<String, Object> result = rule.process(InputBuilder.newInput().withRatingType(null)
                .withRatingTerm(null).withRatingCurrency(null).build());
        assertEquals("NA", result.get("RATING_TYPE"));
        assertEquals("NA", result.get("RATING_TERM"));
        assertEquals("NA", result.get("RATING_CURRENCY"));
    }

    static class InputBuilder {

        private Map<String, Object> input = new HashMap<>();

        public static InputBuilder newInput() {
            return new InputBuilder();
        }

        public InputBuilder withRatingType(String ratingType) {
            input.put("RATING_TYPE", ratingType);
            return this;
        }

        public InputBuilder withRatingTerm(String ratingTerm) {
            input.put("RATING_TERM", ratingTerm);
            return this;
        }

        public InputBuilder withRatingCurrency(String ratingCurrency) {
            input.put("RATING_CURRENCY", ratingCurrency);
            return this;
        }

        public Map<String, Object> build() {
            return input;
        }
    }

}
