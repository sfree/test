package com.ubs.idp.orchestrator.processor.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;
import com.ubs.idp.orchestrator.processor.rules.FIAssetTypeRule;

/**
 * Tests for the Fixed Income Asset Type derivation rules
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Fixed Income Asset Type definition section)
 * @author haniffsy
 */
public class FIAssetTypeRuleFixedRatePassThroughDerivationTest {

	private FIAssetTypeRule rule;
	private Map<String,Object> inputFields;

	@Before
	public void setUp() throws Exception {
		rule = new FIAssetTypeRule();
		inputFields = new HashMap<String,Object>();
	}
	
	// Fixed Rate Pass Throughs
	
	/*
	 * If asset type is one of ABS, MBS or Agency 
	 * and bloomber ticker is one of GN, FN, FG 
	 */
	
	@Test
	public void shouldDeriveFixedRatePassThroughsIfAssetTypeABSAndBBTickerGN() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "ABS");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "GN");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Fixed Rate Pass Throughs",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveFixedRatePassThroughsIfAssetTypeABSAndBBTickerFN() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "ABS");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FN");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Fixed Rate Pass Throughs",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveFixedRatePassThroughsIfAssetTypeABSAndBBTickerFG() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "ABS");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FG");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Fixed Rate Pass Throughs",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}

	
	@Test
	public void shouldDeriveFixedRatePassThroughsIfAssetTypeMBSAndBBTickerGN() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "MBS");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "GN");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Fixed Rate Pass Throughs",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveFixedRatePassThroughsIfAssetTypeMBSAndBBTickerFN() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "MBS");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FN");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Fixed Rate Pass Throughs",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveFixedRatePassThroughsIfAssetTypeMBSAndBBTickerFG() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "MBS");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FG");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Fixed Rate Pass Throughs",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}	

	
	@Test
	public void shouldDeriveFixedRatePassThroughsIfAssetTypeAgencyAndBBTickerGN() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Agency");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "GN");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Fixed Rate Pass Throughs",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveFixedRatePassThroughsIfAssetTypeAgencyAndBBTickerFN() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Agency");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FN");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Fixed Rate Pass Throughs",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
	@Test
	public void shouldDeriveFixedRatePassThroughsIfAssetTypeAgencyAndBBTickerFG() {
		inputFields.put(DerivationRuleTemplate.DERIVED_ASSET_TYPE, "Agency");
		inputFields.put(DerivationRuleTemplate.BLOOMBERG_TICKER, "FG");
		Map<String,Object> results = rule.derive(inputFields);
		
		assertTrue(results.containsKey(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
		assertEquals("Fixed Rate Pass Throughs",results.get(DerivationRuleTemplate.DERIVED_FI_ASSET_TYPE));
	}
	
}
