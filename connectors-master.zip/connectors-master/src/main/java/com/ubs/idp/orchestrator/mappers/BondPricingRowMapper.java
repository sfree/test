package com.ubs.idp.orchestrator.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class BondPricingRowMapper implements RowMapper<String> {

	private static final String DELIMITER = ",";
	
	@Override
	public String mapRow(ResultSet result, int arg1) throws SQLException {
		
		StringBuilder buffer = null;
		String temp =  null;
				
		temp = null;
		buffer = new StringBuilder();					
				
		temp = result.getString("INSTR_ID");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("INSTR_TYPE");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
					
		temp = result.getString("INSTR_CCY");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
						
		temp = result.getString("ACCRUED");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("ACCRUED_DAYS");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
						
		temp = result.getString("ASM");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("ASM_CURVE_ID");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("ASSUMED_INFLATION");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("BPV");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("BREAK_EVEN_ACTUAL");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("BREAK_EVEN_INSTR_ID");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("BREAK_EVEN_SIMPLE");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("BRK_EVEN_NUM_A");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("BRK_EVEN_NUM_B");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("BRK_EVEN_UNIT_A");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("BRK_EVEN_UNIT_B");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("CALC_UPDATED");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("CALC_UPDATED_USER");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("CLEAN_PRICE");
		temp = (temp != null) ? temp + DELIMITER : DELIMITER;
		buffer.append(temp);
				
		temp = result.getString("CONVEXITY");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("CREATED");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("CREATED_USER");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("DIRTY_PRICE");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("DISCOUNT_MARGIN");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("GAMMA");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("INDEX_RATIO");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("ISPRD");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("ISPRD_CURVE_ID");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("MCDURATION");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("MOD_DURATION");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("OAS");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("OAS_CURVE_ID");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("ORIGINAL_PRICE_SRCE");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("PRICED_TO");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("PRICED_TO_DATE");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("PRICE_DATE");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("PRICE_GRP");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("PRICE_ROLLED");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("PRICE_ROLLED_DATE");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("PRICE_SRCE");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("PRICE_TYPE");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("PRINCIPAL_RETURN");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("QUOTE_IND");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("REAL_NOMINAL");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("SETTLEMENT_DATE");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("SPRD");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("SPRD_CURVE_ID");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("SPRD_INSTR_ID");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("TOTAL_RETURN");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("UPDATED");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("UPDATED_USER");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("VDR_PRICE_QUAL");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("YIELD");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("YIELD_FREQ_NUM");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("YIELD_FREQ_UNIT");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("YIELD_TAX_BASIS");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("YIELD_TO_CALL");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("YIELD_TO_MATURITY");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("YIELD_TO_PUT");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("YVO1");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("ZSPRD");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("ZSPRD_CURVE_ID");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("SENIORITY_TYPE");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("AMT_OUTSTAND");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("AMT_OUTSTAND_CREATED");
				temp = (temp != null) ? temp + DELIMITER : DELIMITER;
				buffer.append(temp);
				
				temp = result.getString("AMT_OUTSTAND_UPDATED");
				if(temp != null){ 
					buffer.append(temp);
				}
				
				return buffer.toString();
		}

}
