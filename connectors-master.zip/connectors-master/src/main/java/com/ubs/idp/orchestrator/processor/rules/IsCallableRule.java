package com.ubs.idp.orchestrator.processor.rules;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.batch.item.ItemProcessor;

public class IsCallableRule extends DerivationRuleTemplate implements
		ItemProcessor<Map<String, Object>, Map<String, Object>> {

	static final List<String> CALLABLE_CALL_TYPES = Arrays.asList("CALLABLE", "INWHOLE", "PARTIAL",
			"FULL");

	static final String YES_DERIVED = "Y";

	static final String NO_DERIVED = "N";

	@Override
	public Map<String, Object> process(Map<String, Object> item) throws Exception {
		return derive(item);
	}

	@Override
	public Map<String, Object> applyRules(Map<String, Object> inputFields) {
		Map<String, Object> derivedFields = new HashMap<String, Object>();

		String callType = getMappedInputField(CALL_TYPE, inputFields);

		if (CALLABLE_CALL_TYPES.contains(callType)) {
			derivedFields.put(DERIVED_IS_CALLABLE, YES_DERIVED);
		} else {
			derivedFields.put(DERIVED_IS_CALLABLE, NO_DERIVED);
		}

		return derivedFields;
	}

}
