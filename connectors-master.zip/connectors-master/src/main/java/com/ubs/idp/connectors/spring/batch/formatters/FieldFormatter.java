package com.ubs.idp.connectors.spring.batch.formatters;

public interface FieldFormatter {
    public String formatField(Object valueIn);
}
