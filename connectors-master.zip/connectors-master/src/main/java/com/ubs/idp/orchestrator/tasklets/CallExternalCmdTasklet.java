package com.ubs.idp.orchestrator.tasklets;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

/**
 * Tasklet that calls an external command on the file system. Note this should
 * be used to call scripts rather than os system commands directly. To execute
 * system commands then wrap them in a script file.
 * 
 * By naming the scripts:
 * 
 * myScript (unix)
 * myScript.bat (windows)
 * 
 * We can specify "myScript" in config and the tasklet will work out what 
 * os it is on and append .bat if necessary. This way we can transparently test
 * script calling on both unix and windows 
 * 
 * @author loverids
 */
public class CallExternalCmdTasklet implements Tasklet, InitializingBean {

    private String command = null;
    private File workingDir = null;
    private String[] envVariables = null;
    private List<Object> commandArgs = new ArrayList<Object>();
    
    private Logger logger = LoggerFactory.getLogger(getClass());
    
    /* (non-Javadoc)
     * @see org.springframework.batch.core.step.tasklet.Tasklet#execute(org.springframework.batch.core.StepContribution, org.springframework.batch.core.scope.context.ChunkContext)
     */
    @Override
    public RepeatStatus execute(StepContribution contribution,
            ChunkContext chunkContext) throws Exception {

    	Process proc  = null;
		List<String> commandArray = new ArrayList<String>();
		
        Assert.notNull(command, "External command must be set");
		
		commandArray.add(command);
		for( Object commandArg : commandArgs )
		{
			commandArray.add( commandArg.toString() );
		}
		
		
		logger.info("Calling external command {} with the following arguments {} ", command, commandArgs);
		if( envVariables != null )
		{
			logger.info("Overriding environment proeprties with {} ", Arrays.asList(envVariables));
		}
		if( workingDir != null )
		{
			logger.info("Working directory is {} ", workingDir);
		}

		fixCommandForBatchFiles(commandArray);
		
		if( workingDir == null && envVariables == null)
		{
			proc = Runtime.getRuntime().exec(commandArray.toArray(new String[]{}));
		}
		else if( workingDir == null )
		{
			proc = Runtime.getRuntime().exec(commandArray.toArray(new String[]{}),envVariables);
		}
		else
		{
			proc = Runtime.getRuntime().exec(commandArray.toArray(new String[]{}),envVariables,workingDir);
		}
		
		try(BufferedReader br = new BufferedReader( new InputStreamReader( proc.getErrorStream() ) );)
		{			
			int exitCode = proc.waitFor();	
			logger.info("External command process returned exit code {}", exitCode);
			if( exitCode != 0 )
			{
				String errorMessage = "";
				String line = "";
				while( (line = br.readLine()) != null )
				{
					errorMessage += line;
				}
				
				throw new RuntimeException("The external command process returned an unexpected exit code of " + exitCode + ". Reason: " + errorMessage );

			}
		}
		catch (InterruptedException e)
		{
			throw new RuntimeException("The external command process was interrupted before it could finish: " + e,e );
		}
    	
    	return RepeatStatus.FINISHED;
    }


    /**
     * Checks the first command in the array to see if the command exists.
     * If not it appends ".bat" and checks if that exists. If so then the command
     * will be modified to append ".bat" to it.
     * 
     * This allows us to specify a single command for both unix and windows but
     * differentiate by having ".bat" on the end for windows. 
     * 
     * @param commandArray
     */
    private void fixCommandForBatchFiles(List<String> commandArray)
    {
		// Are we on Windows
		if( System.getProperty("os.name").toLowerCase().contains("windows") )
		{
			String command = commandArray.get(0);
			if( new File(command +".bat").exists()  )
			{
				commandArray.set(0, command + ".bat");
			}
		}
    	
    }

    /* (non-Javadoc)
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(command, "External command must be set");
        
        /*
         * To allow us to dynamically add variable length command line attributes
         * we check if any of the argument objects is an array and if so explands
         * it into the commandArgList
         */
        for( int i = 0; i < commandArgs.size(); i ++ )
        {
        	Object arg = commandArgs.get(i);
        	if( arg instanceof List )
        	{
        		commandArgs.remove(i);
        		List<Object> newArgs = (List<Object>)arg;
        		for( int j = newArgs.size()-1; j >=0; j -- )
        		{
        			Object newArg = newArgs.get(j);
        			commandArgs.add(i, newArg);
        		}
        		i += newArgs.size();
        	}
        }
    }



	public String getCommand()
	{
		return command;
	}



	public void setCommand(String command)
	{
		this.command = command;
	}



	public File getWorkingDir()
	{
		return workingDir;
	}



	public void setWorkingDir(File workingDir)
	{
		this.workingDir = workingDir;
	}



	public String[] getEnvVariables()
	{
		return envVariables;
	}



	public void setEnvVariables(String[] envVariables)
	{
		this.envVariables = envVariables;
	}



	public List<Object> getCommandArgs()
	{
		return commandArgs;
	}



	public void setCommandArgs(List<Object> commandArgs)
	{
		this.commandArgs = commandArgs;
	}
    
	public void addCommandArgs(List<Object> commandArgs)
	{
		this.commandArgs.addAll( commandArgs );
	}
    
	/**
	 * Allows you to append command arguments as a CSV string
	 * @param csvCommands
	 */
	public void addCommandArgsAsCSV(String csvCommandArgs )
	{
		this.commandArgs.addAll( Arrays.asList( csvCommandArgs.split(",") ) );
	}
    
}
