package com.ubs.idp.orchestrator.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.transform.FieldSet;

public class SplitProcessor implements ItemProcessor<FieldSet, FieldSet>{

    private String splitField;

    @Override
    public FieldSet process(FieldSet item) throws Exception {
        String str = item.readString(splitField);
        return item;
    }

    public void setSplitField(String splitField) {
        this.splitField =splitField;
    }
}
