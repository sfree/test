package com.ubs.idp.orchestrator.tasklets;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.ubs.idp.orchestrator.util.AccountEventConstants;

/**
 * Tasklet that checks for bulk events in a database
 * If records are found, events are de-prioritized
 * 
 */

public class JdbcEventManagerTasklet implements Tasklet, InitializingBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(JdbcEventManagerTasklet.class);
	private NamedParameterJdbcTemplate jdbcTemplate;
	private DataSource dataSource;
	private String findBulkUpdateQuery;
	private String deprioritizeQuery;
	private String csvStreams;
	private String snapshotMinutes;
	private int minutes;
	private List<String> streamsWhiteList;
	private Map<String, List<BigDecimal>> streamMinutesMap;
	private Calendar utcCalendar;
	
	public void init() {
		LOGGER.info("Running the event manager with snapshot of {} minutes", minutes);
		jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
		minutes = minutes * -1;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		LOGGER.debug("Running the event manager with snapshot of {} minutes", minutes);
		TimeZone timeZone = TimeZone.getTimeZone("UTC");
		utcCalendar = Calendar.getInstance(timeZone);
		utcCalendar.add(Calendar.MINUTE, minutes);
		
		MapSqlParameterSource params = getSelectParams();
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(findBulkUpdateQuery, params);

		streamMinutesMap = new HashMap<String, List<BigDecimal>>();
		if (!rows.isEmpty()) {
			for (int i = 0; i < rows.size(); i++) {
				Map<String, Object> mappedRow = rows.get(i);
				String stream = (String) mappedRow.get(AccountEventConstants.STREAM);
				BigDecimal minute = (BigDecimal) mappedRow.get(AccountEventConstants.MINUTE);
				if (streamsWhiteList.contains(stream)) {
					if (streamMinutesMap.containsKey(stream)) {
						streamMinutesMap.get(stream).add(minute);
					}
					else {
						List<BigDecimal> list = new ArrayList<BigDecimal>();
						list.add(minute);
						streamMinutesMap.put(stream, list);
					}
				}
				else {
					LOGGER.warn("Found bulk updates for stream {} but job is not configured to de-prioritize", stream);
				}
			}
		}

		if (!streamMinutesMap.isEmpty()) {
			Set<String> keys = streamMinutesMap.keySet();
			Iterator<String> iterator = keys.iterator();
			String updateKey = "";
			while (iterator.hasNext()) {
				updateKey = iterator.next();
				LOGGER.info("Found bulk updates for stream: {}", updateKey);

				params = getUpdateParams(updateKey, streamMinutesMap.get(updateKey));
				int numRowsUpdated = jdbcTemplate.update(deprioritizeQuery, params);

				LOGGER.info("De-prioritized {} events for {} stream", numRowsUpdated, updateKey);
			}
			LOGGER.info("Event Manager completed. Bulk updates found");
		}
		else {
			LOGGER.info("Event Manager completed. No bulk updates found");
		}

		return RepeatStatus.FINISHED;
	}

	public MapSqlParameterSource getSelectParams() {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("timestamp", utcCalendar, Types.TIMESTAMP);
		return params;
	}

	public MapSqlParameterSource getUpdateParams(String streamName, List<BigDecimal> minutes) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("streamName", streamName, Types.VARCHAR);
		params.addValue("minuteSlices", minutes, Types.INTEGER);
		params.addValue("timestamp", utcCalendar, Types.TIMESTAMP);
		return params;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(findBulkUpdateQuery, "External command must be set");
		Assert.notNull(deprioritizeQuery, "External command must be set");
		Assert.notNull(csvStreams, "Consumers must be set");

		// put the streams in a list
		LOGGER.debug("Starting event manager with streams: {}", csvStreams);
		streamsWhiteList = new ArrayList<String>();
		String[] consumers = csvStreams.split(",");
		for (int i = 0; i < consumers.length; i++) {
			streamsWhiteList.add(consumers[i].trim());
		}

		// set how far back in minutes to look for events
		try {
			minutes = Integer.parseInt(snapshotMinutes);
		}
		catch (Exception ex) {
			LOGGER.warn("Error getting the set snapshot minutes value. Using Default of 30 minutes");
			minutes = 30;
		}
	}
	
	public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }
	
	public void setJdbcTemplate(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

	public void setFindBulkUpdateQuery(String findBulkUpdateQuery) {
		this.findBulkUpdateQuery = findBulkUpdateQuery;
	}

	public void setDeprioritizeQuery(String deprioritizeQuery) {
		this.deprioritizeQuery = deprioritizeQuery;
	}

	public void setStreamsWhiteList(List<String> streamsWhiteList) {
		this.streamsWhiteList = streamsWhiteList;
	}

	public void setCsvStreams(String csvStreams) {
		this.csvStreams = csvStreams;
	}

	public void setSnapshotMinutes(String snapshotMinutes) {
		this.snapshotMinutes = snapshotMinutes;
	}
}
