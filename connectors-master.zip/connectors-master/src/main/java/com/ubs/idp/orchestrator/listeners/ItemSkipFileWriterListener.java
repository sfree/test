package com.ubs.idp.orchestrator.listeners;

import java.io.File;
import java.io.PrintWriter;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.SkipListener;

public class ItemSkipFileWriterListener implements SkipListener {

    public static final String DEFAULT_MAPPING = "default";

    private Map<String, String> exceptionFileMap;

    private Logger logger = LoggerFactory.getLogger(ItemSkipFileWriterListener.class);

    @Override
    public void onSkipInRead(Throwable t) {
        logger.error(t.getLocalizedMessage());
    }

    @Override
    public void onSkipInWrite(Object item, Throwable t) {
        logger.error(t.getLocalizedMessage());

        String exceptionName = t.getClass().getName();
        String fileName;

        if (exceptionFileMap != null && exceptionFileMap.containsKey(exceptionName)) {
            fileName = exceptionFileMap.get(exceptionName);
        } else if (exceptionFileMap != null && exceptionFileMap.containsKey(DEFAULT_MAPPING)) {
            fileName = exceptionFileMap.get(DEFAULT_MAPPING);
        } else {
            fileName = t.getClass().getSimpleName() + ".out";
        }

        PrintWriter writer = null;

        try {
            File outputFile = new File(fileName);
            
            File errorDir = outputFile.getParentFile();
            
            // IDP-400 - check for existence of parent dir and create if missing
            
            if (!errorDir.exists()) {
                if (!errorDir.mkdirs()) {
                    throw new Exception("Failed to create error log dir '" + errorDir.getAbsolutePath() + "'?");
                }
            }
            
            writer = new PrintWriter(outputFile);

            writer.println(item.toString());
        } catch (Exception e) {
            logger.error("Failed to write errored row data?", e);
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

    @Override
    public void onSkipInProcess(Object item, Throwable t) {
        logger.error(t.getLocalizedMessage());
    }

    /**
     * @param exceptionFileMap the exceptionFileMap to set
     */
    public void setExceptionFileMap(Map<String, String> exceptionFileMap) {
        this.exceptionFileMap = exceptionFileMap;
    }
}