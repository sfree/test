package com.ubs.idp.connectors.cassandra;

import static org.springframework.util.StringUtils.isEmpty;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.datastax.driver.core.AuthProvider;
import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.CloseFuture;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Cluster.Builder;
import com.datastax.driver.core.ColumnDefinitions;
import com.datastax.driver.core.ColumnDefinitions.Definition;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.DataType;
import com.datastax.driver.core.PlainTextAuthProvider;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.SimpleStatement;
import com.datastax.driver.core.Statement;

/**
 * This is a simple proxy to Cassandra that uses the CQL based API (rather than Hector)
 */
public class CassandraCqlProxyImpl implements CassandraCqlProxy {

    private static final int MAX_SHUTDOWN_RETRIES = 5;

    private static final Logger LOGGER = LoggerFactory.getLogger(CassandraCqlProxyImpl.class);

    private CassandraConfig cassandraConfig;

    private ConsistencyLevel defaultConsistencyLevel = null;
    private Session session;
    
    private Map<String, PreparedStatement> preparedStatementCache = new HashMap<String, PreparedStatement>();

    /**
     * Main constructor
     * @param cassandraConfig
     */
    public CassandraCqlProxyImpl(CassandraConfig cassandraConfig) {
        this.cassandraConfig = cassandraConfig;
    }

    /* (non-Javadoc)
     * @see com.ubs.idp.connectors.cassandra.CassandraCqlProxy#connect()
     */
    public boolean connect() {

        if (session != null) {
            LOGGER.debug("Already connected");
            return true;
        }

        boolean connected = true;

        try {
            Cluster cluster = null;
            Builder builder = null;

            // Check if username is supplied and use auth accordingly, assumes password is encrypted
            if (!isEmpty(cassandraConfig.getCassandraUser())) {
                AuthProvider authProvider = new PlainTextAuthProvider(cassandraConfig.getCassandraUser(), cassandraConfig.getDecryptedCassandraPassword());
                builder = Cluster.builder().withAuthProvider(authProvider);
            } else {
                builder = Cluster.builder();
            }

            // Allow for comma-separated list of nodes
            String hostAddresses[] = cassandraConfig.getCassandraHost().split(",");

            for(String address : hostAddresses) {
                address = address.trim();
                LOGGER.info("Adding contact endpoint {}", address);
                builder.addContactPoint(address);
            }

            cluster = builder.build();

            if (!isEmpty(cassandraConfig.getCassandraKeyspace())) {
                LOGGER.info("Connecting to Cassandra ({}) using keyspace '{}'...", cassandraConfig.getCassandraHost(), cassandraConfig.getCassandraKeyspace());
                String quotedKeySpace = "\"" + cassandraConfig.getCassandraKeyspace() + "\"";
                setSession(cluster.connect(quotedKeySpace));
            } else {
                LOGGER.debug("Connecting to Cassandra (no keyspace)...");
                setSession(cluster.connect());
            }

            // Set up default consistency level

            if (!isEmpty(cassandraConfig.getDefaultConsistencyLevel())) {
                defaultConsistencyLevel = ConsistencyLevel.valueOf(cassandraConfig.getDefaultConsistencyLevel());
            }

        } catch (Exception e) {
            // TODO: Should we catch and log ... or re-throw?
            LOGGER.error("Failed to connect to Cassandra?", e);
            connected = false;
        }
        return connected;
    }

    /* @deprecated
     * @see com.ubs.idp.connectors.cassandra.CassandraCqlProxy#shutdown
     */
    @Deprecated
    public void shutdown() {
        close();
    }

    /* (non-Javadoc)
     * @see com.ubs.idp.connectors.cassandra.CassandraCqlProxy#close()
     */
    public void close() {
        boolean interupted = false;
        int retry = 0;

        if (session != null) {
            LOGGER.info("Closing down Cassandra session...");

            CloseFuture res = session.closeAsync();

            while (!res.isDone() && !interupted && retry < MAX_SHUTDOWN_RETRIES) {
                LOGGER.info("Waiting on close complete....");
                try {
                    Thread.sleep(5000);
                    retry++;
                } catch (InterruptedException e) {
                    LOGGER.warn("close loop interupted");
                    interupted = true;
                }
            }

            session = null;

            LOGGER.info("Done....");
        }
    }
    
    /* (non-Javadoc)
     * @see com.ubs.idp.connectors.cassandra.CassandraCqlProxy#isConnected()
     */
    public boolean isConnected() {
        return !(null == session);
    }

    /* (non-Javadoc)
     * @see com.ubs.idp.connectors.cassandra.CassandraCqlProxy#executeStatement(java.lang.String)
     */
    public ResultSet executeStatement(String cqlStatement) {
        return executeStatement(cqlStatement, null);
    }

    /* (non-Javadoc)
     * @see com.ubs.idp.connectors.cassandra.CassandraCqlProxy#executeStatement(java.lang.String, com.datastax.driver.core.ConsistencyLevel)
     */
    public ResultSet executeStatement(String cqlStatement, ConsistencyLevel consistencyLevel) {
        if (null == cqlStatement) {
            throw new IllegalArgumentException("You need to provide a DDL or DML statement");
        }

        LOGGER.debug("Executing '{}'...", cqlStatement);

        // TODO: Move to bind variables...

        Statement statement = new SimpleStatement(cqlStatement);

        if (consistencyLevel != null) {
            statement.setConsistencyLevel(consistencyLevel);
        } else if (defaultConsistencyLevel != null) {
            statement.setConsistencyLevel(defaultConsistencyLevel);
        }

        return executeStatement(statement);
    }

    public ResultSet executeStatement(Statement statement) {
        if (null == statement) {
            throw new IllegalArgumentException("NULL statement supplied?");
        }

        LOGGER.debug("Executing prepared statement...");

        return session.execute(statement);
    }

    /* (non-Javadoc)
     * @see com.ubs.idp.connectors.cassandra.CassandraCqlProxy#executeQuery(java.lang.String)
     */
    public List<Map<String, Object>> executeQuery(final String cqlQuery) {
        if (null == cqlQuery) {
            throw new IllegalArgumentException("You need to provide a CQL query string");
        }

        LOGGER.debug("Executing '{}'...", cqlQuery);

        // Holds the rows in the order receive and a map of cell names and values
        List<Map<String, Object>> results = new ArrayList<Map<String, Object>>();

        ResultSet rs = session.execute(cqlQuery);
        List<Row> rows = rs.all();

        LOGGER.debug("Processing {} rows...", rows.size());

        // Loop over all rows
        for (Row row : rows) {
            Map<String, Object> columns = new LinkedHashMap<String, Object>(); // LHM to preserve order
            ColumnDefinitions colDefs = rs.getColumnDefinitions();
            List<Definition> defs = colDefs.asList();
            // work out the data type of the cell value and populate
            for (Definition d : defs) {
                String columnName = d.getName();
                if (DataType.varchar().equals(d.getType())) {
                    columns.put(columnName, row.getString(columnName));
                } else if (DataType.bigint().equals(d.getType())) {
                    columns.put(columnName, row.getLong(columnName));
                } else if (DataType.cint().equals(d.getType())) {
                    columns.put(columnName, row.getInt(columnName));
                } else if (DataType.timestamp().equals(d.getType())) {
                    columns.put(columnName, row.getDate(columnName));
                }
            }
            results.add(columns);
        }
        return results;
    }

    /**
     * @param session the session to set
     */
    private void setSession(Session session) {
        this.session = session;
    }

    /* (non-Javadoc)
     * @see com.ubs.idp.connectors.cassandra.CassandraCqlProxy#addColumnFamilyIfNeeded(java.lang.String)
     */
    public boolean addColumnFamilyIfNeeded(String columnFamilyName) {
        boolean newColumnFamily = false;
        String cqlQuery = "select columnfamily_name, keyspace_name, type from system.schema_columnfamilies where keyspace_name = '"
                + cassandraConfig.getCassandraKeyspace()
                + "' and columnfamily_name = '"
                + columnFamilyName
                + "'";

        LOGGER.debug("Check for/create column family '{}'...", columnFamilyName);

        ResultSet res1 = session.execute(cqlQuery);
        List<Row> rows = res1.all();

        if (rows.size() == 0) {
            String createTableCql = "CREATE TABLE \""
                    + columnFamilyName
                    + "\" ( key text, column1 text, value text, PRIMARY KEY (key, column1) ) WITH COMPACT STORAGE ;";

            LOGGER.debug("Execute table create CQL '{}'...", createTableCql);

            session.execute(createTableCql);
            newColumnFamily = true;
        }
        return newColumnFamily;
    }

    /* (non-Javadoc)
     * @see com.ubs.idp.connectors.cassandra.CassandraCqlProxy#addColumnFamilyIfNeeded(java.lang.String, java.lang.String)
     */
    @Override
    public boolean addColumnFamilyIfNeeded(String columnFamilyName,	String createTableCql) {

        boolean newColumnFamily = false;

        String cqlQuery = "select columnfamily_name, keyspace_name, type from system.schema_columnfamilies where keyspace_name = '"
                + cassandraConfig.getCassandraKeyspace()
                + "' and columnfamily_name = '"
                + columnFamilyName
                + "'";

        LOGGER.debug("Check for/create column family '{}'...", columnFamilyName);

        ResultSet res1 = session.execute(cqlQuery);
        List<Row> rows = res1.all();

        if (rows.size() == 0) {
            LOGGER.debug("Execute table create CQL '{}'...", createTableCql);
            session.execute(createTableCql);
            newColumnFamily = true;
        }

        return newColumnFamily;
    }

    /** This is generic method to return PreapreStatement Object for used with Batch insert
     * @param cql- a valid cql statement
     * @return
     */
    @Override
    public PreparedStatement getPrepareStatement(String cql) {
        PreparedStatement pstmt=null;
        
        // TODO - A short key may help...
        if (preparedStatementCache.containsKey(cql)) {
            pstmt = preparedStatementCache.get(cql);
        } else {
            pstmt= session.prepare(cql);
            
            preparedStatementCache.put(cql, pstmt);
        }
        
        return pstmt;

    }

    /**
     * Executes provided Batch statement in Cassandra store
     *
     * @param batchStatement
     * @return
     */
    @Override
    public ResultSet executeStatement(BatchStatement batchStatement) {

        return session.execute(batchStatement);
    }
}

