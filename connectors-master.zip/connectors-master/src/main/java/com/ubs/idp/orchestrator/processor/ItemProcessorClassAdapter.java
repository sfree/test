package com.ubs.idp.orchestrator.processor;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * @author clarkst
 * TODO refactor this to handle FieldSets rather than Strings
 */
public class ItemProcessorClassAdapter implements ItemProcessor<Map<String, Object>, Map<String, Object>>, ApplicationContextAware {
    private List<String> processorClassList;    
    private Map<String, Object> tempInputItem;
    private Map<String, Object> tempOutputItem;
    
    private Map<String, ItemProcessor> processorInstances = new HashMap<String, ItemProcessor>();
    
    /**
     * We keep an instance of the Spring context so that dynamic rule classes with autowiring
     * can be Spring registered
     */
    private ApplicationContext applicationContext;


    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        if(null== processorClassList || processorClassList.isEmpty()){
            return item;
        }
        else{
            tempOutputItem=item;
            for(String processorClassName: processorClassList ){

                ItemProcessor itemProcessor = getOrCreateItemProcessor(processorClassName);
                
                tempInputItem = tempOutputItem;
                tempOutputItem = (Map<String, Object>) itemProcessor.process(tempInputItem);
            }
            return tempOutputItem;
        }
    }
    
    private ItemProcessor getOrCreateItemProcessor(String processorClassName) throws Exception {
        
        if (processorInstances.containsKey(processorClassName)) {
            return processorInstances.get(processorClassName);
        }
        
        Class<?> itemProcessorClass = Class.forName(processorClassName);
        ItemProcessor itemProcessor = (ItemProcessor) itemProcessorClass.newInstance();

        // Register the bean for spring auotwiring
        
        applicationContext.getAutowireCapableBeanFactory().autowireBean(itemProcessor);
        
        // TODO: May be a neater (more Spring-like) way to do this
        initializeBean(itemProcessorClass, itemProcessor);
        
        // Cache
        
        processorInstances.put(processorClassName, itemProcessor);
        
        return itemProcessor;
    }

    private void initializeBean(Class<?> itemProcessorClass, ItemProcessor itemProcessor)
            throws Exception {
        if (itemProcessor instanceof InitializingBean) {
            ((InitializingBean) itemProcessor).afterPropertiesSet();
        } else {
            Set<Method> initMethods = org.springframework.batch.support.ReflectionUtils.findMethod(
                    itemProcessorClass, PostConstruct.class);
            Assert.isTrue(initMethods.size() <= 1,
                    "Only one method can be annotated with @PostConstruct");
            for (Method initMethod : initMethods) {
                ReflectionUtils.makeAccessible(initMethod);
                ReflectionUtils.invokeMethod(initMethod, itemProcessor);
            }
        }
    }

	public List<String> getProcessorClassList()
	{
		return processorClassList;
	}

	public void setProcessorClassList(List<String> processorClassList)
	{
		this.processorClassList = processorClassList;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException
	{
		this.applicationContext = applicationContext;
	}
}