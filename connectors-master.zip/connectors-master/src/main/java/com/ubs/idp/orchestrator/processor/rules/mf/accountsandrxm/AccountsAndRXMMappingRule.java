package com.ubs.idp.orchestrator.processor.rules.mf.accountsandrxm;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.item.ItemProcessor;

import com.ubs.idp.base.utils.TimeUtils;
import com.ubs.idp.orchestrator.processor.rules.DerivationRule;

/**
 * Simple rule to populate current date (UTC)
 * TODO: Clarify with Syed
 * @author mcminnp
 */
public class AccountsAndRXMMappingRule implements DerivationRule, ItemProcessor<Map<String,Object>,Map<String,Object>>
{

    public final static String TRANSACTION_DATE_DERIVED = "derived.transactionDate";
    public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
    public static final String TZ_UTC = "UTC";

    public static final String IDP_ACCOUNT_ID = "accId";
    public static final String IDP_CLIENT_CLASSIFICATION = "clientClassification";
	public static final String IDP_ACTIVE_FLAG = "activeFlag";
	public static final String IDP_COUNTERPARTY_TYPE = "counterpartyType";
	public static final String IDP_RXM_CODE = "rxmCode";
	public static final String IDP_RISK_ENTITY = "riskEntity";
	public static final String IDP_VALID_FROM = "validFrom";
	public static final String IDP_VALID_TO = "validTo";
	public static final String IDP_LEM_ID = "lemid";

    public static final String SRC_ACCOUNT_ID = "GLcconsol";
    public static final String SRC_CLIENT_CLASSIFICATION = "Class";
	public static final String SRC_ACTIVE_FLAG = "Factive";
	public static final String SRC_COUNTERPARTY_TYPE = "CPType";
	public static final String SRC_RXM_CODE = "RXM";
	public static final String SRC_RISK_ENTITY = "ReverseEntity";
	public static final String SRC_VALID_FROM = "ValidFrom";
	public static final String SRC_VALID_TO = "ValidTo";
	public static final String SRC_LEM_ID = "lemid";
	
	
    @Override
    public Map<String,Object> derive(Map<String, Object> inputFields)
    {
        Map<String,Object> derivedFields = new HashMap<String,Object>();

        String now = TimeUtils.nowPlusDelta(TZ_UTC, DATE_FORMAT, 0); 
        
        derivedFields.put(IDP_ACCOUNT_ID, inputFields.get(SRC_ACCOUNT_ID));
        derivedFields.put(IDP_CLIENT_CLASSIFICATION, inputFields.get(SRC_CLIENT_CLASSIFICATION));
        derivedFields.put(IDP_ACTIVE_FLAG, inputFields.get(SRC_ACTIVE_FLAG));
        derivedFields.put(IDP_COUNTERPARTY_TYPE, inputFields.get(SRC_COUNTERPARTY_TYPE));
        derivedFields.put(IDP_RXM_CODE, inputFields.get(SRC_RXM_CODE));
        derivedFields.put(IDP_RISK_ENTITY, inputFields.get(SRC_RISK_ENTITY));
        derivedFields.put(IDP_VALID_FROM, inputFields.get(SRC_VALID_FROM));
        derivedFields.put(IDP_VALID_TO, inputFields.get(SRC_VALID_TO));
        derivedFields.put(TRANSACTION_DATE_DERIVED, now);
        derivedFields.put(IDP_LEM_ID, inputFields.get(SRC_LEM_ID));

        return derivedFields;
    }

    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        return derive(item);
    }

}


