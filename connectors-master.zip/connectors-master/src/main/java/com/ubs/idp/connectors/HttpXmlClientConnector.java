package com.ubs.idp.connectors;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.support.GenericMessage;

import com.ubs.idp.base.IPayLoad;
import com.ubs.idp.base.XmlPayload;

/**
 * Single connector
 * @author haniffsy
 */
public class HttpXmlClientConnector extends BaseConnector implements Connector {

	public static final String OPERATION_GET_CURRENT = "GetCurrent";

	private static final Logger LOGGER = LoggerFactory.getLogger(HttpXmlClientConnector.class);

    private String url;

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @param url the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }

	/**
	 * @param input
	 * @return
	 */
	public GenericMessage<IPayLoad> execute(Object input) {

		Collection<IPayLoad> results = new ArrayList<IPayLoad>();

		if (url == null || url.length() == 0) {
			LOGGER.error("Error in DatingServiceClient:executeEndpoint reason No endPointSet for Web Service Request");
			throw new IllegalStateException(
					"No endPointSet for Web Service Request");
		}

		GenericMessage<IPayLoad> result = null;
		try {
			URL endPointURL = new URL(url);
			URLConnection urlConnection = endPointURL.openConnection();
			InputStreamReader is = new InputStreamReader(
					urlConnection.getInputStream());
			StringBuilder sb = new StringBuilder();

			int data = is.read();
			while (data != -1) {

				char theChar = (char) data;
				sb.append(String.valueOf(theChar));

				data = is.read();
			}

			is.close();

			XmlPayload xmlPayload = new XmlPayload();
			xmlPayload.setXml(sb.toString());

			results.add(xmlPayload);
			result = new GenericMessage<IPayLoad>(xmlPayload);

		} catch (IOException e) {
			LOGGER.error("Error in DatingServiceClient:executeEndpoint reason {}", e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			LOGGER.error("Error ConnectorTemplate:apply {}", e.getMessage());
		}

		LOGGER.info("Exiting DatingServiceClient:executeEndpoint");
		return result;
	}
}
