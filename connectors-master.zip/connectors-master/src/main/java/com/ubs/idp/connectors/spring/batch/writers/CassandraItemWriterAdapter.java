package com.ubs.idp.connectors.spring.batch.writers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.util.StringUtils;

public class CassandraItemWriterAdapter implements ItemWriter<FieldSet>{
    private CassandraItemWriter cassandraItemWriter;

    @Override
    public void write(List<? extends FieldSet> items) throws Exception {

        List<String> itemsAsStrings = convertListOfFieldSetsToStrings(items);
        cassandraItemWriter.write(itemsAsStrings);
    }

    private List<String> convertListOfFieldSetsToStrings(List<? extends FieldSet> items) {
        List<String> itemsAsStrings = new ArrayList<String>();
        for(FieldSet item:items){
            String itemAsString = StringUtils.arrayToDelimitedString(item.getValues(), ",");
            itemsAsStrings.add(itemAsString);
        }
        return itemsAsStrings;
    }

    public void setCassandraItemWriter(CassandraItemWriter cassandraItemWriter) {
        this.cassandraItemWriter = cassandraItemWriter;
    }
}
