package com.ubs.idp.orchestrator.processor.rules.merge;

import static org.springframework.util.Assert.notNull;

import java.util.List;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;


@Configuration
@PropertySource({"classpath:application.properties", "classpath:environment-${environment}.properties"})
public class CFCheckRuleConfiguration implements InitializingBean {
    
    public static final String CHECK_TYPE_EXISTS = "exists";
    
    @Value("${cfcheckrule.checkType:}")
    private String lookupCheckType;

    @Value("${cfcheckrule.derivedFieldSettingTrue:}")
    private String derivedFieldSettingTrue;

    @Value("${cfcheckrule.derivedFieldSettingFalse:}")
    private String derivedFieldSettingFalse;
    
    @Value("${cfcheckrule.lookupColumnFamily:}")
    private String lookupColumnFamily;

    @Value("${cfcheckrule.lookupFieldNames:}")
    private List<String> lookupFieldNames;

    @Value("${cfcheckrule.joinFields:}")
    private List<String> joinFields;

    @Value("${cfcheckrule.sourceFieldNames:}")
    private List<String> sourceFieldNames;

    @Value("${cfcheckrule.preload:false}")
    private Boolean preload;

    @Value("${cfcheckrule.lookupDataSeparator:\t}")
    private String lookupDataSeparator;

    public String getLookupCheckType() {
        return lookupCheckType;
    }

    public void setLookupCheckType(String lookupCheckType) {
        this.lookupCheckType = lookupCheckType;
    }


    public String getDerivedFieldSettingTrue() {
        return derivedFieldSettingTrue;
    }

    public void setDerivedFieldSettingTrue(String derivedFieldSettingTrue) {
        this.derivedFieldSettingTrue = derivedFieldSettingTrue;
    }

    public String getDerivedFieldSettingFalse() {
        return derivedFieldSettingFalse;
    }

    public void setDerivedFieldSettingFalse(String derivedFieldSettingFalse) {
        this.derivedFieldSettingFalse = derivedFieldSettingFalse;
    }

    public String getLookupColumnFamily() {
        return lookupColumnFamily;
    }

    public void setLookupColumnFamily(String lookupColumnFamily) {
        this.lookupColumnFamily = lookupColumnFamily;
    }

    public List<String> getLookupFieldNames() {
        return lookupFieldNames;
    }

    public void setLookupFieldNames(List<String> lookupFieldNames) {
        this.lookupFieldNames = lookupFieldNames;
    }

    public List<String> getJoinFields() {
        return joinFields;
    }

    public void setJoinFields(List<String> joinFields) {
        this.joinFields = joinFields;
    }

    public List<String> getSourceFieldNames() {
        return sourceFieldNames;
    }

    public void setSourceFieldNames(List<String> sourceFieldNames) {
        this.sourceFieldNames = sourceFieldNames;
    }

    public Boolean getPreload() {
        return preload;
    }

    public void setPreload(Boolean preload) {
        this.preload = preload;
    }

    public String getLookupDataSeparator() {
        return lookupDataSeparator;
    }

    public void setLookupDataSeparator(String lookupDataSeparator) {
        this.lookupDataSeparator = lookupDataSeparator;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        // Sanity check config

        notNull(lookupCheckType, "No lookupCheckType specified?");
        notNull(derivedFieldSettingTrue, "No derivedFieldSettingTrue specified?");
        notNull(derivedFieldSettingFalse, "No derivedFieldSettingFalse specified?");
        notNull(lookupColumnFamily, "No lookupColumnFamily specified?");
        notNull(lookupFieldNames, "No lookupFieldNames specified?");
        notNull(joinFields, "No joinFields specified?");
        notNull(sourceFieldNames, "No sourceFieldNames specified?");
        notNull(lookupDataSeparator, "No lookupDataSeparator specified?");
    }
}
