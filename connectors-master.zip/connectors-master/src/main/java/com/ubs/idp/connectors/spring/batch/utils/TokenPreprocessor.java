package com.ubs.idp.connectors.spring.batch.utils;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Token replacement pre-processor
 * @author mcminnp
 */
public class TokenPreprocessor implements PropertyPreprocessor {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private Map<String, String> tokenMap;
    
    /**
     * Set up tokens to replace
     * @param tokenMap
     */
    public void setTokenMap(Map<String, String> tokenMap) {
        if (tokenMap == null) {
            return;
        }
        
        this.tokenMap = tokenMap;
        
        logger.debug("Token map set with {} tokens", tokenMap.size());
    }

    @Override
    public String preProcess(String input) {
        String res = input;
        
        if (tokenMap != null) {
            logger.debug("Processing input value...");
            
            for (String key : tokenMap.keySet()) {
                String value = tokenMap.get(key);
                
                /* IMPORTANT NOTE
                 * ==============
                 * For the initial implementation, we're using in a Spring XML job context
                 * file. As such, defining the token as '${MYTOKEN}' would be evaluated by
                 * Spring resulting in a start up error.
                 * To get around this we ass the '${' and '}' inside the processor.
                 */
                String token = "${" + key + "}";
                
                logger.debug("Processing token '{}'...", token);

                
                // TODO: Review
                if (value == null) {
                    value = "";
                }
                
                if (value.equals(token)) {
                    logger.warn("Token and value should not be equal? {}", token);
                } else {
                    while(res.indexOf(token) >= 0) {
                        logger.info("Replacing {} with {}",token,value);
                        res = res.replace(token, value);
                    }
                }
            }
        }
        
        return res;
    }
}
