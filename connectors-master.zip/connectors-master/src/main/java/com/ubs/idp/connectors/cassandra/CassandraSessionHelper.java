package com.ubs.idp.connectors.cassandra;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * Provide centralised access to singleton Cassandra cluster session.
 * @author mcminnp
 */
@Component("cassandraSessionHelper")
public class CassandraSessionHelper {

    @Autowired
    @Qualifier("cassandraConfig")
    private CassandraConfig cassandraConfig;

    private static CassandraCqlProxy proxy = null;

    private static Logger logger = LoggerFactory.getLogger(CassandraSessionHelper.class);

    /**
     * Create/return Cassandra proxy
     * @return
     */
    public synchronized CassandraCqlProxy getProxy() {
        if(proxy == null) {
            logger.info("Initialise Cassandra proxy...");

            proxy = new CassandraCqlProxyImpl(cassandraConfig);

            logger.info("Connect Cassandra proxy...");

            proxy.connect();
        }

        logger.info("Return Cassandra proxy {}", proxy);

        return proxy;
    }
}