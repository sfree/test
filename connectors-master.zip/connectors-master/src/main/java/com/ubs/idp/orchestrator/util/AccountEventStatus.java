package com.ubs.idp.orchestrator.util;


public enum AccountEventStatus {
    UNPROCESSED, PROCESSED, PUBLISHED, FATAL
}
