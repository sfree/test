package com.ubs.idp.connectors;

import com.ubs.distribution.idm.IdmService;
import com.ubs.distribution.idm.RcasClient;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.LaxRedirectStrategy;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStreamReader;
import java.net.HttpCookie;
import java.net.URL;
import java.util.List;

/**
 * Wrap Apache HTTP interface to facilitate changes and testing
 * @author mcminnp
 */
public class HttpClientWrapper {
    
    // TODO: Use enum?
    public static final String RCAS_ENV_DEV  = "DEV";
    public static final String RCAS_ENV_PROD = "PROD";
    public static final String RCAS_ENV_UAT  = "UAT";

    private static final int MAX_TRIES = 1;
    private static final Logger LOGGER = LoggerFactory.getLogger(HttpClientWrapper.class);
    
    private HttpClient httpClient = null;
    private InputStreamReader is = null;

    /**
     * Initialise HTTP connection.
     * @param username
     * @param password
     * @param rcasEnv
     * @param appKey
     * @throws Exception
     */
    public void init(String username, String password, String rcasEnv, String appKey) throws Exception {
        
        URL rcasUrl = null;
        
        switch(rcasEnv) {
            case RCAS_ENV_DEV:
                rcasUrl = IdmService.RcasUrl.DEV;
                break;
            case RCAS_ENV_UAT:
                rcasUrl = IdmService.RcasUrl.UAT;
                break;
            case RCAS_ENV_PROD:
                rcasUrl = IdmService.RcasUrl.PROD;
                break;
            default:
                throw new Exception("Invalid RCAS environment specified?");
        }
        
        RcasClient rcasClient = IdmService.createRcasClient(rcasUrl, appKey);
        
        // Set up cookies from RCAS
        
        List<HttpCookie> rcasCookieList = rcasClient.getCookies(username, password);
        CookieStore cookieStore = new BasicCookieStore();
        
        for (HttpCookie rcasCookie : rcasCookieList) {
            cookieStore.addCookie(generateApacheHttpCookie(rcasCookie));
        }

        // Create client
        RequestConfig config = RequestConfig.custom()
                .setCircularRedirectsAllowed(true)
                .setRedirectsEnabled(true)
                .setExpectContinueEnabled(true)
                .setRelativeRedirectsAllowed(true)
                .build();

        httpClient = HttpClientBuilder.create()
                .setDefaultCookieStore(cookieStore)
                .setRedirectStrategy(new LaxRedirectStrategy())
                .setDefaultRequestConfig(config)
                .setMaxConnTotal(1)
                .build();
    }
    
    /**
     * Get input stream for specified URI
     * @param uri
     * @return
     * @throws Exception
     */
    public InputStreamReader getInput(String uri) throws Exception {

        if (LOGGER.isDebugEnabled()) LOGGER.debug("Attempt HTTP get from '" + uri + "'...");
        
        HttpUriRequest request = new HttpGet(uri);
        HttpResponse response = null;
        
        for (int i = 1; response == null && i <= MAX_TRIES; i++) {
            try {
                response = httpClient.execute(request);
            } catch (Exception e) {
                LOGGER.warn("Error fetching data: " + e.getMessage());

                // Throw exception if max tries reached
                if (i == MAX_TRIES) {
                    LOGGER.error("Retry limit exceeded!", e);
                    throw e;
                }
            }
        }
        
        // If no data after retries, throw error
        if (response == null) {
            String msg = "Retry limit exceeded!";
            LOGGER.error(msg);
            throw new Exception(msg);
        }
        
        // Check response status and, if valid wrap with InputStreamReader
        
        StatusLine status = response.getStatusLine();
        HttpEntity entity = response.getEntity();
        
        if (status.getStatusCode() != HttpStatus.SC_OK) {
            throw new Exception("Failed to get data from '" + uri + "': " + status.getReasonPhrase());
        } else {
            is = new InputStreamReader(entity.getContent());
        }
        
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Returning valid input stream");
        
        return is;
    }

    /**
     * Set up Apache cookie
     * @param cookie
     * @return
     */
    private static Cookie generateApacheHttpCookie(HttpCookie cookie) {
        BasicClientCookie apacheCookie = new BasicClientCookie(
                cookie.getName(), cookie.getValue());
        apacheCookie.setComment(cookie.getComment());
        apacheCookie.setDomain(cookie.getDomain());
        apacheCookie.setPath(cookie.getPath());
        apacheCookie.setSecure(cookie.getSecure());
        apacheCookie.setVersion(cookie.getVersion());
        return apacheCookie;
    }
}
