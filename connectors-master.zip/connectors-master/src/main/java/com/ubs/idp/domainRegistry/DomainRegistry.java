package com.ubs.idp.domainRegistry;


import java.util.Map;
import java.util.Set;

import com.ubs.idp.domainRegistry.common.DomainKey;

public interface DomainRegistry {
	
	/**
	 * Creates a domain wide key instead of one at a per dataset level
	 * 
	 * If Domain Id already exist in store, it will be return else new only one will created 
	 * @param registerInfo
	 * @return
	 */
	public DomainKey createDomainKey(String domain,String primaryKey);

	/**
	 * Creates a domain wide set of keys instead of one at a per dataset level
	 * 
	 * If Domain Id already exist in store, it will be return else new only one will created 
	 * @param registerInfo
	 * @return
	 */
	public Set<DomainKey> createDomainKey(String domain,Set<String>  primaryKeys);

	/**
	 * If Domain Id already exist in store, it will be return else new only one will created 
	 * @param registerInfo
	 * @return
	 */
	public DomainKey createDomainKey(String domain,String dataset,String physicalNodeId,String primaryKey);
	
	/**
	 *	If Domain Id already exist in store, it will be return else new only one will created
	 * @param registerInfo
	 * @return
	 */
	public Set<DomainKey> createDomainKey(String domain,String dataset,String physicalNodeId,Set<String> primaryKey);
	
	/**
	 * If the Information exist in the IDP_Registry table, it is retrieved and returned as Record object to the caller.
	 * @param registerInfo
	 * @return
	 */
	public DomainKey lookUpDomainKey(String domain,String dataset,String physicalNodeId,String primaryKey);
	
	
	/**
	 * If the Information exist in the IDP_Registry table, it is retrieved and returned as Record object to the caller.
	 * @param registerInfo
	 * @return
	 */
	
	public Map<String,DomainKey> lookUpDomainKey(String domain,String dataset,String physicalNodeId,Set<String> primaryKey);	
	
}
