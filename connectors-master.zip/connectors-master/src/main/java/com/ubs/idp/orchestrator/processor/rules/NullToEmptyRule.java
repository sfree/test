package com.ubs.idp.orchestrator.processor.rules;

import static org.apache.commons.lang.StringUtils.equalsIgnoreCase;
import static org.apache.commons.lang.StringUtils.trim;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.batch.item.ItemProcessor;

public class NullToEmptyRule extends DerivationRuleTemplate implements
        ItemProcessor<Map<String, Object>, Map<String, Object>> {

    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        return derive(item);
    }

    @Override
    public Map<String, Object> applyRules(Map<String, Object> inputFields) {
        Map<String, Object> derivedFields = new HashMap<String, Object>();
        for (Entry<String, Object> inputField : inputFields.entrySet()) {
            derivedFields.put(inputField.getKey(), nvl((String) inputField.getValue()));
        }
        return derivedFields;
    }

    private String nvl(String value) {
        if (value == null || equalsIgnoreCase(trim(value), "NULL")) {
            return "";
        }
        return value;
    }

}
