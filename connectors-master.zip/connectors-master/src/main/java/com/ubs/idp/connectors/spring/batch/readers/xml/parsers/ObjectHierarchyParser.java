package com.ubs.idp.connectors.spring.batch.readers.xml.parsers;

import java.io.InputStream;
import java.util.List;

/**
 * Object hierarchy parser interface
 * @author mcminnp
 */
public interface ObjectHierarchyParser <T> {
    
    /**
     * Parse input stream into object list
     * @param inputStream
     * @return
     * @throws Exception
     */
    public List<T> parseData(InputStream inputStream) throws Exception;

    /**
     * Parse file content into object list
     * @param fileName
     * @return
     * @throws Exception
     */
    public List<T> parseData(String fileName) throws Exception;
    
}
