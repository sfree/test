package com.ubs.idp.orchestrator.listeners;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

import com.ubs.idp.base.utils.TimeUtils;

/**
 * Job Execution listener that allows us to set an explicit date on the filename used throughout the job
 * @author loverids
 *
 */
public class FilenameJobExecutionListener implements JobExecutionListener {
	
	private String filePrefix;
	
	private String filenameDateFormat;
	
	private String deltaDays;
	
	/**
	 * Determine the filename we're going to be using for the job
	 */
    public void beforeJob(JobExecution jobExecution) {

    	String deltaString = jobExecution.getJobParameters().getString("deltaDays",deltaDays);
    	String suffix = TimeUtils.nowPlusDeltaDays("UTC", filenameDateFormat, Integer.parseInt( deltaString ) );
    	String filename = filePrefix + "-" + suffix + ".csv";
    	
        jobExecution.getExecutionContext().putString("filename", filename );
        jobExecution.getExecutionContext().putString("suffix", suffix );
    }

	@Override
	public void afterJob(JobExecution jobExecution)
	{
	}

	public String getFilePrefix()
	{
		return filePrefix;
	}

	public void setFilePrefix(String filePrefix)
	{
		this.filePrefix = filePrefix;
	}

	public String getFilenameDateFormat()
	{
		return filenameDateFormat;
	}

	public void setFilenameDateFormat(String filenameDateFormat)
	{
		this.filenameDateFormat = filenameDateFormat;
	}

	public String getDeltaDays()
	{
		return deltaDays;
	}

	public void setDeltaDays(String deltaDays)
	{
		this.deltaDays = deltaDays;
	}

	
	
	
}
