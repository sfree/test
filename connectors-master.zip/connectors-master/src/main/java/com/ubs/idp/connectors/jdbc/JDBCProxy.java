package com.ubs.idp.connectors.jdbc;

import org.springframework.jdbc.datasource.SimpleDriverDataSource;

/**
 * This is a simple JDBC proxy interface
 */

public interface JDBCProxy {
	
	 /**
   	 * This method is used to create a connection  
   	 * for JDBC source.
   	 * 
   	 * @return SimpleDriverDataSource
   	 */
	public SimpleDriverDataSource  getDataSource() throws ClassNotFoundException;
	
	/**This  method returns the status of Connection to jdbc database  
	 * 
	 * @return - Returns the value of status
	 */
	
	public boolean isConnected();
}
