package com.ubs.idp.connectors.spring.batch.writers;

import static org.springframework.util.Assert.notEmpty;
import static org.springframework.util.Assert.notNull;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;

/**
 * @formatter:off
 * <p>For each row:<p>
 * <ul>
 *   <li>Read existing main CF row (e.g.: from "INDEX") and split into value array</li>
 *   <li>For each queryable value (from MDS):</li>
 *     <ul>
 *       <li>Insert new record in corresponding <b>dataset_NN</b> CF
 *           values are: key=field value (e.g.: SEDOL), column1=key from above, value=null/blank</li>
 *     </ul>
 *   </ul>
 * @author mcminnp
 */
@Component("cassandraIndexItemWriter")
public class CassandraIndexItemWriter extends BaseCassandraItemWriter implements ItemWriter<String>, InitializingBean {

    private Logger logger = LoggerFactory.getLogger(CassandraIndexItemWriter.class);

    @Override
    public void write(List<? extends String> items) throws Exception {
        if (logger.isDebugEnabled()) logger.debug("Write {} items to Cassandra db...", items.size());

        // Pre-parse input rows
        Map<String, InputItem> inputItemMap = parseInputItems(items);
        
        // Load old rows (if any)
        Map<String, String[]> oldRows = loadOldRows(inputItemMap.keySet());

        // TODO: Review auto-DDL policy
        // Create column families as required

        for (int fldIdx : queryableAttributePositions) {
            String cfName = datasetName + CASSANDRA_CF_SEPARATOR + fldIdx;
            addColumnFamilyIfNeeded(cfName);
        }
        
        // As reading each old row is expensive, buffer the rows in memory off 1x read
        
        // Set up batch execution
        BatchStatement batchStatement = new BatchStatement();

        for(String keyValue : inputItemMap.keySet()) {
            
            if (logger.isDebugEnabled()) logger.debug("Processing key '{}'...", keyValue);
            
            InputItem inputItem = inputItemMap.get(keyValue);
            String fields[] = inputItem.getFields();
            
            // Loop through queryable fields, deleting OLD data as we go
            
            // Assemble reverse index CQL
            assembleRevIdxInsert(batchStatement, inputItem, oldRows);

            for (int fldIdx : queryableAttributePositions) {
                String cfName = datasetName + CASSANDRA_CF_SEPARATOR + fldIdx;
                // Escape logic removed as not required when binding
                String newValue = fields[fldIdx];
                
                // Insert reverse index
                
                String insertLineCql = "insert into \"" + cfName + "\" (key, column1, value) values (?, ?, ?)";

                PreparedStatement stmt = proxy.getPrepareStatement(insertLineCql);
                
                logger.debug("Append insert statement '{}'...", insertLineCql);
                
                BoundStatement boundStatement = stmt.bind();

                int parmIdx = 0;
                
                boundStatement.setString(parmIdx++, newValue);
                // Escape logic removed as not required when binding
                boundStatement.setString(parmIdx++, keyValue);
                boundStatement.setString(parmIdx++, "");

                // Add to batch
                
                batchStatement.add(boundStatement);
            }
        }

        if (logger.isDebugEnabled()) logger.debug("Wrote {} lines! (total: {})", items.size(), total);

        proxy.executeStatement(batchStatement);
    }
    
    /**
     * @throws Exception
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        // Sanity check config
        
        notNull(queryableAttributePositions, "No queryable attributes configured?");
        notEmpty(queryableAttributePositions, "Zero queryable attributes configured?");
        
        super.afterPropertiesSet();
    }
}
