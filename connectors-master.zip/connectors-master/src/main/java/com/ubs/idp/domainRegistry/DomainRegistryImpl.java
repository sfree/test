package com.ubs.idp.domainRegistry;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;
import com.ubs.idp.domainRegistry.common.DomainKey;

@Component("domainRegistry")
public class DomainRegistryImpl implements InitializingBean, DomainRegistry {

    private static final String MAIN_INSERT_CQL = "INSERT INTO \"DomainRegistry\" (\"domain\",\"dataset\",\"physicalNodeId\",\"primaryKey\",\"domainkey\") VALUES (?, ?, ?, ?, ?)";

    @Autowired
    @Qualifier("cassandraSessionHelper")
    private CassandraSessionHelper cassandraSessionHelper;
    
    private CassandraCqlProxy proxy = null;
    
	 @Autowired
	 @Qualifier("DomainIdGenerator")
	 private DomainIdGenerator idGenerator;
	 private static final Logger LOGGER = LoggerFactory.getLogger(DomainRegistryImpl.class);
	 
	 /**
	  * This is a placeholder value for dataset names and ids when we are creating a domain key
	  * at the domain level without the dataset forming part of the key 
	  */
	 public static final String DATASET_PLACEHOLDER = "";
	 
	 private Logger logger = LoggerFactory.getLogger(DomainRegistryImpl.class);

	 public DomainRegistryImpl() {
		 // TODO Auto-generated constructor stub
	 }
	 
	 @Override
	 public void afterPropertiesSet() throws Exception {
	     
	     logger.info("Get Cassandra proxy");

	     // Initialise/fetch proxy
	     proxy = cassandraSessionHelper.getProxy();

	     logger.info("Got Cassandra proxy: {}", proxy);
	     
	     logger.info("Initialise domain registry schema");
	        
		 String cql = "CREATE TABLE \"DomainRegistry\" (\"domain\" text, \"dataset\" text,\"physicalNodeId\" text,\"primaryKey\" "+
		 			   " text,domainkey bigint , PRIMARY KEY (\"domain\",\"dataset\", \"physicalNodeId\",\"primaryKey\") ) WITH COMPACT STORAGE;";
		 
		 proxy.addColumnFamilyIfNeeded("DomainRegistry",cql);		 
		 
		 cql = "CREATE TABLE \"DomainRegistryCounter\" (\"domain\" text, \"dataset\" text,\"physicalNodeId\" text,\"domainkeyCounter\" counter, "
		 		+ "PRIMARY KEY (\"domain\",\"dataset\", \"physicalNodeId\") ) WITH COMPACT STORAGE;";
		 
		 proxy.addColumnFamilyIfNeeded("DomainRegistryCounter",cql);
	 }
	 
	@Override
	public DomainKey createDomainKey(String domain,String dataset,String physicalNodeId,String primaryKey){
		
		LOGGER.debug("domain = "+domain+", dataset = "+dataset+", physicalNodeId = "+physicalNodeId + "Primary Key = "+primaryKey);
		
		// check if already exists
		DomainKey record = lookUpDomainKey(domain,dataset,physicalNodeId,primaryKey);
				
		if(record==null){
			long domainkey = idGenerator.createDomainKey(domain, dataset, physicalNodeId);
			
			String insertCql = MAIN_INSERT_CQL;
			
			PreparedStatement stmt = proxy.getPrepareStatement(insertCql);
			
			BoundStatement boundStatement = stmt.bind();

	        int parmIdx = 0;
	        
            boundStatement.setString(parmIdx++, domain);
            boundStatement.setString(parmIdx++, dataset);
            boundStatement.setString(parmIdx++, physicalNodeId);
            boundStatement.setString(parmIdx++, primaryKey);
            boundStatement.setLong(parmIdx++, domainkey);
            
            boundStatement.setConsistencyLevel(ConsistencyLevel.ALL);
            
            proxy.executeStatement(boundStatement);
			
			record = lookUpDomainKey(domain,dataset,physicalNodeId,primaryKey);			
		}
		return record;
	}	

	@Override
	public DomainKey createDomainKey(String domain,String primaryKey){
		
		return createDomainKey(domain,DATASET_PLACEHOLDER,DATASET_PLACEHOLDER ,primaryKey);
	}	

	@Override
	public Set<DomainKey> createDomainKey(String domain,Set<String> primaryKeys){
		
		return createDomainKey(domain,DATASET_PLACEHOLDER,DATASET_PLACEHOLDER ,primaryKeys);
	}	

	
	@Override
	public Set<DomainKey> createDomainKey(String domain,String dataset,String physicalNodeId,Set<String> primaryKey) {
		
		Map<String,DomainKey> existingKey = lookUpDomainKey(domain,dataset,physicalNodeId,primaryKey);
		
		if(existingKey.keySet().size()==primaryKey.size()){
			// if all of the primary key has domain key then return
			return new HashSet<DomainKey>(existingKey.values());
		}
		
		// remove the primary key that already has domain key
		primaryKey.removeAll(existingKey.keySet());
		
		KeyRange domainkey = idGenerator.getDomainKeys(domain, dataset, physicalNodeId, primaryKey.size());
		long startKey = domainkey.getKeyStartRange();
		
		BatchStatement batchStatement = new BatchStatement();
		
		String insertCql = MAIN_INSERT_CQL;
		
        for(String pKey : primaryKey){
            PreparedStatement stmt = proxy.getPrepareStatement(insertCql);
    
            BoundStatement boundStatement = stmt.bind();
            
            int parmIdx = 0;
            
            boundStatement.setString(parmIdx++, domain);
            boundStatement.setString(parmIdx++, dataset);
            boundStatement.setString(parmIdx++, physicalNodeId);
            
            boundStatement.setString(parmIdx++, pKey);
            boundStatement.setLong(parmIdx++, startKey);
        
            startKey--;
            
            batchStatement.add(boundStatement);
        }
        
        batchStatement.setConsistencyLevel(ConsistencyLevel.ALL);
		
		proxy.executeStatement(batchStatement);
		
		Map<String,DomainKey> newKeys = lookUpDomainKey(domain,dataset,physicalNodeId,primaryKey);
		
		Set<DomainKey> resultSet = new HashSet<DomainKey>(existingKey.values());
		resultSet.addAll(newKeys.values());
		return resultSet;
	}
	
	
	@Override
	public DomainKey lookUpDomainKey(String domain,String dataset,String physicalNodeId,String primaryKey) {
		
	    String selectCql = "SELECT domainkey FROM \"DomainRegistry\" WHERE \"domain\" = ? AND \"dataset\" = ? AND \"physicalNodeId\"= ? AND \"primaryKey\" = ?";
	    
	    PreparedStatement stmt = proxy.getPrepareStatement(selectCql);
	    BoundStatement boundStatement = stmt.bind();
	    
	    int parmIdx = 0;
	    
	    boundStatement.setString(parmIdx++, domain);
	    boundStatement.setString(parmIdx++, dataset);
	    boundStatement.setString(parmIdx++, physicalNodeId);
	    boundStatement.setString(parmIdx++, primaryKey);
	    
	    ResultSet resultSet = proxy.executeStatement(boundStatement);
	    
		DomainKey record = null;
		
		if(resultSet!=null){
			Row row = resultSet.one();
			if(row!=null){
				record = new DomainKey();
				record.setDomain(domain);
				record.setDataSet(dataset);
				record.setPhysicalNodeId(physicalNodeId);
				record.setPrimaryKey(primaryKey);
				record.setDomainKey(row.getLong("domainkey"));				
			}
		}			
		return record;			
	}
	
	@Override
	public Map<String,DomainKey> lookUpDomainKey(String domain,String dataset,String physicalNodeId,Set<String> primaryKey) {
		
		Map<String,DomainKey> recordMap= new HashMap<String,DomainKey>();

		List<String> primaryKeyList = new ArrayList<>();
		
		primaryKeyList.addAll(primaryKey);
		
		String selectCql = "SELECT \"primaryKey\",\"domainkey\" FROM \"DomainRegistry\" WHERE \"domain\" = ? AND \"dataset\" = ? AND \"physicalNodeId\" = ? AND \"primaryKey\" in ?";
		
		PreparedStatement stmt = proxy.getPrepareStatement(selectCql);
		
		BoundStatement boundStatement = stmt.bind();
		
        int parmIdx = 0;
        
        boundStatement.setString(parmIdx++, domain);
        boundStatement.setString(parmIdx++, dataset);
        boundStatement.setString(parmIdx++, physicalNodeId);
        boundStatement.setList(parmIdx++, primaryKeyList);
        
		ResultSet resultSet = proxy.executeStatement(boundStatement);
		
		if(resultSet!=null){
			List<Row> rows = resultSet.all();
			if(rows!=null && rows.size() > 0){
				DomainKey record = null;
				for (Row singleRow : rows) {
					
					record = new DomainKey();
					record.setDomain(domain);
					record.setDataSet(dataset);
					record.setPhysicalNodeId(physicalNodeId);
					record.setPrimaryKey(singleRow.getString("primaryKey"));
					record.setDomainKey(singleRow.getLong("domainkey"));
					
					recordMap.put(record.getPrimaryKey(),record);
				}							
			}
		}
		
		return recordMap;
	}
}
