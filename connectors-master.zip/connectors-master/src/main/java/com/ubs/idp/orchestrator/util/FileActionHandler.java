package com.ubs.idp.orchestrator.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import com.ubs.idp.base.utils.IdpFileUtils;

/**
 * Spring configurable bean to wrap common file functions in IDP
 * @author mcminnp
 */
public class FileActionHandler {
	
	public static final String ACTION_MOVE = "move";
	public static final String ACTION_DELETE = "delete";

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	private String action;
	private Resource inputFile;
	private Resource targetDirectory;
	private boolean zip = false;
	private boolean timestampFile = true;
	private String timestampFormat = "yyyyMMddHHmmss";

	/**
	 * Generic process method
	 * @throws IOException
	 */
	public void processFile() throws IOException {
		Assert.notNull(inputFile, "No file provided?");
		Assert.notNull(action, "No action provided?");

		logger.debug("Process '{}' action on input file '{}'...", action, inputFile.getFilename());
		
		File originalFile = inputFile.getFile();
		
		Assert.isTrue(inputFile.exists(), "Invalid file name? (" + originalFile.getAbsolutePath() + ")");
		
		if (action.equals(ACTION_DELETE)) {
			deleteFile(originalFile);
		} else if (action.equals(ACTION_MOVE)) {
			String newFileName = null;
			
			Assert.notNull(targetDirectory, "No target directory specified?");

			// Conditionally derive new file name based on the current timestamp
			
			if (timestampFile) {
		        Date now = new Date();
		        DateFormat df = new SimpleDateFormat(timestampFormat);
		        
				String[] parts = originalFile.getName().split("\\.");
				
				for (String part : parts) {
					if (newFileName == null) {
						newFileName = part + "-" + df.format(now);
					} else {
						newFileName += "." + part;
					}
				}
			}
			
			move(originalFile, targetDirectory.getFile(), newFileName, zip);
		} else {
			throw new IllegalArgumentException("Invalid action ? (" + action + ")");
		}
	}
	
	// Getters and setters
	
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Resource getInputFile() {
		return inputFile;
	}

	public void setInputFile(Resource inputFile) {
		this.inputFile = inputFile;
	}

	public Resource getTargetDirectory() {
		return targetDirectory;
	}

	public void setTargetDirectory(Resource targetDirectory) {
	    this.targetDirectory = targetDirectory;

	    try {
	        File targetDirectoryFile = targetDirectory.getFile();

	        if (!targetDirectoryFile.exists()) {
	            Assert.isTrue(targetDirectoryFile.mkdir(), "Failed to create directory '" + targetDirectory + "'?");
	        }

	        Assert.isTrue(targetDirectoryFile.isDirectory(), "Specified destination '" + targetDirectoryFile + "' is not a directory?");
	        Assert.isTrue(targetDirectoryFile.canWrite(), "Specified destination '" + targetDirectoryFile + "' must be writeable!");
	    } catch (IOException e) {
	        throw new IllegalArgumentException("Failed to set destination directory of '" + targetDirectory + "'?", e); 
	    }
	}

	public boolean isZip() {
		return zip;
	}

	public void setZip(boolean zip) {
		this.zip = zip;
	}

	public boolean isTimestampFile() {
		return timestampFile;
	}

	public void setTimestampFile(boolean timestampFile) {
		this.timestampFile = timestampFile;
	}

	public String getTimestampFormat() {
		return timestampFormat;
	}

	public void setTimestampFormat(String timestampFormat) {
		this.timestampFormat = timestampFormat;
	}

	/**
	 * Delete specified file
	 * @param fileNameToDelete
	 * @throws IOException
	 */
	public void deleteFile(File fileToDelete) throws IOException {
		Assert.isTrue(fileToDelete.exists(), "Requested file ('" + fileToDelete.getAbsolutePath() + "') does not exist?");

		logger.debug("Deleting file  '{}'...", fileToDelete.getAbsolutePath());

		Assert.isTrue(fileToDelete.delete(), "Failed to delete file '" + fileToDelete.getAbsolutePath() + "'?");
	}

	/**
	 * Move and optionally rename/zip file
	 * @param fileToMove
	 * @param destinationDir
	 * @param newFileName
	 * @param zip
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public void move(File fileToMove, File destinationDir, String newFileName, boolean zip) throws FileNotFoundException, IOException {
		String fileNameToMove = fileToMove.getName();
		File resultingFile;
		
		Assert.isTrue(fileToMove.exists(), "Requested file ('" + fileToMove.getAbsolutePath() + "') does not exist?");
		
		if (zip) {
			logger.debug("Zipping file '{}' to '{}'...", fileToMove.getAbsolutePath(), destinationDir.getAbsolutePath());

			String zipFileName;

			if (StringUtils.isEmpty(newFileName)) {
				zipFileName = IdpFileUtils.moveAndZip(destinationDir, fileToMove);
			} else {
				// Rename and zip
				zipFileName = IdpFileUtils.renameAndZip(newFileName, destinationDir, fileToMove);
			}

			resultingFile = new File(zipFileName);
		} else {
			if (StringUtils.isEmpty(newFileName)) {
				resultingFile = new File(destinationDir.getAbsolutePath() + File.separator + fileNameToMove);
			} else {
				// Rename
				resultingFile = new File(destinationDir.getAbsolutePath() + File.separator + newFileName);
			}
	
			logger.debug("Moving file '{}' to '{}'...", fileToMove.getAbsolutePath(), resultingFile.getAbsolutePath());
	
			fileToMove.renameTo(resultingFile);
		}
		
		// Sanity check output file exists
		Assert.isTrue(resultingFile.exists(), "Failed to write file '" + resultingFile.getAbsolutePath() + "'?");
	}
}
