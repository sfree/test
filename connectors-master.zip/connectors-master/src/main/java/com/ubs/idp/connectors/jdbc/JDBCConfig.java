package com.ubs.idp.connectors.jdbc;


import static com.ubs.idp.encrypt.Crypto.decrypt;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration("jdbcConfig")
@PropertySource({"classpath:application.properties", "classpath:environment-${environment}.properties"})
public class JDBCConfig {

	@Value("${jdbc.user:}")
	private String jdbcUser;

	@Value("${jdbc.password:}")
	private String jdbcPassword;

	@Value("${jdbc.url:}")
	private String jdbcUrl;
	
	@Value("${jdbc.driver:}")
	private String jdbcDriver;
	
	private String decryptedJDBCPassword;

	public String getJdbcUser() {
		return jdbcUser;
	}

	public String getJdbcPassword() {
		return jdbcPassword;
	}


	public String getJdbcUrl() {
		return jdbcUrl;
	}

	public String getJdbcDriver() {
		return jdbcDriver;
	}
	
	public String getDecryptedJDBCPassword() {

		if (decryptedJDBCPassword == null) {
			decryptedJDBCPassword = decrypt(jdbcPassword);
		}
		return decryptedJDBCPassword;
	}	
}
