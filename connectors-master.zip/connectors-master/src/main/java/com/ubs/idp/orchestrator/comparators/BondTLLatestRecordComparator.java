package com.ubs.idp.orchestrator.comparators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.ubs.idp.connectors.spring.batch.utils.BaseCassandraComparator;
import com.ubs.idp.connectors.spring.batch.writers.BaseCassandraItemWriter.InputItem;

/**
 * Comparator that ensures that the latest Bond TL record is written to cassandra
 * 
 * @author loverids
 * 
 */
public class BondTLLatestRecordComparator extends BaseCassandraComparator
{
	public final static String ATTR_TL_UBSID = "tL.ubsId";
	public final static String ATTR_EVENT_MAJOR_VERSION = "event.majorVersion";

	public final static String[] ATTR_SORT_ORDER = { ATTR_TL_UBSID,ATTR_EVENT_MAJOR_VERSION };

	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.connectors.spring.batch.utils.BaseCassandraComparator#castValueToType(java.lang.String, java.lang.String)
	 */
	@Override
	public Comparable<?> castValueToType( String attrName, String value ) throws ParseException
	{
		if( attrName.equals(ATTR_TL_UBSID) )return value;
		if( attrName.equals(ATTR_EVENT_MAJOR_VERSION) )return new Integer(Integer.parseInt(value));
		
		throw new RuntimeException("Unexpected attribute name " + attrName + " with value " + value);
	}

	/*
	 * (non-Javadoc)
	 * @see com.ubs.idp.connectors.spring.batch.utils.BaseCassandraComparator#getAttributeCompareOrder()
	 */
	@Override
	public String[] getAttributeCompareOrder()
	{
		return ATTR_SORT_ORDER;
	}
}
