package com.ubs.idp.domainRegistry.common;

public class DomainKey {

	private long domainKey;
	private String domain;
	private String dataSet;
	private String physicalNodeId;
	private String primaryKey;
	
	public DomainKey() {
		// TODO Auto-generated constructor stub
	}		
	
	/**
	 * @return the negative domain dataset id 
	 */
	public long getDomainKey() {
		return domainKey;
	}	

	/**
	 * @param domainKey is a negative domain dataset id 
	 */
	public void setDomainKey(long domainKey) {
		this.domainKey = domainKey;
	}

	/**
	 * @return the domain
	 */
	public String getDomain() {
		return domain;
	}

	/**
	 * @param domain the domain to set
	 */
	public void setDomain(String domain) {
		this.domain = domain;
	}

	/**
	 * @return the dataSet
	 */
	public String getDataSet() {
		return dataSet;
	}

	/**
	 * @param dataSet the dataSet to set
	 */
	public void setDataSet(String dataSet) {
		this.dataSet = dataSet;
	}

	/**
	 * @return the physicalNodeId
	 */
	public String getPhysicalNodeId() {
		return physicalNodeId;
	}

	/**
	 * @param physicalNodeId the physicalNodeId to set
	 */
	public void setPhysicalNodeId(String physicalNodeId) {
		this.physicalNodeId = physicalNodeId;
	}

	/**
	 * @return the keyId
	 */
	public String getPrimaryKey() {
		return primaryKey;
	}

	/**
	 * @param keyId the keyId to set
	 */
	public void setPrimaryKey(String keyId) {
		this.primaryKey = keyId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DomainKey [domainKey=" + domainKey + ", domain=" + domain
				+ ", dataSet=" + dataSet + ", physicalNodeId=" + physicalNodeId
				+ ", primaryKey=" + primaryKey + "]";
	}
}
