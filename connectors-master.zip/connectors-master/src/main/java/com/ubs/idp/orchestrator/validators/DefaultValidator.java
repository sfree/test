package com.ubs.idp.orchestrator.validators;

import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;

public class DefaultValidator implements Validator {
    @Override
    public void validate(Object value) throws ValidationException {
        FieldSet fieldSet = (FieldSet) value;
        if(fieldSet.readString(2).equalsIgnoreCase("JPY")){
            throw new ValidationException("JPY:I DONT WANT YEN !");
        }
        if(fieldSet.readString(2).equalsIgnoreCase("USD")){
            throw new ValidationException("USD:I DONT WANT DOLLARS !");
        }
    }
}
