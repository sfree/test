package com.ubs.idp.orchestrator.writers;

import java.util.List;
import java.util.Map;

import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import com.ubs.idp.base.IdpBoundary;
import com.ubs.idp.orchestrator.util.MetaDataRetrieverUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;

import static com.ubs.idp.orchestrator.util.AccountEventConstants.*;

@IdpBoundary
@Service
public class AccountEventXmlMqWriter implements ItemWriter<Map<String, Object>>, InitializingBean {

    private static final Logger logger = LoggerFactory.getLogger(AccountEventXmlMqWriter.class);
    @Autowired
    private MetaDataRetrieverUtil metaDataRetrieverUtil;

    @Override
    public void write(List<? extends Map<String, Object>> xmls) throws Exception {

        final Map<String, Object> xmlMessageAndAttributesInMap = xmls.get(0);
        JmsTemplate jmsTemplate = metaDataRetrieverUtil.getJmsTemplateForView((String)
                xmlMessageAndAttributesInMap.get(EVENT_DOWNSTREAM_SP_ID));
        
        logger.info("Preparing to dispatch the XML message over MQ");
        
        jmsTemplate.send(createMessage(xmlMessageAndAttributesInMap));
    }
    
    public MessageCreator createMessage(final Map<String, Object> xmlMessageAndAttributesInMap) {
    	return new MessageCreator() {
    		
    		@Override
            public Message createMessage(Session session) throws javax.jms.JMSException {
    			TextMessage message = session.createTextMessage(
                        xmlMessageAndAttributesInMap.get(XML_OUTBOUND_MESSAGE_NAME) != null ?
                                (String) xmlMessageAndAttributesInMap.get(XML_OUTBOUND_MESSAGE_NAME) : "");
    			
                message.setJMSCorrelationID(String.valueOf(xmlMessageAndAttributesInMap.get(EVENT_ID)));
                message.setJMSType((String) xmlMessageAndAttributesInMap.get(EVENT_DOWNSTREAM_SP_ID));
                
                logger.info("Dispatching message for event id: {} and propagation code: {} ",
                        xmlMessageAndAttributesInMap.get(EVENT_ID),
                        xmlMessageAndAttributesInMap.get(EVENT_DOWNSTREAM_SP_ID));
                
                return message;
    		}
    	};
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        //To change body of implemented methods use File | Settings | File Templates.
    }
    
}
