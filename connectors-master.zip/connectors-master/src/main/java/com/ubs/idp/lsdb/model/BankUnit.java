package com.ubs.idp.lsdb.model;

import java.util.List;

/**
 * JiBX POJO
 * @author mcnamars
 */
public class BankUnit {
	
	private List<Company> companyList;

	public BankUnit() {
		
	}
	
	public BankUnit(List<Company> companyList) {
		this.companyList = companyList;
	}
	 
	public List<Company> getCompanyList() {
		return companyList;
	}

	public void setCompanyList(List<Company> companyList) {
		this.companyList = companyList;
	}
}