package com.ubs.idp.domainRegistry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;

@Component("DomainIdGenerator")
public final class DomainIdGenerator implements InitializingBean {

    private static final String SELECT_COUNTER_CQL = "SELECT  \"domainkeyCounter\" FROM \"IDP\".\"DomainRegistryCounter\" WHERE \"domain\" = ? AND \"dataset\" = ? AND \"physicalNodeId\" = ?";
    private static final String DECREMENT_COUNTER_CQL1 = "UPDATE \"IDP\".\"DomainRegistryCounter\" SET \"domainkeyCounter\" = \"domainkeyCounter\" -1 WHERE \"domain\"= ? AND \"dataset\" = ? AND \"physicalNodeId\" = ?";
    private static final String DECREMENT_COUNTER_CQL2 = "UPDATE \"IDP\".\"DomainRegistryCounter\" set \"domainkeyCounter\" = \"domainkeyCounter\" - ? WHERE \"domain\" = ? AND \"dataset\" = ? AND \"physicalNodeId\" = ?";

    @Autowired
    @Qualifier("cassandraSessionHelper")
    private CassandraSessionHelper cassandraSessionHelper;
    
    private CassandraCqlProxy proxy = null;
    
    private Logger logger = LoggerFactory.getLogger(DomainIdGenerator.class);

	public DomainIdGenerator() {
		// TODO Auto-generated constructor stub
	}
	
	public long createDomainKey(String domain, String dataset, String physicalNodeId ){
		
		synchronized (DomainIdGenerator.class) {
					
			Long counter = lookupDomainKey(domain, dataset, physicalNodeId);
			long domainKey = (counter==null)  ? -1 : counter-1;
			
			String updateCounterCql = DECREMENT_COUNTER_CQL1;

			PreparedStatement stmt = proxy.getPrepareStatement(updateCounterCql);
			
			BoundStatement boundStatement = stmt.bind();
			
			int parmIdx = 0;
		        
		    boundStatement.setString(parmIdx++, domain);
		    boundStatement.setString(parmIdx++, dataset);
		    boundStatement.setString(parmIdx++, physicalNodeId);

		    boundStatement.setConsistencyLevel(ConsistencyLevel.ALL);

		    proxy.executeStatement(boundStatement);
			
			return domainKey;
		}
	}
	
	public KeyRange getDomainKeys(String domain,String dataset,String physicalNodeId, long numberOfKeys){
		
		synchronized (DomainIdGenerator.class) {

			Long keyObject = lookupDomainKey(domain,dataset,physicalNodeId);
			Long startKeyRange = (keyObject==null) ? -1 : (keyObject -1);
			Long endKeyRange = startKeyRange - (numberOfKeys-1);
			
			String updateCounterCql = DECREMENT_COUNTER_CQL2;
			
			PreparedStatement stmt = proxy.getPrepareStatement(updateCounterCql);
            
            BoundStatement boundStatement = stmt.bind();
            
            int parmIdx = 0;
            
            boundStatement.setLong(parmIdx++, numberOfKeys);
            boundStatement.setString(parmIdx++, domain);
            boundStatement.setString(parmIdx++, dataset);
            boundStatement.setString(parmIdx++, physicalNodeId);

		    boundStatement.setConsistencyLevel(ConsistencyLevel.ALL);

			proxy.executeStatement(boundStatement);
									
			return 	new KeyRange(startKeyRange,endKeyRange);			
		}		
	}
	
	private Long lookupDomainKey(String domain,String dataset,String physicalNodeId){
		
		String selectQuery = SELECT_COUNTER_CQL;
		
		PreparedStatement stmt = proxy.getPrepareStatement(selectQuery);
        
        BoundStatement boundStatement = stmt.bind();
        
        int parmIdx = 0;
            
        boundStatement.setString(parmIdx++, domain);
        boundStatement.setString(parmIdx++, dataset);
        boundStatement.setString(parmIdx++, physicalNodeId);
        
        ResultSet resultSet = proxy.executeStatement(boundStatement);

        Long domainKey = null;
		
		if(resultSet!=null){
			Row row = resultSet.one();
			
			if(row!=null){
				domainKey = row.getLong("domainkeyCounter");
			}
		}
		
		return domainKey;
	}

    /* (non-Javadoc)
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        logger.info("Get Cassandra proxy");

        // Initialise/fetch proxy
        proxy = cassandraSessionHelper.getProxy();
        
        logger.info("Got Cassandra proxy: {}", proxy);
    }
}
