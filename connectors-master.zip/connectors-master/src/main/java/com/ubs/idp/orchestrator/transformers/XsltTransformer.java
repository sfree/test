package com.ubs.idp.orchestrator.transformers;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XsltTransformer implements XmlTransformer{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(XsltTransformer.class);
	private Transformer transformer;
	
	public XsltTransformer(String xslt) throws TransformerConfigurationException {
		TransformerFactory factory = TransformerFactory.newInstance();
		Source sourceXslt = new StreamSource(new StringReader(xslt));
		transformer = factory.newTransformer(sourceXslt);
	}

	@Override
	public String transformXmlMessage(String xml) throws TransformerException {
		String transformedMessage = null;
		if (xml != null) {
			LOGGER.debug("Performing XSLT Transformation on generated XML Message");
			StringWriter xmlOutWriter = new StringWriter(); 
			Source originalXml = new StreamSource(new StringReader(xml));
			transformer.transform(originalXml, new StreamResult(xmlOutWriter));
			transformedMessage = xmlOutWriter.toString();
		}
		
		return transformedMessage;
	}

}
