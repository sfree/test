package com.ubs.idp.lsdb.model;

/**
 * JiBX POJO
 * @author mcminnp
 */
public class General {
    private EntityType entityType;

    public EntityType getEntityType() {
        return entityType;
    }

    public void setEntityType(EntityType entityType) {
        this.entityType = entityType;
    }
}
