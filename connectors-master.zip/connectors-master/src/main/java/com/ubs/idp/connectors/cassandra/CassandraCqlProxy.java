package com.ubs.idp.connectors.cassandra;

import java.util.List;
import java.util.Map;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Statement;

/**
 * This is a simple Cassandra proxy interface
 */
public interface CassandraCqlProxy {

	/**
	 * Connect and create a session. This will be the real proxy to the
	 * Cassandra cluster.
	 * 
	 * @return Whether the connection was successful
	 */
	public boolean connect();
	
	
	/**
	 * Shut down underlying session
	 */
	public void shutdown();

	/**
	 * Assume that we are connected if we have a non-null session (a bit naive)
	 * 
	 * @return
	 */
	public boolean isConnected();

    /**
     * Use this to execute DDL or DML on the Cassandra store.
     * 
     * @deprecated
     * @param cqlStatement
     *            A valid CQL statement
     * @return
     */
    public ResultSet executeStatement(String cqlStatement);

	/**
	 * Use this to execute DDL or DML on the Cassandra store.
	 * If possible, use the prepared statement interface method for improved performance
	 * 
	 * @param cqlStatement   A valid CQL statement
     * @param consistencyLevel Cassandra consistency level required
     * @return
     */
    public ResultSet executeStatement(String cqlStatement, ConsistencyLevel consistencyLevel);
    
    /**
     * @param statement
     * @return
     */
    public ResultSet executeStatement(Statement statement);
    
	/**
	 * Use this to fire a query on the Cassandra store. At present this only
	 * supports String, Date, and Long cell values.
	 * 
	 * @param cqlQuery
	 *            A valid CQL statement
	 * @return An ordered list of order cell-value pairs
	 */
	public List<Map<String, Object>> executeQuery(final String cqlQuery);

	/**
	 * Return true if we have added a missing CF
	 * 
	 * @param columnFamilyName
	 * @return
	 */
	public boolean addColumnFamilyIfNeeded(String columnFamilyName);
	
	/**
	 * Return true if we have added a missing CF
	 * 
	 * @param columnFamilyName
	 * @return
	 */
	public boolean addColumnFamilyIfNeeded(String columnFamilyName,String createTableCql);
	

	/** This is generic method to return PreapreStatement Object for used with Batch insert
	 * @param cql- a valid cql statement
	 * @return
	 */
	public PreparedStatement getPrepareStatement(String cql);

    /**
     * Executes provided Batch statement in Cassandra store
     *
     * @param batchStatement
     * @return
     */
    ResultSet executeStatement(BatchStatement batchStatement);
}
