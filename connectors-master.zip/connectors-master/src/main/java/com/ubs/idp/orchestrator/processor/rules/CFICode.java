package com.ubs.idp.orchestrator.processor.rules;


/**
 * This implementation is based on the CFI Codes supplied by DMS-I.
 * These are 8 characters long  
 * @author haniffsy
 *
 */
public class CFICode {
	
	private String code;
	
	static final int CFI_SIZE = 8;
	
	/**
	 * @param code
	 */
	public CFICode(final String code) {
		this.code = code;
	}
	

	
	/**
	 * The caller will supply the index of the actual code 
	 * @param position The absolute position in the code string BEGINNING WITH 1
	 * @return The code value
	 */
	public String atPosition(int position) {
		// no code => no atPosition()
		if (null == this.code) 
			return null;
		
		// position too low => no atPosition()		
		if (position < 1) 
			return null;
		
		// position too high => no atPosition()		
		if (position > this.code.length())
			return null;
		
		// all good
		return String.valueOf(this.code.charAt(position-1));
		
	}
	
	
	/**
	 * @param position
	 * @param matches
	 * @return
	 */
	public boolean matchesAtPosition(int position, String... matches) {
		boolean found = false;
		
		String charAtPos = this.atPosition(position);
		
		if (matches != null && charAtPos != null) {
			
			for (int i = 0; i < matches.length; i++) {
				if (matches[i] != null && matches[i].equals(charAtPos)) {
					found = true;
					break;
				}
			}
			
		}
		
		return found;
	}
	
	public boolean startsWith(String matches) {
		return code != null ? code.startsWith(matches) : false;
	}
	
	public String toString() {
		return this.code;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		return result;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		CFICode other = (CFICode) obj;
		if (code == null) {
			if (other.code != null) return false;
		}
		else if (!code.equals(other.code)) return false;
		return true;
	}
	
	

}
