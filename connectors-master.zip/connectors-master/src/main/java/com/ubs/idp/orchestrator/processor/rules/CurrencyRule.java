package com.ubs.idp.orchestrator.processor.rules;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ubs.idp.domainRegistry.DomainRegistry;
import com.ubs.idp.domainRegistry.common.DomainKey;

/**
 * Currency rules
 *
 * @author loverids
 */
@Component
public class CurrencyRule extends DerivationRuleTemplate implements ItemProcessor<Map<String,Object>,Map<String,Object>>
{	
	public final static String DERIVED_UBS_ID = "derived.ubsId";
	public final static String DERIVED_CCY_CODE = "derived.CcyCode";
	public final static String DERIVED_IS_MINOR_CCY_CODE = "derived.isMinorCcyCode";
	public final static String ISO_NAME = "isoName";
	public final static String MAJOR_CCY_CODE = "majorCcyCode";
	public final static String MINOR_CCY_CODE = "minorCcyCode";
	public final static String CCY_CODE_DELIM = "-";
	
	@Autowired
	@Qualifier("domainRegistry")
	DomainRegistry domainRegistry;
	
    @Override
    public Map<String, Object> applyRules(Map<String, Object> inputFields) 
    {
        Map<String,Object> derivedFields = new HashMap<String,Object>();

        String isoName = (null == inputFields.get(ISO_NAME)) ? null : inputFields.get(ISO_NAME).toString();
        String majorCCYCode = (null == inputFields.get(MAJOR_CCY_CODE)) ? null : inputFields.get(MAJOR_CCY_CODE).toString();
        String minorCCYCode = (null == inputFields.get(MINOR_CCY_CODE)) ? null : inputFields.get(MINOR_CCY_CODE).toString();
        
        // Generate negative sequence for UBS ID
        DomainKey domainKey = domainRegistry.createDomainKey("Currency", "CURRENCY", "CURRENCY.IDP", isoName);
       	derivedFields.put(DERIVED_UBS_ID, domainKey.getDomainKey());
       	
       	// Derived CCY Code holds both major and minor CCY codes
       	String derivedCCYCode = majorCCYCode;
       	boolean isMinorCCYCode = false;
       	if( minorCCYCode != null && minorCCYCode.trim().length() > 0)
       	{
       		// If there is a minor CCY code we add it and set the flag
       		isMinorCCYCode = true;
       		derivedCCYCode += CCY_CODE_DELIM + minorCCYCode;	
       	}
       	        	
        derivedFields.put(DERIVED_CCY_CODE, derivedCCYCode);
        derivedFields.put(DERIVED_IS_MINOR_CCY_CODE, isMinorCCYCode);
        
        return derivedFields;
    }

    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        return derive(item);
    }
}


