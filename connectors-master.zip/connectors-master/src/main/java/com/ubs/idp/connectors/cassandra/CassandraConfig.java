package com.ubs.idp.connectors.cassandra;

import static com.ubs.idp.encrypt.Crypto.decrypt;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration("cassandraConfig")
@PropertySource({"classpath:application.properties", "classpath:environment-${environment}.properties"})
public class CassandraConfig {

	@Value("${cassandra.host}")
	private String cassandraHost;
	
	@Value("${cassandra.keyspace}")
	private String cassandraKeyspace;
	
	@Value("${cassandra.user:}")
	private String cassandraUser;
	
	@Value("${cassandra.password:}")
	private String cassandraPassword;
    
    @Value("${cassandra.defaultConsistencyLevel:}")
    private String defaultConsistencyLevel;

	private String decryptedCassandraPassword;
	
	public String getCassandraHost() {
		return cassandraHost;
	}

	public String getCassandraKeyspace() {
		return cassandraKeyspace;
	}

	public String getCassandraUser() {
		return cassandraUser;
	}

	public String getCassandraPassword() {
		return cassandraPassword;
	}
	
	public String getDecryptedCassandraPassword() {
		if (decryptedCassandraPassword == null) {
			decryptedCassandraPassword = decrypt(cassandraPassword);
		}
		return decryptedCassandraPassword;
	}

    public String getDefaultConsistencyLevel() {
        return defaultConsistencyLevel;
    }

    public void setDefaultConsistencyLevel(String defaultConsistencyLevel) {
        this.defaultConsistencyLevel = defaultConsistencyLevel;
    }
}
