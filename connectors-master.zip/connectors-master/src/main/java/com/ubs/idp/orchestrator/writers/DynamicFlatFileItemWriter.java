package com.ubs.idp.orchestrator.writers;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.batch.item.file.transform.LineAggregator;
import org.springframework.core.io.UrlResource;

import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DynamicFlatFileItemWriter implements ItemStream, ItemWriter<FieldSet> {

    private Map<String, FlatFileItemWriter<FieldSet>> writers = new HashMap<>();

    private LineAggregator<FieldSet> lineAggregator;

    private String splitField;

    private ExecutionContext executionContext;

    @Override
    public void open(ExecutionContext executionContext) throws ItemStreamException {
        this.executionContext = executionContext;
    }

    @Override
    public void update(ExecutionContext executionContext) throws ItemStreamException {
    }

    @Override
    public void close() throws ItemStreamException {
        for(FlatFileItemWriter f:writers.values()){
            f.close();
        }
    }

    @Override
    public void write(List<? extends FieldSet> items) throws Exception {
        for (FieldSet item : items) {
            FlatFileItemWriter<FieldSet> ffiw = getFlatFileItemWriter(item);
            ffiw.write(Arrays.asList(item));
        }
    }

    public LineAggregator<FieldSet> getLineAggregator() {
        return lineAggregator;
    }

    public void setLineAggregator(LineAggregator<FieldSet> lineAggregator) {
        this.lineAggregator = lineAggregator;
    }


    public FlatFileItemWriter<FieldSet> getFlatFileItemWriter(FieldSet item) {
        String key = item.readString(splitField);
        if(key.isEmpty()){
            key="NO_VALUE_SET";
        }

        String splitFieldFileName = splitField+"_"+key;

        FlatFileItemWriter<FieldSet> ffiw = writers.get(splitFieldFileName);
        if(ffiw == null){
            ffiw = new FlatFileItemWriter<>();
            ffiw.setLineAggregator(lineAggregator);
            try {
                UrlResource resource = new UrlResource("file:"+splitFieldFileName);
                ffiw.setResource(resource);
                ffiw.open(executionContext);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            writers.put(splitFieldFileName, ffiw);
        }
        return ffiw;
    }

    public void setSplitField(String splitField) {
        this.splitField = splitField;
    }

}