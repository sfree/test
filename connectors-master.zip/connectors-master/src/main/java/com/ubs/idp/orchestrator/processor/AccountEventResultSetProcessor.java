package com.ubs.idp.orchestrator.processor;

import static com.ubs.idp.orchestrator.util.AccountEventConstants.EVENT_ACCOUNT_CODE;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.EVENT_ACCOUNT_ID;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.EVENT_DOWNSTREAM_SP_ID;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.EVENT_ID;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.EVENT_MF_HOST;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.EVENT_RETRY_COUNT;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.LOA_TYPE;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import javax.validation.Validation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.stereotype.Service;

import com.google.common.collect.Sets;
import com.ubs.idp.base.IdpBoundary;
import com.ubs.idp.connectors.spring.batch.writers.AccountEventResultSetWriter;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.orchestrator.util.MetaDataRetrieverUtil;

@IdpBoundary
@Service
public class AccountEventResultSetProcessor implements ItemProcessor<Map<String, Object>, List<AccountEventResultSetWriter.AccountEventResultSets>>, InitializingBean {

    public static final String COLUMN_DATA_TYPE = "type";
    @Autowired
    private MetaDataRetrieverUtil metaDataRetrieverUtil;
    private Map<String, SimpleDriverDataSource> locationBasedDataSources;
    //To map column type from metadata to Sql types
    private static Map<String, Integer> sqlTypes = new HashMap<>();
    static {
        sqlTypes.put("VARCHAR", Types.VARCHAR);
        sqlTypes.put("CHAR", Types.CHAR);
        sqlTypes.put("INTEGER", Types.INTEGER);
    }

    public MetadataService mdsClient;
    private Map<String, Map<String, Map<String, Object>>> storedProc;
    //private LinkedHashMap <String, List<String>> dataSets = new LinkedHashMap <>();
    private List<Map<String,String>> datasetsDetails;

    private static  final Logger logger = LoggerFactory.getLogger(AccountEventResultSetProcessor.class);
    private String propagationCode;
    private int retryCount;
    private long id;
    private boolean isResultInValid;
    private long loaType;


    @Override
    public List<AccountEventResultSetWriter.AccountEventResultSets> process(Map<String, Object> mfEvent) throws Exception {
        setItemProcessorEnvironment(mfEvent);
        List<AccountEventResultSetWriter.AccountEventResultSets> resultSetEventData = new ArrayList<>();
        Map<String, Object> resultSetData = getResultSetData(mfEvent, storedProc.keySet().iterator().next(), datasetsDetails);
        logger.info("Validating EVENT_ID: " + mfEvent.get(EVENT_ID));
        validateResultSetData(resultSetData);
        if(isResultInValid){
        	return null;        	
        } 
        for (Map <String, String> dataset : datasetsDetails){
            for (String rsId : dataset.keySet()) {
                @SuppressWarnings("unchecked")
                List<Map<String, String>> resultSet = (List<Map<String, String>>) resultSetData.get(rsId);
                if (resultSet!= null){
                    List<String> rsHeaders = mdsClient.getAttributeNamesForDataset(rsId);
                    for (Map<String, String> data : resultSet) {
                        AccountEventResultSetWriter.AccountEventResultSets accountEventResultSets = new AccountEventResultSetWriter.AccountEventResultSets();
                        Map<String, Map<String, String>> map = new HashMap();
                        HashMap<String, Object> copied = (HashMap<String, Object>) ((HashMap) mfEvent).clone();
                        accountEventResultSets.setMappedEvent(copied);
                        map.put(dataset.get(rsId).toString(), (Map<String, String>) data );
                        accountEventResultSets.setResultSets(map);
                        resultSetEventData.add(accountEventResultSets);
                    }

                }
            }
        }
        return resultSetEventData;
    }

    public void setItemProcessorEnvironment(Map<String, Object> mfEvent) {
        id= (Long) mfEvent.get(EVENT_ID);
        propagationCode = String.valueOf(mfEvent.get(EVENT_DOWNSTREAM_SP_ID));
        retryCount =  ((Long) mfEvent.get(EVENT_RETRY_COUNT)).intValue();
        storedProc = mdsClient.getStoredProcedureDetails("PropagationStoredProc"+propagationCode);
        datasetsDetails = mdsClient.getOrderedDatasetDetails("PropagationStoredProc"+propagationCode);
        loaType=(Long)mfEvent.get(LOA_TYPE);
    }

    private Map<String, Object> getResultSetData(Map<String, Object> mfEvent, String procName, List<Map<String,String>> datasetsDetails) {

        SimpleJdbcCall simpleJdbcCall = getLocationBasedMfSimpleJdbcCall((String) mfEvent.get(EVENT_MF_HOST))
                .withProcedureName(procName)
                .withoutProcedureColumnMetaDataAccess()
                .useInParameterNames(getColumnKeys())
                .declareParameters(getSqlParameters());
        for (Map <String, String> dataset : datasetsDetails){
            for (String rsId : dataset.keySet()){
                List<String> columnHeaders = mdsClient.getAttributeNamesForDataset(rsId);
                simpleJdbcCall.returningResultSet(rsId, new ResultSetMapper(rsId,columnHeaders)) ;
            }
        }
        logger.info("Calling Stored proc {} with parameters {}, {} at MF location : {}", procName, mfEvent.get(EVENT_ACCOUNT_ID), mfEvent.get(EVENT_ACCOUNT_CODE),mfEvent.get(EVENT_MF_HOST));
        Map<String, Object> resultSet = simpleJdbcCall.execute(getBindParametersMap(mfEvent));
        return resultSet;
    }


    /**
     * Validates the output of sp. Validation logic checks if the number all columns received are exactly as what was expected as per
     * metadata
     * @param resultSetData : Map of all maps for reslutset received  via stored proc call
     * @throws Validation Exception
     */
    public void validateResultSetData(Map<String, Object> resultSetData){
        for (Map <String, String> dataset : datasetsDetails){
            for (String rsId : dataset.keySet()){
                List<String> columnHeaders = mdsClient.getAttributeNamesForDataset(rsId);
                HashSet<String> columnHeadersSet=new HashSet<String>(columnHeaders);             
                Object resultSetCol= resultSetData.get(rsId);
                if(resultSetCol==null){
                	 isResultInValid=true;
                	 logger.info("Validation failed:" + " Due to absence of resultset: " + rsId); 
                	 return;
                }
				ListIterator<Map<String,String>> mapListIterator = ((List<Map<String, String>>) resultSetCol).listIterator();                
                if (mapListIterator.hasNext()) {
                    Map<String,String> record=mapListIterator.next();
                    Set<String> spResultSet=record.keySet();
                    Set delta=Sets.difference(columnHeadersSet, spResultSet);
                    StringBuilder colsToLog=new StringBuilder();
                    if(spResultSet.size()>columnHeadersSet.size()){
                        isResultInValid=true;
                        for(Object col:spResultSet.toArray()){
                            colsToLog.append(col.toString()+",");
                        }
                        logger.info("Validation failed: " + "Extra Unknown columns recieved in SP resultset with " + rsId + " Columns received are " + colsToLog.toString());
                        return;
                    }
                    if(!delta.isEmpty()){
                        colsToLog=new StringBuilder();
                        for(Object col:delta.toArray()){
                            colsToLog.append(col.toString()+",");
                        }
                        isResultInValid=true;
                        logger.info("Validation failed: " + "Columns not received are " + colsToLog);
                        return;
                    }                    
                }
            }
        }
    }

    /*  **REVIEW**: Is there a way to make it generic? */
    private HashMap<String, Object> getBindParametersMap(Map mfEvent) {

        HashMap<String, Object> params = new HashMap<>();
        params.put(getColumnKeys()[0], String.valueOf(mfEvent.get(EVENT_ACCOUNT_ID)));
        params.put(getColumnKeys()[1], String.valueOf(mfEvent.get(EVENT_ACCOUNT_CODE)));
        params.put(getColumnKeys()[2], null);
        params.put(getColumnKeys()[3], null);
        return params;
    }

    private String[] getColumnKeys() {

        Map<String, Map<String, Object>> columns = storedProc.entrySet().iterator().next().getValue();
        return columns.keySet().toArray(new String[0]);
    }

    private SqlParameter[] getSqlParameters() {

        Map<String, Map<String, Object>> columns = storedProc.entrySet().iterator().next().getValue();
        Set<Map.Entry<String,Map<String,Object>>> entries = columns.entrySet();
        Iterator<Map.Entry<String,Map<String,Object>>> iterator = entries.iterator();
        SqlParameter[] sqlParameter = new SqlParameter[entries.size()];
        int index = 0;
        while (iterator.hasNext()) {
            Map.Entry<String, Map<String, Object>> nextEntry = iterator.next();
            sqlParameter[index] = new SqlParameter(nextEntry.getKey(),
                    sqlTypes.get(nextEntry.getValue().get(COLUMN_DATA_TYPE)));
            index++;
        }
        return sqlParameter;
    }

    SimpleJdbcCall getLocationBasedMfSimpleJdbcCall (String mfLocation) {

        return  new SimpleJdbcCall(locationBasedDataSources.get(mfLocation));
    }

    public void setLocationBasedDataSources(Map<String, SimpleDriverDataSource> locationBasedDataSources) {
        this.locationBasedDataSources = locationBasedDataSources;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    static class ResultSetMapper implements RowMapper<Map<String, String>> {
        private String rsId;
        private List<String> columnHeaders;

        ResultSetMapper (String rsId, List <String> columnHeaders){
            this.rsId= rsId;
            this.columnHeaders = columnHeaders;
        }
        @Override
        public Map<String, String> mapRow(ResultSet resultSet, int i) throws SQLException {

            int columnCount = resultSet.getMetaData().getColumnCount();
            Map<String, String> mappedResultSet = new HashMap<>();
            for (int j=1; j <= columnCount; j++) {
            	// bit type should be 1/0 and not true/false
            	if (resultSet.getMetaData().getColumnType(j) == Types.BIT) {
            		mappedResultSet.put(columnHeaders.get(j-1).toString(), getBitValue(resultSet.getObject(j)));
            	}
            	else {
            		mappedResultSet.put(columnHeaders.get(j-1).toString(),
                            resultSet.getObject(j) == null ? "" : resultSet.getObject(j).toString());
            	}
            }
            return mappedResultSet;
        }
        
        public String getBitValue(Object bitValue) {
        	String intBitValue = "";
    		if (bitValue != null) {
    			boolean boolBitValue = (boolean) bitValue;
    			if (boolBitValue)
        			intBitValue = "1";
        		else if (!boolBitValue)
        			intBitValue = "0";
    		}
    		return intBitValue;
        }

    }

    public void setMdsClient(MetadataService mdsClient) {
        this.mdsClient = mdsClient;
    }

    public void setStoredProc(Map<String, Map<String, Map<String, Object>>> storedProc) {
        this.storedProc = storedProc;
    }

    @AfterStep
    public ExitStatus  afterStep(StepExecution stepExecution) {
        JobExecution stepContext = stepExecution.getJobExecution();
        logger.info("Setting context with idpid:{}, propagation code:{}, retrycount:{} and eventValidt:{} in afterStep of Stored Proc call (step 2) ",id,propagationCode,retryCount,isResultInValid);
        stepContext.getExecutionContext().put("id", id);
        stepContext.getExecutionContext().put("propCode", propagationCode);
        stepContext.getExecutionContext().put("retryCount", retryCount);
        stepContext.getExecutionContext().put("isEventInValid", isResultInValid);
        stepContext.getExecutionContext().put("loaType", loaType);
        if(isResultInValid){
        	return new ExitStatus("FAILED");        	
        }        
        return stepExecution.getExitStatus();
    }

    public boolean isResultInValid() {
        return isResultInValid;
    }

    public void setResultInValid(boolean isResultInValid) {
        this.isResultInValid = isResultInValid;
    }

}
