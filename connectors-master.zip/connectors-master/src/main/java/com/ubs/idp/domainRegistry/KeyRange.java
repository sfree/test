package com.ubs.idp.domainRegistry;

public class KeyRange {
	
	private long keyStartRange = 0;
	private long keyEndRange = 0;
	
	public KeyRange(long keyStartRange,long keyEndRange) {
		
		this.keyStartRange = keyStartRange;
		this.keyEndRange = keyEndRange;
	}

	/**
	 * @return the keyStartRange
	 */
	public long getKeyStartRange() {
		return keyStartRange;
	}

	/**
	 * @param keyStartRange the keyStartRange to set
	 */
	public void setKeyStartRange(int keyStartRange) {
		this.keyStartRange = keyStartRange;
	}

	/**
	 * @return the keyEndRange
	 */
	public long getKeyEndRange() {
		return keyEndRange;
	}

	/**
	 * @param keyEndRange the keyEndRange to set
	 */
	public void setKeyEndRange(long keyEndRange) {
		this.keyEndRange = keyEndRange;
	}	
}
