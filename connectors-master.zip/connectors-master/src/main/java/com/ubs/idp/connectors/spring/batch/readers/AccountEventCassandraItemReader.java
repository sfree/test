package com.ubs.idp.connectors.spring.batch.readers;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.ubs.idp.connectors.BaseConnector;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;
import com.ubs.idp.connectors.spring.batch.writers.AccountEventResultSetWriter;

/**
 * Spring batch Cassandra reader
 * Can be refactored to extend CassandraItemReader and override only open and read method after CassandraItemReader is modified to accept Object instead of FieldSet
 */
public class AccountEventCassandraItemReader extends BaseConnector implements ItemReader<AccountEventResultSetWriter.AccountEventResultSets>, ItemStream, InitializingBean {

    public static final String RESULT_SET_TYPE = "resultsettype";
    public static final String RESULT_SET_NO_ID = "resultsetno";
    public static final String RESULT_SET_ROW_ID= "recordno";
    public static final String RESULT_SET_MAP_ID = "resultsetmap";
    public static final String RESULT_SET_TRANSFORMED_MAP_ID= "transformed_resultsetmap";

    public static final String CASSANDRA_TEXT_DATA_TYPE = "text";
    public static final String CASSANDRA_BIGINT_DATA_TYPE = "bigint";
    public static final String CASSANDRA_INT_DATA_TYPE = "int";
    public static final String CASSANDRA_MAP_DATA_TYPE = "map<text, text>";
    private long rowCount = 0;
    private long id;
    private boolean runnedOnce;
    private Map<String, String> columnsAndTypes;

    @Autowired
    @Qualifier("cassandraSessionHelper")
    private CassandraSessionHelper cassandraSessionHelper;


    protected CassandraCqlProxy proxy;

    private String cql;
    private String attributeNames[];
    private String fieldSeparator = DelimitedLineTokenizer.DELIMITER_TAB;

    private ResultSet resultSet = null;

    private Logger logger = LoggerFactory.getLogger(AccountEventCassandraItemReader.class);

    /**
     * Bare bones constructor
     */
    public AccountEventCassandraItemReader() {
        if (logger.isDebugEnabled()) logger.debug("Initialise Cassandra reader");
    }

   
    /**
     * @return the fieldSeparator
     */
    public String getFieldSeparator() {
        return fieldSeparator;
    }

    /**
     * @param fieldSeparator the fieldSeparator to set
     */
    public void setFieldSeparator(String fieldSeparator) {
        this.fieldSeparator = fieldSeparator;
    }

    /**
     * @return the attributeNames
     */
    public String[] getAttributeNames() {
        return attributeNames;
    }

    public void setAttributeNames(
            String[] attributeNames) {
        this.attributeNames = attributeNames;
    }

    public void setAttributeNames(String attributeNames) {
        this.attributeNames = attributeNames.split(DelimitedLineTokenizer.DELIMITER_COMMA);
    }

    /**
     * Return number of rows read
     * @return
     */
    public long getRowCount() {
        return rowCount;
    }

    @Override
    public AccountEventResultSetWriter.AccountEventResultSets read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
        if (logger.isDebugEnabled()) logger.debug("Cassandra Read called for ID :{}" ,id);
        AccountEventResultSetWriter.AccountEventResultSets spResult = null;
        Map<Integer,Map<Integer,Map<String,String>>> resultSetsMap=new TreeMap<Integer,Map<Integer,Map<String,String>>>();
        Map<Integer,Map<Integer,Map<String,String>>> transformedResultSetsMap=new TreeMap<Integer,Map<Integer,Map<String,String>>>();
        if (resultSet != null) {
        	spResult = new AccountEventResultSetWriter.AccountEventResultSets();
            HashMap<Integer, String> uniqueResultsetType = new HashMap<Integer,String>();
            Iterator<Row> rowIt = resultSet.iterator();
            while (rowIt.hasNext() && !runnedOnce) {
                Row row =rowIt.next();
                int rsNo = (Integer) getValueFromRow(RESULT_SET_NO_ID, columnsAndTypes.get(RESULT_SET_NO_ID), row);
                int rowNo = (Integer) getValueFromRow(RESULT_SET_ROW_ID, columnsAndTypes.get(RESULT_SET_ROW_ID), row);
                if (!uniqueResultsetType.containsKey( getValueFromRow(RESULT_SET_NO_ID, columnsAndTypes.get(RESULT_SET_NO_ID), row))){
                    uniqueResultsetType.put(
                            (Integer) getValueFromRow(RESULT_SET_NO_ID, columnsAndTypes.get(RESULT_SET_NO_ID), row),
                            (String) getValueFromRow(RESULT_SET_TYPE, columnsAndTypes.get(RESULT_SET_TYPE), row));
                }
                Map<String,String> transformedResultMap= (Map) getValueFromRow(RESULT_SET_TRANSFORMED_MAP_ID,
                        columnsAndTypes.get(RESULT_SET_TRANSFORMED_MAP_ID), row);
                if(!transformedResultMap.isEmpty()) {
                	Map<Integer,Map<String,String>> rTransformed = transformedResultSetsMap.get(rsNo);
                	if(rTransformed==null){
                    	rTransformed=new TreeMap<Integer,Map<String,String>>();
                    	rTransformed.put(rowNo,transformedResultMap);
                    	transformedResultSetsMap.put(rsNo,rTransformed);
                    }else{
                    	rTransformed.put(rowNo,transformedResultMap);
                    }
                    spResult.setTransformedResultSetsMap(transformedResultSetsMap);
                }
                Map<String,String> spResultMap= (Map) getValueFromRow(RESULT_SET_MAP_ID,
                        columnsAndTypes.get(RESULT_SET_MAP_ID), row);
                Map<Integer,Map<String,String>> r= resultSetsMap.get(rsNo);
                if(r==null){
                    r=new TreeMap<Integer,Map<String,String>>();
                    r.put(rowNo,spResultMap);
                    resultSetsMap.put(rsNo,r);
                }else{
                    r.put(rowNo,spResultMap);
                }
                Map<String, Object> events = new HashMap<>();
                Iterator<Map.Entry<String,String>> iterator = columnsAndTypes.entrySet().iterator();
                while (iterator.hasNext()) {
                    Map.Entry<String, String> nextEntry = iterator.next();
                    events.put(nextEntry.getKey(), getValueFromRow(nextEntry, row));
                }
                spResult.setMappedEvent(events);
                spResult.setResultSetsMap(resultSetsMap);
                spResult.setUniqueResultsetType(uniqueResultsetType);
                rowCount++;
            }
        }
        //TODo: Move this in to a generic util Method ReadOnceReader()
        if(runnedOnce){
            return null;
        }else{
            runnedOnce=true;
            if (resultSet != null) {
            	return	spResult;
            }
            else {
            	throw new Exception("Emtpy result returned from Cassandra for event " + id + " which passed validation");
            }
        }

    }

    @BeforeStep
    public void beforeStep(StepExecution stepExecution){
        JobExecution stepContext = stepExecution.getJobExecution();
        id = (long) stepContext.getExecutionContext().get("id");
    }




    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#open(org.springframework.batch.item.ExecutionContext)
     */
    @Override
    public void open(ExecutionContext executionContext){

        if (logger.isDebugEnabled()) logger.debug("Open Cassandra reader...");

        rowCount = 0;
        String cqlQuery=cql+id+";";
        if (logger.isDebugEnabled()) logger.debug("Run CQL query {}...", cqlQuery);
        resultSet = proxy.executeStatement(cqlQuery);
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#close()
     */
    public void close() {
        if (logger.isDebugEnabled()) logger.debug("Closing Cassandra reader");

        if (resultSet != null) {
            // TODO: Close!?
        }
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#update(org.springframework.batch.item.ExecutionContext)
     */
    @Override
    public void update(ExecutionContext executionContext)
            throws ItemStreamException {
        if (logger.isDebugEnabled()) logger.debug("Update exectution context");
    }

    /* (non-Javadoc)
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {

        proxy=cassandraSessionHelper.getProxy();
        // TODO: Add property assertions
    }

    private Object getValueFromRow(Map.Entry<String, String> nextEntry, Row row) throws SQLException {

        return getValueFromRow(nextEntry.getKey(), nextEntry.getValue(), row);
    }

    private Object getValueFromRow(String key, String type, Row row) throws SQLException {

        Object value;
        switch (type) {
            case CASSANDRA_TEXT_DATA_TYPE: value = row.getString(key); break;
            case CASSANDRA_BIGINT_DATA_TYPE: value = row.getLong(key); break;
            case CASSANDRA_INT_DATA_TYPE: value = row.getInt(key); break;
            case CASSANDRA_MAP_DATA_TYPE: value = row.getMap(key, String.class, String.class); break;
            default : value = null;
        }
        return value;
    }

    public void setColumnsAndTypes(Map<String, String> columnsAndTypes) {
        this.columnsAndTypes = columnsAndTypes;
    }


	public String getCql() {
		return cql;
	}


	public void setCql(String cql) {
		this.cql = cql;
	}
}
