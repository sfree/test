package com.ubs.idp.connectors.spring.batch.readers;

import com.ubs.idp.connectors.BaseConnector;
import com.ubs.idp.connectors.HttpClientWrapper;
import com.ubs.idp.connectors.spring.batch.utils.PropertyPreprocessor;
import com.ubs.idp.encrypt.Crypto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.util.StringUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.concurrent.*;

/**
 * Custom Spring Batch item reader
 * @author mcminnp
 */
public class HTTPSourceReader extends BaseConnector implements ItemReader<String>, ItemStream {

    public static final String ERROR_NO_INIT  = "Not initialised? Ensure the init() method is configured";
    public static final String ERROR_NO_URI   = "No uri specified?";
    public static final String ERROR_NO_KEY   = "No appKey specified?";
    public static final String ERROR_NO_ENV   = "No rcasEnv specified?";
    public static final String ERROR_NO_USER  = "No username specified?";
    
    public static final int DEFAULT_SECURE_PORT = 443;
    public static final int DEFAULT_READ_TIMEOUT = 1000 * 60 * 5; // default 5 mins
    
    
    /*
     * Properties from Spring context/injection
     */
    private String  authUri;            // Short URI to prime authentication via SSO (see IDP-343)
    private String  uri;                // Main URI used to fetch business data
    private boolean skipHeader = false;
    private String  username;
    private String  password;
    private String  rcasEnv;
    private String  appKey;
    private long readTimeout   = DEFAULT_READ_TIMEOUT;
    
    private PropertyPreprocessor urlPreProcessor = null;

    /*
     * Internal operation
     */
    private HttpClientWrapper httpClient = null; 
    private boolean initialised = false;
    private BufferedReader in;
    private long rowCount = 0;

    private Logger logger = LoggerFactory.getLogger(HTTPSourceReader.class);
    
    /**
     * Executor for reading in a non blocking way so that we can
     * issue timeouts
     */
    private ExecutorService executor = Executors.newFixedThreadPool(2);
    
    /**
     * Bare bones constructor
     */
    public HTTPSourceReader() {
        super();
    }
    
    /**
     * Construct and set HTTP client
     * @param httpClient
     */
    public HTTPSourceReader(HttpClientWrapper httpClient) {
        super();
        this.httpClient = httpClient;
    }

    /**
     * Set the URI for the HTTP source
     * @param uriIn
     */
    public void setUri(String uriIn) {
        
        if (urlPreProcessor != null) {
            uri = urlPreProcessor.preProcess(uriIn);
        } else {
            uri = uriIn;
        }
    }
    
    /**
     * @param authUri the authUri to set
     */
    public void setAuthUri(String authUri) {
        this.authUri = authUri;
    }

    /**
     * Set the URI for the HTTP source
     * @param uri
     * @throws URISyntaxException 
     */
    public void setUrl(URL url) throws URISyntaxException {
        setUri(url.toURI().toString());
    }

    /**
     * Set true if header row is to be skipped
     * @param skipHeader the skipHeader to set
     */
    public void setSkipHeader(boolean skipHeader) {
        this.skipHeader = skipHeader;
        logger.debug("Skip header option set to '" + this.skipHeader + "'");
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @param password the encrypted password to set
     */
    public void setPassword(String password) {
        this.password = Crypto.decrypt(password);
    }
    
    /**
     * Set RCAS env ("DEV", "UAT" or "PROD")
     * @param rcasEnv the rcasEnv to set
     */
    public void setRcasEnv(String rcasEnv) {
        this.rcasEnv = rcasEnv;
    }

    /**
     * @param appKey the appKey to set
     */
    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    /**
     * @param urlPreProcessor the urlPreProcessor to set
     */
    public void setUrlPreProcessor(PropertyPreprocessor urlPreProcessor) {
        this.urlPreProcessor = urlPreProcessor;
    }
    
    /**
     * 
     * @return
     */
    public long getReadTimeout()
	{
		return readTimeout;
	}

    /**
     * @param readTimeout
     */
	public void setReadTimeout(long readTimeout)
	{
		this.readTimeout = readTimeout;
	}

	/**
     * Return number of rows read
     * @return
     */
    public long getRowCount() {
        return rowCount;
    }

    /**
     * Return true if connected
     * @return
     */
    public boolean isConnected() {
        boolean open = false;

        if (in == null) {
            return open;
        }

        try {
            open = in.ready();
        } catch (IOException e) {
            open = false;
        }

        return open;
    }

    /**
     * @param httpClient the httpClient to set
     */
    public void setHttpClient(HttpClientWrapper httpClient) {
        this.httpClient = httpClient;
    }

    /**
     * Called via init-method Spring bean configuration 
     * @throws Exception
     */
    public void init() throws Exception {
        rowCount = 0;

        // Check basic config
        
        checkConfig();

        logger.debug("Initialise HTTP reader for url '" + uri + "'");

        if (uri == null || uri.length() == 0) {
            logger.error("Missing/invalid uri?");
            throw new IllegalStateException(ERROR_NO_URI);
        }

        try {
            logger.debug("Connecting to HTTP endpoint...");
            
            // Default HTTP client if not injected 
            if (httpClient == null) {
                httpClient = new HttpClientWrapper();
                httpClient.init(username, password, rcasEnv, appKey);
            }

            initialised = true;
        }catch (Exception e) {
            logger.error("Unexpected exception setting up HTTP client?" + e.getMessage());

            throw e;
        }
    }
    
    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemReader#read()
     */
    @Override
    public String read() throws Exception {
        String res = null;
        
        if (!initialised) {
            logger.warn("Init method not configured in Spring - invoking now");
            init();
        }

        // This is a valid situation as the last read would have closed and nulled the reader
        if (in == null) {
            throw new Exception("Input stream not open?");
        }

        if (logger.isDebugEnabled()) logger.debug("Reading next line...");
        
    	// Read data with timeout
        Callable<String> readTask = new Callable<String>() {
            @Override
            public String call() throws Exception {
            	try {
            		return in.readLine();
           		}
                catch (IOException e) {
                    logger.error("Error reading line: " + e.getMessage());
                    logger.error("Aborting connection!");
                    close();
                    throw e;
                }
            }
        };
        
    	Future<String> future = executor.submit(readTask);
        
    	try
		{
			res = future.get(readTimeout, TimeUnit.MILLISECONDS);
		}
		catch (TimeoutException e)
		{
			String message = "Timed out reading line. Failed to receive a response after " + readTimeout + "ms";
            logger.error(message);
            logger.error("Aborting connection!");
            
            throw new Exception(message,e);
		}

        if(res != null){
            rowCount ++;
        }
        
        return res;
    }

    /**
     * Sanity check initialisation data
     */
    private void checkConfig() {
        if (uri == null || uri.length() == 0) {
            throw new IllegalStateException(ERROR_NO_URI);
        }

        if (appKey == null || appKey.length() == 0) {
            throw new IllegalStateException(ERROR_NO_KEY);
        }

        if (rcasEnv == null || rcasEnv.length() == 0) {
            throw new IllegalStateException(ERROR_NO_ENV);
        }

        if (username == null || username.length() == 0) {
            throw new IllegalStateException(ERROR_NO_USER);
        }
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#close()
     */
    public void close() {
        try {
            if (in != null) {
                in.close();
            }
        } catch (IOException e) {
            logger.error("Error closing input?!", e);
        } finally {
            in = null;
        }
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#open(org.springframework.batch.item.ExecutionContext)
     */
    @Override
    public void open(ExecutionContext executionContext)
            throws ItemStreamException {
        InputStreamReader is =  null;
        
        if (!StringUtils.isEmpty(authUri)) {
            InputStreamReader authIs = null;
            
            logger.debug("Fetching from authentication URI {}...", authUri);
            
            try {
                authIs = httpClient.getInput(authUri);
    
                BufferedReader authIn = new BufferedReader(authIs);
    
                // Log and discard resulting response data
    
                String buff;
                
                logger.debug("Auth URI response:");
                
                while ((buff = authIn.readLine()) != null) {
                    logger.debug(buff);
                    authIn.readLine();
                }
                
            } catch(Exception e) {
                String msg = "Error opening auth uri '" + authUri + "'?";
                
                throw new ItemStreamException(msg, e);
            } finally {

                try {
                    if (authIs != null) authIs.close();
                } catch (IOException e1) {
                    logger.error("Unexpected exception while closing auth input stream?", e1);
                }
            }
        }

        // Get data as input stream
        
        try {
            is = httpClient.getInput(uri);

            in = new BufferedReader(is);

            // Optionally skip header row

            if (skipHeader) {
                logger.debug("Skip header record...");
                in.readLine();
            }
            
            // Reset row count
            rowCount = 0;
        } catch (Exception e) {
            String msg = "Error opening uri '" + uri + "'?";
            
            try {
                if (is != null) is.close();
            } catch (IOException e1) {
                logger.error("Unexpected exception while closing input stream?", e1);
            }
            
            throw new ItemStreamException(msg, e);
        }
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#update(org.springframework.batch.item.ExecutionContext)
     */
    @Override
    public void update(ExecutionContext executionContext)
            throws ItemStreamException {
        // TODO Auto-generated method stub
        
    }


}
