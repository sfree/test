package com.ubs.idp.connectors.cassandra;

import java.util.Date;
import java.util.Map;
import java.util.Set;

import com.ubs.idp.base.BaseDataObject;
import com.ubs.idp.base.DataObject;
import com.ubs.idp.base.IPayLoad;

/**
 * Decorates a BaseDataObject with the name of the physical table where it
 * should be persisted
 */
public class CassandraDataObject implements DataObject, IPayLoad {
	
	/**
	 * The underlying data object. The P
	 */
	private DataObject base;
	
	/**
	 * The table name where this will be stored 
	 */
	private String tableName;
	
	/**
	 * Make sure we always have a valid base object to delegate to
	 */
	public CassandraDataObject() {
		this.base = new BaseDataObject();
	}

	/* (non-Javadoc)
	 * @see com.ubs.idp.base.DataObject#addKey(java.lang.String, java.lang.String)
	 */
	public void addKey(String keyName, String key) {
		base.addKey(keyName, key);
	}
	
	/**
	 * @param attrName
	 * @param attrValue
	 * @see com.ubs.idp.domain.BaseDataObject#addKey(java.lang.String)
	 */
	public void addAttribute(String attrName, Object attrValue) {
		base.addAttribute(attrName, attrValue);
	}	

	/**
	 * @return
	 * @see com.ubs.idp.domain.BaseDataObject#getKeys()
	 */
	public Map<String,String> getKeys() {
		return base.getKeys();
	}

	/**
	 * @param newKeys
	 * @see com.ubs.idp.domain.BaseDataObject#setKeys(java.util.List)
	 */
	public void setKeys(Map<String,String> newKeys) {
		base.setKeys(newKeys);
	}

	/**
	 * @return
	 * @see com.ubs.idp.domain.BaseDataObject#getAttributes()
	 */
	public Map<String, Object> getAttributes() {
		return base.getAttributes();
	}

	/**
	 * @param newAttributes
	 * @see com.ubs.idp.domain.BaseDataObject#setAttributes(java.util.Map)
	 */
	public void setAttributes(Map<String, Object> newAttributes) {
		base.setAttributes(newAttributes);
	}

	/**
	 * @param compareWith
	 * @return
	 * @see com.ubs.idp.domain.BaseDataObject#getDeltas(com.ubs.idp.domain.BaseDataObject)
	 */
	public Map<String, Object> getDeltas(BaseDataObject compareWith) {
		return base.getDeltas(compareWith);
	}

	/**
	 * @param base the base to set
	 */
	public void setBase(DataObject base) {
		this.base = base;
	}

	/**
	 * @param tableName the tableName to set
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * @return
	 * @see com.ubs.idp.domain.BaseDataObject#hashCode()
	 */
	public int hashCode() {
		return base.hashCode();
	}

	/**
	 * @param obj
	 * @return
	 * @see com.ubs.idp.domain.BaseDataObject#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		return base.equals(obj);
	}

	/**
	 * @return
	 * @see com.ubs.idp.domain.BaseDataObject#toString()
	 */
	public String toString() {
		return base.toString();
	}

	/**
	 * Be helpful and return a way of inserting this object with a CQL statement
	 * @return A CQL statement to insert this bean
	 */
	public String insertStatement() {
		
		if (null == tableName)
			throw new IllegalStateException("Can't create an insert statement without the Cassandra table to insert in to");

		if (null == getKeys() || getKeys().isEmpty())
			throw new IllegalStateException("Can't create an insert statement without primary keys");
	
		Set<String> allKeys = getKeys().keySet();
		Set<String> allCols = getAttributes().keySet();
		
		
		StringBuffer buffy = new StringBuffer();
		buffy.append("INSERT INTO ");
		buffy.append(tableName);
		// first the keys
		buffy.append(" (");
		for (String keyName : allKeys) {
			buffy.append(keyName);
			buffy.append(",");
		}
		buffy = snipComma(buffy);
		// then the columns
		for (String colName : allCols) {
			// don't double add the column
			if (!allKeys.contains(colName)) {
				buffy.append(",");	
				buffy.append(colName);
			}			
		}
		buffy.append(") ");
		// now the values
		buffy.append("VALUES(");
		// first the keys
		for (String keyName : getKeys().keySet()) {
			buffy.append("'");
			buffy.append(getKeys().get(keyName));
			buffy.append("'");
			buffy.append(",");
		}
		buffy = snipComma(buffy);
		// then the columns
		for (String colName : getAttributes().keySet()) {
			if (!allKeys.contains(colName)) {
				buffy.append(",");		
				Object colVal = getAttributes().get(colName);
				
				if (colVal instanceof String || colVal instanceof Date)
					buffy.append("'");
				
				buffy.append(colVal);		// append the column value here
			
				if (colVal instanceof String || colVal instanceof Date)
					buffy.append("'");
			}
		}
		buffy = snipComma(buffy);
		buffy.append(")");
		
		return buffy.toString();
	}
	
	// TODO DRY this up ... repeated from BaseDataObject
	private StringBuffer snipComma(StringBuffer buffy) {
		if (buffy.charAt(buffy.length()-1) == ',')
			buffy.deleteCharAt(buffy.length()-1);
		return buffy;
	}

	public boolean isValid() {
		return (tableName != null && !getKeys().isEmpty());
	}
}
