package com.ubs.idp.orchestrator.tasklets;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Tasklet that calls an JDBC source and gets the maxEventID for the Batch
 * poller
 * 
 * @author sureshkp
 */

public class JdbcEventPollerTasklet implements Tasklet, InitializingBean {

	private BigDecimal maxEventId;
	private int pollerSleepTime;
	private JdbcTemplate jdbcTemplate;
	private static final Logger LOGGER = LoggerFactory.getLogger(JdbcEventPollerTasklet.class);

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	private String query = null;

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public BigDecimal getMaxEventId() {
		return maxEventId;
	}
	
	public int getPollerSleepTime() {
		return pollerSleepTime;
	}
	
	public void setPollerSleepTime(int pollerSleepTime) {
		this.pollerSleepTime = pollerSleepTime;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.batch.core.step.tasklet.Tasklet#execute(org.
	 * springframework.batch.core.StepContribution,
	 * org.springframework.batch.core.scope.context.ChunkContext)
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {

		try {
			LOGGER.debug("Sleeping for {}ms", pollerSleepTime);
			Thread.sleep(pollerSleepTime);
		} catch (InterruptedException e) {
			LOGGER.info("sleep interrupted: {}", e.getMessage());
		}

		maxEventId = jdbcTemplate.queryForObject(query, BigDecimal.class);
		maxEventId = (maxEventId == null) ? BigDecimal.ZERO : maxEventId;
		LOGGER.debug("Max event Id to fetch MF events: {}", maxEventId.toString());
		JobExecution jobContext = chunkContext.getStepContext().getStepExecution().getJobExecution();
		jobContext.getExecutionContext().put("maxEventId", maxEventId);
		return RepeatStatus.FINISHED;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(query, "External command must be set");
	}
}
