package com.ubs.idp.orchestrator.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.transform.DefaultFieldSet;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.util.StringUtils;

public class FieldSetToKeyValueProcessor implements ItemProcessor<FieldSet, FieldSet> {

    private String datasetName;
    private String keyField;

    @Override
    public FieldSet process(FieldSet item) throws Exception {
        String itemValues = StringUtils.arrayToDelimitedString(item.getValues(), ",");
        String keyValue = item.readString(0);
        return new DefaultFieldSet(new String[]{keyValue, datasetName, itemValues}, new String[]{"key", "column1", "value"});
    }


    public void setDatasetName(String datasetName) {
        this.datasetName = datasetName;
    }

    public void setKeyField(String keyField) {
        this.keyField = keyField;
    }
}