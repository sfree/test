package com.ubs.idp.orchestrator.mappers;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by clarkst on 15/04/2014.
 */
public class FieldSetToMapMapper implements FieldSetMapper<Map<String,Object>> {
    @Override
    public Map<String, Object> mapFieldSet(FieldSet fieldSet) throws BindException {

        Map<String, Object> m = new HashMap<String,Object>();
        for(String name : fieldSet.getNames()){
            m.put(name, fieldSet.readString(name));
        }
        return m;
    }
}
