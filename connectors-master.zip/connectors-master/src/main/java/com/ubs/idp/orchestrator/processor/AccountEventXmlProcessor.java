package com.ubs.idp.orchestrator.processor;

import static com.ubs.idp.orchestrator.util.AccountEventConstants.DATA_TYPE;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.DOWNSTREAM_SP_ID;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.DOWNSTREAM_SYSTEM;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.PROPAGATION_SERVICE_IMPL_PREFIX;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.RESULT_SET_IDP_ID;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.RESULT_SET_TYPE;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.XML_RAW_MESSAGE_NAME;
import static com.ubs.idp.orchestrator.util.AccountEventConstants.XML_OUTBOUND_MESSAGE_NAME;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.xml.XMLConstants;
import javax.xml.bind.Marshaller;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ubs.idp.base.IdpBoundary;
import com.ubs.idp.connectors.spring.batch.writers.AccountEventResultSetWriter.AccountEventResultSets;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.orchestrator.parser.Message;
import com.ubs.idp.orchestrator.parser.Message.Header;
import com.ubs.idp.orchestrator.parser.Message.PayloadData;
import com.ubs.idp.orchestrator.transformers.XmlTransformer;

@IdpBoundary
@Service
public class AccountEventXmlProcessor implements ItemProcessor<AccountEventResultSets, AccountEventResultSets>, InitializingBean {

	@Autowired
	@Qualifier(value = "jaxb2Marshaller")
	private org.springframework.oxm.jaxb.Jaxb2Marshaller marshaller;

	@Autowired
	@Qualifier("mdsClient")
	public MetadataService mdsClient;
    private static final Logger LOGGER = LoggerFactory.getLogger(AccountEventXmlProcessor.class);
    
    @Resource
    @Qualifier("transformStrategy")
    private HashMap<String, XmlTransformer> transformStrategy;

	@Override
	public AccountEventResultSets process(AccountEventResultSets accountEventResultSets) throws Exception {
		LOGGER.info("In to Process- Generating Consumer XML Message for IDP ID " + accountEventResultSets.getMappedEvent().get(RESULT_SET_IDP_ID));
		
		Message message =createMessage(accountEventResultSets);
		final StringWriter out = new StringWriter();
		Map<String,String> marshallerProperties=new HashMap<String,String>();
		marshallerProperties.put(Marshaller.JAXB_SCHEMA_LOCATION, "urn:idp:consumer:idp_message.xsd");		
		marshaller.setMarshallerProperties(marshallerProperties);
		marshaller.setSchemaLanguage(XMLConstants.W3C_XML_SCHEMA_INSTANCE_NS_URI);
		marshaller.marshal(message, new StreamResult(out));
		
		
		String rawXml = out.toString();
		/*
		 * DefaultXmlTransformer will return the same XML message without any transformation
		 * This identical XML is stored as the Out Bound Message, and the original (but same) message
		 * is stored as the Raw Message.
		 * 
		 * Even though the same message is duplicated in both the Raw_Message column and the Outbound_Message
		 * column for DefaultXMlTransformer strategy, it was agreed that the simplicity it provides outweighs
		 * the duplicate data and the extra storage needed
		 */
		XmlTransformer xmlFurtherProcessor = transformStrategy.get(accountEventResultSets.getMappedEvent().get(DOWNSTREAM_SP_ID));
		String finalXml = xmlFurtherProcessor.transformXmlMessage(rawXml);
		accountEventResultSets.getMappedEvent().put(XML_RAW_MESSAGE_NAME, rawXml);
		accountEventResultSets.getMappedEvent().put(XML_OUTBOUND_MESSAGE_NAME, finalXml);
		
		return accountEventResultSets;
	}

    /**
     * Returns  XML Message with pay load data and header data wrapped in to xml. 
     * 
     * @param result
     * @return Message
     */
	private Message createMessage(AccountEventResultSets result) {
		LOGGER.info("In to createMessage Method- constructing xml message for IDP ID " + result.getMappedEvent().get(RESULT_SET_IDP_ID));
		Message message = new Message();
		Header header=createHeader(result);
		PayloadData payloadData=createPayloadData(result);		
		message.setHeader(header);
		message.setPayloadData(payloadData);
		return message;
	}

	 /**
     * Returns the pay load data for the XML to be generated. 
     * 
     * @param result
     * @return PayloadData
     */
	
	private PayloadData createPayloadData(AccountEventResultSets result) {
		LOGGER.debug("In to createPayloadData Method- Generating payload Data for IDP ID " + result.getMappedEvent().get(RESULT_SET_IDP_ID));
		PayloadData payloadData = new PayloadData();
		PayloadData.ResultSets resultSets = new PayloadData.ResultSets();
        Map<Integer, Map<Integer, Map<String, String>>> resultSetsMap = result
				.getTransformedResultSetsMap();

		Map<String, Map<String, String>> fieldsMapping = mdsClient.getTransformationMappingforView("ConsumerView"
                + result.getMappedEvent().get(DOWNSTREAM_SP_ID));
		for (Integer resultsetKey : resultSetsMap.keySet()) {
			PayloadData.ResultSets.ResultSet set = new PayloadData.ResultSets.ResultSet();
			PayloadData.ResultSets.ResultSet.Records records = new PayloadData.ResultSets.ResultSet.Records();
			Map<Integer, Map<String, String>> eventRawData = resultSetsMap
					.get(resultsetKey);
			for (Integer recordKey : eventRawData.keySet()) {
				PayloadData.ResultSets.ResultSet.Records.Record record = new PayloadData.ResultSets.ResultSet.Records.Record();
				Map<String, String> fieldData = eventRawData.get(recordKey);
				PayloadData.ResultSets.ResultSet.Records.Record.Fields fields = new PayloadData.ResultSets.ResultSet.Records.Record.Fields();
				for (String fieldkey : fieldData.keySet()) {
					PayloadData.ResultSets.ResultSet.Records.Record.Fields.Field field = new PayloadData.ResultSets.ResultSet.Records.Record.Fields.Field();
					field.setLegacyName(getLegacyName(fieldsMapping, (String) result.getMappedEvent().get(RESULT_SET_TYPE), fieldkey));
					field.setName(fieldkey);				
					field.setValue(fieldData.get(fieldkey));
					fields.getField().add(field);
				}
				record.setFields(fields);
				records.getRecord().add(record);
			}
			set.setRecords(records);
			set.setType(result.getUniqueResultsetType().get(resultsetKey).toString());
			resultSets.getResultSet().add(set);
			payloadData.setResultSets(resultSets);
		}
		return payloadData;
	}

	
	/**
     * Returns the legacy name data for the a given Name.
     * In case no match found legacy name will be set as BLANK. 
     * 
     * @param filedsMapping
     * @param fieldkey
     * @return legacyname
     */
	
	private String getLegacyName(			
			Map<String, Map<String, String>> filedsMapping,
			String resultsetType, String fieldkey) {
		
		Map<String, String> resultsetMapping = null;
		for (String key : filedsMapping.keySet()){
			resultsetMapping=filedsMapping.get(key);
		}
		if(null !=resultsetMapping){
			return resultsetMapping.get(fieldkey);			
		}	
		return "";
	}
	
	   
	 /**
     * Returns the Header data  for the XML to be generated. 
     * 
     * @param result
     * @return Header
     */
     
	private Header createHeader(AccountEventResultSets result) {
		Header header = new Header();
		header.setMessageType(mdsClient.getPropertyMapOfServiceImplementation(PROPAGATION_SERVICE_IMPL_PREFIX+ result.getMappedEvent().get(DOWNSTREAM_SP_ID)).get(DATA_TYPE));
		header.setSystemID((String) result.getMappedEvent().get(DOWNSTREAM_SP_ID));
		header.setMessageID(String.valueOf(result.getMappedEvent().get(RESULT_SET_IDP_ID)));
		header.setSourceSystem(mdsClient.getPropertyMapOfServiceImplementation(PROPAGATION_SERVICE_IMPL_PREFIX + result.getMappedEvent().get(DOWNSTREAM_SP_ID)).get(DOWNSTREAM_SYSTEM));
		return header;
	}

    @Override
    public void afterPropertiesSet() throws Exception {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
