package com.ubs.idp.orchestrator.processor.rules;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ubs.idp.domainRegistry.DomainRegistry;

/**
 * Temporary Rule for DSCURRENCY to get us up and running. Sets the issue.ubsId
 *  tL.countryUbsId to be -1
 *
 * @author loverids
 */
@Component
public class DSCurrencyRule extends DerivationRuleTemplate implements ItemProcessor<Map<String,Object>,Map<String,Object>>
{
	
	@Autowired
	@Qualifier("domainRegistry")
	DomainRegistry domainRegistry;
	
    @Override
    public Map<String, Object> applyRules(Map<String, Object> inputFields) 
    {
        Map<String,Object> derivedFields = new HashMap<String,Object>();

        String isoCode = (null == inputFields.get(DSCURRENCY_ISOCODE)) ? null : inputFields.get(DSCURRENCY_ISOCODE).toString();
        
    	derivedFields.put("issue.ubsId", domainRegistry.createDomainKey("Instrument", isoCode).getDomainKey());
    	//TODO country code
    	derivedFields.put("tL.countryUbsId", domainRegistry.createDomainKey("Country", "DSCURRENCY", "DSCURRENCY.IDP", isoCode).getDomainKey());

        String derivedCashAttribute = (null == isoCode? null: "CASH - " + isoCode);
        
        derivedFields.put(DERIVED_ASSET_CLASS, "CASH");
        
        derivedFields.put(DERIVED_DSCURRENCY_ISSUE_ISIN, derivedCashAttribute);
        derivedFields.put(DERIVED_DSCURRENCY_ISSUE_CUSIP, derivedCashAttribute);
        derivedFields.put(DERIVED_DSCURRENCY_ISSUE_SEDOL, derivedCashAttribute);
        
        derivedFields.put(DERIVED_DSCURRENCY_ISSUE_BONDISSUERTYPE, "CASH");
        derivedFields.put(DERIVED_DSCURRENCY_ISSUEFACTOR, "1");
        derivedFields.put(DERIVED_DSCURRENCY_VALUEFACTOR, "1");
        derivedFields.put(ISSUE_ISSUESIZE, "0");
        derivedFields.put(DERIVED_DSCURRENCY_MINDENOMINATION, "1000");
        derivedFields.put(DERIVED_DSCURRENCY_COUPON_CURRENTCOUPONRATE, "0");
		
		derivedFields.put(DERIVED_SECFUNDING_ISSUERNAME, "TBDByMayank");
        
        return derivedFields;
    }

    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        return derive(item);
    }
}


