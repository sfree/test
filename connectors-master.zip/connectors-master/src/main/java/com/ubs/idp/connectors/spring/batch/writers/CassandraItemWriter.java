package com.ubs.idp.connectors.spring.batch.writers;

import static org.springframework.util.Assert.notEmpty;
import static org.springframework.util.Assert.notNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.Weeks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;

/**
 * @formatter:off
 * <p>Cassandra item writer for Spring batch (based on DAS code)</p>
 * 
 * <p>
 * Operation:
 * </p>
 * <p>
 * <ul>
 *   <li>Pre-create main ([dataset] e.g.: "INDEX") and PK ([dataset]_ e.g. "INDEX_") column families (CFs)</li>
 *   <li>Pre-create reverse index CFs as required (based on metadata: [dataset]_[NN]")</li>
 *   <li>Pre-parse (split and derive keys) for inbound items</li>
 *   <li>Pre-load the OLD rows</li>
 *   <li>For each inbound record:</li>
 *      <ul> 
 *        <li>Insert into main CF (e.g.: "INDEX")
 *            values are:  key=key (see above), column1=[dataset] (e.g.: "INDEX"), value=the raw record</li>
 *        <li>Insert into PK CF (e.g.: "INDEX_")
 *            values are:  key=[dataset] (e.g.: "INDEX"), column1=key from above, value=null/blank</li>
 *       <li>For each queryable value (from MDS):</li>
 *       <ul>
 *         <li>Read the existing reverse index record (if any) from the corresponding <b>dataset_NN</b> table based on the PK (key) in column1</li>
 *         <li>If we have an old value</li>
 *           <ul>
 *             <li>check old vs. new value read from main table in 1.a. above (e.g.: has SEDOL changed?)</li>
 *             <li>If different, delete old value from corresponding <b>dataset_NN</b> CF</li>
 *           </ul>
 *         <li>Insert new record in corresponding <b>dataset_NN</b> CF
 *             values are: key=field value (e.g.: SEDOL), column1=key from above, value=null/blank</li>
 *       </ul>
 *      </ul>
 * </ul>
 * </p>
 * <p>
 * To clarify - so the result will be a wide row: INDEX =&gt; 111, 222, 333
 * </p>
 * @author mcminnp
 */
@Component("cassandraItemWriter")
public class CassandraItemWriter extends BaseCassandraItemWriter implements ItemWriter<String>, ChunkListener, ItemStream, InitializingBean {

    private Logger logger = LoggerFactory.getLogger(CassandraItemWriter.class);

    public final static int MAX_CACHE_SIZE = 1000000;

    /**
     * This is a cache of all items that have been written so far as part of the
     * the current transaction for the spring batch write job. When commit is
     * called this cache is cleared. 
     * 
     * The cache is used as part of the comparator to determine if records that
     * have been written (but not committed) are to be superceded by new records
     * coming in.
     */
    private Map<String,InputItem> writeChunkCache = new HashMap<String,InputItem>();
    
    @Override
    public void write(List<? extends String> items) throws Exception {
        logger.debug("Write {} items to Cassandra db...", items.size());

        // TODO: Review auto-DDL policy
        // Create column families as required

        addColumnFamilyIfNeeded(datasetName);                           // Main CF for raw data
        addColumnFamilyIfNeeded(datasetName + CASSANDRA_CF_SEPARATOR);  // PK CF (wide row)
        
        for (int fldIdx : queryableAttributePositions) {
            String cfName = datasetName + CASSANDRA_CF_SEPARATOR + fldIdx;
            addColumnFamilyIfNeeded(cfName);
        }
        
        // Pre-parse input rows
        Map<String, InputItem> inputItemMapSplit = parseInputItems(items);
        
        // Load old rows (if any)
        Map<String, String[]> oldRows = null;
        
        if (!loadOnly) {
            oldRows = loadOldRows(inputItemMapSplit.keySet());
        }

        // Set up batch execution
        BatchStatement batchStatement = new BatchStatement();
        
        for(String keyValue : inputItemMapSplit.keySet()) {
            
            logger.debug("Processing key '{}'...", keyValue);
            
            InputItem inputItem = inputItemMapSplit.get(keyValue);
            
            if( checkInputItemAgainstOldRows(keyValue,inputItem,oldRows) &&
            	checkInputItemAgainstRowsInCache(keyValue,inputItem) )
            {
	            // Get prepared statement
	            
	            // Insert into main CFs (<DATASET> and <DATASET>_)
	            assembleMainInsert(batchStatement, inputItem);
	            
	            // Assemble reverse index CQL
	            assembleRevIdxInsert(batchStatement, inputItem, oldRows);

            	// If we have a comparator then we need to cache all the items
	            // we write so we can do comparisons
	            if( latestRecordComparator != null )
	            {
	            	// Put a fail safe on the cache so we dont run out of memory
	            	if( writeChunkCache.size() < MAX_CACHE_SIZE )
	            	{
	            		writeChunkCache.put(keyValue, inputItem);
	            	}
	            	else
	            	{
	            		logger.warn("Cannot add any more items to the writeChunkCache. This has occured because the spring batch job for this item writer has not committed a transaction after " + MAX_CACHE_SIZE + " writes. Data may be inconsistent from this point on as the comparison cache is full");
	            	}
	            }
	            
	            total++;
            }
        }

        logger.debug("Wrote {} lines! (total: {})", items.size(), total);
        proxy.executeStatement(batchStatement);
    }
    
    /**
     * Checks the input item against any old rows loaded using the specified
     * comparator. Will return true if the record should be written.  
     * @param keyValue
     * @param inputItem
     * @param oldRows
     * @return
     */
    private boolean checkInputItemAgainstOldRows(String keyValue, InputItem inputItem, Map<String,String[]> oldRows)
    {
        // If a comparator has been specified and we have old rows then we run the comparator
        // against the old rows to determine if we want to replace it
        if( latestRecordComparator != null && oldRows != null && oldRows.size() > 0 )
        {
        	String[] oldRow = oldRows.get(keyValue);
        	if( oldRow != null )
        	{
	        	String line = fieldListToLine(oldRow);
	        	InputItem oldInputItem = new InputItem(keyValue, oldRow, line);
	        	
	        	// If the new value is earlier or less then the old value then we dont want to add it 
	        	if( latestRecordComparator.compare(inputItem,oldInputItem ) < 0 )
	        	{
	        		return false;
	        	}
        	}
        }

        return true;
    }

    /**
     * Checks the input item against any items in the write cache using the specifed 
     * comparator. Will return true if the record should be written.  
     * @param keyValue
     * @param inputItem
     * @return
     */
    private boolean checkInputItemAgainstRowsInCache(String keyValue, InputItem inputItem)
    {
        // If a comparator has been specified and we have old rows then we run the comparator
        // against the old rows to determine if we want to replace it
        if( latestRecordComparator != null && writeChunkCache != null && writeChunkCache.size() > 0 )
        {
        	InputItem oldInputItem = writeChunkCache.get(keyValue);
        	
        	// If the new value is earlier or less then the old value then we dont want to add it 
        	if( oldInputItem != null && latestRecordComparator.compare(inputItem,oldInputItem ) < 0 )
        	{
        		return false;
        	}
        }

        return true;
    }
    
    /**
     * Assemble main CF inserts into StringBuffer
     * @param batchStatement
     * @param inputItem
     * @return
     */
    private void assembleMainInsert(BatchStatement batchStatement, InputItem inputItem) {
        logger.debug("Assemble main inserts for {}...", inputItem.getKeyValue());
        
        StringBuffer cqlBuffer = new StringBuffer();
        
        // 1) Assemble main insert 
        
        cqlBuffer.append("insert into \"");
        cqlBuffer.append(datasetName);
        cqlBuffer.append("\" (key, column1, value) values (?, ?, ?)");
        
        PreparedStatement stmt = proxy.getPrepareStatement(cqlBuffer.toString());

        // Escape logic removed as not required when binding
        String keyValue = inputItem.getKeyValue();
        String value = inputItem.getLine();
        
        BoundStatement boundStatement = stmt.bind();

        int parmIdx = 0;
        
        boundStatement.setString(parmIdx++, keyValue);
        boundStatement.setString(parmIdx++, datasetName);
        boundStatement.setString(parmIdx++, value);

        // Add to batch
        
        batchStatement.add(boundStatement);

        // 2) Insert key using dataset as key to create wide row in Cassandra
        // e.g.: INDEX, 1234, 2345, 3456...., NNNNN
        
        cqlBuffer = new StringBuffer();
        
        cqlBuffer.append("insert into \"");
        cqlBuffer.append(datasetName + CASSANDRA_CF_SEPARATOR);
        cqlBuffer.append("\" (key, column1, value) values (?, ?, ?)");
        
        stmt = proxy.getPrepareStatement(cqlBuffer.toString());
        
        boundStatement = stmt.bind();

        parmIdx = 0;
        
        // Escape logic removed as not required when binding
        
        boundStatement.setString(parmIdx++, datasetName);
        boundStatement.setString(parmIdx++, keyValue);
        boundStatement.setString(parmIdx++, "");

        // Add to batch
        
        batchStatement.add(boundStatement);
    }
    
    /* (non-Javadoc)
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        notNull(queryableAttributePositions, "No queryable attribute positions configured?");
        notEmpty(queryableAttributePositions, "Zero queryable attribute positions configured?");

        notNull(keyAttributePositions, "No key attribute positions configured?");
        notEmpty(keyAttributePositions, "Zero key attribute positions configured?");

        notNull(attributeNames, "No attribute names configured?");
        notEmpty(attributeNames, "Zero attribute names configured?");

        // Initialise base class
        super.afterPropertiesSet();
    }

    @Override
    public void open(ExecutionContext executionContext)
            throws ItemStreamException {
    }

    @Override
    public void update(ExecutionContext executionContext)
            throws ItemStreamException {
    }

    @Override
    public void close() throws ItemStreamException {
    }

	@Override
	public void beforeChunk(ChunkContext context)
	{		
	}

	/**
	 * Called when the current chunk is being committed 
	 */
	@Override
    public void afterChunk(ChunkContext context) {

        int readCount = context.getStepContext().getStepExecution().getReadCount();
        int writeCount = context.getStepContext().getStepExecution().getWriteCount();
        int rollbackCount = context.getStepContext().getStepExecution().getRollbackCount();
        int skipCount = context.getStepContext().getStepExecution().getSkipCount();

        /**
         * If we had a record that caused an error, then each record in the batch will be committed one by one.
         * So we need to make sure that we don't clear the cache until we have completed the batch.
         *
         * rollback count does not give exact number of rollbacks.
         * e.g if there is one bad record in the chunk of size 5 then rollback count will be 2 while committing
         * the last item.
         *
         * Spring increments rollback count when any bad record is encountered while processing
         * the whole chunk and then again increments for same record while the chunk records are processed
         * one by one. This behaviour is repeated for all the chunks.
         *
         * e.g If there are 10 items to process with chunk size of 5 and both the chunks contains one bad item.
         * On processing of last item (10th item) rollback count will be 4. One each when spring tried to process
         * chunks and encountered the bad item and one each when both the chunks processed one by one and bad items
         * processed.
         *
         */
        if( rollbackCount > 0 )	{
            if ((skipCount + writeCount) == readCount) {
                writeChunkCache.clear();
            }
        } else {
            writeChunkCache.clear();
        }
    }

	@Override
	public void afterChunkError(ChunkContext context) {
	}

    /* Added to mock and verify on unit testing */
    void setWriteChunkCache(Map<String, InputItem> writeChunkCache) {
        this.writeChunkCache = writeChunkCache;
    }
}
