package com.ubs.idp.connectors.spring.batch.readers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import kafka.consumer.Consumer;
import kafka.consumer.ConsumerConfig;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

/**
 * 
 * @author rochesi
 *
 */
public class KafkaReader implements ItemReader<String> {

	private ConsumerConfig consumerConfig = null;
	private ConsumerConnector consumerConnector = null;
	private List<KafkaStream<byte[], byte[]>> streams = null;
	
	/**
	 * init the kafka producer with the config details 
	 * of the kafka server
	 */
	public void init(){
		
		Properties props = new Properties();
		
		props.put("zookeeper.connect", "xstm5346vdap.stm.swissbank.com:9092");
		props.put("zk.connectiontimeout.ms", "1000000");
		props.put("group.id", "topic2");
		
		consumerConfig = new ConsumerConfig(props);
		consumerConnector = Consumer.createJavaConsumerConnector(consumerConfig);
	
		Map<String, Integer> topicCountMap = new HashMap<String, Integer>();
	    topicCountMap.put("topic2", new Integer(0));
		
		Map<String, List<KafkaStream<byte[], byte[]>>> consumerMap = consumerConnector.createMessageStreams(topicCountMap);
		streams = consumerMap.get("topic2");	
	}
	
	@Override
	public String read() throws Exception, UnexpectedInputException,
			ParseException, NonTransientResourceException {
		
	    KafkaStream<byte[], byte[]> message = streams.get(0);
		
		return message.toString();
	}
}
