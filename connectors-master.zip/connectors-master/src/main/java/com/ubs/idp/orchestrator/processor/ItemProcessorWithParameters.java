package com.ubs.idp.orchestrator.processor;

import java.util.Map;

import org.springframework.batch.item.ItemProcessor;

/**
 * Extension of the ItemProcessor that allows us to pass in parameters
 * when processing an item
 * @author loverids
 *
 * @param <I>
 * @param <O>
 */
public interface ItemProcessorWithParameters<I,O> extends ItemProcessor<I,O>
{
	O process(I item, Map<String,Object> parameters) throws Exception; 
}
