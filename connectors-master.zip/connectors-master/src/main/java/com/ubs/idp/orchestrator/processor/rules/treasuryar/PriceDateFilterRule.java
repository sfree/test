package com.ubs.idp.orchestrator.processor.rules.treasuryar;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.ubs.idp.orchestrator.processor.ItemProcessorWithParameters;

/**
 * Rule that only returns records where the price date matches todays date
 * @author loverids
 *
 */
public class PriceDateFilterRule implements ItemProcessorWithParameters<Map<String, Object>, Map<String, Object>>
{
	public final static String PRICEDATE_ATTRIBUTE_NAME = "PRICE_DATE";
	public final static String PRICEDATE_PARAMETER_NAME = "priceDate";
	public final static String DATE_FORMAT = "yyyyMMdd";
	
	
	@Override
	public Map<String, Object> process(Map<String, Object> inputFields) throws Exception
	{
		return process(inputFields, new HashMap<String,Object>());
	}


	@Override
	public Map<String, Object> process(Map<String, Object> inputFields, Map<String, Object> parameters) throws Exception
	{
		// Find a value for the active attributes
		Object value = inputFields.get(PRICEDATE_ATTRIBUTE_NAME);

		String priceDate = (String)parameters.get(PRICEDATE_PARAMETER_NAME);
		if( priceDate == null )
		{
			priceDate = new SimpleDateFormat(DATE_FORMAT).format(new Date(System.currentTimeMillis()));
		}
			
		// If we have a value determine if it is set todays date
		if( value != null )
		{
			if( value.toString().trim().equals(priceDate)	)
			{
				return inputFields;
			}
			else
			{
				return null;
			}
		}
		
		return inputFields;
	}

}