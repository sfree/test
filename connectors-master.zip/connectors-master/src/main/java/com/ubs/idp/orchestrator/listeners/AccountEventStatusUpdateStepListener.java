package com.ubs.idp.orchestrator.listeners;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.StepExecutionListenerSupport;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ubs.idp.orchestrator.util.AccountEventJdbcStatusUpdateUtil;
import com.ubs.idp.orchestrator.util.AccountEventStatus;

public class AccountEventStatusUpdateStepListener extends StepExecutionListenerSupport {

    private static final Logger LOGGER = LoggerFactory.getLogger(AccountEventStatusUpdateStepListener.class);

    private AccountEventJdbcStatusUpdateUtil accountEventJdbcStatusUpdateUtil;

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
    	ExecutionContext context=stepExecution.getJobExecution().getExecutionContext();
        Long id = (Long) context.get("id");
        int retryCount = (Integer) context.get("retryCount");
        String propagationCode = (String) context.get("propCode");
        boolean isEventInValid = (boolean) context.get("isEventInValid");        
        String errorMessage="";
        
        AccountEventStatus stepStatusToUpdate = getMfEventStatusForCurrentStep(stepExecution);       
        if (ExitStatus.COMPLETED.equals(stepExecution.getExitStatus()) && !StringUtils.isEmpty(stepStatusToUpdate)) {
        	 LOGGER.info("Executing after step for Id: {} with propagation Code: {} with status to update: {} ", id, propagationCode, stepStatusToUpdate);
            accountEventJdbcStatusUpdateUtil.updateStatus(stepExecution.getExitStatus().getExitCode(),
                    stepStatusToUpdate, id, propagationCode, retryCount,isEventInValid,errorMessage);
            if (AccountEventStatus.PUBLISHED.equals(stepStatusToUpdate) ) {
                clearExecutionContext(stepExecution);
            }
        } else if (ExitStatus.FAILED.getExitCode().equals(stepExecution.getExitStatus().getExitCode())) {
        	if(stepExecution.getFailureExceptions().iterator().hasNext()) {
        		errorMessage=stepExecution.getFailureExceptions().iterator().next().getMessage();        	
        	}
        	LOGGER.info("Executing after step for Id: {} with propagation Code: {} for FAILED step ", id, propagationCode );
        	if(isEventInValid){
        		errorMessage="Validation Exception";
        		accountEventJdbcStatusUpdateUtil.updateStatus(stepExecution.getExitStatus().getExitCode(),
                		AccountEventStatus.FATAL, id, propagationCode, retryCount,isEventInValid,errorMessage );
        	}
        	else if(isEventInValid || retryCount==(accountEventJdbcStatusUpdateUtil.getMaxRetryCount(propagationCode)-1)){
        		accountEventJdbcStatusUpdateUtil.updateStatus(stepExecution.getExitStatus().getExitCode(),
                		AccountEventStatus.FATAL, id, propagationCode, retryCount,isEventInValid,errorMessage );
        	}else{
        		long loaType=(Long)context.get("loaType");
        		rollbackFailedEventSteps(getCurrentStepExecution(stepExecution),id,loaType);
        		accountEventJdbcStatusUpdateUtil.updateStatus(stepExecution.getExitStatus().getExitCode(),
                		AccountEventStatus.UNPROCESSED, id, propagationCode, retryCount,isEventInValid,errorMessage);        		
        	}            
            clearExecutionContext(stepExecution);
        }
        return stepExecution.getExitStatus();
    }

   /*
    * This method rollback all DB Commit happened in current and previous steps for a failed event(any exception coming except Validation Exception)  
    * This method doesnt have break from step 5 to step2 in order to achieve rollback waterfall   with non repeatable code
    */

	public void rollbackFailedEventSteps(StepExecution currentStepExecution,
			Long id, long loaType) {
		LOGGER.info("Starting Rollback for IDP id"+id);
		if (currentStepExecution != null) {
            switch (currentStepExecution.getStepName()) {
               case "step5" :            	                     
               case "step4" : accountEventJdbcStatusUpdateUtil.deleteJDBCXMLRecordForEventIdpID(id,loaType);
               case "step3" :
               case "step2" : accountEventJdbcStatusUpdateUtil.deleteCassandraRSRecordsForEventIdpID(id,loaType);
               				  LOGGER.info("Rollback applied for Failure in STEP: {} for IDPID: {}",currentStepExecution.getStepName(),id);
               				  break;                 
               default		: LOGGER.info("Rollback not requied for failures in STEP1 and STEP6");
            }
        }
		
	}



	private void clearExecutionContext(StepExecution stepExecution) {
        stepExecution.getJobExecution().getExecutionContext().remove("id");
        stepExecution.getJobExecution().getExecutionContext().remove("retryCount");
        stepExecution.getJobExecution().getExecutionContext().remove("propCode");
        stepExecution.getJobExecution().getExecutionContext().remove("isEventInValid");
        stepExecution.getJobExecution().getExecutionContext().remove("loaType");
    }

    private AccountEventStatus getStepStatusToUpdate(StepExecution currentStepExecution ) {

        AccountEventStatus status = null;
        if (currentStepExecution != null) {
            switch (currentStepExecution.getStepName()) {
                case "step4" :
                    status = AccountEventStatus.PROCESSED;
                    break;
                case "step5" :
                    status = AccountEventStatus.PUBLISHED;
                    break;
                default: status = null;
            }
        }
        return status;
    }

    private AccountEventStatus getMfEventStatusForCurrentStep(StepExecution stepExecution) {
        StepExecution currentStepExecution = getCurrentStepExecution(stepExecution);
        return getStepStatusToUpdate(currentStepExecution);
    }

	/**
	 * This method gives the current step name which got executed in batch flow
	 * 
	 * @param stepExecution
	 * @return stepExecution
	 */
	public StepExecution getCurrentStepExecution(StepExecution stepExecution) {
		StepExecution currentStepExecution = null;
        Collection<StepExecution> stepExecutions = stepExecution.getJobExecution().getStepExecutions();
        if (!CollectionUtils.isEmpty(stepExecutions)) {
            currentStepExecution = (StepExecution) stepExecutions.toArray()[(stepExecutions.size() - 1)];
        }
		return currentStepExecution;
	}

    public void setAccountEventJdbcStatusUpdateUtil(AccountEventJdbcStatusUpdateUtil accountEventJdbcStatusUpdateUtil) {
        this.accountEventJdbcStatusUpdateUtil = accountEventJdbcStatusUpdateUtil;
    }
}
