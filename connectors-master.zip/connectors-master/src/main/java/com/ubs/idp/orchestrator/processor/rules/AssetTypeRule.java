package com.ubs.idp.orchestrator.processor.rules;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.item.ItemProcessor;

/**
 * Rules to derive the Asset Type from a number of fields.
 * <p>
 * The derived values for Asset Type are also used as the input for a two other derivations, Asset
 * Class and Fixed Income Asset Type.
 *
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT (See the section
 *      Calculated Fields > Asset Type definitions)
 * @author haniffsy
 */
public class AssetTypeRule extends DerivationRuleTemplate implements
		ItemProcessor<Map<String, Object>, Map<String, Object>> {

	/*
	 * These are constants that the AssetTypeRule uses to compare to the input field values
	 */
	private static final String GOVT = "Govt";

	private static final String SOVEREIGN = "Sovereign";

	private static final String MTGE = "Mtge";

	static final String MBS_REGEX = "^.*MORTGAGE.*BACKED.*$";

	static final String ABS_REGEX = "^.*ASSET.*BACKED.*$";

	private static final String JUMBO_PFANDBRIEFE_REGEX = "^.*JUMBO.*PFANDBRIEFE.*$";

	private static final String PFANDBRIEFE_REGEX = "^.*PFANDBRIEFE.*$";

	private static final String CERT_DEPOSIT_REGEX_A = "^.*CERT.*OF.*DEPOSIT.*$";

	private static final String CERT_DEPOSIT_REGEX_B = "^.*DEPOSIT.*NOTES.*$";

	private static final String MONEY_MARKEY = "MoneyMarket";

	private static final String SECURITY_TYPE_REGEX = "GDR|EDR|REIT";

	private static final String ADR_REGEX = "ADR|BDR|IDR";

	private static final String PREFERENCE = "PREFERENCE";

	private static final String ETF_REGEX = "ETF|ETN|ETC";

	/*
	 * These are the derived values that the AssetTypeRule needs to emit
	 */
	static final String GOVERNMENT_DERIVED = "Government";

	static final String MBS_DERIVED = "MBS";

	static final String ABS_DERIVED = "ABS";

	static final String JUMBO_PFANDBRIEF_DERIVED = "Jumbo Pfandbrief";

	static final String PFANDBRIEF_DERIVED = "Pfandbrief";

	static final String CERTIFICATES_OF_DEPOSIT_DERIVED = "Certificates of Deposit";

	static final String COMMERCIAL_PAPER_DERIVED = "Commercial Paper";

	static final String CORPORATE_DERIVED = "Corporate";

	static final String SUPRANATIONAL_DERIVED = "Supranational";

	static final String MUNICIPAL_DERIVED = "Municipal";

	static final String AGENCY_DERIVED = "Agency";

	static final String ADR_DERIVED = "ADR";

	static final String PREFERENCE_DERIVED = "Preference";

	static final String ETF_DERIVED = "ETF";

	static final String CONVERTIBLE_PREFERENCE_SHARES_DERIVED = "Convertible Preference Shares";

	static final String UIT_DERIVED = "UIT";

	static final String RIGHTS_DERIVED = "Rights";

	static final String WARRANT_DERIVED = "Warrant";

	static final String COMMON_EQUITY_DERIVED = "Common Equity";

	static final String UNKNOWN_DERIVED = "Unknown";

	/*
	 * Values that are directly derived from the input
	 */
	static final String GDR_DERIVED = "GDR";

	static final String EDR_DERIVED = "EDR";

	static final String REIT_DERIVED = "REIT";

	@Override
	public Map<String, Object> applyRules(Map<String, Object> inputFields) {
		String bbgYellowKey = getMappedInputField(BLOOMBERG_YELLOW_KEY, inputFields);
		String bbgIndustryGroup = getMappedInputField(BLOOMBERG_INDUSTRY_GROUP, inputFields);
		String bbgIndustrySubgroup = getMappedInputField(BLOOMBERG_INDUSTRY_SUBGROUP, inputFields);
		CFICode ubsCfiCode = new CFICode(getMappedInputField(UBS_CFI_CODE, inputFields));
		String collType = getMappedInputField(COLLATERAL_TYPE, inputFields);
		String marketIssueType = getMappedInputField(MARKET_ISSUE_TYPE, inputFields);

		/*
		 * If bbg yellowkey is 'Govt' and bbg industry group is 'Sovereign' and bbg industry
		 * subgroup is 'Sovereign' then asset type is 'Government'
		 */
		if (GOVT.equals(bbgYellowKey) && SOVEREIGN.equals(bbgIndustryGroup)
				&& SOVEREIGN.equals(bbgIndustrySubgroup)) {
			return derivedValue(GOVERNMENT_DERIVED);
		}

		/*
		 * If UBS cfi code 1th char is 'D' and 7th char is not 'G' and 4th char is 'R' then asset
		 * type is 'MBS'
		 */
		if (ubsCfiCode.matchesAtPosition(1, "D") && ubsCfiCode.matchesAtPosition(4, "R")
				&& !ubsCfiCode.matchesAtPosition(7, "G")) {
			return derivedValue(MBS_DERIVED);
		}

		/*
		 * If UBS cfi code 1th char is 'D' and 7th char is not 'G' and 4th char is 'A' then asset
		 * type is 'ABS'
		 */
		if (ubsCfiCode.matchesAtPosition(1, "D") && ubsCfiCode.matchesAtPosition(4, "A")
				&& !ubsCfiCode.matchesAtPosition(7, "G")) {
			return derivedValue(ABS_DERIVED);
		}

		/*
		 * If bbg yellowkey is 'Mtge' and collateral type is like '%MORTGAGE%BACKED%' then asset
		 * type is 'MBS'
		 */
		if (MTGE.equals(bbgYellowKey) && collType != null && collType.matches(MBS_REGEX)) {
			return derivedValue(MBS_DERIVED);
		}

		/*
		 * If bbg yellowkey is 'Mtge' and collateral type is like '%ASSET%BACKED%' then asset type
		 * is 'ABS'
		 */
		if (MTGE.equals(bbgYellowKey) && collType != null && collType.matches(ABS_REGEX)) {
			return derivedValue(ABS_DERIVED);
		}

		/*
		 * If UBS cfi code 1th char is 'D' and 7th char is 'G' then asset type is 'Government'
		 */
		if (ubsCfiCode.matchesAtPosition(1, "D") && ubsCfiCode.matchesAtPosition(7, "G")) {
			return derivedValue(GOVERNMENT_DERIVED);
		}

		/*
		 * If collateral type is like '%JUMBO%PFANDBRIEFE%' then asset type is 'Jumbo Pfandbrief'
		 */
		if (collType != null && collType.matches(JUMBO_PFANDBRIEFE_REGEX)) {
			return derivedValue(JUMBO_PFANDBRIEF_DERIVED);
		}

		/*
		 * If collateral type is like '%PFANDBRIEFE%' then asset type is 'Pfandbrief'
		 */
		if (collType != null && collType.matches(PFANDBRIEFE_REGEX)) {
			return derivedValue(PFANDBRIEF_DERIVED);
		}

		/*
		 * If UBS cfi code 1th char is 'D' and 7th char is 'D' then asset type is 'Certificates of
		 * Deposit'
		 */
		if (ubsCfiCode.matchesAtPosition(1, "D") && ubsCfiCode.matchesAtPosition(7, "D")) {
			return derivedValue(CERTIFICATES_OF_DEPOSIT_DERIVED);
		}

		/*
		 * If UBS cfi code starts with 'DY' and (collateral type is like '%CERT%OF%DEPOSIT%' or
		 * '%DEPOSIT%NOTES%') then asset type is 'Certificates of Deposit'
		 */
		if (ubsCfiCode.startsWith("DY")
				&& collType != null
				&& (collType.matches(CERT_DEPOSIT_REGEX_A) || collType
						.matches(CERT_DEPOSIT_REGEX_B))) {
			return derivedValue(CERTIFICATES_OF_DEPOSIT_DERIVED);
		}

		/*
		 *  NOT (cfi 1th char is "D" and the second is "C")
			AND (cfi 1th char is "D" and cfi 7th char is "S")
			OR (no cfi 
				AND NOT (bbYellowKey is "Govt" and bbIndustryGroup is "Sovereign" and bbIndSubGroup is "Sovereign")
				AND secType = "SUPRANATL")
			then asset type is 'Supranational'
		 */
		if (!ubsCfiCode.startsWith("DC") 
				&& ubsCfiCode.matchesAtPosition(1, "D") && ubsCfiCode.matchesAtPosition(7, "S")
				|| ((ubsCfiCode.toString() == null || ubsCfiCode.toString().trim().equals(""))
						&& !(GOVT.equals(bbgYellowKey) && SOVEREIGN.equals(bbgIndustryGroup) && SOVEREIGN.equals(bbgIndustrySubgroup))
						&& "SUPRANATL".equals(marketIssueType))) {
			return derivedValue(SUPRANATIONAL_DERIVED);
		}

		/*
		 * If market issue type is 'MoneyMarket' then asset type is 'Commercial Paper'
		 */
		if (MONEY_MARKEY.equals(marketIssueType)) {
			return derivedValue(COMMERCIAL_PAPER_DERIVED);
		}

		/*
		 * If UBS cfi code starts with 'DY' and (collateral type is not like '%CERT%OF%DEPOSIT%' or
		 * '%DEPOSIT%NOTES%') then asset type is 'Commercial Paper'
		 */
		if (ubsCfiCode.startsWith("DY") && collType != null
				&& !collType.matches(CERT_DEPOSIT_REGEX_A)
				&& !collType.matches(CERT_DEPOSIT_REGEX_B)) {
			return derivedValue(COMMERCIAL_PAPER_DERIVED);
		}

		/*
		 * If UBS cfi code starts with 'DC' then asset type is 'Corporate'
		 */
		if (ubsCfiCode.startsWith("DC")) {
			return derivedValue(CORPORATE_DERIVED);
		}

		/*
		 * If UBS cfi code 1th char is 'D' and 7th char is one of 'C', 'M', 'I', 'E' or 'K' then
		 * asset type is 'Corporate'
		 */
		if (ubsCfiCode.matchesAtPosition(1, "D")
				&& ubsCfiCode.matchesAtPosition(7, "C", "M", "I", "E", "K")) {
			return derivedValue(CORPORATE_DERIVED);
		}

		/*
		 * If UBS cfi code 1th char is 'D' and 7th char is 'L' then asset type is 'Municipal'
		 */
		if (ubsCfiCode.matchesAtPosition(1, "D") && ubsCfiCode.matchesAtPosition(7, "L")) {
			return derivedValue(MUNICIPAL_DERIVED);
		}

		/*
		 * If UBS cfi code 1th char is 'D' and 7th char is 'A' then asset type is 'Agency'
		 */
		if (ubsCfiCode.matchesAtPosition(1, "D") && ubsCfiCode.matchesAtPosition(7, "A")) {
			return derivedValue(AGENCY_DERIVED);
		}

		String bbSecurityType = getMappedInputField(BLOOMBERG_SECURITY_TYPE, inputFields);

		/*
		 * If bbg security type is one of 'GDR', 'EDR' or 'REIT' then asset type is bbg security
		 * type
		 */
		if (bbSecurityType != null && bbSecurityType.matches(SECURITY_TYPE_REGEX)) {
			return derivedValue(bbSecurityType);
		}

		/*
		 * If bbg security type is one of 'ADR', 'BDR' or 'IDR' then asset type is 'ADR'
		 */
		if (bbSecurityType != null && bbSecurityType.matches(ADR_REGEX)) {
			return derivedValue(ADR_DERIVED);
		}

		/*
		 * If bbg security type is 'PREFERENCE' (case insensitive) then asset type is 'Preference'
		 */
		if (bbSecurityType != null && bbSecurityType.equalsIgnoreCase(PREFERENCE)) {
			return derivedValue(PREFERENCE_DERIVED);
		}

		/*
		 * If bbg security type is one of 'ETF', 'ETN' or 'ETC' then asset type is 'ETF'
		 */
		if (bbSecurityType != null && bbSecurityType.matches(ETF_REGEX)) {
			return derivedValue(ETF_DERIVED);
		}

		/*
		 * If UBS cfi code 5th char is 'A' then asset type is 'ADR'
		 */
		if (ubsCfiCode.matchesAtPosition(5, "A")) {
			return derivedValue(ADR_DERIVED);
		}

		/*
		 * If UBS cfi code starts with 'EP' then asset type is 'Preference'
		 */
		if (ubsCfiCode.startsWith("EP")) {
			return derivedValue(PREFERENCE_DERIVED);
		}

		/*
		 * If UBS cfi code starts with 'EC' then asset type is 'Convertible Preference Shares'
		 */
		if (ubsCfiCode.startsWith("EC")) {
			return derivedValue(CONVERTIBLE_PREFERENCE_SHARES_DERIVED);
		}

		/*
		 * If UBS cfi code starts with 'EU' then asset type is 'UIT'
		 */
		if (ubsCfiCode.startsWith("EU")) {
			return derivedValue(UIT_DERIVED);
		}

		/*
		 * If UBS cfi code starts with 'RM' then asset type is 'Rights'
		 */
		if (ubsCfiCode.startsWith("RM")) {
			return derivedValue(RIGHTS_DERIVED);
		}

		/*
		 * If UBS cfi code starts with 'RW' or 'MM' then asset type is 'Warrant'
		 */
		if (ubsCfiCode.startsWith("RW") || ubsCfiCode.startsWith("MM")) {
			return derivedValue(WARRANT_DERIVED);
		}

		/*
		 * If UBS cfi code starts with 'ES' or 'EM' then asset type is 'Common Equity'
		 */
		if (ubsCfiCode.startsWith("ES") || ubsCfiCode.startsWith("EM")) {
			return derivedValue(COMMON_EQUITY_DERIVED);
		}

		return derivedValue(UNKNOWN_DERIVED);

	}

	@Override
	public Map<String, Object> process(Map<String, Object> item) throws Exception {
		return derive(item);
	}

	private Map<String, Object> derivedValue(String derivedValue) {
		Map<String, Object> derivedFields = new HashMap<String, Object>();
		derivedFields.put(DERIVED_ASSET_TYPE, derivedValue);
		return derivedFields;
	}
}
