package com.ubs.idp.orchestrator.processor.rules.rddh.rating;

import static org.apache.commons.lang.StringUtils.isBlank;
import static org.apache.commons.lang.StringUtils.trimToEmpty;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.item.ItemProcessor;

import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;

/**
 * Rule to populate standard rating values with values supplied by DMSI in case the standard values
 * are not available. This rules replaces all the attributes related to a particular rating agency
 * depending on whether or not a standard {@code rawCode} value is found for an agency is found.
 */
public class RatingAgencyRule extends DerivationRuleTemplate implements
		ItemProcessor<Map<String, Object>, Map<String, Object>> {

	private static final String DERIVED_PREFIX = "derived.";

	private static final String DERIVED_DMSI_PREFIX = DERIVED_PREFIX + "DMSI_";

	private static final String KEY_PATTERN = "%s_%s";

	private static final String STANDARD_KEY = DERIVED_PREFIX + KEY_PATTERN;

	private static final String DMSI_KEY = DERIVED_DMSI_PREFIX + KEY_PATTERN;

	private static final String[] AGENCIES = { "SandP", "Moodys", "Fitch" };

	// A single attribute is used to check whether or not the fall back should be triggered
	private static final String KEY_ATTRIBUTE = "issueRating.rawCode";

	private static final String[] ATTRIBUTES = { "event.lastUpdatedTime",
			"issueRating.lastUpdatedTime", "issueRating.code", KEY_ATTRIBUTE,
			"issueRating.validDate", "issueRating.ratingGroup", "event.majorVersion" };

	@Override
	public Map<String, Object> applyRules(Map<String, Object> inputFields) {
		Map<String, Object> derivedFields = new HashMap<String, Object>();

		for (String agency : AGENCIES) {
			String keyAttrValue = getMappedInputField(
					String.format(STANDARD_KEY, agency, KEY_ATTRIBUTE), inputFields);
			String dmsiKeyAttrValue = getMappedInputField(
					String.format(DMSI_KEY, agency, KEY_ATTRIBUTE), inputFields);
			if (isBlank(keyAttrValue) && !isBlank(dmsiKeyAttrValue)) {
				for (String attribute : ATTRIBUTES) {
					String key = String.format(STANDARD_KEY, agency, attribute);
					String dmsiKey = String.format(DMSI_KEY, agency, attribute);
					derivedFields.put(key, trimToEmpty(getMappedInputField(dmsiKey, inputFields)));
				}
			}
		}

		return derivedFields;
	}

	@Override
	public Map<String, Object> process(Map<String, Object> item) throws Exception {
		return derive(item);
	}

}
