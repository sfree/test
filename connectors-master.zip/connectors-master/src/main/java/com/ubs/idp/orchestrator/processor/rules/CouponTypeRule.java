package com.ubs.idp.orchestrator.processor.rules;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.item.ItemProcessor;

/**
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Calculated fields / Coupon Type (Fixed income coupon Type for SSP) section
 * 
 * Martini Value	coupon.couponType	Expected Value			Description (Expected)
 *  
 * UNKNOWN 			? 					Is there such thing? 	Coupon Type Not Known 
 * Auction 			? 					CTAU 					Auction 
 * Fixed 			FIXED 				CTFX 					Fixed Coupon 
 * Floating 		FLOATING 			CTFL 					Floating/Adjustable Coupon (or Inverse Floating Coupon) 
 * Zero 			ZERO 				CTZE 					Zero Coupon 
 * FixedFloat 		FIXEDFLOAT 			CTVA 					Variable Coupon (or FixedFloat) 
 * Stepped 			STEPPED 			CTST 					Coupon (or Zero to Fixed) 
 * Index-Linked		INDEXLINKED 		CTIL 					Index-Linked Coupon 
 	Coupon  
 * Compound 		? 					CTCO 					Compound
 * 
 * @author haniffsy
 */
public class CouponTypeRule extends DerivationRuleTemplate implements ItemProcessor<Map<String,Object>,Map<String,Object>>{

	/*
	 * These are constants that the CouponTypeRule uses to compare to the input field values
	 */
	public static final String FIXED = "FIXED";
	public static final String FLOATING = "FLOATING";
	public static final String ZERO = "ZERO";
	public static final String FIXEDFLOAT = "FIXEDFLOAT";
	public static final String STEPPED = "STEPPED";
	public static final String INDEXLINKED = "INDEXLINKED";
	
	/*
	 * These are the derived values that the CouponTypeRule needs to emit
	 */
	public static final String AUCTION_DERIVED = "CTAU";
	public static final String FIXED_DERIVED = "CTFX";
	public static final String FLOATING_DERIVED = "CTFL";
	public static final String ZERO_DERIVED = "CTZE";
	public static final String FIXEDFLOAT_DERIVED = "CTVA";
	public static final String STEPPED_DERIVED = "CTST";
	public static final String INDEXLINKED_DERIVED = "CTIL";
	public static final String COMPOUND_DERIVED = "CTCO";

	// TODO These tests are case-sensitive ... should they be?
	@Override
	public final Map<String,Object> applyRules(Map<String, Object> inputFields) {
		
		Map<String,Object> derivedFields = new HashMap<String,Object>();
		
		String couponType = getMappedInputField(COUPON_TYPE,inputFields);

		if( couponType != null )
		{		
			switch (couponType) {
			
				case FIXED:
					derivedFields.put(DERIVED_COUPON_TYPE, FIXED_DERIVED);				
					break;
					
				case FLOATING:
					derivedFields.put(DERIVED_COUPON_TYPE, FLOATING_DERIVED);
					break;	
					
				case ZERO:
					derivedFields.put(DERIVED_COUPON_TYPE, ZERO_DERIVED);
					break;
					
				case FIXEDFLOAT:
					derivedFields.put(DERIVED_COUPON_TYPE, FIXEDFLOAT_DERIVED);
					break;
					
				case STEPPED:
					derivedFields.put(DERIVED_COUPON_TYPE, STEPPED_DERIVED);
					break;
					
				case INDEXLINKED:
					derivedFields.put(DERIVED_COUPON_TYPE, INDEXLINKED_DERIVED);
					break;				
					
				default:
					break;
			
			}
		}
		else
		{
		    // TODO: Do we really want to do this - -for large files it could swamp the logs
			//logger.warn("No attribute " + COUPON_TYPE + " passed into " + this.getClass().getSimpleName() );
		}
		
		return derivedFields;
		
	}

	@Override
	public Map<String, Object> process(Map<String, Object> item) throws Exception
	{
		return derive(item);
	}
}
