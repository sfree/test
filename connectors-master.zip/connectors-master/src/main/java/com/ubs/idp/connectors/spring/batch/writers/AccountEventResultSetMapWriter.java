package com.ubs.idp.connectors.spring.batch.writers;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.ubs.idp.base.IdpBoundary;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@IdpBoundary
@Service
public class AccountEventResultSetMapWriter extends BaseCassandraItemWriter implements ItemWriter<AccountEventResultSetWriter.AccountEventResultSets>, InitializingBean {

    private String query;
    private final static String UNIQUE_KEY_PRFIX = "R";
    public static final String RESULT_SET_IDP_ID = "idpid";
    
    private static final Logger logger = LoggerFactory.getLogger(AccountEventResultSetMapWriter.class);

    @Override
    public void write(List<? extends AccountEventResultSetWriter.AccountEventResultSets> mfSpResults) throws Exception {

        PreparedStatement prepareStatement;
        BatchStatement batchStatement = new BatchStatement();
        logger.info("Preparing to write Event SP Resultset in Cassandra");
        AccountEventResultSetWriter.AccountEventResultSets accountEventResultSets = mfSpResults.get(0);
        Map<Integer, Map<Integer, Map<String, String>>> resultSetsMap = accountEventResultSets.getTransformedResultSetsMap();
        for (Integer resultSetKey : resultSetsMap.keySet()) {
            Map<Integer, Map<String, String>> rowsForResultSet = resultSetsMap.get(resultSetKey);
            for (Integer recordKey : rowsForResultSet.keySet()) {
                Map<String, String> transformedMap = rowsForResultSet.get(recordKey);
                prepareStatement = proxy.getPrepareStatement(query);
                Object num = accountEventResultSets.getMappedEvent().get(RESULT_SET_IDP_ID);
                String num2 = getuniqueKey(resultSetKey,recordKey);
                BoundStatement bound = prepareStatement.bind(transformedMap, num, num2);
                batchStatement.add(bound);
            }
        }
        proxy.executeStatement(batchStatement);
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getuniqueKey (Integer resultSetKey , Integer recordKey){
        return UNIQUE_KEY_PRFIX+resultSetKey+"-"+recordKey;
    }

    public void afterPropertiesSet() throws Exception {
        super.afterPropertiesSet();
    }
}
