package com.ubs.idp.connectors.spring.batch.readers;

import java.util.ArrayList;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.InitializingBean;

/**
 * 
 * configure the list reader as to read all object one by one or all in onshot
 * for proccessor. List reader reader anything as Object, type cast to your
 * actual object in Proccesor proccess method.
 */
public class ListItemReader implements ItemReader<Object>, ItemStream,
		InitializingBean {
	private int index;
	private boolean read1iteminStep;
	private boolean readfullListl;

	@Resource(name = "listOfItems")
	private ArrayList listOfItems;
	
	private Logger logger = LoggerFactory.getLogger(ListItemReader.class);

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	
	public void open(ExecutionContext executionContext)
			throws ItemStreamException {

	}

	@BeforeStep
	public void getIndex(StepExecution stepExecution) {
		JobExecution stepContext = stepExecution.getJobExecution();
		index = stepContext.getExecutionContext().getInt("index");
	}

	@AfterStep
	public void setIndex(StepExecution stepExecution) {
		JobExecution stepContext = stepExecution.getJobExecution();
		index++;
		stepContext.getExecutionContext().putInt("index", index);
	}

	@Override
	public void update(ExecutionContext executionContext)
			throws ItemStreamException {
		// TODO Auto-generated method stub

	}

	@Override
	public void close() throws ItemStreamException {
		// TODO Auto-generated method stub

	}

	@Override
	public Object read() throws Exception, UnexpectedInputException,
			ParseException, NonTransientResourceException {
		if (readfullListl) {
			// to do put the logic
			return null;
		} else {
			if (read1iteminStep) {
				return null;
			} else {
				if (listOfItems.size() > 0 && index < listOfItems.size()) {
					Object event = (Object) listOfItems.get(index);
					read1iteminStep = true;
					logger.info("Reading object at index:{} in Job Object list", index);
					return event;
				} else {
					return null;
				}

			}
		}
	}

	public ArrayList getListOfItems() {
		return listOfItems;
	}

	public void setListOfItems(ArrayList listOfItems) {
		this.listOfItems = listOfItems;
	}
}
