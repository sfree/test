package com.ubs.idp.connectors.spring.batch.formatters;

import java.util.List;
import java.util.Map;

import org.springframework.util.StringUtils;

public class ArrayAndMapFormatFormatter implements FieldFormatter {

    private static final String DEFAULT_NAMEVALUE_SEPARATOR = "="; // Note - Java standard rather than JSON
    private static final String DEFAULT_LIST_DELIMITER = ",";
    /**
     * Replacements for true/false
     */
    private String[] booleanValues = { "true", "false" };
    private String listSeparator = DEFAULT_LIST_DELIMITER;
    private String nameValueSeparator = DEFAULT_NAMEVALUE_SEPARATOR;
    private boolean stripQuotes = false;

    @Override
    public String formatField(Object valueIn) {
        String res = null;
        
        if (valueIn instanceof String) {
            res = (String)valueIn;
        } else if (valueIn instanceof Boolean) {
            if (((Boolean)valueIn)) {
                res = booleanValues[0];
            } else {
                res = booleanValues[1];
            }
        } else if (valueIn instanceof String) {
            res = (String)valueIn;
        } else if (valueIn instanceof List) {
            res = valueIn.toString();

            // Only re-build string if mapping is non-standard
            if (!listSeparator.equals(DEFAULT_LIST_DELIMITER)) {
                StringBuffer sb = new StringBuffer();
                List in = (List)valueIn;

                sb.append("[");

                for(int idx = 0 ; idx < in.size() ; idx++) {
                    if (idx > 0) {
                        sb.append(listSeparator);
                    }
                    Object entry = in.get(idx);
                    sb.append(entry.toString());
                }

                sb.append("]");
                
                res = sb.toString();
            }
        } else if (valueIn instanceof Map) {
            res = valueIn.toString();

            // Only re-build string if mapping is non-standard
            if (!listSeparator.equals(DEFAULT_LIST_DELIMITER) ||
                !nameValueSeparator.equals(DEFAULT_NAMEVALUE_SEPARATOR)) {
                StringBuffer sb = new StringBuffer();
                Map in = (Map)valueIn;
                
                int idx = 0;
                
                sb.append("{");
                
                for (Object key : in.keySet()) {
                    Object value = in.get(key);
                    
                    if (idx > 0) {
                        sb.append(listSeparator);
                    }
                    
                    sb.append(key);
                    sb.append(nameValueSeparator);
                    sb.append(value);
                    
                    idx++;
                }

                sb.append("}");
                
                res = sb.toString();
            }
        } else if (valueIn != null){
            res = valueIn.toString();
        } else {
            res = ""; // TODO: Support alternate default e.g.: BLANK
        }
        
        return res;
    }

    // Getters/setters
    
    /**
     * Set alternate mapping for true/false
     * @param booleanValuesIn
     */
    public void setBooleanValues(String booleanValuesIn) {
        if (!StringUtils.isEmpty(booleanValuesIn)) {
            String[] tmp;
            
            if (booleanValuesIn.indexOf(DEFAULT_LIST_DELIMITER) > 0) {
                tmp = booleanValuesIn.split(DEFAULT_LIST_DELIMITER);
            } else if (booleanValuesIn.indexOf("/") > 0) {
                tmp = booleanValuesIn.split("/");
            } else {
                throw new IllegalArgumentException("Invalid delimiter? (expected ',' or '/')");
            }
            
            if (tmp.length != 2) {
                throw new IllegalArgumentException("Invalid value count? (expected 2, got " + tmp.length + ")");
            }
            
            this.booleanValues = tmp;
        }
    }

    public String getListSeparator() {
        return listSeparator;
    }

    public void setListSeparator(String listSeparator) {
        this.listSeparator = listSeparator;
    }

    public String getNameValueSeparator() {
        return nameValueSeparator;
    }

    public void setNameValueSeparator(String nameValueSeparator) {
        this.nameValueSeparator = nameValueSeparator;
    }

    public boolean isStripQuotes() {
        return stripQuotes;
    }

    public void setStripQuotes(boolean stripQuotes) {
        this.stripQuotes = stripQuotes;
    }
}
