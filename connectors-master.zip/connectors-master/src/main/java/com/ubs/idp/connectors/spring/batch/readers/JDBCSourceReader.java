package com.ubs.idp.connectors.spring.batch.readers;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.jdbc.core.RowMapper;

import com.ubs.idp.connectors.BaseConnector;
import com.ubs.idp.connectors.spring.batch.utils.PropertyPreprocessor;

/**
 * Spring batch JDBC reader
 * @author rochesi, mcminnp
 */
public class JDBCSourceReader extends BaseConnector implements ItemReader<Object>, ItemStream {
	
	private DataSource dataSource;
    private RowMapper<Object> rowMapper;
    private String querySql;
	
	private JdbcCursorItemReader<Object> jdbcCursorItemReader;
	
    private long rowCount = 0;

    private Logger logger = LoggerFactory.getLogger(JDBCSourceReader.class);
    
    private PropertyPreprocessor sqlPreProcessor = null;
	
    /**
     * Bare bones constructor
     */
    public JDBCSourceReader() {
        logger.debug("Initialise JDBC reader for source ID '{}'...", sourceIdentifier);
        
        jdbcCursorItemReader = new JdbcCursorItemReader<Object>();
    }
    
	/**
     * @return the dataSource
     */
    public DataSource getDataSource() {
        return dataSource;
    }

    /**
     * @param dataSource the dataSource to set
     */
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * @return the rowMapper
     */
    public RowMapper<Object> getRowMapper() {
        return rowMapper;
    }

    /**
     * @param rowMapper the rowMapper to set
     */
    public void setRowMapper(RowMapper<Object> rowMapper) {
        this.rowMapper = rowMapper;
    }

    /**
     * @return the querySql
     */
    public String getQuerySql() {
        return querySql;
    }

    /**
     * @param querySql the querySql to set
     */
    public void setQuerySql(String querySqlIn) {
        
        if (sqlPreProcessor != null) {
         	 querySql = sqlPreProcessor.preProcess(querySqlIn);
        } else {
         	 querySql = querySqlIn;
        }
    }

    /**
     * Return number of rows read
     * @return
     */
    public long getRowCount() {
        return rowCount;
    }

    /**
	 * Called from Spring to bootstrap the reader
     * @throws Exception 
	 */
	public void init() throws Exception{                
        logger.debug("Set query SQL to '{}'", querySql);
        
	    jdbcCursorItemReader.setSql(querySql);
	    
	    if (rowMapper != null) {
	        jdbcCursorItemReader.setRowMapper(rowMapper);
	    }
	    
	    if (dataSource != null) {
	        jdbcCursorItemReader.setDataSource(dataSource);
	    }
	    
        rowCount = 0;
	}

    @Override
    public Object read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
        Object res = jdbcCursorItemReader.read();
        
        if (res != null) {
            rowCount++;
        }

        return res;
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#open(org.springframework.batch.item.ExecutionContext)
     */
    @Override
    public void open(ExecutionContext executionContext)
            throws ItemStreamException {
        logger.debug("Open jdbcCursorItemReader...");

        jdbcCursorItemReader.open(executionContext);
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#close()
     */
    public void close() {
        logger.debug("Closing reader");

        jdbcCursorItemReader.close();
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#update(org.springframework.batch.item.ExecutionContext)
     */
    @Override
    public void update(ExecutionContext executionContext)
            throws ItemStreamException {
        jdbcCursorItemReader.update(executionContext);
    }
    
    /**
     * @param sqlPreProcessor logic in JDBCReaderFileWriter
     */
    public void setSqlPreProcessor(PropertyPreprocessor sqlPreProcessor) {
		this.sqlPreProcessor = sqlPreProcessor;
	}

    /**
     * getter for sqlPreProcessor
     */
	public PropertyPreprocessor getSqlPreProcessor() {
		return sqlPreProcessor;
	}
	
    public void setFetchSize(int size){

		if(jdbcCursorItemReader != null){
			jdbcCursorItemReader.setFetchSize(size);
		}
	}
}
