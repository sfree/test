package com.ubs.idp.orchestrator.tasklets;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

import com.ubs.idp.orchestrator.util.FileActionHandler;

/**
 * @author mcminnp
 */
/**
 * @author loverids
 *
 */
public class FileMoveTasklet implements Tasklet, InitializingBean {

    private boolean zip = false;
    private Resource file;
    private Resource destinationDirectory;
    private File destinationDirFile = null;
    private String newFileName = null;
    
    private FileActionHandler fileActionHandler = new FileActionHandler();
    
    /**
     * Array of filenames to create duplicates of
     * before doing the move
     */
    private String[] duplicateFileNamePrefixes;

    /**
     * Standard suffix for all duplicated filenames
     */
    private String duplicateFileNameSuffix;

    
    private Logger logger = LoggerFactory.getLogger(getClass());
    
    /* (non-Javadoc)
     * @see org.springframework.batch.core.step.tasklet.Tasklet#execute(org.springframework.batch.core.StepContribution, org.springframework.batch.core.scope.context.ChunkContext)
     */
    @Override
    public RepeatStatus execute(StepContribution contribution,
            ChunkContext chunkContext) throws Exception {
    	
    	logger.debug("Move file {}", file);
    	
        File fileToMove = file.getFile();
        
        copyDuplicates(fileToMove);
                
        Assert.isTrue(fileToMove.exists(), "Requested file ('" + fileToMove.getAbsolutePath() + "') does not exist?");

    	fileActionHandler.move(fileToMove, destinationDirectory.getFile(), newFileName, zip);
        
        return RepeatStatus.FINISHED;
    }

    /**
     * If duplicateFileNames have been specified then a copy
     * of the 'fileToCopy' is placed in the target directory
     * with the name of each duplicateFileName 
     * @param fileToCopy
     * @throws IOException 
     */
    private void copyDuplicates( File fileToCopy ) throws IOException
    {
    	if( duplicateFileNamePrefixes == null || duplicateFileNamePrefixes.length == 0 ) return;
    	
    	for( String filename : duplicateFileNamePrefixes )
    	{
    		if( !filename.isEmpty() )
    		{
	    		if( duplicateFileNameSuffix != null )
	    		{
	    			filename += duplicateFileNameSuffix;
	    		}
	    		
	    		logger.debug("Creating duplicate file '" + filename + "' from '" + fileToCopy.getAbsolutePath() + "'...");
	    		File newFile = new File( destinationDirectory.getFile().getAbsolutePath() + File.separator + filename );
	    		FileUtils.copyFile(fileToCopy, newFile);
    		}
    	}
    }
    
    /**
     * @param destinationDirectory
     */
    public void setDestinationDirectory(Resource destinationDirectory) {
        this.destinationDirectory = destinationDirectory;
        
        try {
            destinationDirFile = destinationDirectory.getFile();
            
            if (!destinationDirFile.exists()) {
                Assert.isTrue(destinationDirFile.mkdir(), "Failed to create directory '" + destinationDirectory + "'?");
            }
        } catch (IOException e) {
            throw new IllegalArgumentException("Failed to set destination directory of '" + destinationDirectory + "'?", e); 
        }
        
        Assert.isTrue(destinationDirFile.isDirectory(), "Specified destination '" + destinationDirectory + "' is not a directory?");
        Assert.isTrue(destinationDirFile.canWrite(), "Specified destination '" + destinationDirectory + "' must be writeable!");
    }

    public void setNewFileName(String newFileName) {
		this.newFileName = newFileName;
	}

	/**
     * @param file the file to set
     */
    public void setFile(Resource file) {
        this.file = file;
    }

    /**
     * @param zip the zip to set
     */
    public void setZip(boolean zip) {
        this.zip = zip;
    }

    /* (non-Javadoc)
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(destinationDirectory, "Destination (destinationDirectory) must be set");
        Assert.notNull(destinationDirectory, "File must be set");
    }
	
	/**
	 * Sets the duplicateFileNames property from a single string for CSV
	 * making it easier to pass in from job property config
	 * @param duplicateFileNamesAsCSV
	 */
	public void setDuplicateFileNamePrefixesAsCSV( String duplicateFileNamesAsCSV )
	{
		if( duplicateFileNamesAsCSV != null )
			this.duplicateFileNamePrefixes = duplicateFileNamesAsCSV.split(",");
	}

	public String getDuplicateFileNameSuffix()
	{
		return duplicateFileNameSuffix;
	}

	public void setDuplicateFileNameSuffix(String duplicateFileNameSuffix)
	{
		this.duplicateFileNameSuffix = duplicateFileNameSuffix;
	}

	public String[] getDuplicateFileNamePrefixes()
	{
		return duplicateFileNamePrefixes;
	}

	public void setDuplicateFileNamePrefixes(String[] duplicateFileNamePrefixes)
	{
		this.duplicateFileNamePrefixes = duplicateFileNamePrefixes;
	}            
}
