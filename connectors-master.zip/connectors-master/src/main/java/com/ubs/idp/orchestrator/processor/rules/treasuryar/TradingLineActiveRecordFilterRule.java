package com.ubs.idp.orchestrator.processor.rules.treasuryar;

import java.util.Map;

import org.springframework.batch.item.ItemProcessor;

/**
 * Rule that only returns active records for trading line records
 * @author loverids
 *
 */
public class TradingLineActiveRecordFilterRule implements ItemProcessor<Map<String, Object>, Map<String, Object>>
{
	public final static String ACTIVE_ATTRIBUTE_NAME = "tL.active";
	
	@Override
	public Map<String, Object> process(Map<String, Object> inputFields) throws Exception
	{
		// Find a value for the active attributes
		Object value = inputFields.get(ACTIVE_ATTRIBUTE_NAME);
			
		// If we have a value determine if it is set to active
		if( value != null )
		{
			if( value.toString().toLowerCase().equals("true") ||  
				value.toString().toLowerCase().equals("t") ||
				value.toString().toLowerCase().equals("yes") || 
				value.toString().toLowerCase().equals("y") ||
				value.toString().toLowerCase().equals("1") )
			{
				return inputFields;
			}
			else
			{
				return null;
			}
		}
		
		return inputFields;
	}

}