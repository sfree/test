package com.ubs.idp.orchestrator.processor.rules;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.item.ItemProcessor;



/**
 * Note that this Rule relies on another rule having being run, namely the AssetTypeRule.
 * This class expects the derived value to be present in the input fields.
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Fixed Income Asset Type section)
 * 
 * @author haniffsy
 */
public class FIAssetTypeRule extends DerivationRuleTemplate implements ItemProcessor<Map<String,Object>,Map<String,Object>>{

	/*
	 * These are constants that the FIAssetTypeRule uses to compare to the input field values
	 */
	static final String MBS_ARM = "MBS ARM";
	static final String GN = "GN";
	static final String FN = "FN";
	static final String FG = "FG";
	static final String GNR = "GNR";
	static final String FNR = "FNR";
	static final String FHR = "FHR";
	static final String INDEX_LINKED = "IndexLinked";
	static final String BILLS = "BILLS";	
	static final String[] BILLS_TICKERS = {"RATB","BGTB","CTB","DGTB","RTFB","BTF","BUBILL","HKTB","IRTB","BOTS","JGTB","SKFB","DTB","NZTB","NGTB","SITB","SGLT","SWTB","SWNBK","SWISTB","UKTB"};
	static final String[] NOTES_TICKERS = {"BTNS","THA","DBSB","FSDB","CCTS"};
	static final String[] BOND_TICKERS = {"RAGB","BGB","CAN","CANADA","DGB","RFGB","FRTR","BKO","OBL","DBR","HKGB","IRISH","ICTZ","BTPS","JGB","KOREA","NDFB","LGB","NETHER","NZGB","NGB","SIGB","SPGB","SGB","SWISS","UKT"};
	static final String US = "US";
	static final String INSTRUMENT_DATE_FORMAT = "yyyyMMdd";
	static final String STRIPS = "STRIPS";
	static final String COUPON = "Coupon";
	static final String STRIP_INTEREST_REGEX = "^.*STRIP.*INTEREST.*$";
	static final String RESOLUTION_FUNDING_STRIP = "RESOLUTION FUNDING STRIP";
	static final String RESOLUTION_FUNDING_PRINCIPAL_STRIP = "RESOLUTION FUNDING PRINCIPAL STRIP";
	static final String PRINCIPAL = "Principal";
	static final String STRIP_PRINC = "STRIP PRINC";
	static final String STRIP_PRINCIPAL_REGEX = "^.*STRIP.*PRINCIPAL.*$";
	static final String COUPON_STRIP_REGEX = "^.*COUPON.*STRIP.*$";
	static final String CPN_STRIP_REGEX = "^.*CPN.*STRIP.*$";
	static final String PRIN_STRIP_REGEX = "^.*PRIN.*STRIP.*$";
	
	static final String[] PRINCIPAL_STRIP_REGEX_LIST = {STRIP_PRINCIPAL_REGEX,COUPON_STRIP_REGEX,CPN_STRIP_REGEX,PRIN_STRIP_REGEX};
	static final String[] PRINCIPAL_STRIP_TICKERS = {"CANRDC","FRTRR","JGBP","NETHRR","OLOR","ITALYP","KOREAP","DBRR","SP","SPGBR","SGBR","SPX","BTPSR","TGR","UKTR"}; 
	
	static final String DISCOUNT_NOTE_REGEX = "^.*DISCOUNT.*NOTE.*$";
	static final String DISCOUNT_BILL_REGEX = "^.*DISCOUNT.*BILL.*$";
	static final String DISCOUNT_BOND_REGEX = "^.*DISCOUNT.*BOND.*$";

	static final String GOVT_GUARANTEED_REGEX = "^.*GOVT.*GUARANTEED.*$";
	static final String GOVT_LIQUID_GTD_REGEX = "^.*GOVT.*LIQUID.*GTD.*$";
	
	
	
	/*
	 * These are the derived values that the FIAssetTypeRule needs to emit
	 */
	static final String ADJUSTABLE_RATE_PASS_THROUGHS_DERIVED = "Adjustable Rate Pass Throughs";
	static final String FIXED_RATE_PASS_THROUGHS_DERIVED = "Fixed Rate Pass Throughs";
	static final String REMIC_DERIVED = "REMIC - Real Estate Mortgage Conduit";
	static final String INDEX_LINKED_DERIVED = "Index Linked";
	static final String BILLS_DERIVED = "Bills";
	static final String NOTES_DERIVED = "Notes";
	static final String BOND_DERIVED = "Bond";
	static final String INTEREST_STRIP_DERIVED = "Interest Strip";	
	static final String PRINCIPAL_STRIP_DERIVED = "Principal Strip";
	static final String CONVERTIBLE_DERIVED = "Convertible";
	static final String DISCOUNT_NOTES_DERIVED = "Discount Notes";
	static final String GOVT_GUARANTEED_DERIVED = "Govt Guaranteed";

	@Override
	public Map<String, Object> applyRules(Map<String, Object> inputFields) {

		Map<String,Object> derivedFields = new HashMap<String,Object>();		
		
		// input parameters to test
		String c                  = getMappedInputField(UBS_CFI_CODE,inputFields);
		String assetType          = getMappedInputField(DERIVED_ASSET_TYPE,inputFields);
		String bbgSecurityType    = getMappedInputField(BLOOMBERG_SECURITY_TYPE,inputFields);
		String bbgTicker          = getMappedInputField(BLOOMBERG_TICKER,inputFields);
		String couponType         = getMappedInputField(COUPON_TYPE,inputFields);
		String bbgCollateralType  = getMappedInputField(COLLATERAL_TYPE,inputFields);
		String issuerCountry      = getMappedInputField(ISSUER_COUNTRY,inputFields); 
		String issueDate          = getMappedInputField(ISSUE_DATE,inputFields);
		String maturityDate       = getMappedInputField(MATURITY_DATE,inputFields);
		String stripType          = getMappedInputField(STRIP_TYPE,inputFields);
		String shortName          = getMappedInputField(SHORT_NAME,inputFields);
		String issuerName         = getMappedInputField(ISSUER_NAME,inputFields);
		
        CFICode cfi = (null == c) ? null : new CFICode(c);
        
		// If asset type is one of ABS, MBS or Agency and the bloomberg security type is "MBS ARM"
		if (MBS_ARM.equals(bbgSecurityType)) {
			if ((AssetTypeRule.ABS_DERIVED.equals(assetType)) || 
					(AssetTypeRule.MBS_DERIVED.equals(assetType)) || 
					(AssetTypeRule.AGENCY_DERIVED.equals(assetType))) {
				derivedFields.put(DERIVED_FI_ASSET_TYPE, ADJUSTABLE_RATE_PASS_THROUGHS_DERIVED);
			}
		}
		
		// If asset type is one of ABS, MBS or Agency and bloomber ticker is one of GN, FN, FG 
		else if ((GN.equals(bbgTicker)) || (FN.equals(bbgTicker)) || (FG.equals(bbgTicker))) {
			if ((AssetTypeRule.ABS_DERIVED.equals(assetType)) || 
					(AssetTypeRule.MBS_DERIVED.equals(assetType)) || 
					(AssetTypeRule.AGENCY_DERIVED.equals(assetType))) {
				derivedFields.put(DERIVED_FI_ASSET_TYPE, FIXED_RATE_PASS_THROUGHS_DERIVED);
			}
		}
		
		// If asset type is one of ABS, MBS or Agency and bloomber ticker is one of GNR, FNR, FHR
		else if ((GNR.equals(bbgTicker)) || (FNR.equals(bbgTicker)) || (FHR.equals(bbgTicker))) {
			if ((AssetTypeRule.ABS_DERIVED.equals(assetType)) || 
					(AssetTypeRule.MBS_DERIVED.equals(assetType)) || 
					(AssetTypeRule.AGENCY_DERIVED.equals(assetType))) {
				derivedFields.put(DERIVED_FI_ASSET_TYPE, REMIC_DERIVED);
			}
		} 
		
			
		// If cfi 7th char is G and coupont type is IndexLined
		else if ((cfi != null) && ("G".equals(cfi.atPosition(7))) && (INDEX_LINKED.equals(couponType))) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, INDEX_LINKED_DERIVED);
		}
			
		// see below for (complex) bills logic
		else if (checkBills(cfi, bbgCollateralType, bbgTicker, issuerCountry, issueDate, maturityDate)) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, BILLS_DERIVED);
		}
			
		// see below for (complex) notes logic
		else if (checkNotes(cfi, bbgCollateralType, bbgTicker, issuerCountry, issueDate, maturityDate)) {				
			derivedFields.put(DERIVED_FI_ASSET_TYPE, NOTES_DERIVED);
		}
			
		// see below for (complex) bond logic
		else if (checkBond(cfi, bbgCollateralType, bbgTicker, issuerCountry, issueDate, maturityDate)) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, BOND_DERIVED);
		}	
		
		
		// If strip coupon ...
		else if (COUPON.equals(stripType)) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, INTEREST_STRIP_DERIVED);
		}
		
		// .. or short name equals "STRIPS" and issuer country is "US" 
		else if ((STRIPS.equals(shortName)) && US.equals(issuerCountry)) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, INTEREST_STRIP_DERIVED);
		}
		
		// ... or short name matches STRIP*INTEREST*
		else if (shortName != null && shortName.matches(STRIP_INTEREST_REGEX)) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, INTEREST_STRIP_DERIVED);
		}
		
		// ... or short name equals "RESOLUTION FUNDING STRIP"
		else if (RESOLUTION_FUNDING_STRIP.equals(shortName)) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, INTEREST_STRIP_DERIVED);
		}
		
		
		// complex logic for principal strip below
		else if (checkPrincipalStrip(stripType, issuerCountry, shortName, bbgTicker)) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, PRINCIPAL_STRIP_DERIVED);
		}
		
		// If cfi begins with "DC"
		else if ((cfi != null) && ("D".equals(cfi.atPosition(1))) && ("C".equals(cfi.atPosition(2)))) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, CONVERTIBLE_DERIVED);
		}
		
		
		// TODO Check with David Cifer whether Discount Notes tests should be for the issuer name (specified) or the issue name

		
		// If issuer name match (DISCOUNT*NOTE*|DISCOUNT*BILL*|DISCOUNT*BOND*)
		else if ((issuerName != null) && issuerName.matches(DISCOUNT_NOTE_REGEX)) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, DISCOUNT_NOTES_DERIVED);
		}

		// If issuer name match (DISCOUNT*NOTE*|DISCOUNT*BILL*|DISCOUNT*BOND*)
		else if ((issuerName != null) && issuerName.matches(DISCOUNT_BILL_REGEX)) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, DISCOUNT_NOTES_DERIVED);
		}

		// If issuer name match (DISCOUNT*NOTE*|DISCOUNT*BILL*|DISCOUNT*BOND*)
		else if ((issuerName != null) && issuerName.matches(DISCOUNT_BOND_REGEX)) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, DISCOUNT_NOTES_DERIVED);
		}

		// if bbCollateralType match (GOVT*GUARANTEED*|GOVT*LIQUID*GTD*)
		else if ((bbgCollateralType != null) && bbgCollateralType.matches(GOVT_GUARANTEED_REGEX)) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, GOVT_GUARANTEED_DERIVED);
		}
		
		// if bbCollateralType match (GOVT*GUARANTEED*|GOVT*LIQUID*GTD*)
		else if ((bbgCollateralType != null) && bbgCollateralType.matches(GOVT_LIQUID_GTD_REGEX)) {
			derivedFields.put(DERIVED_FI_ASSET_TYPE, GOVT_GUARANTEED_DERIVED);
		}

		return derivedFields;
	}

	
	/*
	 * TODO 
	 * checkBills, checkNotes, checkBond *could* be refactored in to a single method which
	 * would avoid the repetition in the code - i.e. make DRY-er
	 * This might make it more difficult to test and / or understand though ...
	 */
	
	/*
	 * TODO Make me DRY-er
	 * If cfi 7th char id G 
	 * and Bloomberg Collateral Type match ("MORTGAGE*BACKED|"ASSET*BACKED) 
	 * and ( bbCollateral Type is BILLS or bbTicker is one of RATB,BGTB,CTB,DGTB,RTFB,BTF,BUBILL,HKTB,IRTB,BOTS,JGTB,SKFB,DTB,NZTB,NGTB,SITB,SGLT,SWTB,SWNBK,SWISTB,UKTB or issuerCountry is US and time between issueDate and maturityDate maximum 12 months long)
	 */
	private boolean checkBills(CFICode cfi, String bbgCollateralType,
			String bbgTicker, String issuerCountry, String issueDate,
			String maturityDate) {
		
		// minimal success criteria
		if (null == cfi || null == bbgCollateralType)
			return false;
		
		boolean isBills = false;
		
		// If cfi 7th char id G ...
		if ("G".equals(cfi.atPosition(7))) {
			
			// .. and Bloomberg Collateral Type does not match ("MORTGAGE*BACKED|"ASSET*BACKED)
			if ( !bbgCollateralType.matches(AssetTypeRule.MBS_REGEX) &&
				 !bbgCollateralType.matches(AssetTypeRule.ABS_REGEX) ) {
				
				// bbCollateral Type is BILLS 
				if (BILLS.equals(bbgCollateralType)) {
					isBills = true;
				}
				
				// or bbTicker is one of RATB,BGTB,CTB,DGTB,RTFB,BTF,BUBILL,HKTB,IRTB,BOTS,JGTB,SKFB,DTB,NZTB,NGTB,SITB,SGLT,SWTB,SWNBK,SWISTB,UKTB
				else if (Arrays.asList(BILLS_TICKERS).contains(bbgTicker)) {
					isBills = true;
				}
				
				// or issuerCountry is US and time between issueDate and maturityDate maximum 12 months long)
				else if (US.equals(issuerCountry)) {
						
					if (issueDate != null && maturityDate != null) {
						Integer monthsBetween = getMonthsBetween(issueDate, maturityDate);
						if (monthsBetween != null) {
							if (monthsBetween <= 12) {
								isBills = true;
							}
						}						
					}						
				}
				
			}
			
		}

		return isBills;
	}

	/*
	 * TODO Make me DRY-er
	 * If cfi 7th char is G 
	 * and Bloomberg Collateral Type match ("MORTGAGE*BACKED|"ASSET*BACKED) 
	 * and ( bbTicker one of BTNS,THA,DBSB,FSDB,CCTS 
	 * or issuerContry is US and month difference between issueDate and maturityDate is greater than 12 but less then 120 month (1 - 10 year)
	 */
	private boolean checkNotes(CFICode cfi, String bbgCollateralType,
			String bbgTicker, String issuerCountry, String issueDate,
			String maturityDate) {
		
		// minimal success criteria
		if (null == cfi || null == bbgCollateralType)
			return false;
		
		boolean isNotes = false;
		
		// If cfi 7th char id G ...
		if ("G".equals(cfi.atPosition(7))) {
			
			// .. and Bloomberg Collateral Type match ("MORTGAGE*BACKED|"ASSET*BACKED)
			if ( !bbgCollateralType.matches(AssetTypeRule.MBS_REGEX) &&
			     !bbgCollateralType.matches(AssetTypeRule.ABS_REGEX) ) {
				
				// .. and ( ...
				
				// bbTicker is one of BTNS,THA,DBSB,FSDB,CCTS
				if (Arrays.asList(NOTES_TICKERS).contains(bbgTicker)) {
					isNotes = true;
				}
				
				// or issuerContry is US and month difference between issueDate and maturityDate is greater than 12 but less then 120 month (1 - 10 year)
				else if (US.equals(issuerCountry)) {
						
					if (issueDate != null && maturityDate != null) {
						Integer monthsBetween = getMonthsBetween(issueDate, maturityDate);
						if (monthsBetween != null) {
							if (monthsBetween > 12 && monthsBetween <= 120) {
								isNotes = true;
							}
						}						
					}						
				}
				
			}
			
		}

		return isNotes;
	}	
	
	/*
	 * TODO Make me DRY-er
	 * If cfi 7th char is G 
	 * and Bloomberg Collateral Type match ("MORTGAGE*BACKED|"ASSET*BACKED) 
	 * and ( bbTicker one of BTNS,THA,DBSB,FSDB,CCTS 
	 * or issuerContry is US and month difference between issueDate and maturityDate is greater than 12 but less then 120 month (1 - 10 year)
	 */
	private boolean checkBond(CFICode cfi, String bbgCollateralType,
			String bbgTicker, String issuerCountry, String issueDate,
			String maturityDate) {
		
		// minimal success criteria
		if (null == cfi || null == bbgCollateralType)
			return false;
		
		boolean isBond = false;
		
		// If cfi 7th char id G ...
		if ("G".equals(cfi.atPosition(7))) {
			
			// .. and Bloomberg Collateral Type match ("MORTGAGE*BACKED|"ASSET*BACKED)
			if ( !bbgCollateralType.matches(AssetTypeRule.MBS_REGEX) &&
				 !bbgCollateralType.matches(AssetTypeRule.ABS_REGEX) ) {
				
				// .. and ( ...
				
				// and (bbTicker one of RAGB,BGB,CAN,DGB,RFGB,FRTR,BKO,OBL,DBR,HKGB,IRISH,ICTZ,BTPS,JGB,KOREA,NDFB,LGB,NETHER,NZGB,NGB,SIGB,SPGB,SGB,SWISS,UKT
				if (Arrays.asList(BOND_TICKERS).contains(bbgTicker)) {
					isBond = true;
				}
				
				// or difference between maturity and issue date is more than 10 year)
				if (issueDate != null && maturityDate != null) {
					Integer monthsBetween = getMonthsBetween(issueDate, maturityDate);
					if (monthsBetween != null) {
						if (monthsBetween > 120) {
							isBond = true;
						}
					}
				}
			}
			
		}

		return isBond;
	}	
	
	/* 
	 * If is strip principal 
	 * or issuer country is US and short name is STRIP PRINC 
	 * or matches (STRIP*PRINCIPAL*|COUPON*STRIP*|CPN*STRIP*|PRIN*STRIP*) 
	 * or short name equals "RESOLUTION FUNDING PRINCIPAL STRIP" 
	 * or bbTicker one of CANRDC,FRTRR,JGBP,NETHRR,OLOR,ITALYP,KOREAP,DBRR,SP,SPGBR,SGBR,SPX,BTPSR,TGR,UKTR,
	 */
	private boolean checkPrincipalStrip(String stripType, String issuerCountry,
			String shortName, String bbgTicker) {
		
		boolean isPrincipalStrip = false;
		
		// If is strip principal ...
		if (PRINCIPAL.equals(stripType)) {
			isPrincipalStrip = true;
		}
		
		// ... or issuer country is US and short name is STRIP PRINC
		else if (STRIP_PRINC.equals(shortName) && US.equals(issuerCountry)) {
			isPrincipalStrip = true;
		}
		
		// ... or bbTicker one of CANRDC,FRTRR,JGBP,NETHRR,OLOR,ITALYP,KOREAP,DBRR,SP,SPGBR,SGBR,SPX,BTPSR,TGR,UKTR
		else if (Arrays.asList(PRINCIPAL_STRIP_TICKERS).contains(bbgTicker)) {
			isPrincipalStrip = true;
		}
		
		// ... or short name equals "RESOLUTION FUNDING PRINCIPAL STRIP"
		else if (RESOLUTION_FUNDING_PRINCIPAL_STRIP.equals(shortName)) {
			isPrincipalStrip = true;
		}
		
		// ... or shortName matches (STRIP*PRINCIPAL*|COUPON*STRIP*|CPN*STRIP*|PRIN*STRIP*)
		else {
			for (int i = 0; i < PRINCIPAL_STRIP_REGEX_LIST.length; i++) {
				String regex = PRINCIPAL_STRIP_REGEX_LIST[i];
				if (shortName != null && shortName.matches(regex)) {
					isPrincipalStrip = true;
					break;
				}
			}
		}
		
		return isPrincipalStrip;
	}	
	
	
	private Integer getMonthsBetween(String issueDate, String maturityDate) {
		Integer monthsBetween = null;
		
		Date dtIssueDate = makeDateFromyyyyMMdd(issueDate);
		Date dtMaturityDate = makeDateFromyyyyMMdd(maturityDate);
		
		if (dtIssueDate != null && dtMaturityDate != null) {
			int mb = org.joda.time.Months.monthsBetween(new org.joda.time.DateTime(dtIssueDate), new org.joda.time.DateTime(dtMaturityDate)).getMonths();
			monthsBetween = mb;
		}
		
		return monthsBetween;
	}

	/**
	 * From the DAS some dates have the value of -9999 ... not clear what this indicates
	 * so will need to determine this and handle appropriately
	 * @param inputDate Expects inputDate as yyyyMMdd (e.g. 20140904) or -9999
	 * @return A date or <code>null</code> if the date can't be parsed
	 */
	private Date makeDateFromyyyyMMdd(String inputDate) {
		
		// TODO Decide what to do with inputDates of -9999
		
		Date output = null;
		
		SimpleDateFormat yyyyMMdd = new SimpleDateFormat(INSTRUMENT_DATE_FORMAT);
		
		try {
			output = yyyyMMdd.parse(inputDate);
		}
		catch(ParseException pe) {
			output = null;		// be explicit
			// TODO log me ?
		}
		
		return output;
	}


	@Override
	public Map<String, Object> process(Map<String, Object> item) throws Exception
	{
		return derive(item);
	}

	

}


