package com.ubs.idp.orchestrator.processor.rules;

import java.util.HashMap;
import java.util.Map;

/**
 * TemplateMethod
 * @author haniffsy
 *
 */
public abstract class DerivationRuleTemplate implements DerivationRule {

    // TODO Map these keys to the actual fields in the IDP or RDDH instrument data

    // keys used by CouponTypeRule
    public static final String COUPON_TYPE = "coupon.couponType";
    public static final String DERIVED_COUPON_TYPE = "derived.couponType";

    // keys used by AssetTypeRule
    public static final String UBS_CFI_CODE = "issue.ubsIsoCfi";
    public static final String CFI_CODE = "issue.isoCfi";
    public static final String BLOOMBERG_SECURITY_TYPE = "issue.bbSecurityType";
    public static final String BLOOMBERG_YELLOW_KEY = "issue.bbYellowKey";
    public static final String BLOOMBERG_INDUSTRY_GROUP = "issuer.bbIndustryGroup";
    public static final String BLOOMBERG_INDUSTRY_SUBGROUP = "issuer.bbIndustrySubGroup";
    public static final String COLLATERAL_TYPE = "issue.collateralType";
    public static final String MARKET_ISSUE_TYPE = "issue.marketIssueType";

    // Derived fields
    public static final String DERIVED_ASSET_TYPE = "derived.assetType";

    // keys used by AssetClassRule
    public static final String DERIVED_ASSET_CLASS = "derived.assetClass";

    // keys used by FIAssetTypeRule
    public static final String CALL_TYPE = "bond.callOptionType";
    public static final String BLOOMBERG_TICKER = "issue.bbTicker";
    public static final String STRIP_TYPE = "bond.stripType";
    public static final String SHORT_NAME = "issue.shortName";
    public static final String ISSUER_COUNTRY = "issuer.countryOfIncorporation";
    public static final String ISSUER_NAME = "issuer.issuerName";

    /** YYYYMMDD or -9999 meaning ?? */
    public static final String ISSUE_DATE = "issue.issueDate";

    /** TODO Verify below
     * Assumed YYYYMMDD or -9999 meaning ??
     * */
    public static final String MATURITY_DATE = "bond.maturityDate";

    // Derived fields
    public static final String DERIVED_FI_ASSET_TYPE = "derived.FIAssetType";
    public static final String DERIVED_IS_CALLABLE = "derived.isCallable";
	public static final String DERIVED_SECFUNDING_ISSUERNAME = "derived.SecFunding.issuerName";

    public static final String DSCURRENCY_ISOCODE = "isoCode";
    // Derived fields for DSCURRENCY
    public static final String DERIVED_DSCURRENCY_ISSUE_ISIN = "issue.isin";
    public static final String DERIVED_DSCURRENCY_ISSUE_CUSIP = "derived.cusip";
    public static final String DERIVED_DSCURRENCY_ISSUE_SEDOL = "derived.sedol";
    public static final String DERIVED_DSCURRENCY_ISSUE_BONDISSUERTYPE = "derived.bondIssuerType";
    public static final String DERIVED_DSCURRENCY_ISSUEFACTOR = "derived.issueFactor";
    public static final String DERIVED_DSCURRENCY_VALUEFACTOR = "derived.valueFactor";
    public static final String ISSUE_ISSUESIZE = "issue.issueSize";
    public static final String DERIVED_DSCURRENCY_MINDENOMINATION = "derived.minDenomination";
    public static final String DERIVED_DSCURRENCY_COUPON_CURRENTCOUPONRATE = "derived.currentCouponRate";
    
    /**
     * Template Method that does basic validity checks on the supplied inputFields.
     * <p>
     * All of the rules should expect a Map holding the attributes needed to perform the
     * tests.<br/>
     * The keys of the map are defined above, whilst the values to be tested and derived
     * are held in the implementing subclasses.<br/>
     * This method combines the original input attributes with those derived attributes
     * returned by the <code>applyRules</code> method of implementing subclasses so the
     * result is the superset of attributes.<br/>
     *
     * @param inputFields
     * @return A Map containing both the input and derived fields
     */
	public final Map<String, Object> derive(Map<String, Object> inputFields) {
		// don't return null even if supplied rubbish
		if (null == inputFields || inputFields.isEmpty())
			return new HashMap<String, Object>();

		Map<String, Object> derivedFields = new HashMap<>(inputFields);
		derivedFields.putAll(applyRules(inputFields));

		return derivedFields;
	}

    /**
     * Subclasses will implement this and apply the rules to the map supplied
     * @param inputFields The fields to perform tests upon
     * @return The derived fields or an empty Map<String,Object>. Implementers must return a non-null object
     */
    public abstract Map<String,Object> applyRules(Map<String, Object> inputFields);

    
    /**
     * Fetches a value from the specified map of input fields
     * @param key
     * @param inputFields
     * @return
     */
    protected String getMappedInputField( String key, Map<String,Object> inputFields )
    {
        String res = null;
        
    	Object value = inputFields.get(key);
    	
    	if (value != null) {
    	    res = value.toString();
    	}
    	
    	return res;
    }

}
