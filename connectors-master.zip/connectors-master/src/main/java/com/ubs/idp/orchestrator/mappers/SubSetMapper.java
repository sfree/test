package com.ubs.idp.orchestrator.mappers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.DefaultFieldSet;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

/**
 * FieldSetMapper that maps values from the original fieldset and extracts
 * a subset of values 
 * 
 * @author loverids
 */
public class SubSetMapper implements FieldSetMapper<FieldSet> 
{
	/**
	 * The field names of the attributes from the incoming fieldset
	 * to extract 
	 */
	private String[] subsetAttributeNames;
	
	/*
	 * (non-Javadoc)
	 * @see org.springframework.batch.item.file.mapping.FieldSetMapper#mapFieldSet(org.springframework.batch.item.file.transform.FieldSet)
	 */
	@Override
	public FieldSet mapFieldSet(FieldSet fieldSet) throws BindException
	{		
		List<String> allFieldNames = Arrays.asList(fieldSet.getNames());
		List<String> allFieldValues = Arrays.asList(fieldSet.getValues());
		
		List<String> subsetNames = new ArrayList<String>();
		List<String> subsetValues = new ArrayList<String>();
		
		for( String fieldName : subsetAttributeNames)
		{
			if( !allFieldNames.contains(fieldName ) )
			{
				throw new RuntimeException("The attribute name '" + fieldName + "' does not exist in the passed in field set: " + allFieldNames );
			}
			
			subsetNames.add( fieldName );
			subsetValues.add( allFieldValues.get( allFieldNames.indexOf( fieldName ) ) );
		}
		
		
		return new DefaultFieldSet(subsetValues.toArray( new String[]{}),subsetNames.toArray(new String[]{}));
	}

	public String[] getSubsetAttributeNames()
	{
		return subsetAttributeNames;
	}

	public void setSubsetAttributeNames(String[] subsetAttributeNames)
	{
		this.subsetAttributeNames = subsetAttributeNames;
	}
	
	
 
}
