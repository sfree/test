package com.ubs.idp.orchestrator.tasklets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

import com.ubs.idp.orchestrator.util.FileActionHandler;

/**
 * @author loverids
 */
public class FileDeleteTasklet implements Tasklet, InitializingBean {

    private Resource file;
    
    private Logger logger = LoggerFactory.getLogger(getClass());
    
    private FileActionHandler fileActionHandler = new FileActionHandler();
    
    /* (non-Javadoc)
     * @see org.springframework.batch.core.step.tasklet.Tasklet#execute(org.springframework.batch.core.StepContribution, org.springframework.batch.core.scope.context.ChunkContext)
     */
    @Override
    public RepeatStatus execute(StepContribution contribution,
            ChunkContext chunkContext) throws Exception {
        
    	fileActionHandler.deleteFile(file.getFile());
        
        return RepeatStatus.FINISHED;
    }

    /**
     * @param file the file to set
     */
    public void setFile(Resource file) {
    	logger.debug("File set to {}", file);
        this.file = file;
    }


    /* (non-Javadoc)
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(file, "File must be set");
    }
}
