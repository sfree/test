package com.ubs.idp.connectors.spring.batch.writers;

import java.util.List;
import java.util.Properties;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

import org.springframework.batch.item.ItemWriter;

/**
 * class to write data to apache kafka 
 * @author rochesi
 *
 */
public class KafkaWriter  implements ItemWriter<String>{

	private ProducerConfig config = null;
	private Producer<String, String> producer = null; 
	
	
	/**
	 * init the kafka producer with the config details 
	 * of the kafka server
	 */
	public void init(){
		
		//Map<String, String> configMap = mds.getKafkaConnectionDetails();
		
		Properties props = new Properties();
		
		props.put("metadata.broker.list", "dhcp-172-19-38-125.pwj.com:9092");
		props.put("serializer.class", "kafka.serializer.StringEncoder");
		props.put("key.serializer.class", "kafka.serializer.StringEncoder");
		props.put("partitioner.class", "com.ubs.idp.orchestrator.writers.SimplePartitioner");
		props.put("request.required.acks", "1");
		
		//props.putAll(configMap);
		config = new ProducerConfig(props);
		producer = new Producer<String, String>(config);
	}
	
	@Override
	public void write(List<? extends String> items) throws Exception {
		
		 for (String item : items) {
			 
			 	 System.out.println(item);
	   			 KeyedMessage<String, String> data = new KeyedMessage<String, String>("topic2", "test", item);
				 producer.send(data);  
		 }
	}
}
