package com.ubs.idp.connectors.spring.batch.writers;

import static org.springframework.util.Assert.notNull;
import static org.springframework.util.Assert.notEmpty;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.InitializingBean;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.ColumnDefinitions;
import com.datastax.driver.core.DataType;
import com.datastax.driver.core.PreparedStatement;
import com.ubs.idp.base.utils.TimeUtils;

/**
 * Reflection based generic object writer
 * @author mcminnp
 */
public class CassandraObjectWriter extends BaseCassandraItemWriter implements ItemWriter<Object>, ItemStream, InitializingBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(CassandraObjectWriter.class);

    private String columnFamily = null;
    private List<String> columnNames = null;
    private List<String> mappings = null;
    
    private String dateFormat = "yyyy-MM-dd HH:mm:ss";
    private String timeZone = "UTC";

    /* (non-Javadoc)
     * @see com.ubs.idp.connectors.spring.batch.writers.BaseCassandraItemWriter#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        notNull(columnFamily, "No insert CQL specified?");
        notNull(columnNames, "No column names specified?");
        notNull(mappings, "No mappings specified?");
        notEmpty(columnNames, "No column names specified?");
        notEmpty(mappings, "No mappings specified?");
        
        super.afterPropertiesSet();
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#open(org.springframework.batch.item.ExecutionContext)
     */
    @Override
    public void open(ExecutionContext executionContext)
            throws ItemStreamException {
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#update(org.springframework.batch.item.ExecutionContext)
     */
    @Override
    public void update(ExecutionContext executionContext)
            throws ItemStreamException {
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#close()
     */
    @Override
    public void close() throws ItemStreamException {
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemWriter#write(java.util.List)
     */
    @Override
    public void write(List<? extends Object> items) throws Exception {
        BatchStatement batchStatement = new BatchStatement();
        
        ValueBinderImpl binder = new ValueBinderImpl();
        
        // Get insertStatement CQL
        
        String insertStatement = getInsertCQL();

        LOGGER.debug("Insert CQL: {} ", insertStatement);

        for (Object object : items) {
            LOGGER.debug("Process object {}..", object);

            // Get prepared statement

            PreparedStatement preparedStatement = proxy.getPrepareStatement(insertStatement);
            
            // Bind fields as we find them
            BoundStatement boundStatement = preparedStatement.bind();
            
            binder.setBoundStatement(boundStatement);
            binder.setPreparedStatement(preparedStatement);

            processMappings(object, binder);

            // Add to batch
            batchStatement.add(boundStatement);
        }

        proxy.executeStatement(batchStatement);
    }
    
    /**
     * Build insert CQL
     * @return
     */
    private String getInsertCQL() {
        String insertStatement = "insert into " + columnFamily + " (";
        String bindVars = "";
        
        for (int colIdx = 0 ; colIdx < columnNames.size() ; colIdx++) {
            if (colIdx > 0) {
                insertStatement += ",";
                bindVars += ",";
            }
            
            insertStatement += columnNames.get(colIdx);
            bindVars += "?";
        }

        insertStatement += ") values (" + bindVars + ")";
        
        return insertStatement;
    }

    /**
     * Process the mappings and write data
     * @param object
     * @param binder
     * @throws Exception
     */
    public void processMappings(Object object, ValueBinder binder) throws Exception {
        // Iterate mappings

        int bindVarIdx = 0;

        for (String mapping : mappings) {
            processMapping(object, mapping, binder, bindVarIdx);
            bindVarIdx++;
        }
    }
    
    /**
     * Process individual mapping
     * @param object
     * @param mapping
     * @param binder
     * @param bindVarIdx
     * @throws Exception 
     */
    private void processMapping(Object object, String mapping, ValueBinder binder, int bindVarIdx) throws Exception {
        LOGGER.debug("Process mapping '" + mapping + "'...");

        String valueExpr;
        String keyExpr = null;

        Object keys = null;
        Object valueOrValues = null;

        if (mapping.indexOf(",") > 0) {
            String[] parts = mapping.split(",");

            keyExpr = parts[0].trim();
            valueExpr = parts[1].trim();
            keys = getValue(object, keyExpr);

            LOGGER.debug("Got keys: " + keys);
        } else {
            valueExpr = mapping;
        }

        valueOrValues = getValue(object, valueExpr);

        LOGGER.debug("Got raw value(s): " + valueOrValues);

        // TODO: Caching of reflection stuff - check in with Steve Mc on need/best practice
        if (keyExpr != null) {
            // We have a map so override values
            valueOrValues = mapKeyValuePairs(keys, valueOrValues);
        }

        LOGGER.debug("Got final value(s): " + valueOrValues);

        // Bind to statement

        binder.bindValue(valueOrValues, bindVarIdx);
    }

    /**
     * Turn 2x lists into hashmap (assumes list values are positionally accurate)
     * @param keys
     * @param values
     * @return
     */
    private Object mapKeyValuePairs(Object keys, Object values) {
        Map<String, Object> map = new HashMap<String, Object>();

        if (keys == null && values == null) {
            // if no data found, return empty map
            return map;
        }
        
        if (keys instanceof List && values instanceof List) {
            // Both lists - check size and generate map

            map = new HashMap<String, Object>();

            List<Object> lkeys = (List)keys;
            List<Object> lvalues = (List)values;

            if (lkeys.size() != lvalues.size()) {
                // TODO: Think about this one!
                throw new RuntimeException("Key/value list size mismatch? (" + lkeys.size() + " vs " + lvalues.size() + ")");
            }

            int i = 0;

            for (Object key : lkeys) {
                Object value = lvalues.get(i++);
                map.put(key.toString(), value);
            }
        } else {
            // TODO: Think about this bit
            throw new RuntimeException("Type mismatch - need two lists to build map?");
        }

        return map;
    }

    /**
     * Look up individual value or list of values
     * @param objectIn 
     * @param key
     * @return
     * @throws Exception
     */
    private Object getValue(Object objectIn, String key) throws Exception {
        Object res = null;

        // Specific macros
        if (key.equals("now()")) {
            // TODO: Joda time
            return TimeUtils.now(timeZone, dateFormat);
        } else if (key.equals("currentTimeMillis()")) {
            return System.currentTimeMillis();
        } else {
            res = getAttr(objectIn, key);
        }

        return res;
    }
    
    /**
     * Parse key and descend object hierarchy
     * @param objectIn
     * @param key
     * @return
     * @throws Exception
     */
    private Object getAttr(Object objectIn, String key) throws Exception {
        Object res = null;
        
        String[] parts = key.split("\\.");
        int depth = 0;
        
        // Descend through object tree
        for (String part : parts) {
            String getter = null;
            Object param = null;
            if (part.contains("[")) {
                String argVal = part.substring(part.indexOf('[')+1, part.length()-1);
                param = getAttr(objectIn, argVal);
                getter ="get" + part.substring(0, 1).toUpperCase() + part.substring(1, part.indexOf('['));
            } else {
                getter ="get" + part.substring(0, 1).toUpperCase() + part.substring(1);
            }
            
            if (depth == 0) {
                // At 1st level, use parent object getter
                res = getterValue(getter, param, objectIn);
            } else {
                // At subsequent levels, use last object getter
                // (if non-null)
                if (res != null) {
                    // If it's a list, build output list
                    if (res instanceof List) {
                        List<Object> output = new ArrayList<>();
                        for (Object entry : ((List) res)) {
                            Object newObject = getterValue(getter, param, entry);
                            output.add(newObject);
                        }
                        res = output;
                    } else {
                        res = getterValue(getter, param, res);
                    }
                }
            }
            depth++;
        } 
        return res;
    }

    private Object getterValue(String getter, Object param, Object entry) throws NoSuchMethodException,
            IllegalAccessException, InvocationTargetException {
        Object newObject = null;
        if (entry == null) {
            // TODO: Think about this bit
            throw new RuntimeException("A null entry was passed with a getter: " + getter + " and param: " + param);
        }
        if (param != null) {
            Method method = entry.getClass().getMethod(getter, param.getClass());
            newObject = method.invoke(entry, param);
        } else {
            Method method = entry.getClass().getMethod(getter);
            newObject = method.invoke(entry);
        }
        return newObject;
    }

    // Getters and setters...

    public String getColumnFamily() {
        return columnFamily;
    }

    public void setColumnFamily(String columnFamily) {
        this.columnFamily = columnFamily;
    }

    public List<String> getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(List<String> columnNames) {
        this.columnNames = columnNames;
    }

    public List<String> getMappings() {
        return mappings;
    }

    public void setMappings(List<String> mappings) {
        this.mappings = mappings;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    /**
     * Interface
     * @author mcminnp
     */
    public interface ValueBinder {
        /**
         * Value binder
         * @param value
         * @param bindVarIdx
         */
        public void bindValue(Object value, int bindVarIdx);
    }
    
    /**
     * Basic implementation
     * @author mcminnp
     */
    public class ValueBinderImpl implements ValueBinder {
        
        private BoundStatement boundStatement;
        private PreparedStatement preparedStatement;
        
        /**
         * Setter
         * @param boundStatement
         */
        public void setBoundStatement(BoundStatement boundStatement) {
            this.boundStatement = boundStatement;
        }

        /**
         * Setter
         * @param preparedStatement
         */
        public void setPreparedStatement(PreparedStatement preparedStatement) {
            this.preparedStatement = preparedStatement;
        }

        /* (non-Javadoc)
         * @see com.ubs.idp.connectors.spring.batch.writers.CassandraObjectWriter.ValueBinder#bindValue(java.lang.Object, int)
         */
        @SuppressWarnings("unchecked")
        @Override
        public void bindValue(Object value,
                int bindVarIdx) {
            
            ColumnDefinitions colDefs = preparedStatement.getVariables();
            
            DataType dataType = colDefs.getType(bindVarIdx);
            
            if (dataType.equals(DataType.map(DataType.varchar(), DataType.varchar()))) {
                // Writing an empty map results in a null in Cassandra anyway
                if (value == null || ((Map)value).size() == 0) {
                    boundStatement.setMap(bindVarIdx, null);
                } else {
                    boundStatement.setMap(bindVarIdx, (Map)value);
                }
            } else if (dataType.equals(DataType.map(DataType.varchar(), DataType.cint()))) {
                // Writing an empty map results in a null in Cassandra anyway
                if (value == null || ((Map)value).size() == 0) {
                    boundStatement.setMap(bindVarIdx, null);
                } else {
                    boundStatement.setMap(bindVarIdx, (Map)value);
                }
            } else if (dataType.equals(DataType.list(DataType.varchar()))) {
                // Writing an empty list results in a null in Cassandra anyway
                if (value == null || ((List)value).size() == 0) {
                    boundStatement.setList(bindVarIdx, null);
                } else {
                    boundStatement.setList(bindVarIdx, (List)value);
                }
            } else if (dataType.equals(DataType.map(DataType.varchar(), DataType.cfloat()))) {
                // Writing an empty map results in a null in Cassandra anyway
                if (value == null || ((Map)value).size() == 0) {
                    boundStatement.setMap(bindVarIdx, null);
                } else {
                    boundStatement.setMap(bindVarIdx, (Map)value);
                }
            } else if (dataType.equals(DataType.varchar())) {
                boundStatement.setString(bindVarIdx, (String)value);
            } else if (dataType.equals(DataType.bigint())) {
                boundStatement.setLong(bindVarIdx, (Long)value);
            } else if (dataType.equals(DataType.cfloat())) {
                boundStatement.setFloat(bindVarIdx, (Float)value);
            } else if (dataType.equals(DataType.timestamp())) {
                boundStatement.setDate(bindVarIdx, (Date)value);
            } else if (dataType.equals(DataType.cboolean())) {
                boundStatement.setBool(bindVarIdx, (Boolean)value);
            } else {
                throw new IllegalArgumentException("Not yet implemented for type " + dataType);
            }
        }
    }
}
