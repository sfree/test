package com.ubs.idp.orchestrator.util;

import com.ubs.idp.metadata.client.MetadataService;
import org.springframework.jms.core.JmsTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MetaDataRetrieverUtil {

    private MetadataService mdsClient;
    private String source;
    private Map<String, JmsTemplate> jmsChannels;
    private String mfEventDataSet;

    public List<Integer> getPropCodes() {

        List<Integer> servicePropCodes = new ArrayList<>();
        List<Map<String,String>> dataSetFilterAttributes = mdsClient.getDataSetFilterAttributes(mfEventDataSet);
        for (Map<String, String> dataStringStringMap : dataSetFilterAttributes) {
            servicePropCodes.add(Integer.parseInt(dataStringStringMap.get("propCode")));
        }
        return servicePropCodes;
    }

    public Integer getRetryCount(final String servicePropCode) {

        //Calling the MDS every time to get latest parameters, this can be loaded once if needed and values can be retrieved from memory.
        List<Map<String,String>> dataSetFilterAttributes = mdsClient.getDataSetFilterAttributes(mfEventDataSet);
        for (Map<String, String> propertyMappingAttributes : dataSetFilterAttributes) {
            if (servicePropCode.equals(propertyMappingAttributes.get("propCode"))) {
                return Integer.parseInt(propertyMappingAttributes.get("maxRetryCount"));
            }
        }
        return null;
    }

    public JmsTemplate getJmsTemplateForView(String viewId) {

        return jmsChannels.get(mdsClient.getChannelWithViewId("ConsumerView"+viewId));
    }

    public void setMdsClient(MetadataService mdsClient) {
        this.mdsClient = mdsClient;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void setJmsChannels(Map<String, JmsTemplate> jmsChannels) {
        this.jmsChannels = jmsChannels;
    }

    public void setMfEventDataSet(String mfEventDataSet) {
        this.mfEventDataSet = mfEventDataSet;
    }
}
