package com.ubs.idp.orchestrator.writers;

import kafka.producer.Partitioner;
import kafka.utils.VerifiableProperties;
 

public class SimplePartitioner implements Partitioner<String> {
    
	public SimplePartitioner (VerifiableProperties props) {
 
    }
 
    public int partition(String key, int a_numPartitions) {
    	
    	int partition = 0;
    	
    	return partition;
  }
 
}
