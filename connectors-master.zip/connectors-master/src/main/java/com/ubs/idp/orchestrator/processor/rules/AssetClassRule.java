package com.ubs.idp.orchestrator.processor.rules;

import org.springframework.batch.item.ItemProcessor;

import java.util.HashMap;
import java.util.Map;

/**
 * Note that this Rule relies on another rule having being run, namely the AssetTypeRule.
 * This class expects the derived value to be present in the input fields.
 * @see http://confluence.swissbank.com/display/SBLOMDEV/IDP+mapping+into+CMT
 * (Asset Class definition section)
 *
 * @author haniffsy
 */
public class AssetClassRule extends DerivationRuleTemplate implements ItemProcessor<Map<String,Object>,Map<String,Object>>{

    /*
     * These are the derived values that the AssetClassRule needs to emit
     */
    static final String FIXED_INCOME = "Fixed Income";
    static final String EQUITY = "Equity";
    static final String MONEY_MARKET = "Money Market";
    static final String WARRANTS = "Warrants";
    static final String FUTURES = "Futures";
    static final String OPTION = "Option";
    static final String OTHER = "Other";

    @Override
    public Map<String, Object> applyRules(Map<String, Object> inputFields) {

        Map<String,Object> derivedFields = new HashMap<String,Object>();

        // input parameters to test
        String c = (null == inputFields.get(UBS_CFI_CODE)) ? null : inputFields.get(UBS_CFI_CODE).toString();
        
        // IDP-642: Using 'issue.isoCfi' if no value for 'issue.ubsIsoCfi' not present
        if( c == null )
        {
        	c = (null == inputFields.get(CFI_CODE)) ? null : inputFields.get(CFI_CODE).toString();
        }
        
        CFICode cfi = (null == c) ? null : new CFICode(c);
        String assetType = (null == inputFields.get(DERIVED_ASSET_TYPE)) ? null : inputFields.get(DERIVED_ASSET_TYPE).toString();

		/*
		 * Derivation logic:
		 * 
		 * 1) Try to derive from the asset type (note this is a derived field so the Asset Type Rule will have to have run)
		 * 2) If no luck then derive from the CFI Code
		 * 
		 * Only put the Asset Class in the derived field if non-null (i.e. derivation has succeeded)
		 */
        String assetClass = null;

        // 1) try asset type
        assetClass = deriveFromAssetType(assetType);

        if (null == assetClass) {
            // 2) try CFI code
            assetClass = deriveFromCFICode(cfi);
        }

        if (assetClass != null) {
            derivedFields.put(DERIVED_ASSET_CLASS, assetClass);
        }


        return derivedFields;
    }



    /*
     * @param The Asset Type to test
     * @return The derived asset class or null if it can't be derived
     *
     */
    private String deriveFromAssetType(final String assetType) {

        // don't bother if rubbish supplied
        if (null == assetType)
            return null;

        String assetClass = null;

        switch (assetType) {

            case AssetTypeRule.CORPORATE_DERIVED:
                assetClass = FIXED_INCOME;
                break;

            case AssetTypeRule.GOVERNMENT_DERIVED:
                assetClass = FIXED_INCOME;
                break;

            case AssetTypeRule.SUPRANATIONAL_DERIVED:
                assetClass = FIXED_INCOME;
                break;

            case AssetTypeRule.MUNICIPAL_DERIVED:
                assetClass = FIXED_INCOME;
                break;

            case AssetTypeRule.AGENCY_DERIVED:
                assetClass = FIXED_INCOME;
                break;

            case AssetTypeRule.MBS_DERIVED:
                assetClass = FIXED_INCOME;
                break;

            case AssetTypeRule.ABS_DERIVED:
                assetClass = FIXED_INCOME;
                break;

            case AssetTypeRule.PFANDBRIEF_DERIVED:
                assetClass = FIXED_INCOME;
                break;

            case AssetTypeRule.JUMBO_PFANDBRIEF_DERIVED:
                assetClass = FIXED_INCOME;
                break;

            case AssetTypeRule.COMMON_EQUITY_DERIVED:
                assetClass = EQUITY;
                break;

            case AssetTypeRule.UIT_DERIVED:
                assetClass = EQUITY;
                break;

            case AssetTypeRule.ADR_DERIVED:
                assetClass = EQUITY;
                break;

            case AssetTypeRule.ETF_DERIVED:
                assetClass = EQUITY;
                break;

            case AssetTypeRule.PREFERENCE_DERIVED:
                assetClass = EQUITY;
                break;

            case AssetTypeRule.REIT_DERIVED:
                assetClass = EQUITY;
                break;

            case AssetTypeRule.GDR_DERIVED:
                assetClass = EQUITY;
                break;

            case AssetTypeRule.EDR_DERIVED:
                assetClass = EQUITY;
                break;

            case AssetTypeRule.CONVERTIBLE_PREFERENCE_SHARES_DERIVED:
                assetClass = EQUITY;
                break;

            case AssetTypeRule.COMMERCIAL_PAPER_DERIVED:
                assetClass = MONEY_MARKET;
                break;

            case AssetTypeRule.CERTIFICATES_OF_DEPOSIT_DERIVED:
                assetClass = MONEY_MARKET;
                break;


            default:
                assetClass = null;		// Unnecessary, but being explicit
                break;

        }

        return assetClass;
    }


    /*
     * @param The CFI Code to test
     * @return The derived asset class or null if it can't be derived
     */
    private String deriveFromCFICode(final CFICode cfi) {

        // don't bother if rubbish supplied
        if (null == cfi)
            return null;

        String assetClass = null;

        // if CFI(1) == D AND CFI(2) != Y
        if ("D".equals(cfi.atPosition(1)) && !("Y".equals(cfi.atPosition(2)))) {
            assetClass = FIXED_INCOME;
        }

        // if CFI(1) == E
        else if ("E".equals(cfi.atPosition(1))) {
            assetClass = EQUITY;
        }

        // if CFI(1) == D AND CFI(2) == Y
        else if ("D".equals(cfi.atPosition(1)) && ("Y".equals(cfi.atPosition(2)))) {
            assetClass = MONEY_MARKET;
        }


        // IF CFI(1,2) == RW
        else if ("R".equals(cfi.atPosition(1)) && ("W".equals(cfi.atPosition(2)))) {
            assetClass = WARRANTS;
        }

        // IF CFI(1,2) == MM
        else if ("M".equals(cfi.atPosition(1)) && ("M".equals(cfi.atPosition(2)))) {
            assetClass = WARRANTS;
        }

        // IF CFI(1) == F
        else if ("F".equals(cfi.atPosition(1))) {
            assetClass = FUTURES;
        }

        // IF CFI(1) == O
        else if ("O".equals(cfi.atPosition(1))) {
            assetClass = OPTION;
        }

        // IF CFI(1,2) == RM
        else if ("R".equals(cfi.atPosition(1)) && "M".equals(cfi.atPosition(2))) {
            assetClass = OTHER;
        }

        // IF CFI(1) == M AND CFI(2) NOT M (no need to test CFI(2) != M as we have picked up CFI(2) == M above)
        else if ("M".equals(cfi.atPosition(1))) {
            assetClass = OTHER;
        }

        return assetClass;

    }

    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        return derive(item);
    }
}


