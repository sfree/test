package com.ubs.idp.orchestrator.transformers;

public interface XmlTransformer {
	
	public String transformXmlMessage(String xml) throws Exception;

}
