package com.ubs.idp.connectors;

public interface Connector {

}
