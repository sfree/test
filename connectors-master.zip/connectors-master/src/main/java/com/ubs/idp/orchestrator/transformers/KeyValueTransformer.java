package com.ubs.idp.orchestrator.transformers;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.transform.FieldSet;

public class KeyValueTransformer implements ItemProcessor<FieldSet,FieldSet> {
    @Override
    public FieldSet process(FieldSet item) throws Exception {
        return item;
    }
}
