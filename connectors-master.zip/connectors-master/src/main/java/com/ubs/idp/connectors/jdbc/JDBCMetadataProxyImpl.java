package com.ubs.idp.connectors.jdbc;

import static org.springframework.util.StringUtils.isEmpty;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import com.ubs.idp.encrypt.Crypto;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.model.JDBCChannel;
import com.ubs.idp.connectors.jdbc.JDBCProxy;


/**
 * <p>Datasource wrapper to support:</p>
 * <ul>
 *   <li>Package scanned injection of a Spring framework SimpleDriverDataSource with id "feedDataSource"</li>
 *   <li>Driver JARs in xd/modules/job/jobname/lib dir</li>
 *   <li>Driver class names rather than Class</li>
 * </ul>
 * <p>Job properties file should contain corresponding entries for XD module properties:</p>
 * <pre>
 * #
 * # Module options
 * #
 * options.srcDataset.type=String
 * options.srcDataset.description=Source dataset e.g.: AccountsAndRXM.MF
 *
 * </pre>
 * @author sureshkp
 */

public class JDBCMetadataProxyImpl implements JDBCProxy {

	private static Logger logger = LoggerFactory.getLogger(JDBCMetadataProxyImpl.class);

	private MetadataService mdsClient;
	private String channelID;
	private String srcDataset;
	private SimpleDriverDataSource bean ;

	/**
	 * This method is used to create a connection  
	 * for JDBC source.
	 * 
	 * @return SimpleDriverDataSource
	 */
	
	@Override
	public SimpleDriverDataSource getDataSource() throws ClassNotFoundException {

		bean = new SimpleDriverDataSource();
		JDBCChannel jdbcChannel  ;
		logger.debug("Fetching database connection details from Metadata for Datasource with ID=" + channelID);
		//TODO: A new method may be needed to get Sybase channel details as its not mapped 
		if (isEmpty(channelID)){
			 jdbcChannel = mdsClient.getDatabaseDetailsForDataset(srcDataset);			 
		} else{
			 jdbcChannel = mdsClient.getJdbcChannelDetailsWithId(channelID);
		}
		logger.debug("Fetched database connection details URL=" + jdbcChannel.url);
		
		bean.setDriverClass((Class<? extends Driver>) Class.forName(jdbcChannel.driverClass));
		bean.setUrl(jdbcChannel.url);
		bean.setUsername(jdbcChannel.username);
		// Passwords from MDS will be encrypted
		bean.setPassword(Crypto.decrypt(jdbcChannel.password));

		return bean;
	}
	
	/**This  method returns the status of Connection to jdbc database  
	 * 
	 * @return - Returns the value of status
	 */
	
	public boolean isConnected(){
		boolean success= false;
		try ( Connection conn = bean.getConnection();){
			if (conn !=null){
				success= true;
			}else{
				success= false;
			}
		}catch (SQLException se){
			//TODO: Should we catch and log ... or re-throw?
			logger.error("Failed to connect to Jdbc source?", se);
		}
		return success;
	}
	
	public MetadataService getMdsClient() {
		return mdsClient;
	}

	public void setMdsClient(MetadataService mdsClient) {
		this.mdsClient = mdsClient;
	}

	public String getChannelID() {
		return channelID;
	}

	public void setChannelID(String channelID) {
		this.channelID = channelID;
	}

	public String getSrcDataset() {
		return srcDataset;
	}

	public void setSrcDataset(String srcDataset) {
		this.srcDataset = srcDataset;
	}
	
	public void setBean(SimpleDriverDataSource bean) {
		this.bean = bean;
	}
}
