package com.ubs.idp.orchestrator.listeners;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.SkipListener;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.support.AbstractItemStreamItemWriter;

import java.util.*;

public class BadItemSkipListener implements SkipListener {

    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private ItemWriter<String> readErrorWriter;
    private ItemWriter<String> writeErrorWriter;
    private ItemWriter<String> processErrorWriter;

    @Override
    public void onSkipInRead(final Throwable t) {
        // TODO: Need to be smarter here
        if (t instanceof FlatFileParseException) {
            ArrayList<String> itemData = new ArrayList<String>() {{
                add(((FlatFileParseException) t).getInput());
            }};
            writeError(readErrorWriter, t, itemData);
        } else {
            logger.warn("Unsupported exception type {}", t);
        }
    }

    @Override
    public void onSkipInWrite(Object item, final Throwable t) {
        ArrayList<String> itemData = new ArrayList<String>();
        
        itemData.add(item.toString());
        
        writeError(writeErrorWriter, t, itemData);
    }

    @Override
    public void onSkipInProcess(Object item, final Throwable t) {
        ArrayList<String> itemData = new ArrayList<String>();
        
        itemData.add(item.toString());

        writeError(processErrorWriter, t, itemData);
    }

    protected void writeError(ItemWriter<String> writer, final Throwable t, final ArrayList<String> itemData) {
        logger.error("Record SKIPPED data written to file:",t);
        try {
            writer.write(itemData);
        } catch (Exception e) {
            logger.error("Error writing to error file", e);
        }

    }
    
    public void setReadErrorWriter(ItemWriter<String> errorItemWriter) {
        this.readErrorWriter = errorItemWriter;
    }

    public void setWriteErrorWriter(ItemWriter<String> writeErrorWriter) {
        this.writeErrorWriter = writeErrorWriter;
    }

    public void setProcessErrorWriter(ItemWriter<String> processErrorWriter) {
        this.readErrorWriter = processErrorWriter;
    }
}