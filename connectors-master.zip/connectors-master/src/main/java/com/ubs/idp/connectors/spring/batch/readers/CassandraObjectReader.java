package com.ubs.idp.connectors.spring.batch.readers;

import static org.springframework.util.Assert.notNull;
import static org.springframework.util.Assert.notEmpty;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.transform.DefaultFieldSet;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.datastax.driver.core.ColumnDefinitions;
import com.datastax.driver.core.ColumnDefinitions.Definition;
import com.datastax.driver.core.DataType;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.ubs.idp.base.utils.TimeUtils;
import com.ubs.idp.connectors.BaseConnector;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;
import com.ubs.idp.connectors.spring.batch.formatters.FieldFormatter;

/**
 * Spring batch Cassandra reader (supports Cassandra column data/object types)
 * @author mcminnp
 */
public class CassandraObjectReader extends BaseConnector implements ItemReader<FieldSet>, ItemStream, InitializingBean {

    private long rowCount = 0;

    @Autowired
    @Qualifier("cassandraSessionHelper")
    private CassandraSessionHelper cassandraSessionHelper;
    
    private String columnFamily;
    private String attributeNames[];
    private long rowLimit = 1000000;

    private String dateFormat = "yyyy-MM-dd HH:mm:ss";
    private String timeZone = "UTC";
    
    private FieldFormatter fieldFormatter = null;
    
    protected CassandraCqlProxy proxy = null;
    
    private ResultSet resultSet = null;
    
    // Jackson mapper for Object to JSON conversion
    ObjectMapper jacksonMapper = new ObjectMapper();

    private Logger logger = LoggerFactory.getLogger(CassandraObjectReader.class);

    /**
     * Bare bones constructor
     */
    public CassandraObjectReader() {
        if (logger.isDebugEnabled()) logger.debug("Initialise Cassancdra object reader...");
    }

    /**
     * Return number of rows read
     * @return
     */
    public long getRowCount() {
        return rowCount;
    }

    // General getters and setters
    
    public String getColumnFamily() {
        return columnFamily;
    }

    public void setColumnFamily(String columnFamily) {
        this.columnFamily = columnFamily;
    }

    public String[] getAttributeNames() {
        return attributeNames;
    }

    public void setAttributeNames(String[] attributeNames) {
        this.attributeNames = attributeNames;
    }

    public void setAttributeNames(String attributeNames) {
        this.attributeNames = attributeNames.split(",");
        for (int i = 0 ; i < this.attributeNames.length ; i++) {
            this.attributeNames[i] = this.attributeNames[i].trim();
        }
    }
    
    public long getRowLimit() {
        return rowLimit;
    }

    public void setRowLimit(long rowLimit) {
        this.rowLimit = rowLimit;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public FieldFormatter getFieldFormatter() {
        return fieldFormatter;
    }

    public void setFieldFormatter(FieldFormatter fieldFormatter) {
        this.fieldFormatter = fieldFormatter;
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemReader#read()
     */
    @Override
    public FieldSet read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
        if (logger.isDebugEnabled()) logger.debug("Read called for source ID '" + sourceIdentifier + "'...");
        
        FieldSet res = null;
        
        ColumnDefinitions columnDefinitions = resultSet.getColumnDefinitions();
        
        if (resultSet != null) {
            Iterator<Row> rowIt = resultSet.iterator();
            
            if (rowIt.hasNext()) {
                Row row = resultSet.iterator().next();
                
                int rowSize = columnDefinitions.size();
                
                String[] names = new String[rowSize];
                String[] tokens = new String[rowSize];
                
                int columnIdx = 0;
                
                for (Definition columnDefinition : columnDefinitions) {

                    names[columnIdx] = columnDefinition.getName();
                    tokens[columnIdx] = getColumnValueAsString(row, columnDefinition, columnIdx);
                    
                    columnIdx++;
                }
                
                res = new DefaultFieldSet(tokens, names);
                
                rowCount++;
            }
        }

        // Think about re-initialise (reset row count etc.)

        if (logger.isDebugEnabled()) logger.debug("Read returns '" + res + "'...");

        return res;
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#open(org.springframework.batch.item.ExecutionContext)
     */
    @Override
    public void open(ExecutionContext executionContext)
            throws ItemStreamException {
        if (logger.isDebugEnabled()) logger.debug("Open Cassandra reader...");

        rowCount = 0;
        
        StringBuffer attributes = new StringBuffer();
        
        for (int i = 0 ; i < attributeNames.length ; i++) {
            if (i > 0) {
                attributes.append(",");
            }
            
            attributes.append(attributeNames[i]);
        }
        
        String query = "select " + attributes + " from " + columnFamily + " limit " + rowLimit;

        if (logger.isDebugEnabled()) logger.debug("Run CQL query {}...", query);
        
        PreparedStatement stmt = proxy.getPrepareStatement(query);
        
        resultSet = proxy.executeStatement(stmt.bind());
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#close()
     */
    public void close() {
        if (logger.isDebugEnabled()) logger.debug("Closing Cassandra reader");
        
        if (resultSet != null) {
            // TODO: Close!?
        }
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#update(org.springframework.batch.item.ExecutionContext)
     */
    @Override
    public void update(ExecutionContext executionContext)
            throws ItemStreamException {
        if (logger.isDebugEnabled()) logger.debug("Update exectution context");
    }

    /* (non-Javadoc)
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        notNull(columnFamily, "Please specify column family?");
        notNull(attributeNames, "Please specify query attributes?");
        notEmpty(attributeNames, "Please specify at least 1 query attribute?");
        
        logger.info("Get Cassandra proxy");

        // Initialise/fetch proxy
        proxy = cassandraSessionHelper.getProxy();
        
        logger.info("Got Cassandra proxy: {}", proxy);
    }
    
    /**
     * Return string representation of Cassandra column value
     * @param row
     * @param columnDefinition
     * @param columnIndex
     * @return
     * @throws IOException 
     * @throws JsonMappingException 
     * @throws JsonGenerationException 
     */
    private String getColumnValueAsString(Row row, Definition columnDefinition, int columnIndex) throws JsonGenerationException, JsonMappingException, IOException {
        String res = "";
        
        DataType dataType = columnDefinition.getType();
        
        if (dataType.equals(DataType.map(DataType.varchar(), DataType.varchar()))) {
            Map<String, String> map = row.getMap(columnIndex, String.class, String.class);
            res = formatField(map);
        } else if (dataType.equals(DataType.map(DataType.varchar(), DataType.cint()))) {
            Map<String, Integer> map = row.getMap(columnIndex, String.class, Integer.class);
            res = formatField(map);
        } else if (dataType.equals(DataType.list(DataType.varchar()))) {
            List list = row.getList(columnIndex, String.class);
            res = formatField(list);
        } else if (dataType.equals(DataType.varchar())) {
            res = row.getString(columnIndex);
        } else if (dataType.equals(DataType.bigint())) {
            res = "" + row.getLong(columnIndex);
        } else if (dataType.equals(DataType.timestamp())) {
            res = TimeUtils.tzDate(row.getDate(columnIndex), timeZone, dateFormat);
        } else if (dataType.equals(DataType.cboolean())) {
            res = formatField(row.getBool(columnIndex));
        } else {
            throw new IllegalArgumentException("Not yet implemented for type " + dataType);
        }

        return res;
    }

    /**
     * Format List/Map/Boolean objects to string value
     * @param field
     * @return
     * @throws JsonGenerationException
     * @throws JsonMappingException
     * @throws IOException
     */
    private String formatField(Object field) throws JsonGenerationException, JsonMappingException, IOException {
        String res;
        
        if (fieldFormatter != null) {
            // Manually defined mapper
            res = fieldFormatter.formatField(field);
        } else {
            // Default to JSON (Jackson)
            res = jacksonMapper.writeValueAsString(field);
        }
        
        return res;
    }
}
