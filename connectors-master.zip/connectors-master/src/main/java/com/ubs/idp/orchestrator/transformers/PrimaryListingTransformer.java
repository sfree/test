package com.ubs.idp.orchestrator.transformers;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static com.ubs.idp.orchestrator.util.CommonUtils.moveFromStageToDrop;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.transformer.Transformer;
import org.springframework.messaging.Message;
import org.springframework.util.Assert;

import com.ubs.idp.base.utils.IdpFileUtils;
import com.ubs.idp.orchestrator.util.CommonUtils;


public class PrimaryListingTransformer implements Transformer, InitializingBean {
	
	private static Logger logger = LoggerFactory.getLogger(PrimaryListingTransformer.class);
	
	private String sortScriptFile;
	private String inputFileDelimiter;
	private String outputFileDelimiter;
	private List<String> scriptInput;
	
	private HashMap<String, Integer> columnIndexMap;
	private static final String PRIMARY_FLAG ="Y";
	private static final String NOT_A_PRIMARY_FLAG ="N";
	private static final String NEWLINE = "\n";
	private static final String PRIMARY_FLAG_UNDETERMINED = "U";
	//private File archiveDir;
	private static final String ACTIVE ="ACTIVE";
	private static final String UNKNOWN ="UNKNOWN";
	private static final String YES = "Y";
	private static final String ONE = "1";
	private File archiveDir;
	private File stagingDir;
	private File dropDir;	
	private File errorDir;

	private String sortby;
		
	public PrimaryListingTransformer() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		
		
	}

	@Override
	public Message<?> transform(Message<?> payload)
	{			
		String inputFileName = payload.getPayload().toString();
		
		File inputFile = new File(inputFileName);
		logger.info("Transforming file {}", inputFile);
		
		// has to be dynamically retrieved from Metadata service
		
		if(inputFileName.contains("EQUITY")){
			sortby = "59";
		}else{
			sortby = "52";
		}		
			
		scriptInput = new ArrayList<String>();
		scriptInput.add(sortby);
		
		File transformedFile = null;
		if( CommonUtils.doesFileHaveMoreThenOneLine( inputFile ) )
		{
		    File stagingFile = execute(inputFile);	
		    transformedFile = moveFromStageToDrop(dropDir, stagingFile);
			logger.info("Created transformed file {}", transformedFile);
		}
		else
		{
			logger.info("No data in file {} so no transformation was performed",inputFile);
			// Set the transformed file to be the trigger file as it is passing through
			transformedFile = inputFile;
		}
		
		try
		{
			// Create archive dir if not done so already
			if( !archiveDir.exists() )
			{
				if( !archiveDir.mkdirs() && !archiveDir.exists() )
				{
					throw new RuntimeException("Unable to create archive dir " + archiveDir );
				}
			}
			IdpFileUtils.moveAndZip(archiveDir,inputFile);
		}		
		catch (Exception e)
		{
			throw new RuntimeException("The following error occured when attempting to zip and archive file '" + inputFile + "':" + e,e );
		}
		return MessageBuilder.withPayload(transformedFile).build();
	}

	/**
	 * Removes the generated sorted file
	 */
	private void removeSortedFile(File sortedOutputFile)
	{
        Assert.isTrue(sortedOutputFile.exists(), "Sorted file ('" + sortedOutputFile + "') does not exist?");        
        Assert.isTrue(sortedOutputFile.delete(), "Failed to delete sorted file ('" + sortedOutputFile + "')");
	}
	
	/**
	 * execute()
	 * 1) Reads the Sorted Equity File (Sorted by issue.isin and issue.status)
	 * 2) Groups all of the same ACTIVE isins together
	 * 3) Applies the rules to each group to get the tL.ubsId for each primary market per group
	 * 4) Returns An ArrayList of tL.ubsIds corresponding to all of the primary markets in the file
	 * @return
	 * @throws IOException
	 */
	public File execute(File inputFile) {
		
		String inputFilename = inputFile.getName();
		
		String header = CommonUtils.extractHeader(inputFile);
		columnIndexMap = mapColumnNamesToIndices(header, inputFileDelimiter);
		
		// Set the filenames to be the same as the triggerfile but with a suffix
		String sortedOutputFilename = inputFilename.replace(CommonUtils.UNSORTED_SUFFIX, CommonUtils.SORTED_SUFFIX);
		//String errorFilename = inputFilename.replace(CommonUtils.UNSORTED_SUFFIX, CommonUtils.ERROR_SUFFIX);
		String stagingFilename = inputFilename.replace(CommonUtils.UNSORTED_SUFFIX, CommonUtils.TRANSFORMED_SUFFIX);
				
		File sortedOutputFile = new File( stagingDir + File.separator + sortedOutputFilename );
		//File errorFile = new File( errorDir + File.separator + errorFilename );
		
		if( !stagingDir.exists() )
		{	
			if( !stagingDir.mkdirs() && !stagingDir.exists() )
			{
				throw new RuntimeException("Failed to create directory for the file path " + stagingDir);
			}
		}			
		
		File stagingFile = new File( stagingDir + File.separator + stagingFilename );
		
		try
		{
			//sortFile(String sortScriptFile,File stageDir,File inputFile,File outputFile,String inputFileDelimiter,List<String> scriptInput)
			// sorting is non-generic but this is a tactical solution and will ultimately be replaced.
			CommonUtils.sortFile(sortScriptFile,this.stagingDir,inputFile,sortedOutputFile,inputFileDelimiter,scriptInput);
		}
		catch (IOException e)
		{
			throw new RuntimeException("The following error occured running the external sort script: " + e.getMessage(),e);
		}						
				
		BufferedReader sortedInputReader = null;
		BufferedWriter transformedBufferedWriter = null;
		
		try {
			
			sortedInputReader = new BufferedReader(new FileReader(sortedOutputFile));
			transformedBufferedWriter = new BufferedWriter(new FileWriter(stagingFile,true));
			
			String curLine = null;
			List<List<String>> listings = new ArrayList<List<String>>();
			
			long isinWithDuplicatePMFlag = 0;
			long isinWithPMUndefinedFlag = 0;
			
			
			// Loop through the sorted file and group all of the same issuer.isin
			while ((curLine = sortedInputReader.readLine()) != null) {
				// Ignore blank lines in the data
				if (! curLine.trim().isEmpty()) {
					
					List<String> curLineTokens = new ArrayList<String>();
					Collections.addAll(curLineTokens,curLine.split(inputFileDelimiter,-1));
					//if nothing in the listings yet, just add the row
					if (listings.isEmpty()) {
						listings.add(curLineTokens);
						
					//if listings has data, check that the row has the same isin
					} else if (curLineTokens.get(columnIndexMap.get("issue.isin"))
							.equals(listings.get(0).get(columnIndexMap.get("issue.isin")))) {
						listings.add(curLineTokens);
						
					//otherwise if listings has data, but row has different isin
					//apply the rules to the listings
					} else {
						//Check/Rule 1
						// If there is only one row in listings, that is the primary flag
						if (listings.size() == 1) {
							listings.get(0).add(PRIMARY_FLAG);
						// otherwise apply the rules
						} else {
							listings = (applyRules(listings));
						}
						
						// for analysis only
						Integer isinIndex = columnIndexMap.get("issue.isin");									
						int PrimaryMarketCount = 0;
						int MarketUndefinedCount = 0;
						String isin = UNKNOWN ;
						
						for (List<String> strings : listings) {
								
								isin = (isinIndex!=null && isin.equals(UNKNOWN)) ? strings.get(isinIndex) : isin;
								
								PrimaryMarketCount = PRIMARY_FLAG.equalsIgnoreCase(strings.get(strings.size()-1)) ? PrimaryMarketCount++
																													 : PrimaryMarketCount;
								MarketUndefinedCount = PRIMARY_FLAG_UNDETERMINED.equalsIgnoreCase(strings.get(strings.size()-1)) ? MarketUndefinedCount ++
																																   : MarketUndefinedCount;							
								transformedBufferedWriter.write(stringCreator(strings,outputFileDelimiter) + NEWLINE);
						}
						
						if(PrimaryMarketCount > 1){
							isinWithDuplicatePMFlag++;
							logger.info("Primary Market ISIN : " + isin + ",PrimaryMarketCount : "+PrimaryMarketCount);
						}
						
						if(MarketUndefinedCount > 0){
							logger.info("Primary Market ISIN : " + isin + ",MarketUndefinedCount : "+MarketUndefinedCount);
							isinWithPMUndefinedFlag++;
						}
						
						//reset listings and add the row with the different isin
						listings.clear();
						listings.add(curLineTokens);
					}
				}
			}

			logger.info("Total Number of isin with Duplicate Primary Market Flag = "+isinWithDuplicatePMFlag);
			logger.info("Total Number of isin with Primary Market undefined Flag = " +isinWithPMUndefinedFlag);
			
			//Check/Rule 1
			// Must finally persist the final remaining list
			if (listings.size() == 1) {
				listings.get(0).add(PRIMARY_FLAG);
			// otherwise apply the rules
			} else {
				listings = (applyRules(listings));
			}
			for (List<String> strings : listings) {
				transformedBufferedWriter.write(stringCreator(strings,outputFileDelimiter) + NEWLINE);
			}
			listings.clear();

		}
		catch (Exception ex) {
			throw new RuntimeException(ex.getMessage());
		}finally{
			
			try{
			
				sortedInputReader.close();
				transformedBufferedWriter.close();
			
			}catch(Exception ignore){
				
				logger.error(ignore.getMessage());
			}
		}
		
		removeSortedFile(sortedOutputFile);
		
		// Move the staging file to the target file
		File transformedFile = new File( dropDir + File.separator + stagingFile.getName() );
		logger.debug("Moving staging file {} to target destination {}",stagingFile,transformedFile);
		if( !stagingFile.renameTo(transformedFile) )
		{
			throw new RuntimeException("Failed to move staging file " + stagingFile + " to target file " + transformedFile + "?! Check permissions? Does the target file already exist?");
		}
		return transformedFile;
	}
	
	/**
	 * Map the Column names to the index of that column for quick searching
	 * through each line of the data for the particular columns in question per rule
	 * 
	 * @param inputHeaderLine
	 * @param delimiter
	 * @return
	 */
	public HashMap<String, Integer> mapColumnNamesToIndices(
			String inputHeaderLine, String delimiter) {
		String[] headerLineTokens = inputHeaderLine.split(delimiter, -1);
		HashMap<String, Integer> tempMap = new HashMap<String, Integer>();
		for (int i = 0; i < headerLineTokens.length; i++) {
			tempMap.put(headerLineTokens[i], i);
		}
		return tempMap;
	}

    /**
     * @param List
     *            <List<String>> listings - all the listings with same isin
     * @return List<List<String>> - The listing containing the primary market
     */
    public List<List<String>> applyRules(List<List<String>> listings) throws Exception {

        // Check/Rule 1
        if (applyRuleCheck1(listings)) {
            return listings;
            // Check/Rule 2
        } else if (applyRuleCheck2(listings)) {
            return listings;
            // Check/Rule 3
        } else if (applyRuleCheck3(listings)) {
            return listings;
            // Check/Rule 4
        } else if (applyRuleCheck4(listings)) {
            return listings;
            // Check/Rule 5
        } else if (applyRuleCheck5(listings)) {
            return listings;
            // Check/Rule 6
        } else if (applyRuleCheck6(listings)) {
            return listings;
            // Check/Rule 7
        } else if (applyRuleCheck7(listings)) {
            return listings;
            // Check/Rule 8
        }else if(applyRuleCheck8(listings)){
        	return listings;
        }
        else if (applyRuleCheck9(listings)) {
            return listings;
        } else
            return noRuleMatched(listings);
    }
	
	/**
	 * This is Check/Rule 1
	 * Checks if only one row of the listings is active
	 * if so sets that as the primary flag
	 * @param listings
	 * @return true if primary listing set
	 */
	public boolean applyRuleCheck1(List<List<String>> listings) throws Exception {
		
		int numActiveListings = 0;
		int indexOfActiveListing = -1;
		Integer posValue = columnIndexMap.get("tL.status");
		
		if(posValue==null){
			throw new Exception("Attribute tL.status is missing in the input file header so unable to proccess the file");
		}
		
		int position = posValue;
		
		for (int i = 0; i < listings.size(); i++) {
			if (listings.get(i).get(position).equalsIgnoreCase(ACTIVE)) {
				numActiveListings++;
				indexOfActiveListing = i;
			}
		}
		if (numActiveListings == 1) {
			listings.get(indexOfActiveListing).add(PRIMARY_FLAG);
			return true;
		} else return false;
	}
	
	/**
	 * Check/Rule 2
	 * Main rule logic: if tL.status == ACTIVE AND bbPrimaryMarketInd == TRUE for a single row
	 * set that as primary listing.
	 * 
	 * Else check all the rows with active and true against the subset of rules
	 * 
	 * @param listings
	 * @return true if primary listing set
	 */
	public boolean applyRuleCheck2(List<List<String>> listings) {
		
		Integer statusIndex = columnIndexMap.get("tL.status");
		Integer bbPrimMarketIndex = columnIndexMap.get("tL.bbPrimaryExchange");
		
		if(statusIndex==null || bbPrimMarketIndex==null){
			
			return false;
		}		
		
		List<List<String>> activePlusPMIndRows = new ArrayList<List<String>>();
		int indexOfRowMeetingRule = -1;
		int statusPosition = statusIndex;
		int bbPrimaryMarkPostion = bbPrimMarketIndex;
		
		for (int i = 0; i < listings.size(); i++) {
					
			if (listings.get(i).get(statusPosition).trim().equalsIgnoreCase(ACTIVE) && 
				listings.get(i).get(bbPrimaryMarkPostion).trim().equalsIgnoreCase(YES)) {
				
				activePlusPMIndRows.add(listings.get(i));
				indexOfRowMeetingRule = i;
			}
		}
		
		if (activePlusPMIndRows.size() == 1) {
			listings.get(indexOfRowMeetingRule).add(PRIMARY_FLAG);
			return true;
		} else {
			if (applySubRuleLogic(activePlusPMIndRows)) {
				return true;
			} else {
				return false;
			}
		}
	}
	
	/**
	 * Check/Rule 3
	 * main rule logic:  if first 2 chars ISIN is same as that of Country of Trade AND
	 *					 Country of Trade is same as Country of Incorporation for a single row
	 * @param listings
	 * @return true if primary listing set
	 */
	
	public boolean applyRuleCheck3(List<List<String>> listings) {
		
		
		Integer quotIndex = columnIndexMap.get("tL.tradeCountry");
		Integer incorpIndex = columnIndexMap.get("issuer.countryOfIncorporation");
		Integer isinIndex = columnIndexMap.get("issue.isin");
		
		if(isinIndex==null || incorpIndex==null || quotIndex==null){
			
			return false;
		}
		
		int quotPosition = quotIndex;
		int incorpPosition = incorpIndex;
		int isinPosition = isinIndex;
		
		List<List<String>> rowsWhereIsinCntryTradeSame = new ArrayList<List<String>>();
		int indexOfRowMeetingRule = -1;
		
		for (int i = 0; i < listings.size(); i++) {				
			
			if(listings.get(i).get(isinPosition)!=null && !listings.get(i).get(isinPosition).trim().isEmpty()) {
				
				if ( listings.get(i).get(quotPosition)!=null && listings.get(i).get(isinPosition) !=null && 
					 listings.get(i).get(quotPosition).equalsIgnoreCase(listings.get(i).get(isinPosition).substring(0, 2))&&
					 (listings.get(i).get(quotPosition).equalsIgnoreCase(listings.get(i).get(incorpPosition)))) {
	
					rowsWhereIsinCntryTradeSame.add(listings.get(i));
					indexOfRowMeetingRule = i;
				}
			}
		}
		
		if (rowsWhereIsinCntryTradeSame.size() == 1) {
			listings.get(indexOfRowMeetingRule).add(PRIMARY_FLAG);
			return true;
		} else {
			if (applySubRuleLogic(rowsWhereIsinCntryTradeSame)) {
				return true;
			} else {
				return false;
			}
		}
	}

	/**
	 * Check/Rule4
	 * main rule logic: first 2 chars ISIN is same as that of Country of Trade (i.e. of quotation) for a single row
	 * @param listings
	 * @return true if primary listing set
	 */
	public boolean applyRuleCheck4(List<List<String>> listings) {

		Integer isinIndex = columnIndexMap.get("issue.isin");
		Integer regIndex = columnIndexMap.get("tL.tradeCountry");
		
		if(isinIndex == null || regIndex ==null){
			
			return false;
		}
		
		List<List<String>> rowsWhereIsinCntryTradeSame = new ArrayList<List<String>>();
		int indexOfRowMeetingRule = -1;
	
		int isinPosition =isinIndex;
		int regPosition = regIndex;
		
		for (int i = 0; i < listings.size(); i++) {
			
			if( listings.get(i).get(isinPosition) !=null && ! listings.get(i).get(isinPosition).trim().isEmpty()) {
				
				if (listings.get(i).get(regPosition)!=null && listings.get(i).get(isinPosition).length() > 0
						&& listings.get(i).get(regPosition).equalsIgnoreCase(listings.get(i).get(isinPosition).substring(0, 2))) {
					
					rowsWhereIsinCntryTradeSame.add(listings.get(i));
					indexOfRowMeetingRule = i;
				}
			}
		}
		
		if (rowsWhereIsinCntryTradeSame.size() == 1) {
			listings.get(indexOfRowMeetingRule).add(PRIMARY_FLAG);
			return true;
		} else {
			if (applySubRuleLogic(rowsWhereIsinCntryTradeSame)) {
				return true;
			} else {
				return false;
			}
		}
	}
	
	/** 
	 * Check/Rule 5
	 * main rule logic: If Country of Trade  is same as Country of Incorporation for a Single row
	 * @param listings
	 * @return true if primary listing set
	 */
	public boolean applyRuleCheck5(List<List<String>> listings) {
		
		
		Integer quotIndex = columnIndexMap.get("tL.tradeCountry");
		Integer inCorpIndex = columnIndexMap.get("issuer.countryOfIncorporation");
		
		if(quotIndex == null || inCorpIndex ==null){
			
			return false;
		}
				
		List<List<String>> rowsWhereTradeSameIncorp = new ArrayList<List<String>>();
		int indexOfRowMeetingRule = -1;		
		int quotPosition = quotIndex;
		int inCorpPosition = inCorpIndex;
		
		
		for (int i = 0; i < listings.size(); i++) {			
			
			if (listings.get(i).get(quotPosition)!=null
				 && listings.get(i).get(quotPosition).equalsIgnoreCase(listings.get(i).get(inCorpPosition))) {

				rowsWhereTradeSameIncorp.add(listings.get(i));
				indexOfRowMeetingRule = i;
			}
		}

		if (rowsWhereTradeSameIncorp.size() == 1) {
			listings.get(indexOfRowMeetingRule).add(PRIMARY_FLAG);
			return true;
		} else {
			if (applySubRuleLogic(rowsWhereTradeSameIncorp)) {
				return true;
			} else {
				return false;
			}
		}
	}

	/**
	 * Check/Rule 6
	 * main rule logic : Primary Exchange and MIFID Exchange is the same for a single row
	 * @param listings
	 * @return true if primary listing set
	 */
	public boolean applyRuleCheck6(List<List<String>> listings) {

		Integer exchangeIndex = columnIndexMap.get("tL.bbPrimaryExchange");
		Integer mifidIndex = columnIndexMap.get("issue.mifidMarket");
		
		if(exchangeIndex == null ||mifidIndex==null ){			
			return false;			
		}
		
		int exchangePosition = exchangeIndex;
		int mifidPosition = mifidIndex;
		
		List<List<String>> rowsPrimExMifidSame = new ArrayList<List<String>>();
		int indexOfRowMeetingRule = -1;
		

		for (int i = 0; i < listings.size(); i++) {
									
			if (listings.get(i).get(exchangePosition)!=null
					&& 	listings.get(i).get(exchangePosition).equals(listings.get(i).get(mifidPosition))) {

				rowsPrimExMifidSame.add(listings.get(i));
				indexOfRowMeetingRule = i;
			}
		}

		if (rowsPrimExMifidSame.size() == 1) {
			listings.get(indexOfRowMeetingRule).add(PRIMARY_FLAG);
			return true;
		} else {
			if (applySubRuleLogic(rowsPrimExMifidSame)) {
				return true;
			} else {
				return false;
			}
		}
	}
	
	/**
	 * Check/Rule 7
	 * main rule logic : Country of Trade is not equal to "ZZ" for a single row
	 * @param listings
	 * @return true if primary listing set
	 */
	public boolean applyRuleCheck7(List<List<String>> listings) {
		
		Integer quotIndex = columnIndexMap.get("tL.tradeCountry");
		
		if(quotIndex == null){
			
			return false;
		}
		
		List<List<String>> rowsTradeNotZZ = new ArrayList<List<String>>();
		int indexOfRowMeetingRule = -1;
		int quotPosition = quotIndex;		
		
		for (int i = 0; i < listings.size(); i++) {
			
			// Country of Trade is not eaul to "ZZ"									
			if (listings.get(i).get(quotPosition).length() > 0
					&& 	!(listings.get(i).get(quotPosition).equals("ZZ"))) {

				rowsTradeNotZZ.add(listings.get(i));
				indexOfRowMeetingRule = i;
			}
		}

		if (rowsTradeNotZZ.size() == 1) {
			listings.get(indexOfRowMeetingRule).add(PRIMARY_FLAG);
			return true;
		} else {
			if (applySubRuleLogic(rowsTradeNotZZ)) {
				return true;
			} else {
				return false;
			}
		}
	}
	
	/** 
	 * Check/Rule 8
	 * main rule logic:if(tL.active=1, tL.status=ACTIVE, tL.ricOfIntInd=1) return true
	 * @param listings
	 * @return true if primary listing set
	 */
	public boolean applyRuleCheck8(List<List<String>> listings) {
		
		
		Integer activeIndex = columnIndexMap.get("tL.active");
		Integer statusIndex = columnIndexMap.get("tL.status");
		Integer ricOfIntIndex = columnIndexMap.get("tL.ricOfIntInd");
		
		if(activeIndex == null || statusIndex ==null ||ricOfIntIndex==null ){
			
			return false;
		}
				
		List<List<String>> matchingListings = new ArrayList<List<String>>();
		int indexOfRowMeetingRule = -1;		
		int activePosition = activeIndex;
		int statusPosition = statusIndex;
		int ricOfIntPosition = ricOfIntIndex;
				
		for (int i = 0; i < listings.size(); i++) {			

            	int noOfColumns = listings.get(i).size();
            	
            	if(activePosition >= noOfColumns || statusPosition >= noOfColumns || ricOfIntPosition >= noOfColumns ) {
                    logger.info("applyRuleCheck8 bug" + " " + activePosition + " " + statusPosition + " " + ricOfIntPosition);
                    return false;
            	}
				String tL_Active = listings.get(i).get(activePosition);
				String tL_Status = listings.get(i).get(statusPosition);
				String tL_RicOfIntInd = listings.get(i).get(ricOfIntPosition);
			
			if (tL_Active == null || tL_Status==null || tL_RicOfIntInd==null) {
				continue;
			}else if(tL_Active.trim().equals(ONE) && tL_Status.equalsIgnoreCase(ACTIVE) && tL_RicOfIntInd.equals(ONE)){
				
				matchingListings.add(listings.get(i));
				indexOfRowMeetingRule = i;
			}
		}

		if (matchingListings.size() == 1) {
			listings.get(indexOfRowMeetingRule).add(PRIMARY_FLAG);
			return true;
		} else {
			if (applySubRuleLogic(matchingListings)) {
				return true;
			} else {
				return false;
			}
		}
	}
	
	/**
	 * Check/Rule 9 
	 * @param listings
	 * @return
	 */
	public boolean applyRuleCheck9(List<List<String>> listings) {
		return applySubRuleLogic(listings);
	}
	
	public boolean applySubRuleLogic(List<List<String>> listings) {
		// A) IF cubscode is present for listing(s): lowest cubscode is primary listing
		//		cubscode decomissioned in MAY therefore not including in logic.
			
		// B) else IF majorVersion is present for listing(s):  highest majorVersion is primary listing
		 if (getMaxNumericColumnValue("tL.majorVersion", listings)) {
			return true;
			
		// C) else IF sedol is present for listing(s): greater sedol is primary listing
		} else if (singleSedolOrGreaterVersion(listings)) {
			return true;
			
		// D) else IF Highest timestamp is set as Primary listing
		} else if (getMaxNumericColumnValue("issue.lastUpdatedTime", listings))
			return true;
		
		return false;
	}
	
	/**
	 * Given a column attribute and a List<List<String>> of listings with same isin
	 * if there is A SINGLE row with a valid NUMERIC Value greater than all the other rows,
	 * that row is assigned the primary flag and true is returned
	 * @param String columnName, List<List<String>> listings
	 * @return true if primary flag is set
	 */

	public boolean getMaxNumericColumnValue(String colName, List<List<String>> listings) {
		
		// Must track the listing(s) with the Max major Column
		List<List<String>> listingsWithMaxColumn = new ArrayList<List<String>>();
		
		Integer columnIndex = columnIndexMap.get(colName);
		// Make sure the dataset contains a majorVersion column else return false
		if(columnIndex ==null){
			return false;
		}
		
		// Track which row contains the Maximum MajorVersion
		int indexOfMaxColumn = -1;
				
		for (int i = 0; i < listings.size(); i++) {
			
			Long curColumnValueOfRow = (listings.get(i).get(columnIndex)!=null) &&
					!(listings.get(i).get(columnIndex).trim().equals("")) ? 
					Long.valueOf(listings.get(i).get(columnIndex))
					: null;
					
			if (curColumnValueOfRow == null) {
				continue;
			}

			if (listingsWithMaxColumn.isEmpty()) {
				listingsWithMaxColumn.add(listings.get(i));
				indexOfMaxColumn = i;
			}
			// If the maxVersion is greater than the value(s) currently in the
			// list, replace with the new value
			else if (listingsWithMaxColumn.get(0).get(columnIndex)!=null && !(listingsWithMaxColumn.get(0).get(columnIndex).equals("")) &&
					curColumnValueOfRow > Long.valueOf(listingsWithMaxColumn.get(0).get(columnIndex)) ){
					//(0 > (Long.valueOf(listingsWithMaxColumn.get(0).get(columnIndex)).compareTo(curColumnValueOfRow)))) {							
				
				listingsWithMaxColumn.clear();
				listingsWithMaxColumn.add(listings.get(i));
				indexOfMaxColumn = i;
			}
			// If the maxVersion is equal to the value(s) in the map, add the
			// value (rule is invalid if multiple results)
			else if (listingsWithMaxColumn.get(0).get(columnIndex)!=null 
					&& (Long.valueOf(listingsWithMaxColumn.get(0).get(columnIndex)).equals(curColumnValueOfRow))) {
				 return  false;
				// unnecessary to update the indexOfMaxMajorVersion as once there is >1 row rule is invalid
			}
		}
		if (listingsWithMaxColumn.size() == 1) {
			listings.get(indexOfMaxColumn).add(PRIMARY_FLAG);
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * If there is only one sedol in the listings, then that is set as the primary listing.
	 * If there is more than one sedol, than of those [sedol] listings only, the one with the
	 * greatest Version is set as the primary listing.
	 * @param List<List<String>> listings
	 * @return true if primary flag is set
	 */
	public boolean singleSedolOrGreaterVersion(List<List<String>> listings) {
		
		// Must track the listing(s) with the Sedol Column
		List<List<String>> listingsWithSedol = new ArrayList<List<String>>();
		
		Integer columnIndex = columnIndexMap.get("tL.sedol");
		// Make sure the dataset contains a tL.sedol column else return false
		if(columnIndex == null){
			return false;
		}
		
		// Track which row contains the tL.sedol
		int indexOfSedol = -1;
			
		// get a list of all the rows with a sedol value
		for (int i = 0; i < listings.size(); i++) {
			if ((listings.get(i).get(columnIndex) != null) &&
				(!listings.get(i).get(columnIndex).equals(""))) {
					
				listingsWithSedol.add(listings.get(i));	
				indexOfSedol = i;
			}
		}
			
		// if there is only one row with a sedol, set that as primary flag
		if (listingsWithSedol.size() == 1) {
			listings.get(indexOfSedol).add(PRIMARY_FLAG);
			return true;
		
		// else get the maxVersion of only those listings with Sedol
		} else {
			return (getMaxNumericColumnValue("tL.majorVersion", listingsWithSedol));
		}

	}

	public List<List<String>> noRuleMatched(List<List<String>> listings) {
		
		for (int i = 0; i < listings.size(); i++) {
			listings.get(i).add(PRIMARY_FLAG_UNDETERMINED);
		}
		return listings;
	}
	
	public void persist(String primaryMarketListing, BufferedWriter writer)
			throws IOException {
		writer.write(primaryMarketListing);
	}
	
	private String stringCreator(List<String> listings,String delimiter){
		
		if( !(listings.get(listings.size()-1).equalsIgnoreCase(PRIMARY_FLAG))
				&& !(listings.get(listings.size()-1).equalsIgnoreCase(PRIMARY_FLAG_UNDETERMINED))) {
			listings.add(NOT_A_PRIMARY_FLAG);			
		}
		
		
		StringBuilder sbuilder = new StringBuilder();
		
		boolean addAfter1stloop = false;
		for ( String s: listings) {
			
			if(addAfter1stloop){
				sbuilder.append(delimiter);
			}
			addAfter1stloop = true;
			sbuilder.append(s);
		}
		return sbuilder.toString();
	}
	
	/**
	 * @return the sortScriptFile
	 */
	public String getSortScriptFile() {
		return sortScriptFile;
	}

	/**
	 * @param sortScriptFile the sortScriptFile to set
	 */
	public void setSortScriptFile(String sortScriptFile) {
		this.sortScriptFile = sortScriptFile;
	}

	/**
	 * @return the inputFileDelimiter
	 */

	
	
	/**
	 * @return the sortby
	 */
	public String getSortby() {
		return sortby;
	}

	/**
	 * @param sortby the sortby to set
	 */
	public void setSortby(String sortby) {
		this.sortby = sortby;
	}

	/**
	 * @return the archiveDir
	 */
	public File getArchiveDir() {
		return archiveDir;
	}

	/**
	 * @param archiveDir the archiveDir to set
	 */
	public void setArchiveDir(File archiveDir) {
		this.archiveDir = archiveDir;
	}

	/**
	 * @return the stagingDir
	 */
	public File getStagingDir() {
		return stagingDir;
	}

	/**
	 * @param stagingDir the stagingDir to set
	 */
	public void setStagingDir(File stagingDir) {
		this.stagingDir = stagingDir;
	}

	/**
	 * @return the dropDir
	 */
	public File getDropDir() {
		return dropDir;
	}

	/**
	 * @param dropDir the dropDir to set
	 */
	public void setDropDir(File dropDir) {
		this.dropDir = dropDir;
	}

	/**
	 * @return the errorDir
	 */
	public File getErrorDir() {
		return errorDir;
	}

	/**
	 * @param errorDir the errorDir to set
	 */
	public void setErrorDir(File errorDir) {
		this.errorDir = errorDir;
	}
	
	
	public void setInputFileDelimiter(String inputFileDelimiter) {
		this.inputFileDelimiter = inputFileDelimiter;
	}
	
	public void setOutputFileDelimiter(String outputFileDelimiter) {
		this.outputFileDelimiter = outputFileDelimiter;
	}
	
	public void setColumnIndexMap(HashMap<String, Integer> columnIndexMap) {
		this.columnIndexMap = columnIndexMap;
	}

	public String getInputFileDelimiter() {
		return inputFileDelimiter;
	}

	public String getOutputFileDelimiter() {
		return outputFileDelimiter;
	}

	public HashMap<String, Integer> getColumnIndexMap() {
		return columnIndexMap;
	}
}
