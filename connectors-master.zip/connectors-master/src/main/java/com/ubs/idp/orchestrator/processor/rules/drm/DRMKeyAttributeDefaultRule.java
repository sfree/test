package com.ubs.idp.orchestrator.processor.rules.drm;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.batch.item.ItemProcessor;

public class DRMKeyAttributeDefaultRule implements
        ItemProcessor<Map<String, Object>, Map<String, Object>> {

    public final static List<String> KEY_ATTRIBUTE_NAMES = Arrays.asList("RATING_TYPE",
            "RATING_TERM", "RATING_CURRENCY");

    public final static String NOT_APPLICABLE = "NA";

    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        for (String keyAttribute : KEY_ATTRIBUTE_NAMES) {
            defaultIfBlank(keyAttribute, item);
        }

        return item;
    }

    private void defaultIfBlank(String keyAttribute, Map<String, Object> item) {
        String value = (String) item.get(keyAttribute);
        item.put(keyAttribute, StringUtils.defaultIfBlank(value, NOT_APPLICABLE));
    }

}
