package com.ubs.idp.orchestrator.processor.rules.rddh.rating;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.batch.item.ItemProcessor;

/**
 * Rule to filter out all rating records that are not long term ratings by a list of agencies. This
 * rule was put in place to improve the performance of T2W transformation.
 */
public class RatingPreProcessorFilterRule implements
		ItemProcessor<Map<String, Object>, Map<String, Object>> {

	private static final String RECORD_TYPE = "RATING";

	private static final String RATING_TYPE = "LT";

	private static final Set<String> AGENCIES = new HashSet<>(Arrays.asList("SandP", "DMSI_SandP",
			"Moodys", "DMSI_Moodys", "Fitch", "DMSI_Fitch"));

	private static final String ATTR_RECORD_TYPE = "issueRating.recordType";

	private static final String ATTR_RATING_TYPE = "issueRating.ratingType";

	private static final String ATTR_AGENCY_TYPE = "issueRating.ratingAgency";

	@Override
	public Map<String, Object> process(Map<String, Object> item) throws Exception {
		// Only record types of 'RATING'
		Object recordType = item.get(ATTR_RECORD_TYPE);
		if (recordType == null || !RECORD_TYPE.equals(recordType.toString())) {
			return null;
		}

		// Only Long Term ratings
		Object ratingType = item.get(ATTR_RATING_TYPE);
		if (ratingType == null || !RATING_TYPE.equals(ratingType.toString())) {
			return null;
		}

		// Only the specified rating agencies
		Object ratingAgency = item.get(ATTR_AGENCY_TYPE);
		if (ratingAgency == null || !AGENCIES.contains(ratingAgency.toString())) {
			return null;
		}

		return item;
	}

}
