package com.ubs.idp.orchestrator.aggregators;

import static org.springframework.util.Assert.notEmpty;
import static org.springframework.util.Assert.notNull;

import java.io.StringWriter;
import java.util.Arrays;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.file.transform.LineAggregator;
import org.springframework.beans.factory.InitializingBean;

/**
 * @author mcminnp
 */
public class FieldMapAggregator implements LineAggregator<Map<String, Object>>, InitializingBean {
    
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    private boolean strict = true;
    private String[] names;
    private String delimiter = org.springframework.batch.item.file.transform.DelimitedLineTokenizer.DELIMITER_TAB;

    /**
     * @return the strict
     */
    public boolean isStrict() {
        return strict;
    }

    /**
     * @param strict the strict to set
     */
    public void setStrict(boolean strict) {
        this.strict = strict;
    }

    /**
     * @return the names
     */
    public String[] getNames() {
        return names;
    }

    /**
     * @param names the names to set
     */
    public void setNames(String[] names) {
        this.names = names;
        
        if (logger.isDebugEnabled()) {
            logger.debug("Names set to {}", Arrays.asList(this.names));
        }
    }

    /**
     * @return the delimiter
     */
    public String getDelimiter() {
        return delimiter;
    }

    /**
     * @param delimiter the delimiter to set
     */
    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
        if (logger.isDebugEnabled()) logger.debug("Delimiter set to {}", this.delimiter);
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.file.transform.LineAggregator#aggregate(java.lang.Object)
     */
    @Override
    public String aggregate(Map<String, Object> inputMap) {
        StringWriter buff = new StringWriter();
        
        notNull(inputMap, "Null input data!?");
        
        // TODO: Review as for large files this will flood the logs
        if (logger.isDebugEnabled()) {
            logger.debug("Aggregating {} map entries", inputMap.size());
            logger.debug("Keyset from map: {}", inputMap.keySet());
        }
                
        int count = 0;
        for(String name : names) {
            if (count > 0) {
                buff.append(delimiter);
            }
            
            Object value = inputMap.get(name);

            if (strict) {
                notNull(value, "Failed to get input value for field '" + name + "'?");
            }

            if (value != null) {
            	if(logger.isDebugEnabled())logger.debug("Adding " + name + "=" + value);
                buff.append(value.toString());
            }
            
            count++;
        }
        
        if (inputMap.size() != count) {
            // TODO: Need to think about this as for large files this will flood the logs 
            //logger.warn("Size mis-match? Map size = {}, aggregated field count = {}", inputMap.size(), count);
        }
        
        return buff.toString();
    }

    /* (non-Javadoc)
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        notNull(names, "No field names configured?");
        notEmpty(names, "Zero field names configured?");
    }
}
