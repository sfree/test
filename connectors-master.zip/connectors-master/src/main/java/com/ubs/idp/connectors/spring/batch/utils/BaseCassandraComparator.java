package com.ubs.idp.connectors.spring.batch.utils;

import java.text.ParseException;
import java.util.Comparator;
import java.util.Map;

import com.ubs.idp.connectors.spring.batch.exceptions.BadRowException;
import com.ubs.idp.connectors.spring.batch.writers.BaseCassandraItemWriter.InputItem;

public abstract class BaseCassandraComparator implements Comparator<InputItem>
{
	protected Map<String,Integer> attributePositionMap;

	public Map<String, Integer> getAttributePositionMap()
	{
		return attributePositionMap;
	}

	public void setAttributePositionMap(Map<String, Integer> attributePositionMap)
	{
		this.attributePositionMap = attributePositionMap;
	}
	
	@Override
	public int compare(InputItem newItem, InputItem existingItem)
	{
		String[] attributePriory = getAttributeCompareOrder();
		
		checkAllAttributesArePresent(newItem,existingItem,attributePriory);

		for (String attrName : attributePriory)
		{
			int position = attributePositionMap.get(attrName);

			String newValueStr = newItem.getFields()[position];
			String oldValueStr = existingItem.getFields()[position];

			Comparable newValue = null;
			Comparable oldValue = null;
			
			try
			{
				 newValue = castValueToType(attrName, newValueStr);
				 oldValue = castValueToType(attrName, oldValueStr);
			}
			catch (ParseException e)
			{
				throw new RuntimeException("Parse exception occured during comparision of attribute " + attrName + " newValue=" + newValue + " oldValue=" + oldValue );
			}

			
			int diff = newValue.compareTo(oldValue);
			if( diff != 0 )
			{
				return diff;
			}
		}
		
		// All columns are the same
		return 0;
	}

	/**
	 * Returns the attribute names to compare in order of priority
	 * @return
	 */
	public abstract String[] getAttributeCompareOrder();
	
	/**
	 * For specified column name and value, the value must be cast to the
	 * specific object type to be used in the comparison. 
	 * @param attrName
	 * @param value
	 * @return
	 * @throws ParseException
	 */
	public abstract Comparable<?> castValueToType( String attrName, String value ) throws ParseException;
	
	/**
	 * Checks that all the attributes used in the sort order are present in both
	 * the incoming new item and the existing item
	 * 
	 * @param newItem
	 * @param existingItem
	 */
	protected void checkAllAttributesArePresent(InputItem newItem, InputItem existingItem, String[] attributeNames)
	{
		for (String attrName : attributeNames)
		{
			String newValue = null;
			String oldValue = null;
			int position = attributePositionMap.get(attrName);
			
			if( position > newItem.getFields().length-1 )
			{
				throw new BadRowException("Failed to fetch attribute '"+attrName+"' with position of '" + position + "' from new row '"+newItem.getLine()+"' as this line only has '"+newItem.getFields().length+"' values");
			}

			if( position > existingItem.getFields().length-1 )
			{
				throw new BadRowException("Failed to fetch attribute '"+attrName+"' with position of '" + position + "' from existing row '"+existingItem.getLine()+"' as this line only has '"+existingItem.getFields().length+"' values");
			}

			newValue = newItem.getFields()[position];
			oldValue = existingItem.getFields()[position];
				
			if (newValue == null || newValue.isEmpty())
			{
				throw new BadRowException("Error performing data comparison for latest record '"+newItem.getLine()+"'. No value found in new record for attribute '" + attrName + "' at position '" + position + "'");
			}

			if (oldValue == null || oldValue.isEmpty())
			{
				throw new BadRowException("Error performing data comparison for latest record '"+existingItem.getLine()+"'. No value found in existing record for attribute '" + attrName + "' at position '" + position + "'");
			}


		}
	}
}
