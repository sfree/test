
package com.ubs.idp.orchestrator.processor;

import static org.springframework.util.Assert.notEmpty;

import java.io.StringWriter;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;

import com.ubs.idp.connectors.spring.batch.exceptions.BadRowException;

/**
 * TODO: Very much a first pass - needs a tidy up. We probably need to review and standardise on input/output types
 * @author mcminnp
 */
public class StringItemProcessorClassAdapter implements ItemProcessor<String, String>,
        InitializingBean, ApplicationContextAware {

    private static final Logger LOG = LoggerFactory
            .getLogger(StringItemProcessorClassAdapter.class);

    private List<String> processorClassList;

    private List<String> inputFieldNames;

    private List<String> outputFieldNames;

    private String inputFieldSeparator = DelimitedLineTokenizer.DELIMITER_TAB;

    private String outputFieldSeparator = DelimitedLineTokenizer.DELIMITER_TAB;

    private int splitLimit = -1;

    private boolean trimFieldValues = false;

    private Map<String, ItemProcessor<Map<String, Object>, Map<String, Object>>> processorInstances = new HashMap<>();

    /**
     * We keep an instance of the Spring context so that dynamic rule classes with autowiring can be
     * Spring registered
     */
    private ApplicationContext applicationContext;

    @Override
    public String process(String item) throws Exception {
        // Empty lines do not need to be processed
        if(StringUtils.isBlank(item)) {
            return null;
        }
        if(CollectionUtils.isEmpty(processorClassList)){
            // TODO: Should throw exception and/or log...
            return item;
        }
        else{
            Map<String, Object> tempOutputItem = mapInputs(item);
            for(String processorClassName: processorClassList ){

                ItemProcessor<Map<String, Object>, Map<String, Object>> itemProcessor = getOrCreateItemProcessor(processorClassName);
                
                Map<String, Object> tempInputItem = tempOutputItem;                
                tempOutputItem = (Map<String, Object>) itemProcessor.process(tempInputItem);
                
                // If the item processor returns null then it indicates that the rule has deemed
                // this line is not to be processed so we return null
                if( tempOutputItem == null )
                {
                	return null;
                }
            }            
            
            return formatResults(tempOutputItem);
        }
    }
    
    private ItemProcessor<Map<String, Object>, Map<String, Object>> getOrCreateItemProcessor(
            String processorClassName) throws Exception {
        
        if (processorInstances.containsKey(processorClassName)) {
            return processorInstances.get(processorClassName);
        }
        
        Class<?> itemProcessorClass = Class.forName(processorClassName);
        
        // All rules need to follow this declaration, failing to do so will result in a
        // ClassCastException
        @SuppressWarnings({ "unchecked", "rawtypes" })
        ItemProcessor<Map<String, Object>, Map<String, Object>> itemProcessor = 
            (ItemProcessor) itemProcessorClass.newInstance();

        // Register the bean for spring auotwiring
        
        applicationContext.getAutowireCapableBeanFactory().autowireBean(itemProcessor);
        
        // TODO: May be a neater (more Spring-like) way to do this
        initializeBean(itemProcessorClass, itemProcessor);
        
        // Cache
        
        processorInstances.put(processorClassName, itemProcessor);
        
        return itemProcessor;
    }
    
    private void initializeBean(Class<?> itemProcessorClass, ItemProcessor itemProcessor)
            throws Exception {
        if (itemProcessor instanceof InitializingBean) {
            ((InitializingBean) itemProcessor).afterPropertiesSet();
        } else {
            Set<Method> initMethods = org.springframework.batch.support.ReflectionUtils.findMethod(
                    itemProcessorClass, PostConstruct.class);
            Assert.isTrue(initMethods.size() <= 1,
                    "Only one method can be annotated with @PostConstruct");
            for (Method initMethod : initMethods) {
                ReflectionUtils.makeAccessible(initMethod);
                ReflectionUtils.invokeMethod(initMethod, itemProcessor);
            }
        }
    }

    /**
     * Build output String for use by CassandraItemWriter
     * @param outputMap
     * @return
     */
    private String formatResults(Map<String, Object> outputMap) {
        StringWriter buff = new StringWriter();
        
        int count = 0;
        
        for(String outputField : outputFieldNames) {
            if (count > 0) {
                buff.append(outputFieldSeparator);
            }

            Object value = outputMap.get(outputField);
            
            if (value != null) {
                buff.append(value.toString());
            }
            
            count++;
        }
        
        LOG.debug("Added {} fields to return string", count);
        
        return buff.toString();
    }
    
    /**
     * Parse string for use in processors (e.g.: Rules)
     * @param line
     * @return
     */
    private Map<String, Object> mapInputs(String line) {
        String fields[] = line.split(inputFieldSeparator, splitLimit);
        
        // Bad count check
        
        if (inputFieldNames.size() != fields.length) {
            throw new BadRowException("Invalid field count? expected " + inputFieldNames.size() + " got " + fields.length + "!?");
        }
        
        Map<String, Object> res = new HashMap<String, Object>();
        
        for (int i = 0; i < fields.length; i++) {
            String fieldName = inputFieldNames.get(i);
            String fieldValue = trimFieldValues ? StringUtils.trimToEmpty(fields[i]) : fields[i];
            res.put(fieldName, fieldValue);
        }
        
        return res;
    }

	/**
	 * @return Processor class list
	 */
	public List<String> getProcessorClassList()
	{
		return processorClassList;
	}

	/**
	 * Set the processor class list
	 * @param processorClassList
	 */
	public void setProcessorClassList(List<String> processorClassList)
	{
		this.processorClassList = processorClassList;
	}

    /**
     * @return the outputFieldNames
     */
    public List<String> getOutputFieldNames() {
        return outputFieldNames;
    }

    /**
     * @param outputFieldNames the outputFieldNames to set
     */
    public void setOutputFieldNames(List<String> outputFieldNames) {
        this.outputFieldNames = outputFieldNames;
    }

    /**
     * @return the inputFieldNames
     */
    public List<String> getInputFieldNames() {
        return inputFieldNames;
    }

    /**
     * @param outputFieldNames the outputFieldNames to set
     */
    public void setInputFieldNames(List<String> inputFieldNames) {
        this.inputFieldNames = inputFieldNames;
    }

    /**
     * @return the inputFieldSeparator
     */
    public String getInputFieldSeparator() {
        return inputFieldSeparator;
    }

    /**
     * @param inputFieldSeparator the inputFieldSeparator to set
     */
    public void setInputFieldSeparator(String inputFieldSeparator) {
        this.inputFieldSeparator = String.format("\\Q%s\\E", inputFieldSeparator);
    }

    /**
     * @return the outputFieldSeparator
     */
    public String getOutputFieldSeparator() {
        return outputFieldSeparator;
    }

    /**
     * @param outputFieldSeparator the outputFieldSeparator to set
     */
    public void setOutputFieldSeparator(String outputFieldSeparator) {
        this.outputFieldSeparator = outputFieldSeparator;
    }

    public int getSplitLimit() {
        return splitLimit;
    }

    public void setSplitLimit(int splitLimit) {
        this.splitLimit = splitLimit;
    }

    public boolean isTrimFieldValues() {
        return trimFieldValues;
    }

    public void setTrimFieldValues(boolean trimFieldValues) {
        this.trimFieldValues = trimFieldValues;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        notEmpty(inputFieldNames, "No input field names configured!");
        notEmpty(outputFieldNames, "No output field names configured!");
    }

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException
	{
		this.applicationContext = applicationContext;
	}
}