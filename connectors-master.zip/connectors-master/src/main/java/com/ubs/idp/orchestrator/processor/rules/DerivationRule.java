package com.ubs.idp.orchestrator.processor.rules;

import java.util.Map;

/**
 * 
 * @author haniffsy
 */
public interface DerivationRule {
	
	/**
	 * @param inputFields
	 * @return A Map containing both the input and derived fields
	 */
	public Map<String,Object> derive(Map<String, Object> inputFields);

}
