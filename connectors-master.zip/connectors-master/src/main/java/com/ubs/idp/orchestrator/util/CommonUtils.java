package com.ubs.idp.orchestrator.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

public class CommonUtils {

    private static Logger logger = LoggerFactory.getLogger(CommonUtils.class);
    public static final String NEWLINE = "\n";

    public final static String SORTED_SUFFIX = "_SORTED";
    public final static String ERROR_SUFFIX = "_ERROR";
    public final static String TRANSFORMED_SUFFIX = "_TRANSFORMED";
    public final static String UNSORTED_SUFFIX = "_UNSORTED";

    public CommonUtils() {
        // TODO Auto-generated constructor stub
    }

    public static String appendTimestampToFilename(String filename) {
        String suffix = "";
        if (filename.indexOf(".") != -1) {
            suffix = filename.substring(filename.lastIndexOf(".") + 1);
            filename = filename.substring(0, filename.lastIndexOf("."));
        }
        filename += "-" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date(System.currentTimeMillis())) + "."
                + suffix;

        return filename;
    }

    /**
     * Calls the external sorting script for Ratings
     * 
     * @throws IOException
     */
    public static void sortFile(String sortScriptFile, File stageDir, File inputFile, File outputFile,
            String inputFileDelimiter, List<String> scriptInput) throws IOException {
        File ScriptFile = new File(sortScriptFile);

        if (!ScriptFile.exists()) {
            throw new IOException("Could not find sort script file" + sortScriptFile);
        }

        logger.info("Calling external sort script {} on incoming file {}", ScriptFile, inputFile);

        // TODO: Get the delimiter and key attribute positions from MDS
        // String[] commands =
        // {ScriptFile.getAbsolutePath(),inputFile.getAbsolutePath(),outputFile.getAbsolutePath(),inputFileDelimiter,"23","8","9","11","12","13"};

        String[] commands = new String[scriptInput.size() + 5];
        commands[0] = ScriptFile.getAbsolutePath();
        commands[1] = stageDir.getAbsolutePath();
        commands[2] = inputFile.getAbsolutePath();
        commands[3] = outputFile.getAbsolutePath();
        commands[4] = inputFileDelimiter;

        for (int i = 0; i < scriptInput.size(); i++) {

            commands[i + 5] = scriptInput.get(i);
        }
        Process proc = Runtime.getRuntime().exec(commands);

        try (BufferedReader br = new BufferedReader(new InputStreamReader(proc.getErrorStream()));) {
            int exitCode = proc.waitFor();
            logger.info("External sort command process returned exit code {}", exitCode);
            if (exitCode != 0) {
                String errorMessage = "";
                String line = "";
                while ((line = br.readLine()) != null) {
                    errorMessage += line;
                }

                throw new RuntimeException("The external sort command process returned an unexpected exit code of "
                        + exitCode + ". Reason: " + errorMessage);
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(
                    "The external sort command process was interrupted before it could finish: " + e, e);
        }
    }

    /**
     * Gets the first line of a file
     * 
     * @param File
     *            sortedFile
     * @return String headerRow
     * @throws IOException
     * @throws FileNotFoundException
     */
    public static String extractHeader(File inFile) {

        BufferedReader bufferedReader;
        String headerRow = null;

        try {
            bufferedReader = new BufferedReader(new FileReader(inFile));
            if ((headerRow = bufferedReader.readLine()) != null) {
                bufferedReader.close();
            } else {
                bufferedReader.close();
                headerRow = null;
            }
        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return headerRow;
    }

    /**
     * Checks if the specified file has more than one line. If so returns true
     * 
     * @param file
     */
    public static boolean doesFileHaveMoreThenOneLine(File file) {
        Assert.isTrue(file.exists(), "Could not find file " + file + " while checking line count.");
        int count = 0;
        try {
            try (FileInputStream fis = new FileInputStream(file);
                    InputStreamReader isr = new InputStreamReader(fis);
                    BufferedReader br = new BufferedReader(isr)) {
                while (br.readLine() != null) {
                    count++;
                    if (count > 1) {
                        fis.close();
                        isr.close();
                        br.close();
                        return true;
                    }
                }
            }
        } catch (Exception ex) {
            throw new RuntimeException(
                    "The following error occured checking the line count of file " + file + ":" + ex, ex);
        }
        return false;
    }

    public static File moveFromStageToDrop(File dropDir, File stagingFile) {
        // Move the staging file to the target file
        File dropFile = new File(dropDir + File.separator + stagingFile.getName());
        logger.debug("Moving staging file {} to target destination {}", stagingFile, dropFile);
        if (!stagingFile.renameTo(dropFile)) {
            throw new RuntimeException("Failed to move staging file " + stagingFile + " to target file " + dropFile
                    + "?! Check permissions? Does the target file already exist?");
        }
        return dropFile;
    }
}
