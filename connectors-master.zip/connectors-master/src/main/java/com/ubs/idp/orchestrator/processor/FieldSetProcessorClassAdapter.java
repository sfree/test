
package com.ubs.idp.orchestrator.processor;

import static org.springframework.util.Assert.notEmpty;
import static org.springframework.util.Assert.notNull;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.transform.DefaultFieldSet;
import org.springframework.batch.item.file.transform.DefaultFieldSetFactory;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.ubs.idp.connectors.spring.batch.exceptions.BadRowException;
import com.ubs.idp.orchestrator.mappers.SubSetMapper;

/**
 * FieldSet Processor which allows us to pass field sets fetched from Cassandra into our rules
 * 
 * This processor also performs a subset mapping after all the rules have been called. This acts
 * in the same way as the {@link SubSetMapper} by selecting a subset of the input attribute names
 * as defined in the output fieldnames and only returning them.
 * 
 *  We do this so that we can run rules over the entire row fetched from cassandra first, before
 *  doing a subset filter. We would be unable to do this is we did the subset before
 *  running the rules as certain attribute values may not be avaialble for the rule as
 *  they have been removed by the subset mapper
 * 
 * @author loverids
 */
public class FieldSetProcessorClassAdapter implements ItemProcessor<FieldSet,FieldSet>, InitializingBean, ApplicationContextAware {
    private List<String> processorClassList;    
    
    private List<String> inputFieldNames; 
    private List<String> outputFieldNames;
        
    private Map<String, ItemProcessor> processorInstances = new HashMap<String, ItemProcessor>();

    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    private Map<String,Object> jobParameters = new HashMap<String,Object>();
    
    /**
     * We keep an instance of the Spring context so that dynamic rule classes with autowiring
     * can be Spring registered
     */
    private ApplicationContext applicationContext;

    @Override
    public FieldSet process(FieldSet item) throws Exception {
        if(null== processorClassList || processorClassList.isEmpty()){
            // TODO: Should throw exception and/or log...
            return item;
        }
        else{
            Map<String, Object> tempOutputItem = mapInputs(item);
            for(String processorClassName: processorClassList ){

                ItemProcessor itemProcessor = getOrCreateItemProcessor(processorClassName);
                
                Map<String, Object> tempInputItem = tempOutputItem;

                // Check if we need to pass in the jobParameters
                if( itemProcessor instanceof ItemProcessorWithParameters )
                {
                	tempOutputItem = (Map<String, Object>) ((ItemProcessorWithParameters)itemProcessor).process(tempInputItem,jobParameters);
                }
                else
                {
                	tempOutputItem = (Map<String, Object>) itemProcessor.process(tempInputItem);
                }
                
                
                
                // If the item processor returns null then it indicates that the rule has deemed
                // this line is not to be processed so we return null
                if( tempOutputItem == null )
                {
                	return null;
                }
            }            
            
            return formatResults(tempOutputItem);
        }
    }
    
    private ItemProcessor getOrCreateItemProcessor(String processorClassName) throws Exception {
        
        if (processorInstances.containsKey(processorClassName)) {
            return processorInstances.get(processorClassName);
        }
        
        ItemProcessor itemProcessor = (ItemProcessor) Class.forName(processorClassName).newInstance();

        // Register the bean for spring auotwiring
        
        applicationContext.getAutowireCapableBeanFactory().autowireBean(itemProcessor);
        
        // TODO: May be a neater (more Spring-like) way to do this
        
        if (itemProcessor instanceof InitializingBean) {
            ((InitializingBean)itemProcessor).afterPropertiesSet();
        }
        
        // Cache
        
        processorInstances.put(processorClassName, itemProcessor);
        
        return itemProcessor;
    }

    /**
     * Build the output FieldSet from the results of the rule parsing
     * by doing a subset mapping. This is achieved by only selecting
     * values defined in the output field names list which should be
     * a subset of the input field names
     * @param outputMap
     * @return
     */
    private FieldSet formatResults(Map<String, Object> outputMap) {
        
		List<String> subsetNames = new ArrayList<String>();
		List<String> subsetValues = new ArrayList<String>();
		
		for( String fieldName : outputFieldNames)
		{
			if( !inputFieldNames.contains(fieldName ) )
			{
				throw new RuntimeException("The attribute name '" + fieldName + "' does not exist in the passed in field set: " + inputFieldNames );
			}
			
			subsetNames.add( fieldName );
			subsetValues.add( (String)outputMap.get(fieldName) );
		}
		
		return new DefaultFieldSet(subsetValues.toArray( new String[]{}),subsetNames.toArray(new String[]{}));
    }
    
    /**
     * Parse string for use in processors (e.g.: Rules)
     * @param line
     * @return
     */
    private Map<String, Object> mapInputs(FieldSet fields) {
        
        // Bad count check
        
        if (inputFieldNames.size() != fields.getFieldCount()) {
            throw new BadRowException("Invalid field count? expected " + inputFieldNames.size() + " got " + fields.getFieldCount() + "!?");
        }
        
        Map<String, Object> res = new HashMap<String, Object>();
        
        for (int i = 0 ; i < fields.getFieldCount() ; i++) {
            String fieldName = inputFieldNames.get(i);
            String fieldValue = fields.readString(fieldName);
            res.put(fieldName, fieldValue);
        }
        
        return res;
    }

	/**
	 * @return Processor class list
	 */
	public List<String> getProcessorClassList()
	{
		return processorClassList;
	}

	/**
	 * Set the processor class list
	 * @param processorClassList
	 */
	public void setProcessorClassList(List<String> processorClassList)
	{
		this.processorClassList = processorClassList;
	}

    /**
     * @return the outputFieldNames
     */
    public List<String> getOutputFieldNames() {
        return outputFieldNames;
    }

    /**
     * @param outputFieldNames the outputFieldNames to set
     */
    public void setOutputFieldNames(List<String> outputFieldNames) {
        this.outputFieldNames = outputFieldNames;
    }

    /**
     * @return the inputFieldNames
     */
    public List<String> getInputFieldNames() {
        return inputFieldNames;
    }

    /**
     * @param outputFieldNames the outputFieldNames to set
     */
    public void setInputFieldNames(List<String> inputFieldNames) {
        this.inputFieldNames = inputFieldNames;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        notNull(inputFieldNames, "No input field names configured?");
        notEmpty(inputFieldNames, "Zero input field names configured?");
        notNull(outputFieldNames, "No output field names configured?");
        notEmpty(outputFieldNames, "Zero output field names configured?");
    }

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException
	{
		this.applicationContext = applicationContext;
	}

	public Map<String, Object> getJobParameters()
	{
		return jobParameters;
	}

	public void setJobParameters(Map<String, Object> jobParameters)
	{
		this.jobParameters = jobParameters;
	}
}