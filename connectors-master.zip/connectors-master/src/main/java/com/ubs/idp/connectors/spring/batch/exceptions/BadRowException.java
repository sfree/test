package com.ubs.idp.connectors.spring.batch.exceptions;

public class BadRowException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public BadRowException() {
        super();
    }

    public BadRowException(String message) {
        super(message);
    }
}
