package com.ubs.idp.orchestrator.processor;

import com.ubs.idp.base.IdpBoundary;
import com.ubs.idp.connectors.spring.batch.writers.AccountEventResultSetWriter;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.orchestrator.util.MetaDataRetrieverUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.ubs.idp.orchestrator.util.AccountEventConstants.*;

import java.util.*;
import java.util.Map.Entry;

@IdpBoundary
@Service
public class AccountEventResultSetMapTransformer implements ItemProcessor<AccountEventResultSetWriter.AccountEventResultSets, AccountEventResultSetWriter.AccountEventResultSets>, InitializingBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(AccountEventResultSetMapTransformer.class);
	private MetaDataRetrieverUtil metaDataRetrieverUtil;

	private MetadataService mdsClient;

	@Override
	public AccountEventResultSetWriter.AccountEventResultSets process(AccountEventResultSetWriter.AccountEventResultSets accountEventResultSets) throws Exception {

		LOGGER.info("Starting result set map transformation for event Id {} ", accountEventResultSets.getMappedEvent().get(RESULT_SET_IDP_ID));
		Map<String, Map<String, String>>dataSetTransformationMappings = mdsClient.getDataSetTransformationMappings("PropagationStoredProc" + accountEventResultSets.getMappedEvent().get(DOWNSTREAM_SP_ID));
		Entry<String, Map<String, String>> dataSetTransformationMapping = dataSetTransformationMappings.entrySet().iterator().next();
		Map<Integer, Map<Integer, Map<String, String>>> resultSetsMap = accountEventResultSets.getResultSetsMap();
		Map<Integer, Map<Integer, Map<String, String>>> transformedResultSetsMap = new HashMap<>();
		for (Integer resultSetKey : resultSetsMap.keySet()) {
			Map<Integer, Map<String, String>> rowsForResultSet = resultSetsMap.get(resultSetKey);
			Map<Integer, Map<String, String>> resultSetRowMap = new HashMap<>();
			for (Integer recordKey : rowsForResultSet.keySet()) {            	
				Map<String, String> map = rowsForResultSet.get(recordKey);
				Map<String, String> transformedMap = new HashMap<>();
				Iterator<Map.Entry<String,String>> iterator = map.entrySet().iterator();
				while (iterator.hasNext()) {
					Map.Entry<String, String> nextEntry = iterator.next();                    
					transformedMap.put(
							dataSetTransformationMapping.getValue().get(nextEntry.getKey()),
							nextEntry.getValue());
				}	

				resultSetRowMap.put(recordKey, transformedMap);
			}
			transformedResultSetsMap.put(resultSetKey, resultSetRowMap);
		}
		accountEventResultSets.setTransformedResultSetsMap(transformedResultSetsMap);
		return accountEventResultSets;
	}

	public void setMdsClient(MetadataService mdsClient) {
		this.mdsClient = mdsClient;
	}

	@Autowired
	public void setMetaDataRetrieverUtil(MetaDataRetrieverUtil metaDataRetrieverUtil) {
		this.metaDataRetrieverUtil = metaDataRetrieverUtil;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		//To change body of implemented methods use File | Settings | File Templates.
	}
}
