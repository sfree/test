package com.ubs.idp.orchestrator.processor.rules.treasuryar;

import java.util.Map;

import org.springframework.batch.item.ItemProcessor;

/**
 * Rule that filters out blank rows with dummy values in from a Rating file
 * @author loverids
 *
 */
public class RatingBlankRowFilterRule implements ItemProcessor<Map<String, Object>, Map<String, Object>>
{
	public final static String ACTIVE_ATTRIBUTE_NAME = "issue.ubsId";
	
	@Override
	public Map<String, Object> process(Map<String, Object> inputFields) throws Exception
	{
		// Find a value for the active attributes
		Object value = inputFields.get(ACTIVE_ATTRIBUTE_NAME);
			
		// If we have a value check if it has a known dummy value and return null if so
		if( value != null )
		{
			if( value.toString().toLowerCase().equals("-9996")  )
			{
				return null;
			}
		}
		
		return inputFields;
	}

}