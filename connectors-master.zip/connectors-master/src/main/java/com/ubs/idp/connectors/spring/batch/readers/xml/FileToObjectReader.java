package com.ubs.idp.connectors.spring.batch.readers.xml;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.ubs.idp.connectors.BaseConnector;
import com.ubs.idp.connectors.spring.batch.readers.xml.parsers.ObjectHierarchyParser;

/**
 * Spring batch file-to-object reader
 * 
 * @author mcnamars
 */
public class FileToObjectReader extends BaseConnector implements ItemReader<Object>, ItemStream, InitializingBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileToObjectReader.class);

    private int rowCount = 0;
    private String filename;
    private List<?> records = null;
    
    @Autowired
    @Qualifier("objectParser")
    private ObjectHierarchyParser<?> parser;

    /**
     * Bare bones constructor
     */
    public FileToObjectReader() {
        LOGGER.debug("Initialise file-to-object reader for source ID '{}'...", sourceIdentifier);
    }

    /**
     * Return number of rows read
     * 
     * @return
     */
    public long getRowCount() {
        return rowCount;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    @Override
    public Object read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
        Object record = null;
        
        LOGGER.debug("Read called for source ID '{}'...", sourceIdentifier);

        if (rowCount < records.size()) {
            record = records.get(rowCount++);
        }

        // Think about re-initialise (reset row count etc.)

        if (LOGGER.isDebugEnabled())
            LOGGER.debug("Read returns '{}'...", record);

        return record;
    }
    
    @Override
    public void open(ExecutionContext executionContext) throws ItemStreamException {
        LOGGER.debug("Open reader...");
        
        try {
            records = parser.parseData(filename);
        } catch (Exception ex) {
            throw new ItemStreamException("Failed to process file '" + filename + "'?", ex);
        }

        rowCount = 0;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.batch.item.ItemStream#close()
     */
    public void close() {
        if (LOGGER.isDebugEnabled())
            LOGGER.debug("Closing reader");

        records = null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.batch.item.ItemStream#update(org.springframework.
     * batch.item.ExecutionContext)
     */
    @Override
    public void update(ExecutionContext executionContext) throws ItemStreamException {
        LOGGER.debug("Update exectution context");
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        // TODO: Add property assertions

        LOGGER.info("Reader afterPropertiesSet");
    }
}
