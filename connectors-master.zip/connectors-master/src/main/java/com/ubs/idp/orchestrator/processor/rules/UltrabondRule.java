package com.ubs.idp.orchestrator.processor.rules;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ubs.idp.domainRegistry.DomainRegistry;

/**
 * Temporary Rule for Ultrabond to get us up and running. Sets the issue.ubsId
 *  and tL.countryUbsId from DomainRegistry
 *
 * @author aigalsa
 */
@Component
public class UltrabondRule extends DerivationRuleTemplate implements ItemProcessor<Map<String,Object>,Map<String,Object>>
{
	
	public final static List<String> FIELDS_TO_SET = Arrays.asList("issue.ubsId"); 
	
	@Autowired
	@Qualifier("domainRegistry")
	DomainRegistry domainRegistry;
	
    @Override
    public Map<String, Object> applyRules(Map<String, Object> inputFields) 
    {
        Map<String,Object> derivedFields = new HashMap<String,Object>();

        String issueIsin = (null == inputFields.get("KEY")) ? null : inputFields.get("KEY").toString();

        derivedFields.put("issue.ubsId", domainRegistry.createDomainKey("Instrument", issueIsin).getDomainKey());
    	//TODO country code
//    	derivedFields.put("tL.countryUbsId", domainRegistry.createDomainKey("Country", "Ultrabond", "Ultrabond.IDP", issueIsin).getDomainKey());

        return derivedFields;
    }

    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        return derive(item);
    }
}


