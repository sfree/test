package com.ubs.idp.orchestrator.writers;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.batch.item.file.FlatFileHeaderCallback;

/**
 * Simple header writer for a flat file that writes the attribute list
 * on the first line separated by the delimeter 
 * 
 * @author loverids
 *
 */
public class AttributeNameFlatFileHeaderWriter implements FlatFileHeaderCallback
{
	private String delimiter;
	
	private List<String> attributeNames;
	
	@Override
	public void writeHeader(Writer writer) throws IOException
	{
		String line = attributeNames.toString();
		
		// Trim the braces and replace the commas with the delimiter
		line = line.substring(1, line.length()-1);
		line = line.replace(",",delimiter);
		
		writer.write(line);
	}

	public String getDelimiter()
	{
		return delimiter;
	}

	public void setDelimiter(String delimiter)
	{
		this.delimiter = delimiter;
	}

	public List<String> getAttributeNames()
	{
		return attributeNames;
	}

	public void setAttributeNames(List<String> attributeNames)
	{
		this.attributeNames = attributeNames;
	}

    public void setAttributeNames(String attributeNames)
    {
        String[] attributeNamesArray = attributeNames.split(",");
        
        List<String> attributeNamesList = new ArrayList<>(Arrays.asList(attributeNamesArray));
        
        this.attributeNames = attributeNamesList;
    }
}
