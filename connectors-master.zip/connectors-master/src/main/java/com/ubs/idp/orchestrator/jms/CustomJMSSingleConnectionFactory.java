/**
 * 
 */
package com.ubs.idp.orchestrator.jms;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;

import org.springframework.jms.connection.SingleConnectionFactory;

/**
 * @author valechak
 *
 */
public class CustomJMSSingleConnectionFactory extends SingleConnectionFactory {
	
	private String username;
	private String password;
	
	
	public CustomJMSSingleConnectionFactory(ConnectionFactory factory){
        super(factory);
    }
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;	
		
	}
	
	@Override
	protected Connection doCreateConnection() throws JMSException {
        return getTargetConnectionFactory().createConnection(username,password);
    }

}
