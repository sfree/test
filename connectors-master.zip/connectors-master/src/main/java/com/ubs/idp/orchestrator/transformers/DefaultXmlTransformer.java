package com.ubs.idp.orchestrator.transformers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DefaultXmlTransformer implements XmlTransformer {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultXmlTransformer.class);

	@Override
	public String transformXmlMessage(String xml) throws Exception {
		LOGGER.debug("No further Transformation required for the XML Message");
		return xml;
	}

}
