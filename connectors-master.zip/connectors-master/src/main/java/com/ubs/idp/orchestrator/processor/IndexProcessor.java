package com.ubs.idp.orchestrator.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.file.transform.FieldSet;

public class IndexProcessor implements ItemProcessor<FieldSet, FieldSet> {

    public String indexName;
    public String indexField;

    private int count=0;

    @Override
    public FieldSet process(FieldSet item) throws Exception {
        if (!indexField.isEmpty() && item.readString(indexField).isEmpty()) {
            throw new ParseException("CANNOT INDEX FIELD (" + indexField + ") with NULL VALUE - RECORD:" + item);
        }

        FieldSetToKeyValueProcessor fieldSetToKeyValueProcessor = new FieldSetToKeyValueProcessor();
        fieldSetToKeyValueProcessor.setDatasetName(item.readString("instr_id"));
        fieldSetToKeyValueProcessor.setKeyField(indexField);

        return fieldSetToKeyValueProcessor.process(item);
    }

    public void setIndexField(String indexField) {
        this.indexField = indexField;
    }
    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }

}
