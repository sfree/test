package com.ubs.idp.orchestrator.util;


import com.ubs.idp.connectors.spring.batch.writers.AccountEventResultSetWriter;
import org.springframework.batch.item.database.ItemSqlParameterSourceProvider;
import org.springframework.jdbc.core.namedparam.AbstractSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.util.Map;

public class MapBasedSqlParameterSourceProvider implements ItemSqlParameterSourceProvider<AccountEventResultSetWriter.AccountEventResultSets> {


    @Override
    public SqlParameterSource createSqlParameterSource(AccountEventResultSetWriter.AccountEventResultSets accountEventResultSets) {

        return new MapPropertySqlParameterSource(accountEventResultSets.getMappedEvent());
    }

    public static class MapPropertySqlParameterSource extends AbstractSqlParameterSource {

        Map<String, Object> events;

        public MapPropertySqlParameterSource (Map<String, Object> events) {
            this.events = events;
        }

        @Override
        public boolean hasValue(String s) {
            return events.containsKey(s);
        }

        @Override
        public Object getValue(String s) throws IllegalArgumentException {
            return events.get(s);
        }
    }
}


