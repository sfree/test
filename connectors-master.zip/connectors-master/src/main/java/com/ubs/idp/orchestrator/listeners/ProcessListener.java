package com.ubs.idp.orchestrator.listeners;

import org.springframework.batch.core.ItemProcessListener;

public class ProcessListener implements ItemProcessListener {
    @Override
    public void beforeProcess(Object item) {        
    }

    @Override
    public void afterProcess(Object item, Object result) {
    }

    @Override
    public void onProcessError(Object item, Exception e) {
    }
}
