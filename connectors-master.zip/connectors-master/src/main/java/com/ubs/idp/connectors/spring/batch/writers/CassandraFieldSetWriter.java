package com.ubs.idp.connectors.spring.batch.writers;

import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraDataObject;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component("cassandraFieldSetWriter")
public class CassandraFieldSetWriter implements ItemWriter<FieldSet>, InitializingBean {

    @Autowired
    @Qualifier("cassandraSessionHelper")
    private CassandraSessionHelper cassandraSessionHelper;
    
    private CassandraCqlProxy proxy;

    private String tableName;
    private String primaryKey;
    
    private Logger logger = LoggerFactory.getLogger(CassandraFieldSetWriter.class);
    
    @Override
    public void write(List<? extends FieldSet> items) throws Exception {
        
        CassandraDataObject cassandraDataObject = new CassandraDataObject();
        cassandraDataObject.setTableName(tableName);

        Map<String,String> keyMap = new HashMap<String,String>();
        Map<String, Object> attributeMap = new HashMap<String, Object>();
        for (FieldSet fieldSet : items) {
            attributeMap.put("value", fieldSet.readString("value"));
            attributeMap.put("column1", fieldSet.readString("column1"));
            keyMap.put("key", fieldSet.readString("key"));

            cassandraDataObject.setKeys(keyMap);
            cassandraDataObject.setAttributes(attributeMap);

            proxy.executeQuery(cassandraDataObject.insertStatement());
        }
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        logger.info("Set table name to {}", tableName);
        this.tableName = tableName;
    }

    public String getPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(String primaryKey) {
        logger.info("Set primary key to {}", primaryKey);
        this.primaryKey = primaryKey;
    }
    
    /* (non-Javadoc)
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    public void afterPropertiesSet() throws Exception {
        logger.info("Get Cassandra proxy");

        // Initialise/fetch proxy
        proxy = cassandraSessionHelper.getProxy();
        
        logger.info("Got Cassandra proxy: {}", proxy);
    }
}
