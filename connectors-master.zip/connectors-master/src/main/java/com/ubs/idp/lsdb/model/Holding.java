package com.ubs.idp.lsdb.model;

/**
 * JiBX POJO
 * @author mcminnp
 */
public class Holding {
    private String id;
    private String typeId;
    private String typeName;
    private Float percentage;
    private String startDate;
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }

    public String getTypeId() {
        return typeId;
    }

    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public Float getPercentage() {
        if (percentage == null) {
            return 0f;
        }
        return percentage;
    }

    public void setPercentage(Float percentage) {
        this.percentage = percentage;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
}