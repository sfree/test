package com.ubs.idp.orchestrator.mappers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.file.LineMapper;

/**
 * LineMapper that maps values from the original fieldset and extracts
 * a subset of values 
 * 
 * @author loverids
 */
public class SubSetLineMapper implements LineMapper<String> 
{
	private static Logger logger = LoggerFactory.getLogger(SubSetLineMapper.class);
	
	/**
	 * The field names of the attributes from the super set
	 */
	private String[] supersetAttributeNames;
	
	/**
	 * The field names of the attributes from the incoming fieldset
	 * to extract 
	 */
	private String[] subsetAttributeNames;
	
	private boolean attributesMatch = false;
	
	private String delimiter;
	
	/*
	 * (non-Javadoc)
	 * @see org.springframework.batch.item.file.LineMapper#mapLine(java.lang.String, int)
	 */
	@Override
	public String mapLine(String line, int lineNumber) throws Exception 
	{	
		// Check if the flag has been set already to save doing a comparison
		if( attributesMatch )
		{
			return line;
		}
		
		List<String> allFieldNames = Arrays.asList(supersetAttributeNames);
		List<String> allFieldValues = Arrays.asList(line.split(delimiter,-1));
		
		if( allFieldNames.size() != allFieldValues.size() )
		{
			throw new RuntimeException("Line mismatch error with line '"+lineNumber+"'. Data is defined with '"+allFieldNames.size()+"' attributes but incoming line has only '"+allFieldValues.size()+"' values using delimiter '"+delimiter+"': line='"+line+"'");
		}
		
		List<String> subsetNames = new ArrayList<String>();
		List<String> subsetValues = new ArrayList<String>();
		
		for( String fieldName : subsetAttributeNames)
		{
			if( !allFieldNames.contains(fieldName ) )
			{
				throw new RuntimeException("The attribute name '" + fieldName + "' does not exist in the passed in line '"+line+"' with attributes '" + allFieldNames + "'");
			}
			
			subsetNames.add( fieldName );
			subsetValues.add( allFieldValues.get( allFieldNames.indexOf( fieldName ) ) );
		}

		return StringUtils.join(subsetValues, delimiter);
	}

	public String getDelimiter()
	{
		return delimiter;
	}

	public void setDelimiter(String delimiter)
	{
		this.delimiter = delimiter;
	}

	public String[] getSubsetAttributeNames()
	{
		return subsetAttributeNames;
	}

	public void setSubsetAttributeNames(String[] subsetAttributeNames)
	{
		this.subsetAttributeNames = subsetAttributeNames;
		checkAttributeNamesForDifferences();
	}

	public String[] getSupersetAttributeNames()
	{
		return supersetAttributeNames;
	}

	public void setSupersetAttributeNames(String[] supersetAttributeNames)
	{
		this.supersetAttributeNames = supersetAttributeNames;
		checkAttributeNamesForDifferences();
	}
	
	/**
	 * Checks the superset attributes against subset attribute names and
	 * if they are the same we set a flag so that this mapper then acts
	 * as a passthrough mapper 
	 */
	public void checkAttributeNamesForDifferences()
	{
		if( supersetAttributeNames != null && supersetAttributeNames.length > 0 &&
			subsetAttributeNames != null && subsetAttributeNames.length > 0 )
		{
			if( supersetAttributeNames.length == subsetAttributeNames.length )
			{
				for( int i = 0; i < supersetAttributeNames.length; i ++ )
				{
					if( !supersetAttributeNames[i].equals(subsetAttributeNames[i]) )
					{
						// Attributes dont match so exit
						return;
					}
				}
				
				// All attribute names match so we set the flag
				logger.debug("Superset attributes and subset attributes match");
				attributesMatch = true;
			}
		}
	}
 
}
