package com.ubs.idp.orchestrator.readers;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.collections.map.MultiValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ReaderNotOpenException;
import org.springframework.batch.item.file.BufferedReaderFactory;
import org.springframework.batch.item.file.DefaultBufferedReaderFactory;
import org.springframework.batch.item.file.FlatFileHeaderCallback;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.file.LineCallbackHandler;
import org.springframework.batch.item.file.NonTransientFlatFileException;
import org.springframework.batch.item.file.separator.RecordSeparatorPolicy;
import org.springframework.batch.item.file.separator.SimpleRecordSeparatorPolicy;
import org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;

import com.ubs.idp.connectors.spring.batch.exceptions.BadRowException;

public class ThinToWideGroupItemReader extends AbstractItemCountingItemStreamItemReader<String> implements InitializingBean,
        FlatFileHeaderCallback {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /*
     * Externally configured variables
     */
    protected String inputFileDelimiter;
    protected String outputFileDelimiter;
    protected File dropDir;
    protected File archiveDir;
    protected File errorDir;
    protected File stagingDir;
    protected List<String> keyColumns;
    protected List<String> inputColumns;
    protected String pivotColumn;
    protected List<String> targetPivotValues;
    protected List<String> columnsAssociatedWithPivot;
    protected List<String> outputColumns;

    /*
     * Member variables for transformation
     */
    protected ArrayList<Integer> keyColumnIndices;
    protected ArrayList<Integer> pivotColumnIndices;
    protected static String outputHeader;
    protected String[] outputTokens;
    protected static HashMap<String, Integer> origHeaderLineIndices;
    protected static MultiValueMap outHdrIndicesAndGroup;

    protected static final String DATA_VARY_WARNING = "varies";
    protected static final String COLUMN_NAME_SEPARATOR = "_";
    protected static final String EMPTY = "";
    protected static final String SPACE = " ";
    protected static final String NEWLINE = "\n";
    protected static final String DEFAULT_DELIMITER = ",";
    protected Comparator<String> comparator;

    // default encoding for input files
    public static final String DEFAULT_CHARSET = Charset.defaultCharset().name();

    private RecordSeparatorPolicy recordSeparatorPolicy = new SimpleRecordSeparatorPolicy();

    private boolean strict = true;

    private Resource resource;

    private String[] comments = new String[] { "#" };

    private BufferedReader reader;

    private int lineCount = 0;

    private int linesToSkip = 0;

    private boolean noInput = false;

    private String encoding = DEFAULT_CHARSET;

    private LineCallbackHandler skippedLinesCallback;

    private BufferedReaderFactory bufferedReaderFactory = new DefaultBufferedReaderFactory();

    private boolean targetEmpty = true;

    private String targetRow = "";

    private ArrayList<String[]> sameKeyRows = new ArrayList<String[]>();

    public ThinToWideGroupItemReader() {
        setName(ClassUtils.getShortName(ThinToWideGroupItemReader.class));
    }

    @Override
    protected String doRead() throws Exception {
        if (noInput) {
            return null;
        }

        String line = null;

        while ((line = readLine()) != null) {
            if (line.length() == 0) {
                // do nothing, want to get to a row of data
            }
            // very first row populates the 'targetRow'
            else if (targetEmpty) {
                sameKeyRows.add(line.split(inputFileDelimiter, -1));
                targetRow = line;
                targetEmpty = false;
                // else compare two rows
            } else if (comparator.compare(line, targetRow) == 0) {
                // ignore identical rows(i.e. duplicated data in file)
                if (!line.equals(targetRow)) {
                    sameKeyRows.add(line.split(inputFileDelimiter, -1));
                    targetRow = line;
                }
            } // previous/cur rows don't match so pivot current sameKeyRows
            else {
                // the non-matching row becomes the new target
                targetRow = line;

                String finalRow = null;

                try {
                    finalRow = pivotRows(sameKeyRows, outHdrIndicesAndGroup);
                } catch (Exception e) {
                    throw e;
                } finally {
                    sameKeyRows.clear();
                    sameKeyRows.add(targetRow.split(inputFileDelimiter, -1));
                }

                if (finalRow != null) {
                    return finalRow;
                }
            }
        }

        // when the buffer has no more entries, process last group
        // First check for the original header which we want to ignore (i.e not
        // persist)
        if (sameKeyRows.size() >= 1 && !sameKeyRows.contains(outputHeader)) {
            String finalRow = null;
            try {
                finalRow = pivotRows(sameKeyRows, outHdrIndicesAndGroup);
            } catch (Exception e) {
                throw e;
            } finally {
                sameKeyRows.clear();
            }

            if (finalRow != null) {
                return finalRow;
            }
        }

        return null;
    }

    @Override
    protected void doOpen() throws Exception {
        Assert.notNull(resource, "Input resource must be set");
        Assert.notNull(recordSeparatorPolicy, "RecordSeparatorPolicy must be set");

        targetEmpty = true;
        targetRow = "";

        noInput = true;
        if (!resource.exists()) {
            if (strict) {
                throw new IllegalStateException("Input resource must exist (reader is in 'strict' mode): " + resource);
            }
            logger.warn("Input resource does not exist " + resource.getDescription());
            return;
        }

        if (!resource.isReadable()) {
            if (strict) {
                throw new IllegalStateException("Input resource must be readable (reader is in 'strict' mode): " + resource);
            }
            logger.warn("Input resource is not readable " + resource.getDescription());
            return;
        }

        reader = bufferedReaderFactory.create(resource, encoding);
        for (int i = 0; i < linesToSkip; i++) {
            String line = readLine();
            if (skippedLinesCallback != null) {
                skippedLinesCallback.handleLine(line);
            }
        }
        noInput = false;

    }

    @Override
    protected void doClose() throws Exception {
        lineCount = 0;
        if (reader != null) {
            reader.close();
        }
    }

    /**
     * @return next line (skip comments).getCurrentResource
     */
    private String readLine() {

        if (reader == null) {
            throw new ReaderNotOpenException("Reader must be open before it can be read.");
        }

        String line = null;

        try {
            line = this.reader.readLine();
            if (line == null) {
                return null;
            }
            lineCount++;
            while (isCommentOrBlank(line)) {
                line = reader.readLine();
                if (line == null) {
                    return null;
                }
                lineCount++;
            }

            line = applyRecordSeparatorPolicy(line);
        } catch (IOException e) {
            // Prevent IOException from recurring indefinitely
            // if client keeps catching and re-calling
            noInput = true;
            throw new NonTransientFlatFileException("Unable to read from resource: [" + resource + "]", e, line, lineCount);
        }
        return line;
    }

    private boolean isCommentOrBlank(String line) {
        for (String prefix : comments) {
            if (line.startsWith(prefix) || line.trim().length() == 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * Public setter for the input resource.
     */
    public void setResource(Resource resource) {
        this.resource = resource;
    }

    private String applyRecordSeparatorPolicy(String line) throws IOException {

        String record = line;
        while (line != null && !recordSeparatorPolicy.isEndOfRecord(record)) {
            line = this.reader.readLine();
            if (line == null) {
                if (StringUtils.hasText(record)) {
                    // A record was partially complete since it hasn't ended but
                    // the line is null
                    throw new FlatFileParseException("Unexpected end of file before record complete", record, lineCount);
                } else {
                    // Record has no text but it might still be post processed
                    // to something (skipping preProcess since that was already
                    // done)
                    break;
                }
            } else {
                lineCount++;
            }
            record = recordSeparatorPolicy.preProcess(record) + line;
        }

        return recordSeparatorPolicy.postProcess(record);

    }

    @Override
    public void afterPropertiesSet() {

        // Create a Hashmap of the orig.header values to its corresp. index
        origHeaderLineIndices = mapSubstringsToIndices(inputColumns);
        keyColumnIndices = new ArrayList<Integer>();
        pivotColumnIndices = new ArrayList<Integer>();

        // set other default values if not provided in config
        if (outputColumns == null || outputColumns.size() == 0) {
            outputColumns = new ArrayList<String>(inputColumns);
        }

        validateProperties();

        // Build the column indicies
        keyColumnIndices = getColumnIndices(inputColumns, keyColumns);
        pivotColumnIndices = getColumnIndices(inputColumns, Arrays.asList(pivotColumn));

        logger.info("Fetching header columns");
        outputTokens = getOutputHeaderTokens();
        outputHeader = getOutputHeader(outputTokens);

        logger.info("Mapping header columns to indicies");
        outHdrIndicesAndGroup = mapOutHdrToIndicesAndPivotValues();

        initComparator();
    }

    /**
     * Validates that we have specified values for all our properties and
     * reverts to defaults if not present
     */
    private void validateProperties() {
        // check for delimiter in config
        if (inputFileDelimiter == null) {
            throw new RuntimeException("No delimiter specified for the input file for ThinToWideTransformer");
        }

        if (keyColumns.size() == 0) {
            throw new RuntimeException("NO KEY VALUES WERE SPECIFIED IN CONFIGURATION");
        }
        if (pivotColumn == null) {
            throw new RuntimeException("No pivot column specified for ThinToWideTransformer");
        }

        if (targetPivotValues.size() == 0) {
            throw new RuntimeException("No target pivot values specified for ThinToWideTransformer");
        }
    }

    /**
     * Sets up the comparator for the columns
     */
    private void initComparator() {
        comparator = new Comparator<String>() {
            public int compare(String firstString, String secondString) {
                String string1 = createKeyFromSourceString(firstString, keyColumnIndices, inputFileDelimiter).toUpperCase();
                String string2 = createKeyFromSourceString(secondString, keyColumnIndices, inputFileDelimiter).toUpperCase();
                return string1.compareTo(string2);
            }
        };

    }

    protected String pivotRows(ArrayList<String[]> sameRowsString, MultiValueMap outHeader) {
        String finalOutput = "";
        // ArrayList<String> finalPivotRowTokens = new ArrayList<String>();
        // Create a map of Pivot Values mapped to the corresponding row:
        HashMap<String, String[]> pivotValueToRowTokens = mapPivotValuesToRows(targetPivotValues, sameRowsString);
        // At least one of the rows in the list must have a relevant pivot value
        boolean aTargetRowExists = false;
        // Scan every item in the Output Header and look for corresponding Pivot
        // values
        for (int outHeaderIndex = 0; outHeaderIndex < outHdrIndicesAndGroup.size(); outHeaderIndex++) {
            // Map has a value of the associated pivot value (or null) to
            // original header index
            Object[] curPivValAndIndexOrigHdr = outHdrIndicesAndGroup.getCollection(outHeaderIndex).toArray();

            String pivotValForColumn = ((String) curPivValAndIndexOrigHdr[0]);
            Integer origHeaderIndexForColumn = Integer.valueOf((String) curPivValAndIndexOrigHdr[1]);
            String curDelimiter = outputFileDelimiter;
            // Do not add a delimiter at end of output rows
            if (outHeaderIndex == outHdrIndicesAndGroup.size() - 1) {
                curDelimiter = EMPTY;
            }
            // IF no pivot value is associated with output column:
            if (pivotValForColumn == null) {
                // First check if data is same among all rows
                if (rowsDataVariesAtIndex(sameRowsString, origHeaderIndexForColumn)) {
                    finalOutput = handleDataVaries(sameRowsString, finalOutput, origHeaderIndexForColumn, curDelimiter);
                }
                // Otherwise can just get the data from the first row in the
                // list
                else {
                    finalOutput += sameRowsString.get(0)[origHeaderIndexForColumn].trim() + curDelimiter;
                }
            }
            // output column assoc to pivot value.... check first if a row
            // exists for that value
            else if (pivotValueToRowTokens.get(pivotValForColumn) != null) {
                aTargetRowExists = true;
                finalOutput += pivotValueToRowTokens.get(pivotValForColumn)[origHeaderIndexForColumn].trim() + curDelimiter;
            } // otherwise the column is null
            else {
                finalOutput += EMPTY + curDelimiter;
            }
        }
        // again, only return value if at least one row contains a target pivot
        if (aTargetRowExists) {
            return finalOutput;
        } else
            return null;
    }

    private String handleDataVaries(ArrayList<String[]> sameRowsString, String finalOutput, Integer origHeaderIndexForColumn,
            String curDelimiter) {
        finalOutput += DATA_VARY_WARNING + curDelimiter;
        if (logger.isWarnEnabled()) {
            String message = "Warning: Data varies at column " + origHeaderIndexForColumn
                    + "(zero based) for the following rows:\n";
            for (String[] nextRow : sameRowsString) {
                String curRow = "";
                for (int i = 0; i < nextRow.length; i++) {
                    if (i != nextRow.length - 1) {
                        curRow += (i == origHeaderIndexForColumn ? "(*)" : "") + nextRow[i] + curDelimiter;
                    } else
                        curRow += nextRow[i];
                }
                message += curRow + NEWLINE;
            }

            // TODO: Do we want to write the row to the output with
            // a "varies" value or do we
            // want to throw a bad row exception?
            // throw new BadRowException(message);
            logger.warn(message);
        }
        return finalOutput;
    }

    /**
     * Creates a map of column headers and positions keyed on the column name
     * 
     * @param columns
     * @return
     */
    protected HashMap<String, Integer> mapSubstringsToIndices(List<String> columns) {
        HashMap<String, Integer> headerMap = new HashMap<String, Integer>();
        int counter = 0;
        for (String column : columns) {
            headerMap.put(column.trim(), counter++);
        }
        return headerMap;
    }

    /**
     * Combines values from the key rows and returns this unique key value as a
     * String
     * 
     * @param String
     *            stringToTokenize
     * @param String
     *            keyColumnIndices
     * @param String
     *            delimiter
     * @return String keyValue
     */
    protected String createKeyFromSourceString(String stringToTokenize, ArrayList<Integer> keyColumnIndices, String delimiter) {
        String rearrangedString = null;
        if (stringToTokenize.length() == 0 || (stringToTokenize.split(delimiter, -1).length) < keyColumnIndices.size()) {
            return EMPTY;
        } else {
            if (stringToTokenize.charAt(stringToTokenize.length() - 1) == DEFAULT_DELIMITER.charAt(0)) {
                stringToTokenize += "0";
            }
            String[] splitString = stringToTokenize.split(delimiter, -1);
            for (int nextIndex : keyColumnIndices) {
                rearrangedString += (splitString[nextIndex]).trim();
            }
            return rearrangedString;
        }
    }

    /**
     * Given a String of column names, finds and returns an ArrayList of
     * corresponding column indices
     * 
     * @param String
     *            headerLine - first line of the input file from where indices
     *            are derived
     * @param String
     *            keyColumns - From the properties file - names of the cols
     *            making up the key
     * @return an ArrayList<Integer> of the indices corresponding to the columns
     *         requested Note: if the properties file entry has a value with a
     *         series of colons (::::) then the first half of that value is the
     *         column name.
     */
    protected ArrayList<Integer> getColumnIndices(List<String> headerColumns, List<String> keyColumns) {
        boolean found = false;
        ArrayList<Integer> keyColumnIndices = new ArrayList<Integer>();

        for (int i = 0; i < keyColumns.size(); i++) {
            for (int x = 0; x < headerColumns.size(); x++) {
                if (headerColumns.get(x).trim().equals(keyColumns.get(i).trim())) {
                    keyColumnIndices.add(x);
                    found = true;
                }
            }
        }
        if (!found) {
            throw new RuntimeException("ERROR: INVALID CONFIG VALUE:  " + keyColumns
                    + " NOT FOUND IN ORIGINAL HEADER COLUMNS. (Please check values.  Verify delimiter value.)");
        }

        return keyColumnIndices;
    }

    /**
     * The output header will be a combination of both the existing column names
     * and also the pivot values that are being considered
     * 
     * @param String
     *            outColumns
     * @param String
     *            pivotColumns
     * @param String
     *            associatedColumns
     * @param String
     *            targetPivotValues
     * @param String
     *            delimiter
     * @return
     */

    protected String[] getOutputHeaderTokens() {
        List<String> outHeader = new ArrayList<String>();

        int maxNumTargetPivotValues = targetPivotValues.size();
        int numColsAssocWithPivot = columnsAssociatedWithPivot.size();

        // For XD integration we must have a set number of columns. So will add
        // blank columns if necessary.
        int maxPossibleOutputColumns = (origHeaderLineIndices.size()) + (maxNumTargetPivotValues * numColsAssocWithPivot)
                - (numColsAssocWithPivot) - 1;

        int countOutputColumns = 0;
        for (String next : outputColumns) {
            if (isTokenWithinString(next.trim(), columnsAssociatedWithPivot)) {
                for (String nextPivotValue : targetPivotValues) {
                    outHeader.add(nextPivotValue.trim() + COLUMN_NAME_SEPARATOR + next.trim());
                    countOutputColumns++;
                }
            } else if (isTokenWithinString(next.trim(), pivotColumn)) {
                // do nothing
            } else {
                outHeader.add(next.trim());
                countOutputColumns++;
            }
        }
        for (int i = 0; i < (maxPossibleOutputColumns - countOutputColumns); i++) {
            outHeader.add("     ");
        }

        String[] substrings = new String[outHeader.size()];
        outHeader.toArray(substrings);
        return substrings;
    }

    private String getOutputHeader(String[] outputTokens) {
        String finalOutputHeader = EMPTY;
        for (int i = 0; i < (outputTokens.length - 1); i++) {
            finalOutputHeader += outputTokens[i].trim() + outputFileDelimiter;
        }
        finalOutputHeader += outputTokens[outputTokens.length - 1].trim();
        return finalOutputHeader;
    }

    /**
     * Map the Output header to the Indices of the Original Header (same as the
     * indices for the rows of data) And to the Pivot value if any (else null)
     * 
     * @return
     */

    protected MultiValueMap mapOutHdrToIndicesAndPivotValues() {
        MultiValueMap outHeaderMap = new MultiValueMap();
        int mapItemCount = 0;
        for (int i = 0; i < outputColumns.size(); i++) {
            if (isTokenWithinString(outputColumns.get(i).trim(), columnsAssociatedWithPivot)) {
                for (String nextPivotValue : targetPivotValues) {
                    outHeaderMap.put(mapItemCount, nextPivotValue.trim());
                    outHeaderMap.put(mapItemCount++, String.valueOf(origHeaderLineIndices.get(outputColumns.get(i).trim())));
                }
            } else if (isTokenWithinString(outputColumns.get(i).trim(), pivotColumn)) {
                // do nothing
            } else {
                outHeaderMap.put(mapItemCount, null);
                outHeaderMap.put(mapItemCount++, String.valueOf(origHeaderLineIndices.get(outputColumns.get(i))));
            }
        }
        return outHeaderMap;
    }

    /**
     * Determines if an entry is located in the given config string
     * 
     * @param String
     *            data value
     * @param String
     *            targetPivotValues eg from config/properties file
     * @param String
     *            delimiter eg from config/properties file
     * @return
     */
    protected boolean isTokenWithinString(String targetValue, List<String> searchValues) {
        boolean isValueInString = false;
        for (String nextToken : searchValues) {
            if (isTokenWithinString(targetValue, nextToken))
                isValueInString = true;
        }
        return isValueInString;
    }

    protected boolean isTokenWithinString(String targetValue, String searchValue) {
        return searchValue.trim().equals(targetValue);
    }

    protected HashMap<String, String[]> mapPivotValuesToRows(List<String> pivotValues, ArrayList<String[]> rows) {
        HashMap<String, String[]> pivotValueToRowTokens = new HashMap<String, String[]>();
        // initialize Hashmap to null values
        for (String nextPivot : pivotValues) {
            pivotValueToRowTokens.put(nextPivot.trim(), null);
        }
        // Put the correct row in the Hashmap at the corresponding PivotValue
        for (String[] nextRow : rows) {
            for (String nextKey : pivotValueToRowTokens.keySet()) {
                if (isTokenWithinString(nextKey.trim(), Arrays.asList(nextRow))) {
                    pivotValueToRowTokens.put(nextKey.trim(), nextRow);
                }
            }
        }
        return pivotValueToRowTokens;
    }

    private boolean rowsDataVariesAtIndex(ArrayList<String[]> sameRowsStrings, int index) {
        boolean valuesDiffer = false;
        String prevVal = "";
        String curVal = "";
        for (int i = 0; i < sameRowsStrings.size(); i++) {
            if (i == 0) {
                // get the value located in the sameRowsString corresponding to
                // outColumn index
                prevVal = sameRowsStrings.get(i)[index];
            } else {
                curVal = sameRowsStrings.get(i)[index];
                if (!curVal.equals(prevVal)) {
                    valuesDiffer = true;
                }
                prevVal = curVal;
            }
        }
        return valuesDiffer;
    }

    public String getInputFileDelimiter() {
        return inputFileDelimiter;
    }

    public void setInputFileDelimiter(String inputFileDelimiter) {
        this.inputFileDelimiter = inputFileDelimiter;
    }

    public String getOutputFileDelimiter() {
        return outputFileDelimiter;
    }

    public void setOutputFileDelimiter(String outputFileDelimiter) {
        this.outputFileDelimiter = outputFileDelimiter;
    }

    public File getDropDir() {
        return dropDir;
    }

    public void setDropDir(File dropDir) {
        this.dropDir = dropDir;
    }

    public File getArchiveDir() {
        return archiveDir;
    }

    public void setArchiveDir(File archiveDir) {
        this.archiveDir = archiveDir;
    }

    public File getErrorDir() {
        return errorDir;
    }

    public void setErrorDir(File errorDir) {
        this.errorDir = errorDir;
    }

    public File getStagingDir() {
        return stagingDir;
    }

    public void setStagingDir(File stagingDir) {
        this.stagingDir = stagingDir;
    }

    public List<String> getKeyColumns() {
        return keyColumns;
    }

    public void setKeyColumns(List<String> keyColumns) {
        this.keyColumns = keyColumns;
    }

    public List<String> getInputColumns() {
        return inputColumns;
    }

    public void setInputColumns(List<String> inputColumns) {
        this.inputColumns = inputColumns;
    }

    public String getPivotColumn() {
        return pivotColumn;
    }

    public void setPivotColumn(String pivotColumn) {
        this.pivotColumn = pivotColumn;
    }

    public List<String> getTargetPivotValues() {
        return targetPivotValues;
    }

    public void setTargetPivotValues(List<String> targetPivotValues) {
        this.targetPivotValues = targetPivotValues;
    }

    public List<String> getColumnsAssociatedWithPivot() {
        return columnsAssociatedWithPivot;
    }

    public void setColumnsAssociatedWithPivot(List<String> columnsAssociatedWithPivot) {
        this.columnsAssociatedWithPivot = columnsAssociatedWithPivot;
    }

    public List<String> getOutputColumns() {
        return outputColumns;
    }

    public void setOutputColumns(List<String> outputColumns) {
        this.outputColumns = outputColumns;
    }

    public ArrayList<Integer> getKeyColumnIndices() {
        return keyColumnIndices;
    }

    public void setKeyColumnIndices(ArrayList<Integer> keyColumnIndices) {
        this.keyColumnIndices = keyColumnIndices;
    }

    public ArrayList<Integer> getPivotColumnIndices() {
        return pivotColumnIndices;
    }

    public void setPivotColumnIndices(ArrayList<Integer> pivotColumnIndices) {
        this.pivotColumnIndices = pivotColumnIndices;
    }

    public String[] getOutputTokens() {
        return outputTokens;
    }

    public void setOutputTokens(String[] outputTokens) {
        this.outputTokens = outputTokens;
    }

    public String[] getComments() {
        return comments;
    }

    public void setComments(String[] comments) {
        this.comments = comments;
    }

    public void setLinesToSkip(int linesToSkip) {
        this.linesToSkip = linesToSkip;
    }

    @Override
    public void writeHeader(Writer writer) throws IOException {
        writer.write(outputHeader);
    }

}