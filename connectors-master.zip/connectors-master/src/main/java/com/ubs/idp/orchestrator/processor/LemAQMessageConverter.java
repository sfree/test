package com.ubs.idp.orchestrator.processor;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import oracle.jms.AQjmsTextMessage;

import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.messaging.converter.MessageConversionException;

/**
 * MessageConverter class to covert oracle AQ message into 
 * a format that IDP can process
 * @author rochesi
 *
 */
public class LemAQMessageConverter implements MessageConverter {
	
	private String correlationMessage = "";
	private String issuerId = "";
	private String issuerMessage = "";
	private static final String ISSUER = "ISSUER";
	private static final String jsonInputParam = "idValue";;
	
	
	/**
	 * Extract the attributes we are interested in from the message
	 * TODO - define attributes in metadata
	 * @param message
	 * @return
	 */
	private String extractStringMessage(AQjmsTextMessage message){
		
		try {
			
			correlationMessage =  message.getJMSCorrelationID();
			
			if(correlationMessage.contains(ISSUER)){
				
				issuerId = correlationMessage.replaceAll(ISSUER, "");
			
				issuerMessage = "{" + "\"" + jsonInputParam + "\":\"" + issuerId + "\"}";
			}
			
		} catch (JMSException e) {
			
			e.printStackTrace();
		}
		
		return issuerMessage;
	}

	/**
	 * convert from a JMS message
	 */
	@Override
	public Object fromMessage(javax.jms.Message message)
			throws JMSException,
			org.springframework.jms.support.converter.MessageConversionException {
		
		if(message instanceof AQjmsTextMessage){
			
			return extractStringMessage((AQjmsTextMessage)message); 
		
		}else {

			throw new MessageConversionException("Cannot convert JMS message [" + message + "] to object", new Throwable());
		}

	}

	/**
	 * convert to a JMS message
	 */
	@Override
	public javax.jms.Message toMessage(Object obj, Session session)
			throws JMSException,
			org.springframework.jms.support.converter.MessageConversionException {
		
		Message message = session.createTextMessage(issuerMessage);
		
		return message;
	}
	
}
