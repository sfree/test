package com.ubs.idp.orchestrator.processor.rules;

import org.springframework.batch.item.ItemProcessor;

public class RuleToUpperCase implements ItemProcessor<String, String> {
    @Override
    public String process(String item) throws Exception {
        return item.toUpperCase();
    }
}
