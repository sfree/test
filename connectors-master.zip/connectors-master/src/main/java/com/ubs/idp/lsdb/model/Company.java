package com.ubs.idp.lsdb.model;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * JiBX POJO
 * 
 * @author mcnamars
 */
public class Company {

    private static final Logger LOGGER = LoggerFactory.getLogger(Company.class);
    private static final String REGISTERED_NAME_TYPE = "1";
    private static final String GCRS_SHORTNAME_TYPE = "6";

    private String id;
    private List<Name> nameList;
    private GCRS gcrs;
    private General general;
    private List<Holding> holdings;

    // need to sort this. % is on the child
    // but parent could have multiple % of child companies
    // dot notation causing a headache - should really pass company id
    // to ensure correct value returned
    private Float percentageHolding = 0f; // If parent
    
    // Derived data
    private List<Company> children;
    private List<Company> parents;
    private List<Company> legalParents;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public GCRS getGcrs() {
        return gcrs;
    }

    public void setGcrs(GCRS gcrs) {
        this.gcrs = gcrs;
    }

    public List<Name> getNameList() {
        return nameList;
    }

    public void setNameList(List<Name> nameList) {
        this.nameList = nameList;
    }

    public General getGeneral() {
        return general;
    }

    public void setGeneral(General general) {
        this.general = general;
    }

    public List<Holding> getHoldings() {
        return holdings;
    }

    public void setHoldings(List<Holding> holdings) {
        this.holdings = holdings;
    }

    public List<Company> getParents() {
        return parents;
    }
    
    public String getSubCategoryCode() {
        String subCategoryCode = null;
        
        if (general != null &&
            general.getEntityType() != null) {
            subCategoryCode = general.getEntityType().getSubCategoryCode();
        }
        
        return subCategoryCode;
    }

    public void setParents(List<Company> parents) {
        if (parents != null && parents.isEmpty()) {
            this.parents = null;
        } else {
            this.parents = parents;
        }
    }

    public List<Company> getLegalParents() {
        return legalParents;
    }

    public void setLegalParents(List<Company> legalParents) {
        if (legalParents != null && legalParents.isEmpty()) {
            this.legalParents = null;
        } else {
            this.legalParents = legalParents;
        }
    }

    public Float getPercentageHolding(String childId) {
        if (children == null || children.isEmpty()) {
            return 0f;
        }
        
        for (Company child : children) {
            if (child.getId().equals(childId)) {
                return getPercentageHoldingFromChild(child);
            }
        }
        return percentageHolding;
    }

    private Float getPercentageHoldingFromChild(Company child) {
        for (Holding holding : child.getHoldings()) {
            if (holding.getId().equals(this.id)) {
                return holding.getPercentage();
            }
        }
        return 0f;
    }

    public boolean getMultiParent() {
        List<Company> parents = getParents();
        return parents != null && parents.size() > 1;
    }

    public String getGcrsShortName() {
        String res = "";
        // TODO: Review with Syed
        for (Name name : nameList) {
            if (name.getTypeId().equals(GCRS_SHORTNAME_TYPE)) {
                res = name.getContent();
            }
        }
        return res;
    }

    public String getRegisteredName() {
        String res = "";
        // TODO: Review with Syed
        for (Name name : nameList) {
            if (name.getTypeId().equals(REGISTERED_NAME_TYPE)) {
                res = name.getContent();
            }
        }
        return res;
    }
    
    public void addChildCompany(Company child) {
        LOGGER.debug("adding child company id: {} to id: {}", child.getId(), this.id);
        if (children == null) {
            children = new ArrayList<Company>();
        }
        children.add(child);
    }
}