package com.ubs.idp.orchestrator.util;

public enum MfLocation {

    STAMFORD("MFNYK"), LONDON("MFLDN"), SINGAPORE("MFSNG");

    private String code;

    MfLocation(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
