package com.ubs.idp.connectors.spring.batch.writers;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.sql.Timestamp;

import org.springframework.batch.item.ItemWriter;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.PreparedStatement;

import org.springframework.beans.factory.InitializingBean;

public class AccountEventResultSetWriter extends BaseCassandraItemWriter implements ItemWriter<List<AccountEventResultSetWriter.AccountEventResultSets>>, InitializingBean {

    public static final String EVENT_MF_HOST = "MF_HOST";
    public static final String EVENT_ID = "ID";
    public static final String EVENT_NEVENT_ID = "NEVENTID";
    public static final String EVENT_ACCOUNT_ID = "ACCOUNT_ID";
    public static final String EVENT_ACCOUNT_CODE = "ACCOUNT_CODE";
    public static final String EVENT_DOWNSTREAM_SP_ID = "DOWNSTREAM_SP_ID";
    public static final String EVENT_RETRY_COUNT = "RETRYCOUNT";

    private String query;

    @Override
    public void write(List<? extends List<AccountEventResultSets>> lists) throws Exception {

        int recordNo=1;
        int resultSetNo=0;
        String previous_key= null;
        String current_key = null;
        if(lists.isEmpty()){
     	   return;
         }
        List<AccountEventResultSets> mfEventDataList = lists.get(0);
        PreparedStatement prepareStatement;
        BatchStatement batchStatement = new BatchStatement();
        for (AccountEventResultSets accountEventResultSets : mfEventDataList) {
            Iterator<Map.Entry<String,Map<String,String>>> entryIterator = accountEventResultSets.getResultSets().entrySet().iterator();
            while (entryIterator.hasNext()) {
                prepareStatement = proxy.getPrepareStatement(query);
                Map.Entry<String, Map<String, String>> mapEntry = entryIterator.next();
                current_key=mapEntry.getKey();
                if (resultSetNo == 0){
                    previous_key=mapEntry.getKey();
                    resultSetNo=1;
                }else if (current_key.equalsIgnoreCase(previous_key)){
                    recordNo++;
                }else {
                    resultSetNo++;
                    recordNo=1;
                }
                batchStatement.add(prepareStatement.bind(
                        accountEventResultSets.getMappedEvent().get(EVENT_ID),
                        accountEventResultSets.getMappedEvent().get(EVENT_NEVENT_ID),
                        String.valueOf(accountEventResultSets.getMappedEvent().get(EVENT_ACCOUNT_ID)),
                        String.valueOf(accountEventResultSets.getMappedEvent().get(EVENT_ACCOUNT_CODE)),
                        String.valueOf(accountEventResultSets.getMappedEvent().get(EVENT_DOWNSTREAM_SP_ID)),
                        mapEntry.getKey(),
                        getResultId(resultSetNo,recordNo),
                        resultSetNo,
                        recordNo,
                        mapEntry.getValue(),
                        new Timestamp(System.currentTimeMillis())
                ));
                previous_key=mapEntry.getKey();
            }

        }
        proxy.executeStatement(batchStatement);
    }

    private String getResultId(int i, int j) {
        return "R"+i+"-"+j;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public static class AccountEventResultSets {

        private Map<String, Object> mappedEvent;
        private Map<Integer,Map<Integer,Map<String,String>>> resultSetsMap;
        private Map<Integer,Map<Integer,Map<String,String>>> transformedResultSetsMap;
        private Map<Integer,String> uniqueResultsetType;
        private Map<String, Map<String, String>> resultSets;

        public Map<Integer, String> getUniqueResultsetType() {
            return uniqueResultsetType;
        }

        public void setUniqueResultsetType(Map<Integer, String> uniqueResultsetType) {
            this.uniqueResultsetType = uniqueResultsetType;
        }

        public Map<Integer, Map<Integer, Map<String, String>>> getResultSetsMap() {
            return resultSetsMap;
        }

        public void setResultSetsMap(
                Map<Integer, Map<Integer, Map<String, String>>> resultSetsMap) {
            this.resultSetsMap = resultSetsMap;
        }

        public Map<Integer, Map<Integer, Map<String, String>>> getTransformedResultSetsMap() {
            return transformedResultSetsMap;
        }

        public void setTransformedResultSetsMap(Map<Integer, Map<Integer, Map<String, String>>> transformedResultSetsMap) {
            this.transformedResultSetsMap = transformedResultSetsMap;
        }

        public Map<String, Object> getMappedEvent() {
            return mappedEvent;
        }

        public void setMappedEvent(Map<String, Object> mappedEvent) {
            this.mappedEvent = mappedEvent;
        }

        public Map<String, Map<String, String>> getResultSets() {
            return resultSets;
        }

        public void setResultSets(Map<String, Map<String, String>> resultSets) {
            this.resultSets = resultSets;
        }
    }

    public void afterPropertiesSet() throws Exception {
        super.afterPropertiesSet();
    }
}
