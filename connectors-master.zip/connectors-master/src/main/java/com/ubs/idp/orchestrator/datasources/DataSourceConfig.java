package com.ubs.idp.orchestrator.datasources;

import com.ubs.idp.encrypt.Crypto;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.model.JDBCChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import java.sql.Driver;

/**
 * <p>Datasource wrapper to support:</p>
 * <ul>
 *   <li>Package scanned injection of a Spring framework SimpleDriverDataSource with id "feedDataSource"</li>
 *   <li>Driver JARs in xd/modules/job/jobname/lib dir</li>
 *   <li>Driver class names rather than Class</li>
 * </ul>
 * <p>Job properties file should contain corresponding entries for XD module properties:</p>
 * <pre>
 * #
 * # Module options
 * #
 * options.srcDataset.type=String
 * options.srcDataset.description=Source dataset e.g.: AccountsAndRXM.MF
 *
 * </pre>
 * @author mcminnp
 */
@Configuration("dataSourceConfig")
@PropertySource({"classpath:application.properties", "classpath:environment-${environment}.properties"})
public class DataSourceConfig {
	
	private static Logger logger = LoggerFactory.getLogger(DataSourceConfig.class);
    
	@Autowired
	@Qualifier("mdsClient")
	MetadataService mds;
	
    @Value("${srcDataset:}")
    private String srcDataset;

    @Value("${idpDataset:}")
    private String idpDataset;
    
    @Bean(name = {"feedDataSource"})
    public SimpleDriverDataSource simpleDriverDataSource() throws ClassNotFoundException {
      
        SimpleDriverDataSource bean = new SimpleDriverDataSource();
        
        logger.info("Fetching database connection details from Metadata for Datasource with ID=" + srcDataset);
        
        JDBCChannel jdbcChannel = mds.getDatabaseDetailsForDataset(srcDataset);
        logger.debug("Fetched database connection details URL=" + jdbcChannel.url);

        bean.setDriverClass((Class<? extends Driver>) Class.forName(jdbcChannel.driverClass));
        bean.setUrl(jdbcChannel.url);
        bean.setUsername(jdbcChannel.username);
        // Passwords from MDS will be encrypted
        bean.setPassword(Crypto.decrypt(jdbcChannel.password));
        
        return bean;
    }
}