package com.ubs.idp.orchestrator.processor.rules.drm;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;

public class DRMRxmCodeRule implements ItemProcessor<Map<String, Object>, Map<String, Object>> {

    private final Cache<String, String> rxmCache = CacheBuilder.newBuilder().maximumSize(100)
            .expireAfterWrite(60, TimeUnit.MINUTES).build();

    private static final String LEM_ID_TO_CCONSOL_REVERSE_INDEX = "AccountsAndRXM_8";

    private static final String ISSUER_ID_ATTRIBUTE_NAME = "ISSUER_ID";

    private static final int RXM_CODE_INDEX = 4;

    private static final String RXM_ATTRIBUTE_NAME = "RXM";

    @Autowired
    private CassandraSessionHelper cassandraSessionHelper;

    private CassandraCqlProxy proxy;

    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        String issuerId = (String) item.get(ISSUER_ID_ATTRIBUTE_NAME);
        String rxmCode = rxmCache.getIfPresent(issuerId);
        if (rxmCode == null) {
            String cconsol = queryForCconsol(issuerId);
            if (!StringUtils.isEmpty(cconsol)) {
                rxmCode = queryForRxmCode(cconsol);
                if (!StringUtils.isEmpty(rxmCode)) {
                    rxmCache.put(issuerId, rxmCode);
                }
            }
        }
        item.put(RXM_ATTRIBUTE_NAME, StringUtils.trimToEmpty(rxmCode));
        return item;
    }

    private String queryForRxmCode(String cconsol) {
        PreparedStatement preparedStmt = proxy
                .getPrepareStatement("SELECT value FROM \"AccountsAndRXM\" WHERE key = ? LIMIT 1;");
        BoundStatement boundStmt = preparedStmt.bind(cconsol);
        ResultSet rs = proxy.executeStatement(boundStmt);
        String data = null;
        for (Row row : rs) {
            data = row.getString(0);
        }

        if (!StringUtils.isEmpty(data)) {
            String[] attributes = data.split("\t", RXM_CODE_INDEX + 2);
            if (attributes.length > RXM_CODE_INDEX) {
                return attributes[RXM_CODE_INDEX];
            }
        }
        return "";
    }

    private String queryForCconsol(String issuerId) {
        PreparedStatement preparedStmt = proxy.getPrepareStatement(String.format(
                "SELECT column1 FROM \"%s\" WHERE key = ? LIMIT 1;",
                LEM_ID_TO_CCONSOL_REVERSE_INDEX));
        BoundStatement boundStmt = preparedStmt.bind(issuerId);
        ResultSet rs = proxy.executeStatement(boundStmt);
        for (Row row : rs) {
            return row.getString(0);
        }
        return null;
    }

    @PostConstruct
    public void init() {
        proxy = cassandraSessionHelper.getProxy();
    }

}
