package com.ubs.idp.connectors.spring.batch.readers;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.ubs.idp.connectors.BaseConnector;

/**
 *  Jdbc named parameter source reader
 *
 *  Provides the chunk reading of source with named sql parameter also supports sql 'IN' clause
 *
 *  1) JdbcCursorItemReader uses java.sql.PreparedStatement which does not support named parameters and IN clause
 *  2) There is no way to get ResultSet to chunk read while working with XxxJdbcTemplates, so chunk reading is on Lists<Object>
 *
 *
 */
public class JdbcNamedParameterSourceReader<T> extends BaseConnector implements ItemReader<T>, ItemStream, InitializingBean {

    private DataSource dataSource;
    private RowMapper rowMapper;
    private String querySql;
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private Map<String, Object> parameters;
    private Iterator<T> iterator;

    private long rowCount = 0;

    final static Logger LOGGER = LoggerFactory.getLogger(JdbcNamedParameterSourceReader.class);

    /**
     * Called from Spring to bootstrap the reader
     * @throws Exception
     */
    public void init() throws Exception{
        if (dataSource != null) {
            namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
        }
    }

    @Override
    public T read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {

        if (iterator != null && iterator.hasNext()) {
            T nextItem = iterator.next();
            if (nextItem != null) {
                rowCount++;
            }
            return nextItem;
        }
        return null;
    }

    @Override
	public void open(ExecutionContext executionContext)
			throws ItemStreamException {
		LOGGER.debug("Executing the query {} with parameters {}", querySql, parameters);
		List list = namedParameterJdbcTemplate.query(querySql, parameters, rowMapper);
		iterator = list.iterator();
	}

    @Override
    public void update(ExecutionContext executionContext) throws ItemStreamException {
    }

    @Override
    public void close() throws ItemStreamException {
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public void setRowMapper(RowMapper rowMapper) {
        this.rowMapper = rowMapper;
    }

    public void setQuerySql(String querySql) {
        this.querySql = querySql;
    }

    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }

    public long getRowCount() {
        return rowCount;
    }
    
    public void setNamedParameterJdbcTemplate (NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
    	this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
