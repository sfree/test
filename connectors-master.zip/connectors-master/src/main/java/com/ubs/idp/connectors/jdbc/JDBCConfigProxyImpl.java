/**
 * 
 */
package com.ubs.idp.connectors.jdbc;

import static org.springframework.util.StringUtils.isEmpty;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.stereotype.Component;

/**
 * @author sureshkp
 *
 */
@Component("jdbcProxy")
public class JDBCConfigProxyImpl implements JDBCProxy, InitializingBean {

	private static Logger logger = LoggerFactory.getLogger(JDBCConfigProxyImpl.class);
	@Autowired
	@Qualifier("jdbcConfig")
	private JDBCConfig jdbcConfig;

	private final static String DATA_TYPE_STRING= "STRING";
	private final static String DATA_TYPE_INT= "INT";
	private final static String DATA_TYPE_LONG= "LONG";
	private final static String DATA_TYPE_BIGDECIMAL= "BIGDECIMAL";
	private SimpleDriverDataSource bean;

	@Override
	public void afterPropertiesSet() throws Exception {
		getDataSource();
	}

	/**
	 * This method is used to create a connection  
	 * for JDBC source.
	 * 
	 * @return SimpleDriverDataSource
	 */
	@Override
	public SimpleDriverDataSource getDataSource() throws ClassNotFoundException {

		bean = new SimpleDriverDataSource();
		logger.info("Fetching database connection details.");
		
		if (!isEmpty(jdbcConfig.getJdbcDriver())){
			bean.setDriverClass((Class<? extends Driver>) Class.forName(jdbcConfig.getJdbcDriver()));
			
		} else{
			logger.debug("Driver Class for JDBC Source is blank.");
		}
		if (!isEmpty(jdbcConfig.getJdbcUrl())){			
			bean.setUrl(jdbcConfig.getJdbcUrl());
		} else{
			logger.debug("URL for JDBC Source is blank.");
		}
		if (!isEmpty(jdbcConfig.getJdbcUser())){
			bean.setUsername(jdbcConfig.getJdbcUser());			
		} else{
			logger.debug("UserId for JDBC Source is blank.");
		}
		bean.setPassword(jdbcConfig.getDecryptedJDBCPassword());
		return bean;
	}

	/**This  method returns the status of Connection to jdbc database  
	 * 
	 * @return - Returns the value of status
	 */
	
	public boolean isConnected(){
		boolean success= false;
		try ( Connection conn = bean.getConnection();){
			if (conn !=null){
				success= true;
			}else{
				success= false;
			}
		}catch (SQLException se){
			//TODO: Should we catch and log ... or re-throw?
			logger.error("Failed to connect to Jdbc source?", se);			
		}
		return success;
	}



	/**This  is a generic method to execute select statements  
	 * @param sqlStatement - A valid SQL statement
	 * @param dataType - Ordered list of data type for dynamic arguments
	 * @param data- HashMap <Integer,String> where key maps to argument position in SQL and value is the actual argument
	 * @return - List of rows with name and value (column and column value) in map
	 */
	
	public  List<Map<String, Object>> executeSelect(String sqlStatement, List<String> dataType, Map<Integer, String> data)throws SQLException {
		PreparedStatement pstmt = null;
		Connection conn =null;
		ResultSet rs = null;
        List<Map<String, Object>> rows = new ArrayList<>();        
        try  {
            conn = bean.getConnection();
            pstmt= conn.prepareStatement(sqlStatement);
            pstmt = sqlQueryBuilder (pstmt,dataType,data);
            rs =pstmt.executeQuery();
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            if (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.put(metaData.getColumnName(i), rs.getObject(i));
                }
                rows.add(row);
            }
		}catch (SQLException se){
			//TODO: Should we catch and log ... or re-throw?
			logger.error("Failed to connect to jdbc?", se);			
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return rows;
	}

	/**This  is a generic method to execute DML (Insert/Update) statements  
	 * @param sqlStatement - A valid SQL statement
	 * @param dataType - Ordered list of data type for dynamic arguments
	 * @param data- HashMap <Integer,String> where key maps to argument position in SQL and value is the actual argument
	 * @return - returns the operation status as boolean value.
	 */
	
	public boolean executeDML(String sqlStatement, List<String> dataType, Map<Integer, String> data)throws SQLException {

		Connection conn =null;
		PreparedStatement pstmt = null;
		boolean success= false;
		try  {
			conn = bean.getConnection();
			pstmt= conn.prepareStatement(sqlStatement);
			logger.info("JDBC proxy executing sql:"+sqlStatement);
			pstmt = sqlQueryBuilder(pstmt,dataType,data);
			if (pstmt != null) {				
				if (pstmt.executeUpdate()>0){
					success = true;
				}else {
					success = false;
				}
			}
		}catch (SQLException se){
			//TODO: Should we catch and log ... or re-throw?
			logger.error("Failed to connect to jdbc?", se);			
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}

		return success;
	}
	
	/**This  is a generic method to build dynamic SQL Query  
	 * @param pstmt - A valid SQL statement
	 * @param dataType - Ordered list of data type for dynamic arguments
	 * @param data- HashMap <Integer,String> where key maps to argument position in SQL and value is the actual argument
	 * @return - returns the modified PreapredStatement
	 */
	public PreparedStatement sqlQueryBuilder (PreparedStatement pstmt, List<String> dataType, Map<Integer, String> data){
		if (pstmt != null) {
			try{
				int key =1;				
				for (String formatType : dataType) {
					logger.debug("DATA type:"+dataType);
					logger.debug("DATA value:"+data.get(key).toString());
					switch (formatType) {
					case DATA_TYPE_STRING:
						pstmt.setString(key, data.get(key).toString());
						key++;
						break;
					case DATA_TYPE_INT: 
						pstmt.setInt(key, Integer.parseInt(data.get(key)));
						key++;
						break;
					case DATA_TYPE_LONG: 
						pstmt.setLong(key, Long.parseLong(data.get(key)));
						key++;
						break;
					case DATA_TYPE_BIGDECIMAL: 
						pstmt.setBigDecimal(key, new BigDecimal(data.get(key)));
						key++;
						break;
					default: 	
						break;
					}
				}
			}catch (SQLException se) {
				//TODO: Should we catch and log ... or re-throw?
				logger.error("Failed to connect to jdbc?", se);			
			}
		}
		return pstmt;
	}
	
	public JDBCConfig getJdbcConfig() {
		return jdbcConfig;
	}
	
	public void setJdbcConfig(JDBCConfig jdbcConfig) {
		this.jdbcConfig = jdbcConfig;
	}
	
	public void setBean(SimpleDriverDataSource bean) {
		this.bean = bean;
	}
}
