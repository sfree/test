package com.ubs.idp.orchestrator.processor.rules;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ubs.idp.domainRegistry.DomainRegistry;

/**
 * Temporary Rule for Ultrabond to get us up and running. Sets the issue.ubsId
 *  and tL.countryUbsId from DomainRegistry
 *
 * @author aigalsa
 */
@Component
public class MTSRule extends DerivationRuleTemplate implements ItemProcessor<Map<String,Object>,Map<String,Object>>
{

    public final static List<String> FIELDS_TO_SET = Arrays.asList("issue.ubsId");

    @Autowired
    @Qualifier("domainRegistry")
    DomainRegistry domainRegistry;

    @Override
    public Map<String, Object> applyRules(Map<String, Object> inputFields)
    {
        Map<String,Object> derivedFields = new HashMap<String,Object>();
        String key = inputFields.get("issue.cusip") + "_" + inputFields.get("issue.nominalCurrency");
        derivedFields.put("KEY", key);
        derivedFields.put("issue.ubsId", domainRegistry.createDomainKey("Instrument", key).getDomainKey());

        // create two more country fields and assign them the same value as issuer.countryOfRisk
		String country = (String)inputFields.get("issuer.countryOfRisk");
		derivedFields.put("issuer.countryOfDomicile", country);
		derivedFields.put("issuer.countryOfIncorporation", country);

		// hardcode MTS derivation
        derivedFields.put(DERIVED_ASSET_CLASS, "Fixed Income");
		derivedFields.put(DERIVED_ASSET_TYPE, "MBS");
		derivedFields.put("derived.issueFactor", "100");
	
		String issuerName = (String)inputFields.get("issuer.issuerName");
		derivedFields.put(DERIVED_SECFUNDING_ISSUERNAME, issuerName);

        return derivedFields;
    }

    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        return derive(item);
    }
}


