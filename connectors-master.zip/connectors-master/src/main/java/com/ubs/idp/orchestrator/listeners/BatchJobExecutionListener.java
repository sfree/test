package com.ubs.idp.orchestrator.listeners;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

import com.ubs.idp.orchestrator.util.FileActionHandler;

/**
 * Add job details to execution context for use in SpEL late binding etc.
 * Includes support for exit status-dependent file handling.
 * @author mcminnp
 */
public class BatchJobExecutionListener implements JobExecutionListener {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private Map<String, FileActionHandler> fileHandlers = null;

    @Override
    public void afterJob(JobExecution jobExecution) {
    	
    	// Optional file handlers on job completion
    	
    	if (fileHandlers != null) {
    		String jobStatus = jobExecution.getExitStatus().getExitCode();
    		
    		logger.debug("Check for file handler for exit status {}...", jobStatus);
    		
    		if (fileHandlers.containsKey(jobStatus)) {
    			logger.debug("Invoke handler...");
    			
    			FileActionHandler fileHandler = fileHandlers.get(jobStatus);
    			
    			try {
					fileHandler.processFile();
					
					logger.debug("Handler processing complete");
				} catch (IOException e) {
					logger.error("Failed to process file?", e);
				}
    		}
    	}
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        Date now = new Date();
        DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
        
        long jobId = jobExecution.getJobId();
        
        logger.debug("Set up context variables for job ID {}...", jobId);
        
        // Add 'fileName' job parameter in addition to 'absoluteFilePath'
        String absoluteFilePath = jobExecution.getJobParameters().getString("absoluteFilePath");

        if (absoluteFilePath !=null)
        {
        	File file = new File(absoluteFilePath);
        	if (file.exists()) {
	            logger.debug("Set up context variable fileName='{}' for job ID {}...", file.getName(), jobId);
	            jobExecution.getExecutionContext().put("fileName", file.getName());
        	}
        }
        
        String timestamp = df.format(now);
        
        logger.debug("Set up context variable jobId='{}' for job ID {}...", jobId, jobId);
        jobExecution.getExecutionContext().put("jobId" ,jobId);

        logger.debug("Set up context variable timestamp='{}' for job ID {}...", timestamp, jobId);
        jobExecution.getExecutionContext().put("timestamp", timestamp);
    }

	public Map<String, FileActionHandler> getFileHandlers() {
		return fileHandlers;
	}

	public void setFileHandlers(Map<String, FileActionHandler> fileHandlers) {
		this.fileHandlers = fileHandlers;
	}
}
