package com.ubs.idp.lsdb.model;

/**
 * JiBX POJO
 * @author mcnamars
 */
public class GCRS {

	private String gcrsCode;
	private String fcrsCode;
	
	public String getGcrsCode() {
		return gcrsCode;
	}
	
	public void setGcrsCode(String gcrsCode) {
		this.gcrsCode = gcrsCode;
	}
	
	public String getFcrsCode() {
		return fcrsCode;
	}
	
	public void setFcrsCode(String fcrsCode) {
		this.fcrsCode = fcrsCode;
	}
}
