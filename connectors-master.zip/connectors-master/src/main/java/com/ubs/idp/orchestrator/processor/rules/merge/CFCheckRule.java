package com.ubs.idp.orchestrator.processor.rules.merge;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;
import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;

/**
 * Generic lookup "rule" to correlate input rows against a 2nd  column family in Cassandra
 */
@Component
public class CFCheckRule extends DerivationRuleTemplate implements ItemProcessor<Map<String,Object>,Map<String,Object>>, InitializingBean {
    private final Logger logger = LoggerFactory.getLogger(CFCheckRule.class);

    private CassandraCqlProxy proxy;

    @Autowired
    private CFCheckRuleConfiguration config;

    @Autowired
    private CassandraSessionHelper cassandraSessionHelper;

    private String srcField;
    private String lookupField;

    private int joinSrcIdx;
    private int joinLookupIdx;

    private Map<String, String[]> lookupData = null;
    
    private String[] derivedFieldSettingTrue;
    private String[] derivedFieldSettingFalse;
    
    private boolean initialised = false;
    
    public CFCheckRule() {
        logger.debug("Construct rule class");
    }

    @Override
    public Map<String, Object> process(Map<String, Object> item)
            throws Exception {
        return derive(item);
    }

    @Override
    public Map<String, Object> applyRules(Map<String, Object> inputFields) {
        
        if (!initialised) {
            init();
        }
        
        Map<String, Object> derived = new HashMap<>();
        boolean match = false;

        // Does row exist in lookup (based on join)

        String id = inputFields.get(srcField).toString();
        String[] lookupFields;

        if ((lookupFields = getLookupData(id)) != null) {
            if (config.getLookupCheckType().equals(CFCheckRuleConfiguration.CHECK_TYPE_EXISTS)) {
                derived.put(derivedFieldSettingTrue[0], derivedFieldSettingTrue[1]);
                match = true;
            }
        }
        
        if (!match) {
            derived.put(derivedFieldSettingFalse[0], derivedFieldSettingFalse[1]);
        }
        
        return derived;        
    }
    
    /**
     * Return matching lookup row or null
     * @param id
     * @return
     */
    private String[] getLookupData(String id) {
        String[] res = null;
        
        if (config.getPreload()) {
            if (lookupData.containsKey(id)) {
                res = lookupData.get(id);
            }
        } else {
            // TODO: Need to think about this one!
            throw new RuntimeException("Row-based lookup not yet implemented!");
        }
        
        return res;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        init();
    }
    
    private synchronized void init() {
        logger.debug("Initialise CFCheckRule - pre-load: {}", config.getPreload());

        initialised = true;

        // Get Cassandra session

        getSession();

        // Get join indexes

        findIndexes();
        

        // Conditionally cache lookup data
        
        if (config.getPreload()) {
            cacheLookupData();
        }
        
        // Set derived field assignment
        
        derivedFieldSettingTrue = config.getDerivedFieldSettingTrue().split("=");
        derivedFieldSettingFalse = config.getDerivedFieldSettingFalse().split("=");
    }

    /**
     * Get Cassandra session (CQL proxy)
     */
    private void getSession() {
        logger.debug("Cassandra session helper: {}", cassandraSessionHelper);

        proxy = cassandraSessionHelper.getProxy();

        logger.debug("Got Cassandra session: {}", proxy);
    }

    /**
     * Cache lookup data (not recommended for medium-large datasets) 
     */
    private void cacheLookupData() {   
        // Pre-load data as required

        logger.debug("Pre-load lookup data...");

        String cqlStatement = "select * from \"" + config.getLookupColumnFamily() + "\";";

        ResultSet resultSet = proxy.executeStatement(cqlStatement);

        logger.debug("Lookup returns {}", resultSet);

        int rowCount = 0;

        // Load and hash rows

        if (resultSet != null) {

            lookupData = new HashMap<>();

            Iterator<Row> rowIt = resultSet.iterator();

            while (rowIt.hasNext()) {
                Row row = rowIt.next();
                String value = row.getString("value");

                String[] fields = value.split(config.getLookupDataSeparator(), -1);

                if (fields.length != config.getLookupFieldNames().size()) {
                    throw new IllegalArgumentException("Field count mismatch on lookup? expected " + 
                            config.getLookupFieldNames().size() + " got " + fields.length);
                }

                if (config.getLookupCheckType().equals(CFCheckRuleConfiguration.CHECK_TYPE_EXISTS)) {
                    // If it's a simple "row exists join" - don't cache field data (save memory)
                    lookupData.put(fields[joinLookupIdx], new String[0]);
                } else {
                    lookupData.put(fields[joinLookupIdx], fields);
                }

                rowCount++;
            }
        } else {
            throw new IllegalArgumentException("Failed to load data for CF '" + config.getLookupColumnFamily() + "'?");
        }

        logger.debug("Processed {} rows", rowCount);
    }

    /**
     * Walk field sets to establish join field offsets and field indexes
     */
    private void findIndexes() {

        List<String> joinFields = config.getJoinFields();

        srcField = joinFields.get(0);
        lookupField = joinFields.get(1);

        // Find join field idx's

        joinSrcIdx = -1;
        joinLookupIdx = -1;
        int idx = 0;

        while(joinSrcIdx < 0 && idx < config.getSourceFieldNames().size()) {
            String fieldId = config.getSourceFieldNames().get(idx);

            if (fieldId.equals(srcField)) {
                joinSrcIdx = idx;
            }

            idx++;
        }

        if (joinSrcIdx < 0) {
            throw new IllegalArgumentException("Failed to find offset for field '" +
                    lookupField + "' in: " + config.getSourceFieldNames());
        }

        idx = 0;

        while(joinLookupIdx < 0 && idx < config.getLookupFieldNames().size()) {
            String fieldId = config.getLookupFieldNames().get(idx);

            if (fieldId.equals(lookupField)) {
                joinLookupIdx = idx;
            }

            idx++;
        }

        if (joinLookupIdx < 0) {
            throw new IllegalArgumentException("Failed to find offset for field '" +
                    lookupField + "' in: " + config.getLookupFieldNames());
        }

        logger.debug("Join source index: {}", joinSrcIdx);
        logger.debug("Join target index: {}", joinLookupIdx);
    }
}
