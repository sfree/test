package com.ubs.idp.orchestrator.util;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.PreparedStatement;
import com.ubs.idp.base.IdpBoundary;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;
import com.ubs.idp.connectors.jdbc.JDBCConfigProxyImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@IdpBoundary
@Service
public class AccountEventJdbcStatusUpdateUtil {

    private static final String STRING_TYPE_IDENTIFIER = "STRING";
    private static final String INTEGER_TYPE_IDENTIFIER = "INT";
    private static final String BIGDECIMAL_TYPE_IDENTIFIER = "BIGDECIMAL";
    private final static String UPDATE_STATUS="idp_mf_events_updatestatus_sql";
    private final static String UPDATE_RETRYCOUNT="idp_mf_events_updateretrycount_sql";
    private final static String UPDATE_ERROR="idp_mf_events_updaeterror_sql";
    private final static String ROLLBACK_CASSANDRA_IDPID_SQL="rollback_cassandra_idpid_sql";
    private final static String ROLLBACK_EVENT_XML_IDPID_SQL="rollback_event_xml_idpid_sql";
    private final static String ROLLBACK_CASSANDRA_IDPID_SQL_LOA4="rollback_cassandra_idpid_sql_loa4";
    private final static String ROLLBACK_EVENT_XML_IDPID_SQL_LOA4="rollback_event_xml_idpid_sql_loa4";

    private static final Logger logger = LoggerFactory.getLogger(AccountEventJdbcStatusUpdateUtil.class);

    @Autowired
    private JDBCConfigProxyImpl jdbcProxy;
    private CassandraSessionHelper cassandraSessionHelper;
    private Map<String, String> properties;
    private String updateTable;

    private MetaDataRetrieverUtil metaDataRetrieverUtil;

    public void updateStatus(String batchStepStatus, AccountEventStatus eventStatusToUpdate, Long id, String propagationCode, int retryCount,boolean isEventInValid,String errorMessage) {
       
        logger.info("Updating status for event id: {} with propagation code: {} with retry count: {}", id, propagationCode, retryCount);
        try {
            if (ExitStatus.COMPLETED.getExitCode().equals(batchStepStatus)) {
            	jdbcProxy.executeDML(properties.get(UPDATE_STATUS),
                        getTypeData(STRING_TYPE_IDENTIFIER, INTEGER_TYPE_IDENTIFIER),
                        getParameterData(eventStatusToUpdate.name(), id.toString()));
            }  else if (ExitStatus.FAILED.getExitCode().equals(batchStepStatus)) {
                if (isEventInValid) {
                    jdbcProxy.executeDML(properties.get(UPDATE_ERROR),
                            getTypeData(STRING_TYPE_IDENTIFIER,STRING_TYPE_IDENTIFIER, INTEGER_TYPE_IDENTIFIER),
                            getParameterData(eventStatusToUpdate.name(), errorMessage,id.toString()));
                } else {
                    jdbcProxy.executeDML(properties.get(UPDATE_RETRYCOUNT),
                            getTypeData(STRING_TYPE_IDENTIFIER,INTEGER_TYPE_IDENTIFIER,STRING_TYPE_IDENTIFIER, INTEGER_TYPE_IDENTIFIER),
                            getParameterData(eventStatusToUpdate.name(),String.valueOf(retryCount+1) ,errorMessage, id.toString()));
                }
            }
        } catch (SQLException sql) {
            throw new RuntimeException("Unable to update Status", sql);
        }
    }

    private Map<Integer, String> getParameterData(String... parameter) {
        HashMap parameters = new HashMap();
        for (int i = 0; i < parameter.length; i++) {
            parameters.put(i+1, parameter[i]);
        }
        return parameters;
    }

    private List<String> getTypeData(String... types) {
        return Arrays.asList(types);
    }

    public void setMetaDataRetrieverUtil(MetaDataRetrieverUtil metaDataRetrieverUtil) {
        this.metaDataRetrieverUtil = metaDataRetrieverUtil;
    }

    public void setUpdateTable(String updateTable) {
        this.updateTable = updateTable;
    }   
    
	public Map<String, String> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, String> properties) {
		this.properties = properties;
	}
	
	/**
	 * This function delete the outbound event xml from oracle DB as per  rollback strategy. 
	 * @param loaType 
	 */
	public void deleteJDBCXMLRecordForEventIdpID(Long id, long loaType){
		try {
			if(4==loaType){
				jdbcProxy.executeDML(properties.get(ROLLBACK_EVENT_XML_IDPID_SQL_LOA4),
				        getTypeData(BIGDECIMAL_TYPE_IDENTIFIER),
				        getParameterData(id.toString()));
			}else{
				jdbcProxy.executeDML(properties.get(ROLLBACK_EVENT_XML_IDPID_SQL),
				        getTypeData(BIGDECIMAL_TYPE_IDENTIFIER),
				        getParameterData(id.toString()));
			}
			
		} catch (SQLException e) {
			 throw new RuntimeException("Unable to ROLLBACK IDPID:"+id, e);
		}
	}
	
	/**
	 * This function delete the SP resultset  from Cassandra DB as per  rollback strategy. 
	 * @param loaType 
	 */
	public void deleteCassandraRSRecordsForEventIdpID(Long id, long loaType) {		
		BatchStatement batchStatement = new BatchStatement();
		logger.info("Rolling back Cassandra Record for IDPID : {}",id);
		PreparedStatement prepareStatement;
		if(4==loaType){
			 prepareStatement = cassandraSessionHelper.getProxy()
					.getPrepareStatement(properties.get(ROLLBACK_CASSANDRA_IDPID_SQL_LOA4));
		}else{
			 prepareStatement = cassandraSessionHelper.getProxy()
					.getPrepareStatement(properties.get(ROLLBACK_CASSANDRA_IDPID_SQL));
		}
		
		batchStatement.add(prepareStatement.bind(id));
		cassandraSessionHelper.getProxy().executeStatement(batchStatement);
	}

	public void setCassandraSessionHelper(
			CassandraSessionHelper cassandraSessionHelper) {
		this.cassandraSessionHelper = cassandraSessionHelper;
	}
	
	public int getMaxRetryCount(String propagationCode){
		 return  metaDataRetrieverUtil.getRetryCount(propagationCode);
	}
    
}
