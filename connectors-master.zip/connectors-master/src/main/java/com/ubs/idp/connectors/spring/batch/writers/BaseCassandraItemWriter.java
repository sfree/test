package com.ubs.idp.connectors.spring.batch.writers;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.StringUtils;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.ubs.idp.base.StaticValues;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;
import com.ubs.idp.connectors.spring.batch.exceptions.BadRowException;
import com.ubs.idp.connectors.spring.batch.utils.BaseCassandraComparator;

/**
 * Base class from which Cassandra item writers can be derived
 * @author mcminnp
 */
public abstract class BaseCassandraItemWriter implements InitializingBean {

    public static final String CASSANDRA_KEYS_SEPARATOR = "_";
    public static final String CASSANDRA_CF_SEPARATOR = "_";

    @Autowired
    @Qualifier("cassandraSessionHelper")
    private CassandraSessionHelper cassandraSessionHelper;
    
    protected CassandraCqlProxy proxy;

    protected String datasetName;
    protected long total = 0;
    protected Map<String, String> columnFamilyMap = new HashMap<String, String>();

    protected List<Integer> keyAttributePositions;
    protected List<String> attributeNames;
    protected List<Integer> queryableAttributePositions;

    protected String fieldSeparator = DelimitedLineTokenizer.DELIMITER_TAB;
    
    /**
     * The comparator used to compare whether an attribute in a record
     * determines that one record should replace an existing one as it
     * is deemed the latest version
     */
    protected BaseCassandraComparator latestRecordComparator;
    
    /**
     * Class of the comparator object. This can be set by the XD jobs
     * to instantiate the comparator object from the job options
     */
    private Class<BaseCassandraComparator> latestRecordComparatorClass;     
    /**
     * Flag to indicate that we are not looking at old data
     */
    protected boolean loadOnly = false;

    private Logger logger = LoggerFactory.getLogger(BaseCassandraItemWriter.class);

    /**
     * @param keyAttributePositions the keyAttributePositions to set
     */
    public void setKeyAttributePositions(List<Integer> keyAttributePositions) {
        this.keyAttributePositions = keyAttributePositions;
    }

    /**
     * @param attributeNames the attributeNames to set
     */
    public void setAttributeNames(List<String> attributeNames) {
        this.attributeNames = attributeNames;
        setAttributePositionMapInComparator();
    }

    /**
     * @param queryableAttributePositions the queryableAttributePositions to set
     */
    public void setQueryableAttributePositions(
            List<Integer> queryableAttributePositions) {
        this.queryableAttributePositions = queryableAttributePositions;
    }

    /**
     * @param datasetName the datasetName to set
     */
    public void setDatasetName(String datasetName) {
        this.datasetName = datasetName;
    }

    /**
     * Add column family as required.
     * @param columnFamilyName
     */
    protected void addColumnFamilyIfNeeded(String columnFamilyName) {
        
        if (logger.isDebugEnabled()) logger.debug("Add '{}' column family ...", columnFamilyName);

        if (columnFamilyMap.containsKey(columnFamilyName)) {
            return;
        }

        proxy.addColumnFamilyIfNeeded(columnFamilyName);

        // Remember for next call.
        columnFamilyMap.put(columnFamilyName, columnFamilyName);
    }

    /**
     * Ensure key chars are escaped (e.g.: single quotes)
     * @param input
     * @return
     */
    protected String escapeString(String input) {
        String value;

        if (input.indexOf("'") >= 0){
            value = input.replaceAll("'", "''");
        } else {
            value = input;
        }

        return value;
    }

    /**
     * Set field separator
     * @param fieldSeparator
     */
    public void setFieldSeparator(String fieldSeparator) {
        this.fieldSeparator = fieldSeparator;
    }
    
    /**
     * Build up PK from split fields
     * @param fields
     * @return
     */
    protected String buildKey(String fields[]) {
        // Assemble key

        StringBuffer keyBuffer = new StringBuffer();

        for (int keyPosition : keyAttributePositions) {
            // key position invalid in metadata!
            if (keyPosition >= fields.length) {
                throw new BadRowException("Invalid key position (" + keyPosition + ")!?");
            }

            if (keyBuffer.length() > 0) {
                keyBuffer.append(CASSANDRA_KEYS_SEPARATOR);
            }
            
            String fieldValue = fields[keyPosition].trim();
            
            if (fieldValue.length() == 0) {
                throw new BadRowException(String.format("Blank key value [%s]",
                        attributeNames.get(keyPosition)));
            }
            
            keyBuffer.append(fieldValue);
        }

        // Store for next section
        String keyValue = keyBuffer.toString();

        return keyValue;
    }

    public void setLoadOnly(boolean loadOnly) {
        this.loadOnly = loadOnly;
    }

    /**
     * Split and map input items
     * @param items
     * @return
     * @throws Exception
     */
    protected Map<String, InputItem> parseInputItems(List<? extends String> items) throws Exception {

        if (logger.isDebugEnabled()) logger.debug("Map {} input items...", items.size());

        Map<String, InputItem> inputItemMapSplit = new HashMap<String, InputItem>();
        
        // Parse the input items
        for(String line : items) {
            // Important note: The -1 option ensures that trailing blank fields are still tokenised
            String fields[] = line.split(fieldSeparator, -1);
            
            // Bad count check
            
            if (attributeNames.size() != fields.length) {
                throw new BadRowException("Invalid field count? expected " + attributeNames.size() + " got " + fields.length + "!?");
            }
            
            // Assemble key and store fields

            String keyValue = buildKey(fields);
            
            InputItem inputItem = new InputItem(keyValue, fields, line);
            
            // Do comparison against existing input items to see if a row supercedes 
            // an existing one
            if( latestRecordComparator != null )
            {
            	executeComparatorAgainstAttributeMap( keyValue, inputItem, inputItemMapSplit );
            }
            else
            {            
            	inputItemMapSplit.put(keyValue, inputItem);
            }
        }
        
        return inputItemMapSplit;
    }
    
    /**
     * If a comparator has been specified then this method will compare the new input
     * item against the existing ones for a record that has the same key. The comparator
     * then determines if the new item is 'later' than the existing one and if so, overwrites
     * it in the map 
     * @param key
     * @param newInputItem
     * @param existingItems
     */
    private void executeComparatorAgainstAttributeMap( 	String key, 
    													InputItem newInputItem, 
    													Map<String, InputItem> existingItems )
    {
    	// Only execute if a comparator has been specified
    	if( latestRecordComparator != null )
    	{
    		InputItem existInputItem = existingItems.get( key );
    		
    		// If there is no existing item for this key then we insert
    		if( existInputItem == null )
   			{
    			existingItems.put(key, newInputItem);
   			}
    		
    		// If the new one is deemed later than the existing record
    		// for the same key then overwrite it
    		else if( latestRecordComparator.compare(newInputItem, existInputItem) > 0 )
    		{
    			existingItems.put(key, newInputItem);
    		}
    	}
    }
    
    /**
     * Assemble reverse index CQL based on new+old row data
     * @param batchStatement
     * @param inputItem
     * @param oldRows
     */
    protected void assembleRevIdxInsert(BatchStatement batchStatement, InputItem inputItem, Map<String, String[]> oldRows) {
        logger.debug("Assemble reverse index inserts for {}...", inputItem.getKeyValue());

        // Escape logic removed as not required when binding
        String keyValue = inputItem.getKeyValue();
        String fields[] = inputItem.getFields();
        String oldValues[] = null;
        
        // oldRows will be null if we are loading only 
        if (oldRows != null && oldRows.size() > 0) {
            oldValues = oldRows.get(keyValue);
        }
        
        // Loop through queryable fields, deleting OLD data as we go
        
        for (int fldIdx : queryableAttributePositions) {
            String cfName = datasetName + CASSANDRA_CF_SEPARATOR + fldIdx;

            // Escape logic removed as not required when binding
            String newValue = fields[fldIdx];
            
            if (oldValues != null) {
                // Escape logic removed as not required when binding
                String oldValue = oldValues[fldIdx];

                // If value has changed, delete old reverse index
                if (!newValue.equals(oldValue)) {
                    if (StringUtils.isEmpty(oldValue)) {
                        logger.debug("Empty OLD reverse index at position {} for PK {}", fldIdx, keyValue);
                        
                        oldValue = StaticValues.BLANK_KEY;
                    }
                    
                    String deleteCql = "delete from \"" + cfName + "\" where key = ? and column1 = ?";
                    
                    PreparedStatement stmt = proxy.getPrepareStatement(deleteCql);
                    
                    logger.debug("Append delete statement '{}'...", deleteCql);
                    
                    BoundStatement boundStatement = stmt.bind();

                    int parmIdx = 0;
                    
                    boundStatement.setString(parmIdx++, oldValue);
                    boundStatement.setString(parmIdx++, keyValue);

                    // Add to batch
                    
                    batchStatement.add(boundStatement);
                }
            }
            
            // Insert reverse index
            
            if (StringUtils.isEmpty(newValue)) {
                logger.debug("Empty reverse index at position {} for PK {}", fldIdx, keyValue);
                
                newValue = StaticValues.BLANK_KEY;
            }

            String insertLineCql = "insert into \"" + cfName + "\" (key, column1, value) values (?, ?, ?)";

            PreparedStatement stmt = proxy.getPrepareStatement(insertLineCql);
            
            logger.debug("Append insert statement '{}'...", insertLineCql);
            
            BoundStatement boundStatement = stmt.bind();

            int parmIdx = 0;
            
            boundStatement.setString(parmIdx++, newValue);
            boundStatement.setString(parmIdx++, keyValue);
            boundStatement.setString(parmIdx++, "");

            // Add to batch
            
            batchStatement.add(boundStatement);
        }
    }

    /**
     * Load old rows
     * @param keySet
     * @return
     */
    protected Map<String, String[]> loadOldRows(Set<String> keySet) {
        
        logger.debug("Load old rows for key set {}...", keySet);
        
        Map<String, String[]> oldRowMapSplit = new HashMap<String, String[]>();
        
        String cqlQuery = "select * from \"" + datasetName + "\" where key in (";
        
        String keys = "";
        for (String key : keySet) {
            if (keys.length() > 0) {
                keys += ",";
            }
            
            // IDP-362 - Some keys (e.g.: EQUITY) have unsafe chars such as single quotes
            // Escape logic required as we aren't using bind vars here (variable length list)
            keys += "'" + escapeString(key) + "'";
        }
        
        cqlQuery += keys + ");";

        logger.debug("Run CQL query...", cqlQuery);
        
        List<Map<String, Object>> res = proxy.executeQuery(cqlQuery);
        
        for (Map<String, Object> rowData : res) {
            String key = rowData.get("key").toString();
            String value = rowData.get("value").toString();
            oldRowMapSplit.put(key, value.split(fieldSeparator,-1));
        }
        
        return oldRowMapSplit;
    }

    /**
     * Simple value object to hold parsed line + original input record
     * @author mcminnp
     */
    public class InputItem {
        private String keyValue;
        private String fields[];
        private String line;
        
        public InputItem(String keyValue, String fields[], String line) {
            this.keyValue = keyValue;
            this.fields = fields;
            this.line = line;
        }
        
        /**
         * @return the keyValue
         */
        public String getKeyValue() {
            return keyValue;
        }
        /**
         * @param keyValue the keyValue to set
         */
        public void setKeyValue(String keyValue) {
            this.keyValue = keyValue;
        }
        /**
         * @return the fields
         */
        public String[] getFields() {
            return fields;
        }
        /**
         * @param fields the fields to set
         */
        public void setFields(String[] fields) {
            this.fields = fields;
        }
        /**
         * @return the line
         */
        public String getLine() {
            return line;
        }
        /**
         * @param line the line to set
         */
        public void setLine(String line) {
            this.line = line;
        }
    }
    
    /**
     * Converts an array of fields to a line to be inserted
     * @param fields
     * @return
     */
    protected String fieldListToLine( String[] fields )
    {
    	return StringUtils.collectionToDelimitedString(Arrays.asList(fields), fieldSeparator);
    }
    
    /* (non-Javadoc)
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    public void afterPropertiesSet() throws Exception {
        logger.info("Get Cassandra proxy");

        // Initialise/fetch proxy
        proxy = cassandraSessionHelper.getProxy();
        
        logger.info("Got Cassandra proxy: {}", proxy);
        
        // Set the attribute positions in the comparator if defined
        setAttributePositionMapInComparator();
    }
    
    /**
     * Sets up the attribute name positions in a comparator 
     * if its defined
     */
    private void setAttributePositionMapInComparator()
    {
        if( latestRecordComparator != null && attributeNames != null )
        {
        	Map<String,Integer> attributePositionMap = new HashMap<String,Integer>();
        	int count = 0;
        	for( String attributeName :  attributeNames )
        	{
        		attributePositionMap.put(attributeName, count++);
        	}        	
        	latestRecordComparator.setAttributePositionMap(attributePositionMap);
        }    	
    }

	public BaseCassandraComparator getLatestRecordComparator()
	{
		return latestRecordComparator;
	}

	public void setLatestRecordComparator(BaseCassandraComparator latestRecordComparator)
	{
		this.latestRecordComparator = latestRecordComparator;
		
		setAttributePositionMapInComparator();
	}

	public void setLatestRecordComparatorClass(Class<BaseCassandraComparator> latestRecordComparatorClass) throws InstantiationException, IllegalAccessException
	{
		if( latestRecordComparatorClass != null )
		{
			this.latestRecordComparatorClass = latestRecordComparatorClass;			
			setLatestRecordComparator( this.latestRecordComparatorClass.newInstance() );
		}
	}
    

    

}
