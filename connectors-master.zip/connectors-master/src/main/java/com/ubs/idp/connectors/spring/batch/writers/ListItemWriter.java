package com.ubs.idp.connectors.spring.batch.writers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;

public class ListItemWriter implements ItemWriter<Object> {

    /*
    * This bean 'listOfItems' is of scope singleton. Spring batch 3.0 added
     * scope 'job'. Once we upgrade to Spring batch 3.0 then this bean 'listOfItems'
     * should be scope 'job'. Once bean is scoped job it may be not be required to clear
      * listOfItems's content in init method while this instantiation of this item writer
    * */
	@Resource(name = "listOfItems")
	private ArrayList listOfItems;
	
	private Logger logger = LoggerFactory.getLogger(ListItemWriter.class);

	// if after step creates problem to generic nature of writer the all
	// bussiness module can shift to listwriter step's proccessor class
	// right now TPOS doesnt have any proccessor for this step

	@AfterStep
	public void afterStep(StepExecution stepExecution) {
		JobExecution jobContext = stepExecution.getJobExecution();
		jobContext.getExecutionContext().putInt("index", 0);
		jobContext.getExecutionContext().put("ItemsListSize",
				listOfItems.size());
		logger.info("Job object list populated with :{} objects", listOfItems.size() );
		logger.debug("Job object list is: {}", listOfItems);
	}

	@Override
	public void write(List<? extends Object> listOfObjects) throws Exception {
		listOfItems.add(listOfObjects.get(0));
	}

    public void init() throws Exception{
        listOfItems.clear();
    }

    @BeforeStep
    public void beforeStep(StepExecution stepExecution) {
        JobExecution jobContext = stepExecution.getJobExecution();
        jobContext.getExecutionContext().remove("index");
        jobContext.getExecutionContext().remove("ItemsListSize");
    }
}
