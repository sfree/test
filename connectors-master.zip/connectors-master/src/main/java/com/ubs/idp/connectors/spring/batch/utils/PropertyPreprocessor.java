package com.ubs.idp.connectors.spring.batch.utils;

/**
 * Simple interface to allow for implementations of property pre-processors
 * e.g.: Token replacement
 * @author mcminnp
 */
public interface PropertyPreprocessor {

    /**
     * Pre-process string and return result
     * @param input
     * @return
     */
    public String preProcess(String input);
    
}
