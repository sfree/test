package com.ubs.idp.lsdb.model;

/**
 * JiBX POJO
 * @author mcminnp
 */
public class EntityType {
    
    public static final String BRANCH_CODE_BR = "BR";
    public static final String BRANCH_CODE_BS = "BS"; 
    
    private String subCategoryCode;

    public String getSubCategoryCode() {
        return subCategoryCode;
    }

    public void setSubCategoryCode(String subCategoryCode) {
        this.subCategoryCode = subCategoryCode;
    }
}
