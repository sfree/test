package com.ubs.idp.orchestrator.processor.rules;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;


@Component
public class BONDISSUERule extends DerivationRuleTemplate implements ItemProcessor<Map<String,Object>,Map<String,Object>>
{
    @Override
    public Map<String, Object> applyRules(Map<String, Object> inputFields)
    {
        Map<String,Object> derivedFields = new HashMap<String,Object>();
        String issuerName = (String)inputFields.get("issuer.issuerName");
        String shortName = (String)inputFields.get("issue.shortName");
        String issueName = (String)inputFields.get("issue.issueName");
        String value = "issuer name not found";
        
        if(issuerName!=null && !issuerName.trim().equals(""))
        	value = issuerName;
        else if(shortName!=null && !shortName.trim().equals(""))
        	value = shortName;
        else if(issueName!=null && !issueName.trim().equals(""))
        	value = issueName;
        
        derivedFields.put(DERIVED_SECFUNDING_ISSUERNAME, value);

        return derivedFields;
    }

    @Override
    public Map<String, Object> process(Map<String, Object> item) throws Exception {
        return derive(item);
    }
}


