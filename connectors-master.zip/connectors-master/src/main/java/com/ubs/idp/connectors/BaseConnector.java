package com.ubs.idp.connectors;

/**
 * Abstract base class from which to sub-class specific connectors
 * @author mcminnp
 */
public abstract class BaseConnector {

    public static final String SOURCE_IDENTIFIER      = "source.identifier";
    public static final String DESTINATION_IDENTIFIER = "destination.identifier";

    protected String sourceIdentifier;
    protected String destinationIdentifier;

    /**
     * Return source system identifier (keys into MDS)
     * @return the sourceIdentifier
     */
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    /**
     * Set the source system identifier (keys into MDS)
     * @param sourceIdentifier the sourceIdentifier to set
     */
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    /**
     * Return destination system identifier (keys into MDS)
     * @return the destinationIdentifier
     */
    public String getDestinationIdentifier() {
        return destinationIdentifier;
    }

    /**
     * Set the destination system identifier (keys into MDS)
     * @param destinationIdentifier the destinationIdentifier to set
     */
    public void setDestinationIdentifier(String destinationIdentifier) {
        this.destinationIdentifier = destinationIdentifier;
    }
}
