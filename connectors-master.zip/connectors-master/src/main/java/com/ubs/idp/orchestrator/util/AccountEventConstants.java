package com.ubs.idp.orchestrator.util;

public final class AccountEventConstants {

    //events
    public static final String EVENT_MF_HOST = "MF_HOST";
    public static final String EVENT_ID = "ID";
    public static final String EVENT_NEVENT_ID = "NEVENTID";
    public static final String EVENT_ACCOUNT_ID = "ACCOUNT_ID";
    public static final String EVENT_ACCOUNT_CODE = "ACCOUNT_CODE";
    public static final String EVENT_DOWNSTREAM_SP_ID = "DOWNSTREAM_SP_ID";
    public static final String EVENT_RETRY_COUNT = "RETRYCOUNT";
    public static final String XML_RAW_MESSAGE_NAME = "RAW_MESSAGE";
    public static final String XML_OUTBOUND_MESSAGE_NAME = "OUTBOUND_MESSAGE";
    public static final String LOA_TYPE = "LOA_CLASSIFICATION";

    //stored result sets
    public static final String RESULT_SET_IDP_ID = "idpid";
    public static final String RESULT_SET_ID = "resultsetid";

    public static final String RESULT_SET_TYPE = "resultsettype";
    public static final String RESULT_SET_NO_ID = "resultsetno";
    public static final String RESULT_SET_ROW_ID= "recordno";
    public static final String RESULT_SET_MAP_ID = "resultsetmap";

    public static final String RESULT_SET_TRANSFORMED_MAP_ID= "transformed_resultsetmap";
    public static final String DOWNSTREAM_SP_ID = "downstream_sp_id";
    public static final String DATA_TYPE = "data_type";
    public static final String PROPAGATION_SERVICE_IMPL_PREFIX = "PropagationStoredProc";
    public static final String CONSUMER_VIEW_PREFIX = "PropagationStoredProc";
    public static final String DOWNSTREAM_SYSTEM = "downstream_system";
    
    // Bulk Update Finder
    public static final String STREAM = "STREAM";
    public static final String MINUTE = "MINUTE_SLICE";
}
