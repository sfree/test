package com.ubs.idp.orchestrator.mappers;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.CollectionUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * MapBasedRowMapper
 *
 */
public class  MapBasedRowMapper implements RowMapper<Map<String, Object>> {

    public static final String VARCHAR2_DATA_TYPE = "VARCHAR2";
    public static final String NUMBER_DATA_TYPE = "NUMBER";

    public static final String BIG_INT_DATA_TYPE = "ubigint";
    public static final String INT_DATA_TYPE = "int";
    public static final String TINY_INT_DATA_TYPE = "tinyint";
    public static final String DATE_TIME_DATA_TYPE = "datetime";
    public static final String SMALL_INT_DATA_TYPE = "smallint";
    public static final String CHAR_DATA_TYPE = "char";
    public static final String VARCHAR_DATA_TYPE = "varchar";

    private Map<String, String> columnsAndTypes;
    private Map<String, Object> defaultValuesAndColumns;

    @Override
    public Map<String, Object> mapRow(ResultSet resultSet, int i) throws SQLException {

        Map<String, Object> mappedRows = new HashMap<>();
        Iterator<Map.Entry<String,String>> iterator = columnsAndTypes.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String> nextEntry = iterator.next();
            mappedRows.put(nextEntry.getKey(), getValueFromResultSet(nextEntry, resultSet));
        }
        if (!CollectionUtils.isEmpty(defaultValuesAndColumns)) {
            mappedRows.putAll(defaultValuesAndColumns);
        }
        return mappedRows;
    }

    private Object getValueFromResultSet(Map.Entry<String, String> nextEntry, ResultSet resultSet) throws SQLException {

        Object value;
        switch (nextEntry.getValue()) {
            case VARCHAR2_DATA_TYPE: value = resultSet.getString(nextEntry.getKey()); break;
            case NUMBER_DATA_TYPE: value = resultSet.getLong(nextEntry.getKey()); break;
            case BIG_INT_DATA_TYPE: value = resultSet.getLong(nextEntry.getKey()); break;
            case INT_DATA_TYPE: value = resultSet.getInt(nextEntry.getKey()); break;
            case TINY_INT_DATA_TYPE: value = resultSet.getInt(nextEntry.getKey()); break;
            case SMALL_INT_DATA_TYPE: value = resultSet.getInt(nextEntry.getKey()); break;
            case CHAR_DATA_TYPE: value = resultSet.getString(nextEntry.getKey()); break;
            case DATE_TIME_DATA_TYPE: value = resultSet.getTimestamp(nextEntry.getKey()); break;
            case VARCHAR_DATA_TYPE: value = resultSet.getString(nextEntry.getKey()); break;
            default : value = null;
        }
        return value;
    }

    public void setColumnsAndTypes(Map<String, String> columnsAndTypes) {
        this.columnsAndTypes = columnsAndTypes;
    }

    public void setDefaultValuesAndColumns(Map<String, Object> defaultValuesAndColumns) {
        this.defaultValuesAndColumns = defaultValuesAndColumns;
    }
}
