package com.ubs.idp.connectors.spring.batch.readers;

import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.DefaultFieldSet;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.ubs.idp.connectors.BaseConnector;
import com.ubs.idp.connectors.cassandra.CassandraCqlProxy;
import com.ubs.idp.connectors.cassandra.CassandraSessionHelper;
import com.ubs.idp.connectors.spring.batch.exceptions.BadRowException;

/**
 * Spring batch Cassandra reader
 * @author mcminnp
 */
public class CassandraItemReader extends BaseConnector implements ItemReader<FieldSet>, ItemStream, InitializingBean {

    private long rowCount = 0;

    @Autowired
    @Qualifier("cassandraSessionHelper")
    private CassandraSessionHelper cassandraSessionHelper;
    
    protected CassandraCqlProxy proxy = null;

    public static final String CASSANDRA_KEYS_SEPARATOR = "_";
    public static final String CASSANDRA_CF_SEPARATOR = "_";

    private String columnFamily;
    private String attributeNames[];
    private String fieldSeparator = DelimitedLineTokenizer.DELIMITER_TAB;
    
    /**
     * Field set mapper that can map a read in row of fields into an
     * alternate shape.
     */
    private FieldSetMapper<FieldSet> fieldSetMapper;
        
    private ResultSet resultSet = null;

    private Logger logger = LoggerFactory.getLogger(CassandraItemReader.class);

    /**
     * Bare bones constructor
     */
    public CassandraItemReader() {
        if (logger.isDebugEnabled()) logger.debug("Initialise Cassandra reader for source ID '" + sourceIdentifier + "'...");
    }

    /**
     * @return the columnFamily
     */
    public String getColumnFamily() {
        return columnFamily;
    }

    /**
     * @param columnFamily the columnFamily to set
     */
    public void setColumnFamily(String primaryColumnFamily) {
        this.columnFamily = primaryColumnFamily;
    }

    /**
     * @return the fieldSeparator
     */
    public String getFieldSeparator() {
        return fieldSeparator;
    }

    /**
     * @param fieldSeparator the fieldSeparator to set
     */
    public void setFieldSeparator(String fieldSeparator) {
        this.fieldSeparator = fieldSeparator;
    }

    /**
     * @return the attributeNames
     */
    public String[] getAttributeNames() {
        return attributeNames;
    }

    /**
     * @param primaryColumnFamilyFieldNames the primaryColumnFamilyFieldNames to set
     */
    public void setAttributeNames(
            String[] attributeNames) {
        this.attributeNames = attributeNames;
    }

    /**
     * @param primaryColumnFamilyFieldNames the primaryColumnFamilyFieldNames to set
     */
    public void setAttributeNames(String attributeNames) {
        this.attributeNames = attributeNames.split(DelimitedLineTokenizer.DELIMITER_COMMA);
    }

    /**
     * Return number of rows read
     * @return
     */
    public long getRowCount() {
        return rowCount;
    }

    @Override
    public FieldSet read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
        if (logger.isDebugEnabled()) logger.debug("Read called for source ID '" + sourceIdentifier + "'...");
        
        FieldSet res = null;
        
        if (resultSet != null) {
            Iterator<Row> rowIt = resultSet.iterator();
            
            if (rowIt.hasNext()) {
                Row row = resultSet.iterator().next();
                
                String value = row.getString("value");

                String[] fieldValues = value.split(fieldSeparator, -1);
                
                if ( fieldValues.length != attributeNames.length) {
                    throw new BadRowException("Invalid field count? expected " + attributeNames.length + " got " + fieldValues.length + "!?");
                }
                
                res = new DefaultFieldSet(fieldValues, attributeNames);
                
                // Do field mapping if one has been specified
                if( fieldSetMapper != null )
                {
                	res = fieldSetMapper.mapFieldSet(res);
                }
                
                rowCount++;
            }
        }

        // Think about re-initialise (reset row count etc.)

        if (logger.isDebugEnabled()) logger.debug("Read returns '" + res + "'...");

        return res;
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#open(org.springframework.batch.item.ExecutionContext)
     */
    @Override
    public void open(ExecutionContext executionContext)
            throws ItemStreamException {
        if (logger.isDebugEnabled()) logger.debug("Open Cassandra reader...");

        rowCount = 0;

        String cqlQuery = "select * from \"" + columnFamily + "\"";

        if (logger.isDebugEnabled()) logger.debug("Run CQL query {}...", cqlQuery);
        
        PreparedStatement stmt = proxy.getPrepareStatement(cqlQuery);

        resultSet = proxy.executeStatement(stmt.bind());
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#close()
     */
    public void close() {
        if (logger.isDebugEnabled()) logger.debug("Closing Cassandra reader");
        
        if (resultSet != null) {
            // TODO: Close!?
        }
    }

    /* (non-Javadoc)
     * @see org.springframework.batch.item.ItemStream#update(org.springframework.batch.item.ExecutionContext)
     */
    @Override
    public void update(ExecutionContext executionContext)
            throws ItemStreamException {
        if (logger.isDebugEnabled()) logger.debug("Update exectution context");
    }

    /* (non-Javadoc)
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        // TODO: Add property assertions
        
        logger.info("Get Cassandra proxy");

        // Initialise/fetch proxy
        proxy = cassandraSessionHelper.getProxy();
        
        logger.info("Got Cassandra proxy: {}", proxy);
    }

	public FieldSetMapper<FieldSet> getFieldSetMapper()
	{
		return fieldSetMapper;
	}

	public void setFieldSetMapper(FieldSetMapper<FieldSet> fieldSetMapper)
	{
		this.fieldSetMapper = fieldSetMapper;
	}

	
    
}
