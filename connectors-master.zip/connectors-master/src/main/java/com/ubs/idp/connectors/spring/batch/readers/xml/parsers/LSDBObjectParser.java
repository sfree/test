package com.ubs.idp.connectors.spring.batch.readers.xml.parsers;

import static org.springframework.util.StringUtils.isEmpty;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.oxm.jibx.JibxMarshaller;

import com.ubs.idp.lsdb.model.BankUnit;
import com.ubs.idp.lsdb.model.Company;
import com.ubs.idp.lsdb.model.EntityType;
import com.ubs.idp.lsdb.model.GCRS;
import com.ubs.idp.lsdb.model.Holding;

/**
 * LSDB-specific object hierarchy parser
 * 
 * @author mcnamars, mcminnp
 */
public class LSDBObjectParser implements ObjectHierarchyParser<Company>, InitializingBean {

    private static final String LEGAL_STRUCTURE = "1";
    private static final Logger LOGGER = LoggerFactory.getLogger(LSDBObjectParser.class);

    @Autowired
    @Qualifier("jibxMarshaller")
    private JibxMarshaller jibxMarshaller;

    /**
     * Bare bones constructor
     */
    public LSDBObjectParser() {
        LOGGER.debug("Initialise JiBX parser...");
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ubs.idp.connectors.spring.batch.readers.xml.parsers.ObjectHierarchyParser
     * #parseData(java.lang.String)
     */
    @Override
    public List<Company> parseData(String fileName) throws Exception {

        LOGGER.debug("Parse file '{}'...", fileName);
        FileInputStream fis = null;

        try {
            fis = new FileInputStream(fileName);
            return parseData(fis);
        } catch (Exception e) {
            throw new ItemStreamException(e);
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    LOGGER.info("Error closing XML file, {}", e.getMessage());
                }
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ubs.idp.connectors.spring.batch.readers.xml.parsers.ObjectHierarchyParser
     * #parseData(java.io.InputStream)
     */
    @Override
    public List<Company> parseData(InputStream inputStream) throws Exception {

        List<Company> outputData = null;
        LOGGER.debug("Parse data from input stream...");
        StreamSource ss = new StreamSource(inputStream);
        BankUnit bankUnit = (BankUnit) jibxMarshaller.unmarshal(ss);
        if (bankUnit != null && bankUnit.getCompanyList() != null) {
            List<Company> companies = bankUnit.getCompanyList();

            // Map for parent/child lookups
            Map<String, Company> companyMap = mapCompanies(companies);

            // Pre-process to create output records for read
            outputData = preProcessCompanies(companies, companyMap);
        }
        return outputData;
    }

    /**
     * Pre-process to create output records for write. Only GRCS-keyed records
     * are eligible
     * 
     * @param companies
     * @param companyMap
     * @return
     * @throws Exception
     */
    private List<Company> preProcessCompanies(List<Company> companies, Map<String, Company> companyMap)
            throws Exception {

        List<Company> outputData = new ArrayList<>();
        for (Company company : companies) {
            Company outputCompany = preProcessCompany(company, companyMap);
            if (outputCompany != null) {
                outputData.add(outputCompany);
            }
        }
        return outputData;
    }

    /**
     * Pre-process (eliminate non-GCRS records and establish parentage)
     * 
     * @param company
     * @param companyMap
     * @return
     * @throws Exception
     */
    private Company preProcessCompany(Company company, Map<String, Company> companyMap) throws Exception {

        GCRS gcrs = company.getGcrs();
        if (gcrs == null || isEmpty(gcrs.getGcrsCode())) {
            LOGGER.debug("No GCRS code - discarding company}");
            return null;
        }

        // Legal parents
        establishParents(company, companyMap);
        establishChildren(company, companyMap);
        return company;
    }

    /**
     * Establish and link children
     * 
     * @param company
     * @param companyMap
     * @throws Exception
     */
    private void establishChildren(Company company, Map<String, Company> companyMap) throws Exception {

        for (Company child : companyMap.values()) {
            if (child.getHoldings() != null) {
                addIfChild(company, child);
            }
        }
    }

    private void addIfChild(Company company, Company child) {
        for (Holding holding : child.getHoldings()) {
            if (company.getId().equals(holding.getId())) {
                // it is possible for a child to have a null GCRS
                // this causes an issue when persisting the data.
                // we are expecting all companies to have a GCRS 
                // or they are discarded. So, only add if child 
                // has a GCRS
                if (child.getGcrs() != null) {
                    company.addChildCompany(child);
                }
            }
        }
    }

    /**
     * Establish and link parents
     * 
     * @param company
     * @param companyMap
     * @throws Exception
     */
    private void establishParents(Company company, Map<String, Company> companyMap) throws Exception {

        company.setParents(getParents(company, companyMap));

        List<Company> legalParents = new ArrayList<Company>();
        List<Company> traversedNodes = new ArrayList<Company>();
        
        // add root company
        traversedNodes.add(company);
        
        company.setLegalParents(getLegalParents(company, companyMap, legalParents, traversedNodes));
    }

    /**
     * Get all immediate parents
     * 
     * @param company
     * @param companyMap
     * @return
     */
    private List<Company> getParents(Company company, Map<String, Company> companyMap) {

        List<Company> parents = new ArrayList<Company>();
        if (company.getHoldings() != null) {
            for (Holding holding : company.getHoldings()) {
                addParentIfApplicable(companyMap, parents, holding);
            }
        }
        return parents;
    }

    private void addParentIfApplicable(Map<String, Company> companyMap, List<Company> parents, Holding holding) {
        if (holding.getTypeId().equals(LEGAL_STRUCTURE)) {
            Company parent = companyMap.get(holding.getId());
            // it is possible for a parent to have a null GCRS
            // this causes an issue when persisting the data.
            // we are expecting all companies to have a GCRS 
            // or they are discarded. So, only add if parent 
            // has a GCRS
            if (parent != null && parent.getGcrs() != null) {
                parents.add(parent);
            }
        }
    }

    /**
     * Traverse company hierarchy to get legal parents
     * @param company
     * @param companyMap
     * @param legalParents
     * @param traversedNodes
     * @return
     */
    private List<Company> getLegalParents(Company company, Map<String, Company> companyMap,
            List<Company> legalParents, List<Company> traversedNodes) {

        LOGGER.debug("Establish legal parent for company id {}...", company.getId());

        List<Company> parents = company.getParents();
        
        if (parents == null) {
            LOGGER.debug("No parents found");
            return legalParents;
        }
        
        // Check we're not looping...
        
        if (isCyclic(parents, traversedNodes)) {
            LOGGER.warn("possible cyclic company hierarchy detected for company Id: {}, gcrs Id: {}. If it is a cycle "
                    + "then no legal parents will be registered against this company.", traversedNodes.get(0).getId(),
                    traversedNodes.get(0).getGcrs().getGcrsCode());
            return legalParents;
        }
        
        // Pass #1 - check for 1st non-branch parent
        
        for (Company parent : parents) {
            String subCategoryCode = parent.getSubCategoryCode();
            
            if (parent.getGcrs() != null && !isBranch(subCategoryCode)) {
                legalParents.add(parent);
                
                return legalParents;
            }
        }

        // Fall through to Pass #2 - move up hierarchy
        
        for (Company parent : parents) {
            List<Company> grandParents = parent.getParents();
            
            if (grandParents != null && grandParents.size() > 0) {
                legalParents = getLegalParents(parent, companyMap, legalParents, traversedNodes);
            }
        }
        
        return legalParents;
    }
    
    /**
     * Return true if code represents a branch
     * @param subCategoryCode
     * @return
     */
    private boolean isBranch(String subCategoryCode) {
        if (subCategoryCode != null && (
                subCategoryCode.equals(EntityType.BRANCH_CODE_BR) ||
                subCategoryCode.equals(EntityType.BRANCH_CODE_BS))) {
            return true;
        }
        
        return false;
    }

    /**
     * Returns true if a node has been visited previously. Also inserts the
     * nodes to visit into the traversedNodes after the check
     * 
     * @param companies
     *            to traverse
     * @param traversedNodes
     *            companies already visited
     * @return boolean if a node has been visited previously
     */
    private boolean isCyclic(List<Company> companies, List<Company> traversedNodes) {

        boolean cyclic = false;
        if (companies != null && !companies.isEmpty()) {
            cyclic = traversedNodes.containsAll(companies);
            traversedNodes.addAll(companies);
        }
        return cyclic;

    }

    /**
     * Hash for parent/child lookups
     * 
     * @param companies
     * @return
     */
    private Map<String, Company> mapCompanies(List<Company> companies) {
        // Hash used for parent/child lookups
        Map<String, Company> companyMap = new HashMap<String, Company>();
        for (Company company : companies) {
            if (company.getGcrs() != null) {
                companyMap.put(company.getId(), company);
            }
        }
        return companyMap;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.batch.item.ItemStream#close()
     */
    public void close() {
        if (LOGGER.isDebugEnabled())
            LOGGER.debug("Closing parser");
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        // TODO: Add property assertions

        LOGGER.info("Parser afterPropertiesSet");
    }
}