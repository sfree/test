package com.ubs.idp.orchestrator.processor.rules.treasuryar;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.springframework.batch.item.ItemProcessor;

import com.ubs.idp.orchestrator.processor.rules.DerivationRuleTemplate;

/**
 * Rule for adding a business date derived field that is set to the current day
 * @author loverids
 *
 */
public class FinanceExportRule extends DerivationRuleTemplate implements ItemProcessor<Map<String, Object>, Map<String, Object>>
{
	public final static String BUSINESS_DATE_ATTR_NAME = "BUSINESS_DATE";
	
	public final static String BUSINESS_DATE_FORMAT = "yyyyMMdd";
	
	@Override
	public Map<String, Object> applyRules(Map<String, Object> inputFields)
	{
		inputFields.put(BUSINESS_DATE_ATTR_NAME, new SimpleDateFormat(BUSINESS_DATE_FORMAT).format(new Date()) );

		return inputFields;
	}

	@Override
	public Map<String, Object> process(Map<String, Object> item) throws Exception
	{
		return derive(item);
	}

}
