package com.ubs.f35.core.zookeeper.client.common;

public class PathBuilder {

    private static final char SC = '/';
    private static final String S = "/";
    private static final String D = ".";

    private final StringBuilder builder = new StringBuilder();

    public PathBuilder() {
    }

    public PathBuilder(String rootPath, boolean normalise) {
        prependSlash(rootPath);
        rootPath = removeTrailingSlash(rootPath);
        if(normalise) {
            rootPath = normaliseToSlashes(rootPath);
        }
        builder.append(rootPath);
    }
    
    public PathBuilder(String rootPath) {
        this(rootPath, true);
    }    

    public PathBuilder appendNormalised(Integer i) {
        return appendNormalised(i.toString());
    }

    public PathBuilder appendNormalised(String path) {
        prependSlash(path);
        path = removeTrailingSlash(path);
        path = normaliseToSlashes(path);
        builder.append(path);
        return this;
    }
    
    public PathBuilder appendAsIs(String path) {
        prependSlash(path);
        path = removeTrailingSlash(path);
        builder.append(path);
        return this;
    }
    
    public PathBuilder verbatim(String string) {
        prependSlash(string);
        builder.append(string);
        return this;
    }

    void prependSlash(String path) {
        if (!path.startsWith(S)) {
            if (builder.length() == 0 || builder.charAt(builder.length() - 1) != SC) {
                builder.append(S);
            }
        }
    }

    String removeTrailingSlash(String path) {
        return path.endsWith(S) ? path.substring(0, path.length() - 1) : path;
    }

    String normaliseToSlashes(String property) {
        return property.contains(D) ? property.replace(D, S) : property;
    }

    @Override
    public String toString() {
        return builder.toString();
    }

}