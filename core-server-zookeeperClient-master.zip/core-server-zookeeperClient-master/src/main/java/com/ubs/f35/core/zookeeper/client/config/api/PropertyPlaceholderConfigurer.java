package com.ubs.f35.core.zookeeper.client.config.api;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.core.zookeeper.client.common.HostPidResolver;
import com.ubs.f35.core.zookeeper.client.common.ZooKeeperClientPropertiesLoader;
import com.ubs.f35.core.zookeeper.client.config.ConfigPropertyValueTypeHelper;

class PropertyPlaceholderConfigurer extends org.springframework.beans.factory.config.PropertyPlaceholderConfigurer {

    static final Logger logger = LoggerFactory.getLogger(PropertyPlaceholderConfigurer.class);

    //placeholder names which are used to get jmxPort and jmxNic which are used to create applicationId
    private final String JMX_PORT_PROPERTY_DEFAULT_NAME = "core.server.lcds.jmx.http.port";
    private final String JMX_INTERFACE_PROPERTY_DEFAULT_NAME = "core.server.lcds.jmx.http.nic";
    
    //placeholder name which is used in core-server-app-support. Change in with cautious
    public final String APPLICATION_ID_PROPERTY_NAME = "internal.application.id"; 
    
    //used if jmxPort is not found
    private final String uuidApplicationId = UUID.randomUUID().toString();
    
    
    protected final String jmxPortPropertyName;
    protected final String jmxInterfacePropertyName;
    
    public PropertyPlaceholderConfigurer() {
        jmxPortPropertyName = JMX_PORT_PROPERTY_DEFAULT_NAME;
        jmxInterfacePropertyName = JMX_INTERFACE_PROPERTY_DEFAULT_NAME;
    }

    @Override
    protected String resolvePlaceholder(String placeholder, Properties properties) {
        String propertyValue = super.resolvePlaceholder(placeholder, properties);
        if (propertyValue == null) {
            return null;
        } else {
            ConfigPropertyValueTypeHelper typeDetector = new ConfigPropertyValueTypeHelper(propertyValue);
            if (typeDetector.isLeased()) {
                return extractPropertyValueFromCompoundExpression(placeholder, propertyValue);
            } else {
                return propertyValue;
            }
        }
    }

    @Override
    protected void loadProperties(Properties springProperties) throws IOException {
        super.loadProperties(springProperties);
        populateLeasedPropertyValues(springProperties);
        populateZooKeeperClientProperties(springProperties);
        populateApplicationIdProperty(springProperties);
    }

    protected String extractPropertyValueFromCompoundExpression(String placeholder, String fullExpression) {
        List<String> propertyGroups = new ConfigPropertyValueTypeHelper(fullExpression).getLeaseEntityExpressions();
        return extractPropertyValueFromSingleExpression(placeholder, propertyGroups.iterator().next());
    }

    @SuppressWarnings("rawtypes")
    protected String extractPropertyValueFromSingleExpression(String placeholder, String singleExpression) {
        Map propertyGroup = ConfigPropertyValueTypeHelper.parseLeaseEntityExpression(singleExpression);
        return propertyGroup.get(placeholder.substring(placeholder.lastIndexOf('.') + 1)).toString();
    }

    protected void populateApplicationIdProperty(Properties springProperties) {
        String nic = springProperties.getProperty(jmxInterfacePropertyName);
        String jmxPort = springProperties.getProperty(jmxPortPropertyName);
        springProperties.put(APPLICATION_ID_PROPERTY_NAME, createApplicationId(jmxPort, nic));
    }

    protected void populateZooKeeperClientProperties(Properties springProperties) {
        String emptyValue = ZooKeeperClientPropertiesLoader.EMPTY_VALUE;
        springProperties.setProperty(ZooKeeperClientPropertiesLoader.HOST_PORTS, emptyValue);
        springProperties.setProperty(ZooKeeperClientPropertiesLoader.SESSION_TIMEOUT, emptyValue);
        springProperties.setProperty(ZooKeeperClientPropertiesLoader.CONNECTION_TIMEOUT, emptyValue);
        springProperties.setProperty(ZooKeeperClientPropertiesLoader.USERNAME, emptyValue);
        springProperties.setProperty(ZooKeeperClientPropertiesLoader.PASSWORD, emptyValue);
    }

    @SuppressWarnings({ "rawtypes" })
    void populateLeasedPropertyValues(Properties springProperties) {
        for (String key : springProperties.stringPropertyNames()) {
            String expression = springProperties.getProperty(key);
            ConfigPropertyValueTypeHelper typeDetector = new ConfigPropertyValueTypeHelper(expression);
            if (typeDetector.isLeased()) {
                List<String> childExpressions = new ConfigPropertyValueTypeHelper(expression).getLeaseEntityExpressions();
                String firstExpression = childExpressions.iterator().next();
                Map properties = ConfigPropertyValueTypeHelper.parseLeaseEntityExpression(firstExpression);
                for (Object o : properties.entrySet()) {
                    Map.Entry e = (Map.Entry) o;
                    springProperties.remove(key);
                    springProperties.setProperty(key + "." + e.getKey().toString(), e.getValue().toString());
                }
            }
        }
    }
    
    protected String createApplicationId(String jmxPort, String nic) {
        String ipAddress = null;
        try {
            ipAddress = new HostPidResolver().getIPAddress(nic);
        } catch (IOException e) {
            logger.error("can not get IP address of network interface {}", nic, e);
        }
        
        return (jmxPort == null || ipAddress == null) ? uuidApplicationId : (ipAddress + "_" + jmxPort); 
    }
}