package com.ubs.f35.core.zookeeper.client.common;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

import com.google.common.base.Splitter;

public class HostPidResolver {

    private final byte[] DUMMY_ADDRESS = new byte[]{0,0,0,0,0,0};
    
    private final String host;
    private final String pid;

    public HostPidResolver() {
        String name = ManagementFactory.getRuntimeMXBean().getName();
        Iterator<String> iterator = Splitter.on('@').split(name).iterator();
        pid = iterator.next();
        host = iterator.next();
    }

    public String host() {
        return host;
    }

    public String pid() {
        return pid;
    }
    
    public String getMacAddress(String nic) throws IOException {
        Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
        SortedSet<String> macs = new TreeSet<String>();
        for (NetworkInterface netint : Collections.list(nets)) {
            if (!netint.isLoopback() && !(Arrays.equals(DUMMY_ADDRESS, netint.getHardwareAddress()))) {
                byte[] macBytes = netint.getHardwareAddress();
                if (macBytes != null) {
                    String mac = formatMac(macBytes);
                    if (nic != null && nic.equals(netint.getName())) {
                        return mac;
                    }
                    macs.add(mac);
                }
            }
        }
        return !macs.isEmpty() ? macs.first() : null;
    }

    public String getIPAddress(String nic) throws IOException {
        
        Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
        SortedSet<String> ips = new TreeSet<String>();
        SortedSet<String> nicIPs = new TreeSet<String>();
        for (NetworkInterface netint : Collections.list(nets)) {
            if (!netint.isLoopback() && !(Arrays.equals(DUMMY_ADDRESS, netint.getHardwareAddress()))) {
                Enumeration<InetAddress> inetAddresses = netint.getInetAddresses();
                if (nic != null && nic.equals(netint.getName())) {
                    while (inetAddresses.hasMoreElements()) {
                        nicIPs.add(inetAddresses.nextElement().getHostAddress());
                    }
                    break;
                } else {
                    while (inetAddresses.hasMoreElements()) {
                        ips.add(inetAddresses.nextElement().getHostAddress());
                    }
                }
            }
        }
        
        if(!nicIPs.isEmpty()) {
            return nicIPs.first();
        } else if(!ips.isEmpty()) {
            return ips.first();
        } else {
            return null;
        }
    }
    
    
    private String formatMac(byte[] macBytes) {
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < macBytes.length; i++) {
            buf.append(String.format("%02X%s", macBytes[i], (i < macBytes.length - 1) ? "-" : ""));
        }
        return buf.toString();
    }

}