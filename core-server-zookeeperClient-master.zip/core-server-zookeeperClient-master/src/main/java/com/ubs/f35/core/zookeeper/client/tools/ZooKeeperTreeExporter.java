package com.ubs.f35.core.zookeeper.client.tools;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.core.zookeeper.client.ZNode;
import com.ubs.f35.core.zookeeper.client.ZNodeProcessor;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.common.StringValueTransformer;

/**
 * Exports the zookeeper tree to the file.
 * The format of the exported data is human readable.
 * Every line represents the tree's node with not null data. * 
 * 
 * Exported data can be used to upload to another zookeeper cluster (see {@link ZooKeeperTreeImporter}).
 * @author chernyse
 *
 */
public class ZooKeeperTreeExporter {

    private static final Logger logger = LoggerFactory.getLogger(ZooKeeperTreeExporter.class);

    public static final String NEW_ZNODE_MARKER = "[ZNODE]:";
    public static final String IMPORT_LINES_SEPARATOR_PATTERN = "\\[ZNODE\\]:";
    public static final String DEFAULT_F35_ROOT_PATH = "/f35";
    public static final String NEW_LINE_SYMBOL = "\n";
    public static final String PATH_VALUE_SEPARATOR = " : ";

    static final StringValueTransformer valueTransformer = new StringValueTransformer();

    private final ZooKeeperService zks;

    public ZooKeeperTreeExporter(ZooKeeperService zks) {
        this.zks = zks;
    }

    public static class ZNodeWriter implements ZNodeProcessor {
        private final OutputStream fos;

        public ZNodeWriter(OutputStream fos) {
            this.fos = fos;
        }

        @Override
        public void process(ZNode znode) {

            // Only persistent znodes and leaf nodes or not leaf nodes with not
            // null value are to be exported
            if (znode.isEphemeral() || 
                    (!znode.isLeaf() && (znode.value() == null || znode.value().length == 0))) {
                return;
            }

            StringBuffer exportZnodeLine = new StringBuffer().append(NEW_ZNODE_MARKER).append(znode.path()).append(PATH_VALUE_SEPARATOR);

            if (znode.value() != null && znode.value().length > 0) {
                exportZnodeLine.append(valueTransformer.fromInput(znode.value()));
            }

            // appending new line symbol to make the exported file human
            // readable            
            exportZnodeLine.append(NEW_LINE_SYMBOL);

            try {
                fos.write(exportZnodeLine.toString().getBytes());
            } catch (IOException e) {
                logger.error("Can not write to file", e);
            }
        }
    }

    public void exportTreeToFile(String filePath, String rootNodeName) throws Exception {
        File file = new File(filePath);
        validateOutputFile(file);
        String rootPath = rootNodeName == null ? DEFAULT_F35_ROOT_PATH : makeRootPath(rootNodeName);
        FileOutputStream fos = new FileOutputStream(file);
        exportTree(rootPath, fos);
        logger.info("Zookeeper's tree was successfully exported to {}", file.getCanonicalPath());
    }

    public void exportTree(String startNode, OutputStream ous) throws Exception {
        try {
            zks.walk(startNode, new ZNodeWriter(ous));
        } finally {
            ous.close();
        }
    }

    private void validateOutputFile(File file) throws IOException {
        if (file.exists()) {
            logger.warn("The file for the export already exists");
            if (!file.canWrite()) {
                logger.error("Can not write to the file");
                throw new IllegalArgumentException(
                        "Can not export the tree as the provided file is forbidden for writing");
            } else {
                long suffix = System.currentTimeMillis();
                String oldName = file.getCanonicalPath();
                String newName = oldName + suffix;
                logger.warn("Existing file will be renamed to {}, the imported data will be written to {}", newName,
                        oldName);
                file.renameTo(new File(newName));
                file = new File(oldName);
            }
        } else {
            if (!file.createNewFile()) {
                throw new IllegalArgumentException("Can not create export file " + file.getCanonicalPath());                
            } else {
                logger.debug("File for export {} is created", file.getCanonicalPath());
            }
        }
    }

    private String makeRootPath(String rootNodeName) {
        return rootNodeName.startsWith("/") ? rootNodeName : "/" + rootNodeName;
    }

}
