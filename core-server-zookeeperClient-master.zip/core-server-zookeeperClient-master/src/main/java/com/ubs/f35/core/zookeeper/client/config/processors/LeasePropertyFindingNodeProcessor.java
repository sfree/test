package com.ubs.f35.core.zookeeper.client.config.processors;

import java.util.HashMap;
import java.util.Map;

import com.ubs.f35.core.zookeeper.client.ZNode;
import com.ubs.f35.core.zookeeper.client.ZNodeProcessor;
import com.ubs.f35.core.zookeeper.client.common.StringValueTransformer;
import com.ubs.f35.core.zookeeper.client.config.ConfigPropertyValueTypeHelper;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper;

/**
 * Populates the map of property name and its corresponding zookeeper node with
 * is used in {@link ZooKeeperPropertyPlaceholderConfigurer} to acquire the
 * leased value.
 */
public class LeasePropertyFindingNodeProcessor implements ZNodeProcessor {

    static final StringValueTransformer valueTransformer = new StringValueTransformer();

    final Map<String, ZNode> placeholderToLeaseGroupNodeMapping = new HashMap<String, ZNode>();

    public Map<String, ZNode> getPlaceholderToLeaseGroupNodeMapping() {
        return placeholderToLeaseGroupNodeMapping;
    }

    @Override
    @SuppressWarnings("rawtypes")
    public void process(ZNode zNode) {
        if (ConfigTagSchemeHelper.parse(zNode.name()).isLeaseEntity()) {
            String value = valueTransformer.fromInput(zNode.value());
            Map properties = ConfigPropertyValueTypeHelper.parseLeaseEntityExpression(value);
            for (Object o : properties.entrySet()) {
                Map.Entry property = (Map.Entry) o;
                placeholderToLeaseGroupNodeMapping.put(property.getKey().toString(), zNode.parent());
            }
        }
    }

}