package com.ubs.f35.core.zookeeper.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.data.Stat;

import com.ubs.f35.core.zookeeper.client.common.PathBuilder;

/**
 * Lazy zookeeper node.
 * </p>
 * Node's data is retrieved only when it is called.
 *
 */
public class LazyZNode implements ZNode {

    protected final String path;
    protected final String name;
    protected final Integer relativeOffset;
    protected final ZooKeeperClient zkc;

    protected boolean leaf;
    protected byte[] value;
    protected LazyZNode parent;

    LazyZNode(String path, Integer relativeOffset, ZooKeeperClient zkc) {
        this.path = path;
        this.zkc = zkc;
        this.name = path.substring(path.lastIndexOf('/') + 1);
        this.relativeOffset = relativeOffset;
    }

    @Override
    public String path() {
        return path;
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public Integer relativeOffset() {
        return relativeOffset;
    }

    @Override
    public LazyZNode parent() {
        if (parent == null) {
            int lastPathSeparatorIndex = path.lastIndexOf('/');
            if (lastPathSeparatorIndex > 0) {
                parent = new LazyZNode(path.substring(0, lastPathSeparatorIndex), relativeOffset - 1, zkc);
            }
        }

        return parent;
    }

    @Override
    public boolean isEphemeral() {
        return new ZkcCall<Boolean>() {
            @Override
            protected Boolean doCall(String path) throws KeeperException, InterruptedException {
                Stat stat = zkc.stat(path);
                if (stat == null) {
                    throw new KeeperException.NoNodeException("stat object is null");
                } else {
                    return stat.getEphemeralOwner() != 0;
                }
            }
        }.call(path);
    }

    @Override
    public boolean isLeaf() {
        return new ZkcCall<Boolean>() {
            @Override
            protected Boolean doCall(String path) throws KeeperException, InterruptedException {
                Stat stat = zkc.stat(path);
                if (stat == null) {
                    throw new KeeperException.NoNodeException("stat object is null");
                } else {
                    return stat.getNumChildren() == 0;
                }
            }
        }.call(path);
    }

    @Override
    public byte[] value() {
        return new ZkcCall<byte[]>() {
            @Override
            protected byte[] doCall(String path) throws KeeperException, InterruptedException {
                return zkc.read(path);
            }
        }.call(path);
    }

    @Override
    public List<ZNode> children() {
        List<String> childNodes = new ZkcCall<List<String>>() {
            @Override
            protected List<String> doCall(String path) throws KeeperException, InterruptedException {
                return zkc.getChildren(path);
            }
        }.call(path);

        if (childNodes == null || childNodes.isEmpty()) {
            return Collections.emptyList();
        }

        List<ZNode> children = new ArrayList<ZNode>(childNodes.size());
        for (String child : childNodes) {
            String childPath = new PathBuilder().verbatim(path).verbatim(child).toString();
            children.add(new LazyZNode(childPath, relativeOffset + 1, zkc));
        }

        return children;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Node [path=").append(path).append(", relativeOffset=").append(relativeOffset).append(", leaf=")
                .append(leaf).append(", value=").append(Arrays.toString(value)).append("]");
        return builder.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((path == null) ? 0 : path.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        LazyZNode other = (LazyZNode) obj;
        if (path == null) {
            if (other.path != null)
                return false;
        } else if (!path.equals(other.path))
            return false;
        return true;
    }

    /**
     * Isolates the exception wrapping in one place
     * 
     * @author bandopdh
     * 
     * @param <T>
     */
    private abstract static class ZkcCall<T> {
        final T call(String path) {
            try {
                return doCall(path);
            } catch (KeeperException e) {
                throw new LazyLoadException("Failed lazy operation at path: " + path, e);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new LazyLoadException("Failed lazy operation at path: " + path, e);
            }
        }

        protected abstract T doCall(String path) throws KeeperException, InterruptedException;
    }

    int groupId;

    public static class LazyLoadException extends RuntimeException {
        private static final long serialVersionUID = -2011927165863620593L;

        LazyLoadException() {
            super();
        }

        LazyLoadException(String message) {
            super(message);
        }

        LazyLoadException(Throwable cause) {
            super(cause);
        }

        LazyLoadException(String message, Throwable cause) {
            super(message, cause);
        }
    }

}