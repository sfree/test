package com.ubs.f35.core.hash;

public interface HashFunction {
    int hash(byte[] data, int seed);
}
