package com.ubs.f35.core.zookeeper.client;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.data.Stat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.base.Strings;
import com.ubs.f35.core.zookeeper.client.LazyZNode.LazyLoadException;
import com.ubs.f35.core.zookeeper.client.ZNode.ZNodeType;
import com.ubs.f35.core.zookeeper.client.ZNodeNavigator.NavigateResult;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient.DataAndStat;
import com.ubs.f35.core.zookeeper.client.common.PathBuilder;
import com.ubs.f35.core.zookeeper.client.common.StringValueTransformer;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper;

/**
 * Provides the functions on zookeeper tree data:
 * <ul>
 * <li>Persistent node creation</li>
 * <li>Ephemeral  node creation</li>
 * <li>Different types of navigation across the tree</li>
 * <li>Deleting  sub-tree</li>
 * <li>Pretty print of tree</li>
 * </ul>
 */
public class ZooKeeperService {

    static final Logger logger = LoggerFactory.getLogger(ZooKeeperService.class);
    static final StringValueTransformer valueTransformer = new StringValueTransformer();

    protected ZooKeeperClient zkc;
    
    public ZooKeeperService() {
    }

    public ZooKeeperService(ZooKeeperClient zkc) {
        this.zkc = zkc;
    }
    
    /**
     * Creates {@link ZNode} from the given tree path
     * @param path - path to the node
     * @return {@link ZNode} if the zookeeper client is connected or null otherwise
     * @throws KeeperException
     * @throws InterruptedException
     */
    public ZNode read(String path) throws KeeperException, InterruptedException {

        if (!clientValidated()) {
            return null;
        }

        if (zkc.exists(path)) {
            return new LazyZNode(path, 0, zkc);
        } else {
            return null;
        }
        
    }

    /**
     * Walk the tree from given rootPath to leafs with a collection of callbacks called for every passed node.
     * {@link TraversalType.DEPTH_FIRST} traversal type is used.
     * 
     * @param rootPath - tree path to start the walk with
     * @param processors - list of {@link ZNodeProcessor} callbacks
     * @throws Exception
     */
    public void walkMulti(String rootPath, Collection<ZNodeProcessor> processors) throws Exception {
        doWalk(rootPath, processors, null, TraversalType.DEPTH_FIRST);
    }

    /**
     * Walk the tree from given rootPath to leafs with a single callback called for every passed node.
     * {@link TraversalType.DEPTH_FIRST} traversal type is used.
     * 
     * @param rootPath - tree path to start the walk with
     * @param processor - {@link ZNodeProcessor} callback
     * @throws Exception 
     */
    public void walk(String rootPath, ZNodeProcessor processor) throws Exception {
        doWalk(rootPath, Collections.singleton(processor), null, TraversalType.DEPTH_FIRST);
    }

    /**
     * Walk the tree from given rootPath to leafs with a single callback and given {@link TraversalType}.
     * 
     * @param rootPath - tree path to start the walk with
     * @param processor - {@link ZNodeProcessor} callback
     * @param traversalType - {@link TraversalType}
     * @throws Exception
     */
    public void walk(String rootPath, ZNodeProcessor processor, TraversalType traversalType) throws Exception {
        doWalk(rootPath, Collections.singleton(processor), null, traversalType);
    }

    /**
     * Walks across the tree from given rootPath to leafs analysing every node by {@link ZNodeNavigator}. 
     * {@link ZNodeNavigator} returns the {@link NavigateResult} which indicates how to proceed the walk:
     * <ul>
     * <li>CONTINUE</li>
     * <li>TERMINATE</li>
     * <li>SKIP_SIBLINGS</li>
     * <li>SKIP_SUBTREE</li>
     * </ul>    
     *
     * @param rootPath - tree path to start the walk with 
     * @param navigator
     * @throws Exception
     */
    public void navigate(String rootPath, ZNodeNavigator navigator) throws Exception {
        doWalk(rootPath, navigator, TraversalType.DEPTH_FIRST);
    }

    /**
     * Walks across the tree from given rootPath to leafs analysing every node by {@link ZNodeNavigator}. 
     * {@link ZNodeNavigator} returns the {@link NavigateResult} which indicates how to proceed the walk:
     * <ul>
     * <li>CONTINUE</li>
     * <li>TERMINATE</li>
     * <li>SKIP_SIBLINGS</li>
     * <li>SKIP_SUBTREE</li>
     * </ul>    
     *
     * {@link TraversalType} is used to define the style of the walk.
     * 
     * @param rootPath
     * @param navigator
     * @param traversalType
     * @throws Exception
     */
    public void navigate(String rootPath, ZNodeNavigator navigator,TraversalType traversalType) throws Exception {
        doWalk(rootPath, navigator, traversalType);
    }
    
    /**
     * Walk algorithm with ZNodeNavigator
     */
    void doWalk(String rootPath, ZNodeNavigator navigator, TraversalType traversalType) throws Exception {

        if (!clientValidated()) {
            return;
        }
        
        /*
         * handle missing root
         */
        Stat rootStat = zkc.stat(rootPath);
        if (rootStat == null) {
            return;
        }

        /*
         * handle root being leaf (has no children)
         */
        if (rootStat.getNumChildren() == 0) {
            navigator.navigate(new LazyZNode(rootPath, 0, zkc));
            return;
        }

        Deque<LazyZNode> deck = new ArrayDeque<LazyZNode>();

        /*
         * handle root being branch (has children)
         */
        LazyZNode rootNode = new LazyZNode(rootPath, 0, zkc);
        if (traversalType == TraversalType.DEPTH_FIRST) {
            deck.addFirst(rootNode);
        } else {
            deck.addLast(rootNode);
        }

        int groupId = 0;
        BitSet bs = new BitSet();
        while (!deck.isEmpty()) {

            LazyZNode currentNode = deck.removeFirst();
            if (bs.get(currentNode.groupId)) {
                continue;
            }

            NavigateResult result = null;
            try {
                result = navigator.navigate(currentNode);
            } catch (LazyLoadException e) {
                logger.warn("lazy load exception encountered at path: " + currentNode.path
                        + " while calling navigator: " + navigator.getClass() + "; continuing walk ...", e);
            } catch (InterruptedException e) {
                logger.warn("interrupted exception occurred at path: " + currentNode.path
                        + " while calling navigator: " + navigator.getClass() + "; continuing walk ...", e);
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                logger.error("exception occurred at path: " + currentNode.path + " while calling navigator: "
                        + navigator.getClass() + "; continuing walk ...", e);
            }

            if (result == null) {
                result = NavigateResult.CONTINUE;
            }

            if (result == NavigateResult.SKIP_SIBLINGS) {
                bs.set(currentNode.groupId);
            }

            if (result == NavigateResult.TERMINATE) {
                logger.info("walk termination requested; terminating at {}", currentNode.path);
                return;
            }

            if (result != NavigateResult.SKIP_SUBTREE) {

                List<String> childNodes = Collections.emptyList();

                try {
                    childNodes = zkc.getChildren(currentNode.path());
                } catch (KeeperException.NoNodeException e) {
                    logger.warn("failed to get children of non-existent node: " + currentNode.path()
                            + "; continuing walk ...");
                    continue;
                }

                for (String child : childNodes) {

                    String childPath = new PathBuilder().verbatim(currentNode.path).verbatim(child).toString();
                    LazyZNode childNode = new LazyZNode(childPath, currentNode.relativeOffset() + 1, zkc);

                    childNode.groupId = groupId;
                    childNode.parent = currentNode;

                    if (traversalType == TraversalType.DEPTH_FIRST) {
                        deck.addFirst(childNode);
                    } else {
                        deck.addLast(childNode);
                    }
                }

                groupId++;

            }
        }

    }

    /**
     * Walk algorithm with collection of ZNodeProcessor.
     */
    protected void doWalk(String rootPath, Collection<ZNodeProcessor> processors, Deque<DefaultZNode> deck,
            TraversalType traversalType) throws Exception {

        if (!clientValidated()) {
            return;
        }
        
        DataAndStat rootData = zkc.getDataAndStat(rootPath);

        /*
         * handle missing root
         */
        if (rootData == null || rootData.stat == null) {
            return;
        }

        /*
         * handle root being leaf (has no children)
         */
        if (rootData.stat.getNumChildren() == 0) {
            for (ZNodeProcessor processor : processors) {
                processor.process(new DefaultZNode(rootPath, getType(rootData.stat), 0, true, rootData.data));
            }
            return;
        }

        // set null collection
        if (deck == null) {
            deck = new ArrayDeque<DefaultZNode>();
        }

        /*
         * handle root being branch (has children)
         */
        DefaultZNode rootNode = new DefaultZNode(rootPath, getType(rootData.stat), 0, false, rootData.data);
        if (traversalType == TraversalType.DEPTH_FIRST) {
            deck.addFirst(rootNode);
        } else {
            deck.addLast(rootNode);
        }

        while (!deck.isEmpty()) {

            DefaultZNode currentNode = deck.removeFirst();

            List<String> childNodes = zkc.getChildren(currentNode.path);
            currentNode.children = new ArrayList<ZNode>(childNodes.size());

            for (String child : childNodes) {

                DefaultZNode childNode = loadChild(currentNode, child);
                
                currentNode.children.add(childNode);
                if (traversalType == TraversalType.DEPTH_FIRST) {
                    deck.addFirst(childNode);
                } else {
                    deck.addLast(childNode);
                }

            }

            for (ZNodeProcessor processor : processors) {
                processor.process(currentNode);
            }
        }
    }

    /**
     * Loads a child node of the ZK tree.  As ZK operations are across the wire, minimise the number of remote calls.
     */
    protected DefaultZNode loadChild(DefaultZNode currentNode, String child) throws KeeperException, InterruptedException {
        String childPath = new PathBuilder().verbatim(currentNode.path).verbatim(child).toString();

        DataAndStat childStat = zkc.getDataAndStat(childPath);
        if (childStat == null) {
            logger.error("childStat is null: {}", childPath);
        }

        DefaultZNode childNode = new DefaultZNode(childPath, getType(childStat.stat),
                currentNode.relativeOffset + 1, !hasChildren(childStat.stat), childStat.data);

        childNode.parent = currentNode;
        
        return childNode;
    }

    private boolean hasChildren(final Stat stat) throws KeeperException, InterruptedException {
        if (stat == null) {
            return false;
        } else {
            return stat.getNumChildren() > 0;
        }
    }
    
    /**
     * Creates ephemeral node and set the value to the node. 
     * If node already exists - the value is updated
     * @param path of the node to create
     * @param data node's data
     * @throws KeeperException
     * @throws InterruptedException
     * 
     * @deprecated
     */
    public void createOrUpdateEphemeralNode(String path, byte[] data) throws KeeperException, InterruptedException {
        zkc.createFull(path, data, CreateMode.EPHEMERAL);
    }    

    /**
     * Creates or updates persistent node 
     * @param path
     * @param data
     * @throws KeeperException
     * @throws InterruptedException
     * 
     * @deprecated
     */
    public void createPersistentNode(String path, byte[] data) throws KeeperException, InterruptedException {
        zkc.createFull(path, data, CreateMode.PERSISTENT);
    }    

    /**
     * Pretty print the tree starting from the root path.
     */
    public void prettyPrint(String rootPath) throws Exception {
        System.out.println();
        walk(rootPath, new ZNodeProcessor() {
            @Override
            public void process(ZNode znode) {
                System.out.println(String.format("%s * %s %s (%s) : %s", Strings.repeat("  ", znode.relativeOffset()),
                        znode.path(), znode.isEphemeral() ? "[E]" : "", znode.relativeOffset(),
                        valueTransformer.fromInput(znode.value())));
            }
        });
        System.out.println();
    }

    /**
     * Iteratively delete all nodes under the root path including the root path
     * node itself.
     */
    public void deleteSubTree(String rootPath) throws Exception {
        
        //checking first that we do not remove any locked properties
        final List<ZNode> locks = new LinkedList<ZNode>();
        
        doWalk(rootPath, new ZNodeNavigator() {

            @Override
            public NavigateResult navigate(ZNode znode) throws Exception {
                if (znode.isEphemeral() && znode.name().indexOf(ConfigTagSchemeHelper.SCHEME_LEASE_LOCK) > -1) {
                    locks.add(znode);
                }
                return NavigateResult.CONTINUE;
            }}, TraversalType.DEPTH_FIRST);

        if(!locks.isEmpty()) {
            StringBuilder message = new StringBuilder();
            for(ZNode lock : locks) {
                message.append("You must stop currently connected application [applicationId=").append(valueTransformer.fromInput(lock.value())).append("] before deleting properties ").append(lock.parent().path()).append("\n");
            }
            throw new IllegalStateException(message.toString());
        }
        
        
        //checks passed
        deleteSubTree(rootPath, Collections.<String>emptyList());
    }
    
    public void deleteSubTree(String rootPath, final Collection<String> filter) throws Exception {
        final Deque<ZNode> deck = new ArrayDeque<ZNode>();

        doWalk(rootPath, new ZNodeNavigator() {

            @Override
            public NavigateResult navigate(ZNode znode) throws Exception {

                if (!znode.isLeaf()) {
                    deck.addFirst(znode);
                } else {
                    if(!filter.contains(znode.path())) {
                        logger.info("deleting leaf node at relative offset {} with path {}", znode.relativeOffset(),
                                znode.path());
                        zkc.delete(znode.path());
                    }
                }
                return NavigateResult.CONTINUE;
            }}, TraversalType.BREADTH_FIRST);
        
        while (!deck.isEmpty()) {
            ZNode znode = deck.removeFirst();
            if(!filter.contains(znode.path()) && znode.isLeaf()) {
                logger.info("deleting branch node at relative offset {} with path {}", znode.relativeOffset(), znode.path());
                zkc.delete(znode.path());
            }
        }
    }

    /**
     * Disconnect zookeeper client form the cluster
     * @throws InterruptedException
     */
    public void stop() throws InterruptedException {
        if (zkc != null) {
            zkc.stop();
        }
    }
    
    private boolean clientValidated() {
        
        if(!zkc.isEnabled()) {
            logger.info("zookeeper client is disabled");
            return false;
        }
        
        if(!zkc.isAlive()) {
            logger.warn("zookeeper client is dead");
            throw new IllegalStateException("zk client dead");
        }
        
        return true;
    }

    /**
     * Type of traversal across the zookeeper tree.
     * Used in walk(...) and navigate(...) functions.
     * Possible values: DEPTH_FIRST and BREADTH_FIRST
     */
    public enum TraversalType {
        /**
         * Nodes located in tree's depth are navigated first
         */
        DEPTH_FIRST,
        
        /**
         * Nodes located in tree's breadth are navigated first
         */
        BREADTH_FIRST;
    }

    /*
     * TODO: Please move everything under here to one or more new classes.
     */

    private ZNodeType getType(Stat stat) {
        return (stat.getEphemeralOwner() == 0) ? ZNodeType.PERSISTENT : ZNodeType.EPHEMERAL;
    }
    
    @Required
    public void setZooKeeperClient(ZooKeeperClient zkc) {
        this.zkc = zkc;
    }

    public ZooKeeperClient getClient() {
        return zkc;
    }
}