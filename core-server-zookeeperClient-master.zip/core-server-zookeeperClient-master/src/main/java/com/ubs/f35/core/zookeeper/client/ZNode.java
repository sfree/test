package com.ubs.f35.core.zookeeper.client;

import java.util.List;

/**
 * Zookeeper's tree node model. 
 * Aggregates information about its tree path, parent, children nodes, etc. 
 *
 */
public interface ZNode {

    /**
     * Zookeeper has 4 types of nodes: persistent, ordered persistent,
     * ephemeral and ordered ephemeral. We are using only not ordered nodes.
     */
    public enum ZNodeType {
        PERSISTENT, EPHEMERAL
    }

    boolean isEphemeral();

    /**
     * @return Node's full path
     */
    String path();

    /**
     * @return Node's name
     */
    String name();

    /**
     * @return level of the node relatively to the node used as a root.
     * This value can be different for the same given tree node and depends on the used root path.  
     */
    Integer relativeOffset();

    boolean isLeaf();

    /**
     * @return node's data
     */
    byte[] value();

    ZNode parent();

    List<ZNode> children();

}