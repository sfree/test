package com.ubs.f35.core.zookeeper.client.tools;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;

/**
 * Imports zookeeper data from the file into tree.
 * It parses the file created by {@link ZooKeeperTreeExporter} and creates corresponding nodes in the tree.
 * If the node already exists its data will be overwritten with data from the file.
 * </p>
 * Failed during parsing/creation import file lines are recorded to <b>import.err</b>.
 * 
 * @author chernyse
 *
 */
public class ZooKeeperTreeImporter {

    private static final Logger logger = LoggerFactory.getLogger(ZooKeeperTreeImporter.class);
    
    private static final String ZKPATH_VALUE_REG_EXPRESSION = "(/\\S+)\\s\\:\\s(.*)";
    private static final String IMPORT_ERR_FILE = "import.err";    
    
    private final ZooKeeperClient zkc;
    
    public ZooKeeperTreeImporter(ZooKeeperClient zkc) {
        this.zkc = zkc;
    }
    
    public void importTreeFromFile(String filePath) throws Exception 
    {
        File file = new File(filePath);
        if (!file.exists() || !file.canRead() || !file.isFile()) {
            throw new IllegalArgumentException("Can not read from the file " + filePath);
        }
        
        List<String> failedLines = importTree(makeReadable(new FileInputStream(file).getChannel()));
        
        String errFileCanonicalPath = null;
        if (!failedLines.isEmpty()) {
            logger.warn("There are {} lines that are not imported to the zookeeper", failedLines.size());

            File importFileDir = file.getParentFile();
            if (importFileDir.canWrite()) {
                long suffix = System.currentTimeMillis();
                File errFile = new File(importFileDir.getCanonicalPath() + File.separator + IMPORT_ERR_FILE + suffix);

                if (!errFile.createNewFile()) {
                    logger.error("Can not create file {} to write the lines failed during the import to zookeeper",
                            errFile.getCanonicalPath());
                    logger.error("The lines with error are: \n {} ", failedLines);
                    return;
                }

                FileOutputStream errFos = new FileOutputStream(errFile);

                try {
                    for (String failedLine : failedLines) {
                        errFos.write(failedLine.getBytes());
                    }
                } finally {
                    errFos.close();
                }

                errFileCanonicalPath = errFile.getCanonicalPath();
            } else {
                logger.error(
                        "Can not create a file to write the lines failed during the import as the directory {} is closed on write ops",
                        importFileDir.getCanonicalPath());
                logger.error("The lines with error are: \n {} ", failedLines);
            }

            if (errFileCanonicalPath != null) {
                logger.info("Lines that were not imported to the zookeeper are saved in {}", errFileCanonicalPath);
            }
        }

        logger.info("Importing of data to the zookeeper server from the file {} is finished {}", filePath,
                ((errFileCanonicalPath == null) ? "without errors" : "with errors"));        
    }
    
    public List<String> importTree(Readable source) throws Exception {

        Scanner scanner = new Scanner(source).useDelimiter(ZooKeeperTreeExporter.IMPORT_LINES_SEPARATOR_PATTERN);

        List<String> failedLines = new ArrayList<String>();

        try {
            while (scanner.hasNext()) {
                String nextLine = scanner.next();

                // removing appended during the export new line symbol
                String dataLine = nextLine.substring(0, nextLine.length() - 1);

                // Line's pattern: "<LINEMARKER><PATH> : <VALUE>"
                Pattern linePattern = Pattern.compile(ZKPATH_VALUE_REG_EXPRESSION, Pattern.DOTALL);
                Matcher lineMatcher = linePattern.matcher(dataLine);
                if (lineMatcher.matches()) {
                    if (lineMatcher.groupCount() != 2) {
                        logger.error("Number of groups ({}) is less than expected ({}). The line {} is skipped",
                                new Object[] { lineMatcher.groupCount(), "2", dataLine });
                        failedLines.add(nextLine);
                    } else {
                        String zkPath = lineMatcher.group(1);
                        String zkValue = lineMatcher.group(2);
                        logger.debug("The line {} is parsed successfuly", dataLine);

                        try {
                            zkc.createFull(zkPath, zkValue, CreateMode.PERSISTENT);
                        } catch(KeeperException e) {
                            logger.error("The line {} is not imported", e);
                            failedLines.add(nextLine);
                        }
                    }
                } else {
                    logger.error("Line {} is not matched to the expected pattern", dataLine);
                    failedLines.add(nextLine);
                }
            }
        } finally {
            scanner.close();
        }
        return failedLines;
    }
    
    private static Readable makeReadable(ReadableByteChannel source) {
        if (source == null)
            throw new NullPointerException("source");
        return Channels.newReader(source,  java.nio.charset.Charset.defaultCharset().name());
    }    
    
}
