package com.ubs.f35.core.zookeeper.client;

public class ZooKeeperClientException extends Exception {
    private static final long serialVersionUID = 8516672967293296246L;

    ZooKeeperClientException(String message) {
        super(message);
    }

    ZooKeeperClientException(String message, Throwable cause) {
        super(message, cause);
    }

    static class ZooKeeperClientConnectionTimeOutException extends ZooKeeperClientException {
        private static final long serialVersionUID = 7937315678014336159L;

        ZooKeeperClientConnectionTimeOutException(String message) {
            super(message);
        }

    }
}