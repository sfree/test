package com.ubs.f35.core.zookeeper.client;

/**
 * The interface is used in the zookeeper tree's walk functionality. Every
 * observer node is passed to this interface.
 * See {@link ZooKeeperService#walk(String, ZNodeProcessor)}
 * 
 * @author chernyse
 * 
 */
public interface ZNodeProcessor {
    /**
     * Called on every found zookeeper node during tree walk.
     * @param zNode
     * @throws Exception
     */
    void process(ZNode zNode) throws Exception;
}