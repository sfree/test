package com.ubs.f35.core.zookeeper.client.config.processors;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.core.zookeeper.client.ZNode;
import com.ubs.f35.core.zookeeper.client.ZNodeProcessor;
import com.ubs.f35.core.zookeeper.client.common.StringValueTransformer;
import com.ubs.f35.core.zookeeper.client.config.ConfigPropertyValueDecryptionProvider;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper.ConfigTagScheme;
import com.ubs.f35.core.zookeeper.utils.ConfigUtils;

/**
 * Class processes the znodes which represent literal properties.
 * It decrypts them if it is required and populates the property map with values.
 */
public class PropertyExposingNodeProcessor implements ZNodeProcessor {

    static final Logger logger = LoggerFactory.getLogger(PropertyExposingNodeProcessor.class);
    static final StringValueTransformer valueTransformer = new StringValueTransformer();

    private final String rootPath;
    private final Properties properties;
    private final ConfigPropertyValueDecryptionProvider decryptionProvider;

    public PropertyExposingNodeProcessor(String rootPath, Properties properties,
            ConfigPropertyValueDecryptionProvider decryptionProvider) {
        this.rootPath = rootPath;
        this.properties = properties;
        this.decryptionProvider = decryptionProvider;
    }

    @Override
    public void process(ZNode zNode) throws GeneralSecurityException, IOException {

        byte[] value = zNode.value();

        // skip null value nodes
        if (value == null) {
            logger.info("skipping null value node: {}", zNode.path());
            return;
        }

        String valueString = valueTransformer.fromInput(value);
        ConfigTagScheme scheme = ConfigTagSchemeHelper.parse(zNode.name());

        if (scheme.isLease()) {

            logger.info("skipping lease node: {}", zNode.path());
            return;

        } else {

            if (scheme.isEncrypted()) {

                if (decryptionProvider != null) {
                    String relativePath = ConfigUtils.erase(rootPath, zNode.parent().path());
                    String propertyKey = ConfigUtils.convertPathToProperty(relativePath);
                    logger.info("decrypting encrypted property: {}", propertyKey);
                    String decryptedValue = decryptionProvider.decrypt(propertyKey, valueString);
                    logger.info("exposing decrypted property: {}", propertyKey);
                    properties.setProperty(propertyKey, decryptedValue);
                } else {
                    logger.warn("no decryption provider set so not decrypting: {}", zNode);
                }

            } else {

                // expose literal property
                String relativePath = ConfigUtils.erase(rootPath, zNode.path());
                String propertyKey = ConfigUtils.convertPathToProperty(relativePath);
                logger.info("exposing literal property {} : {}", propertyKey, valueString);
                properties.setProperty(propertyKey, valueString);

            }

        }

    }

}