package com.ubs.f35.core.hash;

import java.util.Arrays;
import java.util.BitSet;
import java.util.Collection;


/**
 * Built on the baisis of the paper
 * http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.72.2442&rep=rep1&type=pdf 
 * Partition Schemes: h1(u) + ih2(u) mod m'
 * 
 * @author chernyse
 * 
 */
public class BloomFilter {

    final static int DEFAULT_HASH_FUNCTIONS_NUMBER = 5;

    private BitSet bitset;
    private int bitSetSize;
    private int disjointSubArraySize;

    private int k = DEFAULT_HASH_FUNCTIONS_NUMBER; // number of hash functions

    private static final HashFunction murmur = new Murmur2();
    
    private static final double defaultAccuracy = 0.000001;

    
    /**
     * Creates BloomFilter based on default false positive probability and
     * expectedNumberOfElements
     * 
     * @param expectedNumberOfElements
     */
    public BloomFilter(int expectedNumberOfElements) {
        this(defaultAccuracy, expectedNumberOfElements);
    }
    
    /**
     * Constructs an empty Bloom filter with a given false positive probability.
     * The number of bits per element and the number of hash functions is
     * estimated to match the false positive probability.
     * 
     * @param falsePositiveProbability
     *            is the desired false positive probability.
     * @param expectedNumberOfElements
     *            is the expected number of elements in the Bloom filter.
     */
    public BloomFilter(double falsePositiveProbability, int expectedNumberOfElements) {
        this((int) Math.ceil(-(double) DEFAULT_HASH_FUNCTIONS_NUMBER
                / Math.log(1 - Math.pow(falsePositiveProbability, 1.0 / (double) DEFAULT_HASH_FUNCTIONS_NUMBER))),
                expectedNumberOfElements, DEFAULT_HASH_FUNCTIONS_NUMBER);
    }

    /**
     * Constructs an empty Bloom filter. The total length of the Bloom filter
     * will be m=c*n.
     * 
     * @param c
     *            is the number of bits used per element, c = m/n, where m - size of the filter in bits.
     * @param n
     *            is the expected number of elements the filter will contain.
     * @param k
     *            is the number of hash functions used.
     */
    private BloomFilter(int c, int n, int k) {
        this.k = k;
        // "+1" is to prevent the decreasing of probability if only part of the
        // initial size is used for sub-arrays. E.g. m=c*n=14, k = 5. It is
        // better to increase m to 15 than decrease to 10.
        int expectedBitSize = (c * n / k + 1) * k;  
        int setSize = (((expectedBitSize - 1) >> 6) + 1) * 64; //taken from BitSet source code for size()
        //8388544 = 1MB - 64 Byte (which are used to code the number of hash functions used in filter), 1MB - is limit for ZK node value
        this.bitSetSize = Math.min(8388544 , setSize);
        this.disjointSubArraySize = this.bitSetSize / k;
        this.bitset = new BitSet(this.bitSetSize);
    }
    
    private BloomFilter() {}

    private int[] createHashes(byte[] data, int hashes) {
        int[] result = new int[hashes];

        int hash1 = murmur.hash(data, 1985);
        int hash2 = Arrays.hashCode(data);

        for (int i = 0; i < hashes; i++) {
            result[i] = (hash1 + i * hash2);
        }

        return result;
    }

    public void add(byte[] bytes) {
        int[] hashes = createHashes(bytes, k);
        for (int i = 0; i < hashes.length; i++) {
            int hash = hashes[i];
            bitset.set(i * disjointSubArraySize + Math.abs(hash % disjointSubArraySize), true);
        }
    }

    public void addAll(Collection<? extends byte[]> c) {
        for (byte[] element : c)
            add(element);
    }

    public boolean contains(byte[] bytes) {
        int[] hashes = createHashes(bytes, k);
        for (int i = 0; i < hashes.length; i++) {
            int hash = hashes[i];
            if (!bitset.get(i * disjointSubArraySize + Math.abs(hash % disjointSubArraySize))) {
                return false;
            }
        }
        return true;
    }

    public boolean containsAll(Collection<? extends byte[]> c) {
        for (byte[] element : c)
            if (!contains(element))
                return false;
        return true;
    }

    public boolean getBit(int bit) {
        return bitset.get(bit);
    }

    public void setBit(int bit, boolean value) {
        bitset.set(bit, value);
    }

    public BitSet getBitSet() {
        return bitset;
    }
    
    public boolean isEmpty() {
        return bitset.isEmpty();
    }
    
    // Returns a byte array of at least length 1.
    // The most significant bit in the result is guaranteed not to be a 1
    // (since BitSet does not support sign extension).
    // The byte-ordering of the result is big-endian which means the most
    // significant bit is in element 0.
    // The bit at index 0 of the bit set is assumed to be the least significant
    // bit.
    public byte[] toByteArray() {
        byte[] bytes = new byte[bitset.size() / 8 + 1]; // 1st byte is number of hash functions used to build the filter
        
        if(k > Byte.MAX_VALUE) {
            throw new IllegalArgumentException("Serialized bloom filter is not reliable as number of hash functions used is more than 127");
        }
        
        bytes[0] = (byte)k; //do not expect to use more than 127 hash functions
        for (int i = 0; i < bitset.size(); i++) {
            if (bitset.get(i)) {
                bytes[bytes.length - (i >> 3) - 1] |= 1 << (i & 7);
            }
        }
        return bytes;
    }
    
    
    private void setBitSet(BitSet bitSet) {
        this.bitset = bitSet;
    }    

    public int size() {
        return this.bitSetSize;
    }
    
    int getHashFunctionsNumber() {
        return k;
    }
    
    public static class BloomFilterReader {

        private final BloomFilter bloomFilter;
        
        public BloomFilterReader(byte[] bytes) {
            bloomFilter = fromByteArray(bytes);
        }

        // Returns a bitset containing the values in bytes.
        // The byte-ordering of bytes must be big-endian which means the most significant bit is in element 0.
        private BloomFilter fromByteArray(byte[] bytes) {
            
            if(bytes.length <= 1) {
                throw new IllegalArgumentException("Can not desirialize the filter from array of " + bytes.length +" bytes");
            }
            
            BloomFilter bf = new BloomFilter();
            bf.k = bytes[0];
            int bLength = bytes.length;
            int bLengthMinus = bLength - 1;
            int bLengthMinusMult = bLengthMinus * 8;
            
            bf.disjointSubArraySize = (int) Math.ceil(bLengthMinusMult / bf.k); 
            
            BitSet bits = new BitSet((bytes.length - 1) * 8);
            //setting the bits
            for (int i = 0; i < (bytes.length - 1) * 8; i++) {
                if ((bytes[bytes.length - i / 8 - 1] & (1 << (i % 8))) != 0) {
                    bits.set(i);
                }
            }
            
            bf.setBitSet(bits);
            return bf;
        }
        
        public BloomFilter getFilter() {
            return bloomFilter;
        }
        
        public boolean contains(byte[] bytes) {
            return bloomFilter.contains(bytes);
        }

        public boolean containsAll(Collection<? extends byte[]> c) {
            return bloomFilter.containsAll(c);
        }
    }
}
