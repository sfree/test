package com.ubs.f35.core.zookeeper.client.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.DumperOptions.FlowStyle;
import org.yaml.snakeyaml.Yaml;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * sample.literal.encrypted.property=expression: { encrypted:, value:foo }
 * 
 * sample.leased.encrypted.property=expression: { encrypted:, leased:, keys:
 * [name], values: [ [foo], [bar], [baz] ] }
 * 
 * @author bandopdh
 * 
 */
public class ConfigPropertyValueTypeHelper {

    private static final DumperOptions dumperOptions;
    static {
        DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(FlowStyle.FLOW);
        dumperOptions = options;
    }

    private static final String EMPTY = "";
    private static final String VALUE = "value";
    private static final String VALUES = "values";
    private static final String KEYS = "keys";
    private static final String LEASED = "leased";
    private static final String ENCRYPTED = "encrypted";
    private static final String EXPRESSION = "expression:";

    private boolean isExpression;
    private boolean isEncrypted;
    private boolean isLeased;

    private String originalValue;
    private String value;
    private String leaseGroupExpression;
    private List<String> leaseEntityExpressions;

    public boolean isExpression() {
        return isExpression;
    }

    public boolean isEncrypted() {
        return isEncrypted;
    }

    public boolean isLeased() {
        return isLeased;
    }

    public String getValue() {
        return value;
    }

    public String getOriginalValue() {
        return originalValue;
    }

    public String getLeaseGroupExpression() {
        return leaseGroupExpression;
    }

    public List<String> getLeaseEntityExpressions() {
        return leaseEntityExpressions;
    }

    public ConfigPropertyValueTypeHelper(String key, String value) {
        originalValue = value;
        if (value.replace(" ", EMPTY).startsWith(EXPRESSION)) {
            isExpression = true;
            Yaml yaml = new Yaml(dumperOptions);
            value = value.replaceFirst(EXPRESSION, EMPTY);
            @SuppressWarnings("rawtypes")
            Map map = (Map) yaml.load(value);
            if (map.containsKey(ENCRYPTED)) {
                isEncrypted = true;
            }
            if (map.containsKey(LEASED)) {
                isLeased = true;
                parseLeaseGroupExpression(key, yaml, map);
            }
            if (isEncrypted && !isLeased) {
                this.value = map.get(VALUE).toString();
            }
        }
    }

    public ConfigPropertyValueTypeHelper(String value) {
        this(null, value);
    }

    /**
     * Parse a compound expression and split into individual expressions.
     * 
     * Example input expression: {keys: [username, password, timeout], values:
     * [[u1, p1, t1], [ u2, p2, t2], [u3, p3, t3]]}
     * 
     * Example output expression: {username: u1, password: p1, timeout: t1}
     * 
     * @param yaml
     * @param map
     * @return
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    private void parseLeaseGroupExpression(String key, Yaml yaml, Map map) {

        List keyGroup = (List) map.get(KEYS);
        List valueGroup = (List) map.get(VALUES);
        List<String> childExpressions = Lists.newArrayList();

        for (int i = 0; i < valueGroup.size(); i++) {
            Map properties = Maps.newLinkedHashMap();
            List values = (List) valueGroup.get(i);
            for (int j = 0; j < values.size(); j++) {
                String expandedKey = null;
                if (key != null) {
                    expandedKey = String.format("%s.%s", key, keyGroup.get(j));
                } else {
                    expandedKey = keyGroup.get(j).toString();
                }
                properties.put(expandedKey, values.get(j));
            }
            childExpressions.add(yaml.dump(properties).trim());
        }

        this.leaseEntityExpressions = childExpressions;

        if (isEncrypted) {
            map.remove(ENCRYPTED);
        }

        map.remove(LEASED);

        if (key != null) {
            List<String> expandedKeyGroup = new ArrayList<String>();
            for (Object o : keyGroup) {
                String leaseGroupKey = o.toString();
                expandedKeyGroup.add(String.format("%s.%s", key, leaseGroupKey));
            }
            map.put(KEYS, expandedKeyGroup);
        }

        leaseGroupExpression = yaml.dump(map).trim();
    }

    /**
     * Parse a single expression into Java.
     * 
     * Example input expression: {username: u1, password: p1, timeout: t1}
     * 
     * @param expression
     * @return Map of property key value pairs
     */
    @SuppressWarnings("rawtypes")
    public static Map parseLeaseEntityExpression(String expression) {
        Yaml yaml = new Yaml(dumperOptions);
        Object object = yaml.load(expression);
        return (Map) object;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static List<String> extractKeysFromLeaseGroupExpression(String expression) {
        Yaml yaml = new Yaml(dumperOptions);
        Object mapObject = yaml.load(expression);
        Map map = (Map) mapObject;
        List list = (List) map.get(KEYS);
        return list;
    }

}