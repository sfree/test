package com.ubs.f35.core.zookeeper.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DefaultZNode implements ZNode {

    protected String path;
    protected String name;
    protected Integer relativeOffset;
    protected boolean leaf;
    protected byte[] value;
    protected DefaultZNode parent;
    protected List<ZNode> children;
    protected ZNodeType type;

    public DefaultZNode() {
    }

    public DefaultZNode(String path, ZNodeType type, Integer relativeOffset, boolean leaf, byte[] value) {
        this(path, type, relativeOffset, leaf, value, null, null);
    }

    public DefaultZNode(String path, ZNodeType type, Integer relativeOffset, boolean leaf, byte[] value, DefaultZNode parent,
            List<ZNode> children) {
        this.path = path;
        this.name = path.substring(path.lastIndexOf('/') + 1);
        this.relativeOffset = relativeOffset;
        this.leaf = leaf;
        this.value = value;
        this.parent = parent;
        this.children = children == null ? new ArrayList<ZNode>() : children;
        this.type = type;
    }

    @Override
    public boolean isEphemeral() {
        return type == ZNodeType.EPHEMERAL;
    }

    @Override
    public String path() {
        return path;
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public Integer relativeOffset() {
        return relativeOffset;
    }

    @Override
    public boolean isLeaf() {
        return leaf;
    }

    @Override
    public byte[] value() {
        return value;
    }

    @Override
    public DefaultZNode parent() {
        return parent;
    }

    @Override
    public List<ZNode> children() {
        return children;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Node [path=").append(path).append(", type=").append(type).append(", relativeOffset=")
                .append(relativeOffset).append(", leaf=").append(leaf).append(", value=")
                .append(Arrays.toString(value)).append("]");
        return builder.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((path == null) ? 0 : path.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DefaultZNode other = (DefaultZNode) obj;
        if (path == null) {
            if (other.path != null)
                return false;
        } else if (!path.equals(other.path))
            return false;
        return true;
    }

}