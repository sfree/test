package com.ubs.f35.core.zookeeper.client.config.api;

public class CommandLineException extends RuntimeException {

    public CommandLineException() {}
    
    public CommandLineException(String message) {
        super(message);
    }
    
    public int exitCode() {
        return -1;
    }

    
    /**
     * Custom exceptions
     *
     */
    
    public static class MissedLeaseGroupException extends CommandLineException {
        
        public int exitCode() {
            return -2;
        }
    }
    
    public static class MissedLeaseValueException extends CommandLineException {
        public int exitCode() {
            return -3;
        }
    }
    
    public static class NoPathException extends CommandLineException {
        public int exitCode() {
            return -4;
        }
    }    
    
    public static class ShortPathToDeleteException extends CommandLineException {
        public int exitCode() {
            return -5;
        }
    }    
    
    public static class LeaseValueLockedException extends CommandLineException {
        public int exitCode() {
            return -6;
        }
    }    
    
}
