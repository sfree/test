package com.ubs.f35.core.zookeeper.client.config.api;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.NoNodeException;
import org.apache.zookeeper.KeeperException.NodeExistsException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.data.Stat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Strings;
import com.ubs.f35.core.zookeeper.client.ZNode;
import com.ubs.f35.core.zookeeper.client.ZNodeNavigator;
import com.ubs.f35.core.zookeeper.client.ZNodeProcessor;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.common.StringValueTransformer;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper.ConfigTagScheme;

public class ZooKeeperConfigService extends ZooKeeperService {

    private static final Logger logger = LoggerFactory.getLogger(ZooKeeperConfigService.class);
    
    public static final String ZOOKEEPER_CONFIG_ROOT_PATH = "/f35/config";
    
    private static final String ENCRYPTED_VALUE = "<< ENCRYPTED_VALUE >>";
    public static final String FREED_VALUE = "FREED";
    private static final StringValueTransformer valueTransformer = new StringValueTransformer();
    
    private final Map<String, byte[]> acquiredLeaseValues = new HashMap<String, byte[]>(5);
    private final ExecutorService leaseCheckerService;

    public ZooKeeperConfigService(ZooKeeperClient zkc) {
        super(zkc);
        this.leaseCheckerService = Executors.newSingleThreadExecutor(new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                t.setName("LeaseCheckerThread");
                return t;
            }
        });
    }

    @Override
    public void prettyPrint(String rootPath) throws Exception {
        System.out.println();
        walk(rootPath, new ZNodeProcessor() {
            @Override
            public void process(ZNode znode) {
                ConfigTagScheme scheme = ConfigTagSchemeHelper.parse(znode.name());
                String value = null;
                if (scheme.isEncrypted()) {
                    value = ENCRYPTED_VALUE;
                } else {
                    value = valueTransformer.fromInput(znode.value());
                }
                System.out.println(String.format("%s * %s (%s) : %s", Strings.repeat("  ", znode.relativeOffset()),
                        znode.path(), znode.relativeOffset(), value));
            }
        });
        System.out.println();
    }

    private void reRegisterLeaseLock(String applicationId, ZNode leasingValue, ZNode oldLock) throws InterruptedException {
        String path = oldLock.path();
        logger.info("Re-registering the lease node lock {} for the application {}", path, applicationId);
        try {
            try {
                zkc.delete(path);
            } catch (NoNodeException e) {
                logger.error("Node {} is not removed as it does not exist anymore", path);
            }
            createLockNode(applicationId, path);
        } catch (KeeperException e) {
            logger.error("Can not re-register lease node lock", e);
        }
    }

    private ZNode reaqcuireOldLock(String applicationId, ZNode leaseProvider) throws InterruptedException 
    {
        for(ZNode leaseChild : leaseProvider.children()) {
            if (!leaseChild.isLeaf()) {
                //checking if the node was leased by me (applicationId)
                List<ZNode> leaseChildLocks = leaseChild.children();
                for(ZNode lock : leaseChildLocks) {
                    if(applicationId.equals(valueTransformer.fromInput(lock.value()))) {
                        // we need to re-register leased lock as it is ephemeral
                        // and belongs to the different zookeeper session  
                        reRegisterLeaseLock(applicationId, leaseChild, lock);
                        return leaseChild;
                    }
                }
            }
        }
        return null;
    }
    
    public ZNode acquireLease(String applicationId, ZNode leaseProvider, String fixedNumber) throws InterruptedException {

        logger.info("requesting lease on parent: {}", leaseProvider.path());
        
        if(fixedNumber!=null)
          logger.info("caller has requested fixed lease number: {}", fixedNumber);
        
        // Looking for my old locks (remained in the tree because of still live sessionTimeout
        // period during which the ephemeral nodes are not removed) 
        ZNode reaqcuiredLock = reaqcuireOldLock(applicationId, leaseProvider);
        if(reaqcuiredLock != null) {
            logger.info("lock for {} is reacquired", reaqcuiredLock.parent().path());
            return reaqcuiredLock;
        }
        
        //If old locks are not found trying to find free lease value
        // for each leaf node try to acquire lease
        for (ZNode leaseChild : leaseProvider.children()) {
            
            // skip already leased child
            if (!leaseChild.isLeaf()) {
                logger.info("skipping node; already leased: {}", leaseChild.path());
                continue;
            }

            logger.info("found leasable node: {}", leaseChild.path());
            
            if(fixedNumber!=null) {
              
              if(!leaseChild.name().endsWith(":"+fixedNumber)) {
                logger.info("Ignoring leasable node because a fixed id of {} was requested",fixedNumber);
                continue;
              }
              
              logger.info("Leasable node passes the fixed id check");
            }
            
            String leaseAcquirerPath = leaseChild.path() + "/" + ConfigTagSchemeHelper.SCHEME_LEASE_LOCK;
            try {
                // lease available; acquire it
                createLockNode(applicationId, leaseAcquirerPath);
                acquiredLeaseValues.put(leaseChild.path(), leaseChild.value());
                return leaseChild;
            } catch (NodeExistsException e) {
                logger.info("lease already taken at {}; continuing search; exception: {}", leaseAcquirerPath, e.toString());
            }
        }

        // no lease found; terminate application startup
        throw new IllegalStateException("no lease available for property: " + leaseProvider.path());
    }
    
    private void createLockNode(String applicationId, String leaseLockPath) throws NodeExistsException, InterruptedException {
        try {
            String createdLeaseLockPath = zkc.create(leaseLockPath, applicationId, CreateMode.EPHEMERAL);
            logger.info("successfully created lease lock at {}", createdLeaseLockPath);
            
            logger.info("setting a watcher on locked lease node");
            zkc.exists(createdLeaseLockPath, new LockedLeaseNodeWatcher(applicationId, createdLeaseLockPath));
            
        } catch (NodeExistsException e) { 
            throw e;
        } catch (KeeperException e) {
            // unforeseen failure; terminate application startup
            logger.error("lease acquisition irrecoverably failed at {}", leaseLockPath);
            throw new RuntimeException(e);
        }
    }
    
    /**
     * Watcher on lock of lease entities. If the lock node is modified (e.g. removed manually or by the cluster)
     * the watcher is triggered and tried o restore the lock. 
     * 
     * @author chernyse
     *
     */
    private class LockedLeaseNodeWatcher implements Watcher, Runnable {
        
        private final String applicationId;
        private final String lockPath;
        private final String leaseEntityPath;
        private final String leaseGroupPath;
        
        public LockedLeaseNodeWatcher(String applicationId, String lockPath) {
            this.applicationId = applicationId;
            this.lockPath = lockPath;
            this.leaseEntityPath = lockPath.substring(0, lockPath.lastIndexOf("/"));
            this.leaseGroupPath = leaseEntityPath.substring(0, leaseEntityPath.lastIndexOf("/"));
        }
        
        @Override
        public void process(WatchedEvent event) {
            
            logger.info("Received event: {}", event);
            
            //submitting the task to a single thread pool to prevent blocking of watcher's caller
            if(event.getState() == KeeperState.SyncConnected || event.getState() == KeeperState.Expired) {
                leaseCheckerService.execute(this);
            }
        }

        @Override
        public void run() {
            for (int i = 0; i < 5; i++) //trying to restore 5 times if there is an exception. If no luck then give up 
            { 
                try {
                    logger.info("Watcher on locked lease node [{}] is fired. Waiting for alive connection to cluster", lockPath);
                    zkc.waitForAlive();
                    
                    //request by another process to release the watcher and stop recreating the lock node
                    if(zkc.exists(lockPath)) {
                        byte[] value = zkc.read(lockPath);
                        if(value == null) {
                            zkc.set(lockPath, FREED_VALUE);
                            logger.info("request to release the watcher on lock node completed");
                            return;
                        }
                    }

                    byte[] holdingValue = acquiredLeaseValues.get(leaseEntityPath); 
                    byte[] currentValueInZk = zkc.read(leaseEntityPath);
                    
                    if(Arrays.equals(holdingValue, currentValueInZk)) { //common case
                        
                        Stat stat = zkc.stat(lockPath);
                        
                        if (stat == null) { //node is removed by cluster
                            logger.info("Lock [{}] has gone. Reacquiring", lockPath);
                            createLockNode(applicationId, lockPath);
                            
                        } else if (zkc.getSessionId() != stat.getEphemeralOwner()) { //lease is taken by other
                            logger.error("Restoring acquired leased node {} is already taken by another instance", lockPath);
                            
                            //registering the watcher to be triggered if the holder gone.
                            //Then we will restore our lock
                            zkc.getChildren(leaseEntityPath, this); 
                            
                            //TODO: if manual lock is added this else-if block should be updated
                            
                        } else { //lock still exists
                            
                            logger.info("Lock [{}] has not changed. Restoring watcher", lockPath);
                            zkc.exists(lockPath, this); // re-register the watcher                            
                        }
                        
                    } else { //properties are uploaded while instance is disconnected and lease entities changed the order
                        
                        logger.warn("Properties were reuploaded while application was disconnected. Looking for the value which application acquired earlier");
                        
                        ZNode entityToLock = findLeaseEntityByValue(leaseGroupPath, holdingValue);
                        
                        if(entityToLock == null) { //holding value does not exist in new properties
                            
                            logger.error("Can not find holding lease value {} in zookeeper to lock.", valueTransformer.fromInput(holdingValue));
                            
                            //registering the watcher to be triggered if the missing entity is added.
                            //Then we will try to lock our value back
                            zkc.getChildren(leaseGroupPath, this);                            
                        
                        } else if(entityToLock.children().isEmpty()) { //entity with holding value is found and it is not locked by others
                            
                            createLockNode(applicationId, entityToLock.path() + "/" + ConfigTagSchemeHelper.SCHEME_LEASE_LOCK);
                        
                        } else { //entity with holding value is found but it is locked by others
                            
                            logger.error("Lease entity with holding value is found but it is already locked");
                            
                            //registering the watcher to be triggered if the holder gone.
                            //Then we will restore our lock                            
                            zkc.getChildren(entityToLock.path(), this);
                        }
                    }                    
                    return;
                    
                } catch (Exception e) {
                    logger.warn("{} Restore lock node watcher on [{}] is failed", new Object[]{i, lockPath}, e);
                }
            }
        }
        
        ZNode findLeaseEntityByValue(String leaseGroupPath, final byte[] value) throws Exception {
            
            final AtomicReference<ZNode> nodeRef = new AtomicReference<ZNode>();
            
            navigate(leaseGroupPath, new ZNodeNavigator() {
                @Override
                public NavigateResult navigate(ZNode zNode) throws Exception {
                    byte[] zValue = zNode.value();
                    if(Arrays.equals(value, zValue)) {
                        nodeRef.set(zNode);
                        return NavigateResult.TERMINATE;
                    } else {
                        return NavigateResult.CONTINUE;
                    }
                }});
            return nodeRef.get();
        }
    }
}