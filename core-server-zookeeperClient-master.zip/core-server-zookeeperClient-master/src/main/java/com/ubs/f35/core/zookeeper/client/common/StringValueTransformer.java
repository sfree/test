package com.ubs.f35.core.zookeeper.client.common;

import java.io.UnsupportedEncodingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Transformer between the string and byte array which represents zookeeper node data.
 *
 */
public class StringValueTransformer implements ValueTransformer<String, byte[]> {

    private static final Logger logger = LoggerFactory.getLogger(StringValueTransformer.class);

    public static final StringValueTransformer INSTANCE = new StringValueTransformer();
    
    String defaultEncoding = "ISO-8859-1";

    @Override
    public String fromInput(byte[] input) {
        if (input == null) {
            return null;
        }
        
        if (input.length == 0) {
            return "";
        }
        
        try {
            return new String(input, defaultEncoding);
        } catch (UnsupportedEncodingException e) {
            logger.error("", e);
            return null;
        }
    }

    @Override
    public byte[] toOutput(String input) {
        if (input == null) {
            return null;
        } else {
            try {
                return input.getBytes(defaultEncoding);
            } catch (UnsupportedEncodingException e) {
                logger.error("", e);
                return null;
            }
        }
    }

}