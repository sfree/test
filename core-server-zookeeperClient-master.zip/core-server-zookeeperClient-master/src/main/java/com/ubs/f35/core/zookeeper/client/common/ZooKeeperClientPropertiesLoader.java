package com.ubs.f35.core.zookeeper.client.common;

import java.io.IOException;
import java.util.Properties;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;

import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.google.common.collect.Sets;
import com.ubs.f35.core.zookeeper.utils.PropertyUtils;

/**
 * Loads the zookeper client properties from CLASSPATH.
 *
 */
public class ZooKeeperClientPropertiesLoader {

    static final Logger logger = LoggerFactory.getLogger(ZooKeeperClientPropertiesLoader.class);

    // system keys

    public static final String ENV = "env";
    public static final String GROUP_ID = "f35.group";
    public static final String ARTIFACT_ID = "f35.artifact";
    public static final String VERSION = "f35.version";
    
    private static final Set<String> GAV_PROPERTY_NAMES = Sets.newHashSet(ENV, GROUP_ID, ARTIFACT_ID, VERSION);

    // zookeeper client keys

    public static final String HOST_PORTS = "zookeeper.client.host.ports";
    public static final String SESSION_TIMEOUT = "zookeeper.client.session.timeout";
    public static final String CONNECTION_TIMEOUT = "zookeeper.client.connection.timeout";
    public static final String USERNAME = "zookeeper.client.username";
    public static final String PASSWORD = "zookeeper.client.password";
    public static final String RECONNECT_INTERVAL = "zookeeper.client.reconnectInterval";
    public static final String RECONNECT_ON_EXPIRATION = "zookeeper.client.reconnectOnExpiration";

    public static final String DEFAULT_RESOURCE_PATH = "classpath:/properties/zookeeper-client.properties";
    public static final String EMPTY_VALUE = "<null>";

    /**
     * @return zookepeer client properties if found or null otherwise
     */
    public Properties loadFromPathSilent() {
        try {
            return loadFromPath();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Loads the zookeeper client properties from CLASSPATH by the default path 'properties/zookeeper-client.properties'
     * @return client properties or throws runtime exception is the given path is not found
     */
    public Properties loadFromPath() {
        return loadFromResource(DEFAULT_RESOURCE_PATH);
    }
    
    /**
     * Loads the zookeeper client properties from CLASSPATH by the given path
     * @param path
     * @return client properties or throws runtime exception is the given path is not found
     */
    public Properties loadFromPath(String path) {
        logger.info("loading property file from classpath:{}", path);
        Properties p = PropertyUtils.loadFromClassPath(path);
        validateZooKeeperProperties(p);
        return p;
    }    
    
    /**
     * Loads the zookeeper client properties from a resource, using a Spring resource uri
     * @param path A Spring {@link Resource} path.
     * @return
     */
    public Properties loadFromResource(String path) {
        return loadFromResource(new DefaultResourceLoader().getResource(path));
    }
    
    /**
     * Loads from the provided Spring {@link Resource}
     * @param resource
     * @return
     */
    public Properties loadFromResource(Resource resource) {
        Properties props = new Properties();
        try {
            props.load(resource.getInputStream());
        } catch (IOException e) {
            throw new IllegalArgumentException("Failed to load Properties from: " + resource, e);
        }
        validateZooKeeperProperties(props);
        
        return props;        
    }
    
    public Properties loadFromResourceSilent(Resource resource) {
        try {
            return loadFromResource(resource);
        } catch (Exception e) {
            return null;
        }        
    }
    
    /**
     * Loads only the following system properties:
     * <ul>
     * <li>{@value #GROUP_ID}</li>
     * <li>{@value #ARTIFACT_ID}</li>
     * <li>{@value #VERSION}</li>
     * <li>{@value #ENV}</li>
     * </ul>
     * @return
     */
    public Properties loadGroupArtifactVersionEnvSystemProperties() {
        return loadFromSystem(GAV_PROPERTY_NAMES, false);
    }

    /**
     * Loads the zookeeper client properties from the system properties
     * @param requiredProperties - list of required client properties
     * @return
     */
    public Properties loadFromSystem(Set<String> requiredProperties) {
        return loadFromSystem(requiredProperties, true);
    }
    
    private Properties loadFromSystem(Set<String> requiredProperties, boolean validateZookeeperProperties) {
        validateProperties(System.getProperties(), requiredProperties);
        if (validateZookeeperProperties) {
            validateZooKeeperProperties(System.getProperties());
        }
        Properties p = new Properties();
        for (String propertyName : requiredProperties) {
            p.setProperty(propertyName, System.getProperty(propertyName));
        }
        return p;
    }    

    private void validateSystemProperty(String key, Properties properties) {
        Preconditions.checkArgument(!Strings.isNullOrEmpty(properties.getProperty(key)),
                "%s system property not found", key);
    }

    private void validateProperties(Properties properties, Set<String> propsToCheck) {
        for (String propName : propsToCheck) {
            validateSystemProperty(propName, properties);
        }
    }

    private void validateZooKeeperProperties(Properties properties) {
        validateSystemProperty(HOST_PORTS, properties);
        validateSystemProperty(SESSION_TIMEOUT, properties);
        validateSystemProperty(CONNECTION_TIMEOUT, properties);
        validateSystemProperty(USERNAME, properties);
        validateSystemProperty(PASSWORD, properties);
    }

}