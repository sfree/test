package com.ubs.f35.core.zookeeper.client.common;

import java.util.LinkedList;

import com.ubs.f35.core.zookeeper.client.ZNode;

public class ZNodePathList extends LinkedList<String> {

    private static final long serialVersionUID = 6518855360975961173L;
    private static final String SLASH = "/"; 
    
    private final String zNodePath; 
    
    public ZNodePathList(ZNode znode) {
        if(znode == null) {
            throw new IllegalArgumentException("ZNode can not be null");
        }
        zNodePath = znode.path();
        process();
    }
    
    public ZNodePathList(String zNodePath) {
        this.zNodePath = zNodePath;
        process();
    }
    
    void process() {
        String[] pathUnitComponents = zNodePath.split(SLASH);
        for(String each : pathUnitComponents) {
            if(!each.isEmpty())
                this.add(each);
        }
    }
    
    public String toPath() {
        PathBuilder pathBuilder = new PathBuilder();
        for(String each : this) {
            pathBuilder.appendAsIs(each); 
        }
        return pathBuilder.toString();
    }
    
    public void addFirst(String pathUnit) {
        String[] pathUnitComponents = pathUnit.split(SLASH);
        for(int i = pathUnitComponents.length - 1; i >= 0; i--)
            super.addFirst(pathUnitComponents[i]);
    }
    
    public void addLast(String pathUnit) {
        String[] pathUnitComponents = pathUnit.split(SLASH);
        for(int i = 0; i < pathUnitComponents.length; i++)
            super.addLast(pathUnitComponents[i]);
    }    
}