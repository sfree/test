package com.ubs.f35.core.zookeeper.client.config.api;

import java.util.List;
import java.util.Properties;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.common.PathBuilder;
import com.ubs.f35.core.zookeeper.client.common.ZookeeperRootPathResolver;
import com.ubs.f35.core.zookeeper.client.config.ConfigPropertyValueTypeHelper;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper;
import com.ubs.f35.core.zookeeper.utils.ConfigUtils;
import com.ubs.f35.core.zookeeper.utils.PropertyUtils;

/**
 * Imports the property file to the zookeeper cluster.
 * One need to provide group/artifact/version for the importing properties.
 * 
 * Locked lease properties are not checked and just removed
 *
 */
public class ZooKeeperPropertyFileImporter {

    static final Logger logger = LoggerFactory.getLogger(ZooKeeperPropertyFileImporter.class);

    private ZooKeeperClient zkc;
    private ZooKeeperService zks;
    private String rootPath;

    ZooKeeperPropertyFileImporter(ZooKeeperService zks) {
        this(zks, new ZookeeperRootPathResolver(ZooKeeperConfigService.ZOOKEEPER_CONFIG_ROOT_PATH));
    }
    
    public ZooKeeperPropertyFileImporter(ZooKeeperService zks, ZookeeperRootPathResolver resolver) {
        this.zkc = zks.getClient();
        this.zks = zks;
        rootPath = resolver.resolveApplicationRootPath();
    }

    void stop() throws InterruptedException {
        if (zks != null) {
            zks.stop();
        }
    }

    void importFromPath(String pathToFile) throws Exception {
        logger.info("deleting subtree under root path: {}", rootPath);
        zks.deleteSubTree(rootPath);
        logger.info("loading {} from path", pathToFile);
        Properties properties = PropertyUtils.loadFromFilePath(pathToFile);
        importProperties(properties);
    }

    void importFromClassPath(String fileName) throws Exception {
        logger.info("deleting subtree under root path: {}", rootPath);
        zks.deleteSubTree(rootPath);
        logger.info("loading {} from classpath", fileName);
        Properties properties = PropertyUtils.loadFromClassPath(fileName);
        importProperties(properties);
    }

    void importMultipleFromPath(List<String> filePaths) throws Exception {
        logger.info("attempting to load the following property files in order: {}", filePaths);
        Properties properties = null;
        for (String filePath : filePaths) {
            logger.info("loading property file: {}", filePath);
            properties = PropertyUtils.loadFromFilePath(filePath, properties);
            logger.info("loaded {} properties from file: {}", properties.size(), filePath);
        }
        logger.info("deleting subtree under root path: {}", rootPath);
        zks.deleteSubTree(rootPath);
        logger.info("importing properties for all file paths supplied: {}", filePaths);
        importProperties(properties);
    }

    /**
     * sample.literal.property=foo
     * 
     * sample.literal.encrypted.property=expression: { encrypted:, value:foo }
     * 
     * sample.leased.encrypted.property=expression: { encrypted:, leased:, keys:
     * [name], values: [ [foo], [bar], [baz] ] }
     */
    public void importProperties(Properties properties) throws KeeperException, InterruptedException {

        logger.info("creating root path: {}", rootPath);
        zkc.createFull(rootPath, CreateMode.PERSISTENT);

        for (String key : properties.stringPropertyNames()) {
            String propertyPath = ConfigUtils.convertPropertyToPath(key);
            String propertyValue = properties.getProperty(key);

            ConfigPropertyValueTypeHelper propertyValueTypeHelper = new ConfigPropertyValueTypeHelper(key,
                    propertyValue);
            if (!propertyValueTypeHelper.isExpression()) {

                // NOT EXPRESSION
                importLiteral(propertyPath, propertyValue);

            } else {

                // EXPRESSION

                if (propertyValueTypeHelper.isEncrypted() && !propertyValueTypeHelper.isLeased()) {

                    // ENCRYPTED AND NOT LEASED
                    String fullPath = new PathBuilder().verbatim(rootPath).appendNormalised(propertyPath)
                            .verbatim(ConfigTagSchemeHelper.SCHEME_ENCRYPTED_NODE).toString();
                    logger.info("creating encrypted property {} : {}", fullPath, propertyValue);
                    zkc.createFull(fullPath, propertyValueTypeHelper.getValue(), CreateMode.PERSISTENT);

                } else if (propertyValueTypeHelper.isEncrypted() && propertyValueTypeHelper.isLeased()) {

                    // ENCRYPTED AND LEASED
                    importLeasedProperty(key, propertyPath, propertyValueTypeHelper, true);

                } else if (!propertyValueTypeHelper.isEncrypted() && propertyValueTypeHelper.isLeased()) {

                    // NOT ENCRYPTED BUT LEASED
                    importLeasedProperty(key, propertyPath, propertyValueTypeHelper, false);

                } else {                    
                    // UNRECOGNIZED EXPRESSION - IMPORT AS LITERAl
                    logger.info("Unrecognized expression type. Importing as literal value: {}", propertyValue);
                    importLiteral(propertyPath, propertyValue);
                }
            }
        }
    }

    private void importLiteral(String propertyPath, String propertyValue) throws KeeperException, InterruptedException {
        String fullPath = new PathBuilder().verbatim(rootPath).appendNormalised(propertyPath).toString();
        logger.info("creating literal property {} : {}", fullPath, propertyValue);
        zkc.createFull(fullPath, propertyValue, CreateMode.PERSISTENT);
    }

    void importLeasedProperty(String propertyKey, String propertyPath,
            ConfigPropertyValueTypeHelper propertyValueTypeHelper, boolean encrypted) throws KeeperException,
            InterruptedException {

        ConfigTagSchemeHelper leaseGroupHelper = new ConfigTagSchemeHelper().addLease().addLeaseGroup();
        if (encrypted) {
            leaseGroupHelper.addEncrypted();
        }
        leaseGroupHelper.addNode();
        String leaseGroupNodeName = leaseGroupHelper.toString();
        logger.info("using leaseGroupNodeName: {}", leaseGroupNodeName);

        String fullLeaseGroupPath = new PathBuilder().verbatim(rootPath).appendNormalised(propertyPath)
                .appendNormalised(leaseGroupNodeName).toString();
        logger.info("creating leased property {} : {}", fullLeaseGroupPath, propertyValueTypeHelper.getOriginalValue());
        zkc.createFull(fullLeaseGroupPath, propertyValueTypeHelper.getLeaseGroupExpression(), CreateMode.PERSISTENT);

        List<String> leaseEntityValues = propertyValueTypeHelper.getLeaseEntityExpressions();
        logger.info("resolved lease entity expressions: {}", leaseEntityValues);

        ConfigTagSchemeHelper leaseEntityHelper = new ConfigTagSchemeHelper().addLease().addLeaseEntity();
        if (encrypted) {
            leaseEntityHelper.addEncrypted();
        }
        leaseEntityHelper.addSeparator();
        String leaseEntityNodeName = leaseEntityHelper.toString();
        logger.info("using leaseEntityNodeName: {}", leaseEntityNodeName);

        for (int i = 0; i < leaseEntityValues.size(); i++) {
            String singleLeaseValue = leaseEntityValues.get(i);
            String leaseAcquirerPath = leaseEntityNodeName + (i + 1);
            String fullLeasePath = new PathBuilder().verbatim(fullLeaseGroupPath).appendNormalised(leaseAcquirerPath).toString();
            logger.info("creating leased property child {} : {}", fullLeasePath, singleLeaseValue);
            zkc.createFull(fullLeasePath, singleLeaseValue, CreateMode.PERSISTENT);
        }
    }

}