package com.ubs.f35.core.zookeeper.client.config;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.util.HashMap;
import java.util.Map;

import org.bouncycastle.util.encoders.Base64;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.core.io.Resource;
import org.springframework.util.StringUtils;

import com.ubs.security.encryption.SecurityProvider;
import com.ubs.security.encryption.rsa.RSAKeyFileLoader;
import com.ubs.security.encryption.rsa.RSASecurityProvider;

public class ConfigPropertyValueDecryptionProvider {
    
    private Map<Object, String> encryptedValues = new HashMap<Object, String>();

    private String decryptionKeyFilePath;
    private String decryptionKeyClassPath;
    private Resource decryptionKeyResource;

    private SecurityProvider<byte[],byte[]> rsaSecurityProvider;

    public void init() throws Exception {
      
      // backwards compatible support for the old method (which really should have had its own init-method!)
      
      if(rsaSecurityProvider instanceof RSASecurityProvider)
        ((RSASecurityProvider)rsaSecurityProvider).init();
    }

    protected PublicKey getPublicKey() throws NoSuchAlgorithmException, InvalidKeySpecException, IOException{
        if (decryptionKeyResource != null && decryptionKeyResource.exists()) {
            return RSAKeyFileLoader.loadPublicKeyFromInputStream(decryptionKeyResource.getInputStream());
        } else if (StringUtils.hasText(decryptionKeyClassPath)){
            return RSAKeyFileLoader.loadPublicKeyFromClasspath(decryptionKeyClassPath);
        }else if (StringUtils.hasText(decryptionKeyFilePath)){
            return RSAKeyFileLoader.loadPublicKey(decryptionKeyFilePath);
        }else{
            throw new IOException("A decryptionKeyClassPath or decryptionKeyFilePath must be provided");
        }
    }
    public String decrypt(String key, String propertyValue) throws GeneralSecurityException, IOException {
        encryptedValues.put(key, propertyValue);
        byte[] propertyValueBytes = propertyValue.getBytes(SecurityProvider.DEFAULT_CHARSET);
        byte[] decoded = Base64.decode(propertyValueBytes);
        PublicKey publicKey = getPublicKey();
        byte[] outputBytes = rsaSecurityProvider.decrypt(decoded, publicKey);
        String output = new String(outputBytes, SecurityProvider.DEFAULT_CHARSET);
        return output;
    }
    
    public boolean hasEncryptedValue(Object key) {
        return encryptedValues.containsKey(key);
    }
    
    public String getEncryptedValue(Object key) {
        return encryptedValues.get(key);
    }

    /**
     * @return the decryptionKeyClassPath
     */
    public String getDecryptionKeyClassPath() {
        return decryptionKeyClassPath;
    }

    /**
     * @param decryptionKeyClassPath the decryptionKeyClassPath to set
     * @deprecated Use {@link #setDecryptionKeyResource(Resource)} instead.
     */
    @Deprecated
    public void setDecryptionKeyClassPath(String decryptionKeyClassPath) {
        this.decryptionKeyClassPath = decryptionKeyClassPath;
    }
    
    /**
     * @param decryptionKeyFilePath the decryptionKeyFilePath to set
     * @deprecated Use {@link #setDecryptionKeyResource(Resource)} instead.
     */
    @Deprecated
    public void setDecryptionKeyFilePath(String decryptionKeyFilePath) {
        this.decryptionKeyFilePath = decryptionKeyFilePath;
    }
    
    /**
     * @param decryptionKeyResource The Spring {@link Resource} containing the decryption key.
     */
    public void setDecryptionKeyResource(Resource decryptionKeyResource) {
        this.decryptionKeyResource = decryptionKeyResource;
    }

    @Required
    public void setRsaSecurityProvider(SecurityProvider<byte[],byte[]> securityProvider) {
        this.rsaSecurityProvider = securityProvider;
    }
}