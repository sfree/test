package com.ubs.f35.core.zookeeper.client.config.api;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.ubs.f35.core.zookeeper.client.ZNode;
import com.ubs.f35.core.zookeeper.client.ZNodeProcessor;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClientException;
import com.ubs.f35.core.zookeeper.client.common.StringValueTransformer;
import com.ubs.f35.core.zookeeper.client.common.ZooKeeperClientPropertiesLoader;
import com.ubs.f35.core.zookeeper.client.common.ZookeeperRootPathResolver;
import com.ubs.f35.core.zookeeper.client.config.ConfigPropertyValueDecryptionProvider;
import com.ubs.f35.core.zookeeper.client.config.ConfigPropertyValueTypeHelper;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper.ConfigTagScheme;
import com.ubs.f35.core.zookeeper.client.config.processors.LeasePropertyFindingNodeProcessor;
import com.ubs.f35.server.support.annotation.NeoSupport;

/**
 * The class replaces the original Spring's
 * {@link PropertyPlaceholderConfigurer}. It consumes the property values from
 * the zookeeper cluster. </p> On startup: </br>If the zookeeper clients
 * properties are found it goes to the cluster for the property values. </br>If
 * the zookeeper clients properties are not found it dedicates the work to the
 * original {@link PropertyPlaceholderConfigurer}. </p>
 * 
 * If the group/artifact/version properties are not found in the zookeeper
 * cluster the execution is halted.
 * 
 * There are four supported property types:
 * <ul>
 * <li>Literal (usual ones)</li>
 * <li>Encrypted literal</li>
 * <li>Leased</li>
 * <li>Encrypted leased</li>
 * </ul>
 * 
 * </br>All encrypted properties are decrypted using
 * {@link ConfigPropertyValueDecryptionProvider}. </br>Leased property values
 * are presented in format of yaml expression and parsed by
 * {@link ConfigPropertyValueTypeHelper#parseLeaseEntityExpression(String)}
 * 
 * </p>
 * 
 * Acquired leased property value is marked as taken by creation of child
 * ephemeral znode under corresponding leased property value node, see
 * {@link ZooKeeperConfigService#acquireLease(ZNode)}. *
 * 
 * 
 */
@ManagedResource(description="Provides access to the application properties")
public class ZooKeeperPropertyPlaceholderConfigurer extends com.ubs.f35.core.zookeeper.client.config.api.PropertyPlaceholderConfigurer {

    private static final String OVERRIDE_SEPARATOR = "/";
    
    static final Logger logger = LoggerFactory.getLogger(ZooKeeperPropertyPlaceholderConfigurer.class);
    static final StringValueTransformer valueTransformer = new StringValueTransformer();
    
    private ConfigPropertyValueDecryptionProvider decryptionProvider;

    private boolean usePropertyFileOnly=false;
    private boolean trimProperties=false;
    
    private boolean exitOnUnavailableLeasedProperties=true;


    private final static String lineSeparator = System.getProperty("line.separator");
    
    ZooKeeperConfigService zkcs;
    Properties zooKeeperClientProperties;
    Map<String, ZNode> placeholderToLeaseGroupNodeMapping = Collections.emptyMap();
    private Properties mergedProperties;
    
    private Resource zooKeeperClientPropertiesLocation = new DefaultResourceLoader().getResource(ZooKeeperClientPropertiesLoader.DEFAULT_RESOURCE_PATH);
    
    private Resource entitlementsPropertiesLocation;
    
    // allows teams to override the group / artifact / version
    String overriddenGroupId;
    String overriddenArtifactId;
    String overriddenVersion;
    
    private Properties copyOfMergedProperties;


    @Override
    protected String resolvePlaceholder(String placeholder, Properties springProperties) {
        
        ZNode leaseGroupNode = placeholderToLeaseGroupNodeMapping.get(placeholder);

        if (leaseGroupNode == null) {

            String value = super.resolvePlaceholder(placeholder, springProperties);
            return value;

        } else {
            
            try {

                // resolve a previously leased placeholder
                String leasedPropertyValue = springProperties.getProperty(placeholder);
                if (leasedPropertyValue != null) {
                    logger.info("resolved pre-leased placeholder: {}={}", placeholder, leasedPropertyValue);
                    return leasedPropertyValue;
                }

                String applicationId = springProperties.getProperty(APPLICATION_ID_PROPERTY_NAME);
                
                // lease and resolve a new leased placeholder
                logger.info("resolving leased placeholder: {}", placeholder);
                logger.info("acquiring lease under lease group node: {} for applicationId: {}", leaseGroupNode.path(), applicationId);
                
                String fixedLeaseNumber,fixedLeaseName;
                int pos;
                
                // if resolving a leased placeholder and there is a leasedpropname.fixed value then
                // the user wants to fix the leased property entry that they get to the one identified
                // by the numeric 1..n value of leasedpropname.fixed (written for cash equities)
                
                if((pos=placeholder.lastIndexOf('.'))!=-1) {
                  
                  fixedLeaseName=placeholder.substring(0,pos)+".fixed";
                  fixedLeaseNumber=decodeFixedLeaseNumber(fixedLeaseName,springProperties);
                }
                else
                  fixedLeaseNumber=null;
                
                ZNode leaseEntity = zkcs.acquireLease(applicationId, leaseGroupNode, fixedLeaseNumber);
                
                logger.info("acquired lease on lease entity: {}", leaseEntity.path());
                exposeAllLeasedPropertiesInEntity(placeholder, leaseEntity, springProperties);
                return springProperties.getProperty(placeholder);

            } catch (Throwable t) {
                logger.error("failed to resolve placeholder: " + placeholder, t);
                
                if(exitOnUnavailableLeasedProperties){
                    throw(new RuntimeException(t));
                }
                
                return null;
            }
        }
    }


    /*
     * Convert leased name (e.g. myleasedprop.fixed) to a possible fixed number (1..n) 
     */
    
    private String decodeFixedLeaseNumber(String fixedLeaseName,Properties props) {
                
      String fixedLeaseNumber;
      
      // sanity
      
      if(fixedLeaseName==null)
        return null;
            
      // try for a regular substitution
      
      if((fixedLeaseNumber=resolvePlaceholder(fixedLeaseName,props))==null)
        return null;
      
      if(stringIsNumber(fixedLeaseNumber))
        return fixedLeaseNumber;

      // now try for a ${whatever} substitution. cannot use the non-deprecated replacement
      // for parseStringValue because it depends on private members in the parent
      
      if((fixedLeaseNumber=parseStringValue(fixedLeaseNumber,props,new HashSet()))==null)
        return null;
      
      if(stringIsNumber(fixedLeaseNumber))
        return fixedLeaseNumber;
      
      // all fail
      
      return null;
    }
    
    
    boolean stringIsNumber(String fixedLeaseNumber) {
      
      for(char c : fixedLeaseNumber.toCharArray())
        if(!Character.isDigit(c))
          return false;
      
      return true;
    }
    
    
    @Override
    protected Properties mergeProperties() throws IOException {
        mergedProperties = super.mergeProperties();
        
        if (copyOfMergedProperties != null) {
            copyOfMergedProperties.putAll(mergedProperties);
        }
        
        return mergedProperties;
    }    

    private String decryptLeaseEntityValue(ZNode leaseEntity, String leaseEntityKey, String leaseEntityNodeValue)
            throws GeneralSecurityException, IOException {
        if (decryptionProvider != null) {
            return decryptionProvider.decrypt(leaseEntityKey, leaseEntityNodeValue);
        } else {
            logger.warn("no decryption provider set so not decrypting: {}", leaseEntity);
            return null;
        }
    }

    @SuppressWarnings("rawtypes")
    private void exposeAllLeasedPropertiesInEntity(String placeholder, ZNode leaseEntity, Properties springProperties)
            throws GeneralSecurityException, IOException {
        String leaseEntityExpression = valueTransformer.fromInput(leaseEntity.value());
        ConfigTagScheme scheme = ConfigTagSchemeHelper.parse(leaseEntity.name());
        Map propertyGroup = ConfigPropertyValueTypeHelper.parseLeaseEntityExpression(leaseEntityExpression);
        for (Object o : propertyGroup.entrySet()) {
            Entry e = (Entry) o;
            String key = e.getKey().toString();
            String value = e.getValue().toString();
            if (scheme.isEncrypted()) {
                logger.info("decrypting encrypted value for node: {}", leaseEntity.path());
                value = decryptLeaseEntityValue(leaseEntity, key, value);
            }
            logger.info("resolved newly leased placeholder: {}={}", placeholder, value);
            springProperties.setProperty(key, value);
            logger.info("exposed leased property internally: {}={}", key, value);
        }
    }

    @Override
    protected void loadProperties(Properties springProperties) throws IOException {

        logger.info("loading properties");

        ZooKeeperClientPropertiesLoader zooKeeperClientPropertiesLoader = new ZooKeeperClientPropertiesLoader();
        
        zooKeeperClientProperties = zooKeeperClientPropertiesLoader.loadFromResourceSilent(zooKeeperClientPropertiesLocation);
        if (zooKeeperClientProperties != null && !zooKeeperClientProperties.isEmpty() && !usePropertyFileOnly) {

            logger.info("Loading property placeholders from zookeeper");
            logger.info("zookeeper client properties file: {}", zooKeeperClientPropertiesLocation.getFile().getCanonicalPath());
            logger.info("loaded zookeeper client properties: {}", zooKeeperClientProperties);

            try {
                
                initialiseZooKeeper();
                
                ZooKeeperPropertiesService zkPropertiesService = new ZooKeeperPropertiesService();
                zkPropertiesService.setDecryptionProvider(decryptionProvider);
                zkPropertiesService.setZooKeeperConfigService(zkcs);

                // the ids we will use to load zookeeper properties
                String groupId, artifactId, version;

                if (overriddenGroupId != null) {
                    groupId = overriddenGroupId;
                    artifactId = overriddenArtifactId;
                    version = overriddenVersion;
                    logger.info("Using overrides to load ZooKeeper properties: " + groupId + OVERRIDE_SEPARATOR + artifactId + OVERRIDE_SEPARATOR + version);
                } else {
                    Properties gavProperties = zooKeeperClientPropertiesLoader.loadGroupArtifactVersionEnvSystemProperties();
                    groupId = gavProperties.getProperty(ZooKeeperClientPropertiesLoader.GROUP_ID);
                    artifactId = gavProperties.getProperty(ZooKeeperClientPropertiesLoader.ARTIFACT_ID);
                    version = gavProperties.getProperty(ZooKeeperClientPropertiesLoader.VERSION);                    
                }
                
                String rootPath = new ZookeeperRootPathResolver(ZooKeeperConfigService.ZOOKEEPER_CONFIG_ROOT_PATH, groupId, artifactId, version).resolveApplicationRootPath();
                logger.info("using root path: {}", rootPath);                
                
                LeasePropertyFindingNodeProcessor leasePropertyFinder = new LeasePropertyFindingNodeProcessor();
                
                Properties zooKeeperProperties = zkPropertiesService.loadProperties(groupId, artifactId, version, Arrays.asList(new ZNodeProcessor[] {leasePropertyFinder}));

                Map<String, ZNode> placeholderToLeaseGroupNodeMapping = this.placeholderToLeaseGroupNodeMapping = Collections
                        .unmodifiableMap(leasePropertyFinder.getPlaceholderToLeaseGroupNodeMapping());
                logger.info("loaded {} placeholder to group node mappings", placeholderToLeaseGroupNodeMapping.size());

                if (zooKeeperProperties.isEmpty() && placeholderToLeaseGroupNodeMapping.isEmpty()) {
                    throw new IOException("no zookeeper properties found at root path: " + rootPath);
                }

                springProperties.clear();
                springProperties.putAll(zooKeeperProperties);
                populateZooKeeperClientProperties(springProperties);
                populateApplicationIdProperty(springProperties);
                logger.info("loaded {} zookeeper properties so using for resolution", zooKeeperProperties.size());

            } catch (Exception e) {
                throw new IOException("property loading failed", e);
            }

        } else {
            logger.info("zookeeper client properties not found or empty. Loading from files...");
            super.loadProperties(springProperties);
            logger.info("loaded {} spring properties", springProperties.size());            
        }
        
        loadEntitlementsProperties(springProperties);        
        trimProperties(springProperties);
    }
    
    protected void loadEntitlementsProperties(Properties springProperties) {
        if (entitlementsPropertiesLocation == null) {
            logger.info("entitlementsPropertiesLocation is null - unable to load entitlements properties");
            return;
        }
        
        try {
            logger.info("Loading entitlements properties from: " + entitlementsPropertiesLocation);
            Properties entitlementsProperties = PropertiesLoaderUtils.loadProperties(entitlementsPropertiesLocation);
            
            boolean clashFound = false;
            for (Object entitlementKey : entitlementsProperties.keySet()) {
                if (springProperties.containsKey(entitlementKey)) {
                    logger.warn("Property loaded from " + entitlementsPropertiesLocation + " already resolved by placeholder configurer: " + entitlementKey);
                    clashFound = true; // don't exit early - log all the problems in one go
                }
            }            
            
            if (clashFound) {
                logger.warn("Not using any properties from " + entitlementsPropertiesLocation + " - clashes found with properties loaded from ZooKeeper / files");
            } else {
                logger.info("Loaded an additional " + entitlementsProperties.size() + " properties from " + entitlementsPropertiesLocation);
                for (Object entitlementKey : entitlementsProperties.keySet()) {
                    springProperties.put(entitlementKey, entitlementsProperties.get(entitlementKey));
                }                  
            }
            
        } catch (IOException e) {
            logger.error("Failed to load entitlements properties from: " + entitlementsPropertiesLocation, e);  
        }
        
    }

    protected void trimProperties(Properties springProperties){
        if (isTrimProperties()){
            logger.info("Trimming aggregate property set");
            Set<Object> keys = springProperties.keySet();
            for(Object key:keys){
               Object obj = springProperties.get(key);
               if (obj instanceof String){
                   String temp= (String)obj;
                   String temp2 = temp.trim();
                   if (temp2.length() < temp.length()){
                       logger.info("Trimmed ["+temp+"] to ["+temp2+"]");
                       springProperties.put(key, ((String)obj).trim()) ;
                   }
               }
            }
        }
    }

    private void initialiseZooKeeper() throws ZooKeeperClientException {
        logger.info("initialising zookeeper client");
        ZooKeeperClient zkc = ZooKeeperClient.newFromZooKeeperClientProperties(zooKeeperClientProperties, true);
        zkcs = new ZooKeeperConfigService(zkc);
        logger.info("initialised zookeeper client");
    }

    @Override
    protected void populateZooKeeperClientProperties(Properties springProperties) {
        if (zooKeeperClientProperties == null) {
            super.populateZooKeeperClientProperties(springProperties);
        } else {
            springProperties.setProperty(ZooKeeperClientPropertiesLoader.HOST_PORTS,
                    zooKeeperClientProperties.getProperty(ZooKeeperClientPropertiesLoader.HOST_PORTS));
            springProperties.setProperty(ZooKeeperClientPropertiesLoader.SESSION_TIMEOUT,
                    zooKeeperClientProperties.getProperty(ZooKeeperClientPropertiesLoader.SESSION_TIMEOUT));
            springProperties.setProperty(ZooKeeperClientPropertiesLoader.CONNECTION_TIMEOUT,
                    zooKeeperClientProperties.getProperty(ZooKeeperClientPropertiesLoader.CONNECTION_TIMEOUT));
            springProperties.setProperty(ZooKeeperClientPropertiesLoader.USERNAME,
                    zooKeeperClientProperties.getProperty(ZooKeeperClientPropertiesLoader.USERNAME));
            springProperties.setProperty(ZooKeeperClientPropertiesLoader.PASSWORD,
                    zooKeeperClientProperties.getProperty(ZooKeeperClientPropertiesLoader.PASSWORD));
        }
    }

    public void setDecryptionProvider(ConfigPropertyValueDecryptionProvider decryptionProvider) {
        this.decryptionProvider = decryptionProvider;
    }    
    
    @PreDestroy
    public void stop() throws InterruptedException {
        if (zkcs != null) {
            zkcs.stop();
        }
    }
    
    private final Comparator<Entry<Object, Object>> comparator = new Comparator<Entry<Object, Object>>() {
        @Override
        public int compare(Entry<Object, Object> o1, Entry<Object, Object> o2) {
            return o1.getKey().toString().compareTo(o2.getKey().toString());
        }
    };
    
    @ManagedOperation(description="Returns application properties")
    public String getApplicationProperties() {
        StringBuffer buf = new StringBuffer(1000);
        buf.append(lineSeparator).append("======= Properties =======").append(lineSeparator);
        
        
        SortedSet<Entry<Object, Object>> sorted = new TreeSet<Entry<Object, Object>>(comparator);
        sorted.addAll(mergedProperties.entrySet());
        
        for(Entry<Object, Object> each : sorted) {
            Object value = each.getValue();
            if (decryptionProvider != null && decryptionProvider.hasEncryptedValue(each.getKey())) {
                value = decryptionProvider.getEncryptedValue(each.getKey());
            }
            
            buf.append(each.getKey()).append("=").append(value).append(lineSeparator);
        }
        buf.append(lineSeparator);  
        
        buf.append("======= VM Arguments =======").append(lineSeparator);
        
        sorted.clear();
        sorted.addAll(System.getProperties().entrySet());
        
        for(Entry<Object, Object> each : sorted) {
            buf.append(each.getKey()).append("=").append(each.getValue()).append(lineSeparator);
        }
        buf.append(lineSeparator);
        
        RuntimeMXBean RuntimemxBean = ManagementFactory.getRuntimeMXBean();
        List<String> aList=RuntimemxBean.getInputArguments();
        
        buf.append("======= Input Arguments =======").append(lineSeparator);
        
        for(String arg : aList) {
            buf.append(arg).append(lineSeparator);
        }
        
        return buf.toString();
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @NeoSupport(name="Config Zookeeper Client Properties")
    @ManagedOperation(description="Returns zookeeper client connection properties")
    public Map<String, String> getConfigZookeeperClientProperties() {
        if(zooKeeperClientProperties == null || zooKeeperClientProperties.isEmpty()) {
            return Collections.singletonMap("", "properties are not defined");
        } else {
            return (Map)zooKeeperClientProperties;
        }
    }
    
    public void setGavOverride(String gavOverride) {
        String[] gav = gavOverride.split(OVERRIDE_SEPARATOR);
        if (gav.length != 3) {
            throw new IllegalArgumentException("Invalid syntax for GAV. Should have format - groupId:artifactId:version");
        }
        
        this.overriddenGroupId = checkGavElement(gav[0]);
        this.overriddenArtifactId = checkGavElement(gav[1]);
        this.overriddenVersion = checkGavElement(gav[2]);
        
        logger.info("Will use overridden groupId / artifactId / version for property lookup: " + overriddenGroupId + " / " + overriddenArtifactId + " / " + overriddenVersion);
    }

    private String checkGavElement(String el) {
        if (el.trim().length() == 0) {
            throw new IllegalArgumentException("Empty GAV element - check syntax");
        }
        
        return el;
    }

    /**
     * Only override this if you know what you are doing. It changes the location that the properties will be loaded from to 
     * connect to ZooKeeper. By default they are loaded from {@value ZooKeeperClientPropertiesLoader#DEFAULT_RESOURCE_PATH}.
     * @param zooKeeperClientPropertiesPath
     */
    public void setZooKeeperClientPropertiesLocation(Resource zooKeeperClientPropertiesPath) {
        this.zooKeeperClientPropertiesLocation = zooKeeperClientPropertiesPath;
    }
    
    public boolean isUsePropertyFileOnly() {
        return usePropertyFileOnly;
    }

    public void setUsePropertyFileOnly(boolean usePropertyFileOnly) {
        this.usePropertyFileOnly = usePropertyFileOnly;
    }

    public boolean isExitOnUnavailableLeasedProperties() {
        return exitOnUnavailableLeasedProperties;
    }

    public void setExitOnUnavailableLeasedProperties(boolean exitOnUnavailableLeasedProperties) {
        this.exitOnUnavailableLeasedProperties = exitOnUnavailableLeasedProperties;
    }

    /**
     * @return the trimProperties
     */
    public boolean isTrimProperties() {
        return trimProperties;
    }

    /**
     * @param trimProperties the trimProperties to set
     */
    public void setTrimProperties(boolean trimProperties) {
        this.trimProperties = trimProperties;
    }

    public void setEntitlementsPropertiesLocation(Resource entitlementsPropertiesLocation) {
        this.entitlementsPropertiesLocation = entitlementsPropertiesLocation;
    }

    /**
     * If provided, then once the Properties have been resolved, they will be copied into this
     * @param copyOfMergedProperties
     */
    public void setCopyOfMergedProperties(Properties copyOfMergedProperties) {
        this.copyOfMergedProperties = copyOfMergedProperties;
    }
}