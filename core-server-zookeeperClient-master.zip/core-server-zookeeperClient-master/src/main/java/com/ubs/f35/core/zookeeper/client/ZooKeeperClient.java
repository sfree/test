package com.ubs.f35.core.zookeeper.client;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.zookeeper.ClientCnxn;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.Op;
import org.apache.zookeeper.OpResult;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooDefs.Perms;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.ZooKeeper.States;
import org.apache.zookeeper.data.ACL;
import org.apache.zookeeper.data.Id;
import org.apache.zookeeper.data.Stat;
import org.apache.zookeeper.server.auth.DigestAuthenticationProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

import ch.qos.logback.classic.Level;

import com.google.common.base.Splitter;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClientException.ZooKeeperClientConnectionTimeOutException;
import com.ubs.f35.core.zookeeper.client.common.StringValueTransformer;
import com.ubs.f35.core.zookeeper.client.common.ZooKeeperClientPropertiesLoader;
import com.ubs.f35.server.support.providers.ApplicationStatus;
import com.ubs.f35.server.support.providers.ApplicationStatus.Status;
import com.ubs.f35.server.support.providers.ApplicationStatusProvider;
import com.ubs.f35.server.support.providers.DefaultApplicationStatus;

/**
 * ZookeeperClient is responsible for zookeeper cluster connection management
 * and CRUD operations on tree's node. 
 * <p/>
 * If the connection is lost (internal zookeeper client haven't connected during
 * connectionTimeout interval) ZooKeeperClient creates the thread which is
 * trying to connect periodically (see {@link ReconnectonWatcher}).
 * <p/>
 * Zookeeper connection can be in different states: (see {@link KeeperState})
 * <ul>
 * <li>Disconnected</li>
 * <li>SyncConnected</li>
 * <li>AuthFailed</li>
 * <li>Expired</li>
 * </ul>
 * 
 * <p/>
 * The beginning state is <b>Disconnected</b>. Once the connection is
 * established it goes to <b>SyncConnected</b>. After that the session should be
 * authenticated (see {@link AuthenticationCallback}). If the authentication is
 * failed the state is changed to <b>AuthFailed</b>, if it is successful the
 * state remains <b>SyncConnected</b>.
 * 
 * <p/>
 * 
 * During the run if the connection is temporary lost it goes to
 * <b>Disconnected</b> state. At this state the zookeeper library is trying to
 * establish the connection by itself. If it is restored the state is going back
 * to <b>SyncConnected</b> (no authentication is required). If it fails the
 * state is changed to <b>Expired</b> and {@link ReconnectonWatcher} starts a
 * new reconnect thread which is running periodically until success.
 * 
 * @author chernyse
 * 
 */
@ManagedResource(description="Zookeeper client")
public class ZooKeeperClient implements ApplicationStatusProvider {
    
    static final Logger logger = LoggerFactory.getLogger(ZooKeeperClient.class);
    static final StringValueTransformer valueTransformer = new StringValueTransformer();
    static final String authScheme = "digest";
    
    volatile ZooKeeper client;
    private String hostPorts;
    private int sessionTimeOut;
    private long connectionTimeOut;
    private String username;
    private String password;
    private Properties properties;
    private boolean enabled = true;
    private long lastConnectedTimestamp;
    private static final AtomicInteger connectionCounter = new AtomicInteger();
    
    private ScheduledExecutorService connectService;

    List<ZKConnectionCallback> zkConnectionCallbacks = new CopyOnWriteArrayList<ZooKeeperClient.ZKConnectionCallback>();
    long reconnectInterval = 10000;
    private boolean reconnectOnExpiration = true;
    
    final List<ACL> acls = new CopyOnWriteArrayList<ACL>();
    
    public ZooKeeperClient() {
        //disable redundant debug messages produced by ClientCnxn
        if(logger.isDebugEnabled() && !logger.isTraceEnabled()) {
            try {
                ch.qos.logback.classic.Logger clientCnxnLogger = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(ClientCnxn.class);
                clientCnxnLogger.setLevel(Level.INFO);
                logger.info("Set ClientCnxn log level to INFO");
            } catch (Throwable ex) {
                logger.info("Skipped logback config since not found on classpath");
            }
        }
        initializeConnectionThreadService();
    }
    
    /**
     * Instantiates and connects a new {@link ZooKeeperClient} based on the zookeeper-client.properties file on the classpath.
     * @return A connected {@link ZooKeeperClient}, ready for use.
     * @throws ZooKeeperClientException if the client could not be instantiated or connected.
     */
    public static ZooKeeperClient newFromPath() throws ZooKeeperClientException {
        return newFromZooKeeperClientProperties(new ZooKeeperClientPropertiesLoader().loadFromPath(), true);
    }
    
    /**
     * Instantiates and connects a new {@link ZooKeeperClient} based on the zookeeper-client.properties file on the classpath.
     * @return A connected {@link ZooKeeperClient}, ready for use, or null if it could not be loaded for whatever reason.
     */    
    public static ZooKeeperClient newFromPathSilent() {
        return newFromZooKeeperClientPropertiesSilent(new ZooKeeperClientPropertiesLoader().loadFromPathSilent());
    }

    /**
     * Creates and connects a new instance of {@link ZooKeeperClient} based on the provided properties, which must include the following
     * properties:
     * <ul>
     * <li>ZooKeeperClientPropertiesLoader.HOST_PORTS</li>
     * <li>ZooKeeperClientPropertiesLoader.SESSION_TIMEOUT</li>
     * <li>ZooKeeperClientPropertiesLoader.CONNECTION_TIMEOUT</li>
     * <li>ZooKeeperClientPropertiesLoader.USERNAME)</li>
     * <li>ZooKeeperClientPropertiesLoader.PASSWORD</li>
     * </ul>
     * @param zooKeeperClientProperties
     * @return
     * @throws ZooKeeperClientException
     */
    public static ZooKeeperClient newFromZooKeeperClientProperties(Properties zooKeeperClientProperties, boolean waitConnection) throws ZooKeeperClientException {
        String hostPorts = zooKeeperClientProperties.getProperty(ZooKeeperClientPropertiesLoader.HOST_PORTS);
        String sessionTimeOut = zooKeeperClientProperties.getProperty(ZooKeeperClientPropertiesLoader.SESSION_TIMEOUT);
        String connectionTimeOut = zooKeeperClientProperties
                .getProperty(ZooKeeperClientPropertiesLoader.CONNECTION_TIMEOUT);
        String username = zooKeeperClientProperties.getProperty(ZooKeeperClientPropertiesLoader.USERNAME);
        String password = zooKeeperClientProperties.getProperty(ZooKeeperClientPropertiesLoader.PASSWORD);
        
        ZooKeeperClient zkClient = new ZooKeeperClient();
        if(waitConnection)
            zkClient.connect(hostPorts, sessionTimeOut, connectionTimeOut, username, password);
        else {
            ZKConnectionCallback authenticationCallback = zkClient.new AuthenticationCallback(username, password);
            zkClient.connect(hostPorts, Integer.valueOf(sessionTimeOut), Integer.valueOf(connectionTimeOut), Collections.singletonList(authenticationCallback), true);
        }
            
        return zkClient;         
    }
    
    /**
     * As {@link #newFromZooKeeperClientProperties(Properties)} but returns null if the {@link ZooKeeperClient} could not be connected.
     * @param zooKeeperClientProperties
     * @return
     */
    public static ZooKeeperClient newFromZooKeeperClientPropertiesSilent(Properties zooKeeperClientProperties) {
        ZooKeeperClient client = null;
        
        if (zooKeeperClientProperties != null) {
            try {
                client = newFromZooKeeperClientProperties(zooKeeperClientProperties, true);
            } catch (ZooKeeperClientException e) {
                logger.warn("Failed to create client", e);
            }
        }
        
        return client;
    }
    
    /**
     * Blocking connection method to the Zookeeper server
     * 
     * @param hostPorts
     * @param sessionTimeOutString
     * @param connectionTimeOutString
     * @throws ZooKeeperClientException
     */
    public void connect(String hostPorts, String sessionTimeOutString, String connectionTimeOutString, String username, String password)
            throws ZooKeeperClientException {
        
        final CountDownLatch connectedLatch = new CountDownLatch(1);
        
        //Authentication callback
        zkConnectionCallbacks.add(0, new AuthenticationCallback(username, password));
        
        //Blocking callback
        zkConnectionCallbacks.add(new ZKConnectionCallback() {
            public void onConnect(boolean restoredFromDisconnect) {
                connectedLatch.countDown();
            }
        });
        
        connect(hostPorts, Integer.valueOf(sessionTimeOutString), Long.valueOf(connectionTimeOutString), true);
        
        try {
            boolean isConnected = connectedLatch.await(30, TimeUnit.SECONDS);
            if(!isConnected)
                throw new ZooKeeperClientException("Can not connect to zookeeper cluster");
        } catch (InterruptedException e) {
            logger.warn("Connection to the zookeeper is interrupted. Client object may be not instantiated");
        }
    }

    /**
     * Not blocking connection method to the Zookeeper server
     * 
     * @param hostPorts
     * @param sessionTimeOut
     * @param connectionTimeOut
     * @param connectionCallbacks
     * @param reconnectOnExpiration if true the client will try to reconnect to
     * ZK each time after reconnectInterval
     * @throws ZooKeeperClientException
     */
    public void connect(final String hostPorts, final int sessionTimeOut, final long connectionTimeOut, final Collection<ZKConnectionCallback> connectionCallbacks, boolean reconnectOnExpiration) {
        zkConnectionCallbacks = new CopyOnWriteArrayList<ZKConnectionCallback>(connectionCallbacks);
        connect(hostPorts, sessionTimeOut, connectionTimeOut, reconnectOnExpiration);
    }
    
    void connect(final String hostPorts, final int sessionTimeOut, final long connectionTimeOut, boolean reconnectOnExpiration) {
        ZKConnectionMaster conectionMaster = new ZKConnectionMaster(hostPorts, sessionTimeOut, connectionTimeOut, reconnectOnExpiration);
        connectService.execute(conectionMaster);
    }    

    /**
     * Callback interface that is called on establishing or restoring connection
     */
    public interface ZKConnectionCallback {
        void onConnect(boolean restoredFromDisconnect);
    }

    /**
     * Connection master to the zookeeper cluster. 
     * <p/>
     * 
     * Apart from blocked connect method it provides the fumakes it possible to establish unblocking connection by running a new thread with the instance of this class.
     * 
     * @author chernyse
     * 
     */
    private class ZKConnectionMaster implements Runnable {

        private final String hostPorts;
        private final int sessionTimeOut;
        private final long connectionTimeOut;
        private final boolean reconnectOnExpiration;
        private final ReconnectonWatcher reconnectonWatcher;

        public ZKConnectionMaster(String hostPorts, int sessionTimeOut, long connectionTimeOut, boolean reconnectOnExpiration) {
            this.hostPorts = hostPorts;
            this.sessionTimeOut = sessionTimeOut;
            this.connectionTimeOut = connectionTimeOut;
            this.reconnectOnExpiration = reconnectOnExpiration;
            this.reconnectonWatcher = new ReconnectonWatcher(this);
        }

        @Override
        public void run() {
            final Thread currentThread = Thread.currentThread();
            while (!currentThread.isInterrupted()) {
                try {
                    connect();

                    if (reconnectOnExpiration) {
                        logger.info("Registering reconnect watcher");
                        client.register(reconnectonWatcher);
                    }

                    for (ZKConnectionCallback callback : zkConnectionCallbacks)
                        safeCall(callback, false);

                    return; // we are in the loop

                } catch (ZooKeeperClientException e) {
                    try {
                        logger.info("No connection to the ZK. Sleeping for {}ms before re-try", reconnectInterval);
                        Thread.sleep(reconnectInterval);
                    } catch (InterruptedException interEx) {
                        logger.info("ReconnectionWatcher thread is interrupted  in sleep phase");
                        currentThread.interrupt();
                    }
                } catch (InterruptedException e) {
                    logger.info("{} thread is interrupted in connection phase", currentThread.getName());
                    currentThread.interrupt();
                } catch(Throwable t) {
                    logger.error("CAN NOT CONNECT", t);
                    throw new RuntimeException(t);
                }
            }
        }

        /**
         * Luke Stephenson notes - WTF is this code for? From the apache Zookeeper documentation
         * "The client will continue attempts until the session is explicitly closed.". So if the zookeeper already
         * provides reconnection, why does this implementation need to provide it's own (buggy) reconnection logic on
         * top of the official implementation? Ever noticed how high CPU usage is when zookeeper goes down. I suspect
         * some of the blame can be directed at this code. Also check out:
         * http://zookeeper-user.578899.n2.nabble.com/High
         * -CPU-usage-on-zookeeper-clients-when-cluster-is-down-td7580027.html
         */
        private void connect() throws ZooKeeperClientException, InterruptedException {

            logger.info("connecting using hostPorts: {}, sessionTimeOut: {}, connectionTimeOut: {}", new Object[] {
                    hostPorts, sessionTimeOut, connectionTimeOut });

            final CountDownLatch latch = new CountDownLatch(1);
            ZooKeeper zk;
            try {
                Watcher watcher = new Watcher() {
                    @Override
                    public void process(final WatchedEvent event) {
                        KeeperState state = event.getState();
                        logger.info("received state: {}", state);
                        if (state == KeeperState.SyncConnected) {
                            logger.info("connection established");
                            latch.countDown();
                        } else if (state == KeeperState.Expired) {
                            logger.error("client session expired", new ZooKeeperClientException(
                                    "the zookeeper client session  has expired"));
                        }
                    }
                };

                zk = new ZooKeeper(hostPorts, sessionTimeOut, watcher);
            } catch (IOException e) {
                throw new ZooKeeperClientException("network failure occurred", e);
            }

            logger.info("waiting for connection to be established");
            boolean connected;
            try {
                connected = latch.await(connectionTimeOut, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                logger.info("interrupted during reconnect.  Closing secondary connection");
                zk.close();
                throw e;
            }

            if (!connected) {
                logger.info("failed to connect within {}ms; disconnecting", connectionTimeOut);
                zk.close();

                throw new ZooKeeperClientConnectionTimeOutException("client timed out connecting; " + "hostPorts: "
                        + hostPorts + ", sessionTimeOut: " + sessionTimeOut + "ms, connectionTimeOut: "
                        + connectionTimeOut + "ms");
            } else {
                client = zk;
                lastConnectedTimestamp = System.currentTimeMillis();
            }

        }
    }

    /**
     * Watcher of the zookeeper connection. It is triggered on every change of {@link KeeperState}
     * and start the connecting thread if the received state is {@link KeeperState.Expired}
     * @author chernyse
     *
     */
    private class ReconnectonWatcher implements Watcher {

        private final ZKConnectionMaster connectionMaster;
        private volatile KeeperState prevState;

        public ReconnectonWatcher(ZKConnectionMaster connectionMaster) {
            this.connectionMaster = connectionMaster;
        }

        @Override
        public void process(WatchedEvent event) {

            logger.info("ReconnectonWatcher is fired with event {}", event);

            KeeperState state = event.getState();
            
            if (state != KeeperState.Expired) {
                logger.debug("ReconnectonWatcher is notified but not with Expired state. Reregestering");

                if (state == KeeperState.SyncConnected) {
                    boolean restoredFromDisconnect = (prevState == KeeperState.Disconnected);
                    for (ZKConnectionCallback callback : zkConnectionCallbacks)
                        safeCall(callback, restoredFromDisconnect);
                    
                }
                
                client.register(this);
                //logger.info("ReconnectonWatcher has been re-registered");
                
            } else {
                logger.info("ReconnectonWatcher is notified with Expired state. Trying to reconnect");

                // Closing the previous connection if it was not yet closed
                // before opening a new one
                try {
                    client.close();
                } catch (InterruptedException e) {
                    logger.warn("Thread {} is interrapted being closing zk's client", Thread.currentThread().getName());
                    Thread.currentThread().interrupt();
                }
                
                connectService.execute(connectionMaster);
            }
            
            prevState = state;
        }
    }

    public synchronized void addUser(String username, String password) {
        if (client == null) {
            throw new ZooKeeperClientRuntimeException("cannot add user on unconnected client");
        }
        
        String userPass = username + ":" + password;
        client.addAuthInfo(authScheme, userPass.getBytes());
        try {
            acls.add(new ACL(Perms.ALL,
                    new Id(authScheme, DigestAuthenticationProvider.generateDigest(userPass))));
        } catch (NoSuchAlgorithmException e) {
            throw new ZooKeeperClientRuntimeException(e);
        }
    }

    public List<OpResult> multi(List<Op> operations) throws KeeperException, InterruptedException {
        
        if(!isAlive()) 
            throw new IllegalStateException("Zookeeper client is not alive");        
        
        return client.multi(operations);
    }
    
    
    public String create(String path, String data, CreateMode createMode) throws KeeperException, InterruptedException {
        byte[] bytes = data == null ? null : valueTransformer.toOutput(data);
        return create(path, bytes, createMode);
    }
    
    public String create(String path, byte[] data, CreateMode createMode) throws KeeperException, InterruptedException {
        
        if(!isAlive()) 
            throw new IllegalStateException("Zookeeper client is not alive");
        
        return client.create(path, data, acls.isEmpty() ? Ids.OPEN_ACL_UNSAFE : acls, createMode);
    }    
    
    public String create(String path, CreateMode createMode) throws KeeperException, InterruptedException {

        if(!isAlive()) 
            throw new IllegalStateException("Zookeeper client is not alive");
        
        return client.create(path, null, acls.isEmpty() ? Ids.OPEN_ACL_UNSAFE : acls, createMode);
    }

    public String createFull(String path, CreateMode createMode) throws KeeperException, InterruptedException {
        return createFull("", path, null, createMode);
    }

    public String createFull(String path, String data, CreateMode createMode) throws KeeperException,
            InterruptedException {
        return createFull(path, valueTransformer.toOutput(data), createMode);
    }
    
    public String createFull(String path, byte[] data, CreateMode createMode) throws KeeperException,
    InterruptedException {
        return createFull("", path, data, createMode);
    }    
    
    String createFull(String rootPath, String path, byte[] data, CreateMode createMode) throws KeeperException,
            InterruptedException {
        rootPath = rootPath == null ? "" : rootPath;
        String fullPath = rootPath + path;
        if (exists(fullPath)) {
            set(fullPath, data);
            return fullPath;
        } else {
            Iterable<String> iterable = Splitter.on('/').omitEmptyStrings().split(path);
            Iterator<String> iterator = iterable.iterator();
            StringBuilder builder = new StringBuilder(rootPath);
            String trackedPath = builder.toString();
            while (iterator.hasNext()) {
                String node = iterator.next();
                trackedPath = builder.append("/").append(node).toString();
                if (!exists(trackedPath)) {
                    try {
                        if (iterator.hasNext()) {
                            create(trackedPath, CreateMode.PERSISTENT);
                        } else {
                            create(trackedPath, createMode);
                        }
                    } catch (KeeperException e) {
                        //Node is created between the check "exists" and call "create"
                        if(KeeperException.Code.NODEEXISTS == e.code()) {
                            continue;
                        }
                    }
                }
            }
            set(trackedPath, data);
            return trackedPath;
        }
    }

    public boolean hasChildren(String path) throws KeeperException, InterruptedException {
        
        if(!isAlive()) 
            throw new IllegalStateException("Zookeeper client is not alive");        
        
        Stat stat = client.exists(path, false);
        if (stat == null) {
            return false;
        } else {
            return stat.getNumChildren() > 0;
        }
    }

    public boolean exists(String path) throws KeeperException, InterruptedException {

        if(!isAlive()) 
            throw new IllegalStateException("Zookeeper client is not alive");
        
        return client.exists(path, false) != null;
    }
    
    public boolean exists(String path, Watcher watcher) throws KeeperException, InterruptedException {
        
        if(!isAlive()) 
            throw new IllegalStateException("Zookeeper client is not alive");        
        
        return client.exists(path, watcher) != null;
    }    

    public byte[] read(String path) throws KeeperException, InterruptedException {
        
        if(!isAlive()) 
            throw new IllegalStateException("Zookeeper client is not alive");        
        
        try {
            return client.getData(path, false, null);
        } catch (KeeperException.NoNodeException e) {
            return null;
        }
    }

    public byte[] read(final String path, final Watcher watch) throws KeeperException, InterruptedException {
        if (!isAlive()) {
            throw new IllegalStateException("Zookeeper client is not alive");
        }

        try {
            return client.getData(path, watch, null);
        } catch (KeeperException.NoNodeException e) {
            return null;
        }
    }
    
    public DataAndStat getDataAndStat(String path) throws KeeperException, InterruptedException {
        
        if(!isAlive()) 
            throw new IllegalStateException("Zookeeper client is not alive");        
        
        Stat stat = new Stat();
        try {
            byte[] data = client.getData(path, false, stat);
            return new DataAndStat(data, stat);
        } catch (KeeperException.NoNodeException e) {
            return null;
        }
    }

    public static class DataAndStat {
        public final byte[] data;
        public final Stat stat;

        public DataAndStat(byte[] data, Stat stat) {
            this.data = data;
            this.stat = stat;
        }
    }

    /**
     * Get children for a given path.
     * 
     * @param path
     * @return Always returns a list whether empty of otherwise. Never returns a
     * null.
     * @throws KeeperException Thrown if supplied path doesn't exist.
     * @throws InterruptedException
     */
    public List<String> getChildren(String path) throws KeeperException, InterruptedException {
        
        if(!isAlive()) 
            throw new IllegalStateException("Zookeeper client is not alive");        
        
        return client.getChildren(path, false);
    }
    
    /**
     * Get children for a given path.
     * 
     * @param path
     * @param watcher
     * @return Always returns a list whether empty of otherwise. Never returns a
     * null.
     * @throws KeeperException
     * @throws InterruptedException
     */
    public List<String> getChildren(String path, Watcher watcher) throws KeeperException, InterruptedException {
        
        if(!isAlive()) 
            throw new IllegalStateException("Zookeeper client is not alive");        
        
        return client.getChildren(path, watcher);
    }    

    public void set(String path, String data) throws KeeperException, InterruptedException {
        set(path, valueTransformer.toOutput(data));
    }
    
    public void set(String path, byte[] data) throws KeeperException, InterruptedException {
        client.setData(path, data, -1);
    }    

    public void delete(String path) throws InterruptedException, KeeperException {

        if(!isAlive()) 
            throw new IllegalStateException("Zookeeper client is not alive");
        
        client.delete(path, -1);
    }

    public long getSessionId() {
        return client.getSessionId();
    }

    public Stat stat(String path) throws KeeperException, InterruptedException {
        
        if(!isAlive()) 
            throw new IllegalStateException("Zookeeper client is not alive");        
        
        return client.exists(path, false);
    }

    public boolean isAlive() {
        return client != null && client.getState() == States.CONNECTED;
    }
    
    public boolean waitForAlive(long timeout, TimeUnit timeUnit) throws InterruptedException {
        
        if (!isAlive()) {
            final CountDownLatch waitLatch = new CountDownLatch(1);
            
            ZKConnectionCallback connectedCallback = new ZKConnectionCallback() {
                public void onConnect(boolean restoredFromDisconnect) {
                    waitLatch.countDown();
                }
            };
            
            zkConnectionCallbacks.add(connectedCallback);
            try {
                if(!isAlive()) 
                    waitLatch.await(timeout, timeUnit);
            } finally {
                zkConnectionCallbacks.remove(connectedCallback);
            }
        }
        
        return isAlive();
    }

    public void waitForAlive() throws InterruptedException {

        if (!isAlive()) {
            
            final CountDownLatch waitLatch = new CountDownLatch(1);
            
            ZKConnectionCallback connectedCallback = new ZKConnectionCallback() {
                public void onConnect(boolean restoredFromDisconnect) {
                    waitLatch.countDown();
                }
            };
            
            zkConnectionCallbacks.add(connectedCallback);
            try {
                // if client is still not alive start waiting callback
                if (!isAlive()) {
                    while (!waitLatch.await(10, TimeUnit.SECONDS)) {
                        if (isAlive())
                            break;
                    }
                }
            } finally {
                // callback received or client became alive
                zkConnectionCallbacks.remove(connectedCallback);
            }
        }
    }
    
    
    public boolean isEnabled() {
        return enabled;
    }   

    private static class ZooKeeperClientRuntimeException extends RuntimeException {
        private static final long serialVersionUID = -4227468971012604317L;

        ZooKeeperClientRuntimeException(Throwable cause) {
            super(cause);
        }

        ZooKeeperClientRuntimeException(String string) {
        }
    }
    
    public Op operationCreate(String path, byte[] data, CreateMode createMode) {
        return Op.create(path, data, acls.isEmpty() ? Ids.OPEN_ACL_UNSAFE : acls, createMode);
    }
    
    public Op operationExists(String path) {
        return Op.check(path, -1);
    }
    
    public Op operationDelete(String path) {
        return Op.delete(path, -1);
    }

    /*
     * spring
     */

    @Required
    public void setZkConnectionCallbacks(Collection<ZKConnectionCallback> zkConnectionCallbacks) {
        this.zkConnectionCallbacks.addAll(zkConnectionCallbacks);
    }

    @Required
    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /**
     * Authenticate the session o zookeeper cluster.
     */
    private class AuthenticationCallback implements ZKConnectionCallback {

        private final String username, password;
        
        AuthenticationCallback(String username, String password) {
            this.username = username;
            this.password = password;
        }
        
        @Override
        public void onConnect(boolean restoredFromDisconnect) {
            if(!restoredFromDisconnect) {
                logger.trace("The session is established, adding user authentication details");
                addUser(this.username, this.password);
            }
        }
    }
    
    @PostConstruct
    public void init() {

        if(!enabled) {
            logger.info("zookeeper client is disabled");
            return;
        }
        
        if (properties.isEmpty()) {
            logger.warn("no zookeeper client properties found; not starting client");
            return;
        }
        
        hostPorts = properties.getProperty(ZooKeeperClientPropertiesLoader.HOST_PORTS);
        sessionTimeOut = Integer.parseInt(properties.getProperty(ZooKeeperClientPropertiesLoader.SESSION_TIMEOUT));
        connectionTimeOut = Long.parseLong(properties.getProperty(ZooKeeperClientPropertiesLoader.CONNECTION_TIMEOUT));
        username = properties.getProperty(ZooKeeperClientPropertiesLoader.USERNAME);
        password = properties.getProperty(ZooKeeperClientPropertiesLoader.PASSWORD);
        reconnectInterval = Long.parseLong(properties.getProperty(ZooKeeperClientPropertiesLoader.RECONNECT_INTERVAL));
        reconnectOnExpiration = Boolean.parseBoolean(properties
                .getProperty(ZooKeeperClientPropertiesLoader.RECONNECT_ON_EXPIRATION));

        //Authentication callback should go first
        ZKConnectionCallback authenticationCallback = new AuthenticationCallback(username, password);
        zkConnectionCallbacks.add(0, authenticationCallback);

        connect(hostPorts, sessionTimeOut, connectionTimeOut, reconnectOnExpiration);
    }
    
    void initializeConnectionThreadService() {
        connectService  = Executors.newSingleThreadScheduledExecutor(new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                t.setName("ZookeeperClientConnectionThread-"+connectionCounter.getAndIncrement());
                return t;
            }
        });          
    }
    
    private static void safeCall(ZKConnectionCallback callback, boolean restoredFromDisconnect) {
        if (callback != null) {
            try {
                callback.onConnect(restoredFromDisconnect);
            } catch (Throwable t) {
                logger.error("Exception is thrown on connection callback", t);
            }
        }
    }

    @PreDestroy
    public void stop() {
        // shutdown the reconnection thread first so that it does not attempt to reconnect after the connection is
        // closed.
        if (connectService != null) {
            connectService.shutdownNow();
            try {
                if (!connectService.awaitTermination(10, TimeUnit.SECONDS)) {
                    logger.warn("Connection service did not shutdown.");
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                logger.warn("Interrupted while waiting for connection service to shutdown.");
            }
        }

        try {
            if (client != null) {
                logger.info("disconnecting client");
                client.close();
            }
        } catch (Exception e) {
            logger.info("ZooKeeperClient is interrupted on closing stage");
        }
    }
    
    private final Map<String, Object> zkStatusData = new HashMap<String, Object>(4);
    private final String disconnected = "Disconnected (seconds)";
    private final String lastConnected = "Last connected";
    private final String hostPortKey = "Host";
    private static final SimpleDateFormat dateFormatter = new SimpleDateFormat("dd MMM HH:mm Z");
    private long zkDisconnectionDetectedTimestamp;

    @Override
    public ApplicationStatus status() {

        if (isEnabled()) {

            Status zkStatus;

            if (!isAlive()) {
                zkStatus = Status.RED;
                zkDisconnectionDetectedTimestamp = (zkDisconnectionDetectedTimestamp == 0) ? System.currentTimeMillis()
                        : zkDisconnectionDetectedTimestamp;
                zkStatusData.put(disconnected,
                        (long) ((System.currentTimeMillis() - zkDisconnectionDetectedTimestamp) / 1000L));
            } else {
                zkStatus = Status.GREEN;
                zkDisconnectionDetectedTimestamp = 0;
                zkStatusData.remove(disconnected);
            }

            zkStatusData.put(hostPortKey, hostPorts);
            zkStatusData.put(lastConnected, formatTime(lastConnectedTimestamp));

            zkStatusData.put(ApplicationStatus.STATUS_KEY, zkStatus);
        
        } else {
            
            zkStatusData.put(ApplicationStatus.STATUS_KEY, "Disabled");
        }
        
        return new DefaultApplicationStatus(zkStatusData);
    }
    
    public ZooKeeper getClient() {
        return client;
    }
    
    private static String formatTime(long timestamp) {
        return dateFormatter.format(new java.util.Date(timestamp));
    }
    
    /*
     * JMX
     */
    
    @ManagedAttribute(description="connection string")
    public String getHostPorts() {
        return hostPorts;
    }
    
    @ManagedAttribute(description="reconnect interval in ms")
    public long getReconnectInterval() {
        return reconnectInterval;
    }
    
    @ManagedOperation(description="set zookeeper reconnect interval in case connection lost")
    @ManagedOperationParameters({@ManagedOperationParameter(name="reconnectInterval", description = "reconnect interval in ms")})
    public void setReconnectInterval(long reconnectInterval) {
        this.reconnectInterval = reconnectInterval;
    }
    
    @ManagedAttribute(description="indicates if the client is reconnected on zookeeper session expiration")
    public boolean getReconnectOnExpiration() {
        return reconnectOnExpiration;
    }
    
    @ManagedOperation
    @ManagedOperationParameters({@ManagedOperationParameter(name="reconnectOnExpiration", description = "reconnectOnExpiration")})
    public void setReconnectOnExpiration(boolean reconnectOnExpiration) {
        this.reconnectOnExpiration = reconnectOnExpiration;
    }
    
    @ManagedAttribute(description="zookeeper login username")
    public String getUsername() {
        return username;
    }
    
    @ManagedAttribute(description="zookeeper login password")
    public String getPassword() {
        return password;
    }
        
    @ManagedAttribute(description="zookeeper connection timeout, ms")
    public long getConnectionTimeout() {
        return connectionTimeOut;
    }
    
    @ManagedAttribute(description="zookeeper session timeout, ms")
    public long getSessionTimeout() {
        return sessionTimeOut;
    }    

}