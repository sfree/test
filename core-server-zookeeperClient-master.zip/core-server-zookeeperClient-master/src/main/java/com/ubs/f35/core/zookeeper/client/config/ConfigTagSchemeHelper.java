package com.ubs.f35.core.zookeeper.client.config;

import com.ubs.f35.core.zookeeper.client.common.TagSchemeHelper;

public class ConfigTagSchemeHelper extends TagSchemeHelper {

    public static final String ENCRYPTED = "encrypted";
    public static final String LOCK = "lock";
    public static final String ENTITY = "entity";
    public static final String GROUP = "group";
    public static final String NODE = "node";
    public static final String LEASE = "lease";
    public static final String CONFIG = "config";

    public static final String SCHEME_LEASE_GROUP_NODE;
    public static final String SCHEME_LEASE_ENTITY;
    public static final String SCHEME_LEASE_LOCK;
    public static final String SCHEME_ENCRYPTED_NODE;

    static {
        SCHEME_LEASE_GROUP_NODE = new ConfigTagSchemeHelper().addLease().addLeaseGroup().addNode().toString();
        SCHEME_LEASE_ENTITY = new ConfigTagSchemeHelper().addLease().addLeaseEntity().add(":").toString();
        SCHEME_LEASE_LOCK = new ConfigTagSchemeHelper().addLease().addLeaseLock().toString();
        SCHEME_ENCRYPTED_NODE = new ConfigTagSchemeHelper().addEncrypted().addNode().toString();
    }

    public ConfigTagSchemeHelper() {
        super();
        builder.append(":").append(CONFIG);
    }

    public ConfigTagSchemeHelper addLease() {
        append(LEASE);
        return this;
    }

    public ConfigTagSchemeHelper addLeaseGroup() {
        append(GROUP);
        return this;
    }

    public ConfigTagSchemeHelper addNode() {
        append(NODE);
        return this;
    }

    public ConfigTagSchemeHelper addLeaseEntity() {
        append(ENTITY);
        return this;
    }

    public ConfigTagSchemeHelper addLeaseLock() {
        append(LOCK);
        return this;
    }

    public ConfigTagSchemeHelper addEncrypted() {
        append(ENCRYPTED);
        return this;
    }

    public static ConfigTagScheme parse(String name) {
        String[] tags = null;
        tags = name.contains(":") ? name.split(":") : new String[0];
        return new ConfigTagScheme(tags);
    }

    public static class ConfigTagScheme extends TagScheme {

        public ConfigTagScheme(String[] tags) {
            super(tags);
        }

        public boolean isConfig() {
            return hasTag(CONFIG);
        }

        public boolean isLease() {
            return hasTag(LEASE);
        }

        public boolean isLeaseGroup() {
            return hasTag(GROUP);
        }

        public boolean isLeaseEntity() {
            return hasTag(ENTITY);
        }

        public boolean isLeaseLock() {
            return hasTag(LOCK);
        }

        public boolean isEncrypted() {
            return hasTag(ENCRYPTED);
        }

    }

}