package com.ubs.f35.core.zookeeper.client.config.api;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.core.zookeeper.client.ZNode;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.common.PathBuilder;
import com.ubs.f35.core.zookeeper.client.common.StringValueTransformer;
import com.ubs.f35.core.zookeeper.client.common.ZookeeperRootPathResolver;
import com.ubs.f35.core.zookeeper.client.config.ConfigPropertyValueTypeHelper;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper;
import com.ubs.f35.core.zookeeper.client.config.processors.LeasePropertyFindingNodeProcessor;
import com.ubs.f35.core.zookeeper.utils.ConfigUtils;
import com.ubs.f35.core.zookeeper.utils.PropertyUtils;

/**
 *
 * Imports the property file to the zookeeper cluster.
 * One need to provide group/artifact/version for the importing properties.
 * 
 * Locked lease properties are checked and in case of conflicts the upload fails
 *
 * @author chernyse
 *
 */
public class CheckedZooKeeperPropertyFileImporter {

    static final Logger logger = LoggerFactory.getLogger(CheckedZooKeeperPropertyFileImporter.class);
    static final StringValueTransformer valueTransformer = new StringValueTransformer();
        
    private ZooKeeperClient zkc;
    private ZooKeeperService zks;
    private String rootPath;
    
    
    CheckedZooKeeperPropertyFileImporter(ZooKeeperService zks, ZookeeperRootPathResolver resolver) {
        this.zkc = zks.getClient();
        this.zks = zks;
        rootPath = resolver.resolveApplicationRootPath();
    }    
    
    CheckedZooKeeperPropertyFileImporter(ZooKeeperService zks) {
        this(zks, new ZookeeperRootPathResolver(ZooKeeperConfigService.ZOOKEEPER_CONFIG_ROOT_PATH));
    }

    void stop() throws InterruptedException {
        if (zks != null) {
            zks.stop();
        }
    }
    
    void importFromPath(String pathToFile) throws Exception {
        logger.info("loading {} from path", pathToFile);
        Properties properties = PropertyUtils.loadFromFilePath(pathToFile);
        validateAndUpload(properties);
    }    
    
    void importFromClassPath(String fileName) throws Exception {
        logger.info("loading {} from classpath", fileName);
        Properties properties = PropertyUtils.loadFromClassPath(fileName);        
        validateAndUpload(properties);
    }
    
    void importMultipleFromPath(List<String> filePaths) throws Exception {
        
        logger.info("Reading property files {}", filePaths);
        
        Properties properties = null;
        for (String filePath : filePaths) {
            logger.info("reading property file: {}", filePath);
            properties = PropertyUtils.loadFromFilePath(filePath, properties);
            logger.info("loaded {} properties from file: {}", properties.size(), filePath);
        }
        
        validateAndUpload(properties);
    }
    
    void validateAndUpload(Properties properties) throws Exception {
        //pre-generate insert operations and  
        List<ImportOperation> importOps = processProperties(properties);
        
        Collection<ImportOperation> groupImportOps = getOperationsByType(importOps, ConfigNodeType.LEASE_GROUP);
        
        //call zk to retrieve lease group nodes
        Collection<ZNode> groupNodes = collectLeaseGroups();

        Collection<String> deleteFilter = new LinkedList<String>();

        //validate extracted leases and pre-generated nodes
        validateLeaseProperties(groupNodes, groupImportOps, deleteFilter);

        logger.info("Validation passed. Deleting old properties for {}", rootPath);
        zks.deleteSubTree(rootPath, deleteFilter);

        uploadProperties(importOps);
    }
    
    void uploadProperties(List<ImportOperation> importOps) throws KeeperException, InterruptedException {
        for(ImportOperation op : importOps) {
            zkc.createFull(op.zkPath, op.value, CreateMode.PERSISTENT);
            logger.info("Creating node {} : {}", op.zkPath, op.value);
            uploadProperties(op.children);
        }
    }

    Collection<ImportOperation> getOperationsByType(Collection<ImportOperation> importOps, ConfigNodeType type) {
        if(importOps == null) {
            return Collections.emptyList();
        }
        
        Collection<ImportOperation> typedOperations = new LinkedList<ImportOperation>();
        for(ImportOperation op : importOps) {
            if(op.type == type) {
                typedOperations.add(op);
            }
            Collection<ImportOperation> filteredKids = getOperationsByType(op.children, type);
            if(typedOperations.containsAll(filteredKids)) {
                continue; 
            } else {
                typedOperations.addAll(filteredKids);
            }
        }
        return typedOperations;
    }
    
    void validateLeaseProperties(Collection<ZNode> groupNodes, Collection<ImportOperation> groupImportOps, Collection<String> deleteFilter) {
        
        //simplify future lookup
        Map<String, ImportOperation> candidates = new HashMap<String, ImportOperation>();
        for(ImportOperation each : groupImportOps)
            candidates.put(each.zkPath, each);        
        
        
        //validate each group node
        for(ZNode groupNode : groupNodes) {
            Collection<ZNode> lockedLeases = getLockedLeasedEntities(groupNode);
            
            ImportOperation groupOp = candidates.get(groupNode.path());
            
            if(lockedLeases.isEmpty()) {
                continue;
            }
            
            if(groupOp == null && !lockedLeases.isEmpty()) {
                logger.error(
                        "Can not import properties because new properties doesn't have lease group ["
                                + groupNode.parent().name() + "] while one of group's values is currently taken and used");

                throw new CommandLineException.MissedLeaseGroupException();
            }
            
            for(ZNode lockedLeaseEntity : lockedLeases) {

                //adding entity value and its lock to the deletion filter
                deleteFilter.add(lockedLeaseEntity.path());
                for(ZNode lock : lockedLeaseEntity.children()) {
                    deleteFilter.add(lock.path());
                }                                    
                
                //looking for a ImportOpeartion corresponding to a lockedLeaseEntity
                ImportOperation lockedEntityOp = null;
                
                for(ImportOperation entityOp : groupOp.children) {
                    if(entityOp.value.equals(valueTransformer.fromInput(lockedLeaseEntity.value()))) {
                        lockedEntityOp = entityOp;
                        break;
                    }
                }
                
                if(lockedEntityOp == null) {
                    logger.error("Lease entity " + valueTransformer.fromInput(lockedLeaseEntity.value()) + " of group ["+groupNode.parent().name()+"] is locked and there is no corresponding entity in new properties");
                    throw new CommandLineException.MissedLeaseValueException();
                } else {
                    logger.info("Found the locked lease entity [{}] in properties. Create operation is removed", lockedEntityOp.zkPath);
                    
                    // as we do not remove locked entity we need to be sure both
                    // in that we exclude creation of lease entity with the same
                    // value but with a new node name and we do not create an entity with the same
                    // name as locked one but with different value.
                    
                    //remove create operation with locked value
                    groupOp.children.remove(lockedEntityOp);

                    //look for a new entity with same name as locked one and replace the name
                    if(!lockedEntityOp.zkPath.equals(lockedLeaseEntity.path())) {
                        ImportOperation namesake = groupOp.getChildByZKPath(lockedLeaseEntity.path());
                        ImportOperation replace = new ImportOperation(lockedEntityOp.key, lockedEntityOp.zkPath, namesake.value, namesake.type);
                        
                        groupOp.children.remove(namesake);
                        groupOp.addOperation(replace);
                    }
                }
            }
        }
    }
    
    
    Collection<ZNode> collectLeaseGroups() throws Exception {
        LeasePropertyFindingNodeProcessor leaseFinder = new LeasePropertyFindingNodeProcessor();
        zks.walk(rootPath, leaseFinder);
        Map<String, ZNode> leaseProperties = leaseFinder.getPlaceholderToLeaseGroupNodeMapping();
        return new HashSet<ZNode>(leaseProperties.values());
    }
    
    
    Collection<ZNode> getLockedLeasedEntities(ZNode groupNode) {
        
        Collection<ZNode> out = new ArrayList<ZNode>();
        
        for(ZNode child : groupNode.children()) {
            if(!child.isLeaf()) {
                out.add(child);
            }
        }
        return out;
    }
    
    
    List<ImportOperation> processProperties(Properties properties) {

        final List<ImportOperation> importOps = new ArrayList<ImportOperation>();
        
        for (String key : properties.stringPropertyNames()) {
            
            String propertyValue = properties.getProperty(key);
            ConfigPropertyValueTypeHelper propertyValueTypeHelper = new ConfigPropertyValueTypeHelper(key, propertyValue);
            
            if (!propertyValueTypeHelper.isExpression()) {
            
                //LITERAL
                importOps.add(createLiteralOperation(this.rootPath, key, propertyValue, false));

            } else {
                // EXPRESSION
                if (propertyValueTypeHelper.isEncrypted() && !propertyValueTypeHelper.isLeased()) {

                    // ENCRYPTED AND NOT LEASED
                    importOps.add(createLiteralOperation(this.rootPath, key, propertyValueTypeHelper.getValue(), true));

                } else if (propertyValueTypeHelper.isEncrypted() && propertyValueTypeHelper.isLeased()) {

                    // ENCRYPTED AND LEASED
                    importOps.add(createLeaseOperation(this.rootPath, key, propertyValueTypeHelper, true));

                } else if (!propertyValueTypeHelper.isEncrypted() && propertyValueTypeHelper.isLeased()) {

                    // NOT ENCRYPTED BUT LEASED
                    importOps.add(createLeaseOperation(this.rootPath, key, propertyValueTypeHelper, false));

                } else {                    
                    // UNRECOGNIZED EXPRESSION - IMPORT AS LITERAl
                    logger.warn("Unrecognized expression type. Importing as literal value: {}", propertyValue);
                    createLiteralOperation(this.rootPath, key, propertyValue, false);
                }
            }
        }        
        
        return importOps;
    }
    
    static class ImportOperation {
        
        final String key;
        final String zkPath;
        final String value;
        
        final List<ImportOperation> children = new ArrayList<ImportOperation>(3);
        
        final ConfigNodeType type;
        
        public ImportOperation(String key, String zkPath, String value, ConfigNodeType type) {
            this.key = key;
            this.zkPath = zkPath;
            this.value = value;
            this.type = type;
        }
        
        public ImportOperation(String key, String zkPath, String value, ConfigNodeType type, ImportOperation... dependants) {
            this.key = key;
            this.zkPath = zkPath;
            this.value = value;
            this.type = type;
            
            for(ImportOperation each : dependants)
                addOperation(each);

        }        
        
        void addOperation(ImportOperation op) {
            if(this.type == ConfigNodeType.LEASE_GROUP && op.type == ConfigNodeType.LEASE_ENTITY) {
                this.children.add(op);
            } else {
                logger.warn("Can not add {} to the children list of {} because of type inconsistency", op, this);
            }
        }
        
        ImportOperation getChildByZKPath(String zkPath) {
            for(ImportOperation child : children) {
                if(child.zkPath.equals(zkPath)) {
                    return child;
                }
            }
            return null;
        }

        @Override
        public String toString() {
            return "ImportOperation [key=" + key + ", zkPath=" + zkPath + ", value=" + value + ", type=" + type + "]";
        }
    }
    
    static enum ConfigNodeType {
        LITERAL,
        LEASE_GROUP,
        LEASE_ENTITY;
     }    
    
    
    /**
     * Creates zookeeper operation for literal property type 
     */    
    ImportOperation createLiteralOperation(String root, String key, String propertyValue, boolean encrypted) {
        
        String propertyPath = ConfigUtils.convertPropertyToPath(key);
        PathBuilder pathBuilder = new PathBuilder().verbatim(root).appendNormalised(propertyPath);
        
        if(encrypted) {
            pathBuilder.verbatim(ConfigTagSchemeHelper.SCHEME_ENCRYPTED_NODE);
        }
        
        String fullPath = pathBuilder.toString();
        logger.debug("literal {}property {} : {}", new Object[] { (encrypted ? "encrypted " : ""), fullPath, propertyValue});
        return new ImportOperation(key, pathBuilder.toString(), propertyValue, ConfigNodeType.LITERAL);
    }
    

    /**
     * Creates zookeeper operation for lease property type 
     */
    ImportOperation createLeaseOperation(String root, String key, ConfigPropertyValueTypeHelper propertyValueTypeHelper, boolean encrypted) {

        ConfigTagSchemeHelper leaseGroupHelper = new ConfigTagSchemeHelper().addLease().addLeaseGroup();
        if (encrypted) {
            leaseGroupHelper.addEncrypted();
        }
        
        leaseGroupHelper.addNode();
        String leaseGroupNodeName = leaseGroupHelper.toString();
        logger.debug("using leaseGroupNodeName: {}", leaseGroupNodeName);

        String propertyPath = ConfigUtils.convertPropertyToPath(key);
        String fullLeaseGroupPath = new PathBuilder().verbatim(root).appendNormalised(propertyPath) .appendNormalised(leaseGroupNodeName).toString();
        logger.debug("creating leased property {} : {}", fullLeaseGroupPath, propertyValueTypeHelper.getOriginalValue());
        
        ImportOperation groupOp = new ImportOperation(key, fullLeaseGroupPath, propertyValueTypeHelper.getLeaseGroupExpression(), ConfigNodeType.LEASE_GROUP);

        List<String> leaseEntityValues = propertyValueTypeHelper.getLeaseEntityExpressions();
        logger.debug("resolved lease entity expressions: {}", leaseEntityValues);

        ConfigTagSchemeHelper leaseEntityHelper = new ConfigTagSchemeHelper().addLease().addLeaseEntity();
        
        if (encrypted) {
            leaseEntityHelper.addEncrypted();
        }
        leaseEntityHelper.addSeparator();
        String leaseEntityNodeName = leaseEntityHelper.toString();
        logger.debug("using leaseEntityNodeName: {}", leaseEntityNodeName);

        for (int i = 0; i < leaseEntityValues.size(); i++) {
            String singleLeaseValue = leaseEntityValues.get(i);
            String leaseAcquirerPath = leaseEntityNodeName + (i + 1);
            String fullLeasePath = new PathBuilder().verbatim(fullLeaseGroupPath).appendNormalised(leaseAcquirerPath).toString();
            logger.debug("creating leased property child {} : {}", fullLeasePath, singleLeaseValue);
            
            ImportOperation entityOp = new ImportOperation(key, fullLeasePath, singleLeaseValue, ConfigNodeType.LEASE_ENTITY);
            groupOp.addOperation(entityOp);
        }
        
        return groupOp;
    }    
    
}
