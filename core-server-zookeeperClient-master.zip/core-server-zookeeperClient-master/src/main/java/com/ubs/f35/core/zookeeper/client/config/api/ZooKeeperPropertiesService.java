package com.ubs.f35.core.zookeeper.client.config.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.ubs.f35.core.zookeeper.client.ZNodeProcessor;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClientException;
import com.ubs.f35.core.zookeeper.client.common.ZooKeeperClientPropertiesLoader;
import com.ubs.f35.core.zookeeper.client.common.ZookeeperRootPathResolver;
import com.ubs.f35.core.zookeeper.client.config.ConfigPropertyValueDecryptionProvider;
import com.ubs.f35.core.zookeeper.client.config.processors.PropertyExposingNodeProcessor;

/**
 * Allows client to retrieve a flat {@link Properties} collection from ZooKeeper based on a particular groupId / artifactId / version.
 * All that should be required is:
 * <ol>
 * <li>Ensure zookeeper-client.properties is on classpath of application.</li>
 * <li>Declare bean in Spring context.</li>
 * <li>Call the init method to connect to the ZooKeeper cluster</li>
 * </ol>
 * On startup the bean will load the ZooKeeper cluster properties from zookeeper-client.properties, and make the connection. Then,
 * at runtime, simply query for the properties via the {@link #loadProperties(String, String, String)} method.
 * <p>
 * The connection to ZooKeeper is persistent.
 */
@ManagedResource(description="Provides querying ability for application properties")
public class ZooKeeperPropertiesService  {
    
    private static final Logger logger = LoggerFactory.getLogger(ZooKeeperPropertiesService.class);
    
    private final static String lineSeparator = System.getProperty("line.separator");

    private ConfigPropertyValueDecryptionProvider decryptionProvider;
    
    private ZooKeeperClient zkClient;
    private ZooKeeperConfigService zooKeeperConfigService;
    // Default root path for Neo, but code is now being used outside of Neo.
    private String configRootPath = ZooKeeperConfigService.ZOOKEEPER_CONFIG_ROOT_PATH;
    
    private final Comparator<Entry<Object, Object>> comparator = new Comparator<Entry<Object, Object>>() {
        @Override
        public int compare(Entry<Object, Object> o1, Entry<Object, Object> o2) {
            return o1.getKey().toString().compareTo(o2.getKey().toString());
        }
    };    
    
    /**
     * Initializes the {@link ZooKeeperConfigService}. Either this method needs to be called, or the {@link ZooKeeperConfigService} needs
     * to be manually provided.
     * @throws ZooKeeperClientException if connection to ZooKeeper failed.
     */
    public void init() throws ZooKeeperClientException {        
        init(new ZooKeeperClientPropertiesLoader().loadFromPathSilent());
    }   
    
    /**
     * Initializes the {@link ZooKeeperConfigService} using the supplied ZooKeeper client properties
     * @param zookeeperProperties ZooKeeper Client properties
     * @throws ZooKeeperClientException if connection to ZooKeeper failed.
     */
    public void init(Properties zookeeperProperties) throws ZooKeeperClientException {
        if (zookeeperProperties == null || zookeeperProperties.isEmpty()) {
            logger.info("No zookeeper-client.properties found - service cannot be initialized");
            return;
        }
        
        logger.info("initialising zookeeper client");
        zkClient = ZooKeeperClient.newFromZooKeeperClientProperties(zookeeperProperties, false);
        
        if (zkClient != null) {
            zooKeeperConfigService = new ZooKeeperConfigService(zkClient);
            logger.info("initialised zookeeper client");             
        } else {
            logger.warn("Failed to intialize ZookeeperPropertiesService - client not connected");
        }         
    }
    
    /**
     * Closes the connection to ZooKeeper.
     */
    public void destroy() {
        logger.info("destroy called");
        try {
            if (zooKeeperConfigService != null) {
                zooKeeperConfigService.stop();
            }
        } catch (InterruptedException e) {           
            logger.info("Interrupted during destroy");
        } finally {
            zooKeeperConfigService = null;
        }
    }
    
    /**
     * Loads the {@link Properties} from ZooKeeper using the supplied groupId / artifactId / version.
     * NB: the {@link #init()} method must be called prior to calling this.
     * @throws IOException if no properties are found for the specified groupId / artifactId / version
     */    
    public Properties loadProperties(String groupId, String artifactId, String version) throws IOException {
        return loadProperties(groupId, artifactId, version, Collections.<ZNodeProcessor>emptyList());
    }
    
    /**
     * Loads the {@link Properties} from ZooKeeper using the supplied groupId / artifactId / version. Also passes the
     * additionalProcessors when walking the tree, though they have no effect on the Properties returned.
     * NB: the {@link #init()} method must be called prior to calling this.
     * @throws IOException if no properties are found for the specified groupId / artifactId / version
     */    
    Properties loadProperties(String groupId, String artifactId, String version, Collection<ZNodeProcessor> additionalProcessors) throws IOException {
        if (!isEnabled()) {
            throw new IllegalStateException("ZookeeperPropertiesService not enabled");
        }
        
        String rootPath = new ZookeeperRootPathResolver(configRootPath, groupId, artifactId, version).resolveApplicationRootPath();
        logger.info("using root path: {}", rootPath);        
        
        Properties zooKeeperProperties = new Properties();
        PropertyExposingNodeProcessor propertyExposingProcessor = new PropertyExposingNodeProcessor(rootPath,
                zooKeeperProperties, decryptionProvider);
        
        Collection<ZNodeProcessor> processors = new ArrayList<ZNodeProcessor>(additionalProcessors.size() + 1);
        processors.add(propertyExposingProcessor);
        processors.addAll(additionalProcessors);
        
        try {
            zooKeeperConfigService.walkMulti(rootPath, processors);
        } catch (Exception e) {
            throw new IOException("Failed to retrieve data from ZooKeeper", e);
        }

        if (zooKeeperProperties.isEmpty()) {
            throw new IOException("no properties found at root path: " + rootPath);
        }    
        
        return zooKeeperProperties;
    }
    
    public boolean isEnabled() {
        return zooKeeperConfigService != null;
    }
    
    /**
     * Check whether the {@link ZooKeeperClient} is alive. Note that there is still a chance that the connection will die
     * between calling this and subsequent calls.
     * @return true if it's alive
     */
    public boolean isZooKeeperClientAlive() {
        ZooKeeperClient localZkClient = zkClient;
        return localZkClient != null && localZkClient.isAlive();
    }
    
    /**
     * block for the specified amount of time waiting for the {@link ZooKeeperClient} to become alive
     * @param timeout
     * @param timeoutUnits
     * @return true if it's alive
     * @throws InterruptedException
     * @see {@link #isZooKeeperClientAlive()}
     */
    public boolean waitForZooKeeperClientAlive(long timeout, TimeUnit timeoutUnits) throws InterruptedException {
        return zkClient != null && zkClient.waitForAlive(timeout, timeoutUnits);
    }
    
    /**
     * Exposed for JMX. Returns a String representing all the properties stored in ZooKeeper for the application specified by
     * groupId / artifactId / version. This returns the same data as would be returned by a call to {@link #loadProperties(String, String, String)}
     * with the same parameters. The only difference is that it is formatted to be readable via JMX.
     */
    @ManagedOperation(description="Returns application properties for group / artifact / version")
    @ManagedOperationParameters({@ManagedOperationParameter(name="groupId", description="The groupId to look up"),
                                 @ManagedOperationParameter(name="artifactId", description="The artifactId to look up"),
                                 @ManagedOperationParameter(name="version", description="The version to look up")})
    public String getApplicationProperties(String groupId, String artifactId, String version) throws Exception {
        Properties mergedProperties = loadProperties(groupId, artifactId, version);
        
        StringBuilder buf = new StringBuilder(1000);
        buf.append(lineSeparator).append("======= Properties for: groupId=").append(groupId).append(", artifactId=").append(artifactId).append(", version=").append(version).append(" =======").append(lineSeparator);
        
        
        SortedSet<Entry<Object, Object>> sorted = new TreeSet<Entry<Object, Object>>(comparator);
        sorted.addAll(mergedProperties.entrySet());
        
        for(Entry<Object, Object> each : sorted) {
            buf.append(each.getKey()).append("=").append(each.getValue()).append(lineSeparator);
        }
        
        return buf.toString();        
    }

    public void setDecryptionProvider(ConfigPropertyValueDecryptionProvider decryptionProvider) {
        this.decryptionProvider = decryptionProvider;
    }

    public void setZooKeeperConfigService(ZooKeeperConfigService zooKeeperConfigService) {
        this.zooKeeperConfigService = zooKeeperConfigService;
    }
    
    public void setConfigRootPath(String configRootPath) {
        logger.info("Config root path set to {}",configRootPath);
        
        this.configRootPath = configRootPath;
    }
}
