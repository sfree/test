package com.ubs.f35.core.zookeeper.client.common;

public interface ValueTransformer<X, Y> {

    X fromInput(Y input);

    Y toOutput(X input);

}