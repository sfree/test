package com.ubs.f35.core.zookeeper.utils;

import com.google.common.base.Strings;

public class ConfigUtils {

    private static final String S = "/";
    private static final String D = ".";

    public static String erase(String erase, String string) {
        return string.replace(erase, "");
    }

    public static String convertPropertyToPath(String property) {
        if (property == null || property.isEmpty()) {
            return property;
        }
        return property.replace(D, S);
    }

    public static String convertPathToProperty(String path) {
        if (Strings.isNullOrEmpty(path)) {
            return path;
        }
        if (path.startsWith(S)) {
            path = path.substring(1);
        }
        return path.replace(S, D);
    }

}