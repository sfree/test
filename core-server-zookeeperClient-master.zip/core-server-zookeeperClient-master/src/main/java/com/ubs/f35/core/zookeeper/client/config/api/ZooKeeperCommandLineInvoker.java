package com.ubs.f35.core.zookeeper.client.config.api;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.PosixParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClientException;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.common.ZooKeeperClientPropertiesLoader;
import com.ubs.f35.core.zookeeper.client.tools.ZooKeeperTreeExporter;
import com.ubs.f35.core.zookeeper.client.tools.ZooKeeperTreeImporter;

public class ZooKeeperCommandLineInvoker {

    static final Logger logger = LoggerFactory.getLogger(ZooKeeperCommandLineInvoker.class);

    private static final String OPTION_IMPORT_FILE = "import-file";
    private static final String OPTION_IMPORT_FILE_MULTI = "import-file-multi";
    private static final String OPTION_IMPORT_FILE_CLASSPATH = "import-file-classpath";
    private static final String OPTION_PRETTY_PRINT = "pretty-print";
    private static final String OPTION_DELETE_SUBTREE = "delete-subtree";
    private static final String OPTION_EXPORT_TREE = "export-tree";
    private static final String OPTION_ROOT_NODE = "root-node";
    private static final String OPTION_IMPORT_TREE = "import-tree";
    private static final String OPTION_FORCE = "force";

    //temp commands
    private static final String OPTION_IMPORT_FILE_MULTI_UNCHECKED = "import-file-multi-unchecked";
    private static final String OPTION_IMPORT_FILE_UNCHECKED = "import-file-unchecked";    
    
    private static final List<String> suportingArgs = Lists.newArrayList(OPTION_DELETE_SUBTREE, OPTION_EXPORT_TREE, OPTION_IMPORT_FILE, 
                                                                         OPTION_IMPORT_FILE_CLASSPATH, OPTION_IMPORT_FILE_MULTI, 
                                                                         OPTION_IMPORT_TREE, OPTION_PRETTY_PRINT);
    
    private static OperationPropertiesDirectory opd = new OperationPropertiesDirectory();
    static {
        initPropertyDirectory();
    }

    private ZooKeeperClient client;
    private ZooKeeperService service;
    private CheckedZooKeeperPropertyFileImporter propertyFileImporter;
    private ZooKeeperPropertyFileImporter uncheckedPropertyFileImporter;
    private ZooKeeperTreeImporter treeImporter;
    private ZooKeeperTreeExporter treeExporter;

    private static Properties properties;

    ZooKeeperCommandLineInvoker() throws ZooKeeperClientException {

        client = ZooKeeperClient.newFromZooKeeperClientProperties(properties, true);
        /*
        client.connect(properties.getProperty(ZooKeeperClientPropertiesLoader.HOST_PORTS),
                properties.getProperty(ZooKeeperClientPropertiesLoader.SESSION_TIMEOUT),
                properties.getProperty(ZooKeeperClientPropertiesLoader.CONNECTION_TIMEOUT),
                properties.getProperty(ZooKeeperClientPropertiesLoader.USERNAME),
                properties.getProperty(ZooKeeperClientPropertiesLoader.PASSWORD));
        */
        service = new ZooKeeperConfigService(client);
    }
    
    CheckedZooKeeperPropertyFileImporter getCheckedPropertyFileImporter() {
        if(propertyFileImporter == null) {
            propertyFileImporter = new CheckedZooKeeperPropertyFileImporter(service);
        }
        return propertyFileImporter;
    }
    
    ZooKeeperPropertyFileImporter getUncheckedPropertyFileImporter() {
        if(uncheckedPropertyFileImporter == null) {
            uncheckedPropertyFileImporter = new ZooKeeperPropertyFileImporter(service);
        }
        return uncheckedPropertyFileImporter;
    }    
    
    ZooKeeperTreeImporter getZooKeeperTreeImporter() {
        if(treeImporter == null) {
            treeImporter = new ZooKeeperTreeImporter(client);
        }
        return treeImporter;        
    }
    
    ZooKeeperTreeExporter getZooKeeperTreeExporter() {
        if(treeExporter == null) {
            treeExporter = new ZooKeeperTreeExporter(service);
        }
        return treeExporter;        
    }    

    void importMultipleFilesFromPath(List<String> filePaths) throws Exception {
        getCheckedPropertyFileImporter().importMultipleFromPath(filePaths);
    }
    
    void uncheckedImportMultipleFilesFromPath(List<String> filePaths) throws Exception {
        getUncheckedPropertyFileImporter().importMultipleFromPath(filePaths);
    }    

    void uncheckedImportFileFromPath(String filePath) throws Exception {
        logger.info("importing file from path: {}", filePath);
        getUncheckedPropertyFileImporter().importFromPath(filePath);
    }
    
    void importFileFromPath(String filePath) throws Exception {
        logger.info("importing file from path: {}", filePath);
        getCheckedPropertyFileImporter().importFromPath(filePath);
    }

    void importFileFromClasspath(String classpathFile) throws Exception {
        logger.info("importing file from classpath: {}", classpathFile);
        getCheckedPropertyFileImporter().importFromClassPath(classpathFile);
    }

    void prettyPrint(String rootPath) throws Exception {
        logger.info("pretty printing root path: {}", rootPath);
        service.prettyPrint(rootPath);
    }

    void deleteSubTree(String rootPath, boolean force) throws Exception {
        logger.info("deleting subtree root path: {}", rootPath);
        
        if(!client.exists(rootPath)) {
            logger.error("Path ["+rootPath+"] does not exist");
            throw new CommandLineException.NoPathException();
        }
        
        int occurrence = StringUtils.countOccurrencesOf(rootPath, "/");
        
        if(occurrence < 5 && !force) {  // /f35/config/g/a/v ->  '/' (5)
            logger.error("Attention! DeleteSubTree command will delete everything under "
                    + rootPath + ". If you are confident please add 'force' flag to command line");
            throw new CommandLineException.ShortPathToDeleteException();
        }
        
        try {
            service.deleteSubTree(rootPath);
        } catch(IllegalStateException e) {
            logger.error("can not delete subtree {}", rootPath, e);
            throw new CommandLineException.LeaseValueLockedException();
        }
    }
    
    void exportTree(String filePath, String rootNodeName) throws Exception {
        logger.info("exporting the tree to the file: {}", filePath);
        getZooKeeperTreeExporter().exportTreeToFile(filePath, rootNodeName);
    }
    
    void importTree(String filePath) throws Exception {
        logger.info("Importing data from the file {} to zookeeper", filePath);
        getZooKeeperTreeImporter().importTreeFromFile(filePath);
    }    

    void stop() throws InterruptedException {
        client.stop();
    }
    
    private static void initPropertyDirectory() {
        opd.addPropertyForAll(ZooKeeperClientPropertiesLoader.HOST_PORTS, 
                              ZooKeeperClientPropertiesLoader.SESSION_TIMEOUT, 
                              ZooKeeperClientPropertiesLoader.CONNECTION_TIMEOUT, 
                              ZooKeeperClientPropertiesLoader.USERNAME, 
                              ZooKeeperClientPropertiesLoader.PASSWORD);
        
        opd.addPropertyNameForOperations(Arrays.asList(OPTION_IMPORT_FILE, OPTION_IMPORT_FILE_MULTI, OPTION_IMPORT_FILE_CLASSPATH), 
                                             ZooKeeperClientPropertiesLoader.ENV, 
                                             ZooKeeperClientPropertiesLoader.GROUP_ID, 
                                             ZooKeeperClientPropertiesLoader.ARTIFACT_ID, 
                                             ZooKeeperClientPropertiesLoader.VERSION);
    }
    
    public static void main(String[] args) throws Exception {
        
        Options options = new Options();
        options.addOption(null, OPTION_IMPORT_FILE, true, "Import file from this location");
        options.addOption(null, OPTION_IMPORT_FILE_MULTI, true, "Import multiple files from this location");
        options.addOption(null, OPTION_IMPORT_FILE_CLASSPATH, true, "Import file from classpath");
        options.addOption(null, OPTION_PRETTY_PRINT, true, "Pretty print tree from this root path");
        options.addOption(null, OPTION_DELETE_SUBTREE, true, "Recursively delete tree from this root path");
        options.addOption(null, OPTION_EXPORT_TREE, true, "Exporting zookepper's data (tree) to the provided file");
        options.addOption(null, OPTION_IMPORT_TREE, true, "Importing to the zookeeper");
        options.addOption(null, OPTION_ROOT_NODE, true, "Root node name. Used during importing/exporting from/to the zookeeper");
        options.addOption(null, OPTION_IMPORT_FILE_MULTI_UNCHECKED, true, "Import multiple files from this location. Does not check locked nodes");
        options.addOption(null, OPTION_IMPORT_FILE_UNCHECKED, true, "Import file from this location. Does not check locked nodes");
        options.addOption(new Option("f", OPTION_FORCE, false, "Force deletion from the tree for short pathes"));

        CommandLineParser clp = new PosixParser();
        CommandLine cmd = clp.parse(options, args);
        
        if(cmd.getOptions().length == 0) {
            HelpFormatter formatter = new HelpFormatter();
            formatter.printHelp("zk", options);
            System.exit(new CommandLineException().exitCode());
        }
        
        Set<String> requiredVMArgs = Sets.newHashSet();
        for(Option each : cmd.getOptions()) {
            String optName = each.getLongOpt();
            requiredVMArgs.addAll(opd.getPropertiesList(optName));
        }
        properties = new ZooKeeperClientPropertiesLoader().loadFromSystem(requiredVMArgs);
        
        ZooKeeperCommandLineInvoker invoker = null;
        try {
            invoker = new ZooKeeperCommandLineInvoker();
            if (cmd.hasOption(OPTION_IMPORT_FILE)) {
                invoker.importFileFromPath(cmd.getOptionValue(OPTION_IMPORT_FILE));
            } else if (cmd.hasOption(OPTION_IMPORT_FILE_MULTI)) {
                String value = cmd.getOptionValue(OPTION_IMPORT_FILE_MULTI);
                Iterator<String> iterator = Splitter.on(',').omitEmptyStrings().trimResults().split(value).iterator();
                List<String> filePaths = new ArrayList<String>();
                while (iterator.hasNext()) {
                    filePaths.add(iterator.next());
                }
                invoker.importMultipleFilesFromPath(filePaths);
            } else if (cmd.hasOption(OPTION_IMPORT_FILE_MULTI_UNCHECKED)) {
                String value = cmd.getOptionValue(OPTION_IMPORT_FILE_MULTI_UNCHECKED);
                Iterator<String> iterator = Splitter.on(',').omitEmptyStrings().trimResults().split(value).iterator();
                List<String> filePaths = new ArrayList<String>();
                while (iterator.hasNext()) {
                    filePaths.add(iterator.next());
                }
                invoker.uncheckedImportMultipleFilesFromPath(filePaths);
            } else if (cmd.hasOption(OPTION_IMPORT_FILE_CLASSPATH)) {
                invoker.importFileFromClasspath(cmd.getOptionValue(OPTION_IMPORT_FILE_CLASSPATH));
            } else if (cmd.hasOption(OPTION_PRETTY_PRINT)) {
                invoker.prettyPrint(cmd.getOptionValue(OPTION_PRETTY_PRINT));
            } else if (cmd.hasOption(OPTION_DELETE_SUBTREE)) {
                invoker.deleteSubTree(cmd.getOptionValue(OPTION_DELETE_SUBTREE), cmd.hasOption(OPTION_FORCE));
            } else if (cmd.hasOption(OPTION_EXPORT_TREE)) {
                invoker.exportTree(cmd.getOptionValue(OPTION_EXPORT_TREE), cmd.getOptionValue(OPTION_ROOT_NODE));
            } else if (cmd.hasOption(OPTION_IMPORT_TREE)) {
                invoker.importTree(cmd.getOptionValue(OPTION_IMPORT_TREE));
            } else if (cmd.hasOption(OPTION_IMPORT_FILE_UNCHECKED)) {
                invoker.uncheckedImportFileFromPath(cmd.getOptionValue(OPTION_IMPORT_FILE_UNCHECKED));
            } else if (cmd.hasOption(OPTION_IMPORT_FILE_MULTI_UNCHECKED)) {
                String value = cmd.getOptionValue(OPTION_IMPORT_FILE_MULTI_UNCHECKED);
                Iterator<String> iterator = Splitter.on(',').omitEmptyStrings().trimResults().split(value).iterator();
                List<String> filePaths = new ArrayList<String>();
                while (iterator.hasNext()) {
                    filePaths.add(iterator.next());
                }
                invoker.uncheckedImportMultipleFilesFromPath(filePaths);
            } else {
                throw new IllegalStateException("no recognised options found");
            }
        } catch(Throwable t) {
            logger.error("Can not execute command {}", Arrays.toString(args), t);
            
            if(t instanceof CommandLineException) {
                System.exit(((CommandLineException)t).exitCode());
            } else {
                System.exit(new CommandLineException().exitCode());
            }
        }
        finally {
            if (invoker != null) {
                invoker.stop();
            }
        }
    }

    /**
     * Holds mandatory VM arguments to be specified for the given operation
     *
     */
    private static class OperationPropertiesDirectory {
        
        private Map<String, List<String>> operationToProperties = new HashMap<String, List<String>>();
        private List<String> commonProperties = new ArrayList<String>();

        /**
         * Add the list of property names for the operation
         * @param operationName
         * @param propertyName
         */
        public void addPropertyNameForOperation(String operationName, String... propertyNames) {
            if(operationToProperties.containsKey(operationName)) {
                operationToProperties.get(operationName).addAll(Arrays.asList(propertyNames));
            } else {
                List<String> propsList = Lists.newArrayList(propertyNames);
                operationToProperties.put(operationName, propsList);
            }
        }
        
        public void addPropertyNameForOperations(List<String> operationNames, String... propertyNames) {
            for(String operationName : operationNames) {
                addPropertyNameForOperation(operationName, propertyNames);
            }
        }        
        
        /**
         * Add the property for any operation
         * @param propertyName
         */
        public void addPropertyForAll(String... propertyName) {
            commonProperties.addAll(Arrays.asList(propertyName));
        }
        
        public List<String> getPropertiesList(String operationName) {
            List<String> result = Lists.newArrayList();
            result.addAll(commonProperties);
            if(operationToProperties.containsKey(operationName)) {
                result.addAll(operationToProperties.get(operationName));
            }
            return result;
        }
    }
    
}