package com.ubs.f35.core.zookeeper.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.core.io.ClassPathResource;

import com.google.common.io.Closeables;

public class PropertyUtils {

    public static Properties loadFromFilePath(String filePath) {
        return loadFromFilePath(filePath, null);
    }

    public static Properties loadFromFilePath(String filePath, Properties defaultProperties) {
        Properties properties = new Properties(defaultProperties);
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(new File(filePath).getCanonicalFile());
            properties.load(fis);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            Closeables.closeQuietly(fis);
        }
        return properties;
    }

    public static Properties loadFromClassPath(String fileName) {
        ClassPathResource classPathResource = new ClassPathResource(fileName);
        Properties properties = new Properties();
        InputStream is = null;
        try {
            is = classPathResource.getInputStream();
            properties.load(is);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            Closeables.closeQuietly(is);
        }
        return properties;
    }

    public static void storeToFilePath(String filePath, Properties properties) throws IOException {
        File file = new File(filePath).getCanonicalFile();
        FileOutputStream fis = null;
        try {
            fis = new FileOutputStream(file);
            properties.store(fis, null);
        } finally {
            Closeables.closeQuietly(fis);
        }
    }

}