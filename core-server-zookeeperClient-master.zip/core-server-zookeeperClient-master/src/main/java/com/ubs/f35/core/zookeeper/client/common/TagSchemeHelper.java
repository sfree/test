package com.ubs.f35.core.zookeeper.client.common;

import java.util.Arrays;

public class TagSchemeHelper {

    private static final String SEPARATOR = ":";
    private static final String TAG = "tag";
    protected final StringBuilder builder = new StringBuilder();

    public TagSchemeHelper() {
        builder.append(TAG);
    }

    public TagSchemeHelper add(String tag) {
        append(tag);
        return this;
    }

    public TagSchemeHelper addSeparator() {
        builder.append(SEPARATOR);
        return this;
    }

    protected void append(String string) {
        builder.append(SEPARATOR).append(string);
    }

    public static TagScheme parse(String name) {
        String[] tags = name.split(SEPARATOR);
        return new TagScheme(tags);
    }

    @Override
    public String toString() {
        return builder.toString();
    }

    public static class TagScheme {

        private final String[] tags;

        public TagScheme(String[] tags) {
            this.tags = tags;
        }

        public boolean hasTag(String tag) {
            for (int i = 0; i < tags.length; i++) {
                if (tag.equals(tags[i])) {
                    return true;
                }
            }
            return false;
        }

        @Override
        public String toString() {
            return "TagScheme [tags=" + Arrays.toString(tags) + "]";
        }

    }

}