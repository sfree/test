package com.ubs.f35.core.zookeeper.client.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZookeeperRootPathResolver {

    static final Logger logger = LoggerFactory.getLogger(ZookeeperRootPathResolver.class);
    
    protected String root;
    protected String groupId;
    protected String artifactId;
    protected String version;
    
    protected String resolvedRoot;
    protected String resolvedApplicationRootPath;
    
    public static final String UNKNOWN = "UNKNOWN";

    private static final String ROOT_NAMESPACE = "f35";    
    
    public ZookeeperRootPathResolver(String root, String groupId, String artifactId, String version) {
        this.root = root;
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.version = version;
        validate();
    }
    
    public ZookeeperRootPathResolver(String root) {
        this(root, System.getProperty(ZooKeeperClientPropertiesLoader.GROUP_ID),
                   System.getProperty(ZooKeeperClientPropertiesLoader.ARTIFACT_ID),
                   System.getProperty(ZooKeeperClientPropertiesLoader.VERSION));
    }
    
    public ZookeeperRootPathResolver() {
        this(ROOT_NAMESPACE);
    }    
    
    protected void validate() {
        
        if(groupId == null || groupId.isEmpty()) {
            groupId = UNKNOWN;
            logger.error("{} is not provided. Set to {}", ZooKeeperClientPropertiesLoader.GROUP_ID, UNKNOWN);
        }
        
        if(artifactId == null || artifactId.isEmpty()) {
            artifactId = UNKNOWN;
            logger.error("{} is not provided. Set to {}", ZooKeeperClientPropertiesLoader.ARTIFACT_ID, UNKNOWN);
        }
        
        if(version == null || version.isEmpty()) {
            version = UNKNOWN;
            logger.error("{} is not provided. Set to {}", ZooKeeperClientPropertiesLoader.VERSION, UNKNOWN);
        }
        
        this.resolvedRoot = new PathBuilder(root, false).toString();
        this.resolvedApplicationRootPath = new PathBuilder(root, false).appendAsIs(groupId())
                                                                       .appendAsIs(artifactId())
                                                                       .appendAsIs(version()).toString();
    }

    public String resolveRoot() {
        return resolvedRoot;
    }
    
    public String resolveApplicationRootPath() {
        return resolvedApplicationRootPath;
    }    

    public String groupId() {
        return groupId;
    }

    public String artifactId() {
        return artifactId;
    }

    public String version() {
        return version;
    }

}