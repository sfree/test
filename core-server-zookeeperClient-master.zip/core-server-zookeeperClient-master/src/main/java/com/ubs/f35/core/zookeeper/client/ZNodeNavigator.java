package com.ubs.f35.core.zookeeper.client;

/**
 * The interface is used in the zookeeper tree's navigation functionality. 
 * Every observer node is passed to this interface.
 * See {@link ZooKeeperService#navigate(String, ZNodeNavigator)}
 * 
 * @author chernyse
 * 
 */

public interface ZNodeNavigator {

    public enum NavigateResult {
        CONTINUE, TERMINATE, SKIP_SIBLINGS, SKIP_SUBTREE;
    }

    /**
     * Called on every navigated zookeeper's node.
     * Returned navigation result indicates how to proceed the walk
     * @param zNode
     * @return
     * @throws Exception
     */
    NavigateResult navigate(ZNode zNode) throws Exception;

}