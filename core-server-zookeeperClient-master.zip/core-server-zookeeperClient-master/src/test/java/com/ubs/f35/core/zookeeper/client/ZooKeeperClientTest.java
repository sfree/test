package com.ubs.f35.core.zookeeper.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.Vector;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient.ZKConnectionCallback;


public class ZooKeeperClientTest {

    private static final Logger logger = LoggerFactory.getLogger(ZooKeeperClientConnectionTest.class);
    private ZooKeeperStandaloneTestServer server;
    private ZooKeeperClient client;

    @Before
    public void setUp() {
        server = new ZooKeeperStandaloneTestServer();
        client = new ZooKeeperClient();
        client.reconnectInterval = 2000; // 2 sec
        client.initializeConnectionThreadService();
    }    
    
    @Test
    public void tesWaitForAlive() throws Exception {

        //Purpose: test waitForAlive with connected client

        
        // Open the socket just to get the available port
        final int port = getAvailablePort();
        String hostPort = getZKHostPort(port);

        startServer(port);
        
        logger.info("Connecting to the server that is not started yet");
        client.connect(hostPort, 1000, 2500, Collections.<ZKConnectionCallback>emptyList(), true);
        
        FutureTask<Boolean> aliveChecker = new FutureTask<Boolean>(new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                logger.info("Checking waitForAlive");
                client.waitForAlive();
                return true;
            }
        });
        
        Thread aliveCheckerThread = new Thread(aliveChecker);
        aliveCheckerThread.start();
        
        assertTrue("Client is not alive but should be", aliveChecker.get(10, TimeUnit.SECONDS));        
    }
    
    @Test(expected=TimeoutException.class)
    public void tesWaitForAliveDisconnected() throws Exception {

        //Purpose: test waitForAlive with disconnected client
        
        //start checking the liveness of the client
        FutureTask<Boolean> aliveChecker = new FutureTask<Boolean>(new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                logger.info("Checking waitForAlive");
                client.waitForAlive();
                return true;
            }
        });
        
        Thread aliveCheckerThread = new Thread(aliveChecker);
        aliveCheckerThread.start();

        //client should not be alive 
        assertFalse("Client is alive but should not be", aliveChecker.get(10, TimeUnit.SECONDS));        
    }

    @Test
    public void tesWaitForAlivePostConnected() throws Exception {

        //Purpose: test waitForAlive with the client connected after the waitForAlive called
        
        FutureTask<Boolean> aliveChecker = new FutureTask<Boolean>(new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                logger.info("Checking waitForAlive");
                client.waitForAlive();
                return true;
            }
        });
        
        Thread aliveCheckerThread = new Thread(aliveChecker);
        aliveCheckerThread.start();
        
        //starting server

        final int port = getAvailablePort();
        String hostPort = getZKHostPort(port);
        startServer(port);
        
        logger.info("Connecting to the server that is not started yet");
        client.connect(hostPort, 1000, 2500, Collections.<ZKConnectionCallback>emptyList(), true);
        
        assertTrue("Client should be alive", aliveChecker.get(10, TimeUnit.SECONDS));
    }

    @Test
    public void tesTimedOutWaitForAliveDisconnected() throws Exception {

        //Purpose: test waitForAlive with disconnected client

        //client should not be alive 
        assertFalse("Client is alive but should not be", client.waitForAlive(10, TimeUnit.SECONDS));        
    }
    
    @Test
    public void tesTimedOutWaitForAlivePostConnected() throws Exception {

        //Purpose: test waitForAlive with the client connected after the timed out waitForAlive called

        FutureTask<Boolean> aliveChecker = new FutureTask<Boolean>(new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                logger.info("Checking waitForAlive");
                return client.waitForAlive(30, TimeUnit.SECONDS);
            }
        });
        
        Thread aliveCheckerThread = new Thread(aliveChecker);
        aliveCheckerThread.start();
        
        
        //starting server

        final int port = getAvailablePort();
        String hostPort = getZKHostPort(port);
        startServer(port);

        logger.info("Connecting to the server that is not started yet");
        client.connect(hostPort, 1000, 2500L, true);
        
        assertTrue("Client should be alive", aliveChecker.get(10, TimeUnit.SECONDS));
    }
    
    @Test
    public void tesWaitForAliveInterrupted() throws Exception {    

        //Purpose: test waitForAlive call after the server is stopped and then started back

        final int port = getAvailablePort();
        String hostPort = getZKHostPort(port);
        startServer(port);
        
        logger.info("Connecting to the server");
        client.connect(hostPort, 1000, 2500, Collections.<ZKConnectionCallback>emptyList(), true);
  
        //default CopyOnWriteArrayList is not suitable for size() calls
        client.zkConnectionCallbacks = new Vector<ZooKeeperClient.ZKConnectionCallback>(); 
        
        FutureTask<Boolean> aliveChecker = new FutureTask<Boolean>(new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                logger.info("Checking waitForAlive");
                client.waitForAlive();
                return true;
            }
        });
        
        Thread aliveCheckerThread = new Thread(aliveChecker);
        aliveCheckerThread.start();
        assertTrue("Client is not alive but should be", aliveChecker.get(10, TimeUnit.SECONDS));
        
        stopServer();
        
        Thread.sleep(5000); //sleep 5 seconds to get client find out that the server has gone
        
        
        //check that unsuccessful call doesn't leave callbacks in the list
        
        //1. Timed out method call
        int callacks0 = client.zkConnectionCallbacks.size();
        assertFalse("Client is alive but should not be", client.waitForAlive(5, TimeUnit.SECONDS));
        int callacks1 = client.zkConnectionCallbacks.size();
        
        assertEquals(callacks0, callacks1);
        
        //2. Not timed out method call
        Thread aliveCheckerThread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                logger.info("Checking waitForAlive");
                try {
                    client.waitForAlive();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        aliveCheckerThread2.start();
        aliveCheckerThread2.interrupt();
        aliveCheckerThread2.join();
        
        int callacks2 = client.zkConnectionCallbacks.size();
        assertEquals(callacks1, callacks2); //as call is interrupted the callback should be de-registered
        
        //starting to wait and start the cluster
        Thread aliveCheckerThread3 = new Thread(new Runnable() {
            @Override
            public void run() {
                logger.info("Checking waitForAlive");
                try {
                    client.waitForAlive();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        aliveCheckerThread3.start();
        
        startServer(port);
        
        aliveCheckerThread3.join(10000);
                
        int callacks3 = client.zkConnectionCallbacks.size();
        assertEquals(0, callacks3); //as call is interrupted the callback should be de-registered
    }
    
    
    
    
    private int getAvailablePort() throws Exception {
        // Open the socket just to get the available port
        ServerSocket socket = new ServerSocket(0);
        final int port = socket.getLocalPort();        
        socket.close();
        return port;
    }
        
    private void startServer(final int port) throws Exception {
        
        Thread serverStarter = new Thread(new Runnable() {
            @Override
            public void run() {
                server.start(port);
            }
        });

        logger.info("Starting the server");
        serverStarter.start();
        serverStarter.join();
    }
    
    private void stopServer() {
        logger.info("stopping server");
        if (server != null && server.isStarted()) {
            logger.info("closing server");
            server.stop();
        }
    }        
    
    public String getZKHostPort(int port) {
        try {
            return InetAddress.getLocalHost().getHostName() + ":" + port;
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
    }  

    @After
    public void afterTest() throws InterruptedException {
        if (client != null) {
            logger.info("closing client");
            client.stop();
        }

        stopServer();
    }
    
}
