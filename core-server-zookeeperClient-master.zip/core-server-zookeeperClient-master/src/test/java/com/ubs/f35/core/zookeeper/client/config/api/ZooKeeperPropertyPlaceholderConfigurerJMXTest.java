package com.ubs.f35.core.zookeeper.client.config.api;

import static org.junit.Assert.*;

import java.util.Properties;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.ZooKeeperStandaloneTestServer;
import com.ubs.f35.core.zookeeper.client.common.ZooKeeperClientPropertiesLoader;
import com.ubs.f35.core.zookeeper.client.common.ZookeeperRootPathResolver;
import com.ubs.f35.core.zookeeper.client.config.api.ZooKeeperPropertyPlaceholderConfigurerIntegrationTest.Bean;

/**
 * B-14312: created to test the {@link ZooKeeperPropertyPlaceholderConfigurer#getApplicationProperties()} method, to ensure
 * that it correctly masks encrypted properties.
 *  
 * @author alexanne
 */
public class ZooKeeperPropertyPlaceholderConfigurerJMXTest {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(ZooKeeperPropertyPlaceholderConfigurerJMXTest.class);
    
    private static final int PORT = 21811;     // matches the port in src/test/resources/properties/zookeeper-client.properties
    
    private ZooKeeperClient client = new ZooKeeperClient();
    private ZooKeeperStandaloneTestServer server = new ZooKeeperStandaloneTestServer();        
    
    private static final String GROUP_ID = "com.ubs.dummy";
    private static final String ARTIFACT_ID = "dummy-artifact";
    private static final String VERSION = "1.0.0";     
    
    private static final String KEY_A_VALUE = "valA";
    
    // value is: top-secret
    private static final String KEY_B_ENCRYPTED_VALUE = "amhjhvSVIX8Fw4RgFXxFOooPn7ERewffyhdcWmNUIzEaoJa9Qr5BMhI/7NMmw+SSfI/KDwUd5q6DuHcO6dTTFkGW+nnx3PHMGPlSZfHycfXAA5XLW3ZvxKNVoL+L/8uZtPP9rpfaIuTe+vF1/8QdXLEyIiR5PA6fLQoFlc8h2OUIADCS044jw83zp1sgkLaCciZBVsQKor6WtGCSIG5h7BxYX+pOLqvwACfTUZQsgXfVKX1WNAdXydlfgUMQRRAKtZiZ3uWYaeLewUA25OceDCYS+0qtpsHOXu6EFYzlpyl1aG+0ezGZm2NKLldLUEE2nCZ3WecszymugaftfafibQ==";
    
    // value is: leased-secret
    private static final String KEY_C_ENCRYPTED_VALUE = "pOslM7VC9KuosxXqzPDgrDoUxT6d9e9nigseRjWXnEoeU0b4aCarHggAPX35zzHirJbcVih3EiQ3ZbVL6VFt8b1Vvzd6o8vnf4EdDMbDKtbnpMWPIb5wWsYJMUWr63OXajUE5i7TycP4BIoT3jX0V6fucx7yBBFBZ615tgEYkz/xMlJGbyXBD2uBBkN33jirMpHT8zxbhQC4J0MEgFTC1yo54q6GWSCue3gwUyZw4j/3Y+tqJ6WbgCpr02h7TcoFNTxt7oeVwR8O3qiegCE4H8fwkHutDcVlYKzmJ7e1WMZeXHrruK017AmMKAsrpkQO5cGUOkHJSRNub2BG4WW83w==";
    
    @SuppressWarnings("serial")
    private Properties toImport = new Properties() {{
        setProperty("keyA", KEY_A_VALUE);
        
        // value is 'top-secret'
        setProperty("keyB", "expression: { encrypted:, value: " + KEY_B_ENCRYPTED_VALUE + " }");
        
        // leased encrypted value is 'top-secret'
        setProperty("leased", "expression: { encrypted:, leased:, keys: [keyC], values: [ [" + KEY_C_ENCRYPTED_VALUE + "] ] }");
        
        // properties for test-zkppc-with-placeholders-context.xml
        setProperty("a", "100");
        setProperty("a.c", "200");
        setProperty("a.b.username", "testuser");
    }};   
    
    @Test
    public void testEncryptedPropertiesMasked() throws Exception {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "test-zkppc-with-encrypted-properties.xml");
        
        // first, assert that the bean was set up correctly
        TestBean testBean = context.getBean(TestBean.class);
        assertEquals("valA", testBean.getKeyA());
        assertEquals("top-secret", testBean.getKeyB());
        assertEquals("leased-secret", testBean.getKeyC());
        
        // then check the jmx value in the ZooKeeperPropertyPlaceholderConfigurer
        ZooKeeperPropertyPlaceholderConfigurer ppc = context.getBean(ZooKeeperPropertyPlaceholderConfigurer.class);
        assertNotNull(ppc); 
        
        // and finally, check the value returned by jmx method
        boolean keyAFound = false, keyBFound = false, keyCFound = false;
        String[] lines = ppc.getApplicationProperties().split(System.getProperty("line.separator"));
        for (String propertyLine : lines) {
            if (propertyLine.startsWith("keyA=")) {
                assertPropertyLineValueEquals(propertyLine, KEY_A_VALUE);
                keyAFound = true;
            } else if (propertyLine.startsWith("keyB=")) {
                assertPropertyLineValueEquals(propertyLine, KEY_B_ENCRYPTED_VALUE);
                keyBFound = true;
            } else if (propertyLine.startsWith("leased.keyC=")) {
                assertPropertyLineValueEquals(propertyLine, KEY_C_ENCRYPTED_VALUE);
                keyCFound = true;
            }
        }
        
        assertTrue("Key A not found in applicationProperties", keyAFound);
        assertTrue("Key B not found in applicationProperties", keyBFound);
        assertTrue("Key C not found in applicationProperties", keyCFound);
        
        context.close();
    }
    
    @Test
    public void testApplicationPropertiesNoneEncrypted() throws Exception {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "test-zkppc-with-placeholders-context.xml");
        
        // first, assert that the bean was set up correctly
        Bean testBean = context.getBean(Bean.class);
        assertEquals("100", testBean.getA());
        assertEquals("testuser", testBean.getB());
        assertEquals("200", testBean.getC());
        
        // then check the jmx value in the ZooKeeperPropertyPlaceholderConfigurer
        ZooKeeperPropertyPlaceholderConfigurer ppc = context.getBean(ZooKeeperPropertyPlaceholderConfigurer.class);
        assertNotNull(ppc); 
        
        // and finally, check the value returned by jmx method
        boolean keyAFound = false, keyBFound = false, keyCFound = false;
        String[] lines = ppc.getApplicationProperties().split(System.getProperty("line.separator"));
        for (String propertyLine : lines) {
            if (propertyLine.startsWith("a.c=")) {
                assertPropertyLineValueEquals(propertyLine, "200");
                keyAFound = true;
            } else if (propertyLine.startsWith("a.b.username=")) {
                assertPropertyLineValueEquals(propertyLine, "testuser");
                keyCFound = true;
            } else if (propertyLine.startsWith("a=")) {
                assertPropertyLineValueEquals(propertyLine, "100");
                keyBFound = true;
            }
        }
        
        assertTrue("Key A not found in applicationProperties", keyAFound);
        assertTrue("Key B not found in applicationProperties", keyBFound);
        assertTrue("Key C not found in applicationProperties", keyCFound);
        
        context.close();
    }    
    
    private void assertPropertyLineValueEquals(String propertyLine, String expectedValue) {        
        String actualValue = propertyLine.substring(propertyLine.indexOf("=") + 1);
        assertEquals(expectedValue, actualValue);
    }

    @BeforeClass
    public static void beforeClass() throws Exception {
        System.setProperty(ZooKeeperClientPropertiesLoader.GROUP_ID, GROUP_ID);
        System.setProperty(ZooKeeperClientPropertiesLoader.ARTIFACT_ID, ARTIFACT_ID);
        System.setProperty(ZooKeeperClientPropertiesLoader.VERSION, VERSION);
        System.setProperty(ZooKeeperClientPropertiesLoader.ENV, "local");
    }    
    
    @Before
    public void setup() throws Exception {
        startServer(PORT);
        connectClient(PORT);
        
        ZooKeeperService zks = new ZooKeeperService(client);
        ZooKeeperPropertyFileImporter pfi = new ZooKeeperPropertyFileImporter(zks, 
                new ZookeeperRootPathResolver(ZooKeeperConfigService.ZOOKEEPER_CONFIG_ROOT_PATH, GROUP_ID, ARTIFACT_ID, VERSION));
        pfi.importProperties(toImport);        
    }
    
    @After
    public void tearDown() {
        client.stop();
        server.stop(true);         
    }
    
    private void connectClient(int port) throws Exception {
        client.connect(server.hostPort(), "1000", "2000", "foo", "bar");
    }    
    
    private void startServer(int port) {
        LOGGER.info("starting server on port {}", port);
        server.start(port);
    }      
    
    public static class TestBean {
        private String keyA;
        private String keyB;
        private String keyC;
        
        public String getKeyA() {
            return keyA;
        }
        
        public void setKeyA(String keyA) {
            this.keyA = keyA;
        }

        public String getKeyB() {
            return keyB;
        }

        public void setKeyB(String keyB) {
            this.keyB = keyB;
        }

        public String getKeyC() {
            return keyC;
        }

        public void setKeyC(String keyC) {
            this.keyC = keyC;
        }
    }
}
