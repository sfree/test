package com.ubs.f35.utils;

import org.junit.Test;
import org.slf4j.LoggerFactory;

public class LogbackTest {

    @Test(expected=NoClassDefFoundError.class)    
    public void ensureLogbackNotOnClasspath() {
        // other tests rely on logback not being on the classpath, therefore we need to ensure that is the case
        // NB: it is not a valid solution to delete this test!! See ZooKeeperClient for why this is required. It
        // has a direct dependency on ch.qos.logback.classic.Logger, and some enviroments do not use Logback for logging.
        // Therefore we need to test that it will start up without Logback. If this test fails, then it means we have
        // found Logback on the testing classpath, which means we can't guarantee that ZooKeeperClient will work without
        // logback
        @SuppressWarnings("unused")
        ch.qos.logback.classic.Logger logger = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(LogbackTest.class);
    }
}
