package com.ubs.f35.core.hash;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.UUID;

import junit.framework.TestCase;

import org.junit.Test;

import com.ubs.f35.core.hash.BloomFilter.BloomFilterReader;

public class BloomFilterTest extends TestCase {

    @Test
    public void testFilterSize() {
        int n = 500000;
        double falsePositiveProbability = 0.01;
        BloomFilter filter = new BloomFilter(falsePositiveProbability, n);
        assertEquals(BloomFilter.DEFAULT_HASH_FUNCTIONS_NUMBER, filter.getHashFunctionsNumber());
        int k = filter.getHashFunctionsNumber();
        int m = filter.getBitSet().size();
        
        double f = Math.pow(1 - Math.exp(-(double)k * (double)n / (double)m), (double)k);
        DecimalFormat dFormat = new DecimalFormat("#.##");

        double formattedF = Double.valueOf(dFormat.format(f));
        
        assertEquals(falsePositiveProbability, formattedF);
    }
    
    @Test
    public void testFilterToArray() {
        
        int n = 10;
        double falsePositiveProbability = 0.01;
        BloomFilter filter = new BloomFilter(falsePositiveProbability, n);
        
        byte[] empty = filter.toByteArray();
        assertEquals(filter.getHashFunctionsNumber(), empty[0]);
        for(int i = 1; i < empty.length; i++) {
            assertEquals(0, empty[i]);
        }
        
        filter.add("ASDA".getBytes());
        filter.add("Tesco".getBytes());
        filter.add("Saynsbury".getBytes());
        
        byte[] coded = filter.toByteArray();
        byte[] expected = new byte[]{5, 8, 0, 8, 40, 32, 0, -128, 0, 16, 13, 0, 0, 12, 16, 0, 4};
        
        assertTrue(Arrays.equals(expected, coded));
    }
    
    @Test
    public void testFilterReader() {
        
        int n = 30000;
        double falsePositiveProbability = 0.00001;
        BloomFilter filter = new BloomFilter(falsePositiveProbability, n);
        
        byte[] empty = filter.toByteArray();
        assertEquals(filter.getHashFunctionsNumber(), empty[0]);
        for(int i = 1; i < empty.length; i++) {
            assertEquals(0, empty[i]);
        }
        
        filter.add("ASDA".getBytes());
        filter.add("Tesco".getBytes());
        filter.add("Saynsbury".getBytes());
        
        byte[] coded = filter.toByteArray();
        
        BloomFilterReader reader = new BloomFilterReader(coded);
        
        assertTrue(reader.contains("ASDA".getBytes()));
        assertTrue(reader.contains("Tesco".getBytes()));
        assertTrue(reader.contains("Saynsbury".getBytes()));
        assertFalse(reader.contains("Waitrose".getBytes()));
        
        assertEquals(reader.getFilter().getBitSet(), filter.getBitSet());
        assertEquals(filter.getHashFunctionsNumber(), reader.getFilter().getHashFunctionsNumber());
        
    }
    
    
    @Test
    public void testFalsePositives() {

        int testNumber = 20;
        
        double falsePositiveProbability = .000001;
        
        for (int j = 0; j < testNumber; j++) {
            
            int falsePositiveCounter = 0;
            
            int elementsNumber = (int)(50000 * Math.random());
            int testElementsNumber = (int)(elementsNumber * 10);
            
            BloomFilter filter = new BloomFilter(falsePositiveProbability, elementsNumber);
            Collection<String> uuids = new ArrayList<String>(elementsNumber);

            for (int i = 0; i < elementsNumber; i++) {
                String uuid = UUID.randomUUID().toString();
                uuids.add(uuid);
                filter.add(uuid.getBytes());
            }
            
            
            for (String uuid : uuids) {
                assertTrue(filter.contains(uuid.getBytes()));
            }

            for (int i = 0; i < testElementsNumber; i++) {
                String uuid = UUID.randomUUID().toString();
                boolean contains = filter.contains(uuid.getBytes());
                if (contains) {
                    falsePositiveCounter++;
                }
            }
            
            //System.out.println("Number of false positive events: " + falsePositiveCounter + ", test elements #: " + testElementsNumber);
            
          //added 10 a we are dealing with probability and values 2,3,4 are possible. If 10 - than something is likely wrong
            assertTrue("Number of false positive events: " + falsePositiveCounter + ", test elements #: " + testElementsNumber,
                    falsePositiveCounter < Math.ceil(testElementsNumber * falsePositiveProbability + 10));
        }        
        
    }
}
