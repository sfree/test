package com.ubs.f35.core.zookeeper.client.config;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

public class ConfigPropertyValueDecryptionProviderTest {
    
    @Test
    public void testResourceKey() throws Exception {
        ConfigPropertyValueDecryptionProvider provider = new ConfigPropertyValueDecryptionProvider();
        provider.setDecryptionKeyResource(new ClassPathResource("/keys/public_key.der"));
        Assert.assertNotNull(provider.getPublicKey());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testClasspathKey() throws NoSuchAlgorithmException, InvalidKeySpecException, IOException {
        ConfigPropertyValueDecryptionProvider provider = new ConfigPropertyValueDecryptionProvider();
        provider.setDecryptionKeyClassPath("keys/public_key.der");
        Assert.assertNotNull(provider.getPublicKey());
    }
    
    @SuppressWarnings("deprecation")
    @Test
    public void testFileKey() throws NoSuchAlgorithmException, InvalidKeySpecException, IOException {
        ConfigPropertyValueDecryptionProvider provider = new ConfigPropertyValueDecryptionProvider();
        provider.setDecryptionKeyFilePath("src/test/resources/keys/public_key.der");
        Assert.assertNotNull(provider.getPublicKey());
    }
    
    @Test(expected=IOException.class)
    public void testNoKey() throws NoSuchAlgorithmException, InvalidKeySpecException, IOException {
        ConfigPropertyValueDecryptionProvider provider = new ConfigPropertyValueDecryptionProvider();
     
        Assert.assertNotNull(provider.getPublicKey());
    }

}
