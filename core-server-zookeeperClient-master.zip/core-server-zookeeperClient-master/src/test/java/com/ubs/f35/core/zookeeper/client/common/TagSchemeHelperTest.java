package com.ubs.f35.core.zookeeper.client.common;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.ubs.f35.core.zookeeper.client.common.TagSchemeHelper.TagScheme;

public class TagSchemeHelperTest {

    @Test
    public void testRead() {
        String s = "tag:config:lease:encrypted";
        TagScheme scheme = TagSchemeHelper.parse(s);
        assertTrue(scheme.hasTag("tag"));
    }

    @Test
    public void testWrite() {
        TagSchemeHelper helper = new TagSchemeHelper().add("foo").add("bar");
        String output = helper.toString();
        assertEquals("tag:foo:bar", output);
        TagScheme scheme = TagSchemeHelper.parse(output);
        assertTrue(scheme.hasTag("tag"));
        assertTrue(scheme.hasTag("foo"));
        assertTrue(scheme.hasTag("bar"));
    }

}