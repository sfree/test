package com.ubs.f35.core.zookeeper.client;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.UnknownHostException;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.zookeeper.server.ServerConfig;
import org.apache.zookeeper.server.ZooKeeperServerMain;
import org.apache.zookeeper.server.quorum.QuorumPeerConfig;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.io.Files;

public class ZooKeeperStandaloneTestServer {

    private static final Logger logger = LoggerFactory.getLogger(ZooKeeperStandaloneTestServer.class);

    private static final int WAIT_TIME = 1000;
    private static String tmpDir;
    private int port;

    private static ZooKeeperServerMainCloseable zkServer;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Future<?> future;
    private boolean started;

    private static ZooKeeperStandaloneTestServer server = new ZooKeeperStandaloneTestServer();

    /**
     * Start server synchronously.
     */
    public void start() {

        /*
         * start server and wait a while
         */
        
    
        if(executor.isShutdown()) {
            executor = Executors.newSingleThreadExecutor();
        }

        logger.info("starting server and waiting for initialisation");
        future = executor.submit(new ZooKeeperServerStarter());
        wait(WAIT_TIME);
        logger.info("Server is started");
        started = true;

    }
    
    public void reStart() {
    
        if(executor.isShutdown()) {
            executor = Executors.newSingleThreadExecutor();
        }

        logger.info("starting server and waiting for initialisation");
        future = executor.submit(new ZooKeeperServerStarter(false));
        wait(WAIT_TIME);
        logger.info("Server is started");
        started = true;
    }
    

    public void start(int port) {
        this.port = port;
        start();
    }

    public void stop() {
        stop(true);
    }
    
    /**
     * Stop server synchronously.
     */
    public void stop(boolean cleanUp) {

        /*
         * shutdown server explicitly and wait a while
         * 
         * server doesn't respond to interruption it seems
         */

        zkServer.shutdown();
        
        /*
         * if still running send interruption (which zk stupidly ignores anyway)
         */
        if (!future.isDone()) {
            boolean cancelled = future.cancel(true);
            logger.info("task cancellation outcome: {}", cancelled);
        }

        executor.shutdownNow();

        if(cleanUp) {
            /*
             * assuming shutdown is complete cleanup tmp dirs
             */
            cleanUp();
        }
        
        started = false;
    }
    
    public void cleanUp() {
        try {
            logger.info("recursively deleting tmpDir");
            // TODO: delete still not working
            delete(new File(tmpDir));
            logger.info("successfully deleted tmpDir");
        } catch (IOException e) {
            logger.error("recursive delete of tmpDir failed: {}", e.getMessage());
        }        
    }
    
    private void delete(File f) throws IOException {
        if (f.isDirectory()) {
            for (File c : f.listFiles())
                delete(c);
        }
        if (!f.delete())
            logger.error("Can not delete {}", f.getCanonicalPath());
    }

    public String hostPort() {
        try {
            return InetAddress.getLocalHost().getHostName() + ":" + port;
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
    }
    
    public boolean isStarted() {
        return started;
    }
    
    public boolean isStopped() {
        return !started;
    }    

    void wait(int waitTime) {
        if (waitTime > 0) {
            try {
                Thread.sleep(waitTime);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * Increase visibility of shutdown method of zookeeper server.
     * @author bandopdh
     */
    private static class ZooKeeperServerMainCloseable extends ZooKeeperServerMain {

        @Override
        public void shutdown() {
            super.shutdown();
        }

    }

    /**
     * Zookeerp server starter.
     * @author bandopdh
     */
    private class ZooKeeperServerStarter implements Runnable {

        private boolean startNew = false;
        
        public ZooKeeperServerStarter(boolean startNew) {
            this.startNew = startNew;
        }
        
        public ZooKeeperServerStarter() {
            this(true);
        }
        
        @Override
        public void run() {

            try {

                /*
                 * create tmp dir, data log dir and tx log dir
                 */
                
                if (startNew) {
                    File tmpDirFile = Files.createTempDir().getCanonicalFile();
                    tmpDir = tmpDirFile.getCanonicalPath();
                    logger.info("created tmpDir: {}", tmpDir);
                }

                File dataLogDirFile = new File(tmpDir, "dataLogDir");
                dataLogDirFile.mkdir();
                String dataLogDir = dataLogDirFile.getCanonicalPath();
                logger.info("created dataLogDir: {}", dataLogDir);

                File txLogDirFile = new File(tmpDir, "txLogDir");
                txLogDirFile.mkdir();
                String txLogDir = txLogDirFile.getCanonicalPath();
                logger.info("created txLogDir: {}", txLogDir);                

                /*
                 * find free port to bind to
                 */
                if (port == 0) {
                    ServerSocket socket = new ServerSocket(0);
                    port = socket.getLocalPort();
                    socket.close();
                    logger.info("found free port: {}", port);
                }

                /*
                 * configure server
                 */

                Properties properties = new Properties();
                properties.setProperty("tickTime", "2000");
                properties.setProperty("initLimit", "5");
                properties.setProperty("syncLimit", "2");
                properties.setProperty("dataDir", dataLogDir);
                properties.setProperty("dataLogDir", txLogDir);
                properties.setProperty("clientPort", String.valueOf(port));
                properties.setProperty("preAllocSize", "16");
                
                logger.info("Properties: {}", properties);
                
                QuorumPeerConfig config = new QuorumPeerConfig();
                
                try {
                    logger.info("Parsing properties...");
                    config.parseProperties(properties);
                } catch(Throwable t) {
                    logger.error("Can not parse properties", t);
                }
                
                ServerConfig serverConfig = null;
                try {
                    serverConfig = new ServerConfig();
                    logger.info("ServerConfig is created. Reading configurations...");
                    serverConfig.readFrom(config);
                } catch(Throwable t) {
                    logger.error("Can not initialize serverConfig. Server startup aborted", t);
                    return;
                }
                
                /*
                 * start server
                 */
                
                logger.info("Runinng zookeeper server from config...");
                zkServer = new ZooKeeperServerMainCloseable();
                zkServer.runFromConfig(serverConfig);

            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        }

    }

    @Test
    public void test() {
        logger.info("running client test");
    }

    @BeforeClass
    public static void beforeClass() throws IOException, InterruptedException {
        logger.info("starting server");
        server.start();
    }

    @AfterClass
    public static void afterClass() throws InterruptedException {
        logger.info("closing server");
        server.stop();
    }

}