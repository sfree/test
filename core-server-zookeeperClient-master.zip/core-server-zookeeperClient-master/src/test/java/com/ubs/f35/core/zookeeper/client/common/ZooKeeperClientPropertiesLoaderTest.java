package com.ubs.f35.core.zookeeper.client.common;

import static org.junit.Assert.*;

import java.net.URL;
import java.util.Properties;

import org.junit.Test;

public class ZooKeeperClientPropertiesLoaderTest {

    @Test
    public void loadFromPath() throws Exception {
        // PURPOSE: make sure load from path works	
        Properties zkClientProperties = new ZooKeeperClientPropertiesLoader().loadFromPath();
        assertPropertiesLoadedCorrectly(zkClientProperties);
    }
    
    @Test    
    public void loadFromPathWithArg() {
        Properties zkClientProperties = new ZooKeeperClientPropertiesLoader().loadFromPath("/properties/zookeeper-client.properties");
        assertPropertiesLoadedCorrectly(zkClientProperties);        
    }
    
    @Test
    public void loadFromResource_filePath() {        
        URL resource = getClass().getClassLoader().getResource("properties/zookeeper-client.properties");
        assertNotNull(resource);
        
        String url = resource.toString();
        assertTrue(url.startsWith("file:"));
        
        Properties zkClientProperties = new ZooKeeperClientPropertiesLoader().loadFromResource(url);
        assertPropertiesLoadedCorrectly(zkClientProperties);
    }
    
    @Test
    public void loadFromResource_classpath() throws Exception {	
        Properties zkClientProperties = new ZooKeeperClientPropertiesLoader().loadFromResource("classpath:/properties/zookeeper-client.properties");
        assertPropertiesLoadedCorrectly(zkClientProperties);
    }

    private void assertPropertiesLoadedCorrectly(Properties zkClientProperties) {
        // these are the values in src/test/resources/properties/zookeeper-client.properties
        assertNotNull(zkClientProperties);
        assertFalse(zkClientProperties.isEmpty());        
        assertEquals("localhost:21811", zkClientProperties.getProperty("zookeeper.client.host.ports"));
        assertEquals("1000", zkClientProperties.getProperty("zookeeper.client.session.timeout"));
        assertEquals("2000", zkClientProperties.getProperty("zookeeper.client.connection.timeout"));
        assertEquals("foo", zkClientProperties.getProperty("zookeeper.client.username"));
        assertEquals("bar", zkClientProperties.getProperty("zookeeper.client.password"));
        assertEquals("5000", zkClientProperties.getProperty("zookeeper.client.reconnectInterval"));
    }
}
