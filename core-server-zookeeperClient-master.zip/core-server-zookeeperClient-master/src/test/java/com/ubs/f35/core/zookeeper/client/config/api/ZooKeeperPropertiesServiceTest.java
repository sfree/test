package com.ubs.f35.core.zookeeper.client.config.api;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClientException;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.ZooKeeperStandaloneTestServer;
import com.ubs.f35.core.zookeeper.client.common.ZooKeeperClientPropertiesLoader;
import com.ubs.f35.core.zookeeper.client.common.ZookeeperRootPathResolver;
import com.ubs.f35.core.zookeeper.client.config.ConfigPropertyValueDecryptionProvider;
import com.ubs.security.encryption.rsa.RSASecurityProvider;

public class ZooKeeperPropertiesServiceTest { 
    
    private static final Logger logger = LoggerFactory.getLogger(ZooKeeperPropertiesServiceTest.class);
    
    private static final int PORT = 21811;     // matches the port in src/test/resources/properties/zookeeper-client.properties
    
    private static final String CUSTOM_YAML_EXPRESSION = "expression: {internal:, value: anInternalValue}";
    
    private ZooKeeperClient client = new ZooKeeperClient();
    private ZooKeeperStandaloneTestServer server = new ZooKeeperStandaloneTestServer();    
    
    private String groupId = "com.ubs.dummy";
    private String artifactId = "dummy-artifact";
    private String version = "1.0.0";    
    
    @SuppressWarnings("serial")
    private Properties toImport = new Properties() {{
        setProperty("keyA", "valA");
        setProperty("keyB", "valB");
        setProperty("keyC.subKey", "valC");  
        
        // value is 'top-secret'
        setProperty("keyD.encrypted", "expression: { encrypted:, value: amhjhvSVIX8Fw4RgFXxFOooPn7ERewffyhdcWmNUIzEaoJa9Qr5BMhI/7NMmw+SSfI/KDwUd5q6DuHcO6dTTFkGW+nnx3PHMGPlSZfHycfXAA5XLW3ZvxKNVoL+L/8uZtPP9rpfaIuTe+vF1/8QdXLEyIiR5PA6fLQoFlc8h2OUIADCS044jw83zp1sgkLaCciZBVsQKor6WtGCSIG5h7BxYX+pOLqvwACfTUZQsgXfVKX1WNAdXydlfgUMQRRAKtZiZ3uWYaeLewUA25OceDCYS+0qtpsHOXu6EFYzlpyl1aG+0ezGZm2NKLldLUEE2nCZ3WecszymugaftfafibQ== }");
        
        // demonstrating that we can add some other yaml expression that will be ignored
        setProperty("key.yaml", CUSTOM_YAML_EXPRESSION);
    }};

    @Test
    public void initWorksWithNoGAV() throws ZooKeeperClientException {
        ZooKeeperPropertiesService zkps = new ZooKeeperPropertiesService();
        assertFalse(zkps.isEnabled());
        zkps.init();
        assertTrue(zkps.isEnabled());
    }    
    
    @Test(expected=IllegalStateException.class)
    public void initWithNoZooKeeperPropertiesFound() throws IOException, ZooKeeperClientException {
        // PURPOSE: make sure the properties service correctly reports that it is not ready for use 	
        ZooKeeperPropertiesService zkps = new ZooKeeperPropertiesService();
        zkps.init(null);
        
        assertFalse(zkps.isEnabled());
        zkps.loadProperties(groupId, artifactId, version);
    }
    
    @Test
    public void initWithZooKeeperConnectionDown() throws ZooKeeperClientException{
        // should throw an exception like the placeholder does
        Properties props = new ZooKeeperClientPropertiesLoader().loadFromPath();
        props.setProperty("zookeeper.client.host.ports", "localhost:21819"); // this server doesn't exist
        
        ZooKeeperPropertiesService zkps = new ZooKeeperPropertiesService();
        zkps.init(props);
    }
    
    @Test(expected=IOException.class)
    public void enabledConnectionGoesDown() throws Exception {
        // PURPOSE: to check that we get an exception if we try to load properties from a service that is enabled, 
        // but that has lost it's connection
        ZooKeeperPropertiesService zkps = newZooKeeperPropertiesService();
        
        server.stop();
        zkps.loadProperties(groupId, artifactId, version);
    }
    
    @SuppressWarnings("deprecation")
    @Test
    public void loadProperties() throws Exception {
        // now request all those properties and make sure they match
        ZooKeeperPropertiesService zkps = newZooKeeperPropertiesService();
        
        // ensure we can decrypt the encrypted property
        ConfigPropertyValueDecryptionProvider configPropertyValueDecryptionProvider = new ConfigPropertyValueDecryptionProvider();
        configPropertyValueDecryptionProvider.setDecryptionKeyFilePath(ZooKeeperPropertiesServiceTest.class.getResource("/keys/public_key.der").getFile());

        RSASecurityProvider securityProvider = new RSASecurityProvider();
        securityProvider.init();
        configPropertyValueDecryptionProvider.setRsaSecurityProvider(securityProvider);
        
        zkps.setDecryptionProvider(configPropertyValueDecryptionProvider);
        
        Properties loadedProperties = zkps.loadProperties(groupId, artifactId, version);       
        
        assertEquals(toImport.size(), loadedProperties.size());
        assertEquals("valA", loadedProperties.getProperty("keyA"));
        assertEquals("valB", loadedProperties.getProperty("keyB"));
        assertEquals("valC", loadedProperties.getProperty("keyC.subKey"));
        assertEquals("top-secret", loadedProperties.getProperty("keyD.encrypted"));
        assertEquals(CUSTOM_YAML_EXPRESSION, loadedProperties.getProperty("key.yaml"));
    }
    
    private ZooKeeperPropertiesService newZooKeeperPropertiesService() throws InterruptedException, ZooKeeperClientException {
        ZooKeeperPropertiesService zkps = new ZooKeeperPropertiesService();
        assertFalse(zkps.isEnabled());
        zkps.init();
        assertTrue(zkps.isEnabled());        
        waitForZooKeeperClientConnection(zkps);
        return zkps;
    }

    private void waitForZooKeeperClientConnection(ZooKeeperPropertiesService zkps) throws InterruptedException {
        if (!zkps.waitForZooKeeperClientAlive(5, TimeUnit.SECONDS)) {
            throw new IllegalStateException("ZooKeeperClient not alive within 5 seconds");
        }
    }
    
    @Test(expected=IOException.class)
    public void loadProperties_notFound() throws Exception {
        ZooKeeperPropertiesService zkps = newZooKeeperPropertiesService();
        zkps.init();
        assertTrue(zkps.isEnabled());
        zkps.loadProperties("missing", artifactId, version);        
    }
    
    @Before
    public void setup() throws Exception {
        startServer(PORT);
        connectClient(PORT);
        
        ZooKeeperService zks = new ZooKeeperService(client);
        ZooKeeperPropertyFileImporter pfi = new ZooKeeperPropertyFileImporter(zks, 
                new ZookeeperRootPathResolver(ZooKeeperConfigService.ZOOKEEPER_CONFIG_ROOT_PATH, groupId, artifactId, version));
        pfi.importProperties(toImport);        
    }
    
    @After
    public void tearDown() {
        client.stop();
        server.stop(true);         
    }
    
    private void connectClient(int port) throws Exception {
        client.connect(server.hostPort(), "1000", "2000", "foo", "bar");
    }    
    
    private void startServer(int port) {
        logger.info("starting server on port {}", port);
        server.start(port);
    }
}
