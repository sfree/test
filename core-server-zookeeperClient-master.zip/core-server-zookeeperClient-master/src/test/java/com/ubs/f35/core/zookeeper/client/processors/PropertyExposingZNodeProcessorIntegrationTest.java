package com.ubs.f35.core.zookeeper.client.processors;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Properties;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClientException;
import com.ubs.f35.core.zookeeper.client.ZooKeeperStandaloneTestServer;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper;
import com.ubs.f35.core.zookeeper.client.config.api.ZooKeeperConfigService;
import com.ubs.f35.core.zookeeper.client.config.processors.PropertyExposingNodeProcessor;

public class PropertyExposingZNodeProcessorIntegrationTest {

    private static ZooKeeperStandaloneTestServer server = new ZooKeeperStandaloneTestServer();
    private static ZooKeeperClient client = new ZooKeeperClient();
    private static ZooKeeperConfigService service;
    private static final String LEASE_1_VALUE = "{username: u1, password: p1, timeout: t1}";
    private static final String LEASE_2_VALUE = "{username: u2, password: p2, timeout: t2}";
    private static final String LEASE_3_VALUE = "{username: u3, password: p3, timeout: t3}";
    private static final String LEASE_META_NODE_VALUE = "{keys: [username, password, timeout], "
            + "values: [[u1, p1, t1], [ u2, p2, t2], [u3, p3, t3]]}";

    @Test
    public void testProcess() throws Exception {

        String leaseProviderPath = "/root/a/b/" + ConfigTagSchemeHelper.SCHEME_LEASE_GROUP_NODE;
        String leaseNodePath1 = leaseProviderPath + "/" + ConfigTagSchemeHelper.SCHEME_LEASE_ENTITY + 1;
        String leaseNodePath2 = leaseProviderPath + "/" + ConfigTagSchemeHelper.SCHEME_LEASE_ENTITY + 2;
        String leaseNodePath3 = leaseProviderPath + "/" + ConfigTagSchemeHelper.SCHEME_LEASE_ENTITY + 3;
        String leaseAcquirerNodePath1 = leaseNodePath1 + "/" + ConfigTagSchemeHelper.SCHEME_LEASE_LOCK;

        // build test tree
        client.create("/root", CreateMode.PERSISTENT);
        client.create("/root/a", "a", CreateMode.PERSISTENT);
        client.create("/root/a/c", "c", CreateMode.PERSISTENT);
        client.create("/root/a/c/d", "d", CreateMode.PERSISTENT);
        client.create("/root/a/b", CreateMode.PERSISTENT);
        client.create(leaseProviderPath, LEASE_META_NODE_VALUE, CreateMode.PERSISTENT);
        client.create(leaseNodePath1, LEASE_1_VALUE, CreateMode.PERSISTENT);
        client.create(leaseNodePath2, LEASE_2_VALUE, CreateMode.PERSISTENT);
        client.create(leaseNodePath3, LEASE_3_VALUE, CreateMode.PERSISTENT);
        client.create(leaseAcquirerNodePath1, "applicationId", CreateMode.EPHEMERAL);

        service.prettyPrint("/root");

        // actual
        Properties actual = new Properties();
        service.walk("/root", new PropertyExposingNodeProcessor("/root", actual, null));

        // expected
        Properties expected = new Properties();
        expected.setProperty("a", "a");
        expected.setProperty("a.c", "c");
        expected.setProperty("a.c.d", "d");

        // test
        assertEquals(expected, actual);

    }

    @BeforeClass
    public static void beforeClass() throws IOException, InterruptedException, ZooKeeperClientException {
        server.start();
        client.connect(server.hostPort(), "5000", "10000", "foo", "bar");
        service = new ZooKeeperConfigService(client);
    }

    @AfterClass
    public static void afterClass() throws InterruptedException, KeeperException {
        service.stop();
        server.stop();
    }

}