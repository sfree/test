package com.ubs.f35.core.zookeeper.client.config.api;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.util.Properties;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.google.common.io.Files;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.ZooKeeperStandaloneTestServer;

public class CheckedZooKeeperPropertyFileImporterIntegrationTest {

private static final Logger logger = LoggerFactory.getLogger(CheckedZooKeeperPropertyFileImporterTest.class);
    
    private CheckedZooKeeperPropertyFileImporter importer;

    static final String GROUP_NAME = "service-group";
    static final String ARTIFACT_NAME = "service-artifact";
    static final String VERSION_NAME = "1.10";    
    
    static {
        System.setProperty("f35.group", GROUP_NAME);
        System.setProperty("f35.artifact", ARTIFACT_NAME);
        System.setProperty("f35.version", VERSION_NAME);
        System.setProperty("env", "local");
    }
    
    private ZooKeeperStandaloneTestServer server = new ZooKeeperStandaloneTestServer();
    private ZooKeeperClient zkClient = new ZooKeeperClient();
    private ZooKeeperService service;
    private String tmpDir;
    private long sessionTimeout = 5000;
    
    @Before
    public void setUp() throws Exception {
        
        //starting zookeeper server
        server = new ZooKeeperStandaloneTestServer();
        //final int port = getAvailablePort();
        final int port = 21811;
        startServer(port);
        
        //establishing connection to zookeeper server
        String hostPort = getZKHostPort(port);
        zkClient = new ZooKeeperClient();
        zkClient.connect(hostPort, String.valueOf(sessionTimeout), "10000", "foo", "bar");

        service = new ZooKeeperService(zkClient);
        importer = new CheckedZooKeeperPropertyFileImporter(service);
        
        File tmpDirFile = Files.createTempDir().getCanonicalFile();
        tmpDir = tmpDirFile.getCanonicalPath();
        logger.info("Temp dir {} is created", tmpDir);
    }
    
    @Test
    public void importFromPathTest() throws Exception {
        
        //Creating properties
        
        Properties properties = new Properties();
        //lease
        properties.put("externalSystem",
                "expression: { leased:, keys: [username, password, timeouts],  values: [[foo1, bar1, \"1000,1001\"]] }");
        //literal
        properties.put("clearing.house.eligibility.outQueueName", "b2c.irs.clearing.eligibility.request.dev0");

        
        //Storing properties on disk
        String fileName = "initial-values.properties";
        String filePath = tmpDir + File.separator + fileName;
        
        createPropertyFile(properties, filePath);
        
        
        //uploading properties from file
        importer.importFromPath(filePath);
        
        
        //Starting Spring's context
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("test-properties-importer-context.xml");
        ValuesHolder vh = ctx.getBean("valueHolderBean", ValuesHolder.class);
        
        assertEquals("foo1", vh.externalSystemName);
        assertEquals("bar1", vh.externalSystemPass);
        assertEquals("1000,1001", vh.externalSystemTimeout);
        assertEquals("b2c.irs.clearing.eligibility.request.dev0", vh.queueName);
        
        service.prettyPrint("/f35");
        
        //Check that the lease entity is locked
        boolean lockExists = zkClient.exists("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:1/tag:config:lease:lock");
        assertTrue(lockExists);
        

        //re-import same properties
        importer.importFromPath(filePath);
        
        //checking that lock still exists
        lockExists = zkClient.exists("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:1/tag:config:lease:lock");
        assertTrue(lockExists);
        

        //replace literal value
        properties.put("clearing.house.eligibility.outQueueName", "newQueueName");
        //add new property
        properties.put("clearing.outQueueName", "abc");
        properties.put("internalSystem",
                "expression: { leased:, keys: [username, password, timeouts],  values: [[foo1, bar1, \"1000,1001\"]] }");        
        
        //Storing new properties to a new file
        String newFileName = "new-values.properties";
        String newFilePath = tmpDir + File.separator + newFileName;
        
        createPropertyFile(properties, newFilePath);
        
        
        //Uploading new properties to zookeeper
        importer.importFromPath(newFilePath);
        
        //Check that the lock still exists
        lockExists = zkClient.exists("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:1/tag:config:lease:lock");
        assertTrue(lockExists);        
        
        service.prettyPrint("/f35");
        
        //Cleaning
        ctx.destroy();
        Thread.sleep(sessionTimeout); // to let cluster to expire the session
        deleteFile(filePath);
        deleteFile(newFilePath);
        service.deleteSubTree("/f35");
    }
    

    @Test(expected=CommandLineException.MissedLeaseValueException.class)
    public void importFromPathReplaceLeaseTest() throws Exception {
        
        //Preparing the properties
        Properties properties = new Properties();
        properties.put("externalSystem",
                "expression: { leased:, keys: [username, password, timeouts],  values: [[foo1, bar1, \"1000,1001\"]] }");
        //literal
        properties.put("clearing.house.eligibility.outQueueName", "b2c.irs.clearing.eligibility.request.dev0");
        
        //saving to file
        String fileName = "initial-values.properties";
        String filePath = tmpDir + File.separator + fileName;
        
        createPropertyFile(properties, filePath);
        
        //uploading properties to zookeeper
        importer.importFromPath(filePath);
        
        //starting Spring's container
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("test-properties-importer-context.xml");
        //ValuesHolder vh = ctx.getBean("valueHolderBean", ValuesHolder.class);
        
        //checking that lock exists
        boolean lockExists = zkClient.exists("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:1/tag:config:lease:lock");
        assertTrue(lockExists);
        
        //replace values in leased
        properties.put("externalSystem",
                "expression: { leased:, keys: [username, password, timeouts],  values: [[foo2, bar2, \"1000,1001\"]] }");
        
        //Storing new properties to a new file
        String newFileName = "new-values.properties";
        String newFilePath = tmpDir + File.separator + newFileName;
        
        createPropertyFile(properties, newFilePath);
        
        try {
            
        //Uploading new properties to zookeeper
        importer.importFromPath(newFilePath);
        
        } catch(Exception e) {
            logger.error("Expected exception", e);
            
            lockExists = zkClient.exists("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:1/tag:config:lease:lock");
            assertTrue(lockExists);
            
            throw e;
        } finally {
            //Cleaning
            ctx.destroy();
            Thread.sleep(sessionTimeout); // to let cluster to expire the session
            deleteFile(filePath);
            deleteFile(newFilePath);
            service.deleteSubTree("/f35");
        }
    }    
    
    
    @Test
    public void importFromPathAddLeaseValueTest() throws Exception {
        
        //Preparing the properties
        Properties properties = new Properties();
        properties.put("externalSystem",
                "expression: { leased:, keys: [username, password, timeouts],  values: [[foo1, bar1, \"1000,1001\"]] }");
        //literal
        properties.put("clearing.house.eligibility.outQueueName", "b2c.irs.clearing.eligibility.request.dev0");
        
        //saving to file
        String fileName = "initial-values.properties";
        String filePath = tmpDir + File.separator + fileName;
        
        createPropertyFile(properties, filePath);
        
        //uploading properties to zookeeper
        importer.importFromPath(filePath);
        
        //starting Spring's container
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("test-properties-importer-context.xml");
        //ValuesHolder vh = ctx.getBean("valueHolderBean", ValuesHolder.class);
        
        //checking that lock exists
        boolean lockExists = zkClient.exists("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:1/tag:config:lease:lock");
        assertTrue(lockExists);
        
        //add value in lease group
        properties.put("externalSystem",
                "expression: { leased:, keys: [username, password, timeouts],  values: [[foo2, bar2, \"1000,1001\"], [foo1, bar1, \"1000,1001\"]] }");
        
        //Storing new properties to a new file
        String newFileName = "new-values.properties";
        String newFilePath = tmpDir + File.separator + newFileName;
        
        createPropertyFile(properties, newFilePath);
        
        //Uploading new properties to zookeeper
        importer.importFromPath(newFilePath);
        
        //properties uploaded. Lock still exists
        lockExists = zkClient.exists("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:1/tag:config:lease:lock");
        assertTrue(lockExists);
        
        //starting new Spring's container
        ClassPathXmlApplicationContext ctx2 = new ClassPathXmlApplicationContext("test-properties-importer-context.xml");
        //ValuesHolder vh2 = ctx.getBean("valueHolderBean", ValuesHolder.class);
        
        service.prettyPrint("/f35");
        
        //old lock exists
        lockExists = zkClient.exists("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:1/tag:config:lease:lock");
        assertTrue(lockExists);        
        
        //new lock acquired
        lockExists = zkClient.exists("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:2/tag:config:lease:lock");
        assertTrue(lockExists);        

         //Cleaning
         ctx.destroy();
         ctx2.destroy();
         Thread.sleep(sessionTimeout); // to let cluster to expire the session        
         deleteFile(filePath);
         deleteFile(newFilePath);
         service.deleteSubTree("/f35");

         
    }        
    
    
    public static class ValuesHolder {
        String queueName;
        String externalSystemName;
        String externalSystemPass;
        String externalSystemTimeout;
        public ValuesHolder(String queueName, String externalSystemName, String externalSystemPass,
                String externalSystemTimeout) {
            this.queueName = queueName;
            this.externalSystemName = externalSystemName;
            this.externalSystemPass = externalSystemPass;
            this.externalSystemTimeout = externalSystemTimeout;
        }
    }
    
    void createPropertyFile(Properties properties, String filePath) throws IOException {
        File file = new File(filePath);
        boolean created = file.createNewFile();
        if(created)
            logger.info("New file {} created", filePath);
        Writer writer = Files.newWriter(file, Charset.defaultCharset());
        properties.store(writer, filePath);
    }
    
    void deleteFile(String filePath) {
        File file = new File(filePath);
        boolean deleted = file.delete();
        if(deleted)
            logger.info("New file {} deleted", filePath);        
    }
    
    
    // === Service methods for zookeeper cluster =====
/*    
    private int getAvailablePort() throws Exception {
        // Open the socket just to get the available port
        ServerSocket socket = new ServerSocket(0);
        final int port = socket.getLocalPort();        
        socket.close();
        return port;
    }
*/        
    private void startServer(final int port) throws Exception {
        
        Thread serverStarter = new Thread(new Runnable() {
            @Override
            public void run() {
                server.start(port);
            }
        });

        logger.info("Starting the server");
        serverStarter.start();
        serverStarter.join();
    }
    
    private void stopServer() {
        logger.info("stopping server");
        if (server != null && server.isStarted()) {
            logger.info("closing server");
            server.stop();
        }
    }        
    
    public String getZKHostPort(int port) {
        try {
            return InetAddress.getLocalHost().getHostName() + ":" + port;
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
    }  

    @After
    public void afterTest() throws InterruptedException {
        if (zkClient != null) {
            logger.info("closing client");
            zkClient.stop();
        }

        stopServer();
        deleteFile(tmpDir);
    }

    
    
}
