package com.ubs.f35.utils;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.ubs.f35.core.zookeeper.client.common.PathBuilder;

public class PathBuilderTest {

    @Test
    public void testEmptyBuilder() {
        PathBuilder path = new PathBuilder();
        assertEquals("", path.toString());
    }

    @Test
    public void testNoLeadingSlash() {
        PathBuilder path = new PathBuilder("foo");
        assertEquals("/foo", path.toString());
    }

    @Test
    public void testLeadingSlash() {
        PathBuilder path = new PathBuilder("/foo");
        assertEquals("/foo", path.toString());
    }

    @Test
    public void testPath() {
        PathBuilder path = new PathBuilder("/foo/bar/baz");
        assertEquals("/foo/bar/baz", path.toString());
    }

    @Test
    public void testProperty() {
        PathBuilder path = new PathBuilder("foo.bar.baz");
        assertEquals("/foo/bar/baz", path.toString());
    }
    
    @Test
    public void testValue() {
        PathBuilder path = new PathBuilder("foo.bar.baz", false);
        assertEquals("/foo.bar.baz", path.toString());
    }    

    @Test
    public void testAppendPath() {
        PathBuilder path = new PathBuilder("/foo");
        path.appendNormalised("bar/baz");
        assertEquals("/foo/bar/baz", path.toString());
    }
    
    @Test
    public void testAppendAsIsPath() {
        PathBuilder path = new PathBuilder("/foo");
        path.appendAsIs("bar.bar/baz.baz");
        assertEquals("/foo/bar.bar/baz.baz", path.toString());
    }    

    @Test
    public void testAppendPathWithLeadingSlash() {
        PathBuilder path = new PathBuilder("/foo");
        path.appendNormalised("/bar/baz");
        assertEquals("/foo/bar/baz", path.toString());
    }
    
    @Test
    public void testAppendProperty() {
        PathBuilder path = new PathBuilder("/foo");
        path.appendNormalised("bar.baz");
        assertEquals("/foo/bar/baz", path.toString());
    }
 
    @Test
    public void testTrailingSlashWithRootPath() {
        PathBuilder path = new PathBuilder("/foo/");
        assertEquals("/foo", path.toString());
    }

    @Test
    public void testTrailingSlashWithPath() {
        PathBuilder path = new PathBuilder("/foo/");
        path.appendNormalised("/bar.baz/");
        assertEquals("/foo/bar/baz", path.toString());
    }

    @Test
    public void testAppendVerbatim() {
        PathBuilder path = new PathBuilder("/foo");
        path.verbatim("1.0.3");
        assertEquals("/foo/1.0.3", path.toString());
    }

}