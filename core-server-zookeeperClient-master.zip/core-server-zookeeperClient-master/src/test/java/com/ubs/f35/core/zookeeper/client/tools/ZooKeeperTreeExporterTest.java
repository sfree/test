package com.ubs.f35.core.zookeeper.client.tools;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;

import org.apache.zookeeper.CreateMode;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.ZooKeeperStandaloneTestServer;

public class ZooKeeperTreeExporterTest {

    private ZooKeeperStandaloneTestServer server = new ZooKeeperStandaloneTestServer();
    private ZooKeeperClient client = new ZooKeeperClient();
    private ZooKeeperService service;
    private ZooKeeperTreeExporter exporter;
    
    //Only persistent nodes are exported 
    private String expectedExportedTree = 
        "[ZNODE]:/a/b/ps : \n"+
        "[ZNODE]:/a/b/ps1 : \n"+        
        "[ZNODE]:/a/b/ps2 : null\n"+
        "[ZNODE]:/a/b/ps4 :  \n"+
        "[ZNODE]:/a/b/ps3 :  : \n"+
        "[ZNODE]:/a/b/ps5 :  abc \n"+
        " def \n";
    
    @Test
    public void testExportTree() throws Exception {
        
        String startNode = "/a";
        
        ByteArrayOutputStream ous = new ByteArrayOutputStream();
        exporter.exportTree(startNode, ous);
        
        String result = new String(ous.toByteArray());
        
        assertEquals("The tree is exported incorrectly", expectedExportedTree, result);
    }
    
    private void createTestTree() throws Exception {
        client.create("/a", CreateMode.PERSISTENT);
        client.createFull("/a/b", CreateMode.PERSISTENT);
        client.createFull("/a/b/ep", "abep", CreateMode.EPHEMERAL);
        client.createFull("/a/b/ps", "", CreateMode.PERSISTENT);
        client.createFull("/a/b/ps1", "", CreateMode.PERSISTENT);
        client.createFull("/a/b/ps2", "null", CreateMode.PERSISTENT);
        client.createFull("/a/b/ps3", " : ", CreateMode.PERSISTENT);
        client.createFull("/a/b/ps4", " ", CreateMode.PERSISTENT);
        client.createFull("/a/b/ps5", " abc \n def ", CreateMode.PERSISTENT);
        client.create("/a/b/epsq-", "epsq", CreateMode.EPHEMERAL_SEQUENTIAL);
    }
    
    @Before
    public void beforeTest() throws Exception {
        server.start();
        client.connect(server.hostPort(), "5000", "10000", "foo", "bar");
        service = new ZooKeeperService(client);
        exporter = new ZooKeeperTreeExporter(service);
        createTestTree();
    }

    @After
    public void afterTest() throws Exception {
        service.stop();
        client.stop();
        server.stop();
    }
}
