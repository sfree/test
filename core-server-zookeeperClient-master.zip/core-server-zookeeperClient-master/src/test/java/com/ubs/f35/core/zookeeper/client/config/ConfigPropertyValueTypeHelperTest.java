package com.ubs.f35.core.zookeeper.client.config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class ConfigPropertyValueTypeHelperTest {

    @Test
    public void testNotExpression() {
        String s = "{encrypted:, value: foo}";
        assertFalse(new ConfigPropertyValueTypeHelper(s).isExpression());
    }

    @Test
    public void testExpression() {
        String s = "expression: {encrypted:, value: foo}";
        assertTrue(new ConfigPropertyValueTypeHelper(s).isExpression());
    }

    @Test
    public void testEncrypted() {
        String s = "expression: {encrypted:, value: foo}";
        assertTrue(new ConfigPropertyValueTypeHelper(s).isEncrypted());
    }

    @Test
    public void testLeased() {
        String s = "expression: { encrypted:, leased:, keys: [name], values: [ [foo], [bar], [baz] ] }";
        assertTrue(new ConfigPropertyValueTypeHelper(s).isLeased());
    }

    @Test
    public void testChildExpressions() {
        String s = "expression: { encrypted:, leased:, keys: [name], values: [ [foo], [bar], [baz] ] }";
        List<String> list = Arrays.asList("{name: foo}", "{name: bar}", "{name: baz}");
        assertEquals(list, new ConfigPropertyValueTypeHelper(s).getLeaseEntityExpressions());
    }

}