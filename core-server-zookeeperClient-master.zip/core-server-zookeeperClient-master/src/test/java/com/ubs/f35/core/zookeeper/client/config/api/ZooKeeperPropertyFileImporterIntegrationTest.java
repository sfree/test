package com.ubs.f35.core.zookeeper.client.config.api;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.zookeeper.KeeperException;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.google.common.io.Files;
import com.ubs.f35.core.zookeeper.client.ZNode;
import com.ubs.f35.core.zookeeper.client.ZNodeProcessor;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClientException;
import com.ubs.f35.core.zookeeper.client.ZooKeeperStandaloneTestServer;
import com.ubs.f35.core.zookeeper.client.common.StringValueTransformer;
import com.ubs.f35.core.zookeeper.client.common.ZooKeeperClientPropertiesLoader;
import com.ubs.f35.core.zookeeper.client.common.ZookeeperRootPathResolver;
import com.ubs.f35.core.zookeeper.client.config.ConfigPropertyValueTypeHelper;
import com.ubs.f35.core.zookeeper.client.config.processors.LeasePropertyFindingNodeProcessor;
import com.ubs.f35.core.zookeeper.client.config.processors.PropertyExposingNodeProcessor;
import com.ubs.f35.core.zookeeper.utils.PropertyUtils;

public class ZooKeeperPropertyFileImporterIntegrationTest {

    private static ZooKeeperStandaloneTestServer server = new ZooKeeperStandaloneTestServer();
    private static ZooKeeperClient client = new ZooKeeperClient();
    private static ZooKeeperConfigService service;
    private static ZooKeeperPropertyFileImporter importer;
    
    static final StringValueTransformer valueTransformer = new StringValueTransformer();

    // leased property
    private static final String LEASE_META_NODE_VALUE = "expression: { leased:, keys: [username, password, timeout], "
            + "values: [[u1, p1, t1], [ u2, p2, t2], [u3, p3, t3]]}";

    @SuppressWarnings("rawtypes")
    @Test
    public void testImportFromPath() throws Exception {

        // create a property file in memory
        Properties source = new Properties();
        source.setProperty("a", "a");
        source.setProperty("a.c", "c");
        source.setProperty("a.c.d", "d");
        source.setProperty("a.b", LEASE_META_NODE_VALUE);
        source.setProperty("blank", "");

        File tmpDir = createTmpDir();
        String tmpFile = new File(tmpDir, "tmpFile").getCanonicalPath();
        PropertyUtils.storeToFilePath(tmpFile, source);

        // import
        importer.importFromPath(tmpFile);

        // export
        Properties actual = new Properties();
        String rootPath = new ZookeeperRootPathResolver(ZooKeeperConfigService.ZOOKEEPER_CONFIG_ROOT_PATH).resolveApplicationRootPath();

        LeasePropertyFindingNodeProcessor leasePropertyProcessor = new LeasePropertyFindingNodeProcessor();
        
        Collection<ZNodeProcessor> processors = Arrays.asList(new ZNodeProcessor[] { leasePropertyProcessor, new PropertyExposingNodeProcessor(rootPath, actual, null) });
        
        service.walkMulti(rootPath, processors);
        
        // expected literal property values
        Properties expected = createTestProperties();
        expected.remove("a.b");

        // test literal values
        assertEquals(expected, actual);

        // leased values
        Map<String, ZNode> leasedResults = leasePropertyProcessor.getPlaceholderToLeaseGroupNodeMapping();
        
        assertEquals(3, leasedResults.size());
        
        List<ZNode> acquiredLocks = new LinkedList<ZNode>();
        
        // expected leased values
        Map[] expectedLeasedMaps = createdExpectedLeasedMaps(leasedResults.size());
        
        int index = 0;
        for(ZNode node : leasedResults.values()) {
            ZNode acquired = service.acquireLease("applicationId", node, null);
            String leaseEntityExpression = valueTransformer.fromInput(acquired.value());
            Map propertyGroup = ConfigPropertyValueTypeHelper.parseLeaseEntityExpression(leaseEntityExpression);
            assertEquals(expectedLeasedMaps[index++], propertyGroup);
            
            acquiredLocks.add(acquired);
            service.prettyPrint("/f35");
        }
        
        // clean up
        
        //first, disable the watchers on locks as they restore the removed nodes
        for(ZNode acquired : acquiredLocks) {
            
            ZNode node = service.read(acquired.path());
            if(!node.children().isEmpty()) {
                ZNode lock = node.children().iterator().next();
                client.getClient().setData(lock.path(), null, -1);
                long startTS = System.currentTimeMillis();
                do {
                    byte[] data = client.read(lock.path());
                    if(ZooKeeperConfigService.FREED_VALUE.equals(valueTransformer.fromInput(data))) {
                        break;
                    } else {
                        Thread.sleep(100);
                        long currentTS = System.currentTimeMillis();
                        if(currentTS - startTS > 5000) {
                            fail();
                        }
                    }
                } while(true);
                client.getClient().delete(lock.path(), -1);
            }
        }
        
        service.deleteSubTree(rootPath);
        deleteFile(tmpDir);
    }

    @Test
    public void testImportFromClassPath() throws Exception {

        // import
        importer.importFromClassPath("test-local.properties");

        // export
        Properties actual = new Properties();
        String rootPath = new ZookeeperRootPathResolver(ZooKeeperConfigService.ZOOKEEPER_CONFIG_ROOT_PATH).resolveApplicationRootPath();
        service.walk(rootPath, new PropertyExposingNodeProcessor(rootPath, actual, null));

        // expected
        Properties expected = createTestProperties();

        // test
        assertEquals(expected, actual);
        
        // clean up
        service.deleteSubTree(rootPath);
    }
    
    @Test
    public void testPropertiesNull() throws Exception {
        // just verifying that Properties load as empty string when left blank
        Properties props = new Properties();
        props.load(getClass().getResourceAsStream("/import-empty.properties"));
        
        assertEquals("true", props.getProperty("hasValue"));
        assertEquals("", props.getProperty("noValue", "not_set"));
    }

    @Test
    public void testImportMultipleFromPath() throws Exception {

        // create two property files in memory
        Properties p1 = new Properties();
        p1.setProperty("a", "old");
        p1.setProperty("b", "old");
        p1.setProperty("x", "1");
        Properties p2 = new Properties();
        p2.setProperty("a", "new");
        p2.setProperty("c", "old");
        p2.setProperty("y", "2");

        // write both to file
        File tmpDir = createTmpDir();
        String f1 = new File(tmpDir, "f1").getCanonicalPath();
        String f2 = new File(tmpDir, "f2").getCanonicalPath();
        PropertyUtils.storeToFilePath(f1, p1);
        PropertyUtils.storeToFilePath(f2, p2);

        // import
        importer.importMultipleFromPath(Arrays.asList(new String[] { f1, f2 }));

        // expected; test property override
        Properties expected = new Properties();
        expected.setProperty("a", "new");
        expected.setProperty("b", "old");
        expected.setProperty("c", "old");
        expected.setProperty("x", "1");
        expected.setProperty("y", "2");

        // actual
        Properties actual = new Properties();
        String rootPath = new ZookeeperRootPathResolver(ZooKeeperConfigService.ZOOKEEPER_CONFIG_ROOT_PATH).resolveApplicationRootPath();
        service.walk(rootPath, new PropertyExposingNodeProcessor(rootPath, actual, null));

        // test
        assertEquals(expected, actual);

        // clean up
        service.deleteSubTree(rootPath);
        deleteFile(tmpDir);

    }
    
    private void deleteFile(File f) throws IOException {
        if (f.isDirectory()) {
            for (File c : f.listFiles())
                deleteFile(c);
        }
        f.delete();
    }    

    private File createTmpDir() throws IOException {
        File tmpDir = Files.createTempDir().getCanonicalFile();
        tmpDir.mkdir();
        return tmpDir;
    }

    private Properties createTestProperties() {
        Properties expected = new Properties();
        expected.setProperty("a", "a");
        expected.setProperty("a.c", "c");
        expected.setProperty("a.c.d", "d");
        expected.setProperty("a.b", "expression: {keys: [username, password, timeout], values: [[u1, p1, t1], [ u2, p2, t2], [u3, p3, t3]]}");
        expected.setProperty("blank", "");
        return expected;
    }
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
    private Map[] createdExpectedLeasedMaps(int size) {
        Map<String, String>[] maps = new HashMap[size];

        for(int i = 0; i < size; i++) {
            maps[i] = createExpectedLeasedMap(i+1);
        }
        
        return maps;
    }
    
    private Map<String, String> createExpectedLeasedMap(int index) {
        Map<String, String> result = new LinkedHashMap<String, String>(3);
        result.put("a.b.username", "u"+index);
        result.put("a.b.password", "p"+index);
        result.put("a.b.timeout", "t"+index);
        return result;
    }
    
    @BeforeClass
    public static void beforeClass() throws ZooKeeperClientException {
        System.setProperty(ZooKeeperClientPropertiesLoader.ENV, "local");
        System.setProperty(ZooKeeperClientPropertiesLoader.GROUP_ID, "foo");
        System.setProperty(ZooKeeperClientPropertiesLoader.ARTIFACT_ID, "bar");
        System.setProperty(ZooKeeperClientPropertiesLoader.VERSION, "baz");
        server.start();
        client.connect(server.hostPort(), "5000", "10000", "foo", "bar");
        service = new ZooKeeperConfigService(client);
        importer = new ZooKeeperPropertyFileImporter(service);
    }

    @AfterClass
    public static void afterClass() throws InterruptedException, KeeperException {
        if (importer != null) {
            importer.stop();
        }
        client.stop();
        server.stop();
    }

}