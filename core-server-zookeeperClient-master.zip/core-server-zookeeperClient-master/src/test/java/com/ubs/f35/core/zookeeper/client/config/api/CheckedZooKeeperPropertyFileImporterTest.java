package com.ubs.f35.core.zookeeper.client.config.api;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import org.junit.Before;
import org.junit.Test;

import com.ubs.f35.core.zookeeper.client.DefaultZNode;
import com.ubs.f35.core.zookeeper.client.ZNode;
import com.ubs.f35.core.zookeeper.client.ZNode.ZNodeType;
import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.config.ConfigPropertyValueTypeHelper;
import com.ubs.f35.core.zookeeper.client.config.api.CheckedZooKeeperPropertyFileImporter.ConfigNodeType;
import com.ubs.f35.core.zookeeper.client.config.api.CheckedZooKeeperPropertyFileImporter.ImportOperation;

public class CheckedZooKeeperPropertyFileImporterTest {
    
    private CheckedZooKeeperPropertyFileImporter importer;

    static final String GROUP_NAME = "service-group";
    static final String ARTIFACT_NAME = "service-artifact";
    static final String VERSION_NAME = "1.10";    
    
    static {
        System.setProperty("f35.group", GROUP_NAME);
        System.setProperty("f35.artifact", ARTIFACT_NAME);
        System.setProperty("f35.version", VERSION_NAME);
    }
    
    private ZooKeeperClient zkClient;
    
    @Before
    public void setUp() throws Exception {
        zkClient = new ZooKeeperClient();
        ZooKeeperService zks = new ZooKeeperService(zkClient);
        importer = new CheckedZooKeeperPropertyFileImporter(zks);
    }
    
    @Test
    public void createLiteralOperationTest() {
        
        String root = "/f35/config/g/a/v";
        String key = "lcds.nio.streaming.endpoint";
        String propertyValue = "http://localhost:5400/nioamfstream";
        
        //Testing        
        ImportOperation op = importer.createLiteralOperation(root, key, propertyValue, false);
        
        //Checking
        assertEquals(key, op.key);
        assertEquals(propertyValue, op.value);
        assertEquals(root + "/lcds/nio/streaming/endpoint", op.zkPath);
        assertEquals(ConfigNodeType.LITERAL, op.type);
        assertTrue(op.children.isEmpty());
    }
    
    @Test
    public void createEncryptedLiteralOperationTest() {
        
        String root = "/f35/config/g/a/v";
        String key = "key.encrypted";
        String propertyValue = "expression: { encrypted:, value: amhjhvSVIX8Fw4RgFXxFOooPn7ERewffyhdcWmNUIzEaoJa9Qr5BMhI/7NMmw+SSfI/KDwUd5q6DuHcO6dTTFkGW+nnx3PHMGPlSZfHycfXAA5XLW3ZvxKNVoL+L/8uZtPP9rpfaIuTe+vF1/8QdXLEyIiR5PA6fLQoFlc8h2OUIADCS044jw83zp1sgkLaCciZBVsQKor6WtGCSIG5h7BxYX+pOLqvwACfTUZQsgXfVKX1WNAdXydlfgUMQRRAKtZiZ3uWYaeLewUA25OceDCYS+0qtpsHOXu6EFYzlpyl1aG+0ezGZm2NKLldLUEE2nCZ3WecszymugaftfafibQ== }";
        
        //Testing
        ImportOperation op = importer.createLiteralOperation(root, key, propertyValue, true);
        
        //Checking
        assertEquals(key, op.key);
        assertEquals(propertyValue, op.value);
        assertEquals(root + "/key/encrypted/tag:config:encrypted:node", op.zkPath);
        assertEquals(ConfigNodeType.LITERAL, op.type);
        assertTrue(op.children.isEmpty());
    }
    
    @Test
    public void createLeaseOperationTest() {
        
        String root = "/f35/config/g/a/v";
        String key = "externalSystem";
        String propertyValue = "expression: { leased:, keys: [username, password],  values: [[foo, \"http://localhost:5400\"]] }";
        
        ConfigPropertyValueTypeHelper propertyValueTypeHelper = new ConfigPropertyValueTypeHelper(key, propertyValue);
        
        
        //Testing
        ImportOperation op = importer.createLeaseOperation(root, key, propertyValueTypeHelper, false);
        
        //Checking
        assertEquals(key, op.key);
        assertEquals("{keys: [externalSystem.username, externalSystem.password], values: [[foo, 'http://localhost:5400']]}", op.value);
        assertEquals(root + "/externalSystem/tag:config:lease:group:node", op.zkPath);
        assertEquals(ConfigNodeType.LEASE_GROUP, op.type);
        
        //lease entities
        assertEquals(1, op.children.size());
        
        ImportOperation entityOp = op.children.get(0);
        assertNotNull(entityOp);
        
        assertEquals("externalSystem", entityOp.key);
        assertEquals("{externalSystem.username: foo, externalSystem.password: 'http://localhost:5400'}", entityOp.value);
        assertEquals(root + "/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:1", entityOp.zkPath);
        assertEquals(ConfigNodeType.LEASE_ENTITY, entityOp.type);
        assertTrue(entityOp.children.isEmpty());
    }
    
    
    @Test
    public void createLeaseEncryptedOperationTest() {
        
        String root = "/f35/config/g/a/v";
        String key = "externalSystem";
        String propertyValue = "expression: { encrypted:, leased:, keys: [username, password],  values: [[foo, bar]] }";
        
        ConfigPropertyValueTypeHelper propertyValueTypeHelper = new ConfigPropertyValueTypeHelper(key, propertyValue);
        
        assertTrue(propertyValueTypeHelper.isLeased());
        assertTrue(propertyValueTypeHelper.isEncrypted());
        
        //Testing
        ImportOperation op = importer.createLeaseOperation(root, key, propertyValueTypeHelper, true);
        
        
        //Checking
        assertEquals(key, op.key);
        assertEquals("{keys: [externalSystem.username, externalSystem.password], values: [[foo, bar]]}", op.value);
        assertEquals(root + "/externalSystem/tag:config:lease:group:encrypted:node", op.zkPath);
        assertEquals(ConfigNodeType.LEASE_GROUP, op.type);
        
        //lease entities
        assertEquals(1, op.children.size());
        
        ImportOperation entityOp = op.children.get(0);
        assertNotNull(entityOp);
        
        assertEquals("externalSystem", entityOp.key);
        assertEquals("{externalSystem.username: foo, externalSystem.password: bar}", entityOp.value);
        assertEquals(root + "/externalSystem/tag:config:lease:group:encrypted:node/tag:config:lease:entity:encrypted:1", entityOp.zkPath);
        assertEquals(ConfigNodeType.LEASE_ENTITY, entityOp.type);
        assertTrue(entityOp.children.isEmpty());
    }
    
    @Test
    public void processPropertiesTest() {
        Properties properties = new Properties();
        //lease
        properties.put("externalSystem",
                       "expression: { leased:, keys: [username, password, timeouts],  values: [[foo1, bar1, \"1000,1001\"], [foo2, bar2, \"1000,1002\"]] }");
        //literal
        properties.put("clearing.house.eligibility.outQueueName", "b2c.irs.clearing.eligibility.request.dev0");

        //encrypted lease
        properties.put("internalSystem", "expression: { encrypted:, leased:, keys: [username, password],  values: [[foo, bar]] }");

        //encrypted
        properties.put("lcds.nio.endpoint", "expression: { encrypted:, value: \"http://localhost:5400/nioamf\" }");
        

        //Testing
        List<ImportOperation> operations = importer.processProperties(properties);
        
        //Checking
        assertEquals(4, operations.size());
        
        List<String> expectedZKNodes = new ArrayList<String>();
        expectedZKNodes.add("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node"); 
        expectedZKNodes.add("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:1"); 
        expectedZKNodes.add("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:2");
        expectedZKNodes.add("/f35/config/service-group/service-artifact/1.10/clearing/house/eligibility/outQueueName");
        expectedZKNodes.add("/f35/config/service-group/service-artifact/1.10/internalSystem/tag:config:lease:group:encrypted:node");
        expectedZKNodes.add("/f35/config/service-group/service-artifact/1.10/internalSystem/tag:config:lease:group:encrypted:node/tag:config:lease:entity:encrypted:1");                
        expectedZKNodes.add("/f35/config/service-group/service-artifact/1.10/lcds/nio/endpoint/tag:config:encrypted:node");
        
        for(ImportOperation op : operations) {
            expectedZKNodes.remove(op.zkPath);
            for(ImportOperation child : op.children) {
                assertTrue(expectedZKNodes.remove(child.zkPath));
            }
        }
        
        assertTrue(expectedZKNodes.isEmpty());
    }
    
    @Test
    public void getOperationsByTypeTest() {
        
        ImportOperation literalOp = new ImportOperation("literalKey", "literalZkPath", "literalValue", ConfigNodeType.LITERAL);
        //test
        Collection<ImportOperation> literalOps = importer.getOperationsByType(Arrays.asList(literalOp), ConfigNodeType.LITERAL);
        
        assertEquals(1, literalOps.size());
        assertEquals(literalOp, literalOps.iterator().next());

        //test
        Collection<ImportOperation> groupOps = importer.getOperationsByType(Arrays.asList(literalOp), ConfigNodeType.LEASE_GROUP);
        assertTrue(groupOps.isEmpty());
        
        //adding more values to the set of operations
        ImportOperation leaseEntOp = new ImportOperation("leaseEntKey", "leaseEntZkPath", "leaseEntValue", ConfigNodeType.LEASE_ENTITY);
        ImportOperation leaseGroupOp = new ImportOperation("leaseGrKey", "leaseGrZkPath", "leaseGrValue", ConfigNodeType.LEASE_GROUP, leaseEntOp);
        
        //test
        literalOps = importer.getOperationsByType(Arrays.asList(literalOp, leaseGroupOp), ConfigNodeType.LITERAL);
        assertEquals(1, literalOps.size());
        assertEquals(literalOp, literalOps.iterator().next());
        
        
        //test
        Collection<ImportOperation> entityOps = importer.getOperationsByType(Arrays.asList(literalOp, leaseGroupOp), ConfigNodeType.LEASE_ENTITY);
        assertEquals(1, entityOps.size());
        assertEquals(leaseEntOp, entityOps.iterator().next());
    }
    
    
    
    @Test
    public void validateLeasePropertiesTest() {
        
        //Test prepare

        Properties properties = new Properties();
        //lease
        properties.put("externalSystem",
                       "expression: { leased:, keys: [username, password, timeouts],  values: [[foo1, bar1, \"1000,1001\"]] }");
        //literal
        properties.put("clearing.house.eligibility.outQueueName", "b2c.irs.clearing.eligibility.request.dev0");

        //encrypted
        properties.put("lcds.nio.endpoint", "expression: { encrypted:, value: \"http://localhost:5400/nioamf\" }");
        
        List<ImportOperation> operations = importer.processProperties(properties);
        LinkedHashMap<ImportOperation, ZNode> zkState = createZookeeperState(operations);
        
        Collection<ImportOperation> leaseEntityOps = importer.getOperationsByType(operations, ConfigNodeType.LEASE_GROUP);
        ImportOperation leaseGroupOp = leaseEntityOps.iterator().next();
        
        ZNode groupZNode = zkState.get(leaseGroupOp);
        
        ZNode entityZNode = groupZNode.children().iterator().next();
        ZNode lockedZNode = lockNode(entityZNode);
        
        groupZNode.children().remove(entityZNode);
        groupZNode.children().add(lockedZNode);
        
        Collection<String> deleteFilter = new ArrayList<String>();
        
        //Testing
        importer.validateLeaseProperties(Collections.singleton(groupZNode), operations, deleteFilter);
        
        //Checking
        assertFalse(deleteFilter.isEmpty());
        assertTrue(deleteFilter.contains("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:1"));
        assertTrue(deleteFilter.contains("/f35/config/service-group/service-artifact/1.10/externalSystem/tag:config:lease:group:node/tag:config:lease:entity:1/lock"));
    }
    
    @Test(expected=CommandLineException.MissedLeaseGroupException.class)
    public void validateLeasePropertiesMissedLockedGroupTest() {
        
        //Test prepare

        Properties properties = new Properties();
        //lease
        properties.put("externalSystem",
                       "expression: { leased:, keys: [username, password, timeouts],  values: [[foo1, bar1, \"1000,1001\"]] }");
        //literal
        properties.put("clearing.house.eligibility.outQueueName", "b2c.irs.clearing.eligibility.request.dev0");

        //encrypted
        properties.put("lcds.nio.endpoint", "expression: { encrypted:, value: \"http://localhost:5400/nioamf\" }");
        
        List<ImportOperation> operations = importer.processProperties(properties);
        LinkedHashMap<ImportOperation, ZNode> zkState = createZookeeperState(operations);
        
        Collection<ImportOperation> leaseEntityOps = importer.getOperationsByType(operations, ConfigNodeType.LEASE_GROUP);
        ImportOperation leaseGroupOp = leaseEntityOps.iterator().next();
        
        ZNode groupZNode = zkState.get(leaseGroupOp);
        
        ZNode entityZNode = groupZNode.children().iterator().next();
        ZNode lockedZNode = lockNode(entityZNode);
        
        groupZNode.children().remove(entityZNode);
        groupZNode.children().add(lockedZNode);
        
        Properties newProperties = new Properties();
        newProperties.put("clearing.house.eligibility.outQueueName", "b2c.irs.clearing.eligibility.request.dev0");
        List<ImportOperation> newOperations = importer.processProperties(newProperties);
        
        Collection<String> deleteFilter = new ArrayList<String>();
        
        //Testing
        importer.validateLeaseProperties(Collections.singleton(groupZNode), newOperations, deleteFilter);
    }
    
    @Test(expected=CommandLineException.MissedLeaseValueException.class)
    public void validateLeasePropertiesMissedLockedEntityTest() {
        
        //Test prepare

        Properties properties = new Properties();
        //lease
        properties.put("externalSystem",
                       "expression: { leased:, keys: [username, password, timeouts],  values: [[foo1, bar1, \"1000,1001\"]] }");
        //literal
        properties.put("clearing.house.eligibility.outQueueName", "b2c.irs.clearing.eligibility.request.dev0");

        //encrypted
        properties.put("lcds.nio.endpoint", "expression: { encrypted:, value: \"http://localhost:5400/nioamf\" }");
        
        List<ImportOperation> operations = importer.processProperties(properties);
        LinkedHashMap<ImportOperation, ZNode> zkState = createZookeeperState(operations);
        
        Collection<ImportOperation> leaseEntityOps = importer.getOperationsByType(operations, ConfigNodeType.LEASE_GROUP);
        ImportOperation leaseGroupOp = leaseEntityOps.iterator().next();
        
        ZNode groupZNode = zkState.get(leaseGroupOp);
        
        ZNode entityZNode = groupZNode.children().iterator().next();
        ZNode lockedZNode = lockNode(entityZNode);
        
        groupZNode.children().remove(entityZNode);
        groupZNode.children().add(lockedZNode);
        
        Properties newProperties = new Properties();
        newProperties.put("externalSystem",
                "expression: { leased:, keys: [username, password, timeouts],  values: [[foo2, bar2, \"1001,1002\"]] }");
        List<ImportOperation> newOperations = importer.processProperties(newProperties);
        
        Collection<String> deleteFilter = new ArrayList<String>();
        
        //Testing
        importer.validateLeaseProperties(Collections.singleton(groupZNode), newOperations, deleteFilter);
    }
    
    
    private ZNode lockNode(ZNode node) {
        ZNode lockeNode = new DefaultZNode(node.path() + "/lock", ZNodeType.EPHEMERAL, -1, true, "lock value".getBytes());
        ZNode lockedNode = new DefaultZNode(node.path(), ZNodeType.PERSISTENT, node.relativeOffset(), false, node.value());
        lockedNode.children().add(lockeNode);
        return lockedNode;
    }
    
    private LinkedHashMap<ImportOperation, ZNode> createZookeeperState(List<ImportOperation> ops) {
        LinkedHashMap<ImportOperation, ZNode> zkNodes = new LinkedHashMap<ImportOperation, ZNode>();
        for(ImportOperation each : ops) {
            LinkedHashMap<ImportOperation, ZNode> zkNodesChildern = new LinkedHashMap<ImportOperation, ZNode>();
            if(!each.children.isEmpty()) {
                zkNodesChildern = createZookeeperState(each.children);
                
            }
            DefaultZNode parent = new DefaultZNode(each.zkPath, ZNodeType.PERSISTENT, 0, false, null);
            DefaultZNode node = new DefaultZNode(each.zkPath, ZNodeType.PERSISTENT, 1, each.children.isEmpty(), each.value.getBytes(), parent, null);
            zkNodes.put(each, node);
            node.children().addAll(zkNodesChildern.values());
        }
        return zkNodes;
    }
}
