package com.ubs.f35.core.zookeeper.client.config.api;

import static org.junit.Assert.*;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Properties;

import org.apache.zookeeper.CreateMode;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperStandaloneTestServer;
import com.ubs.f35.core.zookeeper.client.common.ZooKeeperClientPropertiesLoader;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper;

public class ZooKeeperPropertyPlaceholderConfigurerIntegrationTest {

    static final Logger logger = LoggerFactory.getLogger(ZooKeeperPropertyPlaceholderConfigurerIntegrationTest.class);
    private ZooKeeperConfigService service;
    private ZooKeeperClient client;
    private ZooKeeperStandaloneTestServer server;

    private static final String LEASE_1_VALUE = "{a.b.username: u1, a.b.password: p1, a.b.timeout: t1}";
    private static final String LEASE_2_VALUE = "{a.b.username: u2, a.b.password: p2, a.b.timeout: t2}";
    private static final String LEASE_3_VALUE = "{a.b.username: u3, a.b.password: p3, a.b.timeout: t3}";
    private static final String LEASE_PROVIDER_VALUE = "{keys: [a.b.username, a.b.password, a.b.timeout], "
            + "values: [[u1, p1, t1], [ u2, p2, t2], [u3, p3, t3]]}";

    private static final String ALT_LEASE_1_VALUE = "{a.b.username: u1_alt, a.b.password: p1_alt, a.b.timeout: t1_alt}";
    private static final String ALT_LEASE_2_VALUE = "{a.b.username: u2_alt, a.b.password: p2_alt, a.b.timeout: t2_alt}";
    private static final String ALT_LEASE_3_VALUE = "{a.b.username: u3_alt, a.b.password: p3_alt, a.b.timeout: t3_alt}";
    private static final String ALT_LEASE_PROVIDER_VALUE = "{keys: [a.b.username, a.b.password, a.b.timeout], "
            + "values: [[u1_alt, p1_alt, t1_alt], [ u2_alt, p2_alt, t2_alt], [u3_alt, p3_alt, t3_alt]]}";

    final int port = 21811; // port should be the same as in
                            // zookeeper-client.properties

    @Test(expected = org.springframework.beans.factory.BeanInitializationException.class)
    public void testWithZooKeeperTreeAbsent() throws Exception {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "test-zkppc-no-placeholders-context.xml");
        ZooKeeperPropertyPlaceholderConfigurer ppc = context.getBean(ZooKeeperPropertyPlaceholderConfigurer.class);
        assertNotNull(ppc);
        context.close();
    }

    @Test
    public void testWithZooKeeperTreePresent() throws Exception {
        startServer(port);
        connectClient(port);
        createPropertyTree();

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "test-zkppc-with-placeholders-context.xml");
        assertExpectedBeanValues(context, "ac", "u3", "cs");

        service.deleteSubTree("/f35");
    }

    @Test
    public void testWithZooKeeperTreePresent_alt_withGAVSystemProperties() throws Exception {
        doTestWithZooKeeperTreePresent_alt(true);
    }

    @Test
    public void testOverridingClientPropertiesLocation_classpath() throws Exception {
        doTestOverridingClientPropertiesLocation("classpath:/properties/alt-zookeeper-client.properties");
    }

    @Test
    public void testOverridingClientPropertiesLocation_file() throws Exception {
        URL resource = getClass().getClassLoader().getResource("properties/alt-zookeeper-client.properties");
        assertNotNull(resource);

        String url = resource.toString();
        assertTrue(url.startsWith("file:"));

        doTestOverridingClientPropertiesLocation(url);
    }

    private void doTestOverridingClientPropertiesLocation(String location) throws Exception {
        // PURPOSE: make sure when we override it is able to load the properties
        startServer(port);
        connectClient(port);
        createPropertyTree();

        System.setProperty("zookeeper.properties.location", location);
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "test-zkppc-with-placeholders-context-overridden-location.xml");

        // make sure the properties used were correct
        ZooKeeperPropertyPlaceholderConfigurer configurer = context
                .getBean(ZooKeeperPropertyPlaceholderConfigurer.class);
        assertNotNull(configurer);
        Properties zkProperties = configurer.zooKeeperClientProperties;
        assertTrue(zkProperties.getProperty("loadedAltFile").equals("true"));

        // and make sure the values were replaced as before
        assertExpectedBeanValues(context, "ac", "u3", "cs");
    }

    @Test
    public void testWithZooKeeperTreePresent_alt_withoutGAVSystemProperties() throws Exception {
        doTestWithZooKeeperTreePresent_alt(false);
    }

    private void doTestWithZooKeeperTreePresent_alt(boolean gavSystemPropertiesSet) throws Exception {
        startServer(port);
        connectClient(port);
        createPropertyTree();

        // now check that the gav override works
        if (!gavSystemPropertiesSet) {
            clearSystemProperties();
        }
        ClassPathXmlApplicationContext altContext = new ClassPathXmlApplicationContext(
                "test-zkppc-with-placeholders-context-gav-override.xml");
        assertExpectedBeanValues(altContext, "ac_alt", "u3_alt", "cs_alt");

        service.deleteSubTree("/f35");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGAVOverrideSyntax_invalid0() throws Exception {
        new ZooKeeperPropertyPlaceholderConfigurer().setGavOverride("");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGAVOverrideSyntax_invalid1() throws Exception {
        new ZooKeeperPropertyPlaceholderConfigurer().setGavOverride("a");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGAVOverrideSyntax_invalid2() throws Exception {
        new ZooKeeperPropertyPlaceholderConfigurer().setGavOverride("a/b");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGAVOverrideSyntax_invalid3() throws Exception {
        new ZooKeeperPropertyPlaceholderConfigurer().setGavOverride("a/b/");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGAVOverrideSyntax_invalid4() throws Exception {
        new ZooKeeperPropertyPlaceholderConfigurer().setGavOverride("a/b/c/d");
    }

    @Test
    public void testGAVOverrideSyntax_valid() throws Exception {
        ZooKeeperPropertyPlaceholderConfigurer configurer = new ZooKeeperPropertyPlaceholderConfigurer();
        configurer.setGavOverride("a/b/c");

        assertEquals("a", configurer.overriddenGroupId);
        assertEquals("b", configurer.overriddenArtifactId);
        assertEquals("c", configurer.overriddenVersion);
    }

    @Test(expected = BeanCreationException.class)
    public void testGAVOverrideSyntaxContext_invalid1() throws Exception {
        // PURPOSE: make sure context blows up if override is not in the
        // expected format i.e. resolves to 3 values, GAV
        startServer(port);
        connectClient(port);
        new ClassPathXmlApplicationContext("test-zkppc-with-placeholders-context-invalid1-gav-override.xml");
        server.stop();
    }

    @Test(expected = BeanCreationException.class)
    public void testGAVOverrideSyntaxContext_invalid2() throws Exception {
        // PURPOSE: make sure context blows up if override is not in the
        // expected format i.e. resolves to 3 values, GAV
        startServer(port);
        connectClient(port);
        new ClassPathXmlApplicationContext("test-zkppc-with-placeholders-context-invalid2-gav-override.xml");
        server.stop();
    }

    private void assertExpectedBeanValues(ClassPathXmlApplicationContext context, String a, String b, String c)
            throws Exception {
        ZooKeeperPropertyPlaceholderConfigurer ppc = context.getBean(ZooKeeperPropertyPlaceholderConfigurer.class);

        Bean bean = context.getBean(Bean.class);
        assertNotNull(bean);
        assertEquals(a, bean.a);
        assertEquals(c, bean.c);
        assertEquals(b, bean.b);

        ppc.zkcs.prettyPrint("/f35/config");
        
        Properties props = bean.getLoadedProperties();
        if (props != null) {            
            assertEquals(a, props.getProperty("a"));
            assertEquals(c, props.getProperty("a.c"));
        }

        context.close();
    }

    @Test
    public void testWithZooKeeperTreeGoesDown() throws Exception {

        startServer(port);
        connectClient(port);
        createPropertyTree();

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "test-zkppc-with-placeholders-context.xml");
        ZooKeeperPropertyPlaceholderConfigurer ppc = context.getBean(ZooKeeperPropertyPlaceholderConfigurer.class);

        Bean bean = context.getBean(Bean.class);
        assertNotNull(bean);
        assertEquals("ac", bean.a);
        assertEquals("cs", bean.c);
        assertEquals("u3", bean.b);

        ppc.zkcs.prettyPrint("/f35/config");

        List<String> locks = ppc.zkcs.getClient().getChildren(
                "/f35/config/foo/bar/baz/a/b/tag:config:lease:group:node/tag:config:lease:entity::3");
        assertEquals(1, locks.size());

        server.stop(false);

        Thread.sleep(60000);

        logger.info("Restarting the server");
        server.reStart();

        logger.info("Waiting for client to reconnect");
        Thread.sleep(20000);

        ppc.zkcs.prettyPrint("/f35/config");

        locks = ppc.zkcs.getClient().getChildren(
                "/f35/config/foo/bar/baz/a/b/tag:config:lease:group:node/tag:config:lease:entity::3");
        assertEquals(1, locks.size());

        context.close();
        service.deleteSubTree("/f35");

    }

    // TODO: test override with zk down where spring wins
    // TODO: test system properties override works with zk properties
    // TODO: test system properties fallback works with zk properties

    @Before
    public void initSystemProperties() throws Exception {
        System.setProperty(ZooKeeperClientPropertiesLoader.GROUP_ID, "foo");
        System.setProperty(ZooKeeperClientPropertiesLoader.ARTIFACT_ID, "bar");
        System.setProperty(ZooKeeperClientPropertiesLoader.VERSION, "baz");
        System.setProperty(ZooKeeperClientPropertiesLoader.ENV, "local");
    }

    private void clearSystemProperties() {
        System.setProperties(null);
    }

    private void createPropertyTree() throws Exception {
        createPropertyTree("foo", "bar", "baz", LEASE_PROVIDER_VALUE, new String[] { LEASE_1_VALUE, LEASE_2_VALUE,
                LEASE_3_VALUE }, "ac", "cs");
        createPropertyTree("foo_alt", "bar_alt", "baz_alt", ALT_LEASE_PROVIDER_VALUE, new String[] { ALT_LEASE_1_VALUE,
                ALT_LEASE_2_VALUE, ALT_LEASE_3_VALUE }, "ac_alt", "cs_alt");
    }

    private void createPropertyTree(String group, String artifact, String version, String leaseProviderValue,
            String[] leasedValues, String aValue, String cValue) throws Exception {
        String gavPath = group + "/" + artifact + "/" + version;
        String f35ConfigPath = "/f35/config/" + gavPath;

        client.createFull(f35ConfigPath, CreateMode.PERSISTENT);
        client.create(f35ConfigPath + "/a", aValue, CreateMode.PERSISTENT);
        client.create(f35ConfigPath + "/a/c", cValue, CreateMode.PERSISTENT);
        client.create(f35ConfigPath + "/a/b", CreateMode.PERSISTENT);

        String leaseProviderPath = client.create(f35ConfigPath + "/a/b/"
                + ConfigTagSchemeHelper.SCHEME_LEASE_GROUP_NODE, leaseProviderValue, CreateMode.PERSISTENT);

        for (int i = 0; i < leasedValues.length; i++) {
            client.create(leaseProviderPath + "/" + ConfigTagSchemeHelper.SCHEME_LEASE_ENTITY + (i + 1),
                    leasedValues[i], CreateMode.PERSISTENT);
        }
    }

    private void startServer(int port) {
        logger.info("starting server on port {}", port);
        server.start(port);
    }

    public String getZKHostPort(int port) {
        try {
            return InetAddress.getLocalHost().getHostName() + ":" + port;
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
    }

    private void connectClient(int port) throws Exception {
        client.connect(getZKHostPort(port), "1000", "2000", "foo", "bar");
    }

    @Before
    public void beforeTest() throws Exception {
        server = new ZooKeeperStandaloneTestServer();
        client = new ZooKeeperClient();
        service = new ZooKeeperConfigService(client);
    }

    @After
    public void afterTest() throws InterruptedException {
        service.stop();

        if (client != null) {
            logger.info("closing client");
            client.stop();
        }

        if (server != null && server.isStarted()) {
            logger.info("closing server");
            server.stop();
        }
    }

    static class Bean {
        private String a;
        private String c;
        private String b;
        
        private Properties loadedProperties;

        public void setA(String a) {
            this.a = a;
        }

        public void setC(String c) {
            this.c = c;
        }

        public void setB(String b) {
            this.b = b;
        }

        public String getA() {
            return a;
        }

        public String getC() {
            return c;
        }

        public String getB() {
            return b;
        }
        
        public Properties getLoadedProperties() {
            return loadedProperties;
        }

        public void setLoadedProperties(Properties loadedProperties) {
            this.loadedProperties = loadedProperties;
        }

        @Override
        public String toString() {
            StringBuilder builder = new StringBuilder();
            builder.append("Bean [a=").append(a).append(", c=").append(c).append("]");
            return builder.toString();
        }

    }

    @Test
    public void testClaimOfNoLeasedProperties() throws Exception {
        startServer(port);
        connectClient(port);
        createPropertyTree();

        String contextName="test-zkppc-with-placeholders-context.xml";
        
        testLoadContext(contextName);
        testLoadContext(contextName);
        testLoadContext(contextName);

        try {
            //This time the leased property should not be available so will kill startup.
            testLoadContext(contextName);
        } catch (Throwable t) {
            //This is expected, should kill the app.
            return;
        }
        fail("Should not have been able to load context");
    }
    
    
    @Test
    public void testTrim(){
        ZooKeeperPropertyPlaceholderConfigurer configurer = new ZooKeeperPropertyPlaceholderConfigurer();
        Object obj = new Object();
        Properties prop = new Properties();
        prop.put("1", " fddffd");
        prop.put("2", 23);
        prop.put("3", obj);
        prop.put("4", "   ");
        prop.put("5", "");
        prop.put("6", "asdsa ");
        configurer.trimProperties(prop);
        Assert.assertEquals(" fddffd",prop.get("1"));
        Assert.assertEquals(23,prop.get("2"));
        Assert.assertEquals(obj,prop.get("3"));
        Assert.assertEquals("   ",prop.get("4"));
        Assert.assertEquals("",prop.get("5"));
        Assert.assertEquals("asdsa ",prop.get("6"));
        configurer.setTrimProperties(true);
        configurer.trimProperties(prop);
        Assert.assertEquals("fddffd",prop.get("1"));
        Assert.assertEquals(23,prop.get("2"));
        Assert.assertEquals(obj,prop.get("3"));
        Assert.assertEquals("",prop.get("4"));
        Assert.assertEquals("",prop.get("5"));
        Assert.assertEquals("asdsa",prop.get("6"));
    }
    
    @Test
    public void testLoadEntitlements_clean() throws Exception {
        // PURPOSE: make sure entitlements properties are added in when there are no clashes	
        Properties springProperties = new Properties();        
        ZooKeeperPropertyPlaceholderConfigurer configurer = new ZooKeeperPropertyPlaceholderConfigurer();
        configurer.setEntitlementsPropertiesLocation(new ClassPathResource("entitlements-overrides.properties"));        
        configurer.loadEntitlementsProperties(springProperties);
        
        assertEquals(4, springProperties.size());
        assertEquals(springProperties.get("entitlements.transport_lbtrm_destination_port"), "3000");
        assertEquals(springProperties.get("entitlements.transport_lbtrm_multicast_address"), "239.193.76.153");
        assertEquals(springProperties.get("entitlements.resolver_multicast_address"), "239.193.76.149");
        assertEquals(springProperties.get("entitlements.resolver_multicast_port"), "12965");
    }
    
    @Test
    public void testLoadEntitlements_clashes() throws Exception {
        // PURPOSE: ensure none of the entitlements properties are loaded if they already exist in spring properties	
        Properties springProperties = new Properties();        
        springProperties.setProperty("entitlements.resolver_multicast_port", "666");
        
        ZooKeeperPropertyPlaceholderConfigurer configurer = new ZooKeeperPropertyPlaceholderConfigurer();
        configurer.setEntitlementsPropertiesLocation(new ClassPathResource("entitlements-overrides.properties"));        
        configurer.loadEntitlementsProperties(springProperties);
        
        // should not have had any of the entitlements loaded
        assertEquals(1, springProperties.size());
        assertEquals("666", springProperties.getProperty("entitlements.resolver_multicast_port"));
    }
    
    @Test
    public void testLoadEntitlements_notSet() throws Exception {
        // PURPOSE: make sure it just ignores the missing resource	
        Properties springProperties = new Properties();        
        springProperties.setProperty("entitlements.resolver_multicast_port", "666");
        
        ZooKeeperPropertyPlaceholderConfigurer configurer = new ZooKeeperPropertyPlaceholderConfigurer();       
        configurer.loadEntitlementsProperties(springProperties);
        assertEquals(1, springProperties.size());
        assertEquals("666", springProperties.getProperty("entitlements.resolver_multicast_port"));
    }

    @Test
    public void testNoZookeeperContext()throws Exception {

        startServer(port);
        connectClient(port);       
        createPropertyTree();
        
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("test-no-zk-context.xml");
        ZooKeeperPropertyPlaceholderConfigurer ppc = context.getBean(ZooKeeperPropertyPlaceholderConfigurer.class);
        
        assertNotNull(ppc);
    
        Bean bean = context.getBean(Bean.class);

        assertNotNull(bean);
        assertEquals("aNotFromZk", bean.a);
        assertEquals("cNotFromZk", bean.c);
        assertEquals("u1NotFromZk", bean.b);
        
    }
    
    private void testLoadContext(String contextName) {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(contextName);
        ZooKeeperPropertyPlaceholderConfigurer ppc = context.getBean(ZooKeeperPropertyPlaceholderConfigurer.class);

        Bean bean = context.getBean(Bean.class);
        assertNotNull(bean);
        logger.info("Property of a: " + bean.a);
        logger.info("Property of b: " + bean.b);
        logger.info("Property of c: " + bean.c);
    }

}