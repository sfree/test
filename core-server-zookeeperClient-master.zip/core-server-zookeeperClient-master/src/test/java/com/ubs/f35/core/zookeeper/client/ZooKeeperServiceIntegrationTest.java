package com.ubs.f35.core.zookeeper.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.google.common.io.Closeables;
import com.ubs.f35.core.zookeeper.client.LazyZNode.LazyLoadException;
import com.ubs.f35.core.zookeeper.client.ZNode.ZNodeType;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService.TraversalType;
import com.ubs.f35.core.zookeeper.client.common.StringValueTransformer;
import com.ubs.f35.core.zookeeper.client.tools.ZooKeeperTreeImporter;

public class ZooKeeperServiceIntegrationTest {

    static final Logger logger = LoggerFactory.getLogger(ZooKeeperServiceIntegrationTest.class);

    static final StringValueTransformer valueTransformer = new StringValueTransformer();

    private static ZooKeeperStandaloneTestServer server = new ZooKeeperStandaloneTestServer();
    private static ZooKeeperClient client = new ZooKeeperClient();
    private static ZooKeeperService service;

    private static final String DEV0_ZK_HOST_PORTS = "xldn4158vdap.ldn.swissbank.com:2080,"
            + "xldn4158vdap.ldn.swissbank.com:2081," + "xldn4158vdap.ldn.swissbank.com:2082,"
            + "xldn4158vdap.ldn.swissbank.com:2083," + "xldn4158vdap.ldn.swissbank.com:2084";

    private static class CollectingZNodeProcessor implements ZNodeProcessor {
        private List<ZNode> list;

        public CollectingZNodeProcessor(List<ZNode> list) {
            this.list = list;
        }

        @Override
        public void process(ZNode zNode) throws InterruptedException, KeeperException {
            list.add(zNode);
        }
    }

    @Test
    public void testWalkDfsAndBfs() throws Exception {

        client.createFull("/a/b/d", CreateMode.PERSISTENT);
        client.createFull("/a/c/e", CreateMode.PERSISTENT);

        DefaultZNode a = new DefaultZNode("/a", ZNodeType.PERSISTENT, 0, false, null, null, null);
        DefaultZNode b = new DefaultZNode("/a/b", ZNodeType.PERSISTENT, 1, false, null, a, null);
        DefaultZNode c = new DefaultZNode("/a/c", ZNodeType.PERSISTENT, 1, false, null, a, null);
        DefaultZNode d = new DefaultZNode("/a/b/d", ZNodeType.PERSISTENT, 2, true, null, b, null);
        DefaultZNode e = new DefaultZNode("/a/c/e", ZNodeType.PERSISTENT, 2, true, null, c, null);

        List<ZNode> dfsActual = new ArrayList<ZNode>();
        service.walk("/a", new CollectingZNodeProcessor(dfsActual));
        List<ZNode> dfsExpected = Arrays.asList(new ZNode[] { a, c, e, b, d });
        assertEquals(dfsExpected, dfsActual);

        List<ZNode> bfsActual = new ArrayList<ZNode>();
        service.walk("/a", new CollectingZNodeProcessor(bfsActual), TraversalType.BREADTH_FIRST);
        List<ZNode> bfsExpected = Arrays.asList(new ZNode[] { a, b, c, d, e });
        assertEquals(bfsExpected, bfsActual);

        service.deleteSubTree("/a"); // cleanup root
    }

    @Test
    public void testZNodeType() throws Exception {

        client.create("/a", CreateMode.PERSISTENT);
        client.createFull("/a/b", CreateMode.PERSISTENT);
        client.createFull("/a/b/ep", "abep", CreateMode.EPHEMERAL);
        client.createFull("/a/b/ps", "abps", CreateMode.PERSISTENT);
        String epsqName = client.create("/a/b/epsq-", "epsq", CreateMode.EPHEMERAL_SEQUENTIAL);
        String pssqName = client.create("/a/b/pssq-", "pssq", CreateMode.PERSISTENT_SEQUENTIAL);

        DefaultZNode a = new DefaultZNode("/a", ZNodeType.PERSISTENT, 0, false, null, null, null);
        DefaultZNode b = new DefaultZNode("/a/b", ZNodeType.PERSISTENT, 1, false, null, a, null);
        DefaultZNode c = new DefaultZNode("/a/b/ep", ZNodeType.EPHEMERAL, 2, true, "abep".getBytes(), b, null);
        DefaultZNode e = new DefaultZNode("/a/b/ps", ZNodeType.PERSISTENT, 2, true, "abps".getBytes(), b, null);
        DefaultZNode d = new DefaultZNode(epsqName, ZNodeType.EPHEMERAL, 2, true, "epsq".getBytes(), b, null);
        DefaultZNode f = new DefaultZNode(pssqName, ZNodeType.PERSISTENT, 2, true, "pssq".getBytes(), b, null);

        List<ZNode> dfsActual = new ArrayList<ZNode>();
        service.walk("/a", new CollectingZNodeProcessor(dfsActual));

        List<ZNode> dfsExpected = Arrays.asList(new ZNode[] { a, b, e, f, d, c });

        assertEquals(dfsExpected, dfsActual);
    }

    @Test
    public void testGetClient() {
        assertNotNull(service.getClient());
    }

    @Test
    public void testPrettyPrint() throws Exception {
        service.prettyPrint("/a");
    }

    @Test
    public void testRead() throws Exception {
        client.createFull("/a/b/d", "foo", CreateMode.PERSISTENT);
        client.createFull("/a/b/e", "bar", CreateMode.PERSISTENT);
        client.createFull("/a/c/f", "baz", CreateMode.PERSISTENT);
        client.createFull("/a/c/g", "qux", CreateMode.PERSISTENT);
        ZNode a = service.read("/a");
        assertNotNull(a);
        assertTrue(a instanceof LazyZNode);
        List<ZNode> children = a.children();
        assertNotNull(children);
        assertTrue(!children.isEmpty());
        assertTrue(children.size() == 2);

        for (ZNode child : children) {
            assertFalse(child.isLeaf());
            assertEquals(a, child.parent());
            assertEquals(Integer.valueOf(1), child.relativeOffset());
        }

        ZNode g = service.read("/a/c/g");
        assertTrue(g.isLeaf());
        assertEquals(a, g.parent().parent());
        assertNull(a.parent());
        assertNull(g.parent().parent().parent());
        assertEquals("qux", valueTransformer.fromInput(g.value()));
    }

    @Test
    public void testDoNavigableWalk() throws Exception {
        client.createFull("/a/b/d", "foo", CreateMode.PERSISTENT);
        client.createFull("/a/b/e", "bar", CreateMode.PERSISTENT);
        client.createFull("/a/c/f", "baz", CreateMode.PERSISTENT);
        client.createFull("/a/c/g", "qux", CreateMode.PERSISTENT);

        testDoNavigableWalk(TraversalType.BREADTH_FIRST);
        testDoNavigableWalk(TraversalType.DEPTH_FIRST);
    }

    private void testDoNavigableWalk(TraversalType traversalType) throws Exception {
        ZNodeNavigatorRecorder recorder = new ZNodeNavigatorRecorder();

        // non-existant node
        service.doWalk("/z", recorder, traversalType);
        assertEquals(0, recorder.numberOfVisitedNodes());
        recorder.reset();

        // leaf node
        service.doWalk("/a/b/d", recorder, traversalType);
        assertEquals(1, recorder.numberOfVisitedNodes());
        assertTrue(recorder.visitedNode("/a/b/d"));
        recorder.reset();

        // nodes with children
        service.doWalk("/a", recorder, traversalType);
        assertEquals(7, recorder.numberOfVisitedNodes());
        assertTrue(recorder.visitedNode("/a"));
        assertTrue(recorder.visitedNode("/a/b"));
        assertTrue(recorder.visitedNode("/a/b/d"));
        assertTrue(recorder.visitedNode("/a/b/e"));
        assertTrue(recorder.visitedNode("/a/c"));
        assertTrue(recorder.visitedNode("/a/c/f"));
        assertTrue(recorder.visitedNode("/a/c/g"));
        recorder.reset();

        service.doWalk("/a/c", recorder, traversalType);
        assertEquals(3, recorder.numberOfVisitedNodes());
        assertTrue(recorder.visitedNode("/a/c"));
        assertTrue(recorder.visitedNode("/a/c/f"));
        assertTrue(recorder.visitedNode("/a/c/g"));
        recorder.reset();

        // terminate
        ZNodeNavigatorRecorder terminatingRecorder = new ZNodeNavigatorRecorder() {
            protected NavigateResult getResult(ZNode zNode) {
                return zNode.name().equals("c") ? NavigateResult.TERMINATE : NavigateResult.CONTINUE;
            }
        };

        service.doWalk("/a", terminatingRecorder, traversalType);
        if (traversalType == TraversalType.BREADTH_FIRST) {
            assertEquals(3, terminatingRecorder.numberOfVisitedNodes());
            assertTrue(terminatingRecorder.visitedNode("/a"));
            assertTrue(terminatingRecorder.visitedNode("/a/b"));
            assertTrue(terminatingRecorder.visitedNode("/a/c"));
        } else {
            assertEquals(2, terminatingRecorder.numberOfVisitedNodes());
            assertTrue(terminatingRecorder.visitedNode("/a"));
            assertTrue(terminatingRecorder.visitedNode("/a/c"));
        }

        // skip siblings at non leaf level
        String nodeToSkipOn = traversalType == TraversalType.BREADTH_FIRST ? "b" : "c";
        ZNodeNavigatorRecorder skipSiblingRecorder = new SkipSiblingsZNodeNavigator(nodeToSkipOn);

        service.doWalk("/a", skipSiblingRecorder, traversalType);
        if (traversalType == TraversalType.BREADTH_FIRST) {
            assertEquals(4, skipSiblingRecorder.numberOfVisitedNodes());
            assertTrue(skipSiblingRecorder.visitedNode("/a"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/b"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/b/d"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/b/e"));
        } else {
            assertEquals(4, skipSiblingRecorder.numberOfVisitedNodes());
            assertTrue(skipSiblingRecorder.visitedNode("/a"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/c"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/c/f"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/c/g"));
        }
        skipSiblingRecorder.reset();

        // skip siblings at leaf level
        nodeToSkipOn = traversalType == TraversalType.BREADTH_FIRST ? "d" : "g";
        skipSiblingRecorder = new SkipSiblingsZNodeNavigator(nodeToSkipOn);

        service.doWalk("/a", skipSiblingRecorder, traversalType);
        if (traversalType == TraversalType.BREADTH_FIRST) {
            assertEquals(6, skipSiblingRecorder.numberOfVisitedNodes());
            assertTrue(skipSiblingRecorder.visitedNode("/a"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/b"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/c"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/b/d"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/c/f"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/c/g"));
        } else {
            assertEquals(6, skipSiblingRecorder.numberOfVisitedNodes());
            assertTrue(skipSiblingRecorder.visitedNode("/a"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/b"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/c"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/b/d"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/b/e"));
            assertTrue(skipSiblingRecorder.visitedNode("/a/c/g"));
        }

        // skip sub-tree
        logger.info("Skip subtree test");
        ZNodeNavigatorRecorder skipSubtreeRecorder = new ZNodeNavigatorRecorder() {
            protected NavigateResult getResult(ZNode zNode) {
                return zNode.name().equals("c") ? NavigateResult.SKIP_SUBTREE : NavigateResult.CONTINUE;
            }
        };

        service.doWalk("/a", skipSubtreeRecorder, traversalType);
        assertEquals(5, skipSubtreeRecorder.numberOfVisitedNodes());
        assertTrue(skipSubtreeRecorder.visitedNode("/a"));
        assertTrue(skipSubtreeRecorder.visitedNode("/a/c"));
        assertTrue(skipSubtreeRecorder.visitedNode("/a/b"));
        assertTrue(skipSubtreeRecorder.visitedNode("/a/b/d"));
        assertTrue(skipSubtreeRecorder.visitedNode("/a/b/e"));
    }

    @Test
    public void testNavigateWithExceptions() throws Exception {
        testNavigateWithException(new LazyLoadException());
        try {
            testNavigateWithException(new InterruptedException());
        } catch (Exception e) {
        }
        testNavigateWithException(new Exception());
    }

    private void testNavigateWithException(final Exception e) throws Exception {
        client.createFull("/a/b/d", "foo", CreateMode.PERSISTENT);
        client.createFull("/a/b/e", "bar", CreateMode.PERSISTENT);
        client.createFull("/a/c/f", "baz", CreateMode.PERSISTENT);
        client.createFull("/a/c/g", "qux", CreateMode.PERSISTENT);
        ZNodeNavigatorRecorder recorder = new ZNodeNavigatorRecorder() {

            @Override
            protected void performCallbackLogic() throws Exception {
                throw e;
            }

        };
        service.navigate("/a", recorder);
        assertEquals(7, recorder.numberOfVisitedNodes());
        assertTrue(recorder.visitedNode("/a"));
        assertTrue(recorder.visitedNode("/a/b"));
        assertTrue(recorder.visitedNode("/a/b/d"));
        assertTrue(recorder.visitedNode("/a/b/e"));
        assertTrue(recorder.visitedNode("/a/c"));
        assertTrue(recorder.visitedNode("/a/c/f"));
        assertTrue(recorder.visitedNode("/a/c/g"));
    }

    @Test
    @Ignore
    public void testCompareWalkTimesDev() throws IOException, Exception {
        logger.info("testing walk times on dev");
        ZooKeeperClient zkc = new ZooKeeperClient();
        zkc.connect(DEV0_ZK_HOST_PORTS, "5000", "10000", "foo", "bar");
        //zkc.addUser("foo", "bar");
        ZooKeeperService zks = new ZooKeeperService(zkc);
        doWalkCompareTimes(zks);
        zks.stop();
    }

    @Test
    public void testCompareWalkTimesLocal() throws IOException, Exception {

        logger.info("testing walk times on local");
        ClassPathResource cpr = new ClassPathResource("dev0-zk-tree-export.txt");
        BufferedReader br = new BufferedReader(new InputStreamReader(cpr.getInputStream()));
        new ZooKeeperTreeImporter(client).importTree(br);

        doWalkCompareTimes(service);

        Closeables.closeQuietly(br);
        service.deleteSubTree("/f35");
    }

    private void doWalkCompareTimes(ZooKeeperService zks) throws Exception, KeeperException, InterruptedException {

        logger.info("running dfs");
        doCompareWalkTimes(TraversalType.DEPTH_FIRST, zks);

        logger.info("running bfs");
        doCompareWalkTimes(TraversalType.BREADTH_FIRST, zks);

    }

    private void doCompareWalkTimes(TraversalType traversalType, ZooKeeperService zks) throws Exception,
            KeeperException, InterruptedException {

        ZNodeProcessor processor = new ZNodeProcessor() {

            @Override
            public void process(ZNode zNode) throws Exception {
            }
        };

        long start = System.currentTimeMillis();
        zks.doWalk("/f35", Collections.singleton(processor), new ArrayDeque<DefaultZNode>(), traversalType);
        long originalWalkDuration = System.currentTimeMillis() - start;

        ZNodeNavigator navigator = new ZNodeNavigator() {

            @Override
            public NavigateResult navigate(ZNode zNode) {
                return NavigateResult.CONTINUE;
            }

        };

        start = System.currentTimeMillis();
        zks.doWalk("/f35", navigator, traversalType);
        long newWalkDuration = System.currentTimeMillis() - start;

        long difference = originalWalkDuration - newWalkDuration;
        logger.info("original: {}, new: {}, difference: {}", new Object[] { originalWalkDuration, newWalkDuration,
                difference });

        assertTrue((originalWalkDuration) > newWalkDuration);

    }

    @Test
    public void testDeleteSubTree() throws Exception {
        client.createFull("/a/b/d", CreateMode.PERSISTENT);
        client.createFull("/a/b/e", CreateMode.PERSISTENT);
        client.createFull("/a/c", CreateMode.PERSISTENT);
        service.deleteSubTree("/a/b");
        service.prettyPrint("/a");
        DefaultZNode a = new DefaultZNode("/a", ZNodeType.PERSISTENT, 0, false, null, null, null);
        DefaultZNode c = new DefaultZNode("/a/c", ZNodeType.PERSISTENT, 1, true, null, a, null);
        List<ZNode> dfsActual = new ArrayList<ZNode>();
        service.walk("/a", new CollectingZNodeProcessor(dfsActual));
        List<ZNode> dfsExpected = Arrays.asList(new ZNode[] { a, c });
        assertEquals(dfsExpected, dfsActual);
    }

    @After
    public void after() throws Exception {
        service.deleteSubTree("/a");
    }

    @BeforeClass
    public static void beforeClass() throws ZooKeeperClientException {
        server.start();
        client.connect(server.hostPort(), "5000", "10000", "foo", "bar");
        service = new ZooKeeperService(client);
    }

    @AfterClass
    public static void afterClass() throws InterruptedException {
        service.stop();
        client.stop();
        server.stop();
    }

    private static class SkipSiblingsZNodeNavigator extends ZNodeNavigatorRecorder {
        private String nodeToSkipOn;

        private SkipSiblingsZNodeNavigator(String nodeToSkipOn) {
            this.nodeToSkipOn = nodeToSkipOn;
        }

        protected NavigateResult getResult(ZNode zNode) {
            return zNode.name().equals(nodeToSkipOn) ? NavigateResult.SKIP_SIBLINGS : NavigateResult.CONTINUE;
        }
    }

    private static class ZNodeNavigatorRecorder implements ZNodeNavigator {

        private Set<String> visitedNodes = new LinkedHashSet<String>();

        @Override
        public final NavigateResult navigate(ZNode zNode) throws Exception {
            logger.info("navigated to: {}", zNode.path());
            visitedNodes.add(zNode.path());
            performCallbackLogic();
            return getResult(zNode);
        }

        protected void performCallbackLogic() throws Exception {
        }

        protected NavigateResult getResult(ZNode zNode) {
            return NavigateResult.CONTINUE;
        }

        boolean visitedNode(String path) {
            return visitedNodes.contains(path);
        }

        int numberOfVisitedNodes() {
            return visitedNodes.size();
        }

        void reset() {
            visitedNodes.clear();
        }
    }
}