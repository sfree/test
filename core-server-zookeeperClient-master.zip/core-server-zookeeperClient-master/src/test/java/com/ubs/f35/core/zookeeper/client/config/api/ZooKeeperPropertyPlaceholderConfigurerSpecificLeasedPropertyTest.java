package com.ubs.f35.core.zookeeper.client.config.api;

import java.util.Properties;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperService;
import com.ubs.f35.core.zookeeper.client.ZooKeeperStandaloneTestServer;
import com.ubs.f35.core.zookeeper.client.common.ZooKeeperClientPropertiesLoader;
import com.ubs.f35.core.zookeeper.client.common.ZookeeperRootPathResolver;


/*
 * Test of ZooKeeperPropertyPlaceholderConfigurer in the specific scenario where a
 * user wants to request a specific leased property instance.
 */

public class ZooKeeperPropertyPlaceholderConfigurerSpecificLeasedPropertyTest {

  private static final Logger LOGGER=LoggerFactory.getLogger(ZooKeeperPropertyPlaceholderConfigurerSpecificLeasedPropertyTest.class);

  private static final int PORT=21811; // matches the port in
                                       // src/test/resources/properties/zookeeper-client.properties

  private ZooKeeperClient client=new ZooKeeperClient();
  private ZooKeeperStandaloneTestServer server=new ZooKeeperStandaloneTestServer();

  private static final String GROUP_ID="com.ubs.dummy";
  private static final String ARTIFACT_ID="dummy-artifact";
  private static final String VERSION="1.0.0";

  @SuppressWarnings("serial")
  private Properties toImport=new Properties() {
    {
      setProperty("mykey", "myvalue");
      setProperty("leased.fixed","${MY_SERVER}");
      setProperty("leased","expression: { leased:, keys: [username, password, timeout],  values: [[foo1, bar1, 1000], [foo2,bar2,2000], [foo3,bar3,3000]] }");
    }
  };


  @Test
  public void testSpecifiedLeaseNode() throws Exception {
    
    ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("test-zkppc-with-specific-leased-property.xml");

    TestBean testBean=context.getBean(TestBean.class);

    Assert.assertEquals("foo2",testBean.getUsername());
    Assert.assertEquals("bar2",testBean.getPassword());
    Assert.assertEquals("2000",testBean.getTimeout());
    
    context.close();
  }


  @BeforeClass
  public static void beforeClass() throws Exception {
    System.setProperty(ZooKeeperClientPropertiesLoader.GROUP_ID,GROUP_ID);
    System.setProperty(ZooKeeperClientPropertiesLoader.ARTIFACT_ID,ARTIFACT_ID);
    System.setProperty(ZooKeeperClientPropertiesLoader.VERSION,VERSION);
    System.setProperty(ZooKeeperClientPropertiesLoader.ENV,"local");
    System.setProperty("MY_SERVER","2");
  }

  @Before
  public void setup() throws Exception {
    startServer(PORT);
    connectClient(PORT);

    ZooKeeperService zks=new ZooKeeperService(client);
    ZooKeeperPropertyFileImporter pfi=new ZooKeeperPropertyFileImporter(zks,new ZookeeperRootPathResolver(ZooKeeperConfigService.ZOOKEEPER_CONFIG_ROOT_PATH,GROUP_ID,ARTIFACT_ID,VERSION));
    pfi.importProperties(toImport);
  }

  @After
  public void tearDown() {
    client.stop();
    server.stop(true);
  }

  private void connectClient(int port) throws Exception {
    client.connect(server.hostPort(),"1000","2000","foo","bar");
  }

  private void startServer(int port) {
    LOGGER.info("starting server on port {}",port);
    server.start(port);
  }


  public static class TestBean {
    private String username;
    private String password;
    private String timeout;

    public void setTimeout(String timeout) { this.timeout=timeout; }
    public void setUsername(String username) { this.username=username; }
    public void setPassword(String password) { this.password=password; }
    public String getTimeout() { return timeout; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
  }
}
