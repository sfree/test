package com.ubs.f35.core.zookeeper.client;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient.ZKConnectionCallback;

public class ZooKeeperClientConnectionTest {

    private static final Logger logger = LoggerFactory.getLogger(ZooKeeperClientConnectionTest.class);
    private ZooKeeperStandaloneTestServer server = new ZooKeeperStandaloneTestServer();
    private ZooKeeperClient client = new ZooKeeperClient();

    @Test
    public void testNonBlockingSuccessfulDelayedConnection() throws Exception {

        client.reconnectInterval = 2000; // 2 sec
        client.initializeConnectionThreadService();

        CountDownLatch latch = new CountDownLatch(1);
        ZKConnectionCallbackStub clbck = new ZKConnectionCallbackStub(latch);

        // Open the socket just to get the available port
        ServerSocket socket = new ServerSocket(0);
        final int port = socket.getLocalPort();
        String hostPort = getZKHostPort(port);
        socket.close();

        final CountDownLatch startLatch = new CountDownLatch(1);

        Thread serverStarter = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    startLatch.await();
                    Thread.sleep(6000); // sleep 6sec
                    startServer(port);
                } catch (InterruptedException e) {
                    logger.error("InterruptedException during starting the server", e);
                }
            }
        });

        logger.info("Connecting to the server that is not started yet");
        client.connect(hostPort, 1000, 2500, Collections.<ZKConnectionCallback>singletonList(clbck), true);

        logger.info("Starting the server");
        serverStarter.start();
        startLatch.countDown();
        serverStarter.join();

        long interval = 10000;
        logger.info("Waiting for the connection {}ms", interval);

        assertTrue("Client is not connected but should be", latch.await(interval, TimeUnit.MILLISECONDS));
    }

    @Test
    public void testNonBlockingSuccessfulDelayedConnectionWithReconnection() throws Exception {

        client.reconnectInterval = 2000; // 2 sec
        client.initializeConnectionThreadService();
        
        CountDownLatch startLatch = new CountDownLatch(1);
        ZKConnectionCallbackStub zkCallback = new ZKConnectionCallbackStub(startLatch);

        // Open the socket just to get the available port
        ServerSocket socket = new ServerSocket(0);
        final int port = socket.getLocalPort();
        String hostPort = getZKHostPort(port);
        socket.close();

        final CountDownLatch serverStartLatch = new CountDownLatch(1);

        Thread serverStarter = new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    serverStartLatch.await();
                    Thread.sleep(7000); // sleep 7sec
                    startServer(port);
                } catch (InterruptedException e) {
                    logger.error("InterruptedException during starting the server", e);
                }
            }
        });

        serverStarter.start();
        serverStartLatch.countDown();

        client.connect(hostPort, 1000, 2500, Collections.<ZKConnectionCallback>singletonList(zkCallback), true);

        serverStarter.join();

        assertTrue("Client is not connected but should be", startLatch.await(10000, TimeUnit.MILLISECONDS));

        logger.info("Stopping the server...");
        server.stop();

        logger.info("Sleeping for 7000ms to get the session expired");
        Thread.sleep(7000);

        final CountDownLatch reconnectLatch = new CountDownLatch(1);
        zkCallback.setLatch(reconnectLatch);

        logger.info("Starting the server");
        startServer(port);

        assertTrue("Client is not connected after restoring the server but should be",
                reconnectLatch.await(10000, TimeUnit.MILLISECONDS));
    }

    @Test
    public void testBlockingSuccessfulConnection() {

        startServer();
        try {
            client.connect(server.hostPort(), "5000", "10000", "foo", "bar");
        } catch (ZooKeeperClientException e) {
            fail();
        }

        assertTrue("Client is not connected", client.isAlive());
    }

    @Test(expected = com.ubs.f35.core.zookeeper.client.ZooKeeperClientException.class)
    public void testBlockingFailedConnection() throws Exception {
        client.connect(server.hostPort(), "2000", "6000", "foo", "bar");
    }

    @Test
    public void testNonBlockingSuccessfulConnection() throws Exception {

        startServer();

        client.reconnectInterval = 2000; // 2 sec
        client.initializeConnectionThreadService();

        CountDownLatch latch = new CountDownLatch(1);
        ZKConnectionCallbackStub clbck = new ZKConnectionCallbackStub(latch);

        client.connect(server.hostPort(), 5000, 10000, Collections.<ZKConnectionCallback>singletonList(clbck), true);

        assertTrue("Client is not connected", latch.await(2000, TimeUnit.MILLISECONDS));
    }

    @Test
    public void testNonBlockingFailedConnection() throws Exception {

        client.reconnectInterval = 2000; // 2 sec
        client.initializeConnectionThreadService();

        CountDownLatch latch = new CountDownLatch(1);
        ZKConnectionCallbackStub clbck = new ZKConnectionCallbackStub(latch);

        client.connect(server.hostPort(), 500, 1000, Collections.<ZKConnectionCallback>singletonList(clbck), false);

        logger.info("Waiting for the connection");

        assertFalse("Client is connected but should not", latch.await(2500, TimeUnit.MILLISECONDS));
    }

    private class ZKConnectionCallbackStub implements ZKConnectionCallback {

        private CountDownLatch latch;

        public ZKConnectionCallbackStub(CountDownLatch latch) {
            this.latch = latch;
        }

        @Override
        public void onConnect(boolean restoredFromDisconnect) {
            latch.countDown();
        }

        public void setLatch(CountDownLatch latch) {
            this.latch = latch;
        }
    }

    private void startServer() {
        logger.info("starting server");
        server.start();
    }

    private void startServer(int port) {
        logger.info("starting server on port {}", port);
        server.start(port);
    }

    public String getZKHostPort(int port) {
        try {
            return InetAddress.getLocalHost().getHostName() + ":" + port;
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
    }

    @Before
    public void beforeTest() throws InterruptedException {
        server = new ZooKeeperStandaloneTestServer();
        client = new ZooKeeperClient();
    }

    @After
    public void afterTest() throws InterruptedException {
        if (client != null) {
            logger.info("closing client");
            client.stop();
        }

        if (server != null && server.isStarted()) {
            logger.info("closing server");
            server.stop();
        }
    }

}
