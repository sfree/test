package com.ubs.f35.core.zookeeper.client.tools;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient;
import com.ubs.f35.core.zookeeper.client.ZooKeeperStandaloneTestServer;

public class ZooKeeperTreeImporterTest {
    
    private ZooKeeperStandaloneTestServer server = new ZooKeeperStandaloneTestServer();
    private ZooKeeperClient client = new ZooKeeperClient();
    private ZooKeeperTreeImporter importer;
    
    private String importingTree = 
        "[ZNODE]:/a/b/ps : \n"+
        "[ZNODE]:/a/b/ps2 : null\n"+
        "[ZNODE]:/a/b/ps4 :  \n"+
        "[ZNODE]:/a/b/ps3 :  : \n"+
        "[ZNODE]:/a/b/ps5 :  abc \n"+
        " def \n";
    
    private static Map<String, String> resultTree = new HashMap<String, String>();
    
    static {
        resultTree.put("/a", null);
        resultTree.put("/a/b", null);
        resultTree.put("/a/b/ps", "");
        resultTree.put("/a/b/ps2", "null");
        resultTree.put("/a/b/ps4", " ");
        resultTree.put("/a/b/ps3", " : ");
        resultTree.put("/a/b/ps5", " abc \n def ");
    }
    
    @Test
    public void testImportTree() throws Exception {
        
        List<String> failedImports = importer.importTree(new StringReader(importingTree));
        
        assertTrue("Not all lines were imported", failedImports.isEmpty());
        
        for(Map.Entry<String, String> entry : resultTree.entrySet()) {
            String path = entry.getKey();
            String value = entry.getValue();
            assertTrue("The znode is not created", client.exists(path));
            byte[] zNodeValue = client.read(path);
            Object obj = (zNodeValue == null) ? null : new String(zNodeValue);
            assertEquals("The stored znode value is not correct", value, obj);
        }
    }
    
    @Before
    public void beforeTest() throws Exception {
        server.start();
        client.connect(server.hostPort(), "5000", "10000", "foo", "bar");
        importer = new ZooKeeperTreeImporter(client);
    }

    @After
    public void afterTest() throws Exception {
        client.stop();
        server.stop();
    }    
}
