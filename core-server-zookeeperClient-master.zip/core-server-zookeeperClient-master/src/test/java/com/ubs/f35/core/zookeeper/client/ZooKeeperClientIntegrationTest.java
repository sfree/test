package com.ubs.f35.core.zookeeper.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooDefs.Perms;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.ACL;
import org.apache.zookeeper.data.Id;
import org.apache.zookeeper.data.Stat;
import org.apache.zookeeper.server.auth.DigestAuthenticationProvider;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.f35.core.zookeeper.client.ZooKeeperClient.DataAndStat;

public class ZooKeeperClientIntegrationTest {

    private static final Logger logger = LoggerFactory.getLogger(ZooKeeperClientIntegrationTest.class);
    private static ZooKeeperStandaloneTestServer server = new ZooKeeperStandaloneTestServer();
    private static ZooKeeperClient client = new ZooKeeperClient();
    private static ZooKeeper zk;

    @Test
    public void test() throws NoSuchAlgorithmException, KeeperException, InterruptedException,
            UnsupportedEncodingException {

        // local acl
        client.addUser("foo1", "bar1");
        client.addUser("foo2", "bar2");
        List<ACL> acls1 = new ArrayList<ACL>();
        acls1.add(new ACL(Perms.ALL, new Id("digest", DigestAuthenticationProvider.generateDigest("foo:bar"))));
        acls1.add(new ACL(Perms.ALL, new Id("digest", DigestAuthenticationProvider.generateDigest("foo1:bar1"))));
        acls1.add(new ACL(Perms.ALL, new Id("digest", DigestAuthenticationProvider.generateDigest("foo2:bar2"))));
        assertEquals(acls1, client.acls);

        // remote acl
        client.create("/a", "a", CreateMode.PERSISTENT);
        List<ACL> acls2 = zk.getACL("/a", new Stat());
        assertEquals(client.acls, acls2);

        // get
        assertEquals("a", new String(client.read("/a"), "ISO-8859-1"));

        // get with watch
        final AtomicReference<WatchedEvent> watchedEvent = new AtomicReference<WatchedEvent>();
        final CountDownLatch watchCalled = new CountDownLatch(1);
        Watcher aWatch = new Watcher() {
            @Override
            public void process(final WatchedEvent event) {
                watchedEvent.set(event);
                watchCalled.countDown();
            }

        };
        assertEquals("a", new String(client.read("/a", aWatch), "ISO-8859-1"));

        client.set("/a", "updated");

        watchCalled.await(1, TimeUnit.SECONDS);
        assertNotNull("watch triggered", watchedEvent.get());
        assertEquals("watch event has correct path", "/a", watchedEvent.get().getPath());

        // exists
        assertTrue(client.exists("/a"));
        assertFalse(client.exists("/z"));

        // createFull
        client.createFull("/a/b/d", "d", CreateMode.PERSISTENT);
        assertEquals("d", new String(zk.getData("/a/b/d", false, null), "ISO-8859-1"));
        client.createFull("/a", "c", "c".getBytes(), CreateMode.PERSISTENT);
        assertEquals("c", new String(zk.getData("/a/c", false, null), "ISO-8859-1"));

        // hasChildren
        assertTrue(client.hasChildren("/a"));
        assertFalse(client.hasChildren("/a/b/d"));

        // getChildren
        List<String> children = client.getChildren("/a");
        assertEquals(Arrays.asList(new String[] { "b", "c" }), children);

        // set
        client.set("/a", "z");
        assertEquals("z", new String(zk.getData("/a", false, null), "ISO-8859-1"));

        // delete
        client.delete("/a/b/d");
        assertFalse(client.exists("/a/b/d"));
        try {
            client.delete("/a");
        } catch (Exception e) {
        }
        assertTrue(client.exists("/a"));

        // stat
        Stat stat = client.stat("/a");
        assertTrue(stat.getNumChildren() > 0);

    }

    @Test
    public void testGetChildrenOnNodeWithNoChildren() throws KeeperException, InterruptedException {
        zk.create("/foo", null, Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
        List<String> children = zk.getChildren("/foo", false);
        assertNotNull(children);
        assertTrue(children.isEmpty());
        zk.delete("/foo", -1);
    }

    @Test(expected = KeeperException.class)
    public void testGetChildrenOnNonExistentNode() throws InterruptedException, KeeperException {
        zk.getChildren("/foo", false);
    }

    @Test
    public void testGetData() throws KeeperException, InterruptedException {
        // zk.create("/foo", null, Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
        DataAndStat ds = client.getDataAndStat("/random");
        assertNull(ds);
        // zk.delete("/foo", -1);
    }

    @BeforeClass
    public static void beforeClass() throws IOException, InterruptedException, ZooKeeperClientException {
        logger.info("starting server");
        server.start();
        logger.info("starting client");
        client.connect(server.hostPort(), "5000", "10000", "foo", "bar");
        zk = client.client;
    }

    @AfterClass
    public static void afterClass() throws InterruptedException {
        logger.info("closing client");
        client.stop();
        logger.info("closing server");
        server.stop();
    }

}