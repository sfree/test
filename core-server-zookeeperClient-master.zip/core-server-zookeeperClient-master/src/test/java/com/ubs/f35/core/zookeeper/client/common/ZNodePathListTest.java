package com.ubs.f35.core.zookeeper.client.common;

import static org.junit.Assert.*;

import org.junit.Test;

import com.ubs.f35.core.zookeeper.client.DefaultZNode;
import com.ubs.f35.core.zookeeper.client.ZNode.ZNodeType;

public class ZNodePathListTest {

    @Test
    public void testProcess() {
        
        ZNodePathList znodePathList = new ZNodePathList("/f35/presence/application/com.ubs.execution/stub-adaptor/1.0.0");
        assertEquals("Number of znode path tokens does not equal the expected number", 6, znodePathList.size());
        
        DefaultZNode testZNode = new DefaultZNode("/a/b/c/", ZNodeType.PERSISTENT, 0, false, null);
        ZNodePathList defaultZnodePathList = new ZNodePathList(testZNode);
        assertEquals("Number of znode path tokens does not equal the expected number", 3, defaultZnodePathList.size());
    }
    
    
    @Test
    public void testToPath() {
        ZNodePathList znodePathList = new ZNodePathList("/f35/presence/application/com.ubs.execution/stub-adaptor/1.0.0");
        ZNodePathList appPathList = new ZNodePathList("/f35/presence/application");
        znodePathList.removeAll(appPathList);
        String resultPath = znodePathList.toPath();
        assertEquals("Resulted path is incorrect", "/com.ubs.execution/stub-adaptor/1.0.0", resultPath);
    }
    
    @Test
    public void testAddFirst() {    
        ZNodePathList znodePathList = new ZNodePathList("/com.ubs.execution/stub-adaptor/1.0.0");
        String pathPrefix = "/f35/presence/application";
        String expectedPath = "/f35/presence/application/com.ubs.execution/stub-adaptor/1.0.0";
        znodePathList.addFirst(pathPrefix);
        assertEquals("Created path doesnot equal the expecte one", expectedPath, znodePathList.toPath());
    }
    
    @Test
    public void testAddLast() {    
        ZNodePathList znodePathList = new ZNodePathList("f35/presence/application");
        String pathSuffix = "/com.ubs.execution/stub-adaptor/1.0.0/";
        String expectedPath = "/f35/presence/application/com.ubs.execution/stub-adaptor/1.0.0";
        znodePathList.addLast(pathSuffix);
        assertEquals("Created path doesnot equal the expecte one", expectedPath, znodePathList.toPath());
    }    
    
    
}
