package com.ubs.f35.core.zookeeper.client.config.api;

import static org.junit.Assert.*;

import org.junit.Test;

public class CommandLineExceptionTest {

    @Test
    public void testCommandLineException() {
        CommandLineException e = new CommandLineException.LeaseValueLockedException();
        assertEquals(-6, e.exitCode());
    }
    
}
