package com.ubs.f35.core.zookeeper.client.common;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper;
import com.ubs.f35.core.zookeeper.client.config.ConfigTagSchemeHelper.ConfigTagScheme;

public class ConfigTagSchemeHelperTest {

    @Test
    public void testGroup() {
        String s = "tag:config:lease:group:encrypted:node";
        ConfigTagScheme scheme = ConfigTagSchemeHelper.parse(s);
        assertTrue(scheme.hasTag("tag"));
        assertTrue(scheme.isConfig());
        assertTrue(scheme.isLease());
        assertTrue(scheme.isLeaseGroup());
        assertTrue(scheme.isEncrypted());
        String s2 = new ConfigTagSchemeHelper().addLease().addLeaseGroup().addEncrypted().add("node").toString();
        assertEquals(s, s2);
    }

    @Test
    public void testEntity() {
        String s = "tag:config:lease:entity:encrypted";
        ConfigTagScheme scheme = ConfigTagSchemeHelper.parse(s);
        assertTrue(scheme.hasTag("tag"));
        assertTrue(scheme.isConfig());
        assertTrue(scheme.isLease());
        assertTrue(scheme.isLeaseEntity());
        assertTrue(scheme.isEncrypted());
        String s2 = new ConfigTagSchemeHelper().addLease().addLeaseEntity().addEncrypted().toString();
        assertEquals(s, s2);
    }

    @Test
    public void testLock() {
        String s = "tag:config:lease:lock";
        ConfigTagScheme scheme = ConfigTagSchemeHelper.parse(s);
        assertTrue(scheme.hasTag("tag"));
        assertTrue(scheme.isConfig());
        assertTrue(scheme.isLease());
        assertTrue(scheme.isLeaseLock());
        String s2 = new ConfigTagSchemeHelper().addLease().addLeaseLock().toString();
        assertEquals(s, s2);
    }

}