package com.ubs.f35.core.zookeeper.client.common;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringValueTransformerTest {

    @Test
    public void testBlanks() {
        StringValueTransformer svt = new StringValueTransformer();
        byte[] output = svt.toOutput("");
        String input = svt.fromInput(output);
        assertEquals("", input);
    }

}
