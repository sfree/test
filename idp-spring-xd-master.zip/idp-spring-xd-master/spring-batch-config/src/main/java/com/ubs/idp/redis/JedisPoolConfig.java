package com.ubs.idp.redis;

/**
 * Allow us to get into Jedis (Redis) pool configuration!
 * @author mcminnp
 */
public class JedisPoolConfig extends redis.clients.jedis.JedisPoolConfig {

	/**
	 * Setter for maxTotal
	 * @param maxTotal
	 */
	public void maxTotal(int maxTotal) {
		super.setMaxTotal(maxTotal);
	}
	
}
