package com.ubs.idp.batch;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import oracle.ucp.jdbc.PoolDataSource;
import oracle.ucp.jdbc.PoolDataSourceFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.beans.factory.config.SingletonBeanRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import com.ubs.idp.encrypt.Crypto;

/**
 * Override the default job Spring Batch configuration
 */
@Configuration("idpBatchConfigurer")
@PropertySources(@PropertySource({ "classpath:application.properties", "classpath:environment-${environment}.properties" }))
public class IDPBatchConfigurer implements BatchConfigurer, ApplicationContextAware {

    @Autowired
    private ConfigurableEnvironment environment;

    private static Logger LOGGER = LoggerFactory.getLogger(IDPBatchConfigurer.class);
    private static final String ISOLATION_LEVEL_FOR_CREATE = "ISOLATION_READ_COMMITTED";

    private ApplicationContext ctx;
    private PlatformTransactionManager transactionManager;
    private JobRepository jobRepository;
    private JobLauncher jobLauncher;
    private JobExplorer jobExplorer;
    private PoolDataSource dataSource;

    @Override
    public JobExplorer getJobExplorer() throws Exception {
        return jobExplorer;
    }

    @Override
    public JobLauncher getJobLauncher() throws Exception {
        return jobLauncher;
    }

    @Override
    public JobRepository getJobRepository() throws Exception {
        return jobRepository;
    }

    @Override
    public PlatformTransactionManager getTransactionManager() throws Exception {
        if (transactionManager == null) {
            LOGGER.debug("getTransactionManager...");
            transactionManager = new DataSourceTransactionManager(getDataSource());
        }
        return transactionManager;
    }

    @PostConstruct
    public void initialize() throws Exception {

        jobRepository = createJobRepository();
        JobExplorerFactoryBean jobExplorerFactoryBean = new JobExplorerFactoryBean();
        jobExplorerFactoryBean.setDataSource(getDataSource());
        jobExplorerFactoryBean.afterPropertiesSet();
        jobExplorer = jobExplorerFactoryBean.getObject();

        if (ctx != null) {
            LOGGER.debug("check job repo dataSource: {}", ctx.getBean("dataSource"));
            if (!(ctx.getBean("dataSource") instanceof PoolDataSource)) {
                AutowireCapableBeanFactory beanFactory = ctx.getAutowireCapableBeanFactory();
                GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
                beanDefinition.setBeanClass(PoolDataSource.class);
                beanDefinition.setAutowireCandidate(true);
                ((BeanDefinitionRegistry) beanFactory).registerBeanDefinition("dataSource", beanDefinition);
                beanFactory.autowireBeanProperties(this, AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE, false);
                ((DefaultListableBeanFactory) beanFactory).destroySingleton("dataSource");
                ((SingletonBeanRegistry) beanFactory).registerSingleton("dataSource", getDataSource());
                LOGGER.debug("dataSource is now set to: {}", ctx.getBean("dataSource"));
            }
        } else {
            LOGGER.debug("context hasn't been set!");
        }
        this.jobLauncher = createJobLauncher();
    }

    @Bean(name = "dataSource")
    public DataSource getDataSource() throws SQLException {

        if (dataSource == null) {
            checkEnvironment();

            LOGGER.debug("Creating Job Repo DataSource");
            LOGGER.debug("xd.db.driver_class: {}", environment.getProperty("xd.db.driver_class"));
            LOGGER.debug("xd.db.url: {}", environment.getProperty("xd.db.url"));
            LOGGER.debug("xd.db.user: {}", environment.getProperty("xd.db.user"));
            LOGGER.debug("xd.db.password: {}", environment.getProperty("xd.db.password"));

            dataSource = PoolDataSourceFactory.getPoolDataSource();
            dataSource.setConnectionFactoryClassName(environment.getProperty("xd.db.driver_class"));
            dataSource.setConnectionPoolName("SPRING_XD_JOB_REPO");
            dataSource.setConnectionWaitTimeout(8);
            dataSource.setURL(environment.getProperty("xd.db.url"));
            dataSource.setUser(environment.getProperty("xd.db.user"));
            dataSource.setPassword(Crypto.decrypt(environment.getProperty("xd.db.password")));
            dataSource.setInitialPoolSize(2);
            dataSource.setMinPoolSize(2);
            dataSource.setMaxPoolSize(20);
            dataSource.setInactiveConnectionTimeout(300);
            dataSource.setMaxStatements(40);
            dataSource.setAbandonedConnectionTimeout(120);
            dataSource.setValidateConnectionOnBorrow(true);
        }
        return dataSource;
    }

    private void checkEnvironment() {
        if (environment == null) {
            LOGGER.debug("environment not autowired...");
            environment = new StandardEnvironment();
            customLoadEnvironmentProperties();
        } else if (environment.getProperty("xd.db.driver_class") == null) {
            LOGGER.debug("environment is autowired but props not present...");
            customLoadEnvironmentProperties();
        }
    }

    private void customLoadEnvironmentProperties() {
        try {
            LOGGER.info("Custom load of environment properties...");
            String filename = "environment-" + System.getProperty("environment") + ".properties";
            LOGGER.debug("loading {}", filename);
            Properties envProps = new Properties();
            envProps.load(this.getClass().getClassLoader().getResourceAsStream(filename));
            MutablePropertySources propertySources = environment.getPropertySources();
            Map<String, Object> myMap = new HashMap<String, Object>();
            for (Object key : envProps.keySet()) {
                myMap.put((String) key, envProps.getProperty((String) key));
            }
            propertySources.addFirst(new MapPropertySource("customEnvironment", myMap));
        } catch (IOException e) {
            LOGGER.warn("problem loading environment properties file", e);
        }
    }

    private JobLauncher createJobLauncher() throws Exception {
        SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
        jobLauncher.setJobRepository(jobRepository);
        jobLauncher.afterPropertiesSet();
        return jobLauncher;
    }

    protected JobRepository createJobRepository() throws Exception {
        LOGGER.debug("createJobRepository...");
        JobRepositoryFactoryBean factory = new JobRepositoryFactoryBean();
        factory.setDataSource(getDataSource());
        factory.setTransactionManager(getTransactionManager());
        factory.setIsolationLevelForCreate(ISOLATION_LEVEL_FOR_CREATE);
        factory.afterPropertiesSet();
        return factory.getObject();
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        LOGGER.debug("setApplicationContext...");
        ctx = applicationContext;
        LOGGER.debug("dataSource: {}", ctx.getBean("dataSource"));
    }
}
