package com.ubs.idp.xd.plugin;

import com.ubs.idp.metadata.client.Neo4jMetadataServiceImpl;
import com.ubs.idp.metadata.client.properties.MetadataServiceZookeeperDecorator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.SingletonBeanRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.xd.module.core.Module;
import org.springframework.xd.module.core.Plugin;

import java.util.Map;

@Component
public class MetadataClientPlugin implements Plugin, Ordered, ApplicationContextAware {

    private static final Logger LOGGER = LoggerFactory.getLogger(MetadataClientPlugin.class);
    private static final String MDS_CLIENT_BEAN_NAME = "mdsClient";
    private static final String NEO4J_MDS_BEAN_NAME = "neo4jMetadataService";
    private ApplicationContext applicationContext;

    public MetadataClientPlugin() {
        LOGGER.info("Initializing IDP XD Plugin");
    }

    @Override
    public void preProcessModule(Module module) {

        registerMdsClient();
    }

    private void registerMdsClient() {
        MetadataServiceZookeeperDecorator mdsClient = null;
        Map<String, MetadataServiceZookeeperDecorator> beans = applicationContext.getBeansOfType(MetadataServiceZookeeperDecorator.class);
        if (beans.entrySet().iterator() != null && beans.entrySet().iterator().hasNext()) {
            mdsClient = beans.entrySet().iterator().next().getValue();
        }
        ConfigurableListableBeanFactory beanFactory = ((ConfigurableApplicationContext) applicationContext.getParent()).getBeanFactory();
        if (mdsClient !=null && !beanFactory.containsBean(MDS_CLIENT_BEAN_NAME)) {
            beanFactory.registerSingleton(MDS_CLIENT_BEAN_NAME, mdsClient);
            LOGGER.info("{} bean added to spring application context", MDS_CLIENT_BEAN_NAME);
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Override
    public int getOrder() {
        return HIGHEST_PRECEDENCE;
    }

    @Override
    public void postProcessModule(Module module) {
    }

    @Override
    public void removeModule(Module module) {
    }

    @Override
    public void beforeShutdown(Module module) {
    }

    @Override
    public boolean supports(Module module) {
        return true;
    }
}
