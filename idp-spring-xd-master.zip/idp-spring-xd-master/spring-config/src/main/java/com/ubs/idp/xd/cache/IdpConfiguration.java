package com.ubs.idp.xd.cache;

import java.io.InputStream;
import java.lang.management.ManagementFactory;

import javax.management.MBeanServer;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.management.ManagementService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableCaching
public class IdpConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(IdpConfiguration.class);

    @Bean(name = "cacheManager")
    public EhCacheCacheManager getCacheManager() {

        LOGGER.info("Creating Ehcache manager...");
        EhCacheCacheManager cacheCacheManager = new EhCacheCacheManager();

        InputStream in = this.getClass().getClassLoader().getResourceAsStream("ehcache.xml");
        CacheManager cacheManager = net.sf.ehcache.CacheManager.create(in);
        cacheManager.setName("IDP_EHCACHE");

        if (LOGGER.isDebugEnabled()) {
            String[] cacheNames = CacheManager.getInstance().getCacheNames();
            for (int i = 0; cacheNames.length > i; i++) {
                LOGGER.debug("cache name: {}", cacheNames[i]);
            }
        }
        registerCacheAsMBean(cacheManager);
        cacheCacheManager.setCacheManager(cacheManager);
        return cacheCacheManager;
    }

	private void registerCacheAsMBean(CacheManager cacheManager) {
		MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
        ManagementService.registerMBeans(cacheManager, mBeanServer, false, false, false, true);
	}
}

