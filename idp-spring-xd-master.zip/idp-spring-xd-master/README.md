idp-spring-xd
=============

Use the Maven assembly plugin in order to generate a tarball (distribution) containing the IDP Spring XD distribution

    mvn assembly:assembly

TeamCity build page
-------------------
[![Build Status](https://cft-teamcity.ldn.swissbank.com/app/rest/builds/buildType:%28id:Distribution_Idp_IdpSpringXd_Deploy%29/statusIcon)](https://cft-teamcity.ldn.swissbank.com/project.html?projectId=Distribution_Idp_IdpSpringXd)


Nexus artifact location
-----------------------

http://rkyctools.ldn.swissbank.com:8090/nexus/index.html#nexus-search;quick~idp-spring-xd
 
