This distribution is a modification by the IDP team of Spring XD 1.0.0.M5

Contains
- Spring XD 1.0.0.M5 (http://docs.spring.io/spring-xd/docs/1.0.0.M5/api/)
