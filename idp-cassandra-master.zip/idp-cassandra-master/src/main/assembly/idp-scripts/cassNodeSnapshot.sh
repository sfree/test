#!/bin/bash

# ONLY FOR USE ON UAT1 or PROD!!!!

# Prod Nodes

NODEIPS_PRD="172.16.182.86
172.16.182.89
172.16.182.87
172.16.182.81
172.16.182.85
172.16.182.88
172.16.182.90
172.16.182.83
172.16.182.82
172.16.182.84
172.16.34.106
172.16.34.111
172.16.34.105
172.16.34.114
172.16.34.107
172.16.34.109
172.16.34.113
172.16.34.110
172.16.34.108
172.16.34.128" 

# UAT1 Cass Nodes
NODEIPS_UAT1="14.2.67.54
161.239.28.93"

USERID=$(whoami)

indent() {
	while read line
	do
		echo "    "${line}
	done
}

CASSUSERNAME=controlRole

echo -e "Enter NEW snapshot ID -> \c"
read SNAPSHOTID

echo -e "Enter ${CASSUSERNAME} password -> \c"
read -s PASSWORD

echo ""

# Check for prod user - else UAT1

if [ ${USERID} == "idp_prd" ]
then
	echo "ATTENTION: Using PROD IP addresses..."
	NODEIPS="$NODEIPS_PRD"
	PROD=Y
else
	echo "ATTENTION: Using UAT1 IP addresses..."
	NODEIPS="$NODEIPS_UAT1"
	PROD=N
fi

echo -e "Continue? [Y/N] -> \c"
read confirm

case "${confirm}" in
	[Yy])
		;;
	*)
		echo "Aborting..."
		exit 1
		;;
esac

echo "Creating snapshots...."

for NODEIP in $NODEIPS
do
	NODENAME=$(nslookup ${NODEIP} | grep "name =" | sed 's/^.*name = //;s/\..*$//')

	# Check for prod user - else UAT1

	if [ ${PROD} == "Y" ]
	then
		NODETOOL="/sbcimp/run/pkgs/IDP/IDP-CASSANDRA/prd/bin/nodetool"
	else
		NODETOOL="/sbcimp/run/pkgs/IDP/IDP-CASSANDRA/uat1/bin/nodetool"
	fi

	echo "Processing node $NODEIP ($NODENAME)..."
	echo ""

	echo "Clear OLD snapshots..." | indent
	ssh -q $NODENAME ${NODETOOL} --port 7199 --username $CASSUSERNAME --password $PASSWORD clearsnapshot | indent
	echo "Create NEW ${SNAPSHOTID} snapshots..."
	ssh -q $NODENAME ${NODETOOL} --port 7199 --username $CASSUSERNAME --password $PASSWORD snapshot -t ${SNAPSHOTID} -- "IDP"
done

echo Done
