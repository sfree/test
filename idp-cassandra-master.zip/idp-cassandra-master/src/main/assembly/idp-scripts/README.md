idp-scripts
==============

Scripts in this directory are placed into the ```${HOME}/cassandra-scripts``` directory and include backup/recovery
and general maintenance scripts. 