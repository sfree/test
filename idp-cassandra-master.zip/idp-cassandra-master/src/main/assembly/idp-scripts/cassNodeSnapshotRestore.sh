#!/bin/bash

# ONLY FOR USE ON UAT1 or PROD!!!!

# Prod Nodes

NODEIPS_PRD="172.16.182.86
172.16.182.89
172.16.182.87
172.16.182.81
172.16.182.85
172.16.182.88
172.16.182.90
172.16.182.83
172.16.182.82
172.16.182.84
172.16.34.106
172.16.34.111
172.16.34.105
172.16.34.114
172.16.34.107
172.16.34.109
172.16.34.113
172.16.34.110
172.16.34.108
172.16.34.128" 

# UAT1 Cass Nodes
NODEIPS_UAT1="14.2.67.54
161.239.28.93"

USERID=$(whoami)

indent() {
	while read line
	do
		echo "    "${line}
	done
}

confirm() {
	prompt="$1"
	echo -e "$prompt [Y/N] -> \c" > /dev/tty
	read confirm

	case "${confirm}" in
		[Yy])
			echo Y
			;;
		*)
			echo N
			;;
	esac
}

echo -e "Enter snapshot ID to restore -> \c"
read SNAPSHOTID

echo ""

# Check for prod user - else UAT1

if [ ${USERID} == "idp_prd" ]
then
	echo "ATTENTION: Using PROD IP set-up..."
	NODEIPS="$NODEIPS_PRD"
	CTRLSCRIPT=/sbcimp/run/pkgs/IDP/IDP-CASSANDRA/prd/srl/idp_cassandra_ctl.sh
	ORIDESCRIPT=/home/idp_prd/cluster/idp-cassandra-PRD-override.sh
else
	echo "ATTENTION: Using UAT1 IP set-up..."
	NODEIPS="$NODEIPS_UAT1"
	CTRLSCRIPT=/sbcimp/run/pkgs/IDP/IDP-CASSANDRA/uat1/srl/idp_cassandra_ctl.sh
	ORIDESCRIPT=/home/idp_dev/cluster/idp-cassandra-UAT1-override.sh
fi

if [ ! -f ${CTRLSCRIPT} ]
then
	echo "Can't find file '$CTRLSCRIPT'?"
	exit 1
fi

if [ ! -f ${ORIDESCRIPT} ]
then
	echo "Can't find file '$ORIDESCRIPT'?"
	exit 1
fi

YESNO=$(confirm "Continue to shutdown Cassandra and restore snapshot?")

if [ ${YESNO} == "N" ]
then
	echo "Aborting..."
	exit 1
fi

echo "Shutting down cluster..."

$CTRLSCRIPT stop cluster all none ${ORIDESCRIPT}

echo "Restoring snapshots...."

for NODEIP in $NODEIPS
do
	NODENAME=$(nslookup ${NODEIP} | grep "name =" | sed 's/^.*name = //;s/\..*$//')

	CASS_HOME="/sbclocal/apps/glu-agent-server/apps/${NODENAME}/com.ubs.idp/idp-cassandra-*"
	CASS_INST_DIR="/sbclocal/apps/dyn/data/IDP/cassandra/${NODENAME}"
	IDP_KEYSPACE_DATA_DIR="${CASS_INST_DIR}/data/IDP"

	echo "Processing node $NODEIP ($NODENAME)..."
	echo ""

	# Check dirs exist

	ssh -q $NODENAME ls -d ${CASS_HOME} > /dev/null 2>&1

	if [ $? -ne 0 ]
	then
		echo ""
		echo "!!! No '${CASS_HOME}' directory? Aborting!!" | indent
		echo ""
		exit 1
	fi

	ssh -q $NODENAME ls -d ${IDP_KEYSPACE_DATA_DIR} > /dev/null 2>&1

	if [ $? -ne 0 ]
	then
		echo ""
		echo "!!! No '${IDP_KEYSPACE_DATA_DIR}' directory? Aborting!!" | indent
		echo ""
		exit 1
	fi

	# Verify each CF has this snapshot before we zap anything!

	echo "Checking for snapshot dirs...." | indent

	CFCOUNT=$(ssh -q $NODENAME find ${IDP_KEYSPACE_DATA_DIR} -mindepth 1 -maxdepth 1 -not -empty -type d | wc -l 2>/dev/null)
	SSCOUNT=$(ssh -q $NODENAME ls -ld ${IDP_KEYSPACE_DATA_DIR}/*/snapshots/${SNAPSHOTID} | wc -l 2>/dev/null)

	if [ $? -ne 0 ]
	then
		echo ""
		echo "!!! No '${SNAPSHOTID}' snapshot directories? Aborting!!" | indent
		echo ""
		exit 1
	fi

	if [ "${CFCOUNT}" != "${SSCOUNT}" ]
	then
		echo ""
		echo "!!! Missing ${SNAPSHOTID}' directories? Aborting!!" | indent
		echo ""
		echo "         Column family count     : $CFCOUNT"
		echo "         Snapshot directory count: $SSCOUNT"
		echo ""
		exit 1
	fi

	echo "Deleting commitlogs..." | indent
	ssh -q $NODENAME rm -f ${CASS_INST_DIR}/commitlog/*.log

	echo "Deleting saved caches..." | indent
	ssh -q $NODENAME rm -f ${CASS_INST_DIR}/saved_caches/*

	echo "Remove data files..." | indent
	ssh -q $NODENAME rm -f ${IDP_KEYSPACE_DATA_DIR}/*/*.db

	echo "Copy in snapshot files from '${SNAPSHOTID}' snapshot..." | indent
	ssh -q $NODENAME "for dir in ${IDP_KEYSPACE_DATA_DIR}/*/snapshots/${SNAPSHOTID}*; do cp \${dir}/* \${dir}/../.. 2>&1 | grep -v 'are the same file'; done"

	echo ""
done

# Start Cass back up - prompt user first in case of errors/funnies above....

YESNO=$(confirm "Re-start Cassandra (check above for errors/warnings before proceeding)?")

if [ ${YESNO} == "N" ]
then
	echo "Aborting... You will need to start MANUALLY!"
	exit 1
fi

echo "Starting up cluster..."

$CTRLSCRIPT start cluster all none ${ORIDESCRIPT}

echo ""
echo "Done"
