This distribution is a modification by the IDP team of Apache Cassandra 2.1.2

Contains
- Apache Cassandra 2.1.2 (http://cassandra.apache.org/)
- IDP Cassandra Security Library 1.0.4(https://github.ldn.swissbank.com/idp/idp-cassandra-security)
- Distribution's SSO Security Library 1.0.4 (https://github.ldn.swissbank.com/distribution/sso-security-lib)
