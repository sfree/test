idp-cassandra
=============

Use the Maven assembly plugin in order to generate a tarball (distribution) containing the Apache Cassandra distribution along with additional configuration templates and scripts to work with IDP

    mvn assembly:assembly

The custom scripts included will allow for configuring, starting, stopping and unconfiguring much like the Glu lifecycle model

	/sbclocal/apps/run/idp-cassandra-1.0.0/swift/postinstall /sbclocal/apps/run/idp-cassandra-1.0.0 2 3 4 5 ~/idp-cassandra-SIT-env-conf.sh
	/sbclocal/apps/run/idp-cassandra-1.0.0/swift/postconfigure /sbclocal/apps/run/idp-cassandra-1.0.0 2 3 4 5
	/sbclocal/apps/run/idp-cassandra-1.0.0/swift/poststart /sbclocal/apps/run/idp-cassandra-1.0.0 2 3 4 5
	/sbclocal/apps/run/idp-cassandra-1.0.0/swift/poststop /sbclocal/apps/run/idp-cassandra-1.0.0 2 3 4 5
	/sbclocal/apps/run/idp-cassandra-1.0.0/swift/postunconfigure /sbclocal/apps/run/idp-cassandra-1.0.0 2 3 4 5

Cheat sheet

    /sbclocal/apps/run/idp-cassandra-1.0.0/bin/nodetool -p 7199 status
    /sbclocal/apps/run/idp-cassandra-1.0.0/bin/nodetool -p 7199 describecluster
    /sbclocal/apps/run/idp-cassandra-1.0.0/bin/nodetool -p 7199 ring
    /sbclocal/apps/run/idp-cassandra-1.0.0/bin/nodetool -h 14.2.67.54 -p 7199 cfstats | grep Table: | less
    /sbclocal/apps/run/idp-cassandra-1.0.0/bin/nodetool -h 14.2.67.54 -p 7199 tpstats
Also see: http://confluence.swissbank.com/display/IDP/Troubleshooting+Cassandra
