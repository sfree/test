package com.ubs.idp.das.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import me.prettyprint.cassandra.service.ColumnSliceIterator;
import me.prettyprint.hector.api.Serializer;
import me.prettyprint.hector.api.beans.ColumnSlice;
import me.prettyprint.hector.api.beans.HColumn;
import me.prettyprint.hector.api.beans.Row;
import me.prettyprint.hector.api.beans.Rows;
import me.prettyprint.hector.api.query.QueryResult;

import org.apache.commons.lang.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.test.util.ReflectionTestUtils;

import com.ubs.idp.base.StaticValues;
import com.ubs.idp.das.QueryServiceConfiguration;
import com.ubs.idp.das.cassandra.Cassandra;
import com.ubs.idp.das.cassandra.CassandraFilter;
import com.ubs.idp.das.exception.FilegenException;
import com.ubs.idp.das.response.ResponseFormatter;
import com.ubs.idp.das.webservice.LocalController;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.model.JoinRelation;
import com.ubs.idp.metadata.model.PhysicalDataset;
import com.ubs.idp.metadata.model.exceptions.MetadataException;
import com.ubs.idp.metadata.model.relationships.JoinsRelationshipType;

@RunWith(MockitoJUnitRunner.class)
public class CassandraFilterTest {
	private LocalController localController = null;
	private ByteArrayOutputStream responseStream;
	private ByteArrayOutputStream responseParallelStream;
	private FileSystem fileSystem;
	
	private static final ResourceBundle TEST_DATA_FILE = ResourceBundle.getBundle(Shared.TEST_DATA_FILE);
	
	private CassandraFilter testee;
	
	@Mock
	private MetadataService metadataServiceMock;
	@Mock
	private HttpServletRequest request;
	@Mock
	private HttpServletResponse response;
	@Mock
	private HttpServletResponse responseParallel;
	@Mock
	private Cassandra cassandraMock;
	@Mock
	private ColumnSliceIterator<String, String, String> columnSliceIterator;
	@Mock
	private HColumn<String, String> hcolumnIndex;
	@Mock
	private HColumn<String, String> hcolumnMain1;
	@Mock
	private HColumn<String, String> hcolumnMain2;
	@Mock
	private QueryResult<Rows<String, String, String>> multigetQueryResult;
	@Mock
	private Rows<String, String, String> rows;
	@Mock
	private Row<String, String, String> row;
	@Mock
	private ColumnSlice<String, String> columnSlice;

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	static {
        System.setProperty("IDP_DAS_LOG_DIR", ".");
        System.setProperty("DAS_BASE_DIR", ".");
	}

	@Before
	public void setUp() throws Exception {
		localController = new LocalController();
		MetadataMocker.mockMetadataService(metadataServiceMock);
		
		ReflectionTestUtils.setField(localController, "metadataService", metadataServiceMock);

		responseStream = new ByteArrayOutputStream();
		ServletOutputStream servletOutputStream = new ServletOutputStream() {
			@Override
			public void write(int b) throws IOException {
				responseStream.write(b);
			}
		};
		when(response.getOutputStream()).thenReturn(servletOutputStream);

		responseParallelStream = new ByteArrayOutputStream();
		servletOutputStream = new ServletOutputStream() {
			@Override
			public void write(int b) throws IOException {
				responseParallelStream.write(b);
			}
		};
		when(responseParallel.getOutputStream()).thenReturn(servletOutputStream);

		QueryServiceConfiguration config = new QueryServiceConfiguration();
        ReflectionTestUtils.setField(config, "seedHosts", "xstm5346vdap.stm.swissbank.com:9160");
        ReflectionTestUtils.setField(config, "replicationFactor", 2);
        ReflectionTestUtils.setField(config, "distinctLimit", 5000);
        ReflectionTestUtils.setField(config, "readThreadCorePoolSize", 50);
        ReflectionTestUtils.setField(config, "readThreadMaxPoolSize", 50);
        ReflectionTestUtils.setField(config, "readThreadQueueSize", 100);
        ReflectionTestUtils.setField(config, "readBatchSize", 100);
        ReflectionTestUtils.setField(config, "cassandraPassword", "48a7110effe85572ce8be20290f5bc55");
        
		fileSystem = new HUFSFileSystem();

		testee = new CassandraFilter();
		testee.setStatsForTest(new Stats());
		ReflectionTestUtils.setField(testee, "metadataService", metadataServiceMock);
        ReflectionTestUtils.setField(testee, "cassandraWrapper", cassandraMock);
        ReflectionTestUtils.setField(testee, "queryServiceConfiguration", config);
		localController.setCassandraFilterCommand(testee);
		ReflectionTestUtils.setField(localController, "queryServiceConfiguration", config);
	}

	@After
	public void tearDown() {
		testee = null;
	}

	private void setupRequest(String filterURL) throws IOException {
		when(request.getParameterMap()).thenReturn(getRequestMap(filterURL));
		// Roles
		when(request.getHeader(Shared.HEADER_ROLE)).thenReturn("FILEGEN_CLIENT");
	}

	private HashMap<String, String[]> getRequestMap(String filterURL) {
		HashMap<String, String[]> requestMap = new HashMap<String, String[]>();
		if (filterURL != null) {
			Scanner urlScanner = new Scanner(filterURL);
			urlScanner.useDelimiter(Shared.URLPARAMSDELIMITER);
			while (urlScanner.hasNext()) {
				String parameterNameValue = urlScanner.next();
				int indexOfEqualOperator = parameterNameValue
						.indexOf(Shared.URLPARAMVALUEDELIMITER);
				String parameterName = null;
				String parameterValue = null;
				if (indexOfEqualOperator == -1) {
					indexOfEqualOperator = parameterNameValue.length() - 1;
					parameterName = parameterNameValue;
					parameterValue = StaticValues.BLANK;
				} else {
					parameterName = parameterNameValue.substring(0,
							indexOfEqualOperator);
					parameterValue = parameterNameValue
							.substring(indexOfEqualOperator + 1);
				}
				requestMap.put(parameterName, new String[] { parameterValue });
			}
			urlScanner.close();
		}
		return requestMap;
	}
	
	@Test
	public final void testPreventConcurrentFullTableScans() throws Throwable {
		
		when(metadataServiceMock.getDelimiter(anyString())).thenReturn("\t");
		
		Map<String, Integer> attributePositionsMap = new HashMap<String, Integer>();
		attributePositionsMap.put("issue.isin", 0);
		when(metadataServiceMock.getAttributePositionsForDataset(anyString())).thenReturn(attributePositionsMap);
		
		JoinRelation joinRelation = new JoinRelation();
		PhysicalDataset dataset = new PhysicalDataset();
		dataset.tableId = "BONDISSUE";
		dataset.id = "BONDISSUE";
		joinRelation.datasets.add(new JoinsRelationshipType(joinRelation, dataset, 0));
		List<JoinRelation> joinRelations = new ArrayList<JoinRelation>();
		joinRelations.add(joinRelation);
		when(metadataServiceMock.getJoinRelationsForDataset(anyString())).thenReturn(joinRelations);
		
		// Simulate long running full table scan
		String viewName = "InstrumentSecFunding";
		testee.nonIndexedQueryDataset = viewName;
		
		expectedException.expect(FilegenException.class);
		expectedException.expectMessage(Shared.NON_INDEXED_QUERY_IN_PROGRESS + viewName);

		// Concurrent Full table scan
		Map<String, String[]> parameterMap = new HashMap<String, String[]>();
		parameterMap.put("fields", new String[]{"issue.isin"});
		testee.execute(responseStream, parameterMap, new String[]{viewName});
	}
	
	@Test
	public final void testResetFlagOnFullTableScanException() throws Throwable {
		
		when(metadataServiceMock.getDelimiter(anyString())).thenReturn("\t");

		Map<String, Integer> attributePositionsMap = new HashMap<String, Integer>();
		attributePositionsMap.put("issue.isin", 0);
		when(metadataServiceMock.getAttributePositionsForDataset(anyString())).thenReturn(attributePositionsMap);

		JoinRelation joinRelation = new JoinRelation();
		PhysicalDataset dataset = new PhysicalDataset();
		dataset.tableId = "BONDISSUE";
		dataset.id = "BONDISSUE";
		joinRelation.datasets.add(new JoinsRelationshipType(joinRelation, dataset, 0));
		List<JoinRelation> joinRelations = new ArrayList<JoinRelation>();
		joinRelations.add(joinRelation);
		when(metadataServiceMock.getJoinRelationsForDataset(anyString())).thenReturn(joinRelations);
		
		Map<String, String[]> parameterMap = new HashMap<String, String[]>();

		// Simulate Full table scan exception
		ReflectionTestUtils.setField(testee, "cassandraWrapper", null);
		
		testee.nonIndexedQueryDataset = null; // reset any previous
		String dummyViewName = "InstrumentSecFunding";
		parameterMap.put("fields", new String[]{"issue.isin"});
		try {
			testee.execute(responseStream, parameterMap, new String[]{dummyViewName});
		}
		catch (Exception e) {
			// Do nothing
		}
		
		// Should reset after above exception
		assertNull(testee.nonIndexedQueryDataset);
	}
	
	@Test
	public final void testAllowLookupsDuringFullTableScan() throws Throwable {

		when(metadataServiceMock.getDelimiter(anyString())).thenReturn("\t");
		
		Map<String, Integer> attributePositionsMap = new HashMap<String, Integer>();
		attributePositionsMap.put("issue.isin", 0);
		when(metadataServiceMock.getAttributePositionsForDataset(anyString())).thenReturn(attributePositionsMap);
		
		JoinRelation joinRelation = new JoinRelation();
		PhysicalDataset dataset = new PhysicalDataset();
		dataset.tableId = "BONDISSUE";
		dataset.id = "BONDISSUE";
		joinRelation.datasets.add(new JoinsRelationshipType(joinRelation, dataset, 0));
		List<JoinRelation> joinRelations = new ArrayList<JoinRelation>();
		joinRelations.add(joinRelation);
		when(metadataServiceMock.getJoinRelationsForDataset(anyString())).thenReturn(joinRelations);
		
		Map<String, String[]> parameterMap = new HashMap<String, String[]>();

		// Full table scan
		testee.nonIndexedQueryDataset = null; // reset any previous
		String viewName = "InstrumentSecFunding";
		parameterMap.put("fields", new String[]{"issue.isin"});
		testee.execute(responseStream, parameterMap, new String[]{viewName});
		assertTrue(responseStream.toString().startsWith("issue.isin" + Shared.NEWLINE));
		
		// Lookup
		responseStream = new ByteArrayOutputStream();
		parameterMap.put("issue.isin", new String[]{"GB00B8W67662"});
		testee.execute(responseStream, parameterMap, new String[]{viewName});
		assertTrue(responseStream.toString().startsWith("issue.isin" + Shared.NEWLINE));
	}

	@Test
	public final void testNonIndexedQueriesMarkedFullTableScan() throws Throwable {
		
		when(metadataServiceMock.getDelimiter(anyString())).thenReturn("\t");
		
		Map<String, Integer> attributePositionsMap = new HashMap<String, Integer>();
		attributePositionsMap.put("issue.isin", 0);
		attributePositionsMap.put("issue.issueName", 1);
		when(metadataServiceMock.getAttributePositionsForDataset(anyString())).thenReturn(attributePositionsMap);
		
		List<String> attributes = new ArrayList<String>();
		attributes.add("issue.isin");
		attributes.add("issue.issueName");
		when(metadataServiceMock.getAttributeNamesForDataset(anyString())).thenReturn(attributes);
		
		JoinRelation joinRelation = new JoinRelation();
		PhysicalDataset dataset = new PhysicalDataset();
		dataset.tableId = "BONDISSUE";
		dataset.id = "BONDISSUE";
		joinRelation.datasets.add(new JoinsRelationshipType(joinRelation, dataset, 0));
		List<JoinRelation> joinRelations = new ArrayList<JoinRelation>();
		joinRelations.add(joinRelation);
		when(metadataServiceMock.getJoinRelationsForDataset(anyString())).thenReturn(joinRelations);
		
		// Simulate long running full table scan
		String viewName = "InstrumentSecFunding";
		testee.nonIndexedQueryDataset = viewName;

		expectedException.expect(FilegenException.class);
		expectedException.expectMessage(Shared.NON_INDEXED_QUERY_IN_PROGRESS + viewName);

		// Concurrent Non-indexed query = Full table scan
		Map<String, String[]> parameterMap = new HashMap<String, String[]>();
		parameterMap.put("fields", new String[]{"issue.isin"});
		parameterMap.put("issue.issueName", new String[]{"XYZ"}); // Non-indexed
		testee.execute(responseStream, parameterMap, new String[]{viewName});
	}

	// TODO fix mocking - no idea why this is now an issue 
//	@Test
	public final void testConditionalFilter() throws Throwable {
		
		when(metadataServiceMock.getDelimiter(anyString())).thenReturn("\t");
		
		Map<String, Integer> attributePositionsMap = new HashMap<String, Integer>();
		attributePositionsMap.put("issue.isin", 0);
		attributePositionsMap.put("derived.PrimaryListing", 1);
		when(metadataServiceMock.getAttributePositionsForDataset(anyString())).thenReturn(attributePositionsMap);
		
		// Union of EQUITY & BONDISSUE
		JoinRelation joinRelation1 = new JoinRelation();
		PhysicalDataset dataset1 = new PhysicalDataset();
		dataset1.tableId = "EQUITY.IDP";
		dataset1.id = "EQUITY.IDP";
		joinRelation1.datasets.add(new JoinsRelationshipType(joinRelation1, dataset1, 0));
		List<JoinRelation> joinRelations = new ArrayList<JoinRelation>();
		joinRelations.add(joinRelation1);

		JoinRelation joinRelation2 = new JoinRelation();
		PhysicalDataset dataset2 = new PhysicalDataset();
		dataset2.tableId = "BONDTL.IDP";
		dataset2.id = "BONDTL.IDP";
		joinRelation2.datasets.add(new JoinsRelationshipType(joinRelation2, dataset2, 0));
		joinRelations.add(joinRelation2);

		when(metadataServiceMock.getJoinRelationsForDataset(anyString())).thenReturn(joinRelations);

		final Map<Integer, String> filterPositionValueMapForEQUITY = new HashMap<Integer, String>();
		final Map<Integer, String> filterPositionValueMapForBONDTL = new HashMap<Integer, String>();
		
		// Intercept and track filters
		doAnswer(new Answer<Void>() {
			public Void answer(InvocationOnMock invocation) {
				try {
					Object[] args = invocation.getArguments();
					if(((List<PhysicalDataset>) args[1]).get(0).id.equals("EQUITY.IDP")) {
						filterPositionValueMapForEQUITY.putAll(((Map<Integer, String>) args[5]));
					} else if(((List<PhysicalDataset>) args[1]).get(0).id.equals("BONDTL.IDP")) {
						filterPositionValueMapForBONDTL.putAll(((Map<Integer, String>) args[5]));
					}
				} catch (Throwable e) {
					e.printStackTrace();
				}
				return null;
			}
		}).when(testee).filterFromCF((RequestParameters) any(),
				(List<PhysicalDataset>) any(),
				(int[]) any(),
				(int[]) any(),
				(Map<Integer, String>)any(),
				(Map<Integer, String>)any(),
				(Map<Integer, String>)any(),
				(int[]) any(),
				(ResponseFormatter) any(),
				(AtomicInteger) any());
		
		// Mock valid field positions
		doAnswer(new Answer<Integer>() {
			public Integer answer(InvocationOnMock invocation) {
				Object[] args = invocation.getArguments();
				if("issue.isin".equals((String) args[1])) {
					return 0;
				}
				else if("derived.PrimaryListing".equals((String) args[1])) {
					return 1;
				}
				return -1;
			}
		}).when(testee).getFieldPositionInJoinRelation((List<PhysicalDataset>) any(), (String) any());
		
		Map<String, String[]> parameterMap = new HashMap<String, String[]>();
		
		// Conditional filter applied only to EQUITY.IDP dataset
		String viewName = "InstrumentSecFunding";
		responseStream = new ByteArrayOutputStream();
		parameterMap.put("fields", new String[]{"issue.isin"});
		parameterMap.put("issue.isin", new String[]{"GB00B8W67662"});
		parameterMap.put("derived.PrimaryListing", new String[]{"(EQUITY.IDP)Y"}); // conditional filter
		testee.execute(responseStream, parameterMap, new String[]{viewName});
		assertTrue(responseStream.toString().startsWith("issue.isin" + Shared.NEWLINE));
		// ensure 2 execution for 2 datasets
		verify(testee, times(2)).filterFromCF((RequestParameters) any(),
				(List<PhysicalDataset>) any(),
				(int[]) any(),
				(int[]) any(),
				(Map<Integer, String>)any(),
				(Map<Integer, String>)any(),
				(Map<Integer, String>)any(),
				(int[]) any(),
				(ResponseFormatter) any(),
				(AtomicInteger) any());
		// Verify that conditional filter applied only to EQUITY.IDP dataset
		assertTrue(filterPositionValueMapForEQUITY.containsValue("Y"));
		assertTrue(!filterPositionValueMapForBONDTL.containsValue("Y"));
	}

	@Test
	public final void testIsMatchRowEqualsTrue() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"A","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "A,C,F");
		testFilterPositionOperatorMap.put(0,"=");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowEqualsFalse() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"A","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "G,C,F");
		testFilterPositionOperatorMap.put(0,"=");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowNotEqualsTrue() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"A","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "B");
		testFilterPositionOperatorMap.put(0,"=not:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowNotEqualsFalse() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"A","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "A,AA,AAA");
		testFilterPositionOperatorMap.put(0,"=not:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowLessThanTrue() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"A","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "Z");
		testFilterPositionOperatorMap.put(0,"=lt:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowLessThanFalse() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"F","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "A");
		testFilterPositionOperatorMap.put(0,"=lt:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowNullTrue() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"ARARGE03E113","88.991","87.299",""};
		testFilterPositionValueMap.put(3, "");
		testFilterPositionOperatorMap.put(3,"=");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	
	@Test
	public final void testIsMatchRowNotNullTrue() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"ARARGE03E113","88.991","87.299","PSBB"};
		testFilterPositionValueMap.put(2, "");
		testFilterPositionOperatorMap.put(2,"=not:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowGreaterThanTrue() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"F","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "A");
		testFilterPositionOperatorMap.put(0,"=gt:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowGreaterThanFalse() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"F","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "Z");
		testFilterPositionOperatorMap.put(0,"=gt:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowLessThanEqualsTrue1() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"F","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "Z");
		testFilterPositionOperatorMap.put(0,"=lte:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowLessThanEqualsTrue2() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"F","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "F");
		testFilterPositionOperatorMap.put(0,"=lte:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowLessThanEqualsFalse() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"F","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "a");
		testFilterPositionOperatorMap.put(0,"=lte:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowGreaterThanEqualsTrue1() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"F","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "F");
		testFilterPositionOperatorMap.put(0,"=gte:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowGreaterThanEqualsTrue2() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"F","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "E");
		testFilterPositionOperatorMap.put(0,"=gte:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowGreaterThanEqualsFalse() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"F","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0,"G");
		testFilterPositionOperatorMap.put(0,"=gte:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowLikeTrue() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"EQUITY","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0,".*ITY");
		testFilterPositionOperatorMap.put(0,"=like:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowLikeFalse() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"EQUITY","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0,".*OND");
		testFilterPositionOperatorMap.put(0,"=like:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowBetweenTrue1() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"G","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0,"A,H");
		testFilterPositionOperatorMap.put(0,"=between:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowBetweenTrue2() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"G","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0,"G,H");
		testFilterPositionOperatorMap.put(0,"=between:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowBetweenTrue3() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"G","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0,"A,G");
		testFilterPositionOperatorMap.put(0,"=between:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowbetweenFalse1() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"G","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0,"A,C");
		testFilterPositionOperatorMap.put(0,"=between:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchRowbetweenFalse2() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"G","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0,"H,L");
		testFilterPositionOperatorMap.put(0,"=between:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchGreaterEqualLikeTrue() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"G","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "B");
		testFilterPositionOperatorMap.put(0, "=gt:");
		testFilterPositionValueMap.put(1,"AA");
		testFilterPositionOperatorMap.put(1,"=");
		testFilterPositionValueMap.put(2,".*AA");
		testFilterPositionOperatorMap.put(2, "=like:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchGreaterEqualLikeFalse1() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"G","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "H");
		testFilterPositionOperatorMap.put(0, "=gt:");
		testFilterPositionValueMap.put(1,"AA");
		testFilterPositionOperatorMap.put(1,"=");
		testFilterPositionValueMap.put(2,".*AA");
		testFilterPositionOperatorMap.put(2, "=like:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchGreaterEqualLikeFalse2() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"G","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "B");
		testFilterPositionOperatorMap.put(0, "=gt:");
		testFilterPositionValueMap.put(1,"BB");
		testFilterPositionOperatorMap.put(1,"=");
		testFilterPositionValueMap.put(2,".*AA");
		testFilterPositionOperatorMap.put(2, "=like:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchGreaterEqualLikeFalse3() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"G","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "B");
		testFilterPositionOperatorMap.put(0, "=gt:");
		testFilterPositionValueMap.put(1,"AA");
		testFilterPositionOperatorMap.put(1,"=");
		testFilterPositionValueMap.put(2,".*AZ");
		testFilterPositionOperatorMap.put(2, "=like:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchLessNotBetweenTrue() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"G","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "Z");
		testFilterPositionOperatorMap.put(0, "=lt:");
		testFilterPositionValueMap.put(1,"BA");
		testFilterPositionOperatorMap.put(1,"=not:");
		testFilterPositionValueMap.put(2,".*AAA");
		testFilterPositionOperatorMap.put(2, "=like:");
		try {
			assertTrue(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchLessNotBetweenFalse1() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"T","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "A");
		testFilterPositionOperatorMap.put(0, "=lt:");
		testFilterPositionValueMap.put(1,"BA");
		testFilterPositionOperatorMap.put(1,"=not:");
		testFilterPositionValueMap.put(2,".*AAA");
		testFilterPositionOperatorMap.put(2, "=like:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchLessNotBetweenFalse2() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"G","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "Z");
		testFilterPositionOperatorMap.put(0, "=lt:");
		testFilterPositionValueMap.put(1,"AA");
		testFilterPositionOperatorMap.put(1,"=not:");
		testFilterPositionValueMap.put(2,".*AAA");
		testFilterPositionOperatorMap.put(2, "=like:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testIsMatchLessNotBetweenFalse3() {
		CassandraFilter cft = new CassandraFilter();
		Map<Integer, String> testFilterPositionValueMap = new HashMap<Integer, String>();
		Map<Integer, String> testFilterPositionOperatorMap = new HashMap<Integer, String>();
		String[] rowArray = new String[]{"G","AA","AAA","AAAA"};
		testFilterPositionValueMap.put(0, "Z");
		testFilterPositionOperatorMap.put(0, "=lt:");
		testFilterPositionValueMap.put(1,"AHK");
		testFilterPositionOperatorMap.put(1,"=not:");
		testFilterPositionValueMap.put(2,".*ABC");
		testFilterPositionOperatorMap.put(2, "=like:");
		try {
			assertFalse(cft.isMatchRow(testFilterPositionValueMap,testFilterPositionOperatorMap, rowArray));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(expected = FilegenException.class)
	public final void testExecuteInvalidField() throws Throwable {
		String viewName = "FFBONDTL";
		String filterURL = "xyz=US9127956W63";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
	}

	@Test
	public final void testFindJoinableDatasets() throws Exception {
		RequestParameters requestParameters = new RequestParameters();
		requestParameters.setFilterIds(new ArrayList<String>());
		requestParameters.setFields(new String[0]);
		AtomicInteger readRowCount = new AtomicInteger();
		// MTS.IDP_BONDISSUE.IDP_LEGALENTITY.LEM
		JoinRelation joinRelation = Mockito.mock(JoinRelation.class);
		List<PhysicalDataset> physicalDatasets = new ArrayList<PhysicalDataset>();
		PhysicalDataset physicalDataset = new PhysicalDataset();
		physicalDataset.id = "MTS.IDP";
		physicalDataset.tableId = "MTS";
		physicalDatasets.add(physicalDataset);
		
		physicalDataset = new PhysicalDataset();
		physicalDataset.id = "BONDISSUE.IDP";
		physicalDataset.tableId = "BONDISSUE";
		physicalDatasets.add(physicalDataset);
		
		physicalDataset = new PhysicalDataset();
		physicalDataset.id = "LEGALENTITY.LEM";
		physicalDataset.tableId = "LEGALENTITY";
		physicalDatasets.add(physicalDataset);
		
		when(joinRelation.getOrderedDatasets()).thenReturn(physicalDatasets);
		
		when(metadataServiceMock.getJoinKeysForDatasetIds("MTS.IDP","BONDISSUE.IDP")).thenReturn(Arrays.asList("issue.cusip","issue.cusip"));
		when(metadataServiceMock.getJoinKeysForDatasetIds("MTS.IDP","LEGALENTITY.LEM")).thenThrow(new MetadataException("Failed to find any attributes joined between dataset with id=MTS.IDP and dataset with id=LEGALENTITY.LEM"));
		when(metadataServiceMock.getJoinKeysForDatasetIds("BONDISSUE.IDP","LEGALENTITY.LEM")).thenReturn(Arrays.asList("issuer.ubsPartyId","PARTY_ID"));

		when(metadataServiceMock.getDatasetKeyAttributePositions("MTS.IDP")).thenReturn(Arrays.asList(0));
		when(metadataServiceMock.getDatasetKeyAttributePositions("BONDISSUE.IDP")).thenReturn(Arrays.asList(124));
		when(metadataServiceMock.getDatasetKeyAttributePositions("LEGALENTITY.LEM")).thenReturn(Arrays.asList(0));

		List<String> dummyAttibutesList = new ArrayList<String>();
		for(int i = 0; i < 58; i++) {
			dummyAttibutesList.add("dummyAttribute"+ i);
		}
		when(metadataServiceMock.getAttributeNamesForDataset("MTS.IDP")).thenReturn(dummyAttibutesList);
		
		dummyAttibutesList = new ArrayList<String>();
		for(int i = 0; i < 366; i++) {
			dummyAttibutesList.add("dummyAttribute"+ i);
		}
		when(metadataServiceMock.getAttributeNamesForDataset("BONDISSUE.IDP")).thenReturn(dummyAttibutesList);
		
		dummyAttibutesList = new ArrayList<String>();
		for(int i = 0; i < 21; i++) {
			dummyAttibutesList.add("dummyAttribute"+ i);
		}
		when(metadataServiceMock.getAttributeNamesForDataset("LEGALENTITY.LEM")).thenReturn(dummyAttibutesList);

		Map<String, Integer> attributePositionsForDataset = new HashMap<String, Integer>();
		attributePositionsForDataset.put("issue.cusip", 2);
		when(metadataServiceMock.getAttributePositionsForDataset("MTS.IDP")).thenReturn(attributePositionsForDataset);
		
		attributePositionsForDataset = new HashMap<String, Integer>();
		attributePositionsForDataset.put("issue.cusip", 76);
		attributePositionsForDataset.put("issuer.ubsPartyId", 227);
		when(metadataServiceMock.getAttributePositionsForDataset("BONDISSUE.IDP")).thenReturn(attributePositionsForDataset);

		attributePositionsForDataset = new HashMap<String, Integer>();
		attributePositionsForDataset.put("PARTY_ID", 0);
		when(metadataServiceMock.getAttributePositionsForDataset("LEGALENTITY.LEM")).thenReturn(attributePositionsForDataset);

		int[] expectedLeftJoinAttributePositions = {-1, 2, 285};
        int[] expectedRightReverseIndexPositions = {-1, 76, -1};

		final CassandraFilter spyTestClass = spy(testee);
		spyTestClass.processJoinFile(requestParameters, joinRelation, readRowCount, null);
		// ensure BONDISSUE.IDP and LEGALENTITY.LEM join is picked up by checking expected values e.g. 285 = 58 (MTS.IDP offset) + 227 (issuer.ubsPartyId position)
		verify(spyTestClass, times(1)).filterFromCF((RequestParameters) any(),
				(List<PhysicalDataset>) any(),
				Matchers.eq(expectedLeftJoinAttributePositions),
				Matchers.eq(expectedRightReverseIndexPositions),
				(Map<Integer, String>)any(),
				(Map<Integer, String>)any(),
				(Map<Integer, String>)any(),
				(int[]) any(),
				(ResponseFormatter) any(),
				(AtomicInteger) any());
	}

	@Test
	@Ignore
	// TODO Integration tests
	public final void testExecuteRTIMINST() throws Throwable {
		String viewName = "RTIMINST";
		String filterURL = "issue.isin=XS0592582653";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
		System.out.println(responseStream.toString());
		String expectedHeaderRow = "tL.countryUbsId|issue.lastUpdatedTime|"
				+ "issue.majorVersion|issue.active|issue.status|issue.isoCfi|issue.assetClass|"
				+ "issue.assetType|issue.securityType|issue.cusip|issue.common|issue.isin|"
				+ "issue.valoren|issue.wertpapier|issue.nominalCurrency|issue.cins|"
				+ "issue.nominalValueOfUnit|issue.ubsTradable|issue.issueName|issue.shortName|"
				+ "issue.hasListing|issue.ubsIsoCfi|issue.expiryDate|issue.ubsId|"
				+ "issuer.lastUpdatedTime|issuer.majorVersion|issuer.issuerName|"
				+ "issuer.countryOfIncorporation|issuer.cconsol|issuer.bbCompany|issuer.icbIndustry|"
				+ "issuer.icbSector|issuer.icbSubsector|issuer.icbSupersector|issuer.fidbCode|"
				+ "issuer.countryOfDomicile|issuer.ubsPartyId|bond.majorVersion|"
				+ "bond.maturityDate|undl.tlUbsId|undl.issueUbsId|undl.assetClass|undl.isoCfi|"
				+ "undl.majorVersion|event.majorVersion|event.lastUpdatedTime|ISSUE_UBSID|CBE_FED|"
				+ "CBE_FED_HC_PCT|CBE_SNB|CBE_SNB_HC_PCT|CBE_ECB|CBE_ECB_HC_PCT|CBE_BOE|"
				+ "CBE_BOE_HC_PCT|CBE_BOJ|CBE_BOJ_HC_PCT|FED_REPORTING_LINE|FINMA_GROUP";
		assertTrue(responseStream.toString().startsWith(
				expectedHeaderRow + Shared.NEWLINE));
		// Ensure no jagged rows
		String delimiter = "|";
		int expectedDelimiterCount = StringUtils.countMatches(
				expectedHeaderRow, delimiter);
		Scanner lineScanner = new Scanner(responseStream.toString());
		lineScanner.useDelimiter(Shared.NEWLINE);
		while (lineScanner.hasNext()) {
			assertEquals(
					StringUtils.countMatches(lineScanner.next(), delimiter),
					expectedDelimiterCount);
		}
		lineScanner.close();
	}

	@Test
	@Ignore
	// TODO Integration tests
	public final void testExecuteDirectSource() throws Throwable {
		String viewName = "FFBONDISSUE";
		String filterURL = "issue.ubsId=14188686&fields=issue.ubsId,issue.isin";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
		System.out.println(responseStream.toString());
		String expectedHeaderRow = "issue.ubsId	issue.isin";
		assertTrue(responseStream.toString().startsWith(
				expectedHeaderRow + Shared.NEWLINE));
		// Ensure no jagged rows
		String delimiter = "\t";
		int expectedDelimiterCount = StringUtils.countMatches(
				expectedHeaderRow, "\t");
		Scanner lineScanner = new Scanner(responseStream.toString());
		lineScanner.useDelimiter(Shared.NEWLINE);
		while (lineScanner.hasNext()) {
			assertEquals(
					StringUtils.countMatches(lineScanner.next(), delimiter),
					expectedDelimiterCount);
		}
		lineScanner.close();
	}

	@Test
	@Ignore
	// TODO Integration tests
	public final void testExecuteSapphireUnion() throws Throwable {
		String viewName = "sapphire";
		String filterURL = "tL.exchange=A";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
		String expectedHeaderRow = "tL.quick|issue.isoCfi|tL.exchange|tL.status|SYSDATE|issue.isin|tL.ric|tL.sedol|"
				+ "tL.tradingLineName|tL.ricOfIntInd|issue.tseIndustryCode|stopLow.price|"
				+ "stopHigh.price|tL.roundLotSize|base.price|issue.amountOutstanding|"
				+ "tL.maxTradableLot|marketCapitalization.price|adv5.date|adv20.value|adv90.value|"
				+ "issue.ubsUniqueDescription|tL.ubsId|issue.ubsId|bond.minimumTradeSize";
		assertTrue(responseStream.toString().startsWith(
				expectedHeaderRow + Shared.NEWLINE));
		// Ensure no jagged rows
		String delimiter = "|";
		int expectedDelimiterCount = StringUtils.countMatches(
				expectedHeaderRow, delimiter);
		Scanner lineScanner = new Scanner(responseStream.toString());
		lineScanner.useDelimiter(Shared.NEWLINE);
		while (lineScanner.hasNext()) {
			assertEquals(
					StringUtils.countMatches(lineScanner.next(), delimiter),
					expectedDelimiterCount);
		}
		lineScanner.close();
	}

	@Test
	@Ignore
	// TODO Integration tests
	public final void testExecuteParallelRequests() throws Throwable {
		String viewName = "BookFull";
		String filterURL = "format=JSONARRAY&fields=BookName,IDP_STATUS,BookId&BookName=REPO4C,4CPSWP,REPO3C,CORPTP,A4012H";

//		final CassandraFilter spyTestClass = spy(testClass);
		final CassandraFilter spyTestClass = spy(testee);
		// spyTestClass.setFilePath(Shared.BLANK);
		localController.setCassandraFilterCommand(spyTestClass);

		// Intercept with a Parallel request
		final String parallelViewName = "INST";
		String parallelFilterURL = "format=JSONARRAY&fields=IDP_STATUS,issue.isin,issue.ubsId,tL.countryUbsId&issue.isin=US912828QC79,US00084DAE04,xyz";

		// Parallel parameter maps
		when(request.getParameterMap()).thenReturn(getRequestMap(filterURL))
				.thenReturn(getRequestMap(parallelFilterURL));
		// Roles
		when(request.getHeader(Shared.HEADER_ROLE))
				.thenReturn("FILEGEN_CLIENT");

		doAnswer(new Answer<Void>() {
			public Void answer(InvocationOnMock invocation) {
				try {
					// Parallel request
					localController.filter(request, parallelViewName,
							responseParallel);
					// then continue execution
					invocation.callRealMethod();
				} catch (Throwable e) {
					e.printStackTrace();
				}
				return null;
			}
		}).when(spyTestClass).processJoinFile((RequestParameters) any(),
				(JoinRelation) any(), (AtomicInteger) any(), (ResponseFormatter) any());

		// Main request
		localController.filter(request, viewName, response);

		verify(spyTestClass, times(2)).processJoinFile(
				(RequestParameters) any(), (JoinRelation) any(),
				(AtomicInteger) any(),
				(ResponseFormatter) any());

		// Check main
		Scanner lineScanner = new Scanner(responseStream.toString());
		lineScanner.useDelimiter(Shared.NEWLINE);
		assertTrue(lineScanner.next().startsWith("["));
		// Ensure no jagged rows
		String delimiter = ",\"";
		int expectedDelimiterCount = 2;
		String line = null;
		while (lineScanner.hasNext()) {
			line = lineScanner.next();
			if (!lineScanner.hasNext()) { // Skip last line
				break;
			}
			assertEquals(expectedDelimiterCount,
					StringUtils.countMatches(line, delimiter));
		}
		lineScanner.close();
		// Check last line - array end
		assertTrue(line.equals("]"));

		// Check parallel
		lineScanner = new Scanner(responseParallelStream.toString());
		lineScanner.useDelimiter(Shared.NEWLINE);
		assertTrue(lineScanner.next().startsWith("["));
		// Ensure no jagged rows
		delimiter = ",\"";
		expectedDelimiterCount = 3;
		while (lineScanner.hasNext()) {
			line = lineScanner.next();
			if (!lineScanner.hasNext()) { // Skip last line
				break;
			}
			assertEquals(expectedDelimiterCount,
					StringUtils.countMatches(line, delimiter));
		}
		lineScanner.close();
		// Check last line - array end
		assertTrue(line.equals("]"));
	}

	@Test
	public final void testExecuteCSVWriter() throws Throwable {
		String viewName = "sapphire";
		String filterURL = "tL.exchange=A&escape='";
		setupRequest(filterURL);
		// mock index CF
		when(hcolumnIndex.getName()).thenReturn("1");
		when(columnSliceIterator.next()).thenReturn(hcolumnIndex);
		when(columnSliceIterator.hasNext()).thenReturn(true).thenReturn(false);
		when(cassandraMock.createColumnSliceIterator(Matchers.anyString(),
						Matchers.anyString(), Matchers.anyString(),
						Matchers.anyString(), Matchers.anyInt())).thenAnswer(
				new Answer<ColumnSliceIterator<String, String, String>>() {
					public ColumnSliceIterator<String, String, String> answer(
							InvocationOnMock invocation) throws Throwable {
						return columnSliceIterator;
					}
				});
		// mock main CF
		when(hcolumnMain1.getValue()).thenReturn(
				TEST_DATA_FILE.getString("EQUITY_ESCAPE"));
		when(columnSlice.getColumnByName("EQUITY")).thenReturn(hcolumnMain1);
		when(row.getColumnSlice()).thenReturn(columnSlice);
		when(rows.getByKey(Matchers.anyString())).thenReturn(row);
		when(multigetQueryResult.get()).thenReturn(rows);
		when(cassandraMock.executeMultigetSliceQuery(Matchers.anyString(),
						Matchers.anyString(), Matchers.any(String[].class)))
				.thenAnswer(
						new Answer<QueryResult<Rows<String, String, String>>>() {
							public QueryResult<Rows<String, String, String>> answer(
									InvocationOnMock invocation)
									throws Throwable {
								return multigetQueryResult;
							}
						});
//		when(cassandraClientFactory.getInstance()).thenReturn(cassandraMock);
//		localController.setCassandraClientFactory(cassandraClientFactory);

		localController.filter(request, viewName, response);
		String expectedHeaderRow = "tL.quick|issue.isoCfi|tL.exchange|tL.status|SYSDATE|issue.isin|tL.ric|tL.sedol|"
				+ "tL.tradingLineName|tL.ricOfIntInd|issue.tseIndustryCode|stopLow.price|"
				+ "stopHigh.price|tL.roundLotSize|base.price|issue.amountOutstanding|"
				+ "tL.maxTradableLot|marketCapitalization.price|adv5.date|adv20.value|adv90.value|"
				+ "issue.ubsUniqueDescription|tL.ubsId|issue.ubsId|bond.minimumTradeSize";
		
		String receivedHeader = responseStream.toString().split("\n")[0];
		
		assertEquals("Header incorrect",expectedHeaderRow,receivedHeader);
		// Ensure no jagged rows
		String delimiter = "|";
		int expectedDelimiterCount = StringUtils.countMatches(
				expectedHeaderRow, delimiter);
		Scanner lineScanner = new Scanner(responseStream.toString());
		lineScanner.useDelimiter(Shared.NEWLINE);
		while (lineScanner.hasNext()) {
			assertEquals(
					StringUtils.countMatches(lineScanner.next(), delimiter),
					expectedDelimiterCount);
		}
		lineScanner.close();
	}

	@Test(expected = FilegenException.class)
	public final void testExecuteInvalidFieldJSON() throws Throwable {
		String viewName = "RTIMINST";
		String filterURL = "issue.currency=USD&fields=issue.ubsId,tL.countryUbsId&format=JSON";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
	}

	@Test(expected = FilegenException.class)
	public final void testExecuteInvalidFormat() throws Throwable {
		String viewName = "RTIMINST";
		String filterURL = "issue.currency=USD&fields=issue.ubsId,tL.countryUbsId&format=yyy";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
	}

	@Test(expected = FilegenException.class)
	public final void testExecuteInvalidView() throws Throwable {
		String viewName = "xyz";
		String filterURL = "tL.exchange=UJP1&issue.status=ACTIVE&fields=tL.active,tL.exchange";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
	}

	@Test
	public final void testExecuteFormatJSON() throws Throwable {
		String viewName = "RTIMINST";
		String filterURL = "fields=IDP_STATUS,issue.isin,issue.ubsId,tL.countryUbsId&issue.isin=US912828QC79,US00084DAE04,xyz&format=JSON";
		setupRequest(filterURL);

		// Mock Cassandra Data
		mockCassandra("FFBONDISSUE", new String[] { "FFBONDISSUE1",
				"FFBONDISSUE2" }, "RTIM", new String[] { "RTIM" },
				new String[] { "1", "2" }, new boolean[] { true, false, false,
						true, false, false, false });

		ReflectionTestUtils.setField(testee, "cassandraWrapper", cassandraMock);
		
		localController.filter(request, viewName, response);
		System.out.println(responseStream.toString());
		// Ensure no jagged rows
		String delimiter = ",";
		int expectedDelimiterCount = 3;
		Scanner lineScanner = new Scanner(responseStream.toString());
		lineScanner.useDelimiter(Shared.NEWLINE);
		while (lineScanner.hasNext()) {
			String line = lineScanner.next();
			// Delimiter count
			assertEquals(expectedDelimiterCount,
					StringUtils.countMatches(line, delimiter));
			// JSON format
			assertTrue(line.startsWith("{\""));
			assertTrue(line.endsWith("}"));
		}
		lineScanner.close();

		// Check unmatched ID
		assertTrue(responseStream.toString().contains(
				"\"IDP_STATUS\":\"ERROR\""));
	}

	@Test
	public final void testExecuteFormatJSONArray() throws Throwable {
		String viewName = "RTIMINST";
		String filterURL = "fields=IDP_STATUS,issue.isin,issue.ubsId,tL.countryUbsId&issue.isin=US912828QC79,US00084DAE04,xyz&format=JSONARRAY";
		setupRequest(filterURL);

		// Mock Cassandra Data
		boolean[] columnSliceIteratorHasNextValues = new boolean[7];
		columnSliceIteratorHasNextValues[0] = true;
		columnSliceIteratorHasNextValues[3] = true;
		mockCassandra("FFBONDISSUE", new String[] { "FFBONDISSUE1",
				"FFBONDISSUE2" }, "RTIM", new String[] { "RTIM" },
				new String[] { "1", "2" }, new boolean[] { true, false, false,
						true, false, false, false });

		localController.filter(request, viewName, response);
		System.out.println(responseStream.toString());

		Scanner lineScanner = new Scanner(responseStream.toString());
		lineScanner.useDelimiter(Shared.NEWLINE);

		// Check first line - array start
		assertTrue(lineScanner.next().equals("["));

		// Ensure JSONARRAY
		String delimiter = ",";
		String line = lineScanner.next();
		assertTrue(line.startsWith("{\"") && line.endsWith("},")
				&& StringUtils.countMatches(line, delimiter) == 4);
		line = lineScanner.next();
		assertTrue(line.startsWith("{\"") && line.endsWith("},")
				&& StringUtils.countMatches(line, delimiter) == 4);
		line = lineScanner.next();
		assertTrue(line.startsWith("{\"") && line.endsWith("}")
				&& StringUtils.countMatches(line, delimiter) == 3);

		// Check last line - array end
		assertTrue(lineScanner.next().equals("]"));
		lineScanner.close();

		// Check unmatched ID
		assertTrue(responseStream.toString().contains(
				"\"IDP_STATUS\":\"ERROR\""));
	}

	@Test
	public final void testExecuteRTIMEQUITY() throws Throwable {
		String viewName = "RTIMEQUITY";
		String filterURL = "ISSUE_UBSID=15867890,10836138";
		setupRequest(filterURL);

		// Mock Cassandra Data
		Map<String, List<HColumn<String, String>>> cfNameKeyColumnsMap = new HashMap<String, List<HColumn<String, String>>>();
		// RTIM rows
		mockColumn(cfNameKeyColumnsMap, "RTIM", "15867890", "RTIM");
		mockColumn(cfNameKeyColumnsMap, "RTIM_0", "15867890", "15867890");

		mockColumn(cfNameKeyColumnsMap, "RTIM", "10836138", "RTIM");
		mockColumn(cfNameKeyColumnsMap, "RTIM_0", "10836138", "10836138");

		// EQUITY no match
		mockColumn(cfNameKeyColumnsMap, "EQUITY_96", "15867890", null);

		// EQUITY rows
		mockColumn(cfNameKeyColumnsMap, "EQUITY", "0001071020", "EQUITY");
		mockColumn(cfNameKeyColumnsMap, "EQUITY_96", "10836138", "0001071020");

		mockColumn(cfNameKeyColumnsMap, "EQUITY", "0001551010", "EQUITY");
		mockColumn(cfNameKeyColumnsMap, "EQUITY_96", "10836138", "0001551010");

		mockColumn(cfNameKeyColumnsMap, "EQUITY", "0001550335", "EQUITY");
		mockColumn(cfNameKeyColumnsMap, "EQUITY_96", "10836138", "0001550335");

		mockCassandraAll(cfNameKeyColumnsMap);

		localController.filter(request, viewName, response);
		System.out.println(responseStream.toString());

		String expectedHeaderRow = "ISSUE_UBSID	CBE_FED	CBE_FED_HC_PCT	CBE_SNB	CBE_SNB_HC_PCT	CBE_ECB	CBE_ECB_HC_PCT	"
				+ "CBE_BOE	CBE_BOE_HC_PCT	CBE_BOJ	CBE_BOJ_HC_PCT	FED_REPORTING_LINE	"
				+ "FINMA_GROUP	issue.issueDate	issue.cusip	issue.isin	issue.ubsId	tL.ubsId";
		Scanner lineScanner = new Scanner(responseStream.toString());
		lineScanner.useDelimiter(Shared.NEWLINE);
		String line = lineScanner.next();
		assertEquals(expectedHeaderRow,line);
		// Ensure no jagged rows
		String delimiter = "\t";
		int expectedDelimiterCount = StringUtils.countMatches(
				expectedHeaderRow, delimiter);
		List<String> expectedRows = Arrays
				.asList(new String[] {
						"15867890	Y	0.1091	N	1	N	1	Y	0.011	N	1	9.1 Treasuries/Agency Debt	5b06					",
						"10836138	N	0	N	0	N	0	N	0	N	0	9.3 Investment Grade Bonds	5b04	-9999	74270F104	US74270F1049	10836138	0001071020",
						"10836138	N	0	N	0	N	0	N	0	N	0	9.3 Investment Grade Bonds	5b04	-9999	74270F104	US74270F1049	10836138	0001551010",
						"10836138	N	0	N	0	N	0	N	0	N	0	9.3 Investment Grade Bonds	5b04	-9999	74270F104	US74270F1049	10836138	0001550335" });
		while (lineScanner.hasNext()) {
			line = lineScanner.next();
			assertEquals(StringUtils.countMatches(line, delimiter),
					expectedDelimiterCount);
			assertTrue(expectedRows.contains(line));
		}
		lineScanner.close();
	}

	private void mockColumn(
			Map<String, List<HColumn<String, String>>> cfNameKeyColumnsMap,
			String cf, String key, String columnName) {
		String cfNameKey = cf + "." + key;
		List<HColumn<String, String>> columnList = cfNameKeyColumnsMap
				.get(cfNameKey);
		// Create if list doesn't exist
		if (columnList == null) {
			columnList = new ArrayList<HColumn<String, String>>();
		}
		// null columnName means empty iterator
		if (columnName != null) {
			columnList.add(new MockColumn(columnName, TEST_DATA_FILE
					.getString(cfNameKey)));
		}
		cfNameKeyColumnsMap.put(cfNameKey, columnList);
	}

	private void mockCassandraAll(
			Map<String, List<HColumn<String, String>>> cfNameKeyColumnsMap)
			throws Exception {
		// cf specific mockRows
		Map<String, Rows<String, String, String>> cfMockRows = new HashMap<String, Rows<String, String, String>>();

		for (String cfNameKey : cfNameKeyColumnsMap.keySet()) {
			// createColumnSliceIterator
			final ColumnSliceIterator<String, String, String> mockColumnSliceIterator = Mockito
					.mock(ColumnSliceIterator.class);

			List<HColumn<String, String>> list = cfNameKeyColumnsMap
					.get(cfNameKey);
			final Iterator<HColumn<String, String>> iterator = list.iterator();
			when(mockColumnSliceIterator.hasNext()).thenAnswer(
					new Answer<Boolean>() {
						public Boolean answer(InvocationOnMock invocation)
								throws Throwable {
							return iterator.hasNext();
						}
					});

			when(mockColumnSliceIterator.next()).thenAnswer(
					new Answer<HColumn<String, String>>() {
						@Override
						public HColumn<String, String> answer(
								InvocationOnMock invocation) throws Throwable {
							// TODO Auto-generated method stub
							return iterator.next();
						}
					});

			// RTIM.15867890
			String cfName = cfNameKey.substring(0, cfNameKey.indexOf('.'));
			String key = cfNameKey.substring(cfNameKey.indexOf('.') + 1);
			when(
					cassandraMock.createColumnSliceIterator(Matchers.eq(cfName),
							Matchers.eq(key), Matchers.anyString(),
							Matchers.anyString(), Matchers.anyInt()))
					.thenReturn(mockColumnSliceIterator);

			// cf specific mockRows
			Rows<String, String, String> mockRows = cfMockRows.get(cfName);
			if (mockRows == null) {
				QueryResult<Rows<String, String, String>> mockMultigetQueryResult = Mockito
						.mock(QueryResult.class);
				when(
						cassandraMock.executeMultigetSliceQuery(
								Matchers.eq(cfName), Matchers.eq(cfName),
								Matchers.any(String[].class))).thenReturn(
						mockMultigetQueryResult);

				mockRows = Mockito.mock(Rows.class);
				when(mockMultigetQueryResult.get()).thenReturn(mockRows);
				cfMockRows.put(cfName, mockRows);
			}

			Row<String, String, String> mockRow = Mockito.mock(Row.class);
			// mock separate getByKey
			when(mockRows.getByKey(Matchers.eq(key))).thenReturn(mockRow);
			ColumnSlice<String, String> mockColumnSlice = Mockito
					.mock(ColumnSlice.class);
			when(mockRow.getColumnSlice()).thenReturn(mockColumnSlice);
			// 1st column TODO mock all columns
			if (list.size() > 0) {
				HColumn<String, String> column = list.get(0);
				String columnName = column.getName();
				when(mockColumnSlice.getColumnByName(Matchers.eq(columnName)))
						.thenReturn(column);
			}
		}

		when(
				cassandraMock.executeColumnSliceQuery(Matchers.anyString(),
						Matchers.anyString(), Matchers.anyString())).then(
				new Answer<ColumnSlice<String, String>>() {
					@Override
					public ColumnSlice<String, String> answer(
							InvocationOnMock invocation) throws Throwable {
						return null;
					}

				});
//		when(cassandraClientFactory.getInstance()).thenReturn(cassandraMock);
//		localController.setCassandraClientFactory(cassandraClientFactory);
	}

	class MockColumn implements HColumn<String, String> {
		String name;
		String value;

		public MockColumn(String name, String value) {
			this.name = name;
			this.value = value;
		}

		@Override
		public HColumn<String, String> setName(String name) {
			return null;
		}

		@Override
		public HColumn<String, String> setValue(String value) {
			return null;
		}

		@Override
		public String getName() {
			return name;
		}

		@Override
		public String getValue() {
			return value;
		}

		@Override
		public ByteBuffer getValueBytes() {
			return null;
		}

		@Override
		public ByteBuffer getNameBytes() {
			return null;
		}

		@Override
		public long getClock() {
			return 0;
		}

		@Override
		public HColumn<String, String> setClock(long clock) {
			return null;
		}

		@Override
		public int getTtl() {
			return 0;
		}

		@Override
		public HColumn<String, String> setTtl(int ttl) {
			return null;
		}

		@Override
		public HColumn<String, String> clear() {
			return null;
		}

		@Override
		public HColumn<String, String> apply(String value, long clock, int ttl) {
			return null;
		}

		@Override
		public Serializer<String> getNameSerializer() {
			return null;
		}

		@Override
		public Serializer<String> getValueSerializer() {
			return null;
		}

	}

	private void mockCassandra(String leftCF, String[] leftRows,
			String rightCF, String[] righttRows, String[] columnNames,
			boolean[] columnSliceIteratorHasNextValues) throws Exception {
		// mock index CF
		OngoingStubbing<String> stubbingColumn = when(hcolumnIndex.getName());
		for (String columnName : columnNames) {
			stubbingColumn = stubbingColumn.thenReturn(columnName);
		}
		when(columnSliceIterator.next()).thenReturn(hcolumnIndex);

		OngoingStubbing<Boolean> stubbingIterator = when(columnSliceIterator
				.hasNext());
		for (boolean columnSliceIteratorHasNextValue : columnSliceIteratorHasNextValues) {
			stubbingIterator = stubbingIterator
					.thenReturn(columnSliceIteratorHasNextValue);
		}

		when(cassandraMock.createColumnSliceIterator(Matchers.anyString(),
						Matchers.anyString(), Matchers.anyString(),
						Matchers.anyString(), Matchers.anyInt())).thenAnswer(
				new Answer<ColumnSliceIterator<String, String, String>>() {
					public ColumnSliceIterator<String, String, String> answer(
							InvocationOnMock invocation) throws Throwable {
						return columnSliceIterator;
					}
				});
		when(cassandraMock.createColumnSliceIterator(Matchers.anyString(),
						Matchers.same(""), Matchers.anyString(),
						Matchers.anyString(), Matchers.anyInt())).thenThrow(
				new RuntimeException("Key can't be empty string!"));

		// mock main CF
		stubHColumn(leftCF, hcolumnMain1, leftRows);

		stubHColumn(rightCF, hcolumnMain2, righttRows);

		when(row.getColumnSlice()).thenReturn(columnSlice);
		when(rows.getByKey(Matchers.anyString())).thenReturn(row);
		when(multigetQueryResult.get()).thenReturn(rows);
		when(cassandraMock.executeMultigetSliceQuery(Matchers.anyString(),
						Matchers.anyString(), Matchers.any(String[].class)))
				.thenAnswer(
						new Answer<QueryResult<Rows<String, String, String>>>() {
							public QueryResult<Rows<String, String, String>> answer(
									InvocationOnMock invocation)
									throws Throwable {
								return multigetQueryResult;
							}
						});
//		when(cassandraClientFactory.getInstance()).thenReturn(cassandraMock);
//		localController.setCassandraClientFactory(cassandraClientFactory);
	}

	private void stubHColumn(String cfName, HColumn<String, String> hcolumn,
			String[] rows) {
		OngoingStubbing<String> stubbing = when(hcolumn.getValue());
		for (String row : rows) {
			stubbing = stubbing.thenReturn(TEST_DATA_FILE.getString(row));
		}
		when(columnSlice.getColumnByName(cfName)).thenReturn(hcolumn)
				.thenReturn(null);
	}

	/************************ Legacy tests ************************/

	@Test
	@Ignore
	public final void testInvalidRoles() throws Throwable {
		String viewName = "INDEX";
		String filterURL = "tL.exchange=UJP1&issue.status=ACTIVE&fields=tL.active,tL.exchange";
		setupRequest(filterURL);
		when(request.getHeader(Shared.HEADER_ROLE)).thenReturn("xyz");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().equals(
				Shared.UNAUTHORIZED_VIEW_MESSAGE + viewName + StaticValues.SPACE
						+ metadataServiceMock.getRolesForDataset(viewName)));
	}

	@Test
	@Ignore
	public final void testInvalidRolesMDF() throws Throwable {
		String viewName = "CARLA";
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().equals(
				Shared.UNAUTHORIZED_VIEW_MESSAGE + viewName + StaticValues.SPACE
						+ metadataServiceMock.getRolesForDataset(viewName)));
	}

	@Test
	@Ignore
	public final void testValidRoles() throws Throwable {
		String viewName = "INDEX";
		String filterURL = "tL.exchange=UJP1&issue.status=ACTIVE&fields=tL.active,tL.exchange";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"tL.active	tL.exchange" + Shared.NEWLINE));
	}

	@Test
	@Ignore
	public final void testExecuteNoFilter() throws Throwable {
		String viewName = "INDEX";
		String filterURL = null;
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.ubsId	issue.assetClass	perm.source"));
	}

	@Test
	@Ignore
	public final void testExecuteNoFilterSapphire() throws Throwable {
		String viewName = "sapphire";
		String filterURL = null;
		setupRequest(filterURL);
		createTestFileFromProperty("EQUITY_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		String expectedHeaderRow = "issue.isin	issue.quick	issue.amountOutstanding	issue.status	"
				+ "issue.bbPrimSecPrimExchange	undl.sedol	close.price	"
				+ "marketCapitalization.price	stopHigh.price	stopLow.price";
		assertTrue(responseStream.toString().startsWith(
				expectedHeaderRow + Shared.NEWLINE));
		// Ensure no jagged rows
		String delimiter = "\t";
		int expectedDelimiterCount = StringUtils.countMatches(
				expectedHeaderRow, "\t");
		Scanner lineScanner = new Scanner(responseStream.toString());
		lineScanner.useDelimiter(Shared.NEWLINE);
		while (lineScanner.hasNext()) {
			assertEquals(
					StringUtils.countMatches(lineScanner.next(), delimiter),
					expectedDelimiterCount);
		}
		lineScanner.close();
	}

	@Test
	@Ignore
	public final void testExecute() throws Throwable {
		String viewName = "INDEX";
		String filterURL = "tL.exchange=UJP1&issue.status=ACTIVE&fields=tL.active,tL.exchange";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"tL.active	tL.exchange" + Shared.NEWLINE));
	}

	@Test
	@Ignore
	public final void testExecuteDirectFile() throws Throwable {
		String viewName = "EQUITY_EQ-PRICING";
		String filterURL = "tL.active=0&tL.exchange=XOSE";
		setupRequest(filterURL);
		createTestFileFromProperty("EQUITY_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		String expectedHeaderRow = "issue.issueDate	issue.sharesOutstanding	issue.sharesOutstandingDate	issue.rule144A3c7Ind	issue.votesPerShare	tL.portfolioMarginableCode	tL.illiquidStock	tL.bbCompositeExchange	basket.divisor	basket.numOfConstituents	settle.dtcEligible	issuer.ubsPartnerId	issuer.ubsId	undl.tlUbsId	undl.issueUbsId	undl.assetClass	undl.majorVersion	undl.lastUpdatedTime	undl.bbTicker	undl.sedol	issue.standardMarketSize	issue.isOfQuality	tL.settleCalendar	issue.shortName	settle.settleCalendar	issue.amountOutstanding	issue.fosProductGroup	issue.nikkeiStockType	issue.tseIndustryCode	issue.issueName/kanji	issue.shortName/kanji	issue.nikkeiIndustryCode	issue.frenchTransactionTax	tL.firstTradeDate	tL.indicativeNavRic	tL.pmNavSymbol	tL.risklessPrincipal	tL.nikkeiInvTrustType	tL.maxTradableQuantity	tL.maxTradableLot	equity.stockSplitDate	issue.fosGovtClass	issue.hasListing	issue.fosCalcCode	issue.amountOutstandingDate	issue.fos	issue.isStopTrade	issue.lastUpdatedTime	issue.majorVersion	issue.active	issue.status	issue.isoCfi	issue.assetClass	issue.assetType	issue.securityType	issue.bbSecurityType	issue.cusip	issue.common	issue.isin	issue.valoren	issue.wertpapier	issue.securityFormType	issue.nominalCurrency	issue.restrictedListCode	issue.cins	issue.restrictedOffTime	issue.restrictedOnTime	issue.nominalValueOfUnit	issue.mifidLiquidStk	issue.ubsTradable	issue.mifidTradeRep	issue.stdMarketSize	issue.mifidAvgDailyTurnover	issue.mifidAvgDailyTurnoverCcy	issue.mifidMarket	issue.mifidStdMktSizeCurrency	issue.mifidMostrelvMktCurrency	issue.issueName	issue.restrictedClass	issue.restrictedForResearch	issue.restrictionPriority	issue.restrictedForSales	issue.restrictedForTrading	issue.restrictedForPADealing	issue.restrictionComment	issue.sharesPerDepositoryReceipt	issue.regSInd	issue.rule144AInd	issue.adpClassification	issue.taxableCode	issue.quick	issue.adrPerShare	issue.isMultipleShare	issue.bbPrimSecCompExchange	issue.bbPrimSecPrimExchange	issue.ftaClass	issue.ubsId	tL.countryUbsId	tL.majorVersion	tL.lastUpdatedTime	tL.active	tL.status	tL.tickSize	tL.tidm	tL.exchange	tL.currency	tL.lotSize	tL.bbUnique	tL.sedol	tL.quotationType	tL.ticker	tL.tradeCountry	tL.bbTicker	tL.ric	tL.bbTickerExchange	tL.localCode	tL.bbSecurity	tL.roundLotSize	tL.ubsMarketMaker	tL.coltMn	tL.cubsInstrCode	tL.tradingLineName	tL.bbExchange	tL.isdaRegion	tL.opol	tL.regShoCatA	tL.euronext	tL.regShoCatB	tL.consolidatedThresholdInd	tL.etbExternal	tL.etbInternal	tL.whenIssuedFlag	tL.ipoFlag	tL.lastTradeDate	tL.marketSegment	tL.consolidatedListingInd	tL.opolInd	tL.bbCurrency	tL.ricOfIntInd	tL.pinkQuotable	tL.marketSettleVenue	tL.mifidFungibleId	tL.pmSymbol	tL.isdaRelExchCode	tL.isdaRelRtrsExchCode	tL.mifidMktSettleVenueName	tL.mifidubsMostLiquidVenue	tL.dmlMnemonic	tL.traxInd	tL.freeFloatPercent	tL.quoteLotSize	tL.normalMarketSize	tL.calendar	tL.orderRoutingRule	tL.countryOfRegistration	tL.fiiRestrictionInd	tL.auctionSession	tL.t13	tL.isOptionable	tL.relativeIndex	tL.adpId	tL.marginableCode	tL.occMarginableCode	tL.earningsPerShare	tL.bbPrimaryExchange	tL.lniClass	tL.takeoverMarker	tL.takeoverDate	tL.quick	tL.ubsId	equity.lastUpdatedTime	equity.majorVersion	equity.dividendCurrency	equity.dividendPerShare	equity.dividendType	equity.dividendFrequency	equity.dividendPayDate	equity.dividendRecordDate	equity.dividendDeclaredDate	equity.dividendExDate	equity.ipoDate	settle.majorVersion	settle.lastUpdatedTime	settle.seaqReportingInd	settle.crestInd	settle.firstSettleDate	settle.lastSettleDate	settle.ptmLevyApplicable	settle.euroclearInd	settle.stampInd	settle.crestStampDutyInd	settle.calendar	settle.date	issuer.lastUpdatedTime	issuer.majorVersion	issuer.issuerName	issuer.countryOfIncorporation	issuer.cconsol	issuer.bbCompany	issuer.icbIndustry	issuer.icbSector	issuer.icbSubsector	issuer.icbSupersector	issuer.fidbCode	issuer.countryOfDomicile	issuer.countryOfRisk	issuer.ubsPartyId	event.majorVersion	event.lastUpdatedTime	eod.date	eod.tlUbsId	eod.exchange	eod.assetClass	eod.lastUpdatedTime	eod.tradeIndicator	eod.quoteIndicator	adjustmentFactor.splitVolumeMultiplier	adjustmentFactor.effectiveDate	adjustmentFactor.dividendPriceAdjust	adjustmentFactor.splitPriceMultiplier	ask.date	ask.price	ask.currency	ask.lastUpdatedTime	ask.dateTime	ask.dataQuality	bid.date	bid.price	bid.currency	bid.lastUpdatedTime	bid.dateTime	bid.dataQuality	close.date	close.price	close.currency	close.lastUpdatedTime	close.dateTime	close.dataQuality	volume.date	volume.value	volume.lastUpdatedTime	volume.dataQuality	openInterest.date	openInterest.lastUpdatedTime	openInterest.value	openInterest.dataQuality	adv5.date	adv5.lastUpdatedTime	adv5.value	adv5.dataQuality	adv20.date	adv20.lastUpdatedTime	adv20.value	adv20.dataQuality	netAssetValue.source	netAssetValue.date	netAssetValue.price	netAssetValue.currency	netAssetValue.lastUpdatedTime	netAssetValue.dataQuality	adv30.source	adv30.date	adv30.lastUpdatedTime	adv30.value	adv30.dataQuality	adv60.source	adv60.date	adv60.lastUpdatedTime	adv60.value	adv60.dataQuality	adv90.source	adv90.date	adv90.lastUpdatedTime	adv90.value	adv90.dataQuality	open.date	open.price	open.lastUpdatedTime	open.dateTime	open.currency	open.dataQuality	open.source	high.date	high.price	high.lastUpdatedTime	high.dateTime	high.currency	high.dataQuality	high.source	low.date	low.price	low.lastUpdatedTime	low.dateTime	low.currency	low.dataQuality	low.source	marketCapitalization.date	marketCapitalization.price	marketCapitalization.lastUpdatedTime	marketCapitalization.dateTime	marketCapitalization.currency	marketCapitalization.dataQuality	marketCapitalization.source	stopHigh.date	stopHigh.price	stopHigh.lastUpdatedTime	stopHigh.dateTime	stopHigh.currency	stopHigh.dataQuality	stopHigh.source	stopLow.date	stopLow.price	stopLow.lastUpdatedTime	stopLow.dateTime	stopLow.currency	stopLow.dataQuality	stopLow.source	exchangeClose.date	exchangeClose.price	exchangeClose.lastUpdatedTime	exchangeClose.dateTime	exchangeClose.currency	exchangeClose.dataQuality	exchangeClose.source";
		assertTrue(responseStream.toString().startsWith(
				expectedHeaderRow + Shared.NEWLINE));
		// Ensure no jagged rows
		String delimiter = "\t";
		int expectedDelimiterCount = StringUtils.countMatches(
				expectedHeaderRow, "\t");
		Scanner lineScanner = new Scanner(responseStream.toString());
		lineScanner.useDelimiter(Shared.NEWLINE);
		while (lineScanner.hasNext()) {
			assertEquals(
					StringUtils.countMatches(lineScanner.next(), delimiter),
					expectedDelimiterCount);
		}
		lineScanner.close();
	}

	@Test
	@Ignore
	public final void testExecuteCarIndex() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName,SYSDATE,index.divisor,close.price"));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 4);
	}

	@Test
	@Ignore
	public final void testExecuteCarIndexNotEquals() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&tL.active=*not*1";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().equals(
				"issue.issueName,SYSDATE,index.divisor,close.price"
						+ Shared.NEWLINE));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 1);
	}

	@Test
	@Ignore
	public final void testExecuteCarIndexLessThanEquals() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&issue.issueName=*lte*NIKKEI 300 INDEX";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName,SYSDATE,index.divisor,close.price"
						+ Shared.NEWLINE));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 3);
	}

	@Test
	@Ignore
	public final void testExecuteCarIndexGreaterThanEquals() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&issue.issueName=*gte*TOPIX";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName,SYSDATE,index.divisor,close.price"
						+ Shared.NEWLINE));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 2);
	}

	@Test(expected = FilegenException.class)
	@Ignore
	public final void testExecuteCarIndexInvalidOperator() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&issue.issueName#NIKKEI 300 INDEX";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
	}

	@Test
	@Ignore
	public final void testExecuteCarIndexLessThan() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&issue.issueName=*lt*NIKKEI 300 INDEX";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName,SYSDATE,index.divisor,close.price"
						+ Shared.NEWLINE));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 2);
	}

	@Test
	@Ignore
	public final void testExecuteCarIndexGreaterThan() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&issue.issueName=*gt*NIKKEI 300 INDEX";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName,SYSDATE,index.divisor,close.price"
						+ Shared.NEWLINE));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 2);
	}

	@Test
	@Ignore
	public final void testExecuteCarIndexLike() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&issue.issueName=*like*NIK%DE?";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName,SYSDATE,index.divisor,close.price"
						+ Shared.NEWLINE));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 2);
	}

	@Test
	@Ignore
	public final void testExecuteCarIndexIn() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "issue.ubsId=299024957,299021952,299022623";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName,SYSDATE,index.divisor,close.price"
						+ Shared.NEWLINE));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 4);
	}

	@Test
	@Ignore
	public final void testExecuteCarIndexNotIn() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "issue.ubsId=*not*299024957,299021952";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName,SYSDATE,index.divisor,close.price"
						+ Shared.NEWLINE));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 2);
	}

	@Test
	@Ignore
	public final void testExecuteCarIndexSYSDATE() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "issue.ubsId=299024957&fields=issue.issueName,SYSDATE,index.divisor,close.price";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName,SYSDATE,index.divisor,close.price"
						+ Shared.NEWLINE));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 2);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
				Shared.DATE_FORMAT);
		Calendar calendar = Calendar.getInstance();
		Date currentDate = calendar.getTime();
		assertTrue(responseStream.toString().contains(
				"NIKKEI 300 INDEX," + simpleDateFormat.format(currentDate)
						+ ",1.23095955643628E12,INDICATIVE"));
	}

	@Test
	@Ignore
	public final void testExecuteCarIndexSYSDATEPrevious() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "issue.ubsId=299024957&fields=issue.issueName,SYSDATE-1,index.divisor,close.price";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName,SYSDATE-1,index.divisor,close.price"
						+ Shared.NEWLINE));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 2);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
				Shared.DATE_FORMAT);
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		Date previousDate = calendar.getTime();
		assertTrue(responseStream.toString().contains(
				"NIKKEI 300 INDEX," + simpleDateFormat.format(previousDate)
						+ ",1.23095955643628E12,INDICATIVE"));
	}

	@Test
	@Ignore
	public final void testExecuteCarIndexSYSDATENext() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "issue.ubsId=299024957&fields=issue.ubsId,issue.issueName,SYSDATE+1,index.divisor,close.price";
		setupRequest(filterURL);
		createTestFileFromProperty("INDEX_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.ubsId,issue.issueName,SYSDATE+1,index.divisor,close.price"
						+ Shared.NEWLINE));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 2);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
				Shared.DATE_FORMAT);
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, 1);
		Date nextDate = calendar.getTime();
		assertTrue(responseStream.toString().contains(
				"299024957,NIKKEI 300 INDEX,"
						+ simpleDateFormat.format(nextDate)
						+ ",1.23095955643628E12,INDICATIVE"));
	}

	private void createTestFileFromProperty(String propertyName)
			throws Throwable {
		BufferedReader inputReader = new BufferedReader(new StringReader(
				TEST_DATA_FILE.getString(propertyName)));
		DataOutputStream fileOutStream = fileSystem.createFile(propertyName
				.substring(0, propertyName.indexOf("_file")));
		String line = null;
		while ((line = inputReader.readLine()) != null) {
			fileOutStream.writeBytes(line + Shared.NEWLINE);
		}

		// Close streams
		inputReader.close();
		fileOutStream.flush();
		fileOutStream.close();
	}

	@Test
	@Ignore
	public final void testExecuteIncludeInput() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&includeInput=y";
		setupRequest(filterURL);
		when(request.getServletPath()).thenReturn("/" + viewName);
		when(request.getQueryString()).thenReturn(filterURL);
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"/carIndex?tL.exchange=UJP1&includeInput=y"));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 5);
	}

	@Test
	@Ignore
	public final void testExecuteHideInput() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&includeInput=n";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName,SYSDATE,index.divisor,close.price"));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 4);
	}

	@Test
	@Ignore
	public final void testExecuteHideHeader() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&hideHeader=y";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith("NIKKEI 300 INDEX"));
	}

	@Test
	@Ignore
	public final void testExecuteShowHeaderAndDelimiter() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&hideHeader=n&delimiter=|";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName|SYSDATE|index.divisor|close.price"
						+ Shared.NEWLINE + "NIKKEI 300 INDEX|"));
	}

	@Test
	@Ignore
	public final void testExecuteFields() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&fields=issue.issueName,close.price";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"issue.issueName,close.price" + Shared.NEWLINE
						+ "NIKKEI 300 INDEX,"));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 4);
	}

	@Test
	@Ignore
	public final void testExecuteInfo() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&fields=issue.issueName,close.price&includeInfo=y";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"INDEX_EQ-PRICING Nov 2 17:13 569K" + Shared.NEWLINE
						+ "issue.issueName,close.price" + Shared.NEWLINE));
	}

	@Test
	@Ignore
	public final void testExecuteUnionInfo() throws Throwable {
		String viewName = "sapphireUnion";
		String filterURL = "tL.active=0&tL.exchange=XOSE&includeInfo=y";
		setupRequest(filterURL);
		createTestFileFromProperty("EQUITY_EQ-PRICING_file");
		createTestFileFromProperty("CONVERTIBLES_EQ-PRICING_file");
		localController.filter(request, viewName, response);
		String expectedHeader = "issue.isin	issue.quick	issue.amountOutstanding	issue.status	issue.bbPrimSecPrimExchange	"
				+ "undl.sedol	close.price	marketCapitalization.price	stopHigh.price	stopLow.price	issue.ubsUniqueDescription"
				+ "	tL.ubsId	issue.ubsId	bond.minimumTradeSize";
		assertTrue(responseStream.toString().startsWith(
				"EQUITY_EQ-PRICING Nov 2 17:13 39M	CONVERTIBLES_EQ-PRICING Nov 2 17:13 395K"
						+ Shared.NEWLINE + expectedHeader + Shared.NEWLINE));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 7);
	}

	@Test
	@Ignore
	public final void testExecuteEscape() throws Throwable {
		String viewName = "carIndex";
		String filterURL = "tL.exchange=UJP1&escape=\"";
		setupRequest(filterURL);
		localController.filter(request, viewName, response);
		assertTrue(responseStream.toString().startsWith(
				"\"issue.issueName\",\"SYSDATE\",\"index.divisor\",\"close.price\""
						+ Shared.NEWLINE + "\"NIKKEI 300 INDEX\",\""));
		assertEquals(StringUtils.countMatches(responseStream.toString(),
				Shared.NEWLINE), 4);
	}
}
