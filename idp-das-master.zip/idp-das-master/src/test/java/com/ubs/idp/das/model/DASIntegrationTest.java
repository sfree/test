package com.ubs.idp.das.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.Timeout;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * This Integration test is intended to detect regression bugs
 * by testing with UAT2 data (JettyLauncher-UAT2.launch) locally even before committing to git.
 * When adding new tests where data / schema changes not yet available in UAT2,
 * it's okay to use appropriate DEV environment just for the new tests.
 * 
 * @author aigalsa
 *
 */
@RunWith(JUnit4.class)
@Ignore
public class DASIntegrationTest {

	private static final String rcasUrl = "https://rcas.smlogin.ibb.ubstest.net/loginrouter/rcas_v1_50";
	private static final String rcasAppID = "RCAS_IDP";
	private static final String username = "sso_idp";
	private static final String password = "1b1a50dc5ac97cbd9c79c8b93ec5ceac";
    private RestClient restClient = new RestClient(rcasUrl, rcasAppID, username, password);
    public static ObjectMapper mapper = new ObjectMapper();
	private String BASE_URL = "http://localhost:9990";
//	private String BASE_URL = "http://xstm5359vdap.stm.swissbank.com:9990";
	public static final String NEWLINE = "\n";

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	@Rule
    public Timeout globalTimeout = new Timeout(10000); // 10 seconds max per method tested

    public DASIntegrationTest() throws Exception {
    }
    
    @Test
    public void testUnionFeature() throws Exception {
    	String url = BASE_URL  + "/v1/MTS.IDP?"
    			+ "union=(issue.isin:IDPSL8904B20,IDPSL8906B28,IDPSL8906B36,IDPSL8905B29%7C"
    			+ "issue.cusip:IDP00CM63,IDP00CM81,IDP00CM82)&fields=issue.isin,issue.cusip,"
    			+ "POOL_NUMBER&POOL_NUMBER=R00LCX,R00LCT,R00LD0&format=JSONARRAY";
    	
    	BufferedReader inputReader = restClient.queryServiceWebSSOURL(url, null);

		 	// Check response TODO JSON validation
		 	assertEquals("[", inputReader.readLine());
		 	String line = inputReader.readLine() + inputReader.readLine()+inputReader.readLine() + inputReader.readLine();
		 	
		 	assertTrue(line.contains("\"issue.cusip\":\"IDP00CM62\",\"POOL_NUMBER\":\"R00LCT\",\"issue.isin\":\"IDPSL8904B20\""));
		 	assertTrue(line.contains("\"issue.cusip\":\"IDP00CN08\",\"POOL_NUMBER\":\"R00LD0\",\"issue.isin\":\"IDPSL8906B36\""));
		 	assertTrue(line.contains("\"issue.cusip\":\"IDP00CM81\",\"POOL_NUMBER\":\"R00LCX\",\"issue.isin\":\"IDPSL8905B29\""));
		 	assertFalse(line.contains("\"issue.cusip\":\"IDP00CN07\",\"POOL_NUMBER\":\"R00LCZ\",\"issue.isin\":\"IDPSL8906B28\""));		 	
		 	
		 	assertEquals("]", inputReader.readLine());
		
		 	// Close streams
		 	inputReader.close();
    	
    }
   
    @Test
    public void testAnvilUC() throws Exception {
    	String url = BASE_URL  + "/v1/Anvil?issue.isin=BE0000282880,CH0012385586,GB0009075325,US912810DY11,JP1200461000"
    			+"&fields=issue.ubsId,issue.isin,issue.cusip,ACCRUAL_PERIOD_BEGIN,ACCRUAL_PERIOD_END,altInstrumentId.altInstrumentId/eds,"
    			+ "altInstrumentId.altInstrumentId/mxnsec,bond.floatPayDay,bond.indexValueAtIssue,bond.isDirtyPriced,issue.cins,issue.collateralType,"
    			+ "CONVERTIBLE,COUPON_STRIP,issue.issueName,derived.Fitch_issueRating.code,FIXED_INT,FLOATING_INT,issue.fos,derived.Fitch_issueRating.endorsementInd,"
    			+ "INDEX_LINKED,ISSUER_TYPE,issue.istari,MARKET_ISSUE_TYPE,MARKET_TYPE,derived.Moodys_issueRating.endorsementInd,derived.Moodys_issueRating.code,"
    			+ "PRINCIPAL_INDEX_LINKED,PRINCIPAL_STRIP,issue.series,SHORT_TERM_DISCOUNTED_NOTE,derived.SandP_issueRating.code,derived.SandP_issueRating.endorsementInd,"
    			+ "issue.bbTicker,UBSRATING,issuer.countryOfRisk,ULT_PARENT_PARTY_NAME,ZERO_INT,CHASE_SUB_TYPE,COUP_SPEC1,coupon.accruedDayCount,"
    			+ "coupon.couponMonthEndType,coupon.couponType,coupon.currentCouponRate,coupon.exDividendPeriodNum,coupon.exDividendPeriodUnit,coupon.firstAccrualDate,"
    			+ "coupon.firstCouponDate,coupon.frequencyNum,coupon.frequencyUnit,coupon.frnMarginNum,coupon.frnRefixIndex,coupon.lastPrdAccruedDayCount,coupon.payDelay,"
    			+ "coupon.penultCouponDate,CUR_PRICE,derived.assetClass,derived.assetType,derived.FIAssetType,derived.SecFunding.issuerName,derived.valueFactor,"
    			+ "INDUSTRY_GROUP,INDUSTRY_SECTOR,issue.amountOutstanding,issue.bbYellowKey,issue.issueDate,issue.bondIssuerType,issue.issueSize,issue.marketIssueType,"
    			+ "issue.nominalCurrency,issue.securityType,issue.seniority,issue.shortName,issue.ubsUniqueDescription,issue.wertpapier,ISSUER,issuer.issuerName,"
    			+ "ISSUER_INDUSTRY,KEY,LAST_COUPON_DATE,LIMIT_CODE,LIMIT_NAME,MARK_DATE,DOMESTIC_ID,INT_DAY_CNT_TYPE,mortgage.bbMtgeCollateralType,"
    			+ "mortgage.weightAvgCoupon,mortgage.weightAvgRemainMaturity,MTG_TRANCHE_TYPE,NEXT_FACTOR,NEXT_FACTOR_DATE,POOL_NUMBER,PRE_PRICE,PRODUCT,PROGRAM,"
    			+ "SECURITY_ID,settle.currency,settle.duration,settle.firstSettleDate,settle.settleCalendar,Settlement%20Month,coupon.nextPaymentDate"
    			+"&format=JSONARRAY&distinct=y&unionExclusive=y";
    	

    	BufferedReader inputReader = restClient.queryServiceWebSSOURL(url, null);

// Check response TODO JSON validation
		 	assertEquals("[", inputReader.readLine());
		 	String line = inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine();
		 	
		 	assertTrue(line.contains("\"issue.isin\":\"BE0000282880\""));
		 	assertTrue(line.contains("\"issue.isin\":\"CH0012385586\""));
		 	assertTrue(line.contains("\"issue.isin\":\"GB0009075325\""));
		 	assertTrue(line.contains("\"issue.isin\":\"US912810DY11\""));
		 	assertTrue(line.contains("\"issue.isin\":\"JP1200461000\""));
		 	
		 	assertEquals("]", inputReader.readLine());
		
		 	// Close streams
		 	inputReader.close();
    	
    }
    
    @Test
    public void testRtimUC1LookupByIsin() throws Exception {
		// Request iDP Query Service
		String url = BASE_URL  + "/v1/InstrumentSecFunding?format=JSONARRAY&fields=IDP_STATUS,issue.ubsId,issue.isin&issue.isin=US912828FL97,US5528481030,XS0251886163,US48124BAC90,US313586RC55,xyz&derived.PrimaryListing=(EQUITY.IDP,BONDTL.IDP)Y,NULL,U&unionExclusive=y&distinct=y";

		// Check response
		Map<String, HashMap<String,Object>> jsonMap = parseJSONARRAYToMap(restClient.queryServiceWebSSOURL(url, null), new String[] {"issue.isin"});
		
		assertEquals("US912828FL97", ((String) jsonMap.get("US912828FL97").get("issue.isin")));
		assertEquals("OK", ((String) jsonMap.get("US912828FL97").get("IDP_STATUS")));
		assertEquals("11844335", ((String) jsonMap.get("US912828FL97").get("issue.ubsId")));
		
		assertEquals("US5528481030", ((String) jsonMap.get("US5528481030").get("issue.isin")));
		assertEquals("OK", ((String) jsonMap.get("US5528481030").get("IDP_STATUS")));
		assertEquals("10721699", ((String) jsonMap.get("US5528481030").get("issue.ubsId")));

		// BONDISSUE cusip is blank so override flag was incorrect and 2 rows were shown earlier. Now, the override flag predicate is removed and unionExclusive ignores this row when MTS row is found
		assertEquals("XS0251886163", ((String) jsonMap.get("XS0251886163").get("issue.isin")));
		assertEquals("OK", ((String) jsonMap.get("XS0251886163").get("IDP_STATUS")));
		assertTrue(Integer.parseInt(((String) jsonMap.get("XS0251886163").get("issue.ubsId"))) < 0);
		
		// This exists in both BONDISSUE and EQUITY, but unionExclusive ignores EQUITY when BONDISSUE is found.
		assertEquals("US48124BAC90", ((String) jsonMap.get("US48124BAC90").get("issue.isin")));
		assertEquals("OK", ((String) jsonMap.get("US48124BAC90").get("IDP_STATUS")));
		assertEquals("120063411", ((String) jsonMap.get("US48124BAC90").get("issue.ubsId")));
		
		// MTS has isin and is picked
		assertEquals("US313586RC55", ((String) jsonMap.get("US313586RC55").get("issue.isin")));
		assertEquals("OK", ((String) jsonMap.get("US313586RC55").get("IDP_STATUS")));
		assertEquals("-928", ((String) jsonMap.get("US313586RC55").get("issue.ubsId")));
		
		// invalid isin
		assertEquals("xyz", ((String) jsonMap.get("xyz").get("issue.isin")));
		assertEquals("ERROR", ((String) jsonMap.get("xyz").get("IDP_STATUS")));
		assertEquals(null, ((String) jsonMap.get("xyz").get("issue.ubsId")));

		// TODO find isin that exists but suppressed by multiple filters; ERROR row must always be returned for multiple filters
    }

	@Test
    public void testRtimUC1LookupByIsinLegacy() throws Exception {
		// Request iDP Query Service
		String url = BASE_URL  + "/v1/InstrumentSecFunding?format=JSONARRAY&fields=IDP_STATUS,issue.ubsId,issue.isin&issue.isin=US912828FL97,US5528481030,XS0251886163,US48124BAC90,US313586RC55,xyz&derived.PrimaryListing=(EQUITY.IDP,BONDTL.IDP)Y,NULL,U&derived.override=(BONDISSUE.IDP)N&distinct=y";
		
		// Check response
		Map<String, HashMap<String,Object>> jsonMap = parseJSONARRAYToMap(restClient.queryServiceWebSSOURL(url, null), new String[] {"issue.isin", "issue.ubsId"});
		
		assertEquals("US912828FL97", ((String) jsonMap.get("US912828FL97_11844335").get("issue.isin")));
		assertEquals("OK", ((String) jsonMap.get("US912828FL97_11844335").get("IDP_STATUS")));
		assertEquals("11844335", ((String) jsonMap.get("US912828FL97_11844335").get("issue.ubsId")));
		
		assertEquals("US5528481030", ((String) jsonMap.get("US5528481030_10721699").get("issue.isin")));
		assertEquals("OK", ((String) jsonMap.get("US5528481030_10721699").get("IDP_STATUS")));
		assertEquals("10721699", ((String) jsonMap.get("US5528481030_10721699").get("issue.ubsId")));

		// BONDISSUE cusip is blank so override flag was incorrect and 2 rows were shown earlier.
		assertEquals("XS0251886163", ((String) jsonMap.get("XS0251886163_11654291").get("issue.isin")));
		assertEquals("OK", ((String) jsonMap.get("XS0251886163_11654291").get("IDP_STATUS")));
		assertEquals("11654291", ((String) jsonMap.get("XS0251886163_11654291").get("issue.ubsId")));
		// Find -ve issue.ubsId key (varies across environments)
		String negativeKey = null;
		for(String key:jsonMap.keySet()) {
			if(key.startsWith("XS0251886163_-")) {
				negativeKey = key;
				break;
			}
		}
		assertEquals("XS0251886163", ((String) jsonMap.get(negativeKey).get("issue.isin")));
		assertEquals("OK", ((String) jsonMap.get(negativeKey).get("IDP_STATUS")));
		assertTrue(Integer.parseInt(((String) jsonMap.get(negativeKey).get("issue.ubsId"))) < 0);

		// This exists in both BONDISSUE and EQUITY so 2 rows were shown earlier.
		assertEquals("US48124BAC90", ((String) jsonMap.get("US48124BAC90_120063411").get("issue.isin")));
		assertEquals("OK", ((String) jsonMap.get("US48124BAC90_120063411").get("IDP_STATUS")));
		assertEquals("120063411", ((String) jsonMap.get("US48124BAC90_120063411").get("issue.ubsId")));
		assertEquals("US48124BAC90", ((String) jsonMap.get("US48124BAC90_200140074").get("issue.isin")));
		assertEquals("OK", ((String) jsonMap.get("US48124BAC90_200140074").get("IDP_STATUS")));
		assertEquals("200140074", ((String) jsonMap.get("US48124BAC90_200140074").get("issue.ubsId")));

		// MTS has isin and is picked
		assertEquals("US313586RC55", ((String) jsonMap.get("US313586RC55_-928").get("issue.isin")));
		assertEquals("OK", ((String) jsonMap.get("US313586RC55_-928").get("IDP_STATUS")));
		assertEquals("-928", ((String) jsonMap.get("US313586RC55_-928").get("issue.ubsId")));

		// invalid isin
		assertEquals("xyz", ((String) jsonMap.get("xyz_null").get("issue.isin")));
		assertEquals("ERROR", ((String) jsonMap.get("xyz_null").get("IDP_STATUS")));
		assertEquals(null, ((String) jsonMap.get("xyz_null").get("issue.ubsId")));
    }

    @Test
    public void testRtimUC2LookupBySedol() throws Exception {
		// Request iDP Query Service
		String url = BASE_URL  + "/v1/InstrumentSecFunding?format=JSONARRAY&fields=tL.sedol,issue.ubsId,tL.countryUbsId&tL.sedol=B8K36T5,B7K2KZ9,BLD2FL5&derived.PrimaryListing=(EQUITY.IDP,BONDTL.IDP)Y,NULL,U&unionExclusive=y&distinct=y";
		
		// Check response
		Map<String, HashMap<String,Object>> jsonMap = parseJSONARRAYToMap(restClient.queryServiceWebSSOURL(url, null), new String[] {"issue.ubsId"});
		
		assertEquals("0012781301", ((String) jsonMap.get("13384941").get("tL.countryUbsId")));
		assertEquals("13384941", ((String) jsonMap.get("13384941").get("issue.ubsId")));
		assertEquals("B8K36T5", ((String) jsonMap.get("13384941").get("tL.sedol")));
		
		assertEquals("0012773473", ((String) jsonMap.get("11414430").get("tL.countryUbsId")));
		assertEquals("11414430", ((String) jsonMap.get("11414430").get("issue.ubsId")));
		assertEquals("B7K2KZ9", ((String) jsonMap.get("11414430").get("tL.sedol")));
		
		assertEquals("0070644146", ((String) jsonMap.get("121606635").get("tL.countryUbsId")));
		assertEquals("121606635", ((String) jsonMap.get("121606635").get("issue.ubsId")));
		assertEquals("BLD2FL5", ((String) jsonMap.get("121606635").get("tL.sedol")));
    }

    @Test
    public void testRtimUC2LookupBySedolLegacy() throws Exception {
		// Request iDP Query Service
		String url = BASE_URL  + "/v1/InstrumentSecFunding?format=JSONARRAY&fields=tL.sedol,issue.ubsId,tL.countryUbsId&tL.sedol=B8K36T5,B7K2KZ9,BLD2FL5&derived.PrimaryListing=(EQUITY.IDP,BONDTL.IDP)Y,NULL,U&derived.override=(BONDISSUE.IDP)N&distinct=y";
		
		// Check response
		Map<String, HashMap<String,Object>> jsonMap = parseJSONARRAYToMap(restClient.queryServiceWebSSOURL(url, null), new String[] {"issue.ubsId"});
		
		assertEquals("0012781301", ((String) jsonMap.get("13384941").get("tL.countryUbsId")));
		assertEquals("13384941", ((String) jsonMap.get("13384941").get("issue.ubsId")));
		assertEquals("B8K36T5", ((String) jsonMap.get("13384941").get("tL.sedol")));
		
		assertEquals("0012773473", ((String) jsonMap.get("11414430").get("tL.countryUbsId")));
		assertEquals("11414430", ((String) jsonMap.get("11414430").get("issue.ubsId")));
		assertEquals("B7K2KZ9", ((String) jsonMap.get("11414430").get("tL.sedol")));
		
		assertEquals("0070644146", ((String) jsonMap.get("121606635").get("tL.countryUbsId")));
		assertEquals("121606635", ((String) jsonMap.get("121606635").get("issue.ubsId")));
		assertEquals("BLD2FL5", ((String) jsonMap.get("121606635").get("tL.sedol")));
    }

    @Test
    public void testRtimUC3() throws Exception {
		// Request iDP Query Service
		String url = BASE_URL  + "/v1/InstrumentSecFunding?format=JSONARRAY&fields=IDP_STATUS,issue.ubsId,tL.countryUbsId,isoCode&isoCode=USD";
		
		// Check response
		Map<String, HashMap<String,Object>> jsonMap = parseJSONARRAYToMap(restClient.queryServiceWebSSOURL(url, null), new String[] {"isoCode"});
		
		assertEquals("USD", ((String) jsonMap.get("USD").get("isoCode")));
		assertEquals("OK", ((String) jsonMap.get("USD").get("IDP_STATUS")));
		assertEquals("-70", ((String) jsonMap.get("USD").get("tL.countryUbsId")));
		assertEquals("-70", ((String) jsonMap.get("USD").get("issue.ubsId")));
    }

    @Test
    public void testRtimUC5() throws Exception {
		// Request iDP Query Service
		String url = BASE_URL  + "/v1/Book.IDP?format=JSONARRAY&fields=IDP_STATUS,BookId,BookName,LegalEntityCode&BookName=LDTY,OTCMPLTD";
		
		// Check response
		Map<String, HashMap<String,Object>> jsonMap = parseJSONARRAYToMap(restClient.queryServiceWebSSOURL(url, null), new String[] {"BookId"});
		
		assertEquals("207669", ((String) jsonMap.get("207669").get("BookId")));
		assertEquals("LDTY", ((String) jsonMap.get("207669").get("BookName")));
		assertEquals("OK", ((String) jsonMap.get("207669").get("IDP_STATUS")));
		assertEquals("2268", ((String) jsonMap.get("207669").get("LegalEntityCode")));

		assertEquals("394008", ((String) jsonMap.get("394008").get("BookId")));
		assertEquals("OTCMPLTD", ((String) jsonMap.get("394008").get("BookName")));
		assertEquals("OK", ((String) jsonMap.get("394008").get("IDP_STATUS")));
		assertEquals("2300", ((String) jsonMap.get("394008").get("LegalEntityCode")));
    }

    @Test
    public void testRtimUC6() throws Exception {
		// Request iDP Query Service
		String url = BASE_URL  + "/v1/AccountsAndRXM.IDP?format=JSONARRAY&fields=accId,IDP_STATUS,rxmCode&accId=1973394,8782";
		
		// Check response
		Map<String, HashMap<String,Object>> jsonMap = parseJSONARRAYToMap(restClient.queryServiceWebSSOURL(url, null), new String[] {"accId"});
		
		assertEquals("C76746", ((String) jsonMap.get("1973394").get("rxmCode")));
		assertEquals("OK", ((String) jsonMap.get("1973394").get("IDP_STATUS")));
		assertEquals("1973394", ((String) jsonMap.get("1973394").get("accId")));

		assertEquals("0", ((String) jsonMap.get("8782").get("rxmCode")));
		assertEquals("OK", ((String) jsonMap.get("8782").get("IDP_STATUS")));
		assertEquals("8782", ((String) jsonMap.get("8782").get("accId")));
    }

    @Test
    public void testCmtUC1() throws Exception {
		// Request iDP Query Service
		String url = BASE_URL  + "/v1/InstrumentSecFunding?format=JSONARRAY&fields=IDP_STATUS,issue.ubsId,tL.countryUbsId,issue.isin,derived.cusip,derived.sedol,derived.bondIssuerType,derived.issueFactor,derived.valueFactor,issue.issueSize,derived.minDenomination,derived.currentCouponRate,derived.assetClass&issue.ubsId=-70&derived.PrimaryListing=(EQUITY.IDP,BONDTL.IDP)Y,NULL,U&unionExclusive=y&distinct=y";
		
		// Check response
		Map<String, HashMap<String,Object>> jsonMap = parseJSONARRAYToMap(restClient.queryServiceWebSSOURL(url, null), new String[] {"issue.isin"});
		
		assertEquals("1", ((String) jsonMap.get("CASH - USD").get("derived.valueFactor")));
		assertEquals("CASH - USD", ((String) jsonMap.get("CASH - USD").get("derived.sedol")));
		assertEquals("OK", ((String) jsonMap.get("CASH - USD").get("IDP_STATUS")));
		assertEquals("CASH - USD", ((String) jsonMap.get("CASH - USD").get("issue.isin")));
		assertEquals("1", ((String) jsonMap.get("CASH - USD").get("derived.issueFactor")));
		assertEquals("CASH", ((String) jsonMap.get("CASH - USD").get("derived.assetClass")));
    }

    @Test
    public void testCmtUC2And3() throws Exception {
		// Request iDP Query Service
		String url = BASE_URL  + "/v1/InstrumentSecFunding?format=JSONARRAY&fields=issue.assetClass,issue.assetType,issue.cusip,issue.isin,issue.nominalCurrency,issue.issueName,issue.ubsId,issuer.cconsol,issuer.ubsPartyId,tL.countryUbsId,tL.sedol,isoCode,description,currencyOffset,domain,issue.bbTicker,tL.bbTicker,issuer.countryOfIncorporation,issue.ubsIsoCfi,coupon.couponType,issue.issueDate,issue.nominalValueOfUnit,issue.issueSize,issuer.countryOfDomicile,issue.ubsUniqueDescription,issue.bondIssuerType,issue.series,bond.maturityDate,bond.minimumTradeSize,issuer.countryOfRisk,tL.ticker,issue.collateralType,bond.stripType,bond.callOptionType,coupon.currentCouponRate,issue.isin,derived.cusip,derived.sedol,derived.bondIssuerType,derived.issueFactor,derived.valueFactor,issue.issueSize,derived.minDenomination,derived.currentCouponRate,derived.assetClass,derived.PrimaryListing,derived.assetType,derived.couponType,derived.FIAssetType,derived.Fitch_event.lastUpdatedTime,derived.Moodys_event.lastUpdatedTime,derived.SandP_event.lastUpdatedTime,derived.Fitch_issueRating.lastUpdatedTime,derived.Moodys_issueRating.lastUpdatedTime,derived.SandP_issueRating.lastUpdatedTime,issueRating.isProvisional,derived.Fitch_issueRating.code,derived.Moodys_issueRating.code,derived.SandP_issueRating.code,derived.Fitch_issueRating.rawCode,derived.Moodys_issueRating.rawCode,derived.SandP_issueRating.rawCode,issueRating.structuredFinanceInd,derived.Fitch_issueRating.endorsementInd,issueRating.recordType,derived.Fitch_issueRating.validDate,derived.Moodys_issueRating.validDate,derived.SandP_issueRating.validDate,derived.Fitch_issueRating.ratingGroup,derived.Moodys_issueRating.ratingGroup,derived.SandP_issueRating.ratingGroup,issueRating.ratingType,issueRating.currencyType,derived.Fitch_event.majorVersion,derived.Moodys_event.majorVersion,derived.SandP_event.majorVersion,derived.issue.majorVersion,derived.issue.active,derived.issue.isoCfi,derived.issue.assetClass,derived.issue.assetType,derived.issue.nominalCurrency,derived.issue.ubsTradable,derived.issue.ubsIsoCfi,derived.issue.ubsId&issue.ubsId=10000023&derived.PrimaryListing=(EQUITY.IDP,BONDTL.IDP)Y,NULL,U&unionExclusive=y&distinct=y";
		
		// Check response
		Map<String, HashMap<String,Object>> jsonMap = parseJSONARRAYToMap(restClient.queryServiceWebSSOURL(url, null), new String[] {"issue.ubsId"});
		
		assertEquals("CORP", ((String) jsonMap.get("10000023").get("issue.assetType")));
		assertEquals("CTFX", ((String) jsonMap.get("10000023").get("derived.couponType")));
		assertEquals("BBB", ((String) jsonMap.get("10000023").get("derived.SandP_issueRating.code")));
		assertEquals("Y", ((String) jsonMap.get("10000023").get("derived.PrimaryListing")));
		assertEquals("10000023", ((String) jsonMap.get("10000023").get("issue.ubsId")));
		assertEquals("Fixed Income", ((String) jsonMap.get("10000023").get("derived.assetClass")));
    }

    @Test
    public void testLimitLookupPredicate() throws Exception {
		// Request iDP Query Service - test multiple times to ensure deterministic behavior
    	String url = BASE_URL  + "/v1/InstrumentSecFunding?format=JSONARRAY&fields=IDP_STATUS,issue.ubsId,tL.countryUbsId,issue.isin,issue.cusip&issue.ubsId=10917832&derived.PrimaryListing=(EQUITY.IDP,BONDTL.IDP)Y,NULL,U&unionExclusive=y&limit=1";
		for(int i = 0; i < 10; i++) {
			// Check response
			Map<String, HashMap<String,Object>> jsonMap = parseJSONARRAYToMap(restClient.queryServiceWebSSOURL(url, null), new String[] {"issue.isin"});
			
			assertEquals("US14161H1086", ((String) jsonMap.get("US14161H1086").get("issue.isin")));
			assertEquals("OK", ((String) jsonMap.get("US14161H1086").get("IDP_STATUS")));
			assertEquals("14161H108", ((String) jsonMap.get("US14161H1086").get("issue.cusip")));
			assertEquals("", ((String) jsonMap.get("US14161H1086").get("tL.countryUbsId")));
			assertEquals("10917832", ((String) jsonMap.get("US14161H1086").get("issue.ubsId")));
		}
    }

    @Test
    public void testLimitPredicatePerformance() throws Exception {
		// Request iDP Query Service - test multiple times to ensure deterministic behavior
    	String url = BASE_URL  + "/v1/AccountsAndRXM.IDP?format=JSONARRAY&fields=accId&limit=2";
		for(int i = 0; i < 5; i++) {
			// Check response
			Map<String, HashMap<String,Object>> jsonMap = parseJSONARRAYToMap(restClient.queryServiceWebSSOURL(url, null), new String[] {"accId"});
			assertEquals(2, jsonMap.keySet().size());
		}
    }

    @Test
    public void testPostQuery() throws Exception {
		// Request iDP Query Service
		String url = BASE_URL  + "/v1/Book.IDP?format=JSONARRAY";
		// Request parameters
		List<NameValuePair> params = new ArrayList<NameValuePair>(1);
		params.add(new BasicNameValuePair("fields", "IDP_STATUS,BookId,BookName,LegalEntityCode"));
		params.add(new BasicNameValuePair("BookName", "LDTY,OTCMPLTD"));

		// Check response
		Map<String, HashMap<String,Object>> jsonMap = parseJSONARRAYToMap(restClient.queryServiceWebSSOURL(url, params), new String[] {"BookId"});
		
		assertEquals("207669", ((String) jsonMap.get("207669").get("BookId")));
		assertEquals("LDTY", ((String) jsonMap.get("207669").get("BookName")));
		assertEquals("OK", ((String) jsonMap.get("207669").get("IDP_STATUS")));
		assertEquals("2268", ((String) jsonMap.get("207669").get("LegalEntityCode")));
		// ensure no unspecified fields in POST response e.g. BookStatus
		assertNull(jsonMap.get("207669").get("BookStatus"));

		assertEquals("394008", ((String) jsonMap.get("394008").get("BookId")));
		assertEquals("OTCMPLTD", ((String) jsonMap.get("394008").get("BookName")));
		assertEquals("OK", ((String) jsonMap.get("394008").get("IDP_STATUS")));
		assertEquals("2300", ((String) jsonMap.get("394008").get("LegalEntityCode")));
		// ensure no unspecified fields in POST response e.g. BookStatus
		assertNull(jsonMap.get("394008").get("BookStatus"));
    }

    @Test
    @Ignore
    //TODO fix this! For now, tested manually
    public void shouldAllowConcurrentIndexedQueryAndDisallowConcurrentNonIndexedQueryOnView() throws Exception {
		// Allow first non-indexed query
		System.out.println("query 1 started");
		final String nonIndexedQueryUrl = BASE_URL  + "/v1/InstrumentSecFunding?fields=isoCode,issue.isin&derived.assetClass=CASH";
		BufferedReader inputReader = restClient.queryServiceWebSSOURL(nonIndexedQueryUrl, null);
		System.out.println("query 1 done");
		// Close streams
		inputReader.close();

		// Allow concurrent indexed query
		new Thread() {
			public void run() {
				System.out.println("query 2 started");
				BufferedReader inputReader;
				try {
					String indexedQueryUrl = BASE_URL  + "/v1/InstrumentSecFunding?fields=isoCode,issue.isin&isoCode=USD";
					inputReader = new RestClient(rcasUrl, rcasAppID, username, password).queryServiceWebSSOURL(indexedQueryUrl, null);
					System.out.println("query 2 done");
					// Check response
					assertEquals("isoCode	issue.isin", inputReader.readLine());
					assertEquals("USD	CASH - USD", inputReader.readLine());
					assertEquals("", inputReader.readLine());

					inputReader.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}.start();
		// http://localhost:9990/v1/InstrumentSecFunding?fields=isoCode,issue.isin&isoCode=USD
		//isoCode	issue.isin
		//USD	CASH - USD


		// Ensure concurrent non-indexed query disallowed
		String viewName = "InstrumentSecFunding";
		expectedException.expect(IOException.class);
		expectedException.expectMessage("Data request failed with code [503] and message [" + Shared.NON_INDEXED_QUERY_IN_PROGRESS + viewName + "]");

		new Thread() {
			public void run() {
				System.out.println("query 3 started");
				BufferedReader inputReader;
				try {
					inputReader = new RestClient(rcasUrl, rcasAppID, username, password).queryServiceWebSSOURL(nonIndexedQueryUrl, null);
					System.out.println("query 3 done");
					inputReader.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}.start();
    }

    @Test
    @Ignore
    // TODO do full table scans to detect inconsistency
    public void testAnvilInconsistency() throws Exception {
		// Request iDP Query Service
		String url = BASE_URL  + "/v1/MartiniCDRStatic?CDRStatic.ISIN=KR1035017238,KR1035017261,US912828TG56,US31419LZZ92,DE0001137396,US912828TU41,XS0849420905,GB00B84Z9V04,US912828TY62,DE0001137404,FR0011394345,DE0001137412,KR1015014262,KR10150142A7,NL0010418810,US912828UT58,US3128MDPH04,DE0001102317,KR310101G3A1,US912828WE61,XS0429603813,US912796DF38,KR103501G3C2,US912796DG11,DE0001119998,US912796DS58,US912796DV87,US912796DW60,US3128M9X645,FR0122208228,US80283DAG60&format=JSONARRAY&fields=CDRStatic.ISIN";
		BufferedWriter fileWriter = new BufferedWriter(new FileWriter(
				"dasTest.out"));
		try {
			for(int i = 0; i < 10000; i++) {
				BufferedReader inputReader = restClient.queryServiceWebSSOURL(url, null);
				// Check response has 8 lines
				String line = inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() +
						inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() +
						inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine() + inputReader.readLine();
	
				// Log response to file
				fileWriter.write(line + NEWLINE);
	
				assertTrue(line.startsWith("["));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"KR1035017238\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"KR1035017261\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US912828TG56\""));
//				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US31419LZZ92\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"DE0001137396\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US912828TU41\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"XS0849420905\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"GB00B84Z9V04\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US912828TY62\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"DE0001137404\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"FR0011394345\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"DE0001137412\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"KR1015014262\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"KR10150142A7\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"NL0010418810\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US912828UT58\""));
//				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US3128MDPH04\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"DE0001102317\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"KR310101G3A1\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US912828WE61\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"XS0429603813\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US912796DF38\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"KR103501G3C2\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US912796DG11\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"DE0001119998\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US912796DS58\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US912796DV87\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US912796DW60\""));
//				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US3128M9X645\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"FR0122208228\""));
				assertTrue(line.contains("\"CDRStatic.ISIN\":\"US80283DAG60\""));
				assertTrue(line.endsWith("]"));
	
				// Close stream
				inputReader.close();
			}
		} finally {
			// Close log stream
			fileWriter.flush();
			fileWriter.close();
		}
    }

    private Map<String, HashMap<String,Object>> parseJSONARRAYToMap(BufferedReader inputReader, String[] keyAttributes) throws IOException {
		assertEquals("[", inputReader.readLine());
		
    	Map<String, HashMap<String,Object>> jsonMap = new HashMap<String, HashMap<String,Object>>();
    	String line = null;
    	while((line = inputReader.readLine()) != null && !"]".equals(line)) {
    		HashMap<String,Object> result = mapper.readValue(line, HashMap.class);
    		String key = "";
    		for(String keyAttribute : keyAttributes) {
    			key += (key.equals("") ? "" : "_") + result.get(keyAttribute);
    		}
			jsonMap.put(key, result);
    	}
    	assertEquals("]", line);
		assertNull(inputReader.readLine());

		// Close streams
		inputReader.close();
		
		return jsonMap;
	}
}
