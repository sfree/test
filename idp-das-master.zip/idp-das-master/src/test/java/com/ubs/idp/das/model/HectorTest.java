package com.ubs.idp.das.model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import me.prettyprint.cassandra.model.BasicColumnFamilyDefinition;
import me.prettyprint.cassandra.model.ConfigurableConsistencyLevel;
import me.prettyprint.cassandra.serializers.StringSerializer;
import me.prettyprint.cassandra.service.CassandraHostConfigurator;
import me.prettyprint.cassandra.service.ThriftCfDef;
import me.prettyprint.hector.api.Cluster;
import me.prettyprint.hector.api.HConsistencyLevel;
import me.prettyprint.hector.api.Keyspace;
import me.prettyprint.hector.api.beans.Row;
import me.prettyprint.hector.api.beans.Rows;
import me.prettyprint.hector.api.ddl.ColumnFamilyDefinition;
import me.prettyprint.hector.api.ddl.ComparatorType;
import me.prettyprint.hector.api.factory.HFactory;
import me.prettyprint.hector.api.mutation.Mutator;
import me.prettyprint.hector.api.query.QueryResult;

public class HectorTest {
	private static final String CLUSTER_NAME = "Delta Service Data Store Cluster";
	private static final String SEED_HOSTS = "dhcp-172-19-38-111.pwj.com:9160,dhcp-172-19-38-186.pwj.com:9160";
	public static final String KEYSPACE = "IDP";
	private static Cluster cassandraCluster = null;
	private static Keyspace keyspace = null;
	public StringSerializer stringSerializer = StringSerializer.get();
	private String filePath = "/root/";
	public static final String STANDARD_DELIMITER = "\t";
	private String columnFamily = "EQSINGLECOL";
	private String columnName = "EQSINGLECOL";
	private static final int KEY_POSITION = 169;
	private static final int BATCH_SIZE = 50;
	public static final int MILLISECONDS_PER_SECOND = 1000;
	public static final int SECONDS_PER_MINUTE = 60;
	public static final String MINUTES = "m";
	public static final String SECONDS = "s";
	public static final String SPACE = " ";

	HectorTest() {
		// Initialize Cassandra cluster
		lazyInitialize();
	}

	/**
	 * Initialize Cassandra cluster.
	 */
	public void lazyInitialize() {
		if (cassandraCluster == null) {
			CassandraHostConfigurator cassandraHostConfigurator = new CassandraHostConfigurator(
					SEED_HOSTS);
			cassandraCluster = HFactory.getOrCreateCluster(CLUSTER_NAME,
					cassandraHostConfigurator);
			ConfigurableConsistencyLevel ccl = new ConfigurableConsistencyLevel();
			ccl.setDefaultReadConsistencyLevel(HConsistencyLevel.ONE);
			ccl.setDefaultWriteConsistencyLevel(HConsistencyLevel.ANY); // ANY
			keyspace = HFactory.createKeyspace(KEYSPACE, cassandraCluster, ccl);
		}
	}

	public void addColumnFamilyIfNeeded(String columnFamilyName) {
		// // Ensure keyspace
		// createKeyspaceIfNeeded();

		for (ColumnFamilyDefinition columnFamilyDefinition : cassandraCluster
				.describeKeyspace(KEYSPACE).getCfDefs()) {
			// Do nothing if CF exists
			if (columnFamilyDefinition.getName().equals(columnFamilyName)) {
				return;
			}
		}

		// Add new CF
		cassandraCluster.addColumnFamily(
				createColumnFamilyDefinition(columnFamilyName), true);
		System.out.println("Added CF: " + columnFamilyName);
	}

	private ColumnFamilyDefinition createColumnFamilyDefinition(
			String columnFamilyName) {
		BasicColumnFamilyDefinition basicColumnFamilyDefinition = new BasicColumnFamilyDefinition();
		basicColumnFamilyDefinition.setKeyspaceName(KEYSPACE);
		basicColumnFamilyDefinition.setName(columnFamilyName);
		basicColumnFamilyDefinition
				.setDefaultValidationClass(ComparatorType.UTF8TYPE
						.getClassName());
		basicColumnFamilyDefinition
				.setKeyValidationClass(ComparatorType.UTF8TYPE.getClassName());
		basicColumnFamilyDefinition.setComparatorType(ComparatorType.UTF8TYPE);
		return new ThriftCfDef(basicColumnFamilyDefinition);
	}

	/**
	 * Create Keyspace if needed
	 */
	// public void createKeyspaceIfNeeded() {
	// // Create keyspace (and CFs) if not already
	// if (cassandraCluster.describeKeyspace(KEYSPACE) == null) {
	// List<ColumnFamilyDefinition> columnFamilyDefinitions =
	// new ArrayList<ColumnFamilyDefinition>();
	// KeyspaceDefinition keyspaceDef =
	// HFactory.createKeyspaceDefinition(KEYSPACE,
	// ThriftKsDef.DEF_STRATEGY_CLASS, REPLICATION_FACTOR,
	// columnFamilyDefinitions);
	//
	// // Add the schema to the cluster.
	// cassandraCluster.addKeyspace(keyspaceDef, true);
	// System.out.println("Done. Keyspace added: " + KEYSPACE);
	// }
	// }

	public void putAll(String fileName) throws IOException {
		long start = System.currentTimeMillis();
		Mutator<String> mutator = HFactory.createMutator(keyspace,
				stringSerializer);
		// read file
		BufferedReader fileReader = new BufferedReader(new FileReader(filePath
				+ fileName));
		String line = null;
		int rowNum = 0;
		while ((line = fileReader.readLine()) != null) {
			rowNum++;
			// parse
			String[] values = line.split(STANDARD_DELIMITER, -1);
			// System.out.println("Inserting... " + values[KEY_POSITION]);
			mutator.addInsertion(values[KEY_POSITION], columnFamily, HFactory
					.createColumn(columnName, line, stringSerializer,
							stringSerializer));
			// batch insert
			if (rowNum % BATCH_SIZE == 0) {
				mutator.execute();
				mutator = HFactory.createMutator(keyspace, stringSerializer);
			}
		}
		mutator.execute();
		fileReader.close();
		System.out.println("Inserted " + rowNum + " rows in "
				+ elapsedTime(start) + ". Per request: "
				+ ((System.currentTimeMillis() - start) / (double) rowNum)
				+ " ms");
	}

	public void getAll(String fileName) throws IOException {
		long start = System.currentTimeMillis();
		// read file
		BufferedReader fileReader = new BufferedReader(new FileReader(filePath
				+ fileName));
		String line = null;
		int rowNum = 0;
		String[] keyArray = new String[BATCH_SIZE];
		while ((line = fileReader.readLine()) != null) {
			rowNum++;
			// parse
			String[] values = line.split(STANDARD_DELIMITER, -1);
			// System.out.println("Reading... " + values[KEY_POSITION]);
			keyArray[rowNum] = values[KEY_POSITION];
			// batch read
			if (rowNum % BATCH_SIZE == 0) {
				readRows(keyArray);
			}
		}
		readRows(keyArray);
		fileReader.close();
		System.out.println("Read " + rowNum + " rows in " + elapsedTime(start)
				+ ". Per request: "
				+ ((System.currentTimeMillis() - start) / (double) rowNum)
				+ " ms");
	}

	private void readRows(String[] keyArray) {
		QueryResult<Rows<String, String, String>> result = HFactory
				.createMultigetSliceQuery(keyspace, stringSerializer,
						stringSerializer, stringSerializer)
				.setColumnFamily(columnFamily).setColumnNames(columnName)
				.setKeys(keyArray).execute();
		for (Row<String, String, String> row : result.get()) {
			// System.out
			// .println(row.getColumnSlice().getColumnByName(columnName));
			row.getColumnSlice().getColumnByName(columnName);
		}
	}

	public static String elapsedTime(long start) {
		double seconds = ((double) (System.currentTimeMillis() - start))
				/ MILLISECONDS_PER_SECOND;
		if (seconds > SECONDS_PER_MINUTE) {
			return (seconds / SECONDS_PER_MINUTE) + SPACE + MINUTES;
		} else {
			return seconds + SPACE + SECONDS;
		}
	}

	// java HectorTest GET/PUT/ADDCF EQSingle/EQAll/EQSINGLECOL
	public static void main(String args[]) {
		System.out.println("Starting...");
		try {
			if ("GET".equals(args[0])) {
				new HectorTest().getAll(args[1]);
			} else if ("PUT".equals(args[0])) {
				new HectorTest().putAll(args[1]);
			} else if ("ADDCF".equals(args[0])) {
				new HectorTest().addColumnFamilyIfNeeded(args[1]);
			} else {
				System.out.println("Invalid command: " + args[1]);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
