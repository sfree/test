package com.ubs.idp.das.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.NameValuePair;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ubs.idp.das.QueryServiceConfiguration;
import com.ubs.idp.das.response.ResponseFormatter;
import com.ubs.idp.das.webservice.LocalController;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.model.exceptions.MetadataException;

@RunWith(MockitoJUnitRunner.class)
public class InfoTest {
	private Info testClass = null;
	static LocalController localController = null;
	private ByteArrayOutputStream responseStream;
	private ServletOutputStream servletOutputStream;

	@Mock
	HttpServletRequest request;
	@Mock
	HttpServletResponse response;
	@Mock
    private QueryServiceConfiguration mockQueryServiceConfiguration;
	@Mock
    private RestClient mockRestClient;
	@Mock
    private MetadataService metadataService;

	private static final ResourceBundle TEST_DATA_FILE = ResourceBundle.getBundle(Shared.TEST_DATA_FILE);

	@Before
	public void setUp() throws Exception {
		localController = new LocalController();

		responseStream = new ByteArrayOutputStream();
		servletOutputStream = new ServletOutputStream() {
			@Override
			public void write(int b) throws IOException {
				responseStream.write(b);
			}
		};
		when(response.getOutputStream()).thenReturn(servletOutputStream);

		// mock XD HTTP API
		when(mockRestClient.queryServiceWebSSOURL(Matchers.contains("loadAccountsAndRXM"), (List<NameValuePair>)Matchers.any())).
			thenReturn(new BufferedReader(new InputStreamReader(new ByteArrayInputStream(TEST_DATA_FILE.getString("loadAccountsAndRXM").getBytes()))));
		when(mockRestClient.queryServiceWebSSOURL(Matchers.contains("loadDSCurrency"), (List<NameValuePair>)Matchers.any())).
			thenReturn(new BufferedReader(new InputStreamReader(new ByteArrayInputStream(TEST_DATA_FILE.getString("loadDSCurrency").getBytes()))));
		when(mockRestClient.queryServiceWebSSOURL(Matchers.contains("loadMTS"), (List<NameValuePair>)Matchers.any())).
			thenReturn(new BufferedReader(new InputStreamReader(new ByteArrayInputStream(TEST_DATA_FILE.getString("loadMTS").getBytes()))));

		// mock mds
		when(metadataService.getJobNamesForDataset(Matchers.matches("loadAccountsAndRXM"))).
			thenThrow(new MetadataException("Failed to find dataset with id=loadAccountsAndRXM (Query=[match (pd:PhysicalDataset {id:{id}}) return pd.id,pd.name,pd.tableId] Params={id=loadAccountsAndRXM})"));
		when(metadataService.getJobNamesForDataset(Matchers.matches("AccountsAndRXM.IDP"))).
			thenReturn(Arrays.asList("loadAccountsAndRXM"));
		when(metadataService.getJobNamesForDataset(Matchers.matches("InstrumentSecFunding"))).
			thenReturn(Arrays.asList("loadDSCurrency", "loadMTS"));

		testClass = new Info();
		testClass.queryServiceConfiguration = mockQueryServiceConfiguration;
		testClass.restClient = mockRestClient;
		testClass.metadataService = metadataService;
		
		localController.setInfoCommand(testClass);
	}

	@After
	public void tearDown() {
		testClass = null;
	}

	@Test
	public final void testExecuteHealth() throws Throwable {
		localController.health(request, response);
		assertEquals(Shared.OPERATION_SUCCESS, responseStream.toString());
	}

	@Test
	public final void testJobStatusForJobName() throws Throwable {
		Map<String, String[]> parameterMap = new HashMap<String, String[]>();
		testClass.status(servletOutputStream, parameterMap, "loadAccountsAndRXM");
		List<LinkedHashMap<String, Object>> jobsList = ResponseFormatter.mapper.readValue(new BufferedReader(new InputStreamReader(new ByteArrayInputStream(responseStream.toString().getBytes()))), List.class);
		assertEquals("Return only 1 latest job execution", 1, jobsList.size());
		for(LinkedHashMap<String, Object> job : jobsList) {
			assertTrue(job.keySet().contains("endTime"));
			assertTrue(job.keySet().contains("readCount"));
		}
	}

	@Test
	public final void testJobStatusForDataset() throws Throwable {
		Map<String, String[]> parameterMap = new HashMap<String, String[]>();
		parameterMap.put("history", new String[]{"5"});
		testClass.status(servletOutputStream, parameterMap, "AccountsAndRXM.IDP");
		List<LinkedHashMap<String, Object>> jobsList = ResponseFormatter.mapper.readValue(new BufferedReader(new InputStreamReader(new ByteArrayInputStream(responseStream.toString().getBytes()))), List.class);
		assertEquals("Return only 5 job executions", 5, jobsList.size());
		for(LinkedHashMap<String, Object> job : jobsList) {
			assertTrue(job.keySet().contains("endTime"));
			assertTrue(job.keySet().contains("readCount"));
		}
	}

	@Test
	public final void testJobStatusForView() throws Throwable {
		Map<String, String[]> parameterMap = new HashMap<String, String[]>();
		testClass.status(servletOutputStream, parameterMap, "InstrumentSecFunding");
		List<LinkedHashMap<String, Object>> jobsList = ResponseFormatter.mapper.readValue(new BufferedReader(new InputStreamReader(new ByteArrayInputStream(responseStream.toString().getBytes()))), List.class);
		assertEquals("Return only latest execution for 2 jobs", 2, jobsList.size());
		for(LinkedHashMap<String, Object> job : jobsList) {
			assertTrue(job.keySet().contains("endTime"));
			assertTrue(job.keySet().contains("readCount"));
		}
	}
}