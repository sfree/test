package com.ubs.idp.das.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import au.com.bytecode.opencsv.CSVWriter;

import com.ubs.idp.das.QueryServiceConfiguration;
import com.ubs.idp.das.model.RequestParameters;
import com.ubs.idp.das.model.Shared;

@RunWith(MockitoJUnitRunner.class)
public class ResponseFormatterTest {
	private ResponseFormatter testClass = null;
	private ByteArrayOutputStream responseStream;

	RequestParameters requestParameters;

	@Before
	public void setUp() throws Exception {
	    
	    QueryServiceConfiguration config = new QueryServiceConfiguration();
        ReflectionTestUtils.setField(config, "seedHosts", "xstm5346vdap.stm.swissbank.com:9160");
        ReflectionTestUtils.setField(config, "replicationFactor", 2);
        ReflectionTestUtils.setField(config, "distinctLimit", 5000);
        ReflectionTestUtils.setField(config, "DISTINCT_LIMIT", 5000);
        ReflectionTestUtils.setField(config, "readThreadCorePoolSize", 50);
        ReflectionTestUtils.setField(config, "readThreadMaxPoolSize", 50);
        ReflectionTestUtils.setField(config, "readThreadQueueSize", 100);
        ReflectionTestUtils.setField(config, "readBatchSize", 100);
        ReflectionTestUtils.setField(config, "cassandraPassword", "48a7110effe85572ce8be20290f5bc55");

		requestParameters = new RequestParameters();
		requestParameters.setDelimiter(Shared.STANDARD_DELIMITER);
		requestParameters.setQuoteChar(CSVWriter.NO_QUOTE_CHARACTER);
		requestParameters.setEscapeChar(CSVWriter.NO_ESCAPE_CHARACTER);

		responseStream = new ByteArrayOutputStream();
	}

	@Test
	public final void testExecuteTEXT() throws Throwable {
		requestParameters.setResponseFormat("TEXT");
		testClass = ResponseFormatter.getInstance(responseStream,
				requestParameters);
		testClass.writeLine(new String[] { "1", "2", "3" });
		testClass.close();
		assertEquals("1	2	3\n", responseStream.toString());
	}

	@Test
	public final void testExecuteJSONARRAY() throws Throwable {
		requestParameters.setResponseFormat("JSONARRAY");

		testClass = ResponseFormatter.getInstance(responseStream,
				requestParameters);
		testClass.writeHeader(new String[] { "header1", "header2" });
		testClass.writeLine(new String[] { "1", "2" });
		testClass.close();
		assertTrue(responseStream.toString().equals(
				"[\n" + "{\"header1\":\"1\",\"header2\":\"2\"}\n" + "]\n")
				|| responseStream.toString().equals(
						"[\n" + "{\"header2\":\"2\",\"header1\":\"1\"}\n"
								+ "]\n"));
	}

	@Test
	public final void testExecuteJSON() throws Throwable {
		requestParameters.setResponseFormat("JSON");

		testClass = ResponseFormatter.getInstance(responseStream,
				requestParameters);
		testClass.writeHeader(new String[] { "header1", "header2" });
		testClass.writeLine(new String[] { "1", "2" });
		testClass.close();
		assertTrue(responseStream.toString().equals(
				"{\"header1\":\"1\",\"header2\":\"2\"}\n")
				|| responseStream.toString().equals(
						"{\"header2\":\"2\",\"header1\":\"1\"}\n"));
	}

	@Test
	public final void testExecuteTEXTDistinct() throws Throwable {
		requestParameters.setResponseFormat("TEXT");

		testClass = ResponseFormatter.getInstance(responseStream,
				requestParameters);
		testClass.setDistinct(true);
		testClass.writeHeader(new String[] { "header1", "header2" });
		testClass.writeLine(new String[] { "1", "2" });
		testClass.writeLine(new String[] { "1", "2" });
		testClass.writeLine(new String[] { "2", "2" });
		testClass.close();
		assertTrue(responseStream.toString().equals(
				"header1	header2\n" + "1	2\n" + "2	2\n"));
	}

	@Test
	public final void testExecuteJSONARRAYDistinct() throws Throwable {
		requestParameters.setResponseFormat("JSONARRAY");

		testClass = ResponseFormatter.getInstance(responseStream,
				requestParameters);
		testClass.setDistinct(true);
		testClass.writeHeader(new String[] { "header1", "header2" });
		testClass.writeLine(new String[] { "1", "2" });
		testClass.writeLine(new String[] { "1", "2" });
		testClass.writeLine(new String[] { "2", "2" });
		testClass.close();
		assertTrue(responseStream.toString().equals(
				"[\n" + "{\"header1\":\"1\",\"header2\":\"2\"}\n" + "],\n"
						+ "{\"header1\":\"2\",\"header2\":\"2\"}\n" + "]\n")
				|| responseStream.toString().equals(
						"[\n" + "{\"header1\":\"1\",\"header2\":\"2\"}\n"
								+ "],\n"
								+ "{\"header2\":\"2\",\"header1\":\"2\"}\n"
								+ "]\n")
				|| responseStream.toString().equals(
						"[\n" + "{\"header2\":\"2\",\"header1\":\"1\"},\n"
								+ "{\"header1\":\"2\",\"header2\":\"2\"}\n"
								+ "]\n")
				|| responseStream.toString().equals(
						"[\n" + "{\"header2\":\"2\",\"header1\":\"1\"},\n"
								+ "{\"header2\":\"2\",\"header1\":\"2\"}\n"
								+ "]\n"));
	}

	@Test
    public final void testDefaultValuesForSecFuncdingBonds() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream,
                requestParameters);
        testClass.writeHeader(new String[] { "header1", "issue.assetClass", "derived.valueFactor", "derived.issueFactor"});
        testClass.writeLine(new String[] { "header1", "BOND", "", null });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tissue.assetClass\tderived.valueFactor\tderived.issueFactor");
        expected.append("\n");
        expected.append("header1\tBOND\t1\t100");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
	
	@Test
    public final void testDefaultValuesForSecFuncdingBondNotEmpty() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream,
                requestParameters);
        testClass.writeHeader(new String[] { "header1", "issue.assetClass", "derived.valueFactor", "derived.issueFactor"});
        testClass.writeLine(new String[] { "header1", "BOND", "2", "2" });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tissue.assetClass\tderived.valueFactor\tderived.issueFactor");
        expected.append("\n");
        expected.append("header1\tBOND\t2\t2");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
	
	@Test
    public final void testDefaultValuesForSecFuncdingEquity() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream,
                requestParameters);
        testClass.writeHeader(new String[] { "header1", "issue.assetClass", "derived.valueFactor", "derived.issueFactor"});
        testClass.writeLine(new String[] { "header1", "EQUITY", null, "" });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tissue.assetClass\tderived.valueFactor\tderived.issueFactor");
        expected.append("\n");
        expected.append("header1\tEQUITY\t1\t100");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
    
	@Test
    public final void testDefaultValuesForSecFuncdingEquityNotEmpty() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream, requestParameters);
        testClass.writeHeader(new String[] { "header1", "issue.assetClass", "derived.valueFactor", "derived.issueFactor"});
        testClass.writeLine(new String[] { "header1", "EQUITY", "2", "2" });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tissue.assetClass\tderived.valueFactor\tderived.issueFactor");
        expected.append("\n");
        expected.append("header1\tEQUITY\t2\t2");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
	
	@Test
    public final void testDerivedFieldIsin() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream, requestParameters);
        testClass.writeHeader(new String[] { "header1", "issue.isin", "derived.isin"});
        testClass.writeLine(new String[] { "header1", "isin", " " });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tissue.isin\tderived.isin");
        expected.append("\n");
        expected.append("header1\tisin\tisin");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
    
	@Test
    public final void testDerivedFieldCusip() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream, requestParameters);
        testClass.writeHeader(new String[] { "header1", "issue.cusip", "derived.cusip"});
        testClass.writeLine(new String[] { "header1", "test", " " });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tissue.cusip\tderived.cusip");
        expected.append("\n");
        expected.append("header1\ttest\ttest");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
    
	@Test
    public final void testDerivedFieldSedol() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream, requestParameters);
        testClass.writeHeader(new String[] { "header1", "tL.sedol", "derived.sedol"});
        testClass.writeLine(new String[] { "header1", "test", " " });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\ttL.sedol\tderived.sedol");
        expected.append("\n");
        expected.append("header1\ttest\ttest");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
    
	@Test
    public final void testDerivedFieldBondIssuerType() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream, requestParameters);
        testClass.writeHeader(new String[] { "header1", "issue.bondIssuerType", "derived.bondIssuerType"});
        testClass.writeLine(new String[] { "header1", "test", " " });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tissue.bondIssuerType\tderived.bondIssuerType");
        expected.append("\n");
        expected.append("header1\ttest\ttest");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
    
	@Test
    public final void testDerivedFieldCurrentCouponRate() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream, requestParameters);
        testClass.writeHeader(new String[] { "header1", "coupon.currentCouponRate", "derived.currentCouponRate"});
        testClass.writeLine(new String[] { "header1", "test", " " });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tcoupon.currentCouponRate\tderived.currentCouponRate");
        expected.append("\n");
        expected.append("header1\ttest\ttest");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
    
	@Test
    public final void testMinDenominatorEmpty() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream, requestParameters);
        testClass.writeHeader(new String[] { "header1", "issue.nominalValueOfUnit", "derived.minDenomination"});
        testClass.writeLine(new String[] { "header1", "", "" });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tissue.nominalValueOfUnit\tderived.minDenomination");
        expected.append("\n");
        expected.append("header1\t\t1000");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
	
	@Test
    public final void testMinDenominatorEmptyWithNominalValue() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream, requestParameters);
        testClass.writeHeader(new String[] { "header1", "coupon.currentCouponRate", "derived.minDenomination", "issue.nominalValueOfUnit"});
        testClass.writeLine(new String[] { "header1", "test", null, "5" });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tcoupon.currentCouponRate\tderived.minDenomination\tissue.nominalValueOfUnit");
        expected.append("\n");
        expected.append("header1\ttest\t1000\t5");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
    
	@Test
    public final void testMinDenominatorNotEmpty() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream, requestParameters);
        testClass.writeHeader(new String[] { "header1", "coupon.currentCouponRate", "derived.minDenomination"});
        testClass.writeLine(new String[] { "header1", "test", "5" });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tcoupon.currentCouponRate\tderived.minDenomination");
        expected.append("\n");
        expected.append("header1\ttest\t5");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
	
	@Test
    public final void testMinDenominatorGreaterThanNominalValueOfUnit() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream, requestParameters);
        testClass.writeHeader(new String[] { "header1", "issue.nominalValueOfUnit", "derived.minDenomination"});
        testClass.writeLine(new String[] { "header1", "99", "2000000" });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tissue.nominalValueOfUnit\tderived.minDenomination");
        expected.append("\n");
        expected.append("header1\t99\t2000000");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
    
	@Test
    public final void testDefaultMinDenominatorGreaterThanNominalValueOfUnit() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream, requestParameters);
        testClass.writeHeader(new String[] { "header1", "issue.nominalValueOfUnit", "derived.minDenomination"});
        testClass.writeLine(new String[] { "header1", "99", "" });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tissue.nominalValueOfUnit\tderived.minDenomination");
        expected.append("\n");
        expected.append("header1\t99\t1000");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
    
    @Test
    public final void testMinDenominatorWithInvalidNumber() throws Throwable {
        requestParameters.setResponseFormat("TEXT");

        testClass = ResponseFormatter.getInstance(responseStream, requestParameters);
        testClass.writeHeader(new String[] { "header1", "issue.nominalValueOfUnit", "derived.minDenomination"});
        testClass.writeLine(new String[] { "header1", "xx", "2000000" });
        testClass.close();
        StringBuilder expected = new StringBuilder();
        expected.append("header1\tissue.nominalValueOfUnit\tderived.minDenomination");
        expected.append("\n");
        expected.append("header1\txx\t2000000");
        expected.append("\n");
        assertEquals(expected.toString(), responseStream.toString());
    }
    
    @After
	public void tearDown() {
		testClass = null;
	}
}
