package com.ubs.idp.das.model;

import com.ubs.idp.base.StaticValues;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class SharedTest {

    public static final String ENCRYPTED_VALUE_PROP = "ENCRYPTED_VALUE";
    public static final String ENCRYPTED_VALUE = "ecbd77cb12f9e1ed1c2a444df5366d57";
    public static final String DECRYPTED_VALUE = "foobar";

    static {
		// No Shared constants to ensure these are set before Shared
		// initialization
		System.setProperty("SEED_HOSTS", "xstm5346vdap.stm.swissbank.com:9160");
		System.setProperty("REPLICATION_FACTOR", "2");
		System.setProperty("DISTINCT_LIMIT", "5000");
        System.setProperty(ENCRYPTED_VALUE_PROP, ENCRYPTED_VALUE);
        System.setProperty("CASSANDRA_PASSWORD", "48a7110effe85572ce8be20290f5bc55");
    }

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public final void testEscapeAndUnEscape() {
		String testString = "issue.shortName/kanji";
		String escString = "issue.shortName__kanji";
		String unEscString = Shared.formatHeader(escString);
		assertEquals(testString, unEscString);
	}

	// FIXME TeamCity issue has a delay for some odd reason
	// org.junit.ComparisonFailure: expected:<5.[0] s> but was:<5.[691] s>
	@Ignore
	@Test
	public final void testElapsedTime() {
		final double seconds = 5.0;
		final double minutes = 8.5;
		assertEquals(
				seconds + StaticValues.SPACE + Shared.SECONDS,
				Shared.elapsedTime((long) (System.currentTimeMillis() - seconds
						* Shared.MILLISECONDS_PER_SECOND)));
		assertEquals(
				minutes + StaticValues.SPACE + Shared.MINUTES,
				Shared.elapsedTime((long) (System.currentTimeMillis() - minutes
						* Shared.SECONDS_PER_MINUTE
						* Shared.MILLISECONDS_PER_SECOND)));
	}
}
