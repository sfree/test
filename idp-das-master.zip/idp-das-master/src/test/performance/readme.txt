C:\dev\Projects\workspace-distribution-v2\.metadata\.plugins\org.eclipse.debug.core\.launches\filegen-service.launch 
