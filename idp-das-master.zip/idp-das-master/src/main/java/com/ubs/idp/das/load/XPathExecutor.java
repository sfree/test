package com.ubs.idp.das.load;

import java.io.StringReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.xml.transform.stream.StreamSource;

import net.sf.saxon.s9api.Processor;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XPathCompiler;
import net.sf.saxon.s9api.XPathExecutable;
import net.sf.saxon.s9api.XPathSelector;
import net.sf.saxon.s9api.XdmItem;
import net.sf.saxon.s9api.XdmNode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Executes stored XPaths based on metadata model on XML message
 * 
 */
public class XPathExecutor implements Iterator<String> {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(XPathExecutor.class);
	private static final String DELIMITER = "\t";
	private final XPathCompiler xPathCompiler;
	private XdmNode xdmNode;
	private final Processor processor;
	private List<String> xPaths;
	private Iterator<String> scanner;
	private HashMap<String, String> namespaces;

	public XPathExecutor(List<String> xPaths,
			HashMap<String, String> namespaces, Iterator<String> scanner) {
		this.xPaths = xPaths;
		this.scanner = scanner;
		this.namespaces = namespaces;
		this.processor = LicensedSaxonProcessorProvider.getLicensedProcessor();
		this.xPathCompiler = getXpathCompilerWithNamespaces(processor
				.newXPathCompiler());
	}

	public Iterator<String> getFlatScanner() {
		return this;
	}

	@Override
	public boolean hasNext() {
		return scanner.hasNext();
	}

	@Override
	public String next() {
		StringBuilder buffer = new StringBuilder();
		XPathExecutable xPathExecutable = null;
		try {
			xdmNode = processor.newDocumentBuilder().build(
					new StreamSource(new StringReader(scanner.next().trim())));

			for (String xpath : xPaths) {
				xPathExecutable = xPathCompiler.compile(xpath);
				XPathSelector xPathSelector = xPathExecutable.load();
				xPathSelector.setContextItem(xdmNode);
				// TODO multiple
				// XdmValue resultNode = xPathSelector.evaluate();
				XdmItem resultNode = xPathSelector.evaluateSingle();
				if (resultNode != null && resultNode.size() != 0) {
					if (buffer.length() > 0) {
						buffer.append(DELIMITER);
					}
					buffer.append(resultNode.getStringValue());
				}
			}
		} catch (SaxonApiException e) {
			LOGGER.error(
					"XPathExecutable Failure: " + xPathExecutable.toString(), e);
			e.printStackTrace();
		}
		return buffer.toString();
	}

	@Override
	public void remove() {
	}

	/**
	 * @param xPathC
	 *            The XPathCompiler to compile XPathExecutables from
	 * @return the original XPathCompiler with namespaces declared
	 * @since MDF 1.0
	 */
	private XPathCompiler getXpathCompilerWithNamespaces(XPathCompiler xPathC) {
		if (namespaces != null) {
			for (String namespace : namespaces.keySet()) {
				xPathC.declareNamespace(namespace, namespaces.get(namespace));
			}
		}
		return xPathC;
	}

}