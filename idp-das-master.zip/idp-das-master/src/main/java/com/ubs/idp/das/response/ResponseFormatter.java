package com.ubs.idp.das.response;

import static com.ubs.idp.das.QueryServiceConfiguration.DISTINCT_LIMIT;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.http.MediaType;

import au.com.bytecode.opencsv.CSVWriter;

import com.ubs.idp.das.exception.FilegenException;
import com.ubs.idp.das.model.RequestParameters;
import com.ubs.idp.das.model.Shared;
import com.ubs.idp.das.model.Shared.ResponseFormat;

/**
 * Default TEXT formatter. Can be extended to support other formats
 * 
 * @author aigalsa
 * 
 */
public class ResponseFormatter {
	public static ObjectMapper mapper = new ObjectMapper();
	protected OutputStream outputStream;
	protected CSVWriter csvWriter;
	boolean distinct = false;
	Set<String> distinctSet = new HashSet<String>();

	static {
		mapper.configure(JsonGenerator.Feature.AUTO_CLOSE_TARGET, false);
		mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS, true);
	}

	ResponseFormatter() {
	}

	public static String getContentType(String requestFormat) {
		if (requestFormat == null || "TEXT".equals(requestFormat)) {
			return MediaType.TEXT_PLAIN_VALUE;
		} else if ("JSON".equals(requestFormat)) {
			return MediaType.APPLICATION_JSON_VALUE;
		} else if ("JSONARRAY".equals(requestFormat)) {
			return MediaType.APPLICATION_JSON_VALUE;
		} else if ("XML".equals(requestFormat)) {
			return MediaType.APPLICATION_XML_VALUE;
		}
		return MediaType.TEXT_PLAIN_VALUE;
	}

	public static ResponseFormatter getInstance(OutputStream outputStream,
			RequestParameters requestParameters) {
		if (ResponseFormat.TEXT.equals(requestParameters.getResponseFormat())) {
			return new TEXTFormatter(outputStream, requestParameters);
		} else if (ResponseFormat.JSON.equals(requestParameters
				.getResponseFormat())) {
			return new JSONFormatter(outputStream);
		} else if (ResponseFormat.JSONARRAY.equals(requestParameters
				.getResponseFormat())) {
			return new JSONArrayFormatter(outputStream);
		}
		throw new FilegenException(Shared.INVALID_FORMAT
				+ requestParameters.getResponseFormat());
	}

	public void writeHeader(String[] fields) throws Exception {
	}

	// must call at start when overridden to check if write allowed
	public boolean writeLine(String[] strArray) throws Exception {
		// distinct
		if (distinct && !distinctSet.add(Arrays.toString(strArray))) {
			return false;
		}
		if (distinctSet.size() > DISTINCT_LIMIT) {
			throw new FilegenException("Exceeded distinct limit: " + DISTINCT_LIMIT);
		}
		return true;
	}

	public void writeError(String message) throws Exception {
		outputStream.write(message.getBytes());
	}

	// must call at end when overridden
	public void close() throws IOException {
		outputStream.flush();
	}

	public boolean isDistinct() {
		return distinct;
	}

	public void setDistinct(boolean distinct) {
		this.distinct = distinct;
	}
}