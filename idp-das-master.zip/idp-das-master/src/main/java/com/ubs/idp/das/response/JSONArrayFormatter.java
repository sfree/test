package com.ubs.idp.das.response;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import com.ubs.idp.das.model.Shared;

public class JSONArrayFormatter extends PostFilter {
	String[] fields;
	Map<String, String> fieldsMap;
	boolean isFirst = true;

	public JSONArrayFormatter(OutputStream outputStream) {
		this.outputStream = outputStream;
	}

	@Override
	public void writeHeader(String[] fields) throws Exception {
	    super.writeHeader(fields);
		this.fields = fields;
		this.fieldsMap = new HashMap<String, String>(fields.length);
		outputStream.write(Shared.JSONARRAY_START_BYTEARRAY);
	}

	@Override
	public boolean writeLine(String[] strArray) throws Exception {
		synchronized (this) {
			if (super.writeLine(strArray)) {
				int i = 0;
				for (String field : fields) {
					fieldsMap.put(field, strArray[i++]);
				}
				if (isFirst) {
					outputStream.write(Shared.NEWLINE_BYTEARRAY);
				} else {
					outputStream.write(Shared.JSONARRAY_NEWLINE_BYTEARRAY);
				}
				mapper.writeValue(outputStream, fieldsMap);
				isFirst = false;
				return true;
			}
			return false;

		}
	}

	@Override
	public void close() throws IOException {
		outputStream.write(Shared.JSONARRAY_END_BYTEARRAY);
		super.close();
	}
}
