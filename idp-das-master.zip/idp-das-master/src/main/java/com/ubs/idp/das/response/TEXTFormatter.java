package com.ubs.idp.das.response;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import au.com.bytecode.opencsv.CSVWriter;

import com.ubs.idp.das.model.RequestParameters;

/**
 * Default TEXT formatter. Can be extended to support other formats
 * 
 * @author aigalsa
 * 
 */
public class TEXTFormatter extends PostFilter {
	public TEXTFormatter(OutputStream outputStream,
			RequestParameters requestParameters) {
		this.outputStream = outputStream;
		csvWriter = new CSVWriter(new OutputStreamWriter(
				new BufferedOutputStream(outputStream)), requestParameters
				.getDelimiter().charAt(0), requestParameters.getQuoteChar(),
				requestParameters.getEscapeChar());
	}

	@Override
	public void writeHeader(String[] fields) throws Exception {
		writeLine(fields);
	}

	@Override
	public boolean writeLine(String[] strArray) throws Exception {
		if (super.writeLine(strArray)) {
			csvWriter.writeNext(strArray);
			return true;
		}
		return false;
	}

	@Override
	public void close() throws IOException {
		csvWriter.flush();
		csvWriter.close();
		super.close();
	}
}