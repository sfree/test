package com.ubs.idp.das.model;

import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;

public class ResourceStats {
	AtomicLong requests = new AtomicLong();
	AtomicLong goodRows = new AtomicLong();
	AtomicLong badRows = new AtomicLong();
	AtomicLong failRows = new AtomicLong();
	AtomicLong elapsedTimeMillis = new AtomicLong();
	private Date startDate;

	public AtomicLong getRequests() {
		return requests;
	}

	public long getGoodRows() {
		return goodRows.get();
	}

	public long getBadRows() {
		return badRows.get();
	}

	public long getFailRows() {
		return failRows.get();
	}

	public void addRows(long numGoodRows, long numBadRows, long numFailRows) {
		requests.incrementAndGet();
		goodRows.addAndGet(numGoodRows);
		badRows.addAndGet(numBadRows);
		failRows.addAndGet(numFailRows);
	}

	public void addRows(long numGoodRows) {
		goodRows.addAndGet(numGoodRows);
	}

	public void setRows(long numGoodRows) {
		goodRows.set(numGoodRows);
	}

	public long getElapsedTimeMillis() {
		return elapsedTimeMillis.get();
	}

	public void addElapsedTimeMillis(long timeMillis) {
		elapsedTimeMillis.addAndGet(timeMillis);
	}

	public void setStartDateTime(Date startDate) {
		this.startDate = startDate;
	}

	public Date getStartDateTime() {
		return startDate;
	}
}
