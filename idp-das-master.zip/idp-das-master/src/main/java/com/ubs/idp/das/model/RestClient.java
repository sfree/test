package com.ubs.idp.das.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.ubs.idp.encrypt.Crypto;

@SuppressWarnings("deprecation")
public class RestClient {
	DefaultHttpClient httpClient;
	private static final String KEYSTORE_LOCATION = "/dsws-client-certs.dat";

	private static final String KEYSTORE_PASSWORD_ENCRYPTED = "abfae127b8aa5345b42d68e9d0eabb32";

	private static final String CONNECTING = "Connecting...";
	private static final int SECURE_PORT = 443;
	public static final String NEWLINE = "\n";

	public static void main(String[] args) throws Exception {
		// Request iDP Query Service
		String url = "http://xstm5371vdap.stm.swissbank.com:9990/v1/InstrumentSecFunding";
		// Uses IDP UAT credentials
		String rcasUrl = "https://rcas.smlogin.ibb.ubstest.net/loginrouter/rcas_v1_50";
		String rcasAppID = "RCAS_IDP";
		String username = "sso_idp";
		String password = "1b1a50dc5ac97cbd9c79c8b93ec5ceac";
		// Request parameters
		List<NameValuePair> params = new ArrayList<NameValuePair>(1);
		params.add(new BasicNameValuePair("fields", "issue.isin,issue.ubsId"));
		params.add(new BasicNameValuePair("issue.isin", "USY20721AU39,US912810QT88,FR0011008705,US718286AK32,US9128335A44,IT0004965080,US912828VZ00,XS0532728788,US45950KBQ22,US912810QL52,USY9485PAA04,XS0971575880,XS0261559594,DE0001142651,DE0001143428,US195325BE41,GB00B84Z9V04,GB0000515360,XS0831353361,US29843YAB11,US75970QAH39,US80281CAH88,US912796BJ77,XS0214102179,IE00B60Z6194,IT0001247409,US603674AA04,US195325BM66,IT0004890890,GR0138013793,SI0002103065,US912833KQ23,US836205AR58,XS0226233384,US912803EC31,US831594AD88,US912833Z609,DE0001143436,XS0157418137,US912828KS85,DE0001142669,US518417AA89,XS0501195993,XS0748631164,USP3579EAH01,GB0002443694,US912833KZ22,XS0882814386,US930815AA35,BE0000304130,BE0312713820,US912803DZ35,USP06518AF40,ES0000011900,FR0010172478,US912834AU28,SI0002103057,XS0537659632,US536878AD31,FR0121616116,XS0223923870,USP8055QDE90,USY68617AA05,US912833LR96,US105756BM14,US912828SV33,GR0128014710,DE0001142677,GB0004893086,XS0997000251,US917288BA96,DE0001143444,US912820RE90,ES0000011918,US105756AZ36,XS0342993747,GR0138011771,US912810QD37,US105756BU30,US912828SD35,US912828MF47,USP17625AC16,XS0543783434,US045167BJ10,US912833KH24,USP01012AR71,US698299AK07,DE0001142685,GB00B4PTCY75,US912828MV96,DE0001143451,US912828B741,US912833PB09,US912828SN17,US04317NAE94,US912828VJ67,FR0121616108,US067070AF98,US912828UU22,BE0008057060,IT0004907843,US843646AF71,XS0750894577,US060505BM56,GB0002442951,GB0032728064,XS0035901601,FR0010809616,NL0009213651,GB00B4YRFP41,KR31010172C6,US912828A677,US298785FS04,US912796DG11,US718286BL06,XS0219724878,US912828UL23,EU000A1AKD47,US445545AC05,ES0000011892,DE0001142693,FR0010172494,KR3101017340,USX34650AA31,US912828VR83,PTOTELOE0010,FR0010809608,US900123CF53,US912796CL15,XS0159582195,US912828RM43,FR0010773192,XS0192595873,US066716AB78,US912828UE89,US105756AL40,US445545AL04,XS1028901673,XS0498285351,IT0004286966,XS0864511588,US912810RA88,FR0011337880,US455780AS59,US045167CE14,XS0856951263,XS0772910831,XS0530302628,XS0750692864,XS0765619407,KR1017014FC8,US91086QBC15,BE0000325341,JP1150411674,US10138MAG06,FR0010810093,US4581X0BS66,US912803CX95,US912828PP91,FR0010809640,US715638AQ52,US912834MM73,XS0638326263,AT0000386115,US912803DK65,DE0001143402,XS0132108704,US718286BE62,IT0004164775,XS0454897363,FR0010235176,USP16394AF89,US226775AB01,USY8793YAK83,DE0003527966,US900123BE97,US15238PAC05,XS0192840006,US912828VB32,XS0249458984,FR0010809624,XS0190291582,FR0010809632,FR0010810077,DE0001143410,US168863BP27,US912828LU23,US912796DL06,XS0638742485,IT0003242747,US85227SAK24,XS0692728511,US912828EW61,US219868BL92,XS0219107918,XS0546424077,EU000A1G1Q17,XS0096856421,FR0010809533,US445545AK21,DE0001143394,US698299AW45,ES0000011967,XS0115748401,US912803DY69,US74727PAP62,IT0001246807,GB00BBDR7T29,IT0003844534,BE0312708770,XS0327304001,ES0000012650,GB00B09JC451,FR0010809541,DE0001143386,KR310101A431,FR0010810069,XS0183637635,US912810EP94,XS0333225000,US912810FM54,US912828TE09,ES0000011975,GB0032728957,US912796DK23,XS0543425358,BE0008052012,GB0009141671,IE0034074488,FR0010810036,US857524AB80,US912796CF47,ARARGE03G688,US62987BAA08,US912810EZ76,KR3101017324,US912834EC83,US45950VCP94,ES0000011991,NL0010060257,USP14486AC11,FR0010810044,US912803DT74,FR0010809566,FR0010809558,IT0001246815,XS0505478684,XS0113708969,US836205AP92,US718286BD89,US91086QBB32,FR0010810010,DE0001143352,FR0010809574,GB00B3LZBF68,GR0000118217,XS0196448129,US052591AW40,US912828TW07,US233851AH73,ES0000012627,ES0000011926,XS0905659230,DE0001143360,IE00B4W2SW95,RO1115DBE025,US912810EH78,DE0001143345,XS0501195134,US29843YAA38,GB0000514280,US15238RAD44,XS0035906402,US455780AY28,JP1050941B26,ES0000011934,ES0000012619"));
		BufferedReader inputReader = new RestClient(rcasUrl, rcasAppID, username, password).queryServiceWebSSOURL(url, params);

		// Data file
		String line = null;
		BufferedWriter fileWriter = new BufferedWriter(new FileWriter(
				"queryService.out"));
		while ((line = inputReader.readLine()) != null) {
			fileWriter.write(line + NEWLINE);
		}

		// Close streams
		inputReader.close();
		fileWriter.flush();
		fileWriter.close();
	}

	public RestClient(String rcasUrl, String rcasAppID, String username, String password) throws Exception {
		// --------------------------------------------------------------------
		// Prepare keystore
		// (UBS has self-signed certs so we should use special keystore)
		// --------------------------------------------------------------------

		// Load keystore
		KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());

		InputStream inputStream = RestClient.class
				.getResourceAsStream(KEYSTORE_LOCATION);
		try {
            String keystorePassword = Crypto.decrypt(KEYSTORE_PASSWORD_ENCRYPTED);
			trustStore.load(inputStream, keystorePassword.toCharArray());
		} finally {
			inputStream.close();
		}

		// SSL scheme
		SSLSocketFactory socketFactory = new SSLSocketFactory(trustStore);
		Scheme sslScheme = new Scheme("https", socketFactory, SECURE_PORT);

		// --------------------------------------------------------------------
		// Create http client
		// --------------------------------------------------------------------

		AuthScope authScope = new AuthScope(AuthScope.ANY_HOST,
				AuthScope.ANY_PORT);

		Credentials credentials = new UsernamePasswordCredentials(username,
				Crypto.decrypt(password));

		httpClient = new DefaultHttpClient();
		httpClient.getConnectionManager().getSchemeRegistry()
				.register(sslScheme);
		httpClient.getCredentialsProvider().setCredentials(authScope,
				credentials);
		httpClient.getParams().setBooleanParameter(
				"http.authentication.preemptive", true);
		httpClient.getParams().setBooleanParameter(
				ClientPNames.ALLOW_CIRCULAR_REDIRECTS, true);
		httpClient.getParams().setBooleanParameter(
				ClientPNames.HANDLE_REDIRECTS, true);
		httpClient.getParams().setParameter(ClientPNames.COOKIE_POLICY,
				CookiePolicy.BROWSER_COMPATIBILITY);

		// --------------------------------------------------------------------
		// Make RCAS authentication call
		// --------------------------------------------------------------------

		HttpGet initialGet = new HttpGet(rcasUrl + "?appid="
				+ rcasAppID);

		HttpResponse response = httpClient.execute(initialGet);

		int statusCode = response.getStatusLine().getStatusCode();
		if (statusCode != HttpStatus.SC_OK) {
			throw new IOException(String.format(
					"Authentication failed. Reason: %s, code: %d", response
							.getStatusLine().getReasonPhrase(), statusCode));
		}

		HttpEntity entity = response.getEntity();
		if (entity == null) {
			throw new IOException("Authentication failed. Response is empty");
		}

		EntityUtils.consumeQuietly(entity);
	}

	/**
	 * GET / POST request on dataUrl. If params specified method will be POST else GET.
	 * @param dataUrl
	 * @param params request parameters (POST only)
	 * @return
	 * @throws Exception
	 */
	public BufferedReader queryServiceWebSSOURL(String dataUrl, List<NameValuePair> params)
			throws Exception {

		System.out.println(CONNECTING + dataUrl);

		HttpUriRequest request = null;

		// GET / POST to get data
		// http://confluence.swissbank.com/display/IDP/Query+Service
		if(params == null) { // GET
			request = new HttpGet(dataUrl);
		} else { // POST
			// Dummy GET homepage because SiteMinder can't handle first POST request
			request = new HttpGet(dataUrl.substring(0, dataUrl.indexOf("/v1/")));
			HttpResponse httpDataResponse = httpClient.execute(request);
			// Check result code
			int dataStatusCode = httpDataResponse.getStatusLine().getStatusCode();
			if (dataStatusCode != HttpStatus.SC_OK) {
				EntityUtils.consumeQuietly(httpDataResponse.getEntity());
				throw new IOException(String.format(
						"Data request failed with code [%d] and message [%s] ",
						dataStatusCode, httpDataResponse.getStatusLine()
								.getReasonPhrase()));
			}
			EntityUtils.consumeQuietly(httpDataResponse.getEntity());

			request = new HttpPost(dataUrl);
			((HttpPost)request).setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
		}

		HttpResponse httpDataResponse = httpClient.execute(request);

		// Check result code
		int dataStatusCode = httpDataResponse.getStatusLine().getStatusCode();
		if (dataStatusCode != HttpStatus.SC_OK) {
			EntityUtils.consumeQuietly(httpDataResponse.getEntity());
			throw new IOException(String.format(
					"Data request failed with code [%d] and message [%s] ",
					dataStatusCode, httpDataResponse.getStatusLine()
							.getReasonPhrase()));
		}

		// Check content
		HttpEntity httpDataEntity = httpDataResponse.getEntity();
		if (httpDataEntity == null) {
			throw new IOException("Data response is empty");
		}
		// return buffered reader for content
		InputStream dataInputStream = httpDataEntity.getContent();
		return new BufferedReader(new InputStreamReader(dataInputStream));
	}
}
