package com.ubs.idp.das.model;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value = "singleton")
public class HUFSFileSystem implements FileSystem {

	public DataOutputStream createFile(String fileName) throws IOException {
		return new DataOutputStream(new FileOutputStream(new File(fileName)));
	}
}