package com.ubs.idp.das.exception;

public class FilegenException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5009412490857755257L;

	public FilegenException(String message) {
		super(message);
	}

	public FilegenException(String message, Throwable throwable) {
		super(message, throwable);
	}
}