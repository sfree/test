package com.ubs.idp.das.webservice;

import static com.ubs.idp.das.model.Shared.getSystemOrConfigProperty;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.ubs.idp.das.model.Shared;

/**
 * Spring MVC Interceptor for authentication and common tasks
 * 
 * @author aigalsa
 * 
 */
public class AuthenticationInterceptor extends HandlerInterceptorAdapter {

	private static final String IDP_SECRET_WORD = getSystemOrConfigProperty(Shared.IDP_SECRET_WORD);

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		if (IDP_SECRET_WORD != null
				&& !IDP_SECRET_WORD.equals(request
						.getHeader(Shared.IDP_SECRET_WORD))) {
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			return false;
		}
		return true;
	}
}
