package com.ubs.idp.das.cassandra;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import me.prettyprint.cassandra.service.ColumnSliceIterator;
import me.prettyprint.hector.api.beans.ColumnSlice;
import me.prettyprint.hector.api.beans.HColumn;
import me.prettyprint.hector.api.beans.Rows;
import me.prettyprint.hector.api.query.QueryResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import au.com.bytecode.opencsv.CSVWriter;

import com.ubs.idp.base.StaticValues;
import com.ubs.idp.das.Common;
import com.ubs.idp.das.QueryServiceConfiguration;
import com.ubs.idp.das.exception.FilegenException;
import com.ubs.idp.das.model.RequestParameters;
import com.ubs.idp.das.model.Shared;
import com.ubs.idp.das.model.Stats;
import com.ubs.idp.das.response.ResponseFormatter;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.model.JoinRelation;
import com.ubs.idp.metadata.model.PhysicalDataset;
import com.ubs.idp.metadata.model.exceptions.MetadataException;

@Component
public class CassandraFilter {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(CassandraFilter.class);
    
    private static final String TERMINATED_START = "Terminated (timeout = ";
    private static final String TERMINATED_END = "): ";
    private static final int TIMEOUT = 1;
    private static final TimeUnit UNIT = TimeUnit.HOURS;
    private static final String UNCONFIGURED_COLUMN_FAMILY = "me.prettyprint.hector.api.exceptions.HInvalidRequestException: InvalidRequestException(why:unconfigured columnfamily ";
    private static final String NO_INDEX_MESSAGE = "No index found: ";
    private static final int DEFAULT_LINE_LENGTH = 1000;
    private static final Map<Integer, String> SPECIALCODEVALUE = getSpecialCodeValueMap();
    private static final String JOIN_KEYS_NOT_DEFINED = "Join keys not defined: ";
    private static final String JOIN_KEY_INVALID = "Join key invalid: ";

    private HashMap<String, String> blankOutputFieldsMap = new HashMap<String, String>();

    @Autowired
    @Qualifier("queryServiceConfiguration")
    private QueryServiceConfiguration queryServiceConfiguration;

    @Autowired
    @Qualifier("mdsClient")
    private MetadataService metadataService;

    @Autowired
    @Qualifier("cassandraWrapper")
    private Cassandra cassandraWrapper;

    @Autowired
    private Stats stats;
    public static String nonIndexedQueryDataset;

    public int execute(OutputStream outputStream, Map<String, String[]> parameterMap, String... args) throws Throwable {
        long startTime = System.currentTimeMillis();
        final String viewName = args[0];

        RequestParameters requestParameters = null;
        try {
            // Validate View
            if (metadataService.getDelimiter(viewName) == null) {
                throw new FilegenException(Shared.INVALID_VIEW_MESSAGE + viewName);
            }
            // Get the required files from model (considers unions/joins)
            List<JoinRelation> joinRelations = metadataService.getJoinRelationsForDataset(viewName);

            // Parse filters, fields, union (filters & fields) and delimiters
            requestParameters = parseRequestParameterMap(parameterMap, joinRelations, viewName);
            final ResponseFormatter responseFormatter = ResponseFormatter.getInstance(outputStream, requestParameters);

            // Invalid field check
            if (!requestParameters.getInvalidFieldsList().isEmpty()) {
                responseFormatter.writeError(Shared.INVALID_FIELD_MESSAGE + requestParameters.getInvalidFieldsList().get(0));
                throw new FilegenException(Shared.INVALID_FIELD_MESSAGE + requestParameters.getInvalidFieldsList().get(0));
            }

            // If include input
            if (Shared.isYes(requestParameters.getIncludeInput())) {
                responseFormatter.writeLine(new String[] { args[1] });
            }

            // Write header
            if (!Shared.isYes(requestParameters.getHideHeader())) {
                responseFormatter.writeHeader(requestParameters.getFields());
            }

            // distinct
            if (Shared.isYes(requestParameters.getDistinct())) {
                responseFormatter.setDistinct(true);
            }
                        
            AtomicInteger readRowCount = new AtomicInteger(0);
            
            List<String> unionParamValues = requestParameters.getUnionParamValues();

            // union will atleast have 2 values
            int numOfQuery = (unionParamValues!=null) ? (unionParamValues.size()-1) : 0;
            final boolean isUnionQuery = (numOfQuery > 0) ?  true : false ;
            
            String paramValue=null;
            
            do{
            	
            	if(isUnionQuery){
            		paramValue = unionParamValues.get(numOfQuery);
            		requestParameters.getFilterIds().add(paramValue);
            	}
            	
	            // e.g.
	            // [DSCURRENCY.IDP_RATING.IDP,MTS.IDP,BONDISSUE.IDP_BONDTL.IDP_RATING.IDP,EQUITY.IDP_RATING.IDP]
	            for (JoinRelation joinRelation : joinRelations) {
	                processJoinFile(requestParameters, joinRelation, readRowCount, responseFormatter);
	            }
	            
	            // Write ERROR rows for lookup keys that were not found
	            if (requestParameters.isIDPStatusLookup()) {
	                writeUnmatchedLookupKeys(requestParameters.getLookupKeys(), requestParameters.getLookupAttribute(),
	                        requestParameters.getFields(), responseFormatter);
	            }	            	           
	            
            	if(isUnionQuery){
            		
            		requestParameters.getFilterIds().remove(paramValue);             		
            	}
	            
            	numOfQuery--;
            	
            }while(numOfQuery >= 0);
            
            responseFormatter.close();
            
            // set stats
            stats.addQueryStats(viewName, readRowCount.longValue(), System.currentTimeMillis() - startTime);

            return readRowCount.get();
        } catch (Throwable t) {
            if (t instanceof me.prettyprint.hector.api.exceptions.HInvalidRequestException
                    && t.toString().startsWith(UNCONFIGURED_COLUMN_FAMILY)) {
                throw new FilegenException(NO_INDEX_MESSAGE + t.getMessage());
            } else {
                throw t;
            }
        }
    }

    public void processJoinFile(RequestParameters requestParameters, JoinRelation joinRelation, AtomicInteger readRowCount,
            ResponseFormatter responseFormatter) throws Exception {

        // e.g. [BONDISSUE.IDP, BONDTL.IDP, RATING.IDP]
        List<PhysicalDataset> physicalDatasets = joinRelation.getOrderedDatasets();

        // Find dataset to which an index can apply
        int indexApplicableDataset = findIndexApplicableDataset(physicalDatasets, requestParameters.getFilterIds());

        // Optimize - if possible, swap so that an index applies to first
        // dataset
        if (indexApplicableDataset != 0) {
            PhysicalDataset temp = physicalDatasets.get(0);
            physicalDatasets.set(0, physicalDatasets.get(indexApplicableDataset));
            physicalDatasets.set(indexApplicableDataset, temp);
        }

        // Filter fields positions
        Map<Integer, String> filterAttributeNameMap = new HashMap<Integer, String>();
        Map<Integer, String> filterPositionOperatorMap = new HashMap<Integer, String>();
        Map<Integer, String> filterPositionValueMap = new HashMap<Integer, String>();

        for (String filterKeyValue : requestParameters.getFilterIds()) {
            String[] parsedKeyValue = Shared.parseByOperator(filterKeyValue);
            String attribute = parsedKeyValue[0];
            String operator = parsedKeyValue[1];
            String value = parsedKeyValue[2];

            // Skip filter if conditional filter doesn't apply to this dataset
            if (value.charAt(0) == '(') {
                int rightParenthesis = value.indexOf(')');
                if (rightParenthesis != -1 && rightParenthesis > 1) {
                    String conditionalDatasets = value.substring(1, rightParenthesis);
                    boolean isSkip = true;
                    for (PhysicalDataset physicalDataset : physicalDatasets) {
                        if (conditionalDatasets.indexOf(physicalDataset.id) != -1) { // Assuming
                                                                                     // non-empty
                                                                                     // datasetId
                            isSkip = false;
                            break;
                        }
                    }
                    // Skip filter
                    if (isSkip) {
                        continue;
                    }
                    // Remove dataset name "(BONDTL.IDP)Y" => "Y"
                    value = value.substring(rightParenthesis + 1);
                }
            }

            // NULL is reserved keyword for blanks
            String newValue = Common.BLANK;
            Scanner valuesScanner = new Scanner(value);
            valuesScanner.useDelimiter(Shared.VALUESDELIMITER);
            while (valuesScanner.hasNext()) { // CSV in clause
                String scannedValue = valuesScanner.next();
                if (Shared.NULL.equals(scannedValue)) {
                    scannedValue = Common.BLANK;
                }
                newValue += scannedValue;
                if (valuesScanner.hasNext()) {
                    newValue += Shared.VALUESDELIMITER;
                }
            }
            valuesScanner.close();
            value = newValue;

            // Skip dataset if filter field doesn't apply
            int fieldPosition = getFieldPositionInJoinRelation(physicalDatasets, attribute);
            if (fieldPosition == -1) {
                return;
            }
            filterAttributeNameMap.put(fieldPosition, attribute);
            filterPositionOperatorMap.put(fieldPosition, operator);
            filterPositionValueMap.put(fieldPosition, value);
        }

        // Compute left and right join positions for all datasets
        int noOfDatasets = physicalDatasets.size();
        int[] leftJoinAttributePositions = new int[noOfDatasets];
        int[] rightReverseIndexPositions = new int[noOfDatasets];
        boolean isKeyJoin = true;
        int i = 0;
        Map <String,Integer> datasetOffsets = new HashMap<String,Integer>(); 
        
        for (PhysicalDataset physicalDataset : physicalDatasets) {
            /*
             * If there is no tableId specified in the metadata then this
             * dataset definition is not persisted in Cassandra and therefore
             * not available
             */
            if (physicalDataset.tableId == null || physicalDataset.tableId.trim().length() == 0) {
                throw new FilegenException(
                        Shared.INVALID_VIEW_MESSAGE
                                + "The requested resource "
                                + physicalDataset.id
                                + " does not exist in the Cassandra datasource. This maybe because you you are querying a source dataset rather than an IDP specific (.IDP) dataset.\nDetailed Message: The metadata for this dataset does not have a 'tableId' property set.");
            }

            // Calculate offset in joined datasets
            datasetOffsets.put(physicalDataset.id,metadataService.getAttributeNamesForDataset(physicalDataset.id).size());
            
            // Get join key positions, if different from row key (-1 if same)
            if (i == 0) {
                leftJoinAttributePositions[i] = -1;
                rightReverseIndexPositions[i] = -1;
            } else {
            	
            	int[] leftAndRightJoinAttributePositions = null;
            	int positionOffset =0;
            	
            	String joinDatasetName = null;
            	
            	// For current dataset (n) find the first defined join key from 0 to n-1				
            	for (int j = 0; j < i; j++) {
            		try {
            									
            			leftAndRightJoinAttributePositions = getLeftAndRightJoinAttributePositions(
            					physicalDatasets.get(j).id, physicalDataset.id);
            			joinDatasetName = physicalDatasets.get(j).id;
            			break;
            		
            		} catch (MetadataException me) {
            			
            			positionOffset = positionOffset + datasetOffsets.get(physicalDatasets.get(j).id);
            			
            			// if last dataset, then nothing matches so throw exception
            			if(j == i-1) {
            				throw me;	
            			}
            		}
            	}
            	
            	if(positionOffset > 0 && leftAndRightJoinAttributePositions[0]==-1 ){
            		//List<String> keyNames  = metadataService.getDatasetKeyAttributeNames(); 
            		int offset = metadataService.getDatasetKeyAttributePositions(joinDatasetName).get(0);
            		leftJoinAttributePositions[i] = positionOffset+offset;
            	}else{
            		leftJoinAttributePositions[i] = positionOffset + leftAndRightJoinAttributePositions[0];
            	}
            	
            	rightReverseIndexPositions[i] = leftAndRightJoinAttributePositions[1];
            	
                if (leftJoinAttributePositions[i] != -1 || rightReverseIndexPositions[i] != -1) {
                    isKeyJoin = false;
                }
            }
            i++;
        }

        // Fast join if key based
        if (isKeyJoin) {
            leftJoinAttributePositions = null;
            rightReverseIndexPositions = null;
        }

        // Output fields positions
        final int[] outputFieldPositions = new int[requestParameters.getFields().length];
        int j = 0;
        for (String field : requestParameters.getFields()) {
            outputFieldPositions[j++] = getFieldPositionInJoinRelation(physicalDatasets, field);
        }

        filterFromCF(requestParameters, physicalDatasets, leftJoinAttributePositions, rightReverseIndexPositions, filterAttributeNameMap,
                filterPositionValueMap, filterPositionOperatorMap, outputFieldPositions, responseFormatter, readRowCount);
    }

    private int findIndexApplicableDataset(List<PhysicalDataset> physicalDatasets, List<String> filterIds) {
        int i = 0;
        for (PhysicalDataset physicalDataset : physicalDatasets) {
            List<Integer> queryableAttributePositions = metadataService.getQueryableAttributePositionsForDataset(physicalDataset.id);
            List<String> attributes = metadataService.getAttributeNamesForDataset(physicalDataset.id);

            for (String filterKeyValue : filterIds) {
                String[] parsedKeyValue = Shared.parseByOperator(filterKeyValue);
                String attribute = parsedKeyValue[0];
                Integer filterPosition = attributes.indexOf(attribute);
                // If filter attribute exists in dataset
                if (filterPosition != -1) {
                    // and if filter attribute is queryable
                    if (queryableAttributePositions.contains(filterPosition)) {
                        return i;
                    }
                }
            }
            i++;
        }
        return 0; // Default to first dataset
    }

    private void writeUnmatchedLookupKeys(Set<String> lookupKeySet, String lookupField, String[] fields, ResponseFormatter responseFormatter)
            throws Exception {
        if (lookupKeySet != null) {
            String[] outputValuesArray = new String[fields.length];
            int lookupFieldPosition = -1;
            int idpStatusFieldPosition = -1;
            // Get positions for IDP_STATUS and lookup fields
            for (int i = 0; i < fields.length; i++) {
                if (Shared.IDP_STATUS.equals(fields[i])) {
                    idpStatusFieldPosition = i;
                } else if (lookupField.equals(fields[i])) {
                    lookupFieldPosition = i;
                }
            }

            for (String lookupKey : lookupKeySet) {
                if (lookupKey != null) {
                    outputValuesArray[idpStatusFieldPosition] = Common.STATUS_ERROR;
                    if (lookupFieldPosition != -1) {
                        outputValuesArray[lookupFieldPosition] = lookupKey;
                    }
                    responseFormatter.writeLine(outputValuesArray);
                }
            }
        }
    }

    public void filterFromCF(RequestParameters requestParameters, final List<PhysicalDataset> physicalDatasets,
            final int[] leftJoinAttributePositions, final int[] rightReverseIndexPositions, Map<Integer, String> filterAttributeNameMap,
            Map<Integer, String> filterPositionValueMap, Map<Integer, String> filterPositionOperatorMap, final int[] outputFieldPositions,
            final ResponseFormatter responseFormatter, final AtomicInteger readRowCount) throws Exception {
        // Default to all if no filter
        String reverseIndexCF = physicalDatasets.get(0).tableId + Shared.CASSANDRA_INDEX_NAME_SEPARATOR; // default
                                                                                                         // -
                                                                                                         // all
                                                                                                         // keys
                                                                                                         // CF
                                                                                                         // (e.g.
                                                                                                         // BONDISSUE_)
        Set<String> lookupKeySet = new HashSet<String>();
        lookupKeySet.add(physicalDatasets.get(0).tableId); // default - all keys
                                                           // wide row (e.g.
                                                           // BONDISSUE_ =>
                                                           // BONDISSUE row)

        requestParameters.isNonIndexedQuery = true; // Reset for each dataset

        // Use the index for the first queryable filter attribute
        List<Integer> queryableAttributePositions = metadataService.getQueryableAttributePositionsForDataset(physicalDatasets.get(0).id);
        for (Integer filterPosition : filterPositionValueMap.keySet()) {
            if (queryableAttributePositions.contains(filterPosition)) {

                reverseIndexCF += filterPosition;
                lookupKeySet = queryServiceConfiguration.parseCSVToSet(filterPositionValueMap.get(filterPosition));
                requestParameters.isNonIndexedQuery = false;

                // if lookup (IDP_STATUS or unionExclusive). INITIALIZED ONLY
                // ONCE - for the first dataset
                if ((requestParameters.isIDPStatusLookup() || requestParameters.isUnionExclusiveLookup())
                        && requestParameters.getLookupKeys() == null && lookupKeySet != null) {
                    requestParameters.setLookupAttribute(filterAttributeNameMap.get(filterPosition));
                    requestParameters.setLookupKeys(new HashSet<String>(lookupKeySet));
                }

                filterPositionValueMap.remove(filterPosition);
                filterPositionOperatorMap.remove(filterPosition);
                break;
            }
        }

        // Ensure lookup IDs specified for IDP_STATUS / unionExclusive
        if ((requestParameters.isIDPStatusLookup() || requestParameters.isUnionExclusiveLookup())
                && requestParameters.getLookupKeys() == null) {
            throw new FilegenException(Shared.NO_LOOKUP_IDS);
        }

        // unionExclusive - Only lookup keys that haven't been found so far
        if (requestParameters.isUnionExclusiveLookup()) {
            lookupKeySet = new HashSet<String>(requestParameters.getLookupKeys());
        }

        // Non-indexed query check
        if (requestParameters.isNonIndexedQuery) {
            if (nonIndexedQueryDataset != null) {
                responseFormatter.writeError(Shared.NON_INDEXED_QUERY_IN_PROGRESS + nonIndexedQueryDataset);
                throw new FilegenException(Shared.NON_INDEXED_QUERY_IN_PROGRESS + nonIndexedQueryDataset);
            }
            nonIndexedQueryDataset = requestParameters.viewName;
        }

        try {
            // TODO common thread pool. (semaphore) or presto?
            ExecutorService executorService = new ThreadPoolExecutor(queryServiceConfiguration.getReadThreadCorePoolSize(),
                    queryServiceConfiguration.getReadThreadMaxPoolSize(), 100000, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<Runnable>(
                            queryServiceConfiguration.getReadThreadQueueSize()), Executors.defaultThreadFactory(),
                    new ThreadPoolExecutor.CallerRunsPolicy());

            int rowCount = 0;
            for (String lookupKey : lookupKeySet) {
                ColumnSliceIterator<String, String, String> sliceIterator = cassandraWrapper.createColumnSliceIterator(reverseIndexCF,
                        StaticValues.BLANK.equals(lookupKey) ? StaticValues.BLANK_KEY : lookupKey, null, Shared.MAX_KEY,
                        queryServiceConfiguration.getReadBatchSize());

                if (sliceIterator != null) {
                    String[] keyArray = new String[queryServiceConfiguration.getReadBatchSize()];
                    for (rowCount = 0; sliceIterator.hasNext() && readRowCount.get() < requestParameters.getLimit(); rowCount++) {
                        keyArray[rowCount % queryServiceConfiguration.getReadBatchSize()] = sliceIterator.next().getName();
                        if ((rowCount + 1) % queryServiceConfiguration.getReadBatchSize() == 0 || !sliceIterator.hasNext()) {
                            final String[] keyArrayCopy = keyArray;
                            keyArray = new String[queryServiceConfiguration.getReadBatchSize()];
                            // Fast multi-get for key joins
                            if (leftJoinAttributePositions == null) {
                                executorService.execute(new FastKeyParallel(requestParameters, lookupKey, responseFormatter, keyArrayCopy,
                                        physicalDatasets, filterPositionValueMap, filterPositionOperatorMap, outputFieldPositions,
                                        readRowCount));
                            }
                            // Line by line gets for non-key joins
                            else {
                                executorService.execute(new SlowNonKeyParallel(requestParameters, lookupKey, responseFormatter,
                                        keyArrayCopy, physicalDatasets, leftJoinAttributePositions, rightReverseIndexPositions,
                                        filterPositionValueMap, filterPositionOperatorMap, outputFieldPositions, readRowCount));
                            }
                        }
                    }
                }
            }
            executorService.shutdown();

            if (!executorService.awaitTermination(TIMEOUT, UNIT)) {
                LOGGER.error(TERMINATED_START + TIMEOUT + StaticValues.SPACE + UNIT + TERMINATED_END + new Date());
                executorService.shutdownNow();
                throw new FilegenException(TERMINATED_START + TIMEOUT + StaticValues.SPACE + UNIT + TERMINATED_END + new Date());
            }
        } finally {
            // Non-indexed query check - Reset when done
            if (requestParameters != null && requestParameters.isNonIndexedQuery) {
                nonIndexedQueryDataset = null;
            }
        }
    }

    class SlowNonKeyParallel implements Runnable {
        RequestParameters requestParameters;
        String lookupKey;
        ResponseFormatter responseFormatter;
        String[] keyArray;
        List<PhysicalDataset> physicalDatasets;
        int[] leftJoinAttributePositions;
        int[] rightReverseIndexPositions;
        Map<Integer, String> filterPositionValueMap;
        Map<Integer, String> filterPositionOperatorMap;
        int[] outputFieldPositions;
        AtomicInteger readRowCount;

        SlowNonKeyParallel(RequestParameters requestParameters, String lookupKey, ResponseFormatter responseFormatter, String[] keyArray,
                List<PhysicalDataset> physicalDatasets, int[] leftJoinAttributePositions, int[] rightReverseIndexPositions,
                Map<Integer, String> filterPositionValueMap, Map<Integer, String> filterPositionOperatorMap, int[] outputFieldPositions,
                AtomicInteger readRowCount) {
            this.requestParameters = requestParameters;
            this.lookupKey = lookupKey;
            this.responseFormatter = responseFormatter;
            this.keyArray = keyArray;
            this.physicalDatasets = physicalDatasets;
            this.leftJoinAttributePositions = leftJoinAttributePositions;
            this.rightReverseIndexPositions = rightReverseIndexPositions;
            this.filterPositionValueMap = filterPositionValueMap;
            this.filterPositionOperatorMap = filterPositionOperatorMap;
            this.outputFieldPositions = outputFieldPositions;
            this.readRowCount = readRowCount;
        }

        @Override
        public void run() {
            try {
                getSlowNonKeyParallel(requestParameters, lookupKey, responseFormatter, keyArray, physicalDatasets,
                        leftJoinAttributePositions, rightReverseIndexPositions, filterPositionValueMap, filterPositionOperatorMap,
                        outputFieldPositions, readRowCount);
            } catch (Throwable e) {
                LOGGER.error(e.getMessage(), e);
            }
        }
    }

    private void getSlowNonKeyParallel(RequestParameters requestParameters, String lookupKey, ResponseFormatter responseFormatter,
            String[] keyArray, List<PhysicalDataset> physicalDatasets, int[] leftJoinAttributePositions, int[] rightReverseIndexPositions,
            Map<Integer, String> filterPositionValueMap, Map<Integer, String> filterPositionOperatorMap, int[] outputFieldPositions,
            AtomicInteger readRowCount) throws Exception {
        // Bulk load left dataset
        QueryResult<Rows<String, String, String>> leftResult = cassandraWrapper.executeMultigetSliceQuery(physicalDatasets.get(0).tableId,
                physicalDatasets.get(0).tableId, keyArray);
        // Run join algo on each left line
        for (String key : keyArray) {
            if (key == null) {
                break;
            }
            // Read each line from left dataset
            StringBuilder line = new StringBuilder(DEFAULT_LINE_LENGTH);
            line.append(getNonNullValue(leftResult.get().getByKey(key).getColumnSlice().getColumnByName(physicalDatasets.get(0).tableId),
                    physicalDatasets.get(0).id));
            handleLine(requestParameters, lookupKey, line, key, responseFormatter, physicalDatasets, leftJoinAttributePositions,
                    rightReverseIndexPositions, filterPositionValueMap, filterPositionOperatorMap, outputFieldPositions, readRowCount, 1);
        }
    }

    /**
     * Handles join between left and right datasets. Called recursively for
     * multi-joins
     * 
     * @param requestParameters
     * @param lookupKey
     * @param line
     * @param key
     * @param responseFormatter
     * @param physicalDatasets
     * @param leftJoinAttributePositions
     * @param rightReverseIndexPositions
     * @param filterPositionValueMap
     * @param filterPositionOperatorMap
     * @param outputFieldPositions
     * @param readRowCount
     * @param currentDatasetNum
     * @throws Exception
     */
    private void handleLine(RequestParameters requestParameters, String lookupKey, StringBuilder line, String key,
            ResponseFormatter responseFormatter, List<PhysicalDataset> physicalDatasets, int[] leftJoinAttributePositions,
            int[] rightReverseIndexPositions, Map<Integer, String> filterPositionValueMap, Map<Integer, String> filterPositionOperatorMap,
            int[] outputFieldPositions, AtomicInteger readRowCount, int currentDatasetNum) throws Exception {
        // If no further joins, write and return
        if (currentDatasetNum == physicalDatasets.size()) {
            writeToOutput(requestParameters, lookupKey, line, responseFormatter, filterPositionValueMap, filterPositionOperatorMap,
                    outputFieldPositions, readRowCount);
            return;
        }
        
        if(key.isEmpty()) {
        	key = StaticValues.BLANK_KEY;
        }

        line.append(Shared.STANDARD_DELIMITER);
        // Both Join keys = row keys
        if (leftJoinAttributePositions[currentDatasetNum] == -1 && rightReverseIndexPositions[currentDatasetNum] == -1) {
            ColumnSlice<String, String> columnSlice = cassandraWrapper.executeColumnSliceQuery(
                    physicalDatasets.get(currentDatasetNum).tableId, physicalDatasets.get(currentDatasetNum).tableId, key);
            line.append(getNonNullValue(columnSlice.getColumnByName(physicalDatasets.get(currentDatasetNum).tableId),
                    physicalDatasets.get(currentDatasetNum).id));
            // Handle next joins, if any
            handleLine(requestParameters, lookupKey, line, key, responseFormatter, physicalDatasets, leftJoinAttributePositions,
                    rightReverseIndexPositions, filterPositionValueMap, filterPositionOperatorMap, outputFieldPositions, readRowCount,
                    currentDatasetNum + 1);
            return;
        }

        String leftJoinKey = key;

        // Left join key != row key (optimization to avoid split)
        if (leftJoinAttributePositions[currentDatasetNum] != -1) {
            // Extract left join key from position:
            // leftJoinAttributePositions[currentDatasetNum]
            String[] values = line.toString().split(Shared.STANDARD_DELIMITER, -1);
            leftJoinKey = values[leftJoinAttributePositions[currentDatasetNum]];
        }

        // Orchestrator creates reverse index with keyword "BLANK", Empty values are looked up using "BLANK" 
        leftJoinKey = (leftJoinKey.isEmpty()) ? StaticValues.BLANK_KEY : leftJoinKey;
        
        List<String> rightJoinKeys = new ArrayList<String>();
        
        // Right join key != row key (reverse index lookup)
        if (rightReverseIndexPositions[currentDatasetNum] != -1) {
        	
            // Lookup join key reverse index to get matching right key(s)
            ColumnSliceIterator<String, String, String> sliceIterator = cassandraWrapper.createColumnSliceIterator(
                    physicalDatasets.get(currentDatasetNum).tableId + Shared.CASSANDRA_INDEX_NAME_SEPARATOR
                            + rightReverseIndexPositions[currentDatasetNum], leftJoinKey, null, Shared.MAX_KEY,
                    queryServiceConfiguration.getReadBatchSize());

            // If no right keys, pad blank line
            if (!sliceIterator.hasNext()) {
                line.append(getBlankOutputLine(physicalDatasets.get(currentDatasetNum).id));
                // Handle next joins, if any
                handleLine(requestParameters, lookupKey, line, key, responseFormatter, physicalDatasets, leftJoinAttributePositions,
                        rightReverseIndexPositions, filterPositionValueMap, filterPositionOperatorMap, outputFieldPositions, readRowCount,
                        currentDatasetNum + 1);
                return;
            }

            // Read each right key
            while (sliceIterator.hasNext()) {
                // rightJoinKeys.add(sliceIterator.next().getValue());
                rightJoinKeys.add(sliceIterator.next().getName());
            }
        }
        // Right join key == row key
        else {
            rightJoinKeys.add(leftJoinKey);
        }

        // Join each right key
        // Multiget all right keys TODO: Too many rows matching right side
        // rows in memory!
        QueryResult<Rows<String, String, String>> result = cassandraWrapper.executeMultigetSliceQuery(
                physicalDatasets.get(currentDatasetNum).tableId, physicalDatasets.get(currentDatasetNum).tableId,
                rightJoinKeys.toArray(new String[rightJoinKeys.size()]));
        for (String rightJoinKey : rightJoinKeys) {
            StringBuilder lineCopy = new StringBuilder(line);
            lineCopy.append(getNonNullValue(
                    result.get().getByKey(rightJoinKey).getColumnSlice().getColumnByName(physicalDatasets.get(currentDatasetNum).tableId),
                    physicalDatasets.get(currentDatasetNum).id));
            // Handle next joins, if any
            handleLine(requestParameters, lookupKey, lineCopy, key, responseFormatter, physicalDatasets, leftJoinAttributePositions,
                    rightReverseIndexPositions, filterPositionValueMap, filterPositionOperatorMap, outputFieldPositions, readRowCount,
                    currentDatasetNum + 1);
        }
    }

    /**
     * Returns column value or for non-existent column returns blank line
     * matching dataset schema
     * 
     * 
     * @param column
     * @param dataset
     * @return
     * @throws Exception
     */
    private String getNonNullValue(HColumn<String, String> column, String dataset) throws Exception {
        return column == null ? getBlankOutputLine(dataset) : column.getValue();
    }

    public String getBlankOutputLine(String dataset) throws Exception {
        if (blankOutputFieldsMap.get(dataset) == null) {
            StringBuilder blankLine = new StringBuilder(Common.BLANK);
            for (int i = 0; i < metadataService.getAttributeNamesForDataset(dataset).size() - 1; i++) {
                blankLine.append(Common.STANDARD_DELIMITER);
            }
            blankOutputFieldsMap.put(dataset, blankLine.toString());
        }
        return blankOutputFieldsMap.get(dataset);
    }

    class FastKeyParallel implements Runnable {
        RequestParameters requestParameters;
        String lookupKey;
        ResponseFormatter responseFormatter;
        String[] keyArray;
        List<PhysicalDataset> physicalDatasets;
        Map<Integer, String> filterPositionValueMap;
        Map<Integer, String> filterPositionOperatorMap;
        int[] outputFieldPositions;
        AtomicInteger readRowCount;

        FastKeyParallel(RequestParameters requestParameters, String lookupKey, ResponseFormatter responseFormatter, String[] keyArray,
                List<PhysicalDataset> physicalDatasets, Map<Integer, String> filterPositionValueMap,
                Map<Integer, String> filterPositionOperatorMap, int[] outputFieldPositions, AtomicInteger readRowCount) {
            this.requestParameters = requestParameters;
            this.lookupKey = lookupKey;
            this.responseFormatter = responseFormatter;
            this.keyArray = keyArray;
            this.physicalDatasets = physicalDatasets;
            this.filterPositionValueMap = filterPositionValueMap;
            this.filterPositionOperatorMap = filterPositionOperatorMap;
            this.outputFieldPositions = outputFieldPositions;
            this.readRowCount = readRowCount;
        }

        @Override
        public void run() {
            try {
                getFastKeyParallel(requestParameters, lookupKey, responseFormatter, keyArray, physicalDatasets, filterPositionValueMap,
                        filterPositionOperatorMap, outputFieldPositions, readRowCount);
            } catch (Throwable e) {
                LOGGER.error(e.getMessage(), e);
            }
        }
    }

    private void getFastKeyParallel(RequestParameters requestParameters, String lookupKey, ResponseFormatter responseFormatter,
            String[] keyArray, List<PhysicalDataset> physicalDatasets, Map<Integer, String> filterPositionValueMap,
            Map<Integer, String> filterPositionOperatorMap, int[] outputFieldPositions, AtomicInteger readRowCount) throws Exception {
        List<QueryResult<Rows<String, String, String>>> results = new ArrayList<QueryResult<Rows<String, String, String>>>();
        for (PhysicalDataset physicalDataset : physicalDatasets) {
            QueryResult<Rows<String, String, String>> result = cassandraWrapper.executeMultigetSliceQuery(physicalDataset.tableId,
                    physicalDataset.tableId, keyArray);
            results.add(result);
        }

        for (String key : keyArray) {
            if (key == null) {
                return;
            }
            StringBuilder line = new StringBuilder();
            int j = 0;
            for (PhysicalDataset physicalDataset : physicalDatasets) {
                if (line.length() != 0) {
                    line.append(Shared.STANDARD_DELIMITER);
                }
                line.append(getNonNullValue(results.get(j).get().getByKey(key).getColumnSlice().getColumnByName(physicalDataset.tableId),
                        physicalDataset.id));
                j++;
            }

            writeToOutput(requestParameters, lookupKey, line, responseFormatter, filterPositionValueMap, filterPositionOperatorMap,
                    outputFieldPositions, readRowCount);
        }
    }

    private void writeToOutput(RequestParameters requestParameters, String lookupKey, StringBuilder line,
            ResponseFormatter responseFormatter, Map<Integer, String> filterPositionValueMap,
            Map<Integer, String> filterPositionOperatorMap, int[] outputFieldPositions, AtomicInteger readRowCount) throws Exception {

        // split line
        String[] values = line.toString().split(Shared.STANDARD_DELIMITER, -1);

        // If all filters match, select row
        if (isMatchRow(filterPositionValueMap, filterPositionOperatorMap, values)) {
            String[] outputValuesArray = new String[outputFieldPositions.length];
            int position = 0;

            for (int outputFieldPosition : outputFieldPositions) {
                if (SPECIALCODEVALUE.get(outputFieldPosition) != null) {
                    outputValuesArray[position++] = SPECIALCODEVALUE.get(outputFieldPosition);
                } else {
                    outputValuesArray[position++] = values[outputFieldPosition];
                }
            }

            synchronized (readRowCount) {
                if (readRowCount.get() < requestParameters.getLimit()) {
                    readRowCount.incrementAndGet();
                    responseFormatter.writeLine(outputValuesArray);
                    
                    // lookup (IDP_STATUS / unionExclusive) - remove if key found
                    if (requestParameters.getLookupKeys() != null) {
                        requestParameters.getLookupKeys().remove(lookupKey);
                    }
                }
            }
        }
    }

    /**
     * Checks if all filters match given row, based on operators 1) Must check
     * all of the possible values per filter for a match (i.e.
     * individualFilterMatch == true). 2) If any of the individual filters
     * fails, then the row does not match (i.e. allFiltersMatch == false)
     * 
     * @param filterPositionValueMap
     * @param filterPositionOperatorMap
     * @param rowArray
     * @return
     * @throws Exception
     */
    public boolean isMatchRow(Map<Integer, String> filterPositionValueMap, Map<Integer, String> filterPositionOperatorMap, String[] rowArray)
            throws Exception {
        // iterate over each filter position
        boolean allFiltersMatch = true; // default no filter so row is
                                        // automatically a match
        for (int filterPosition : filterPositionValueMap.keySet()) {
            boolean individualFilterMatch = false;
            // chose operator to apply
            switch (filterPositionOperatorMap.get(filterPosition)) {
            
            case Shared.OPERATOR_EQUALS: // equals
            	
            	if(filterPositionValueMap.get(filterPosition).equals(Common.BLANK) &&
            			filterPositionValueMap.get(filterPosition).equals(rowArray[filterPosition])){
            			
            			individualFilterMatch = true;
            			
            	}else {
            		
                    Scanner valuesScanner = new Scanner(filterPositionValueMap.get(filterPosition));
                    valuesScanner.useDelimiter(Shared.VALUESDELIMITER);
                    
                    while (valuesScanner.hasNext()) { // CSV in clause
                        String scannedValue = valuesScanner.next();
                        if (scannedValue.equals(rowArray[filterPosition])) {
                            individualFilterMatch = true;
                        }
                    }
                    valuesScanner.close();
            	}
                
            	if (individualFilterMatch == false) {
                    allFiltersMatch = false;
                }
                
                break;

            case Shared.OPERATOR_NOT_EQUALS: // not equals
            	
            	individualFilterMatch = false;
            	
                if(filterPositionValueMap.get(filterPosition).equals(Common.BLANK) &&
            			filterPositionValueMap.get(filterPosition).equals(rowArray[filterPosition])){
            			
            		individualFilterMatch = true;
            			
            	}else {
	                Scanner notValuesScanner = new Scanner(filterPositionValueMap.get(filterPosition));
	                notValuesScanner.useDelimiter(Shared.VALUESDELIMITER);
	
	                while (notValuesScanner.hasNext()) {// CSV not-in clause
	                    if (notValuesScanner.next().equals(rowArray[filterPosition])) {
	                        individualFilterMatch = true;
	                    }
	                }
	                notValuesScanner.close();    
            	}
            	
            	if (individualFilterMatch == true) {
                    allFiltersMatch = false;
                }  
                               
                break;

            case Shared.OPERATOR_LESS_THAN_EQUALS: // less than equals
                individualFilterMatch = false;
                if (rowArray[filterPosition].compareTo(filterPositionValueMap.get(filterPosition)) <= 0) {
                    individualFilterMatch = true;
                }
                if (individualFilterMatch == false) {
                    allFiltersMatch = false;
                }
                break;

            case Shared.OPERATOR_GREATER_THAN_EQUALS: // greater than equals
                individualFilterMatch = false;

                if (rowArray[filterPosition].compareTo(filterPositionValueMap.get(filterPosition)) >= 0) {
                    individualFilterMatch = true;
                }
                if (individualFilterMatch == false) {
                    allFiltersMatch = false;
                }
                break;

            case Shared.OPERATOR_LESS_THAN: // less than
                individualFilterMatch = false;
                if (rowArray[filterPosition].compareTo(filterPositionValueMap.get(filterPosition)) < 0) {
                    individualFilterMatch = true;
                }
                if (individualFilterMatch == false) {
                    allFiltersMatch = false;
                }
                break;

            case Shared.OPERATOR_GREATER_THAN: // greater than
                individualFilterMatch = false;
                if (rowArray[filterPosition].compareTo(filterPositionValueMap.get(filterPosition)) > 0) {
                    individualFilterMatch = true;
                }
                if (individualFilterMatch == false) {
                    allFiltersMatch = false;
                }
                break;

            case Shared.OPERATOR_LIKE: // like NIK.*E.
                individualFilterMatch = false;
                if (rowArray[filterPosition].matches(filterPositionValueMap.get(filterPosition))) {
                    individualFilterMatch = true;
                }
                if (individualFilterMatch == false) {
                    allFiltersMatch = false;
                }
                break;

            case Shared.OPERATOR_BETWEEN: // between from,to (inclusive)
                individualFilterMatch = false;
                // CSV from,to
                Scanner betweenValuesScanner = new Scanner(filterPositionValueMap.get(filterPosition));
                betweenValuesScanner.useDelimiter(Shared.VALUESDELIMITER);
                if (rowArray[filterPosition].compareTo(betweenValuesScanner.next()) >= 0
                        && rowArray[filterPosition].compareTo(betweenValuesScanner.next()) <= 0) {
                    betweenValuesScanner.close();
                    individualFilterMatch = true;
                }
                if (individualFilterMatch == false) {
                    allFiltersMatch = false;
                }
                betweenValuesScanner.close();
                break;

            default:
                throw new FilegenException(filterPositionOperatorMap.get(filterPosition) + Shared.OPERATOR_NOT_SUPPORTED);
            }
        }

        return allFiltersMatch; // no filter
    }

    /**
     * Parses the request parameter map into separate filters, fields, union
     * (filters & fields) and delimiters. Supports only first element in
     * parameterMap.get(parameterName). Does NOT support multiple elements e.g.
     * fields=tL.exchange&fields=tL.quick
     * 
     * @param fields
     * 
     * @param joinRelations
     * @param datasetId
     * @return
     * @throws Exception
     */
    public RequestParameters parseRequestParameterMap(Map<String, String[]> parameterMap, List<JoinRelation> joinRelations, String datasetId)
            throws Exception {
        // New list to avoid ConcurrentModificationException
        List<String> unionOfFiltersAndFields = new ArrayList<String>();
        List<String> filterIdList = new ArrayList<String>();

        // Create default parameter values
        RequestParameters requestParameters = createDefaultRequestParameters(datasetId);

        for (String parameterName : parameterMap.keySet()) {
            // Check parameter value
            if (parameterMap.get(parameterName)[0].length() == 0) {
                throw new FilegenException(Shared.MISSING_VALUE_FOR_PARAMETER + parameterName);
            }
            if (Shared.FIELDS.equals(parameterName)) { // Output fields
                requestParameters.setFields(queryServiceConfiguration.parseCSVToArray(parameterMap.get(parameterName)[0]));
            } else if (Shared.DELIMITER.equals(parameterName)) { // delimiter
                requestParameters.setDelimiter(parameterMap.get(parameterName)[0]);
            } else if (Shared.QUOTE.equals(parameterName)) { // quote
                requestParameters.setQuoteChar(parameterMap.get(parameterName)[0].charAt(0));
            } else if (Shared.ESCAPE.equals(parameterName)) { // escape
                requestParameters.setEscapeChar(parameterMap.get(parameterName)[0].charAt(0));
            } else if (Shared.INCLUDE_INPUT.equals(parameterName)) {
                requestParameters.setIncludeInput(parameterMap.get(parameterName)[0]);
            } else if (Shared.HIDE_HEADER.equals(parameterName)) {
                requestParameters.setHideHeader(parameterMap.get(parameterName)[0]);
            } else if (Shared.OUTPUT_FORMAT.equals(parameterName)) {
                requestParameters.setResponseFormat(parameterMap.get(parameterName)[0]);
            } else if (Shared.DISTINCT.equals(parameterName)) {
                requestParameters.setDistinct(parameterMap.get(parameterName)[0]);
            } else if (Shared.REQUEST_PARAMETER_LIMIT.equals(parameterName)) {
                requestParameters.setLimit(Integer.parseInt(parameterMap.get(parameterName)[0]));
            } else if (Shared.UNION_EXCLUSIVE.equals(parameterName)) {
                requestParameters.setUnionExclusiveLookup(parameterMap.get(parameterName)[0]);
            }else if (Shared.UNION.equals(parameterName)) {
            	
            	List<String> unionParamValues= new ArrayList<String>();
            	String unionParam = parameterMap.get(parameterName)[0];
            	
            	// remove ( ) from the input parameter values if present
            	if(unionParam.charAt(0) =='(' && unionParam.charAt(unionParam.length()-1)==')'){
            		unionParam = unionParam.substring(1, unionParam.length()-1);
            	}
            			
            	String [] unionValues = unionParam.split(Shared.ESC_PIPE_SEPERATOR);
            	
            	for (String param : unionValues) {
					
            		String keyValues[] = param.split(Shared.COLON);
            		unionParamValues.add(keyValues[0]+ Shared.URLPARAMVALUEDELIMITER+keyValues[1]);
            		
            		if (!unionOfFiltersAndFields.contains(keyValues[0])) {
                        unionOfFiltersAndFields.add(keyValues[0]);
                    }            		
				}
                
            	requestParameters.setUnionParamValues(unionParamValues);
            	
            } else {
                filterIdList.add(parameterName + Shared.URLPARAMVALUEDELIMITER + parameterMap.get(parameterName)[0]);
                if (!unionOfFiltersAndFields.contains(parameterName)) {
                    unionOfFiltersAndFields.add(parameterName);
                }
            }
        }

        requestParameters.setFilterIds(filterIdList);

        // Add fields
        for (String field : requestParameters.getFields()) {
            if (!unionOfFiltersAndFields.contains(field)) {
                unionOfFiltersAndFields.add(field);
            }
        }

        // Assume all invalid and then check validity
        requestParameters.getInvalidFieldsList().addAll(unionOfFiltersAndFields);
        for (String attribute : unionOfFiltersAndFields) {
            for (JoinRelation joinRelation : joinRelations) {
                // Field valid for this file?
                if (isAttributeValidForRelation(joinRelation, attribute)) {
                    requestParameters.getInvalidFieldsList().remove(attribute);
                }
            }
        }
        
        // also consider aliases valid
        for (String attribute : metadataService.getAttributeNamesForDataset(datasetId)) {
        	requestParameters.getInvalidFieldsList().remove(attribute);
        }
        
        // Lookup
        for (String field : requestParameters.getFields()) {
            if (Shared.IDP_STATUS.equals(field)) {
                requestParameters.setIDPStatusLookup(true);
                break;
            }
        }

        return requestParameters;
    }

    public boolean isAttributeValidForRelation(JoinRelation joinRelation, String attribute) throws Exception {
        // Special field?
        if (attribute.equals(Shared.SYSDATE) || attribute.equals(Shared.SYSDATE_PREVIOUS) || attribute.equals(Shared.SYSDATE_NEXT)
                || attribute.equals(Shared.IDP_STATUS)) {
            return true;
        }

        for (PhysicalDataset dataset : joinRelation.getOrderedDatasets()) {
            // Field valid?
            if (metadataService.getAttributePositionsForDataset(dataset.id).get(attribute) != null) {
                return true;
            }
        }
        return false;
    }

    private RequestParameters createDefaultRequestParameters(String datasetOrView) throws Exception {
        // Create RequestParameters object
        RequestParameters requestParameters = new RequestParameters();
        List<String> fieldsList = metadataService.getAttributeNamesForDataset(datasetOrView);
        requestParameters.viewName = datasetOrView;
        requestParameters.setFields(fieldsList.toArray(new String[fieldsList.size()]));
        requestParameters.setDelimiter(metadataService.getDelimiter(datasetOrView).startsWith(Shared.XML) ? Shared.STANDARD_DELIMITER
                : metadataService.getDelimiter(datasetOrView));
        requestParameters.setQuoteChar(CSVWriter.NO_QUOTE_CHARACTER);
        requestParameters.setEscapeChar(CSVWriter.NO_ESCAPE_CHARACTER);
        requestParameters.setHideHeader(null);
        requestParameters.setIncludeInput(null);
        return requestParameters;
    }

    private static Map<Integer, String> getSpecialCodeValueMap() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(Shared.DATE_FORMAT);
        // Current day
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();
        // Previous day
        calendar.add(Calendar.DATE, -1);
        Date previousDate = calendar.getTime();
        // Next day
        calendar.add(Calendar.DATE, 2);
        Date nextDate = calendar.getTime();

        Map<Integer, String> specialCodeValue = new HashMap<Integer, String>(5);
        specialCodeValue.put(Common.BLANK_CODE, StaticValues.BLANK);
        specialCodeValue.put(Common.SYSDATE_CODE, simpleDateFormat.format(currentDate));
        specialCodeValue.put(Common.SYSDATE_PREV_CODE, simpleDateFormat.format(previousDate));
        specialCodeValue.put(Common.SYSDATE_NEXT_CODE, simpleDateFormat.format(nextDate));
        specialCodeValue.put(Common.IDP_STATUS_CODE, Common.STATUS_OK);
        return specialCodeValue;
    }

    public int getFieldPositionInJoinRelation(List<PhysicalDataset> physicalDatasets, String attribute) throws Exception {
        // Special fields
        if (Shared.SYSDATE.equals(attribute)) {
            return Common.SYSDATE_CODE;
        }
        if (Shared.SYSDATE_PREVIOUS.equals(attribute)) {
            return Common.SYSDATE_PREV_CODE;
        }
        if (Shared.SYSDATE_NEXT.equals(attribute)) {
            return Common.SYSDATE_NEXT_CODE;
        }
        if (Shared.IDP_STATUS.equals(attribute)) {
            return Common.IDP_STATUS_CODE;
        }

        // Calculate offset in joined datasets
        int positionOffset = 0;
        for (PhysicalDataset dataset : physicalDatasets) {
            List<String> attributes = metadataService.getAttributeNamesForDataset(dataset.id);
            int fieldPosition = attributes.indexOf(attribute);
            if (fieldPosition != -1) {
                return positionOffset + fieldPosition;
            }
            // Column offset in join file
            positionOffset += attributes.size();
        }

        return -1;
    }

    public void setStatsForTest(Stats stats) {
        this.stats = stats;
    }

    /**
     * Gets left and right join-key positions. If join key position same as
     * primary key position, returns -1
     * 
     * @param datasetId1
     *            - left dataset
     * @param datasetId2
     *            - right dataset
     * @return
     * @throws Exception
     */
    private int[] getLeftAndRightJoinAttributePositions(String datasetId1, String datasetId2) throws Exception {
        int[] leftAndRightJoinAttributePositions = new int[2];
        String[] datasets = new String[] { datasetId1, datasetId2 };

        List<String> joinKeys = metadataService.getJoinKeysForDatasetIds(datasetId1, datasetId2);

        if (joinKeys == null) {
            throw new RuntimeException(JOIN_KEYS_NOT_DEFINED + datasetId1 + " and " + datasetId2);
        }

        // Loop for Left and Right
        for (int i = 0; i < 2; i++) {
            Integer joinAttributePosition = metadataService.getAttributePositionsForDataset(datasets[i]).get(joinKeys.get(i));

            if (joinAttributePosition == null) {
                throw new RuntimeException(JOIN_KEY_INVALID + datasetId1 + " and " + datasetId2 + " has " + datasets[i] + "."
                        + joinKeys.get(i));
            }

            List<Integer> keyAttributePositions = metadataService.getDatasetKeyAttributePositions(datasets[i]);
            if (keyAttributePositions.size() == 1 && keyAttributePositions.get(0) == joinAttributePosition) {
                leftAndRightJoinAttributePositions[i] = -1;
            } else {
                leftAndRightJoinAttributePositions[i] = joinAttributePosition;
            }
        }
        return leftAndRightJoinAttributePositions;
    }
}
