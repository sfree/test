package com.ubs.idp.das.model;

import com.ubs.idp.base.StaticValues;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.security.KeyStore;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@SuppressWarnings("deprecation")
public class RDDHWebServiceClient {
    private static final Logger LOGGER = LoggerFactory.getLogger(RDDHWebServiceClient.class);
    DefaultHttpClient httpClient;
    private static final String KEYSTORE_LOCATION = null;//Shared.getSystemOrConfigProperty(Shared.KEYSTORE_LOCATION);

    private static final String KEYSTORE_PASSWORD = null;//Shared.getSystemOrConfigProperty(Shared.KEYSTORE_PASSWORD, true); // Encrypted

    private static final String RDDH_RCAS_ENDPOINT_URL = null;//Shared.getSystemOrConfigProperty(Shared.RDDH_RCAS_ENDPOINT_URL);

    private static final String RDDH_RCAS_SSO_PASSWORD = null;//Shared.getSystemOrConfigProperty(Shared.RDDH_RCAS_SSO_PASSWORD, true); // Encrypted

    private static final String RDDH_RCAS_AUTH_APPGUID = null;//Shared.getSystemOrConfigProperty(Shared.RDDH_RCAS_AUTH_APPGUID);

    private static final String RDDH_WS_HOST = null;//Shared.getSystemOrConfigProperty(Shared.RDDH_WS_HOST);

    private static final String RDDH_WS_PATH = null;//Shared.getSystemOrConfigProperty(Shared.RDDH_WS_PATH);

    private static final String RDDH_WS_USER_APP = null;//Shared.getSystemOrConfigProperty(Shared.RDDH_WS_USER_APP);

    private static final String RDDH_WS_USER_HOST = null;//Shared.getSystemOrConfigProperty(Shared.RDDH_WS_USER_HOST);

    private static final String RDDH_RCAS_SSO_USERNAME = null;//Shared.getSystemOrConfigProperty(Shared.RDDH_RCAS_SSO_USERNAME);

    private static final String RDDH_WS_USER_DOMAIN = null;//Shared.getSystemOrConfigProperty(Shared.RDDH_WS_USER_DOMAIN);

    private static final int MAX_TRIES = 1;
    private static final String RETRYING = "Retrying ";
    private static final String OF = " of ";
    private static final String TRIES = " tries...";
    private static final String AUTHORIZING = "Authorizing...";
    private static final int SECURE_PORT = 443;
    private static final int HTTP_CODE_SUCCESS = 200;
    private static final String LOAD_STARTED = "Load started: ";
    private static final String LOAD_ENDED = "Load ended: ";
    private static final String LOAD_TERMINATED_START = "Load terminated (timeout = ";
    private static final String LOAD_TERMINATED_END = "): ";
    private static String filePath;
    private static final int timeout = 3;
    private static final TimeUnit unit = TimeUnit.HOURS;
    private static final String LOAD_FILE_EXTENSION = ".load";
    private FileSystem fileSystem;
    private WebServiceClientFactory webServiceClientFactory;

    public static void main(String[] arguments) throws Exception {
        RDDHWebServiceClient rDDHWebServiceClient = new RDDHWebServiceClient();
        filePath = "C:\\programs\\cassandra\\";
        rDDHWebServiceClient.setFileSystem(new HUFSFileSystem());
        rDDHWebServiceClient.setWebServiceClientFactory(new WebServiceClientFactory());
        rDDHWebServiceClient.loadMultiple();
    }

    private void loadMultiple() {
        final Map<String, String> fileUrlMap = new HashMap<String, String>();
        // "http://rddh-inst-prd.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?issue.assetClass=EQUITY&issue.isin=US4592001014&user.app=filegen&user.host=xstm0646vdap&user.domain=ubsw&user.name=sso_filegentest&rddh.requesttype=TEXT"
        fileUrlMap
                .put("EQUITY",
                        "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?issue.assetClass=EQUITY&user.app=RDDH&user.host=xstm1489vdap&user.domain=ubsw&user.name=sso_rddhu&rddh.requesttype=TEXT&fields=cb64:eJx1V9tu2zgQ_aHAi6IF9jnrJEWAZJ3aTt8pamSzpkiFFzfar9_Dm0TL7ksinpE45JkzFwtrPa1E-PvAHN3Fp5U9MkN24511TLVCHf6EV98YL-nLt2_3X_nfz6rN4Fk7sm9kduHDO_eyGrRxnZZCvzJzEIo1kta6jSYhpfjwot05zU8BaJq17gdthaPHT35k6kB3DbMncqtWnIXVpiyV7zfdWivrhPOknL2z5JykVev4oxQHATfpRGblG_vGjFNkntsKw8KrVq6cfJ8X0VytmcW-a4l_ad2zX9r8JGOFVgmBzb0PLWhp96KnBDbNXvATmbSy1GpZCA08MtOCDdxjJ_4rbAq76X54JoUbAxXpOmsmKbw-RQNk_svgJd_25lus116561h22r4Z3Xruvhvth4wqcTqRiCHYj0M5jbOEmHrrzBijJWbVBP9_nZj6JZanukDTvjc26QwpftwbpizjDjzu2We4cSeMdYDbpMugD5yeMyfO8HneCh7l1ON5N_YNGMXSCHuSZHExobgYWASL6_PewHm8FdCefYbdgwDBs3KZ6Ap-0e6OIEg3IkzgYzcgGpXgQeB3fc5ySNCR2RcBEdYkIxy8uu9VOC53nKhFCIZ4_YwshZXQCwFmBzxQNOvL-XlTve5KQCopV0AVc0vcG1y-gppmdw1yb0VRD9d9Px1EWFEez0xqxDmvfpNxAxsEmYWrJ236amele1QIufYmaGQsdYagIMHBQ6C6YpYLZa_e2XRdRVeFqwrOjn4y6WnTvSvhCr2iE3CTqtIpgygWRSL1azFYWxom5q-TOr53f0bIhRz33ih9nji4aVtPt47mtGGN7ODlFF0sWErva1yX5BmvLMxT6l4RU0tiRhGZLVlihh8XNggP2aZD-G59tUMxurldoGvOkwvT2_0DofJdGeEKDaFHfb9oR2gvDxTbhDbjljiJwU1fHnZzMyodakZYO8T7gqxQWSbpOvY5daaEQAL8NH1lppZW6Hz10olBUo02DZjpkTKhjU0dbGEL_xa2zrE6Cqk5oTbxUDnM-F7WF8mP9bJEAMrFIHSQVAnw5HCTKMr43PbhP5UTBDdFKmFL7cqrTYPE-PBps9jC8PDhtYvElbLqUqMLTyEf1unI6fv9ZDOpehfosfIuNUfK55FgLjjxK2zWvswnAjEpI15Z3pdr6V5VugRYwjxgylYu6e1FqKT7uHvtWNiWbemQudRD7ihQ0FGvmbuPNHmjFX26C8s_ybOyGGsS-Ueo8qhlG4QWvnJw5Mio1I-wfFbz8veR1HMIdPsk2SGeZNDlMYT0ogn2qabQIabBwnHuPdltuEJ-xCRVBRXsbzocIRsHoU4_QhxDQatchFniJ6kU8VhPnryKo1SS39DPjTeRJwOf0ziXoK0ztoZTYTrV-5d4RFMIKspWKrqT-7aXr4rQW5JwEMzPfHrMD_QkNXNISZ45CaqkSigKfYXJqhwH3sqUFJgyLZmt9oG8rU8s5GTbdEET0FEqD3EwEdu5IOVTMB9XO8we-TX35WtiYTMESyEX5TiOMPiO4pyDElSyeTkQa86vp2TUYIVjXgzVqZgwM14kkhKpioTDIEFCP4kUmBopukr1LSUVzpPnnmVFyfBF4clYmMhbMDoJbYFP513gsXAssCcD4OYmbIwHXsAo-gjhLcsDcQmnN22PnzWKpIvLPEpfXDFjSzamqZt9oO9j6s25l3Ee-la1jhNtkn3tKex6jQ6uf6HzeD9g6ORRPNkQShCXUEG1M2p7Pyw97wL44N1YG4roy8-jafY0twdMc2PCNGl6MPP4YOZseVYIBbiouimsqUiVZfpdx9Q47ceb8sugglD60dFrANq8xgac7QJFEWnmzl2d7QFjHhfy2rDFz4bFz8MxJMEZ9WQh9ggtqPofpq7cOw");
        fileUrlMap
                .put("INDEX",
                        "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?issue.assetClass=EQUITY_INDEX&user.app=RDDH&user.host=xstm1489vdap&user.domain=ubsw&user.name=sso_rddhu&rddh.requesttype=TEXT&fields=cb64:eJxtUttOwzAM_aFqP1EmhEAgbQOJx1zcYcilxM5Y_540Tbcu60vq27F9fIpEETZR0pNuMNuCCLg16dP0EOyGfAwKGn7Z9HY_WOnNaFvx7cMHBELvCjBB-L3XgkEf0EKDTsP5tjABp1HJUDEEcGooaCTfdjgmkLTYgdme1VfrNVzy6K7ZY-nGQWhofXQchjJQedsb4LxxQFWiLtq3rvWOGDmCY1pUe0JO_bZdB4rxBA9iQovslcJ1dmrRcVxYuCMsOOw4UMVDyj0k6sjDYejnYH0kmFvN3NP7KmxufbfIpFrZNTvEgmOR7yRMzDgpD6h-IExhHoePB5xiOf_u8DfOzDSekiShePldLCzlJxjj_55hPDtxiDad4DH42Fe_RpW8qFMn1gS6h65KVRfeS1U3WhGtLrryv41fLvEPYX1Axg");
        fileUrlMap
                .put("INDEXCOMPOSITION",
                        "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?issue.assetClass=INDEX_COMP&user.app=RDDH&user.host=xstm1489vdap&user.domain=ubsw&user.name=sso_rddhu&rddh.requesttype=TEXT&fields=issue.assetClass,perm.source,issue.lastUpdatedTime,tL.ubsId,issue.isoCfi,indexComps.majorVersion,issue.isin,tL.isdaRegion,tL.isdaRelRtrsExchCode,issue.bbSecurityType,tL.exchange,issue.status,tL.bbUnique,issue.ubsId,indexComps.lastUpdatedTime,tL.pmSymbol,tL.majorVersion,tL.currency,perm.result,tL.isdaRelExchCode,tL.tradeCountry,tL.ric,tL.active,issue.majorVersion,issue.issueName,issue.active,tL.lastUpdatedTime,perm.value,tL.bbTicker,perm.type,tL.ticker,event.majorVersion,event.lastUpdatedTime,comp.lastUpdatedTime,comp.indexShareFactor,comp.numOfShares,comp.tLUbsId,comp.tLActive,comp.weighting,comp.majorVersion,comp.issueUbsId,comp.issueActive,comp.sedol,comp.ticker,comp.tLName,comp.issuerName,comp.issuerUbsId,comp.active,instrumentGroup.majorVersion,instrumentGroup.weightingOfficialInd,instrumentGroup.divisor,instrumentGroup.complete,instrumentGroup.compositionEffectiveDate,instrumentGroup.lastUpdatedTime,instrumentGroup.divisorOfficialInd,instrumentGroup.totalShares,instrumentGroup.numOfConstituents,instrumentGroup.constituentsExchange&fields=cb64:eJx9U-1OwzAMfKFp74DKQJMQk9jG_zRxN0OTFNsZ9O3JR7t13eBPU9_ZuculReYAS8UMUrVxWXRAdsk-kIYFZjLCsu-MEjA7tLCQl2WoeW0GGtlXDS7QGfipvO14adWHp3cgRu_OTejSILJRb3BIxLlq34R49aOPlTejZl1vQQdC6Xd9lyUhNih3GBtYlARORF3vHX6FkRisXdzcsd_ZbW9r36b3K7OxjqoETvclCAIOrUy8nn1GSEgZqHxwQn2qCXValBY8jXbuZhGfr8qOLUN_nJxbzRZOqg1QDrpD_QlUYBlykYLBCZxcqxVovqeOodwHc2bboyJ4ipY8FdQFu2kyygWQl32OeCgeivtcfQMejoLuUMorN0UiHXgynuvpDgwmXkvZuhxskMl5XWZoXk82HfN3LBRszOCZfJi5mZNn55umQY2qXTtz02TwFD92usGTagtyK5kIzyhRcdU0kH09qjuN8_v4Q_k_c-JFtcM9zbl8h5WPKEqI6G2HnpCr4U_7BTl-lmk");
        fileUrlMap
                .put("CONVERTIBLES",
                        "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?issue.assetClass=BOND&issue.assetType=CONVERTIBLE&messageLevel=tL&user.app=RDDH&user.host=xstm1489vdap&user.domain=ubsw&user.name=sso_rddhu&rddh.requesttype=TEXT&fields=cb64:eJxtVtuO2zgM_aFBFgv0B7KeThHszCaNMwPsoyzRiRpdXEqaxv36UhfbyuUlkUiJIg-PjtxZI1ZaGqmDPiAT0Mrf8BSMUCuv3ju3EXkinQtQzZlz4BtFf5PfNr3MY7L690EwD-IgdYnWdQfJz4DTcmnyyIGw6imFX3kHGyOC8zg2VsCTf139DLTridswWLPiARGMb9JsT_Enh4GL37FRk_M5mnM4d7JnMDFKL9H5VF5ykyXmuBioFq9gNSD0QEeINs1juPURDB9LwN66b_azlE1BNMOjNKxTkNKdFzVM8cqSfv9jGv46M_NDLtmhv7P2VCA_UWbGMe6lNQd2eRDGM9rEZodnOAVg2gbjt8GT0QhpjjFRy_nbo1ylezcy4yCW9HdoReD-GxK4cTcTw0bMO74HS41dux0g3_Y7hnGJR3ah1k05iCFhJHvJWSwiLuExLxwzhxJ4Pyx-ALriv2VNPJgQ-EwjKsaHhLmXQsd_uPATM8fkzbygNsUw1icKx02JWolE1qc8DuMAOUiiYk5cECIptThHydMfWcTrEip0jgA8g39jZaN0gu3hWJK3Qz4J4diebMP8OuUY0EZqXnn-yWAYZ5XM1Z4QiAxKRADjLt99vXhAw1SZbswylYN9UexY6EcZtXCMRJ2yKEG6rqlAoaq2PUUpzkG3o-5yxrkO9ZXgnO5cMe09utqsqZ0iAmGdf5V0McUHmJBcQqs3A9qajJ6xqJnKgE0IcqbAiMyWQoVtHwGk2z5zhIXE-RbcxArpWmCOUBSlDTMTb_mSrVesKmzMLCq3LhNpInMSrbJsUbTKkBhTtgLxTPqxMnVde2_kwclhGlut50SS6OXhJ1OWulNmvwD9wAZJzLo-6oWArCIbS0rN1NzZbCX2eGow4fBKYFa3m0vj7tZs-76Cq7KbylwO-mAqwLaPGlEc1ICoFlFGZgj-B6Xsr39hvNWpel7J8nJmjfZipaL34IAhP934qKc7lDYi82hXSxR7GC6mHJXwgWu3fgam7p10VEO9ixerqiKRuZpTNnwp69guEohBwd9fvqwXi3Tb_nugs-bkT8zFji2HR3rXlITLIHG8ftHymzHzBOVcMrdK0VJk6oq05gqwrBmbOJ7EsNaikk8l5bfPSZWNZ5f5PSkvaP5rprteYhhDQXjNAelegjnKmkb1TXoGz6Sa36T526FM6ZslVYBVofRuLSgSY38S58BxlINfpKDrsmcWERG0HpvqwibDZrmopD_eDumFnE-35-qSVZKEjzUJH4gSZv7g0ktcVHFjuMXBFlmcvLlN05T03eqBmXGOx7vp26kyEajeYm2gfO9tA-V2ZSWl75Yiq9yeSRm4VPeOvXTnyUhn0HeBHzfiD5VM_WI");
        fileUrlMap
                .put("EQPRICING",
                        "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?service=eod&issue.assetClass=GENERIC&user.app=RDDH&user.host=xstm1489vdap&user.domain=ubsw&user.name=sso_rddhu&rddh.requesttype=TEXT&fields=cb64:eJx9VVFv3CAM_kNTdeqpJ-Wx6jTtpKu0SWvfueD22OWSLJB0268fYLCBkD3F32f7szEBYJB3Uhj4BNYw3ctZH6W34Xd7Ef07OoTWYJ46-_HQGuZldGnyh7qF3ElIOPZStcIMk6d-zYNJKCF_ztrcoDdfRGuJOz12yrwO3XyD57kzykKohMHbG7RGLfDZ9blyS7UoCb38NqkWHr13o5SPSCvpq1-7X0MA4vssbOgfcnpjdJneaudpgr5FfzmHs5IsGAAJRqc3UNBZJOhAKdh2gwaWJEiiHBBMFEabpBGW4ouffCbHFLkX0c0ESolhhP7YG5hAG8zKmP-Go3CpwPOXy0OVALRKbU-ipjXvd2UuMtFZybYspvdgHt3__upQJpN79DBPbSW8pHBLco62Jqcrbe13sRCCuIh9dRH7Hc9gv5rBIdU6sNahqnVItA4rrSbValirqWo1iVaTa7k_gP-dMC1v1n4fPgwe0RyjL5cNHV7U-wVLeAtLeLMsQZGMqET0UQlPhBLd8IEVnIEFnFXqxzACpB48JO5w0L6J6WqvXzEqY31_hVFDmFjVg9WrrrKdTeVtLzW8lUsrqAaEJWkzjF9pVwhh6wTLdrOsnKG20hhqhcik_CnuWARc_FTZuTQlI7LKp2IXIxfqxkf1ia_tnMIecm712q5EKjR1tYqm3nJP6PAsYmPeCu-UqLRBkYz4LRNFLU_E4YMxHbjHOcyfcdgCJla7kOeWHO9FFsfbwTSf24f7D4CrpuMbMZ3iSFQOc5pbcunRTuLSEx7p5J7KukkJvrW2-inTV2R2ldVaSnns6R8ra9lz");
        fileUrlMap
                .put("FUTURE",
                        "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?issue.assetClass=FUTURE&user.app=RDDH&user.host=xstm1489vdap&user.domain=ubsw&user.name=sso_rddhu&rddh.requesttype=TEXT&fields=cb64:eJxtVVty2zAMvJDHd0idZsbTOPFETmb6SVGQjZoiVRJ0o5y-4Euv-McSIXAJ7C7o1pO3sO2t6Xp6FAQbrxu1lRcQPTg6mUdQeAO7d6g36JyHrcbrFfCgoTMaZQ4K54B2ih8bet6eO6x8_fNTXoQ-Q47Ml0IRWM3HnVBewWYQ3k7vfcPh5oRdLiV-eq_dvtm0qdgWLVdmRQOx4ByVRpMVkir8ikf4uCUBozO7FhOeNoRGC_XD6CbkORLk3RrlQygPR7BHg5rKx078MfYDrGOAEZl5YZR60a0FFZrYa0fWd6BpUT9zcbSm8ZJ2poFZdGc8nz6USF3P0wIs2XkktrOo6V4Tmf1MdM4QckoOomGLUtDUVl1XIL1FGk5DHyGgtBdPddAYlXMzgTG-tEHTqZVNuJAX0UFi7F3j37G-ZzHXNCs_qTZmJ5y5uDKx9truw3LNwYGfl4RBaiHD2m1cR99VQ1dzZ_c0DEkVia5f-PCF7SRT0bzpnhrc3MErwl4hC5A7G6cpMlZIZsotaDlE8kBiJ9TO6NsT92FsTOAxNQ4J3pjSdpzdaImljisa3oxSpchvnVWLEVALJYoffoNS5t8vGFIHSQAGo5BZjFvWFbjIQDiMCw0DL4mvkai1mswbPO8d9kXjbNIAw29xkkffpMS0vDuI_Bu9FbHYemEgJ8C12pn9saz14Wl2xtMfJmNH_Hvm4VZRn9mnVEASXF0_WZbhtWVxYDmHLM8ttTFpDJ88esRIR5apNbabrh9ajGRtxReqCiyCm98kLCte4TH5h0EkfLveHuiQwcoQX4ylMprKSKHKpRMFfTbjvRrahJmh0_6bUIatu4Eb-2mpTwqtCWM6SeUZyv8xQzTc_EMV3-dhKdwlRZ-UOJdoAJ-D_AeCQqAd");
        fileUrlMap
                .put("OPTION",
                        "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?issue.assetClass=OPTION&tL.active=1&user.app=RDDH&user.host=xstm1489vdap&user.domain=ubsw&user.name=sso_rddhu&rddh.requesttype=TEXT&fields=cb64:eJx1Vu1y2yAQfKFM3sGjJDOe2q1b2Z3pT4TONjUClY807tP34AAhyfmTGCSOvb3dO7nd82UQrx_8ytQFnvTohFbPZ2GsOxrWwwtz8ORVL5-FtR5Ond32-S1mrbioPbir7p_c7tnHh_ij60rAeHTw0omTbMG5F29YOJxjjAbehfa2vQ-dlvS65rzxVowhlHHmYHTvuWt0vw7XMHvdDNorlwNybcYNd-r1fI7Y0zZ8jIJu3mvlrk8xGwTaAvdGuPvxPkK4D2bALfQIKmaUX0wnrWPOW3qr67ZWKPqNnIBrJP4Lx_pB7hUMWglOUU5K_PEpuJOnTNg4pPwTWixJ64y4zRMmUhbEvZbE6nQLrTFK440Bxe_lqbYi_NiJQbjqzpppRMXzsVyVo-A3MBEwxj8sQGPS7jT2iKI_imEOnTKNO0UlLuirCbUzBRnjqjxqAfU1KWW4kSJ_MokM5vp9ZfkmxD8jyBKBWRahJOIsOKkP71jCjVkJviLrrA2gzMt2gIc8EIzZXbQV6_xmUGXfzngfJNIIcCWPifZFCenNJbzMAsqu6HUKkWmks8Lq5ixKtUGp-1ZNnB-X8DmCNYy7VvyL-JO4p_D7UMVRCsxjYbOII98q1GQ3MFxYyLZ61FCSNLbVMdb_9tYNoFzA-1DL6Sz7rc1PMLVAFDBzBDMcZup2scGlIizbx3fPlAumLleRAeZiedR0YmLLB6kVVn6YUl5QHfeiVAjapw2zpVoQxZhJFHwK5hUStlAP5btjD_p3FEXqWKkRUVhfd3VYxZuRnWJhzSpF12rM5Tp4JErKUMg6p42UejJhD1wMTDZavb8hK9pkfDMrkyyaRF00r7BOqEvll677BRj67xeIFjXUcfF18U6kyNjWZoZdWr3rVrMm1ye_otFNoSwSppIQVlquuQq5zK-hyytPZf_g36mf4ewIopi3D0qnYDFsaskFacG1mZpNjPig47m1L-b55nnYSHQXMp5nQ5VVnJo4HUNBDpI5bJjD1K7WPh0nYYRCgQyAtgpZ8cH5ZSiungTQaIdhfPi0nTWt7LN62turNm7Tjxg-9VitLvWa9ePC-rmo5iIU6yTE9GnTsY-yM30g1eGUuN1A1B8AXA9x9sIPXGfRoXoUjrog3CwQmqtk5dZ3y88zEtALeQcp57DKe-P2aVLEahn2T2A7MQJslQKO9P08tTKGOUgwgeCHwykyGaUavIh-llkXccDsdBklcaRWUk-ai4_hHcs2lwhtLYVqo-HyWEor4yWUBZ--A9NOiPECEu1i7hF52o-T6NMHZO16O0Sm3TfJLnm3z5-xaT1Q50-rP3mspDWbel6Fbn3XJ3nPGKpgrWbQtnyi_we5LpK8");
        fileUrlMap
                .put("UNDLTODERIVATIVES",
                        "http://rddh-inst-uat.stm.swissbank.com:11105/RDDH-INST/instrumentRequestServlet?issue.assetClass=EQUITY&user.app=RDDH&user.host=xstm1489vdap&user.domain=ubsw&user.name=sso_rddhu&rddh.requesttype=TEXT&fields=cb64:eJxNjUkKgDAMRS9UeglXgohXSNssgh0kg-DtnYq4yX__8SEkYuhFQU0cPYWEasdoQtunrztDwbeztyBjcjp16DaEoZUN6vGbLcB6vFumeIdSXJGd1ZS9YGr5lh9AVNr7H79Dboz1BG35P-g");
        try {
            LOGGER.info(LOAD_STARTED + new Date());
            ExecutorService executorService = Executors.newFixedThreadPool(fileUrlMap.keySet().size());
            for (final String filename : fileUrlMap.keySet()) {
                executorService.execute(new Runnable() {
                    @Override
                    public void run() {
                        loadParallel(filename, fileUrlMap.get(filename));
                    }
                });
            }
            executorService.shutdown();

            if (executorService.awaitTermination(timeout, unit)) {
                LOGGER.info(LOAD_ENDED + new Date());
            } else {
                LOGGER.error(LOAD_TERMINATED_START + timeout + StaticValues.SPACE + unit + LOAD_TERMINATED_END + new Date());
                executorService.shutdownNow();
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    private void loadParallel(String sourceId, String url) {
        try {
            long start = System.currentTimeMillis();
            // Load Data TODO: loading 1 day + delta
            BufferedReader inputReader = webServiceClientFactory.getNewInstance().loadWebSSOURL(url);

            // Compare header with config source fields
            String line = inputReader.readLine();
            LOGGER.info(sourceId + " header: " + line);
            // Data file
            String loadFileName = filePath + sourceId + LOAD_FILE_EXTENSION;
            DataOutputStream fileOutStream = fileSystem.createFile(loadFileName);
            while ((line = inputReader.readLine()) != null) {
                fileOutStream.writeBytes(line + Shared.NEWLINE);
            }

            // Close streams
            inputReader.close();
            fileOutStream.flush();
            fileOutStream.close();

            String message = Shared.LOADED + sourceId + Shared.LOG_DELIMITER + Shared.elapsedTime(start);
            LOGGER.info(message);
        } catch (Throwable t) {
            t.printStackTrace();
            LOGGER.info(sourceId + StaticValues.SPACE + t.toString());
        }
    }

    public void setFileSystem(FileSystem fileSystem) {
        this.fileSystem = fileSystem;
    }

    public void setWebServiceClientFactory(WebServiceClientFactory webServiceClientFactory) {
        this.webServiceClientFactory = webServiceClientFactory;
    }

    public void initialize() throws Exception {
        // --------------------------------------------------------------------
        // Prepare keystore
        // (UBS has self-signed certs so we should use special keystore)
        // --------------------------------------------------------------------

        // Load keystore
        KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());

        InputStream inputStream = RDDHWebServiceClient.class.getResourceAsStream(KEYSTORE_LOCATION);
        try {
            trustStore.load(inputStream, KEYSTORE_PASSWORD.toCharArray());
        } finally {
            inputStream.close();
        }

        // SSL scheme
        SSLSocketFactory socketFactory = new SSLSocketFactory(trustStore);
        Scheme sslScheme = new Scheme("https", socketFactory, SECURE_PORT);

        // --------------------------------------------------------------------
        // Create http client
        // --------------------------------------------------------------------

        AuthScope authScope = new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT);

        Credentials credentials = new UsernamePasswordCredentials(RDDH_RCAS_SSO_USERNAME, RDDH_RCAS_SSO_PASSWORD);

        httpClient = new DefaultHttpClient();
        httpClient.getConnectionManager().getSchemeRegistry().register(sslScheme);
        httpClient.getCredentialsProvider().setCredentials(authScope, credentials);
        httpClient.getParams().setBooleanParameter("http.authentication.preemptive", true);
        httpClient.getParams().setBooleanParameter(ClientPNames.ALLOW_CIRCULAR_REDIRECTS, true);
        httpClient.getParams().setBooleanParameter(ClientPNames.HANDLE_REDIRECTS, true);
        httpClient.getParams().setParameter(ClientPNames.COOKIE_POLICY, CookiePolicy.BROWSER_COMPATIBILITY);

        // --------------------------------------------------------------------
        // Make RCAS authentication call
        // --------------------------------------------------------------------

        HttpGet initialGet = new HttpGet(RDDH_RCAS_ENDPOINT_URL + "?appid=" + RDDH_RCAS_AUTH_APPGUID);

        HttpResponse response = executeWithRetry(initialGet);

        int statusCode = response.getStatusLine().getStatusCode();
        if (statusCode != HttpStatus.SC_OK) {
            throw new IOException(String.format("Authentication failed. Reason: %s, code: %d", response.getStatusLine().getReasonPhrase(),
                    statusCode));
        }

        HttpEntity entity = response.getEntity();
        if (entity == null) {
            throw new IOException("Authentication failed. Response is empty");
        }

        entity.consumeContent();

        // --------------------------------------------------------------------
        // First dummy call should be simple - just to get and save auth cookie
        // (auth can't process with long url - there's bug somethere)
        // --------------------------------------------------------------------

        StringBuilder authUrlBuilder = new StringBuilder();
        authUrlBuilder.append(RDDH_WS_HOST);
        authUrlBuilder.append("/");
        authUrlBuilder.append(RDDH_WS_PATH);
        authUrlBuilder.append("?");
        authUrlBuilder.append("issue.assetClass=BOND").append("&");
        authUrlBuilder.append("messageLevel=issue").append("&");
        authUrlBuilder.append("issue.active=1").append("&");
        authUrlBuilder.append("issue.ubsId=0").append("&"); // Query limiter
        authUrlBuilder.append("user.app=").append(RDDH_WS_USER_APP).append("&");
        authUrlBuilder.append("user.host=").append(RDDH_WS_USER_HOST).append("&");
        authUrlBuilder.append("user.name=").append(RDDH_RCAS_SSO_USERNAME).append("&");
        authUrlBuilder.append("user.domain=").append(RDDH_WS_USER_DOMAIN).append("&");
        authUrlBuilder.append("rddh.requesttype=TEXT");

        String authUrl = authUrlBuilder.toString();
        LOGGER.info(AUTHORIZING);
        // System.out.println("authUrl: " + authUrl);
        HttpGet httpAuthGet = new HttpGet(authUrl);

        HttpResponse httpAuthResponse = executeWithRetry(httpAuthGet);

        // Get result code
        int authStatusCode = httpAuthResponse.getStatusLine().getStatusCode();

        // Check result code
        if (authStatusCode != HTTP_CODE_SUCCESS) {
            throw new IOException(String.format("Auth request failed with code [%d] and message [%s] ", authStatusCode, httpAuthResponse
                    .getStatusLine().getReasonPhrase()));
        }

        // Check content
        HttpEntity httpAuthEntity = httpAuthResponse.getEntity();

        if (httpAuthEntity == null) {
            throw new IOException("Data response is empty");
        }

        // Copy content
        InputStream authInputStream = httpAuthEntity.getContent();
        try {
            // String content = IOUtils.toString(authInputStream, "UTF-8");
            // System.out.println(">>> " + content);
        } finally {
            authInputStream.close();
        }
    }

    private HttpResponse executeWithRetry(HttpUriRequest request) throws Exception {
        HttpResponse httpAuthResponse = null;
        for (int i = 1; httpAuthResponse == null && i <= MAX_TRIES; i++) {
            try {
                httpAuthResponse = httpClient.execute(request);
            } catch (Exception e) {
                LOGGER.info(RETRYING + i + OF + MAX_TRIES + TRIES);
                // Throw exception if max tries reached
                if (i == MAX_TRIES) {
                    throw e;
                }
            }
        }
        return httpAuthResponse;
    }

    public BufferedReader loadWebSSOURL(String dataUrl) throws Exception {
        // Initialize
        initialize();

        // Replace parameters
        dataUrl = replaceParameters(dataUrl);

        // --------------------------------------------------------------------
        // Second call is for data
        //
        // http://confluence.swissbank.com/display/RDDH/Web+Service
        // --------------------------------------------------------------------

        LOGGER.info(Shared.CONNECTING + dataUrl);
        HttpUriRequest request = null;
        // POST
        if (dataUrl.startsWith(Shared.REQUEST_TYPE_POST)) {
            request = createPostRequest(dataUrl.substring(Shared.REQUEST_TYPE_POST.length()));
        }
        // GET
        else {
            request = new HttpGet(dataUrl);
        }

        HttpResponse httpDataResponse = executeWithRetry(request);

        // Check result code
        int dataStatusCode = httpDataResponse.getStatusLine().getStatusCode();

        if (dataStatusCode != HTTP_CODE_SUCCESS) {
            HttpEntity httpDataErrorEntity = httpDataResponse.getEntity();

            if (httpDataErrorEntity != null) {
                httpDataErrorEntity.consumeContent();
            }

            throw new IOException(String.format("Data request failed with code [%d] and message [%s] ", dataStatusCode, httpDataResponse
                    .getStatusLine().getReasonPhrase()));
        }

        // Check content
        HttpEntity httpDataEntity = httpDataResponse.getEntity();

        if (httpDataEntity == null) {
            throw new IOException("Data response is empty");
        }

        // Copy content
        InputStream dataInputStream = httpDataEntity.getContent();

        return new BufferedReader(new InputStreamReader(dataInputStream));
    }

    private String replaceParameters(String dataUrl) {
        return dataUrl.replaceAll("\\$\\{RDDH_WS_HOST\\}", RDDH_WS_HOST).replaceAll("\\$\\{RDDH_WS_USER_APP\\}", RDDH_WS_USER_APP)
                .replaceAll("\\$\\{RDDH_WS_USER_HOST\\}", RDDH_WS_USER_HOST)
                .replaceAll("\\$\\{RDDH_RCAS_SSO_USERNAME\\}", RDDH_RCAS_SSO_USERNAME);
    }

    private HttpUriRequest createPostRequest(String dataUrl) throws UnsupportedEncodingException {
        HttpPost httpDataGetViaPost = new HttpPost(dataUrl.substring(0, dataUrl.indexOf(Shared.URLPARAMSTART)));

        // Parse URL to extract header/fields
        HashMap<String, String> urlMap = new HashMap<String, String>();
        Scanner urlScanner = new Scanner(dataUrl.substring(dataUrl.indexOf(Shared.URLPARAMSTART) + 1));
        urlScanner.useDelimiter(Shared.URLPARAMSDELIMITER);
        while (urlScanner.hasNext()) {
            String keyValue = urlScanner.next();
            String[] parsedKeyValue = Shared.parseByOperator(keyValue);
            String key = parsedKeyValue[0];
            String value = parsedKeyValue[2];
            urlMap.put(key, value);
        }
        urlScanner.close();

        httpDataGetViaPost.addHeader("user.app", urlMap.get("user.app"));
        httpDataGetViaPost.addHeader("user.host", urlMap.get("user.host"));
        httpDataGetViaPost.addHeader("user.name", urlMap.get("user.name"));
        httpDataGetViaPost.addHeader("user.domain", urlMap.get("user.domain"));
        httpDataGetViaPost.addHeader("rddh.requesttype", urlMap.get("rddh.requesttype"));

        // create the request XML with DOM4J helper classes
        Document document = DocumentHelper.createDocument();
        Element requestRoot = document.addElement("Request");
        requestRoot.addElement("level").addText(urlMap.get("level"));
        requestRoot.addElement("fields").addText(urlMap.get("fields"));
        requestRoot.addElement("relation");
        requestRoot.addElement("cascading");

        Element descriptor = requestRoot.addElement("Descriptor");
        Element requestIdentifier = descriptor.addElement("Identifier");
        requestIdentifier.addElement("name").addText("issue.assetClass");
        requestIdentifier.addElement("value").addText(urlMap.get("issue.assetClass"));

        requestIdentifier = descriptor.addElement("Identifier");
        requestIdentifier.addElement("name").addText("issue.assetType");
        requestIdentifier.addElement("value").addText(urlMap.get("issue.assetType"));

        requestIdentifier = descriptor.addElement("Identifier");
        requestIdentifier.addElement("name").addText("tL.exchange");
        requestIdentifier.addElement("value").addText(urlMap.get("tL.exchange"));

        requestIdentifier = descriptor.addElement("Identifier");
        requestIdentifier.addElement("name").addText("tL.exchange.relation");
        requestIdentifier.addElement("value").addText(urlMap.get("tL.exchange.relation"));

        String xmlReq = document.asXML();
        LOGGER.info("[REQUEST] :" + xmlReq);

        // send the request string to the servlet
        StringEntity xmlPostEntity = new StringEntity(xmlReq, HTTP.UTF_8);
        xmlPostEntity.setContentType("text/xml");
        httpDataGetViaPost.setEntity(xmlPostEntity);
        return httpDataGetViaPost;
    }

}
