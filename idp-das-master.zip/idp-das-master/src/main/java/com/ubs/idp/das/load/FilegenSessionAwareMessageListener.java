package com.ubs.idp.das.load;

import java.util.Enumeration;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.listener.SessionAwareMessageListener;

import com.ubs.idp.das.exception.UpStreamSourceException;

public abstract class FilegenSessionAwareMessageListener implements
		SessionAwareMessageListener<Message> {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(FilegenSessionAwareMessageListener.class);

	private static final String NEW_LINE = "\n";

	@Override
	public void onMessage(Message message, Session session) throws JMSException {
		LOGGER.info(logMessageRecieved(message));

		try {
			String data;
			try {
				data = ((TextMessage) message).getText();
			} catch (JMSException e) {
				throw new UpStreamSourceException(
						"Message recieved was not an instance of TextMessage",
						e);
			}

			onMessageAction(data);
			session.commit();
		} catch (RuntimeException t) {
			try {
				session.commit();
			} catch (JMSException jmsException) {
				throw new UpStreamSourceException(
						// NOSONAR
						"Exception encountered while attempting a commit of changes",
						jmsException);
			}
			throw t;
		}
	}

	protected String logMessageRecieved(Message message) {
		StringBuilder logMessageBuilder = new StringBuilder();
		logMessageBuilder.append("Message was recieved");
		logMessageBuilder.append(NEW_LINE);
		try {
			logMessageBuilder.append("Message ID: ")
					.append(message.getJMSMessageID()).append(NEW_LINE)
					.append("Message Timestamp: ")
					.append(message.getJMSTimestamp()).append(NEW_LINE)
					.append("Message Destination: ")
					.append(message.getJMSDestination()).append(NEW_LINE);
			Enumeration<?> enumeration = message.getPropertyNames();
			while (enumeration.hasMoreElements()) {
				String property = enumeration.nextElement().toString();
				logMessageBuilder.append(property).append(" : ")
						.append(message.getStringProperty(property))
						.append(NEW_LINE);
			}
		} catch (JMSException e) {
			LOGGER.error(
					"Encountered JMS Exception while logging message details: ",
					e);
		}
		return logMessageBuilder.toString();
	}

	protected abstract void onMessageAction(String data);
}