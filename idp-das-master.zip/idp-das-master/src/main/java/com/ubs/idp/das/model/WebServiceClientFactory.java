package com.ubs.idp.das.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value = "singleton")
public class WebServiceClientFactory {
	public RDDHWebServiceClient getNewInstance() throws Exception {
		return new RDDHWebServiceClient();
	}
}
