package com.ubs.idp.das.webservice;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ubs.idp.das.exception.FilegenException;
import com.ubs.idp.das.model.Shared;
import com.ubs.idp.das.response.ResponseFormatter;
import com.ubs.idp.metadata.client.MetadataService;

@Controller
@RequestMapping(value = "/v1/meta")
public class MetadataController {

    private static final Logger LOGGER = LoggerFactory.getLogger(MetadataController.class);

    @Autowired
    @Qualifier("mdsClient")
    private MetadataService metadataService;

    @RequestMapping(value = "/{view:.+}", produces = MediaType.TEXT_PLAIN_VALUE, method = { RequestMethod.GET, RequestMethod.POST })
    public void filter(HttpServletRequest request, @PathVariable(value = "view") String view, HttpServletResponse response)
            throws Throwable {
        ResponseFormatter.mapper.writeValue(response.getOutputStream(), metadataService.getAttributeNamesForDataset(view));
    }

    @ExceptionHandler(FilegenException.class)
    public void handleException(FilegenException e, HttpServletResponse response) throws IOException {
        LOGGER.error(e.getMessage());
        Shared.handleError(LOGGER, e, response.getOutputStream());
        if (e.getMessage().startsWith(Shared.UNAUTHORIZED_VIEW_MESSAGE)) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, e.getMessage());
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
        }
    }

    @ExceptionHandler(Throwable.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR, reason = Shared.INTERNAL_SERVER_ERROR_MESSAGE)
    public void catchAll(Throwable t, HttpServletResponse response) throws IOException {
        Shared.handleError(LOGGER, t, response.getOutputStream());
    }
}
