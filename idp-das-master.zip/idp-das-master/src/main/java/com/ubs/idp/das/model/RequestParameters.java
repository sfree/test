package com.ubs.idp.das.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.ubs.idp.das.exception.FilegenException;
import com.ubs.idp.das.model.Shared.ResponseFormat;

public class RequestParameters {
	private List<String> filterIds = null;
	private List<String> invalidFieldsList = new ArrayList<String>();
	private String[] fields = null;
	private int[] fieldPositions = null;
	private String delimiter;
	private char quoteChar;
	private char escapeChar;
	private String hideHeader = null;
	private String includeInput = null;
	private List<String> fileNames = null;
	private List<String> outputCassandraFields = null;
	private ResponseFormat responseFormat = ResponseFormat.TEXT;
	private String distinct = null;
	private String resource;
	private List<String> urls;
	private String delta;
	private boolean trim;
	private int limit = Integer.MAX_VALUE;
	private Scanner inputStreamScanner;
	public boolean isNonIndexedQuery = true;
	public String viewName;
	private boolean isIDPStatusLookup = false;
	private boolean isUnionExclusiveLookup = false;
	private String lookupAttribute;
	private Set<String> lookupKeys = null;
	private List<String> unionParamValues= null;
	
	public List<String> getUnionParamValues() {
		return unionParamValues;
	}

	public void setUnionParamValues(List<String> unionParamValues) {
		this.unionParamValues = unionParamValues;
	}	

	public List<String> getFilterIds() {
		return filterIds;
	}

	public void setFilterIds(List<String> filterIds) {
		this.filterIds = filterIds;
	}

	public List<String> getInvalidFieldsList() {
		return invalidFieldsList;
	}

	public void setInvalidFieldsList(List<String> invalidFieldsList) {
		this.invalidFieldsList = invalidFieldsList;
	}

	public String[] getFields() {
		return fields;
	}

	public void setFields(String[] fields) {
		this.fields = fields;
	}

	public int[] getFieldPositions() {
		return fieldPositions;
	}

	public void setFieldPositions(int[] fieldPositions) {
		this.fieldPositions = fieldPositions;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public char getQuoteChar() {
		return quoteChar;
	}

	public void setQuoteChar(char quoteChar) {
		this.quoteChar = quoteChar;
	}

	public char getEscapeChar() {
		return escapeChar;
	}

	public void setEscapeChar(char escapeChar) {
		this.escapeChar = escapeChar;
	}

	public String getHideHeader() {
		return hideHeader;
	}

	public void setHideHeader(String hideHeader) {
		this.hideHeader = hideHeader;
	}

	public String getIncludeInput() {
		return includeInput;
	}

	public void setIncludeInput(String includeInput) {
		this.includeInput = includeInput;
	}

	public List<String> getFileNames() {
		return fileNames;
	}

	public void setFileNames(List<String> fileNames) {
		this.fileNames = fileNames;
	}

	public List<String> getOutputCassandraFields() {
		return outputCassandraFields;
	}

	public void setOutputCassandraFields(List<String> outputCassandraFields) {
		this.outputCassandraFields = outputCassandraFields;
	}

	public ResponseFormat getResponseFormat() {
		return responseFormat;
	}

	public void setResponseFormat(String responseFormat) {
		try {
			this.responseFormat = ResponseFormat.valueOf(responseFormat);
		} catch (IllegalArgumentException e) {
			throw new FilegenException(Shared.INVALID_FORMAT + responseFormat);
		}
	}

	/**
	 * Check if IDP_STATUS field selected
	 * 
	 * @return
	 */
	public boolean isIDPStatusLookup() {
		return isIDPStatusLookup;
	}

	public void setIDPStatusLookup(boolean isIDPStatusLookup) {
		this.isIDPStatusLookup = isIDPStatusLookup;
	}

	public boolean isUnionExclusiveLookup() {
		return isUnionExclusiveLookup;
	}

	public void setUnionExclusiveLookup(String isUnionExclusiveLookup) {
		this.isUnionExclusiveLookup = Shared.isYes(isUnionExclusiveLookup);
	}

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}

	public List<String> getUrls() {
		return urls;
	}

	public void setUrls(List<String> urls) {
		this.urls = urls;
	}

	public String getDelta() {
		return delta;
	}

	public void setDelta(String delta) {
		this.delta = delta;
	}

	public boolean getTrim() {
		return trim;
	}

	public void setTrim(boolean trim) {
		this.trim = trim;
	}

	public void setScanner(Scanner inputStreamScanner) {
		this.inputStreamScanner = inputStreamScanner;
	}

	public Scanner getInputStreamScanner() {
		return inputStreamScanner;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public String getDistinct() {
		return distinct;
	}

	public void setDistinct(String distinct) {
		this.distinct = distinct;
	}

	public String getLookupAttribute() {
		return lookupAttribute;
	}

	public void setLookupAttribute(String lookupAttribute) {
		this.lookupAttribute = lookupAttribute;
	}

	public Set<String> getLookupKeys() {
		return lookupKeys;
	}

	public void setLookupKeys(Set<String> lookupKeys) {
		this.lookupKeys = lookupKeys;
	}

}
