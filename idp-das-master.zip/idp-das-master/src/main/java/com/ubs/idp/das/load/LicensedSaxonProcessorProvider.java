package com.ubs.idp.das.load;

import net.sf.saxon.Configuration;
import net.sf.saxon.expr.parser.Optimizer;
import net.sf.saxon.s9api.Processor;

/**
 * Provides creation of Saxonica based Processor used in XML based processing.
 * 
 * @author brownal
 * 
 */
public enum LicensedSaxonProcessorProvider {
	INSTANCE;
	private static Processor processor;

	/**
	 * Creates a new net.sf.saxon.s9api.Processor object
	 * 
	 * @return
	 */
	public static Processor createNewLicensedProcessor() {
		Configuration configuration = Configuration.newConfiguration();
		configuration.obtainOptimizer().setOptimizationLevel(
				Optimizer.NO_OPTIMIZATION);
		configuration.setGenerateByteCode(false);
		return new Processor(configuration);
	}

	/**
	 * Creates a new net.sf.saxon.s9api.Processor only if one has not already
	 * been created. Processor abides by singleton contract
	 * 
	 * @return
	 */
	public static Processor getLicensedProcessor() {
		if (processor == null) {
			processor = createNewLicensedProcessor();
		}
		return processor;
	}
}