package com.ubs.idp.das.model;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value = "singleton")
public class Stats {

	public Date initializeTime;
	public HashMap<String, ResourceStats> queryStatsMap;
	public HashMap<String, ResourceStats> loadStatsMap;
	public HashMap<String, ResourceStats> indexStatsMap;
	public HashMap<String, ResourceStats> currentLoadStatsMap;
	public HashMap<String, ResourceStats> currentIndexStatsMap;

	Stats() {
		initialize();
	}

	public void initialize() {
		initializeTime = Calendar.getInstance().getTime();
		queryStatsMap = new HashMap<String, ResourceStats>();
		loadStatsMap = new HashMap<String, ResourceStats>();
		indexStatsMap = new HashMap<String, ResourceStats>();
		currentLoadStatsMap = new HashMap<String, ResourceStats>();
		currentIndexStatsMap = new HashMap<String, ResourceStats>();
	}

	public void addQueryStats(String resource, long readRows,
			long elapsedTimeMillis) {
		if (!queryStatsMap.containsKey(resource)) {
			queryStatsMap.put(resource, new ResourceStats());
		}
		addStats(queryStatsMap.get(resource), readRows, -1, -1,
				elapsedTimeMillis);
	}

	/**
	 * 
	 * @param resource
	 * @param numGoodRows
	 * @param numBadRows
	 * @param numFailRows
	 * @param elapsedTimeMillis
	 */
	public void addLoadStats(String resource, long numGoodRows,
			long numBadRows, long numFailRows, long elapsedTimeMillis) {
		addStats(loadStatsMap.get(resource), numGoodRows, numBadRows,
				numFailRows, elapsedTimeMillis);
	}

	public void addIndexStats(String resource, long numGoodRows,
			long numBadRows, long numFailRows, long elapsedTimeMillis) {
		addStats(indexStatsMap.get(resource), numGoodRows, numBadRows,
				numFailRows, elapsedTimeMillis);

	}

	public void addStats(ResourceStats resourceStats, long numGoodRows,
			long numBadRows, long numFailRows, long elapsedTimeMillis) {
		// Aggregate rows & elapsed time
		resourceStats.addRows(numGoodRows, numBadRows, numFailRows);
		resourceStats.addElapsedTimeMillis(elapsedTimeMillis);
	}

	public void startStatsForCurrentLoad(String dataset) {
		ResourceStats resourceStats = new ResourceStats();
		resourceStats.setStartDateTime(new Date());
		currentLoadStatsMap.put(dataset, resourceStats);
		// Initialize aggregate as well
		if (!loadStatsMap.containsKey(dataset)) {
			loadStatsMap.put(dataset, new ResourceStats());
		}
	}

	public void setStatsForCurrentLoad(String dataset, int rowCount) {
		currentLoadStatsMap.get(dataset).setRows(rowCount);
	}

	// remove from current load stats
	public void endStatsForCurrentLoad(String dataset) {
		currentLoadStatsMap.remove(dataset);
	}

	public void startStatsForCurrentIndex(String dataset) {
		ResourceStats resourceStats = new ResourceStats();
		resourceStats.setStartDateTime(new Date());
		currentIndexStatsMap.put(dataset, resourceStats);
		// Initialize aggregate as well
		if (!indexStatsMap.containsKey(dataset)) {
			indexStatsMap.put(dataset, new ResourceStats());
		}
	}

	public void setStatsForCurrentIndex(String dataset, int rowCount) {
		currentIndexStatsMap.get(dataset).setRows(rowCount);
	}

	// remove from current index stats
	public void endStatsForCurrentIndex(String dataset) {
		currentIndexStatsMap.remove(dataset);
	}
}
