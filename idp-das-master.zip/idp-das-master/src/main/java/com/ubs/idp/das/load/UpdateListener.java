package com.ubs.idp.das.load;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class UpdateListener extends FilegenSessionAwareMessageListener {

	private String lockName;
	private static final Map<String, Object> LOCKS = new HashMap<String, Object>();

	@Override
	protected void onMessageAction(String data) {
		Object monitor = null;
		if (this.lockName != null) {
			synchronized (LOCKS) {
				monitor = LOCKS.get(this.lockName);
			}
		}
		if (monitor != null) {
			synchronized (monitor) {
				onMessageActionReal(data);
			}
		} else {
			onMessageActionReal(data);
		}
	}

	private void onMessageActionReal(String data) {
		System.out.println(data);
	}

}
