package com.ubs.idp.das;

import java.io.IOException;
import java.io.StringReader;

import au.com.bytecode.opencsv.CSVReader;

public class Common {
	public static final int BLANK_CODE = -1;
	public static final int SYSDATE_CODE = -2;
	public static final int SYSDATE_PREV_CODE = -3;
	public static final int SYSDATE_NEXT_CODE = -4;
	public static final int IDP_STATUS_CODE = -5;
	public static final String COLUMNDELIMITER = ",";
	public static final String JOINDELIMITER = "_";
	public static final String BLANK = "";
	public static final String STANDARD_DELIMITER = "\t";
	public static final String URLPARAMSDELIMITER = "&";
	public static final char URLPARAMVALUEDELIMITER = '=';
	public static final String VALUESDELIMITER = ",";
	public static final String STATUS_OK = "OK";
	public static final String STATUS_ERROR = "ERROR";
	public static final String YES = "y";
	public static final String NO = "n";
	public static final String FIELDS_PARAM = "&fields=";
	// public static final String XML = "xml://";
	public static final String FILE = "file://";
	// public static final String HTTP = "http://";
	// public static final String MDF = "mdf://";
	public static final String RDDH_WS_HOST = "\\$\\{RDDH_WS_HOST\\}";
	public static final String RDDH_WS_USER_APP = "\\$\\{RDDH_WS_USER_APP\\}";
	public static final String RDDH_WS_USER_HOST = "\\$\\{RDDH_WS_USER_HOST\\}";
	public static final String RDDH_RCAS_SSO_USERNAME = "\\$\\{RDDH_RCAS_SSO_USERNAME\\}";
	public static final String ADD_FIELDS = "\\$\\{ADD_FIELDS\\}";
	public static final String ADD_ENCODED_FIELDS = "\\$\\{ADD_ENCODED_FIELDS\\}";
	public static final String REGEX_ESCAPE = "\\\\";
	public static final String NEWLINE = "\n";
	public static final String INVALID_KEY_ERROR_MESSAGE = "Invalid key for dataset ";

	/**
	 * Parses a CSV string to String []
	 * 
	 * @param csvString
	 * @return parsed String []
	 * @throws IOException
	 */
	public static String[] parseCSVToArray(String csvString) throws IOException {
		CSVReader csvReader = new CSVReader(new StringReader(csvString));
		String[] strArray = csvReader.readNext();
		csvReader.close();
		return strArray;
	}
}
