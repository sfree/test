package com.ubs.idp.das.response;

import static org.apache.commons.lang.StringUtils.isBlank;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PostFilter extends ResponseFormatter {

    public static final String DEFAULT_MIN_DENOMINATOR = "1000";
    public static final String DEFAULT_DERIVED_ISSUE_FACTOR = "100";
    public static final String DEFAULT_DERIVED_VALUE_FACTOR = "1";
    public static final String DERIVED_MIN_DENOMINIATION = "derived.minDenomination";
    public static final String DERIVED_CURRENT_COUPON_RATE = "derived.currentCouponRate";
    public static final String DERIVED_BOND_ISSUER_TYPE = "derived.bondIssuerType";
    public static final String DERIVED_SEDOL = "derived.sedol";
    public static final String DERIVED_CUSIP = "derived.cusip";
    public static final String DERIVED_ISIN = "derived.isin";
    public static final String COUPON_CURRENT_COUPON_RATE = "coupon.currentCouponRate";
    public static final String ISSUE_BOND_ISSUER_TYPE = "issue.bondIssuerType";
    public static final String ISSUE_NOMINAL_VALUE_OF_UNIT = "issue.nominalValueOfUnit";
    public static final String TL_SEDOL = "tL.sedol";
    public static final String ISSUE_CUSIP = "issue.cusip";
    public static final String ISSUE_ISIN = "issue.isin";
    public static final String DERIVED_ISSUE_FACTOR = "derived.issueFactor";
    public static final String DERIVED_VALUE_FACTOR = "derived.valueFactor";
    public static final String ISSUE_ASSET_CLASS = "issue.assetClass";
    public static final String ASSET_CLASS_BOND = "BOND";
    public static final String ASSET_CLASS_EQUITY = "EQUITY";

    private static final Logger LOGGER = LoggerFactory.getLogger(PostFilter.class);

    private int assetClassPos = -1;
    private int derivedValueFactorPos = -1;
    private int derivedIssueFactorPos = -1;
    private int derivedIsinPos = -1;
    private int derivedCuspinPos = -1;
    private int derivedSedolPos = -1;
    private int derivedBondIssueTypePos = -1;
    private int derivedCurrentCouponRatePos = -1;
    private int derivedMinDenominatorPos = -1;
    private int issueNominalValueOfUnitPos = -1;
    private int issueIsinPos = -1;
    private int issueCusipPos = 1;
    private int tlSedolPos = -1;
    private int issueBondIssuerTypePos = -1;
    private int couponCurrentCouponRatePos = -1;

    private int row = 0;

    @Override
    public void writeHeader(String[] strArray) throws Exception {
        applyDefaultValuesForSecFuncding(strArray);
    }

    @Override
    public boolean writeLine(String[] strArray) throws Exception {
        applyDefaultValuesForSecFuncding(strArray);
        return super.writeLine(strArray);
    }

    private void applyDefaultValuesForSecFuncding(String[] strArray) {
        if (row == 0) { // header
            for (int i = 0; i < strArray.length; i++) {
                LOGGER.debug("*** HEADER ROW ***");
                extractHeaderPositionsForConstantFieldsForSecurity(strArray, i);
                extractHeaderPositionsForDerivedFields(strArray, i);
                extractHeaderPositionsForMinDenominator(strArray, i);
            }
        } else {
            if (LOGGER.isDebugEnabled()) {
                for (int i = 0; i < strArray.length; i++) {
                    LOGGER.debug("*** data, pos={}, val={}", i, strArray[i]);
                }
            }
            applyDefaultIssueValueFactor(strArray);
            applyDerivedFields(strArray);
            applyMinDenominator(strArray);
        }
        row++;
    }

    private void extractHeaderPositionsForConstantFieldsForSecurity(String[] strArray, int index) {
        if (ISSUE_ASSET_CLASS.equals(strArray[index])) {
            assetClassPos = index;
        }
        if (DERIVED_VALUE_FACTOR.equals(strArray[index])) {
            derivedValueFactorPos = index;
        }
        if (DERIVED_ISSUE_FACTOR.equals(strArray[index])) {
            derivedIssueFactorPos = index;
        }
    }

    private void extractHeaderPositionsForDerivedFields(String[] strArray, int index) {

        if (ISSUE_ISIN.equals(strArray[index])) {
            issueIsinPos = index;
        }
        if (ISSUE_CUSIP.equals(strArray[index])) {
            issueCusipPos = index;
        }
        if (TL_SEDOL.equals(strArray[index])) {
            tlSedolPos = index;
        }
        if (ISSUE_BOND_ISSUER_TYPE.equals(strArray[index])) {
            issueBondIssuerTypePos = index;
        }
        if (COUPON_CURRENT_COUPON_RATE.equals(strArray[index])) {
            couponCurrentCouponRatePos = index;
        }
        if (DERIVED_ISIN.equals(strArray[index])) {
            derivedIsinPos = index;
        }
        if (DERIVED_CUSIP.equals(strArray[index])) {
            derivedCuspinPos = index;
        }
        if (DERIVED_SEDOL.equals(strArray[index])) {
            derivedSedolPos = index;
        }
        if (DERIVED_BOND_ISSUER_TYPE.equals(strArray[index])) {
            derivedBondIssueTypePos = index;
        }
        if (DERIVED_CURRENT_COUPON_RATE.equals(strArray[index])) {
            derivedCurrentCouponRatePos = index;
        }
    }

    private void extractHeaderPositionsForMinDenominator(String[] strArray, int index) {
        if (DERIVED_MIN_DENOMINIATION.equals(strArray[index])) {
            derivedMinDenominatorPos = index;
        }
        if (ISSUE_NOMINAL_VALUE_OF_UNIT.equals(strArray[index])) {
            issueNominalValueOfUnitPos = index;
        }
    }

    private void applyDefaultIssueValueFactor(String[] strArray) {
        if (isHeaderPresent(assetClassPos, strArray.length)) {
            if (ASSET_CLASS_BOND.equals(strArray[assetClassPos]) || ASSET_CLASS_EQUITY.equals(strArray[assetClassPos])) {
                if (isHeaderPresent(derivedValueFactorPos, strArray.length) && isBlank(strArray[derivedValueFactorPos])) {
                    strArray[derivedValueFactorPos] = DEFAULT_DERIVED_VALUE_FACTOR;
                }
                if (isHeaderPresent(derivedIssueFactorPos, strArray.length) && isBlank(strArray[derivedIssueFactorPos])) {
                    strArray[derivedIssueFactorPos] = DEFAULT_DERIVED_ISSUE_FACTOR;
                }
            }
        }
    }

    private void applyDerivedFields(String[] strArray) {
        if (isHeaderPresent(derivedIsinPos, strArray.length) && isBlank(strArray[derivedIsinPos])) {
            strArray[derivedIsinPos] = strArray[issueIsinPos];
        }
        if (isHeaderPresent(derivedCuspinPos, strArray.length) && isBlank(strArray[derivedCuspinPos])) {
            strArray[derivedCuspinPos] = strArray[issueCusipPos];
        }
        if (isHeaderPresent(derivedSedolPos, strArray.length) && isBlank(strArray[derivedSedolPos])) {
            strArray[derivedSedolPos] = strArray[tlSedolPos];
        }
        if (isHeaderPresent(derivedBondIssueTypePos, strArray.length) && isBlank(strArray[derivedBondIssueTypePos])) {
            strArray[derivedBondIssueTypePos] = strArray[issueBondIssuerTypePos];
        }
        if (isHeaderPresent(derivedCurrentCouponRatePos, strArray.length)
                && isBlank(strArray[derivedCurrentCouponRatePos])) {
            strArray[derivedCurrentCouponRatePos] = strArray[couponCurrentCouponRatePos];
        }
    }

    private void applyMinDenominator(String[] strArray) {
        if (isHeaderPresent(derivedMinDenominatorPos, strArray.length) && isBlank(strArray[derivedMinDenominatorPos])) {
            strArray[derivedMinDenominatorPos] = DEFAULT_MIN_DENOMINATOR;
        }
        if (isHeaderPresent(derivedMinDenominatorPos, strArray.length)
                && isHeaderPresent(issueNominalValueOfUnitPos, strArray.length)) {
			try {
				if (!isBlank(strArray[issueNominalValueOfUnitPos])
						&& Float.valueOf(strArray[issueNominalValueOfUnitPos]) > Float
								.valueOf(strArray[derivedMinDenominatorPos])) {
					strArray[derivedMinDenominatorPos] = strArray[issueNominalValueOfUnitPos];
				}
			} catch (NumberFormatException e) {
				LOGGER.warn(
						"Invalid number whilst evaluating derivedMinDenominator ({}) and issueNominalValueOfUnit({}): {}",
						strArray[derivedMinDenominatorPos], strArray[issueNominalValueOfUnitPos],
						e.getMessage());
			}
        }
    }

    private boolean isHeaderPresent(int headerPos, int len) {
        return (headerPos > -1 && headerPos < len);
    }
}
