package com.ubs.idp.das.model;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.idp.base.StaticValues;
import com.ubs.idp.das.QueryServiceConfiguration;
import com.ubs.idp.das.cassandra.Cassandra;
import com.ubs.idp.das.exception.FilegenException;
import com.ubs.idp.das.response.ResponseFormatter;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.model.exceptions.MetadataException;

@Component
@Scope(value = "prototype")
public class Info {
	private static final Logger LOGGER = LoggerFactory.getLogger(Info.class);
	private static final String INFO = "Info ";
	private static final String HTML_BODY_START = "<html><body>";
	private static final Object HTML_BODY_END = "</body></html>";
	private static final String HTML_NEWLINE = "<hr>";
	
	@Autowired
	@Qualifier("cassandraWrapper")
	private Cassandra cassandraWrapper;

    @Autowired
    @Qualifier("queryServiceConfiguration")
    public QueryServiceConfiguration queryServiceConfiguration;

    @Autowired
    @Qualifier("mdsClient")
    public MetadataService metadataService;

    public RestClient restClient;
    
	public synchronized void status(OutputStream outputStream, Map<String, String[]> parameterMap, String... args)
			throws Throwable {
		if(restClient == null) {
			restClient = new RestClient(queryServiceConfiguration.xdRcasUrl, queryServiceConfiguration.xdRcasAppID,
	        		queryServiceConfiguration.xdWebssoUsername, queryServiceConfiguration.xdWebssoPassword);
		}
		
		int history = 1; // default 1 execution
		// Check parameter value
		if (parameterMap.get("history") != null && parameterMap.get("history")[0].length() != 0) {
			history = Integer.parseInt(parameterMap.get("history")[0]);
			if (history < 1 || history >= 20) {
				throw new FilegenException(Shared.INVALID_VALUE_FOR_HISTORY_PARAMETER + history);
			}
		}

		String dataset = args[0];
		List<String> jobNamesForDataset = Arrays.asList(dataset); // default to job
		try {
			jobNamesForDataset = metadataService.getJobNamesForDataset(dataset);
		} catch (MetadataException e) {
			dataset = null; // If direct query for job, dataset is unknown
		}
		List<Map<String, String>> jobs = new ArrayList<Map<String, String>>();
		for(String jobName : jobNamesForDataset) {
			BufferedReader inputReader = null;
			try {
				inputReader = restClient.queryServiceWebSSOURL(queryServiceConfiguration.xdRestUrl + "/jobs/executions?jobname=" + jobName, null);
				List<LinkedHashMap<String, Object>> xdJobsList = ResponseFormatter.mapper.readValue(inputReader, List.class);
				for(LinkedHashMap<String, Object> xdJob : xdJobsList) {
					Map<String, String> job = new HashMap<String, String>(3);
					job.put("name", (String) xdJob.get("name"));
					job.put("dataset", dataset);
					job.put("timeZone", (String) xdJob.get("timeZone"));
					job.put("duration", (String) xdJob.get("duration"));
					LinkedHashMap<String, Object> jobExecution = (LinkedHashMap<String, Object>) xdJob.get("jobExecution");
					job.put("id",  ((Integer) jobExecution.get("id")).toString());
					job.put("status", (String) jobExecution.get("status"));
					job.put("startTime", (String) jobExecution.get("startTime"));
					job.put("endTime", (String) jobExecution.get("endTime"));
					LinkedHashMap<String, Object> stepExecution = ((List<LinkedHashMap<String, Object>>) jobExecution.get("stepExecutions")).get(0);
					job.put("readCount", ((Integer) stepExecution.get("readCount")).toString());
					job.put("writeCount", ((Integer) stepExecution.get("writeCount")).toString());
					jobs.add(job);
					
					// Show only requested number of executions
					if (--history <= 0) {
						break;
					}
				}
			} catch(Exception e) {
				throw new FilegenException(e.getMessage());
			} finally {
				if(inputReader != null) {
					inputReader.close();
				}
			}
		}
		ResponseFormatter.mapper.writeValue(outputStream, jobs);
		outputStream.flush();
	}

	public void execute(OutputStream outputStream, String... args)
			throws Throwable {
		String response = null;
		if (Shared.MODE_GREP_LOGS.equals(args[0])) {
			LOGGER.info(args[2] + StaticValues.SPACE + args[3] + StaticValues.SPACE
					+ Shared.MODE_GREP_LOGS + StaticValues.SPACE + args[1]);
			String grepLogsScript = Shared.GREP_LOGS_SCRIPT.replaceAll("\\$1",
					args[1]);
			LOGGER.info(grepLogsScript);
			response = getFormattedBashScriptOutput(grepLogsScript);
		} else {
			LOGGER.info(args[1] + StaticValues.SPACE + args[2] + StaticValues.SPACE + INFO
					+ args[0]);
			if (Shared.MODE_HEALTH.equals(args[0])) {
				response = Shared.OPERATION_SUCCESS;
			} else if (Shared.MODE_CACHE.equals(args[0])) {
				response = cassandraWrapper.getInfo();
			}
		}

		BufferedOutputStream outBuffer = new BufferedOutputStream(outputStream);
		outBuffer.write(response.getBytes());
		outBuffer.flush();
		outputStream.flush();
	}

	private String getFormattedBashScriptOutput(String grepLogsScript)
			throws Throwable {
		StringBuilder outBuffer = new StringBuilder();
		outBuffer.append(HTML_BODY_START + Shared.NEWLINE);
		BufferedReader inputReader = null;
		inputReader = new BufferedReader(new InputStreamReader(Shared
				.executeBashScript(grepLogsScript).getInputStream()));
		String line = null;
		while ((line = inputReader.readLine()) != null) {
			outBuffer.append(line + Shared.NEWLINE + HTML_NEWLINE);
		}
		inputReader.close();
		outBuffer.append(HTML_BODY_END);
		return outBuffer.toString();
	}
}