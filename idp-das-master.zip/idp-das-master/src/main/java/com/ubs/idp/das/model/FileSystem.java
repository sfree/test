package com.ubs.idp.das.model;

import java.io.DataOutputStream;
import java.io.IOException;

public interface FileSystem {

	DataOutputStream createFile(String fileName) throws IOException;
}
