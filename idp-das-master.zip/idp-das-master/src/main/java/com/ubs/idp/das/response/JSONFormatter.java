package com.ubs.idp.das.response;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import com.ubs.idp.das.model.Shared;

public class JSONFormatter extends PostFilter {
	String[] fields;
	Map<String, String> fieldsMap;

	public JSONFormatter(OutputStream outputStream) {
		this.outputStream = outputStream;
	}

	@Override
	public void writeHeader(String[] fields) throws Exception {
	    super.writeHeader(fields);
		this.fields = fields;
		this.fieldsMap = new HashMap<String, String>(fields.length);
	}

	@Override
	public boolean writeLine(String[] strArray) throws Exception {
		synchronized (this) {
			if (super.writeLine(strArray)) {
				int i = 0;
				for (String field : fields) {
					fieldsMap.put(field, strArray[i++]);
				}
				mapper.writeValue(outputStream, fieldsMap);
				outputStream.write(Shared.NEWLINE_BYTEARRAY);
				return true;
			}
			return false;
		}
	}
}
