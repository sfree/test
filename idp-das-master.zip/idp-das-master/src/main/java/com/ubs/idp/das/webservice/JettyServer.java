package com.ubs.idp.das.webservice;

import static com.ubs.idp.das.model.Shared.getSystemOrConfigProperty;

import java.io.File;

import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.NCSARequestLog;
import org.eclipse.jetty.server.RequestLog;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.ContextHandler;
import org.eclipse.jetty.server.handler.HandlerCollection;
import org.eclipse.jetty.server.handler.HandlerList;
import org.eclipse.jetty.server.handler.RequestLogHandler;
import org.eclipse.jetty.server.handler.ResourceHandler;
import org.eclipse.jetty.server.nio.SelectChannelConnector;
import org.eclipse.jetty.util.thread.QueuedThreadPool;
import org.eclipse.jetty.util.thread.ThreadPool;
import org.eclipse.jetty.webapp.WebAppContext;

/**
 * JettyServer class which sets up an embedded Jetty appropriately whether
 * running in an IDE or in "production" mode in a shaded jar.
 * 
 */
public class JettyServer {
    private static final int DAS_REQUEST_LOG_RETAIN_DAYS = Integer.parseInt(getSystemOrConfigProperty("DAS_REQUEST_LOG_RETAIN_DAYS"));
    private static final String DAS_REQUEST_LOG_TIMEZONE = getSystemOrConfigProperty("DAS_REQUEST_LOG_TIMEZONE");
    private static final int DAS_MIN_THREADS = Integer.parseInt(getSystemOrConfigProperty("DAS_MIN_THREADS"));
    private static final int DAS_MAX_THREADS = Integer.parseInt(getSystemOrConfigProperty("DAS_MAX_THREADS"));
    private static final int JETTY_PORT = Integer.parseInt(getSystemOrConfigProperty("JETTY_PORT"));
    private static final String JETTY_BIND_HOST = getSystemOrConfigProperty("JETTY_BIND_HOST");
    private static final String DAS_REQUEST_LOG_FILE = getSystemOrConfigProperty("DAS_REQUEST_LOG_FILE");
    private static final String WAR = getSystemOrConfigProperty("WAR");
    private Server server;

    public void start() throws Exception {
        server = new Server();
        server.setThreadPool(createThreadPool());
        server.addConnector(createConnector());
        server.setHandler(createHandlers());
        server.setStopAtShutdown(true);
        server.start();
    }

    public void join() throws InterruptedException {
        server.join();
    }

    public void stop() throws Exception {
        server.stop();
    }

    private ThreadPool createThreadPool() {
        QueuedThreadPool _threadPool = new QueuedThreadPool();
        _threadPool.setMinThreads(DAS_MIN_THREADS);
        _threadPool.setMaxThreads(DAS_MAX_THREADS);
        return _threadPool;
    }

    private Connector createConnector() {
        Connector connector;
        connector = new SelectChannelConnector();
        connector.setPort(JETTY_PORT);

        connector.setRequestHeaderSize(connector.getRequestHeaderSize() * 64);

        if (JETTY_BIND_HOST != null) {
            connector.setHost(JETTY_BIND_HOST);
        }
        return connector;
    }

    private HandlerCollection createHandlers() {
        WebAppContext _ctx = new WebAppContext();
        // needed in order to prevent javamelody from using default scheduler
        _ctx.setInitParameter("javamelody.quartz-default-listener-disabled", "true");
        _ctx.setContextPath("/");

        _ctx.setWar(WAR);

        // Log viewer - Create a resource handler for logs
        ResourceHandler logsResourceHandler = new ResourceHandler();
        // Extract the dyn/logfiles/IDP directory
        String logDir = DAS_REQUEST_LOG_FILE;
        logDir = logDir.substring(0, logDir.indexOf("/IDP") + 4);
        logsResourceHandler.setResourceBase(logDir);
        logsResourceHandler.setDirectoriesListed(true);
        // Create context handler for static resource handler.
        ContextHandler logsContextHandler = new ContextHandler();
        logsContextHandler.setContextPath("/logs");
        logsContextHandler.setHandler(logsResourceHandler);

        HandlerList _contexts = new HandlerList();
        _contexts.setHandlers(new Handler[] { logsContextHandler, _ctx });

        RequestLogHandler _log = new RequestLogHandler();
        _log.setRequestLog(createRequestLog());

        HandlerCollection _result = new HandlerCollection();
        _result.setHandlers(new Handler[] { _contexts, _log });

        return _result;
    }

    private RequestLog createRequestLog() {
        NCSARequestLog _log = new NCSARequestLog();
        File _logPath = new File(DAS_REQUEST_LOG_FILE);
        _logPath.getParentFile().mkdirs();
        _log.setFilename(_logPath.getPath());
        _log.setRetainDays(DAS_REQUEST_LOG_RETAIN_DAYS);
        _log.setExtended(false);
        _log.setAppend(true);
        _log.setLogTimeZone(DAS_REQUEST_LOG_TIMEZONE);
        _log.setLogLatency(true);
        return _log;
    }
}