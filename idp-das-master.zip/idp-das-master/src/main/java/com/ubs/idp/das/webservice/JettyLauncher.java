package com.ubs.idp.das.webservice;

public class JettyLauncher {

	public static void main(String... args) throws Exception {
		new JettyLauncher(args).start();
	}

	private JettyServer server;

	public JettyLauncher(String[] args) {
		// See http://wiki.eclipse.org/Jetty/Howto/Configure_JSP
		System.setProperty("org.apache.jasper.compiler.disablejsr199", "true");
		server = new JettyServer();
	}

	public void start() throws Exception {
		server.start();
		server.join();
	}
}
