package com.ubs.idp.das;

import static com.ubs.idp.das.model.Shared.VALUESDELIMITER;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import me.prettyprint.cassandra.model.ConfigurableConsistencyLevel;
import me.prettyprint.cassandra.service.CassandraHostConfigurator;
import me.prettyprint.hector.api.Cluster;
import me.prettyprint.hector.api.HConsistencyLevel;
import me.prettyprint.hector.api.Keyspace;
import me.prettyprint.hector.api.factory.HFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import au.com.bytecode.opencsv.CSVReader;

import com.ubs.idp.das.exception.FilegenException;
import com.ubs.idp.das.model.Shared;
import com.ubs.idp.encrypt.Crypto;

@Configuration("queryServiceConfiguration")
@PropertySource({"classpath:application.properties", "classpath:environment-${environment}.properties"})
public class QueryServiceConfiguration implements InitializingBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(QueryServiceConfiguration.class);
    
    // had to keep this static for the time being 
    public static int DISTINCT_LIMIT;
    
    @Value("${das.cassandra.username:unknown}")
    private String cassandraUsername;

    @Value("${das.cassandra.password:unknown}")
    private String cassandraPassword;

    @Value("${das.seed.hosts:unknown}")
    private String seedHosts;

    @Value("${das.keyspace:unknown}")
    private String keyspaceName;

    @Value("${das.cluster.name:unknown}")
    private String clusterName;

    @Value("${das.replication.factor:0}")
    private int replicationFactor;

    @Value("${das.distinct.limit:0}")
    private int distinctLimit;

    @Value("${das.read.thread.core.pool.size}")
    private int readThreadCorePoolSize;

    @Value("${das.read.thread.max.pool.size}")
    private int readThreadMaxPoolSize;

    @Value("${das.read.thread.queue.size}")
    private int readThreadQueueSize;

    @Value("${das.read_batch_size}")
    private int readBatchSize;

    @Value("${das.disable.authorization:false}")
    private boolean disableAuthorization;

    @Value("${xd.rest.url:unknown}")
    public String xdRestUrl;

    @Value("${xd.rcas.url:unknown}")
    public String xdRcasUrl;

    @Value("${xd.rcas.appid:unknown}")
    public String xdRcasAppID;

    @Value("${xd.websso.username:unknown}")
    public String xdWebssoUsername;

    @Value("${xd.websso.password:unknown}")
    public String xdWebssoPassword;

    @Override
    public void afterPropertiesSet() throws Exception {
        // Initialize Cassandra cluster
        printPropertyValue(cassandraUsername, "das.cassandra.username");
        cassandraPassword = printPropertyValue(true, cassandraPassword, "das.cassandra.password");
        printPropertyValue(seedHosts, "das.seed.hosts");
        printPropertyValue(keyspaceName, "das.keyspace");
        printPropertyValue(clusterName, "das.cluster.name");
        printPropertyValue(replicationFactor, "das.replication.factor");
        printPropertyValue(distinctLimit, "das.distinct.limit");
        printPropertyValue(readThreadCorePoolSize, "das.read.thread.core.pool.size");
        printPropertyValue(readThreadMaxPoolSize, "das.read.thread.max.pool.size");
        printPropertyValue(readThreadQueueSize, "das.read.thread.queue.size");
        printPropertyValue(readBatchSize, "das.read_batch_size");
        printPropertyValue(disableAuthorization, "das.disable.authorization");

        DISTINCT_LIMIT = getDistinctLimit();
    }

    @Bean(name = "idpKeyspace")
    public Keyspace getKeyspace() {
        ConfigurableConsistencyLevel ccl = new ConfigurableConsistencyLevel();
        ccl.setDefaultReadConsistencyLevel(HConsistencyLevel.ONE);
        ccl.setDefaultWriteConsistencyLevel(HConsistencyLevel.ALL); // ANY
        return HFactory.createKeyspace(getKeyspaceName(), getCassandraCluster(), ccl);
    }

    @Bean(name = "cassandraCluster")
    public Cluster getCassandraCluster() {

        Map<String, String> credentials = new HashMap<String, String>();
        credentials.put("username", getCassandraUsername());
        credentials.put("password", getCassandraPassword());
        CassandraHostConfigurator cassandraHostConfigurator = new CassandraHostConfigurator(getSeedHosts());
        return HFactory.getOrCreateCluster(getClusterName(), cassandraHostConfigurator, credentials);
    }

    /**
     * Parses a CSV string to Set<String>
     * 
     * @param csvString
     * @return parsed Set<String>
     */
    public Set<String> parseCSVToSet(String csvString) {
        Set<String> lookupKeySet = new HashSet<String>(getDistinctLimit() + 1, 1); // avoids
                                                                                   // rehashing
        StringTokenizer st = new StringTokenizer(csvString, VALUESDELIMITER);
        while (st.hasMoreTokens()) {
            lookupKeySet.add(st.nextToken());
            // Check limit to avoid memory issues
            if (lookupKeySet.size() > getDistinctLimit()) {
                throw new FilegenException("Exceeded distinct limit: " + getDistinctLimit());
            }
        }
        return lookupKeySet;
    }

    /**
     * Parses a CSV string to String []
     * 
     * @param csvString
     * @return parsed String []
     * @throws IOException
     */
    public String[] parseCSVToArray(String csvString) throws IOException {
        CSVReader csvReader = new CSVReader(new StringReader(csvString));
        String[] strArray = csvReader.readNext();
        csvReader.close();
        return strArray;
    }

    public String getCassandraUsername() {
        return cassandraUsername;
    }

    public String getCassandraPassword() {
        return cassandraPassword;
    }

    public String getSeedHosts() {
        return seedHosts;
    }

    public String getKeyspaceName() {
        return keyspaceName;
    }

    public String getClusterName() {
        return clusterName;
    }

    public int getReplicationFactor() {
        return replicationFactor;
    }

    public int getDistinctLimit() {
        return distinctLimit;
    }

    public int getReadThreadCorePoolSize() {
        return readThreadCorePoolSize;
    }

    public int getReadThreadMaxPoolSize() {
        return readThreadMaxPoolSize;
    }

    public int getReadThreadQueueSize() {
        return readThreadQueueSize;
    }

    public int getReadBatchSize() {
        return readBatchSize;
    }

    public boolean isDisableAuthorization() {
        return disableAuthorization;
    }

	private String printPropertyValue(boolean decrypt, String value, String propertyName) {
        
        if (decrypt && value != null && value.length() > 0) {
            LOGGER.info("[Decrypting " + propertyName + "]");
            value = Crypto.decrypt(value);
        }
        printPropertyValue(value, propertyName);
        return value;
    }

    private void printPropertyValue(String value, String propertyName) {
        LOGGER.info("[Using " + propertyName + "] {}", Shared.sanitize(propertyName, value));
    }
    
    private void printPropertyValue(int value, String propertyName) {
        LOGGER.info("[Using " + propertyName + "] {}", value);
    }
    
    private void printPropertyValue(boolean value, String propertyName) {
        LOGGER.info("[Using " + propertyName + "] {}", value);
    }
}
