package com.ubs.idp.das.webservice;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.management.ManagementFactory;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ubs.idp.base.StaticValues;
import com.ubs.idp.das.QueryServiceConfiguration;
import com.ubs.idp.das.cassandra.Cassandra;
import com.ubs.idp.das.cassandra.CassandraFilter;
import com.ubs.idp.das.exception.FilegenException;
import com.ubs.idp.das.load.FileUploadForm;
import com.ubs.idp.das.model.Info;
import com.ubs.idp.das.model.Shared;
import com.ubs.idp.das.model.Stats;
import com.ubs.idp.das.response.ResponseFormatter;
import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.model.exceptions.MetadataException;

@Controller
public class LocalController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LocalController.class);
    public static final String API_QUERY_START = "QUERY START";
    public static final String API_QUERY_END = "QUERY END";
    public static final String API_STATUS_START = "STATUS START";
    public static final String API_STATUS_END = "STATUS END";
    private static String logContextID;

    @Autowired
    @Qualifier("queryServiceConfiguration")
    private QueryServiceConfiguration queryServiceConfiguration;

    @Autowired
    private CassandraFilter cassandraFilterCommand;

    @Autowired
    @Qualifier("cassandraWrapper")
    private Cassandra cassandra;

    @Autowired
    private Info infoCommand;

    @Autowired
    private Stats stats;

    @Autowired
    @Qualifier("mdsClient")
    private MetadataService metadataService;

    static {
        logContextID = Shared.APP_NAME + Shared.JOINDELIMITER + Shared.APP_VERSION + Shared.JOINDELIMITER + ManagementFactory.getRuntimeMXBean().getName();
    }

    @RequestMapping(value = "/", method = { RequestMethod.GET, RequestMethod.POST })
    public String home(Model model) throws Exception {
        model.addAttribute("datasetUrlsMap", metadataService.getSourceUrlsForAllDatasets());
        model.addAttribute("relationsMap", metadataService.getAllRelations());
        model.addAttribute("stats", stats);
        return "home";
    }

    @RequestMapping(value = "/v1/upload_client", method = { RequestMethod.GET, RequestMethod.POST })
    public String uploadClient() {
        return "upload_client";
    }

    @RequestMapping(value = "/v1/post_client", method = { RequestMethod.GET, RequestMethod.POST })
    public String postClient() {
        return "post_client";
    }

    @RequestMapping(value = "/v1/reset_stats", method = { RequestMethod.GET, RequestMethod.POST })
    public void stats(HttpServletResponse response) throws IOException {
        stats.initialize();
        response.sendRedirect("/"); // redirect to home
    }

    @RequestMapping(value = "/v1/status/{view:.+}", produces = MediaType.APPLICATION_JSON_VALUE, method = { RequestMethod.GET, RequestMethod.POST })
    public void status(HttpServletRequest request, @PathVariable(value = "view") String view, HttpServletResponse response)
            throws Throwable {
        long startTime = System.currentTimeMillis();
        logRequest(request, API_STATUS_START);

        response.setContentType(MediaType.APPLICATION_JSON_VALUE);

        infoCommand.status(response.getOutputStream(), request.getParameterMap(), view);
        logResponse(API_STATUS_END, view, 1, -1, -1, startTime);
    }

    @RequestMapping(value = "/v1/{view:.+}", produces = MediaType.TEXT_PLAIN_VALUE, method = { RequestMethod.GET, RequestMethod.POST })
    public void filter(HttpServletRequest request, @PathVariable(value = "view") String view, HttpServletResponse response)
            throws Throwable {
        long startTime = System.currentTimeMillis();
        logRequest(request, API_QUERY_START);

        response.setContentType(ResponseFormatter.getContentType(request.getParameter("format")));

        // Authorize
        checkAuthorization(request.getHeader(Shared.HEADER_ROLE), view);
        OutputStream outputStream = response.getOutputStream();

        String inputURL = request.getServletPath() + "?" + request.getQueryString();
        int numGoodRows = cassandraFilterCommand.execute(outputStream, request.getParameterMap(), view, inputURL);
        logResponse(API_QUERY_END, view, numGoodRows, -1, -1, startTime);
    }

    @RequestMapping(value = "/v1/upload/{dataset:.+}", method = RequestMethod.POST)
    @ResponseStatus(value = HttpStatus.CREATED)
    public void upload(@PathVariable(value = "dataset") String dataset, @ModelAttribute("uploadForm") FileUploadForm uploadForm,
            HttpServletRequest request, HttpServletResponse response) throws Throwable {
        throw new FilegenException(Shared.UPLOAD_DISABLED_MESSAGE);

        /**
         * API currently disabled TODO bring it back later with support to
         * trigger our async XD jobs - FTP and check XD job status
         * 
         * long startTime = System.currentTimeMillis(); logRequest(request,
         * API_UPLOAD_START); // Authorize
         * checkAuthorization(request.getHeader(Shared.HEADER_ROLE), dataset);
         * 
         * AtomicBoolean isSuccess = new AtomicBoolean(true); StringBuffer
         * outputMessageBuffer = new StringBuffer(); List<MultipartFile> files =
         * uploadForm.getFiles(); if (null != files && files.size() > 0) { for
         * (MultipartFile multipartFile : files) { String fileName =
         * multipartFile.getOriginalFilename(); if (fileName == null ||
         * fileName.trim().equals("")) { continue; } LOGGER.info(UPLOAD +
         * Shared.LOG_DELIMITER + dataset + Shared.LOG_DELIMITER + fileName);
         * Scanner inputStreamScanner = new Scanner(
         * multipartFile.getInputStream());
         * inputStreamScanner.useDelimiter(Shared.NEWLINE);
         * 
         * boolean trim = Shared .isYes(Shared.validateParameter(
         * Shared.REQUEST_PARAMETER_TRIM,
         * request.getParameterValues(Shared.REQUEST_PARAMETER_TRIM), false,
         * response.getOutputStream())); RequestParameters requestParameters =
         * new RequestParameters(); requestParameters.setResource(dataset);
         * requestParameters.setTrim(trim);
         * requestParameters.setScanner(inputStreamScanner); String
         * outputMessage = ftpAndCheckXDJobStatus(requestParameters);
         * LOGGER.info(outputMessage);
         * outputMessageBuffer.append(outputMessage);
         * response.getOutputStream().write( (outputMessage +
         * Shared.NEWLINE).getBytes()); inputStreamScanner.close(); } }
         * 
         * // Return error if (!isSuccess.get()) {
         * response.sendError(HttpServletResponse.SC_BAD_REQUEST,
         * outputMessageBuffer.toString()); } logResponse(API_UPLOAD_END,
         * dataset, files.size(), -1, -1, startTime);
         */
    }

    /**
     * Gets all files info.
     * 
     * @throws Throwable
     */
    @RequestMapping(value = "/v1/info", method = RequestMethod.GET)
    public void info(HttpServletRequest request, HttpServletResponse response) throws Throwable {
        // infoCommand.setCassandraClient(cassandraClientFactory.getInstance());
        infoCommand.execute(response.getOutputStream(), Shared.MODE_CACHE, request.getHeader(Shared.HEADER_SSO_LOGONID),
                request.getHeader(Shared.HEADER_X_FORWARDED_FOR));
    }

    /**
     * Refreshes and gets all files info.
     * 
     * @throws Throwable
     */
    @RequestMapping(value = "/v1/refreshInfo", method = RequestMethod.GET)
    public void refreshInfo(HttpServletRequest request, HttpServletResponse response) throws Throwable {
        // infoCommand.setCassandraClient(cassandraClientFactory.getInstance());
        infoCommand.execute(response.getOutputStream(), Shared.MODE_REFRESH, request.getHeader(Shared.HEADER_SSO_LOGONID),
                request.getHeader(Shared.HEADER_X_FORWARDED_FOR));
    }

    /**
     * Health check.
     * 
     * @throws Throwable
     */
    @RequestMapping(value = "/v1/health", method = RequestMethod.GET)
    public void health(HttpServletRequest request, HttpServletResponse response) throws Throwable {
        infoCommand.execute(response.getOutputStream(), Shared.MODE_HEALTH, request.getHeader(Shared.HEADER_SSO_LOGONID),
                request.getHeader(Shared.HEADER_X_FORWARDED_FOR));
    }

    @RequestMapping(value = "/v1/greplogs={grepString:.+}", produces = "text/html", method = RequestMethod.GET)
    public void grepLogs(HttpServletRequest request, @PathVariable(value = "grepString") String grepString,
            final HttpServletResponse response) throws Throwable {
        response.setContentType(MediaType.TEXT_HTML_VALUE);
        infoCommand.execute(response.getOutputStream(), Shared.MODE_GREP_LOGS, grepString, request.getHeader(Shared.HEADER_SSO_LOGONID),
                request.getHeader(Shared.HEADER_X_FORWARDED_FOR));
    }

    /**
     * Logs details from each request: SSO ID, IP address, input URL and custom
     * string
     * 
     * @param request
     */
    private void logRequest(HttpServletRequest request, String api) {
        String ssoId = request.getHeader(Shared.HEADER_SSO_LOGONID);
        String ipAddress = request.getHeader(Shared.HEADER_X_FORWARDED_FOR);
        String inputURL = request.getServletPath() + "?" + request.getQueryString();

        LOGGER.info(logContextID + Shared.LOG_DELIMITER + api + Shared.LOG_DELIMITER + ssoId
                + Shared.LOG_DELIMITER + ipAddress + Shared.LOG_DELIMITER + inputURL
                + Shared.LOG_DELIMITER + request.getMethod()
                + Shared.LOG_DELIMITER + request.getParameterMap());
    }

    /**
     * Logs response
     * 
     * @param function
     * @param resource
     * @param numGoodRows
     * @param startTime
     */
    private void logResponse(String function, String resource, int numGoodRows, long numBadRows, long numFailRows, long startTime) {
        LOGGER.info(logContextID + Shared.LOG_DELIMITER + function + Shared.LOG_DELIMITER + resource + Shared.LOG_DELIMITER + numGoodRows
                + Shared.LOG_DELIMITER + Shared.elapsedTime(startTime));
    }

    /**
     * Checks if the user roles (set in the HTTP header by SiteMinder) contain
     * AlL roles required for the view/dataset
     * 
     * @param headerRolesCSV
     *            roles (CSV) from the header
     * @param view
     * @param response
     * @throws Exception
     */
    private void checkAuthorization(String headerRolesCSV, String view) throws Exception {
        List<String> sourceRoles = null;
        // Validate View
        try {
            sourceRoles = metadataService.getRolesForDataset(view);
        } catch (MetadataException e) {
            throw new FilegenException(Shared.INVALID_VIEW_MESSAGE + view);
        }

        if (headerRolesCSV != null) {
            List<String> headerRoles = Arrays.asList(queryServiceConfiguration.parseCSVToArray(headerRolesCSV));
            if (headerRoles.containsAll(sourceRoles)) {
                return;
            }
        }

        // Authorization disabled only when run by JettyLauncher*.launch
        if (!queryServiceConfiguration.isDisableAuthorization()) {
            throw new FilegenException(Shared.UNAUTHORIZED_VIEW_MESSAGE + view + StaticValues.SPACE + sourceRoles);
        }
    }

    public void setCassandraFilterCommand(CassandraFilter cassandraFilterCommand) {
        this.cassandraFilterCommand = cassandraFilterCommand;
    }

    public void setInfoCommand(Info localInfoCommand) {
        this.infoCommand = localInfoCommand;
    }

    @ExceptionHandler(FilegenException.class)
    public void handleFilegenException(FilegenException e, HttpServletResponse response) throws IOException {
        Shared.handleError(LOGGER, e, response.getOutputStream());
        if (e.getMessage().startsWith(Shared.UNAUTHORIZED_VIEW_MESSAGE)) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, e.getMessage());
        } else if (e.getMessage().startsWith(Shared.NON_INDEXED_QUERY_IN_PROGRESS)) {
            response.sendError(HttpServletResponse.SC_SERVICE_UNAVAILABLE, e.getMessage());
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
        }
    }

    @ExceptionHandler(MetadataException.class)
    public void handleMetadataException(MetadataException e, HttpServletResponse response) throws IOException {
        Shared.handleError(LOGGER, e, response.getOutputStream());
        response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
    }

    @ExceptionHandler(Throwable.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR, reason = Shared.INTERNAL_SERVER_ERROR_MESSAGE)
    public void catchAll(Throwable t, HttpServletResponse response) throws IOException {
        Shared.handleError(LOGGER, t, response.getOutputStream());
    }
}
