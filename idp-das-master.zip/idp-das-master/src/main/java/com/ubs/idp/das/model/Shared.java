package com.ubs.idp.das.model;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.idp.base.StaticValues;
import com.ubs.idp.das.Common;
import com.ubs.idp.das.exception.FilegenException;
import com.ubs.idp.encrypt.Crypto;

public class Shared {
    public enum ResponseFormat {
        TEXT, JSON, JSONARRAY
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(Shared.class);
    public static final String APP_NAME = "DAS";
    public static final String APP_VERSION = "v1.4.x";
    public static final String NEWLINE = "\n";
    public static final String COLON = ":";
    public static final String ESC_PIPE_SEPERATOR = "\\|";
    
    public static final byte[] NEWLINE_BYTEARRAY = NEWLINE.getBytes();
    public static final byte[] JSONARRAY_START_BYTEARRAY = "[".getBytes();
    public static final byte[] JSONARRAY_END_BYTEARRAY = (NEWLINE + "]" + NEWLINE).getBytes();
    public static final byte[] JSONARRAY_NEWLINE_BYTEARRAY = ("," + NEWLINE).getBytes();
    public static final String URLPARAMSDELIMITER = "&";
    public static final String VALUESDELIMITER = ",";
    public static final char NULL_CHAR = '\0';
    public static final char URLPARAMVALUEDELIMITER = '=';
    public static final String URLPARAMSTART = "?";
    public static final String COLUMNDELIMITER = ",";
    public static final String JOINDELIMITER = "_";
    public static final String SCHEMADELIMITER = ":chararray" + COLUMNDELIMITER;
    public static final String SYSDATE_NEXT_ESCAPED = "SYSDATE\\+1";
    public static final String ESCAPE_SYSDATE = "date";
    public static final String FILESYSTEM = "hadoop";
    public static final String FIELDS = "fields";
    public static final String SOURCES = "sources";
    public static final String DELIMITER = "delimiter";
    public static final String ESCAPE = "escape";
    public static final String QUOTE = "quote";
    public static final String OUTPUT_FORMAT = "format";
    public static final String DISTINCT = "distinct";
    public static final String HIDE_HEADER = "hideHeader";
    public static final String INCLUDE_INPUT = "includeInput";
    public static final String REQUEST_PARAMETER_TRIM = "trim";
    public static final String REQUEST_PARAMETER_LIMIT = "limit";
    public static final String UNION_EXCLUSIVE = "unionExclusive";
    public static final String UNION = "union";
    public static final String FIELDS_PARAM = "&fields=";
    public static final String DELIMITER_PARAM = "&delimiter=";
    public static final String INPUT_FIELDS_PARAM = "fields=";
    public static final String INPUT_DELIMITER_PARAM = "delimiter=";
    public static final String INVALID_FIELD_MESSAGE = "Invalid field: ";
    public static final String NO_LOOKUP_IDS = "Specify lookup IDs for IDP_STATUS / unionExclusive";
    public static final String NON_INDEXED_QUERY_IN_PROGRESS = "Only one concurrent non-indexed query allowed. Current: ";
    public static final String INVALID_FILE_MESSAGE = "Invalid file: ";
    public static final String INVALID_VIEW_MESSAGE = "Invalid view: ";
    public static final String INVALID_DATASET_MESSAGE = "Invalid dataset: ";
    public static final String UNAUTHORIZED_VIEW_MESSAGE = "Unauthorized for view: ";
    public static final String UPLOAD_DISABLED_MESSAGE = "The upload API has been disabled. Contact us for details.";
    public static final String INVALID_HEADER_MESSAGE = " - invalid header - ";
    public static final String INVALID_DELTA_MESSAGE = "Invalid delta: ";
    public static final String INVALID_FORMAT = "Invalid format: ";
    public static final String TEST_DATA_FILE = "test_data";
    public static final String DAS_BASE_DIR = getSystemOrConfigProperty("DAS_BASE_DIR");
    public static final String HUFS_FILE_PATH = DAS_BASE_DIR + "/files/";;
    public static final String KEYSTORE_LOCATION = "KEYSTORE_LOCATION";
    public static final String KEYSTORE_PASSWORD = "KEYSTORE_PASSWORD";
    public static final String RDDH_RCAS_ENDPOINT_URL = "RDDH.RCAS.EndPoint.URL";
    public static final String RDDH_RCAS_SSO_PASSWORD = "RDDH.RCAS.Authentication.password";
    public static final String RDDH_RCAS_SSO_USERNAME = "RDDH.RCAS.Authentication.username";
    public static final String RDDH_RCAS_AUTH_APPGUID = "RDDH.RCAS.Authentication.appguid";
    public static final String RDDH_WS_HOST = "RDDH_WS_HOST";
    public static final String RDDH_WS_PATH = "RDDH_WS_PATH";
    public static final String RDDH_WS_USER_APP = "RDDH_WS_USER_APP";
    public static final String RDDH_WS_USER_HOST = "RDDH_WS_USER_HOST";
    public static final String RDDH_WS_USER_DOMAIN = "RDDH_WS_USER_DOMAIN";
    public static final String LOADED = "Loaded ";
    public static final String LOG_DELIMITER = " | ";
    public static final String JOINED = "Joined ";
    public static final short FILE_REPLICATION = 1;
    public static final int MILLISECONDS_PER_SECOND = 1000;
    public static final int SECONDS_PER_MINUTE = 60;
    public static final String MINUTES = "m";
    public static final String SECONDS = "s";
    private static final String DOT = "\\.";
    private static final String ESCAPE_DOT = "_";
    private static final String SLASH = "/";
    private static final String ESCAPE_SLASH = "__";
    public static final String DATE_FORMAT = "yyyyMMdd";
    public static final String DELTA_DATE_FORMAT = "yyyyMMddHHmmssSSS";
    public static final String OPERATOR_EQUALS = "=";
    public static final String OLD_OPERATOR_NOT_EQUALS = "!=";
    public static final String OLD_OPERATOR_LESS_THAN_EQUALS = "<=";
    public static final String OLD_OPERATOR_GREATER_THAN_EQUALS = ">=";
    public static final String OLD_OPERATOR_LESS_THAN = "<";
    public static final String OLD_OPERATOR_GREATER_THAN = ">";
    public static final String OLD_OPERATOR_LIKE = "~";
    public static final String OPERATOR_NOT_EQUALS = "=not:";
    public static final String OPERATOR_LESS_THAN_EQUALS = "=lte:";
    public static final String OPERATOR_GREATER_THAN_EQUALS = "=gte:";
    public static final String OPERATOR_LESS_THAN = "=lt:";
    public static final String OPERATOR_GREATER_THAN = "=gt:";
    public static final String OPERATOR_LIKE = "=like:";
    public static final String OPERATOR_BETWEEN = "=between:";
    public static final String NULL = "NULL";

    private static List<String> relationalOperators = Arrays.asList(OPERATOR_NOT_EQUALS, OPERATOR_LESS_THAN_EQUALS,
            OPERATOR_GREATER_THAN_EQUALS, OPERATOR_LESS_THAN, OPERATOR_GREATER_THAN, OPERATOR_LIKE, OPERATOR_BETWEEN, OPERATOR_EQUALS);
    public static final String OPERATOR_NOT_SUPPORTED = " operator not supported";
    private static final String BASH_SHELL = "bash";
    private static final String SCRIPT_SHELL_COMMAND = "-c";
    public static final String SORT_FILE_SUFFIX = ".sorted";
    public static final String NO_ENCODING = "NO_ENCODING:";
    public static final String REQUEST_TYPE_POST = "POST:";
    public static final String INFO_SCRIPT = "ls -lcth " + HUFS_FILE_PATH + " | sed 1d | awk {'print $9\" \"$6\" \"$7\" \"$8\" \"$5'}";
    public static final String GREP_LOGS_SCRIPT = "grep -rni -E \"$1\" ${UBS_CATALINA_LOGS}/../";
    public static final String MODE_CACHE = "cache";
    public static final String MODE_REFRESH = "refresh";
    public static final String MODE_HEALTH = "health";
    public static final String MODE_GREP_LOGS = "greplogs";
    public static final String OPERATION_SUCCESS = "Operation status: SUCCESS";
    public static final String OPERATION_FAILED = "Operation status: FAILED";
    public static final String HEADER_X_FORWARDED_FOR = "X-Forwarded-For";
    public static final String HEADER_SSO_LOGONID = "SSO_LOGONID";
    public static final String HEADER_ROLE = "Role";
    public static final String IDP_SECRET_WORD = "IDP_SECRET_WORD";
    public static final String INTERNAL_SERVER_ERROR_MESSAGE = "Something went wrong. Contact IDP-SUPPORT.";
    private static final Logger NETCOOL_LOGGER = LoggerFactory.getLogger("netcool");
    public static final String RDDH_WS_HOST_PLACEHOLDER = "${RDDH_WS_HOST}";
    public static final String XML = "xml://";
    public static final String FILE = "file:/";
    public static final String CASSANDRA_INDEX_NAME_SEPARATOR = "_";
    public static final String CASSANDRA_KEYS_SEPARATOR = "_";
    public static final String DELTA_START = "\\$\\{START\\}";
    public static final String DELTA_END = "\\$\\{END\\}";
    public static final String MAX_KEY = "\uFFFF";
    private static final String MISSING_REQUIRED_PARAMETER = "Missing required parameter: ";
    public static final String MISSING_VALUE_FOR_PARAMETER = "Missing value for parameter: ";
    public static final String INVALID_VALUE_FOR_HISTORY_PARAMETER = "Invalid value for history (range 1 to 20): ";
    public static final String STANDARD_DELIMITER = "\t";
    public static final String FAIL_FILE_EXTENSION = ".fail";
    public static final String CONNECTING = "Connecting... ";
    public static final String SYSDATE = "SYSDATE";
    public static final String SYSDATE_PREVIOUS = "SYSDATE-1";
    public static final String SYSDATE_NEXT = "SYSDATE+1";
    public static final String IDP_STATUS = "IDP_STATUS";

    /**
     * Format header row in the output replacing special symbols e.g. SYSDATE
     * with date and replacing back certain chars like . which are not allowed
     * in pig scripts
     * 
     * @param string
     * @return
     */
    public static String formatHeader(String string) {
        return string.replaceAll(SYSDATE, ESCAPE_SYSDATE).replaceAll(ESCAPE_SLASH, SLASH).replaceAll(ESCAPE_DOT, DOT);
    }

    /**
     * Format query columns in FOREACH...GENERATE clause replacing special
     * symbols e.g. SYSDATE with current system date
     * 
     * @param outputColumns
     * @return
     */
    public static String formatGeneratedColumns(String outputColumns) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT);

        // Current day
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();

        // Previous day
        calendar.add(Calendar.DATE, -1);
        Date previousDate = calendar.getTime();

        // Next day
        calendar.add(Calendar.DATE, 2);
        Date nextDate = calendar.getTime();

        return outputColumns.replaceAll(SYSDATE_PREVIOUS, simpleDateFormat.format(previousDate))
                .replaceAll(SYSDATE_NEXT_ESCAPED, simpleDateFormat.format(nextDate))
                .replaceAll(SYSDATE, simpleDateFormat.format(currentDate));
    }

    /**
     * Calculates and returns formatted elapsed time in seconds
     * 
     * @param start
     *            the number of milliseconds from start
     * @return
     */
    public static String elapsedTime(long start) {
        double seconds = ((double) (System.currentTimeMillis() - start)) / MILLISECONDS_PER_SECOND;
        if (seconds > SECONDS_PER_MINUTE) {
            return (seconds / SECONDS_PER_MINUTE) + StaticValues.SPACE + MINUTES;
        } else {
            return seconds + StaticValues.SPACE + SECONDS;
        }
    }

    public static void handleError(Logger logger, Throwable t, OutputStream outputStream) throws IOException {
        // Bad request
        if (t instanceof FilegenException) {
            logger.error(t.getMessage());
        }
        // Internal Server error
        else {
            logger.error(t.getMessage(), t);
            NETCOOL_LOGGER.error("DAS internal server error: " + t.getMessage(), t);
        }
        outputStream.write((t.getMessage() + NEWLINE).getBytes());
    }

    /**
     * Executes the UNIX script in a bash shell
     * 
     * @param script
     * @return
     * @throws InterruptedException
     * @throws IOException
     */
    public static Process executeBashScript(String script) throws InterruptedException, IOException {
        return new ProcessBuilder(BASH_SHELL, SCRIPT_SHELL_COMMAND, script).redirectErrorStream(true).start();
    }

    /**
     * Validates and gets URL parameter value. Only first occurrence of
     * parameter used.
     * 
     * @param parameterName
     * @param parameterArray
     * @param isRequired
     * @param outBuffer
     * @return
     * @throws IOException
     */
    public static String validateParameter(String parameterName, String[] parameterArray, boolean isRequired, OutputStream outBuffer)
            throws IOException {
        String parameterValue = (parameterArray == null ? null : parameterArray[0]);
        if (isRequired && parameterValue == null) {
            String outputMessage = MISSING_REQUIRED_PARAMETER + parameterName;
            outBuffer.write((outputMessage).getBytes());
            throw new FilegenException(outputMessage);
        }
        return parameterValue;
    }

    /**
     * Validates and gets URL parameter values. The entire array is returned.
     * 
     * @param parameterName
     * @param parameterArray
     * @param isRequired
     * @param outBuffer
     * @return
     * @throws IOException
     */
    public static String[] validateParameters(String parameterName, String[] parameterArray, boolean isRequired, OutputStream outBuffer)
            throws IOException {
        if (isRequired && parameterArray == null) {
            String outputMessage = MISSING_REQUIRED_PARAMETER + parameterName;
            outBuffer.write((outputMessage).getBytes());
            throw new FilegenException(outputMessage);
        }
        return parameterArray;
    }

    /**
     * Parses the key-value pair looking for various operators starting from
     * multiple to single characters. Returns String array {field, operator,
     * value}
     * 
     * @param keyValue
     * @return
     */
    public static String[] parseByOperator(String keyValue) {
        String[] inputArray = new String[3];
        // Check against all operators, until match found
        for (String operator : relationalOperators) {
            if (keyValue.indexOf(operator) != -1) {
                inputArray[0] = keyValue.substring(0, keyValue.indexOf(operator));
                inputArray[1] = operator;
                inputArray[2] = keyValue.substring(keyValue.indexOf(operator) + operator.length());
                break;
            }
        }

        // If unsupported operator
        if (inputArray[0] == null) {
            throw new FilegenException(INVALID_FIELD_MESSAGE + keyValue);
        }
        return inputArray;
    }

    public static boolean isYes(String input) {
        return Common.YES.equalsIgnoreCase(input);
    }

    /**
     * Return un-encrypted value
     * 
     * @param propertyName
     * @return
     */
    public static String getSystemOrConfigProperty(String propertyName) {
        return getSystemOrConfigProperty(propertyName, false, null);
    }

    /**
     * Return un-encrypted value, defaultValue if null
     * 
     * @param propertyName
     * @return
     */
    public static String getSystemOrConfigProperty(String propertyName, String defaultValue) {
        return getSystemOrConfigProperty(propertyName, false, defaultValue);
    }

    /**
     * Return value (optionally decrypt)
     * 
     * @param propertyName
     * @param decrypt
     * @return
     */
    public static String getSystemOrConfigProperty(String propertyName, boolean decrypt) {
        return getSystemOrConfigProperty(propertyName, decrypt, null);
    }

    /**
     * Return value (optionally decrypt)
     * 
     * @param propertyName
     * @param decrypt
     * @return
     */
    public static String getSystemOrConfigProperty(String propertyName, boolean decrypt, String defaultValue) {
        String value = System.getProperty(propertyName);

        if (decrypt && value != null && value.length() > 0) {
            LOGGER.info("[Decrypting " + propertyName + "]");
            value = Crypto.decrypt(value);
        }

        value = (value != null ? value : defaultValue);

        LOGGER.info("[Using " + propertyName + "] " + sanitize(propertyName, value));

        return value;
    }

    /**
     * Masks any passwords
     *
     * @param propertyName
     * @param password
     * @return
     */
    public static String sanitize(String propertyName, String password) {
        // Looks like password?
        if (propertyName.toLowerCase().contains("password") && password != null && password.length() != 0) {
            return password.substring(0, 1) + "***"; // mask
        } else {
            return password;
        }
    }
}
