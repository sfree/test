package com.ubs.idp.das.exception;

public class UpStreamSourceException extends RuntimeException {

	private static final long serialVersionUID = -2296033494153900374L;

	public UpStreamSourceException(String message) {
		super(message);
	}

	public UpStreamSourceException(String message, Throwable throwable) {
		super(message, throwable);
	}
}