package com.ubs.idp.das.load;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ErrorHandler;

public class SubscriberShutdownHandler implements ErrorHandler {

	private static final Logger FILE_LOGGER = LoggerFactory
			.getLogger(SubscriberShutdownHandler.class);
	private static final Logger NETCOOL_LOGGER = LoggerFactory
			.getLogger("netcool");

	@Override
	public void handleError(Throwable throwable) {
		// TODO listener.stop();
		FILE_LOGGER.error("*** Subscriber error: " + throwable);
		NETCOOL_LOGGER.error("*** Subscriber error: " + throwable);
	}

}