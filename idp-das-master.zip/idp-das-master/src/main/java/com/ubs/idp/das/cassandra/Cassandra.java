package com.ubs.idp.das.cassandra;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import me.prettyprint.cassandra.model.BasicColumnFamilyDefinition;
import me.prettyprint.cassandra.serializers.StringSerializer;
import me.prettyprint.cassandra.service.ColumnSliceIterator;
import me.prettyprint.cassandra.service.ThriftCfDef;
import me.prettyprint.cassandra.service.ThriftKsDef;
import me.prettyprint.hector.api.Cluster;
import me.prettyprint.hector.api.Keyspace;
import me.prettyprint.hector.api.beans.ColumnSlice;
import me.prettyprint.hector.api.beans.HColumn;
import me.prettyprint.hector.api.beans.OrderedRows;
import me.prettyprint.hector.api.beans.Rows;
import me.prettyprint.hector.api.ddl.ColumnFamilyDefinition;
import me.prettyprint.hector.api.ddl.ComparatorType;
import me.prettyprint.hector.api.ddl.KeyspaceDefinition;
import me.prettyprint.hector.api.factory.HFactory;
import me.prettyprint.hector.api.mutation.Mutator;
import me.prettyprint.hector.api.query.QueryResult;
import me.prettyprint.hector.api.query.RangeSlicesQuery;
import me.prettyprint.hector.api.query.SliceQuery;

import org.apache.cassandra.thrift.EndpointDetails;
import org.apache.cassandra.thrift.TokenRange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ubs.idp.base.StaticValues;
import com.ubs.idp.das.QueryServiceConfiguration;
import com.ubs.idp.das.model.Shared;
import com.ubs.idp.metadata.client.MetadataService;

@Component("cassandraWrapper")
public class Cassandra {

    public StringSerializer stringSerializer = StringSerializer.get();

    private static final Logger LOGGER = LoggerFactory.getLogger(Cassandra.class);
    private static final int MAX_TRUNCATE_RETRIES = 3;

    @Autowired
    @Qualifier("queryServiceConfiguration")
    private QueryServiceConfiguration queryServiceConfiguration;

    @Autowired
    @Qualifier("cassandraCluster")
    private Cluster cassandraCluster;

    @Autowired
    @Qualifier("idpKeyspace")
    public Keyspace idpKeyspace;

    @Autowired
    @Qualifier("mdsClient")
    private MetadataService metadataService;

    /**
     * Get ring info
     */
    public String getInfo() {
        // configuration.lazyInitialize();
        StringBuilder infoBuffer = new StringBuilder();
        KeyspaceDefinition keyspaceDefinition = cassandraCluster.describeKeyspace(queryServiceConfiguration.getKeyspaceName());
        infoBuffer.append("Keyspace: " + keyspaceDefinition.getName() + Shared.NEWLINE);
        infoBuffer.append("Replication Factor: " + keyspaceDefinition.getReplicationFactor() + Shared.NEWLINE);
        infoBuffer.append("Ring: " + Shared.NEWLINE);
        infoBuffer.append("-------------------------------------------------------------------------" + Shared.NEWLINE);
        Set<String> uniqueHosts = new HashSet<String>();
        int i = 0;
        for (TokenRange tokenRange : cassandraCluster.describeRing(queryServiceConfiguration.getKeyspaceName())) {
            for (EndpointDetails endpointDetails : tokenRange.getEndpoint_details()) {
                if (uniqueHosts.add(endpointDetails.getHost())) {
                    infoBuffer.append((++i) + StaticValues.SPACE + endpointDetails.toString() + Shared.NEWLINE);
                }
            }
        }
        return infoBuffer.toString();
    }

    /**
     * Create Keyspace if needed
     */
    public void createKeyspaceIfNeeded() {
        // Create keyspace (and CFs) if not already
        if (cassandraCluster.describeKeyspace(queryServiceConfiguration.getKeyspaceName()) == null) {
            List<ColumnFamilyDefinition> columnFamilyDefinitions = new ArrayList<ColumnFamilyDefinition>();
            KeyspaceDefinition keyspaceDef = HFactory.createKeyspaceDefinition(queryServiceConfiguration.getKeyspaceName(),
                    ThriftKsDef.DEF_STRATEGY_CLASS, queryServiceConfiguration.getReplicationFactor(), columnFamilyDefinitions);

            // Add the schema to the cluster.
            cassandraCluster.addKeyspace(keyspaceDef, true);
            LOGGER.info("Done. Keyspace added: " + queryServiceConfiguration.getKeyspaceName());
        }
    }

    public void addColumnFamilyIfNeeded(String columnFamilyName) {
        // Ensure keyspace
        createKeyspaceIfNeeded();

        for (ColumnFamilyDefinition columnFamilyDefinition : cassandraCluster.describeKeyspace(queryServiceConfiguration.getKeyspaceName())
                .getCfDefs()) {
            // Do nothing if CF exists
            if (columnFamilyDefinition.getName().equals(columnFamilyName)) {
                return;
            }
        }

        // Add new CF
        cassandraCluster.addColumnFamily(createColumnFamilyDefinition(columnFamilyName), true);
        LOGGER.info("Added CF: " + columnFamilyName);
    }

    private ColumnFamilyDefinition createColumnFamilyDefinition(String columnFamilyName) {
        BasicColumnFamilyDefinition basicColumnFamilyDefinition = new BasicColumnFamilyDefinition();
        basicColumnFamilyDefinition.setKeyspaceName(queryServiceConfiguration.getKeyspaceName());
        basicColumnFamilyDefinition.setName(columnFamilyName);
        basicColumnFamilyDefinition.setDefaultValidationClass(ComparatorType.UTF8TYPE.getClassName());
        basicColumnFamilyDefinition.setKeyValidationClass(ComparatorType.UTF8TYPE.getClassName());
        basicColumnFamilyDefinition.setComparatorType(ComparatorType.UTF8TYPE);
        return new ThriftCfDef(basicColumnFamilyDefinition);
    }

    public void truncateCF(String cfName) throws Exception {
        // lazyInitialize();
        String keySpaceName = cassandraCluster.describeKeyspace(queryServiceConfiguration.getKeyspaceName()).getName();
        List<String> columnFamilies = new ArrayList<String>();
        // Add given CF
        columnFamilies.add(cfName);
        // Add custom index CFs - only in case of main CF
        if (metadataService.getSourceUrlsForDataset(cfName) != null) {
            int schemaFieldsLength = metadataService.getAttributeNamesForDataset(cfName).size();
            for (int position = 0; position < schemaFieldsLength; position++) {
                String indexCFName = cfName + Shared.CASSANDRA_INDEX_NAME_SEPARATOR + position;
                columnFamilies.add(indexCFName);
            }
        }
        int noOfCFs = columnFamilies.size();
        int noOfCFTruncated = 0;
        int noOfTries = 1;
        int i = 0;
        while (noOfCFTruncated < noOfCFs) {
            String columnFamilyName = columnFamilies.get(i);
            if (columnFamilyName != null) {
                try {
                    cassandraCluster.truncate(queryServiceConfiguration.getKeyspaceName(), columnFamilyName);
                    columnFamilies.set(i, null);
                    noOfCFTruncated++;
                    LOGGER.info("Truncated " + keySpaceName + Shared.LOG_DELIMITER + columnFamilyName);
                } catch (Throwable t) {
                    // Print error only on final try
                    if (noOfTries == MAX_TRUNCATE_RETRIES) {
                        LOGGER.info("FAILED truncate for " + keySpaceName + Shared.LOG_DELIMITER + columnFamilyName);
                        LOGGER.error(t.getMessage(), t);
                    }
                }
            }
            i++;
            if (i == columnFamilies.size()) {
                i = 0;
                if (noOfTries == MAX_TRUNCATE_RETRIES) {
                    break;
                }
                noOfTries++;
                if (noOfTries > 1) {
                    LOGGER.info("RETRYING truncate attempt " + (noOfTries) + " of " + MAX_TRUNCATE_RETRIES);
                }
            }
        }

        // Success
        if (noOfTries == MAX_TRUNCATE_RETRIES) {
            LOGGER.info("Truncate FAILED for " + keySpaceName + Shared.LOG_DELIMITER + columnFamilies);
        } else {
            LOGGER.info("Truncate DONE " + keySpaceName + Shared.LOG_DELIMITER + cfName);
        }
    }

    public void dropKeyspace() {
        // lazyInitialize();
        if (cassandraCluster.describeKeyspace(queryServiceConfiguration.getKeyspaceName()) != null) {
            LOGGER.info("Dropping " + cassandraCluster.describeKeyspace(queryServiceConfiguration.getKeyspaceName()).getName());
            cassandraCluster.dropKeyspace(queryServiceConfiguration.getKeyspaceName(), true);
            LOGGER.info("Dropped " + queryServiceConfiguration.getKeyspaceName());
        } else {
            LOGGER.info("No keyspace found: " + queryServiceConfiguration.getKeyspaceName());
        }
    }

    public void dropCF(String cfName) throws Exception {
        // lazyInitialize();
        if (cassandraCluster.describeKeyspace(queryServiceConfiguration.getKeyspaceName()) != null) {
            LOGGER.info("Dropping " + cassandraCluster.describeKeyspace(queryServiceConfiguration.getKeyspaceName()).getName()
                    + Shared.LOG_DELIMITER + cfName);
            // Drop CF
            cassandraCluster.dropColumnFamily(queryServiceConfiguration.getKeyspaceName(), cfName, true);
            // Drop custom indexes for CF - only in case of main CF
            if (metadataService.getSourceUrlsForDataset(cfName) != null) {
                int schemaFieldsLength = metadataService.getAttributeNamesForDataset(cfName).size();
                for (int position = 0; position < schemaFieldsLength; position++) {
                    cassandraCluster.dropColumnFamily(queryServiceConfiguration.getKeyspaceName(), cfName
                            + Shared.CASSANDRA_INDEX_NAME_SEPARATOR + position, true);
                }
            }
            LOGGER.info("Dropped " + cfName);
        }
    }

    public int totalRowCount(String viewName) {
        // lazyInitialize();
        String start = null;
        String lastEnd = null;
        int count = 0;
        while (true) {
            RangeSlicesQuery<String, String, String> rsq = HFactory.createRangeSlicesQuery(idpKeyspace, StringSerializer.get(),
                    StringSerializer.get(), StringSerializer.get());
            rsq.setColumnFamily(viewName);
            rsq.setColumnNames("issue_active");
            // Nulls are the same as get_range_slices with empty strs.
            rsq.setKeys(start, null);
            rsq.setReturnKeysOnly(); // Return column names instead of values
            rsq.setRowCount(1000); // Arbitrary default
            OrderedRows<String, String, String> rows = rsq.execute().get();
            int rowCount = rows.getCount();
            if (rowCount == 0) {
                break;
            } else {
                start = rows.peekLast().getKey();
                if (lastEnd != null && start.compareTo(lastEnd) == 0) {
                    break;
                }
                count += rowCount - 1; // Key range is inclusive
                lastEnd = start;
            }
        }
        if (count > 0) {
            count += 1;
        }
        return count;
    }

    public void setMetadataService(MetadataService metadataService) {
        this.metadataService = metadataService;
    }

    public ColumnSliceIterator<String, String, String> createColumnSliceIterator(String cfName, String key, String start, String finish,
            int batchSize) {
        // Get column slice for key
        SliceQuery<String, String, String> sliceQuery = HFactory.createSliceQuery(idpKeyspace, stringSerializer, stringSerializer,
                stringSerializer);
        sliceQuery.setColumnFamily(cfName);
        sliceQuery.setKey(key);
        return new ColumnSliceIterator<String, String, String>(sliceQuery, start, finish, false, batchSize);
    }

    public String getValueForColumn(String cfName, String key, String columnName) {
        // Get column slice for key
        SliceQuery<String, String, String> sliceQuery = HFactory.createSliceQuery(idpKeyspace, stringSerializer, stringSerializer,
                stringSerializer);
        List<HColumn<String, String>> columns = sliceQuery.setColumnFamily(cfName).setKey(key).setColumnNames(columnName).execute().get()
                .getColumns();
        if (columns != null && columns.size() == 1) {
            return columns.get(0).getValue();
        }
        return null;
    }

    public QueryResult<Rows<String, String, String>> executeMultigetSliceQuery(String columnFamily, String columnName, String[] keyArray) {
        return HFactory.createMultigetSliceQuery(idpKeyspace, stringSerializer, stringSerializer, stringSerializer)
                .setColumnFamily(columnFamily).setColumnNames(columnName).setKeys(keyArray).execute();
    }

    public Mutator<String> createMutator() {
        return HFactory.createMutator(idpKeyspace, stringSerializer);
    }

    public HColumn<String, String> createColumn(String name, String value) {
        return HFactory.createColumn(name, value, stringSerializer, stringSerializer);
    }

    //
    // public HColumn<String, String> deleteColumn(String key, String cf, String
    // columnName) {
    // return HFactory.createColumn(name, value, stringSerializer,
    // stringSerializer);
    // }
    public ColumnSlice<String, String> executeColumnSliceQuery(String columnFamily, String columnName, String key) {
        return HFactory.createSliceQuery(idpKeyspace, stringSerializer, stringSerializer, stringSerializer).setColumnFamily(columnFamily)
                .setColumnNames(columnName).setKey(key).execute().get();
    }
}
