Query Service (aka DAS)
===

iDP Query Service - http://confluence.swissbank.com/display/IDP/Query+Service

- A `metadata` driven approach to data distribution
- Consumers use logical model abstracted from GDS locations and technology choices
- Consolidates many ad-hoc extracts and jobs into one place
- Supports custom 'views' which allows GDS to more finely know who extracts what data and when
- Various output formats - TEXT, XML, JSON etc
- `Cassandra` provides the load and join engine
- `Neo4j` provides the metadata graph
- MDF `GemFire` provides the caching framework for high-performance access

Future
===
- Temporal data
- Leverage analytics to improve data distribution services
- `Kafka` based the event store
- APIs for `Lookup`, `Search`, `Upload`, `Relate` etc

Local deploy (eclipse)
===
- Start JettyLauncher*.launch
- Before committing code changes, regression test with com.ubs.idp.das.model.DASIntegrationTest

Swift deploy
===
https://swift-dev.ldn.swissbank.com:10443/swift/Distribution/status?group=com.ubs.idp&artifact=idp-das
