package com.ubs.idp.test.swift;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ubs.idp.swiftclient.SwiftService;
import com.ubs.idp.swiftclient.valueobjects.AdhocDeploymentId;
import com.ubs.idp.swiftclient.valueobjects.Artifact;
import com.ubs.idp.swiftclient.valueobjects.ArtifactCfg;
import com.ubs.idp.swiftclient.valueobjects.ArtifactCfgList;
import com.ubs.idp.swiftclient.valueobjects.DeployTag;
import com.ubs.idp.swiftclient.valueobjects.DeploymentPlan;
import com.ubs.idp.swiftclient.valueobjects.Environment;
import com.ubs.idp.swiftclient.valueobjects.Host;
import com.ubs.idp.swiftclient.valueobjects.ListReleasesResponse;
import com.ubs.idp.swiftclient.valueobjects.Organisation;
import com.ubs.idp.swiftclient.valueobjects.ReleaseInfo;
import com.ubs.swift.deployment.model.DeploymentAction;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-applicationContext.xml" })
public class SwiftRestAPISpringIntegrationTest {

    private static final int FIRST_RELEASE = 916;

    private static Logger logger = LoggerFactory.getLogger(SwiftRestAPISpringIntegrationTest.class);

    @Autowired
    private SwiftService swiftService;

    @Before
    public void setUp() {
        logger.info("Set up test");
    }

    @Test
    public void listGroups() {
        logger.info("List groups...");

        try {
            List<String> groups = swiftService.listSwiftGroups();

            logger.info("Got groups: {}", groups);

        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception!");
        }
    }

    @Test
    public void listTeamReleases() {
        logger.info("List releases...");

        try {
            ListReleasesResponse releases = swiftService.listTeamReleases();

            // Get 1st page
            int count = releases.getPageResults().size();

            // Page through remainder
            while (count < releases.getTotalRecords()) {
                releases = swiftService.listTeamReleases(count, 20);

                count += releases.getPageResults().size();
            }

            logger.info("Got {} releases (total: {})", count, releases.getTotalRecords());

        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception!");
        }
    }

    // Tests below set to ignore for now (confine to predictable read tests
    // above)

    @Test
    @Ignore
    public void getReleaseById() {
        logger.info("Get release by ID");

        try {
            ReleaseInfo release = swiftService.getRelease(FIRST_RELEASE);

            logger.info("Got release: {}", release.getName());

        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception!");
        }
    }

    @Test
    @Ignore
    public void updateRelease() {
        logger.info("Update release");

        try {
            SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");

            Date now = new Date();
            DateTime releaseDate = new DateTime().withZone(DateTimeZone.forID("UTC")).plusDays(2);

            releaseDate = releaseDate.dayOfYear().roundFloorCopy();

            String newName = "Pauls First Test";
            String newDescription = "Integration Test Update at " + df.format(now);

            swiftService.updateRelease(FIRST_RELEASE, newName, newDescription, releaseDate.toDate());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception!");
        }
    }

    @Test
    @Ignore
    public void addModifyRemoveArtifact() {
        Artifact artifact = new Artifact();

        artifact.setArtifactId("ariel");
        artifact.setGroupId("idp");
        artifact.setVersion("1.4");

        try {
            swiftService.addArtifactToRelease(FIRST_RELEASE, artifact);

            artifact.setVersion("1.3");

            swiftService.modifyArtifactInRelease(FIRST_RELEASE, artifact);

            swiftService.removeArtifactFromRelease(FIRST_RELEASE, artifact);
        } catch (IOException e) {
            e.printStackTrace();
            fail("Unexpected exception!");
        }
    }

    @Test
    @Ignore
    // Ignore so we don't proliferate releases
    public void cloneRelease() {
        logger.info("Clone release");

        try {
            SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");

            Date now = new Date();
            DateTime releaseDate = new DateTime().withZone(DateTimeZone.forID("UTC")).plusDays(2);

            releaseDate = releaseDate.dayOfYear().roundFloorCopy();

            String newName = "JUnit Cloned Release - " + System.currentTimeMillis();
            String newDescription = "Integration Test Update at " + df.format(now);

            swiftService.cloneRelease(FIRST_RELEASE, newName, newDescription, releaseDate.toDate());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception!");
        }
    }

    @Test
    @Ignore
    public void latestSnapshotTest() {
        logger.info("Move release artifacts to latest snapshot");

        try {
            swiftService.bulkUpdateArtifactVersions(FIRST_RELEASE, SwiftService.SWICHTYPE_SERVER_LATEST_SNAPSHOT);

            swiftService.bulkUpdateArtifactVersions(FIRST_RELEASE, SwiftService.SWICHTYPE_CLIENT_LATEST_SNAPSHOT);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception!");
        }
    }

    @Test
    @Ignore
    public void adhocDeploymentPlanTest() {
        logger.info("Create ad-hoc release deployment");

        try {
            String ids[] = {
                    // For this test, simply stop idp-neo4j(DEV) on 97 box
                    "Distribution/dev//xldn0097vdap/com.ubs.idp/idp-neo4j-DEV" };

            DeploymentPlan adhocPlan = swiftService.createAdhocDeploymentPlan(SwiftService.DEPLOYMENT_ACTION_STOP,
                    false, // Don't include dependencies for this test
                    ids);

            logger.info("Got deployment plan: {}", adhocPlan);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception!");
        }
    }

    @Test
    @Ignore
    public void updateArtifactCfgTest() {
        logger.info("Get artifact cfg");

        try {
            /*
             * String organisation = "Distribution"; String environment = "dev"; String group = "com.ubs.idp"; String
             * artifact = "idp-xd-modules"; String newVersion = "1.0.13-SNAPSHOT";
             */
            String organisation = "Distribution";
            String environment = "dev";
            String group = "idp";
            String artifact = "ariel";
            String newVersion = "1.5-SNAPSHOT";

            String deploymentTag = "IdpXdModulesDev";

            ArtifactCfgList artifactCfgList = swiftService.getArtifactCfg(organisation, environment, group, artifact);

            ArtifactCfg artifactCfg = null;

            if (artifactCfgList.size() == 1) {
                artifactCfg = artifactCfgList.get(0);
            } else {
                for (ArtifactCfg artifactCfgChk : artifactCfgList) {
                    for (DeployTag tag : artifactCfgChk.getDeployTags()) {
                        logger.debug("Check tag {}", tag.getTag());
                        if (tag.getTag().equals(deploymentTag)) {
                            artifactCfg = artifactCfgChk;
                        }
                    }
                }
            }

            assertNotNull(artifactCfg);

            logger.info("Got artifact cfg: {}", artifactCfg);

            // Update version and save

            artifactCfg.setArtifactVersion(newVersion);

            artifactCfg = swiftService.saveArtifactCfg(artifactCfg);

            logger.info("Check LUD: {}", artifactCfg.getLastUpdatedTime());

        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception!");
        }
    }

    @Test
    @Ignore
    public void executeAdhocDeploymentAction() {
        logger.info("Execute ad-hoc deployment action");

        try {
            String organisationName = "Distribution";
            String environmentName = "dev";
            String hostname = "xldn0097vdap";
            String groupId = "idp";
            String artifactId = "ariel";

            /*
             * Looking in Swift code, available actions are: Stop Start - start from any state StartOnly - start only
             * from a stopped state. Bounce Redeploy Undeploy
             */
            // String deploymentAction = "Start";
            DeploymentAction deploymentAction = DeploymentAction.Stop;
            // String deploymentAction = "Undeploy";

            List<AdhocDeploymentId> deploymentIdList = new ArrayList<AdhocDeploymentId>();

            // Set up a deployment ID

            AdhocDeploymentId deploymentId = new AdhocDeploymentId();

            deploymentId.setArtifactId(artifactId);
            deploymentId.setGroupId(groupId);

            // Specify target host

            Host host = new Host();

            host.setHostname(hostname);

            // Specify the environment and organisation for the host

            Environment environment = new Environment();
            environment.setName(environmentName);

            Organisation organisation = new Organisation();
            organisation.setName(organisationName);

            environment.setOrganisation(organisation);

            host.setEnvironment(environment);

            // Update the deployment and add to the list

            deploymentId.setHost(host);

            deploymentIdList.add(deploymentId);

            // Invoke Swift

            swiftService.executeAdhocDeploymentAction(deploymentAction, deploymentIdList);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected exception!");
        }
    }

    @Test
    @Ignore
    public void executeReleaseDeploymentTest() {
        int releaseId = FIRST_RELEASE;
        String environment = "dev";
        
        String res = swiftService.executeReleaseDeployment(releaseId, environment);
        
        // Res is a deployment response string of the form:
        //   6e546fdb-5181-454d-8b5a-013ee6895a18
        //   ..or..
        //   fb411ea8-9489-4da3-8526-5ea5ef9a74f0
        //
        // Which varies with each deployment - so can't really test for absolute value
        
        String[] parts = res.split("-");
        assertEquals("Unexpected response format? (" + res + ")", 5, parts.length);
        
        // Check each part is valid hex number
        for (String part : parts) {
            Long partValue = Long.decode("#" + part);
        }
    }
}
