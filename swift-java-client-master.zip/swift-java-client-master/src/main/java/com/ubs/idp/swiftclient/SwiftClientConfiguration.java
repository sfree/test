package com.ubs.idp.swiftclient;

import java.io.IOException;
import java.net.URL;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ubs.distribution.idm.LwsClient;
import com.ubs.distribution.idm.exceptions.LwsException;
import com.ubs.distribution.idm.internal.base.LwsClientImpl;
import com.ubs.idp.encrypt.Crypto;

/**
 * Swift Client Configuration
 */
@Configuration("swiftClientConfiguration")
public class SwiftClientConfiguration {

    @Value("${lws.authUri}")
    private String authUri;

    @Value("${sso.user}")
    private String ssoUsername;

    @Value("${sso.password}")
    private String ssoPassword;

    @Value("${swift.baseUri}")
    private String baseUri;

    @Value("${swift.connection.read.timeout:0}")
    private String timeout;

    @Value("${swift.release.id}")
    private String releaseId; 
    
    @Bean(name = "swiftClientObjectMapper")
    public ObjectMapper getObjectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(Inclusion.NON_NULL);
        return mapper;
    }

    @Bean(name = "swiftLwsToken")
    public String getLwsToken() throws LwsException, IOException {
        LwsClient lwsClient = new LwsClientImpl(new URL(authUri));
        return lwsClient.getToken(ssoUsername, Crypto.decrypt(ssoPassword)).getToken();
    }

    @Bean(name = "swiftTimeoutMSec")
    public int getTimeout() {
        return Integer.parseInt(timeout);
    }

    @Bean(name = "swiftBaseUri")
    public String getBaseUri() {
        return baseUri;
    }

    public String getReleaseId() {
        return releaseId;
    }
}
