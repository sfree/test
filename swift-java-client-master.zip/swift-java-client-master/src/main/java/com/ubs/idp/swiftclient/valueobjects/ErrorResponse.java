package com.ubs.idp.swiftclient.valueobjects;

/**
 * Value object for errors returned from Swift API calls
 * @author mcminnp
 */
public class ErrorResponse {
	private String message;
	private String exceptionClass;
	private String[] stackTrace;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getExceptionClass() {
		return exceptionClass;
	}
	public void setExceptionClass(String exceptionClass) {
		this.exceptionClass = exceptionClass;
	}
	public String[] getStackTrace() {
		return stackTrace;
	}
	public void setStackTrace(String[] stackTrace) {
		this.stackTrace = stackTrace;
	}
}
