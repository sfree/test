package com.ubs.idp.swiftclient.valueobjects;

public class DeployTag extends Tag {

    private Environment environment;

    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }
    
}
