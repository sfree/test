package com.ubs.idp.swiftclient.valueobjects;

public class Tag {

    private String tag;

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

}
