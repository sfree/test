package com.ubs.idp.swiftclient;

import static org.springframework.util.Assert.notEmpty;
import static org.springframework.util.Assert.notNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ubs.idp.swiftclient.valueobjects.AdhocDeploymentId;
import com.ubs.idp.swiftclient.valueobjects.Artifact;
import com.ubs.idp.swiftclient.valueobjects.ArtifactCfg;
import com.ubs.idp.swiftclient.valueobjects.ArtifactCfgList;
import com.ubs.idp.swiftclient.valueobjects.DeploymentPlan;
import com.ubs.idp.swiftclient.valueobjects.ListReleasesResponse;
import com.ubs.idp.swiftclient.valueobjects.ReleaseInfo;
import com.ubs.swift.deployment.api.DeploymentProcessor;
import com.ubs.swift.deployment.model.DeploymentAction;

/**
 * Swift client service
 * 
 * This client can be used as a pojo or as a Spring bean. The default constructor is necessary if Spring is being used,
 * otherwise instantiate directly by using the constructor that requires parameters.
 */
@Component("swiftService")
public class SwiftService implements DeploymentProcessor {

    private static final Logger LOGGER = LoggerFactory.getLogger(SwiftService.class);

    private static final String PARAM_SEPARATOR = "/";
    private static final String API_LIST_GROUPS = "/api/lookup/groups";
    private static final String API_LIST_TEAM_RELEASES = "/api/release/myteams";
    private static final String API_GET_RELEASE_BY_ID = "/api/release/:releaseId";
    private static final String API_UPDATE_RELEASE = "/api/release/:releaseId/details";
    private static final String API_CLONE_RELEASE = "/api/release/clone/:releaseId";
    private static final String API_RELEASE_ARTIFACT = "/api/release/:releaseId/artifact";
    private static final String API_BULK_ARTIFACT = "/api/release/:releaseId/switchArtifacts/:switchType";
    private static final String API_ADHOC_PLAN = "/api/deployment/process";
    private static final String API_GET_ARTIFACT_CFG = "/api/config/artifact/:organisation/:environment/:group/:artifact";
    private static final String API_PUT_ARTIFACT_CFG = "/api/config/artifact";
    private static final String API_EXECUTE_ADHOC_DEPLOY = "/api/deployment/execute/:deploymentAction";
    private static final String API_EXECUTE_RELEASE_DEPLOY = "/api/deployment/execute/release/:releaseId/:environment";

    // Switch types for use in API_BULK_ARTIFACT call:
    // e.g.: /api/release/916/switchArtifacts/SNAPSHOTCLIENT?version=
    public static final String SWICHTYPE_CLIENT_LATEST_SNAPSHOT = "SNAPSHOTCLIENT?version=";
    public static final String SWICHTYPE_SERVER_LATEST_SNAPSHOT = "SNAPSHOTSERVER?version=";
    public static final String SWICHTYPE_RELEASE = "RELEASE?version=";

    // Deployment actions
    public static final String DEPLOYMENT_ACTION_STOP = "Stop";
    public static final String DEPLOYMENT_ACTION_START = "Start";
    public static final String DEPLOYMENT_ACTION_BOUNCE = "Bounce";
    public static final String DEPLOYMENT_ACTION_REDEPLOY = "Redeploy";
    public static final String DEPLOYMENT_ACTION_UNDEPLOY = "Undeploy";

    @Autowired
    @Qualifier("swiftRESTClient")
    private SwiftRESTClient swiftRestClient;

    public SwiftService() {
        // default constructor for Spring
        LOGGER.info("Initialise (Spring version) Swift client...");
    }

    /**
     * Construct and initialise client
     * 
     * @param baseUri
     * @param lwsToken
     * @param timeoutMSec
     */
    public SwiftService(final String baseUri, final String lwsToken, final int timeoutMSec) {

        LOGGER.info("Initialise Swift client on {}...", baseUri);

        // Set up client:
        swiftRestClient = new SwiftRESTClient(baseUri, lwsToken, timeoutMSec);
    }

    /**
     * List all Swift groups
     * 
     * @return
     * @throws IOException
     */
    @SuppressWarnings("unchecked")
    public List<String> listSwiftGroups() throws IOException {
        LOGGER.info("List Swift groups...");
        return swiftRestClient.getSwiftResponseObject(API_LIST_GROUPS, List.class);
    }

    /**
     * List 1st page of releases for current logged on user's team
     * 
     * @return
     * @throws IOException
     */
    public ListReleasesResponse listTeamReleases() throws IOException {
        return listTeamReleases(-1, -1);
    }

    /**
     * List page of releases for current logged on user's team
     * 
     * @param start
     * @param records
     * @return
     * @throws IOException
     */
    public ListReleasesResponse listTeamReleases(final int start, final int records) throws IOException {
        LOGGER.info("List team releases...");
        String url = API_LIST_TEAM_RELEASES;

        if (start >= 0) {
            url += "?start=" + start;
        }

        if (records >= 0) {
            if (url.equals(API_LIST_TEAM_RELEASES)) {
                url += "?";
            } else {
                url += "&";
            }
            url += "records=" + records;
        }

        return swiftRestClient.getSwiftResponseObject(
                url,
                ListReleasesResponse.class);
    }

    /**
     * Get specified release detail
     * 
     * @param id
     * @return
     * @throws IOException
     */
    public ReleaseInfo getRelease(final int id) throws IOException {
        LOGGER.info("Get release id {}...", id);

        return swiftRestClient.getSwiftResponseObject(
                API_GET_RELEASE_BY_ID.replace(":releaseId", id + ""),
                ReleaseInfo.class);
    }

    /**
     * Clone a release
     * 
     * @param id
     * @param newName
     * @param newDescription
     * @param releaseDate
     * @return
     * @throws IOException
     */
    public ReleaseInfo cloneRelease(final int id, final String newName, final String newDescription,
            final Date releaseDate) throws IOException {
        LOGGER.info("Clone release id {}...", id);

        ReleaseInfo release = new ReleaseInfo();
        release.setName(newName);
        release.setReleaseDate(releaseDate);
        release.setDescription(newDescription);

        return swiftRestClient.postSwiftPayload(
                API_CLONE_RELEASE.replace(":releaseId", id + ""),
                release,
                ReleaseInfo.class);
    }

    /**
     * Update specified release details
     * 
     * @param id
     * @param newName
     * @param newDescription
     * @param releaseDate
     * @throws IOException
     */
    public void updateRelease(final int id, final String newName, final String newDescription, final Date releaseDate)
            throws IOException {
        LOGGER.info("Update release id {}...", id);

    	ReleaseInfo release = getRelease(id);

        release.setName(newName);
        release.setReleaseDate(releaseDate);
        release.setDescription(newDescription);

        swiftRestClient.putSwiftPayload(
                API_UPDATE_RELEASE.replace(":releaseId", id + ""),
                release,
                null);
    }

    /**
     * Update specified release details
     * 
     * @param id
     * @param releaseDate
     * @throws IOException
     */
    public void updateRelease(final int id, final Date releaseDate)
            throws IOException {
        LOGGER.info("Update release id {}...", id);

    	ReleaseInfo release = getRelease(id);

        release.setReleaseDate(releaseDate);

        swiftRestClient.putSwiftPayload(
                API_UPDATE_RELEASE.replace(":releaseId", id + ""),
                release,
                null);
    }
    
    /**
     * Add an artifact to an existing release
     * 
     * @param id
     * @param newArtifact
     * @return
     * @throws IOException
     */
    public Artifact addArtifactToRelease(final int id, final Artifact newArtifact) throws IOException {
        LOGGER.info("Add {} artifact to release id {}...", newArtifact.getArtifactId(), id);

        return swiftRestClient.postSwiftPayload(
                API_RELEASE_ARTIFACT.replace(":releaseId", id + ""),
                newArtifact,
                Artifact.class);
    }

    /**
     * Modify an artifact in an existing release
     * 
     * @param releaseId
     * @param newArtifact
     * @return
     * @throws IOException
     */
    public Artifact modifyArtifactInRelease(final int releaseId, final Artifact newArtifact) throws IOException {
        LOGGER.info("Modify {} artifact in release id {}...", newArtifact.getArtifactId(), releaseId);

        return swiftRestClient.putSwiftPayload(
                API_RELEASE_ARTIFACT.replace(":releaseId", releaseId + ""),
                newArtifact,
                Artifact.class);
    }

    /**
     * Remove an artifact from an existing release
     * 
     * @param releaseId
     * @param newArtifact
     * @return
     * @throws IOException
     */
    public Artifact removeArtifactFromRelease(final int releaseId, final Artifact newArtifact) throws IOException {

        LOGGER.info("Remove {} artifact from release id {}...", newArtifact.getArtifactId(), releaseId);

        return swiftRestClient.deleteSwiftPayload(
                API_RELEASE_ARTIFACT.replace(":releaseId", releaseId + ""),
                newArtifact,
                Artifact.class);
    }

    /**
     * Bulk update artifact versions
     * 
     * @param releaseId
     * @param switchType
     * @return
     * @throws IOException
     */
    public ReleaseInfo bulkUpdateArtifactVersions(final int releaseId, final String switchType) throws IOException {
        LOGGER.info("Bulk update release id {} - switch type: {}", releaseId, switchType);

        return swiftRestClient.putSwiftPayload(
                API_BULK_ARTIFACT
                        .replace(":releaseId", releaseId + "")
                        .replace(":switchType", switchType),
                null,
                ReleaseInfo.class);
    }

    /**
     * Create an ad hoc deployment plan
     * 
     * @param deploymentAction
     * @param includeDependencies
     * @param ids
     * @return
     * @throws IOException
     */
    public DeploymentPlan createAdhocDeploymentPlan(final String deploymentAction, final boolean includeDependencies,
            final String ids[]) throws IOException {
        LOGGER.info("Create ad-hoc deployment plan - action {}, include dependencies {}", deploymentAction,
                includeDependencies);
        LOGGER.debug("Ids: {}", (Object) ids);

        notNull(deploymentAction, "Deployment action must be non-null!");
        notNull(ids, "Deployment ids must be non-null!");
        notEmpty(ids, "Deployment ids must contain 1 or more IDs");

        String url = API_ADHOC_PLAN +
                "?deploymentAction=" + deploymentAction +
                "&includeDependencies=" + includeDependencies;

        return swiftRestClient.postSwiftPayload(url, ids, DeploymentPlan.class);
    }

    /**
     * Fetch current artifact config for a given environment
     * 
     * @param organisation
     * @param environment
     * @param group
     * @param artifact
     * @return
     * @throws IOException
     */
    public ArtifactCfgList getArtifactCfg(final String organisation, final String environment, final String group,
            final String artifact) throws IOException {
        LOGGER.info("Get artifact config for {}/{}/{}/{}", organisation, environment, group, artifact);

        String url = API_GET_ARTIFACT_CFG
                .replace(":organisation", organisation)
                .replace(":environment", environment)
                .replace(":group", group)
                .replace(":artifact", artifact);

        return swiftRestClient.getSwiftResponseObject(url, ArtifactCfgList.class);
    }

    /**
     * Save artifact configuration
     * 
     * @param artifactCfg
     * @return
     * @throws IOException
     */
    public ArtifactCfg saveArtifactCfg(final ArtifactCfg artifactCfg) throws IOException {
        LOGGER.info("Save artifact config for {}/{}/{}/{}",
                artifactCfg.getEnvironment().getName(),
                artifactCfg.getGroupId(),
                artifactCfg.getName());

        return swiftRestClient.putSwiftPayload(API_PUT_ARTIFACT_CFG,
                artifactCfg,
                ArtifactCfg.class);
    }

    /**
     * Execute an ad-hoc deployment for specified artifacts to specified environments
     * 
     * @param deploymentAction
     * @param deploymentIdList
     * @throws IOException
     */
    public void executeAdhocDeploymentAction(final DeploymentAction deploymentAction,
            final List<AdhocDeploymentId> deploymentIdList) throws IOException {

        LOGGER.info("Execute ad-hoc '{}' deployment of {} artifact IDs", deploymentAction, deploymentIdList.size());

        notNull(deploymentIdList, "Deployment ID list cannot be null!");
        notEmpty(deploymentIdList, "Deployment ID list cannot be empty!");

        List<String> deploymentIds = new ArrayList<>();
        for (AdhocDeploymentId deploymentId : deploymentIdList) {
            String id = deploymentId.getHost().getEnvironment().getOrganisation().getName() + PARAM_SEPARATOR
                    + deploymentId.getHost().getEnvironment().getName() + PARAM_SEPARATOR + PARAM_SEPARATOR
                    + deploymentId.getHost().getHostname() + PARAM_SEPARATOR
                    + deploymentId.getGroupId() + PARAM_SEPARATOR
                    + deploymentId.getArtifactId();
            deploymentIds.add(id);
        }
        executeDeployment(deploymentAction, deploymentIds);
    }

    /**
     * Executes an ad-hoc deployment and returns the unique id of the executed deployment.
     */
    @Override
    public String executeDeployment(final DeploymentAction deploymentAction, final List<String> deploymentIdList) {
        String url = API_EXECUTE_ADHOC_DEPLOY.replace(":deploymentAction", deploymentAction.name());

        try {
            return swiftRestClient.postSwiftPayload(url, deploymentIdList, String.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    /**
     * Execute a pre-defined release
     * @param releaseId
     * @param environment
     * @return
     */
    public String executeReleaseDeployment(final int releaseId, final String environment) {
        LOGGER.info("Execute deployment of release ID {} to {} environment", releaseId, environment);

        String url = "/api/deployment/execute/release/:releaseId/:environment"
                .replace(":releaseId", releaseId+"")
                .replace(":environment", environment);

        try {
            return swiftRestClient.postSwiftPayload(url, null, String.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
