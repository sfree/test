package com.ubs.idp.swiftclient.valueobjects;

/**
 * Details for artifact deployment to specific host in a specific environment
 * @author mcminnp
 */
public class AdhocDeploymentId extends Artifact {
    private Host host;

    public Host getHost() {
        return host;
    }

    public void setHost(Host host) {
        this.host = host;
    }
}
