package com.ubs.idp.swiftclient.valueobjects;

import java.util.Date;
import java.util.List;

/**
 * Swift host details
 * @author mcminnp
 */
public class Host {

    private String hostname;
    private Environment environment;
    private Date lastAutoRestartTime;
    private List<DeployTag> deployTags;
    private Date lastUpdatedTime;

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }

    public Date getLastAutoRestartTime() {
        return lastAutoRestartTime;
    }

    public void setLastAutoRestartTime(Date lastAutoRestartTime) {
        this.lastAutoRestartTime = lastAutoRestartTime;
    }

    public List<DeployTag> getDeployTags() {
        return deployTags;
    }

    public void setDeployTags(List<DeployTag> deployTags) {
        this.deployTags = deployTags;
    }

    public Date getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    public void setLastUpdatedTime(Date lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }
}
