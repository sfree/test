package com.ubs.idp.swiftclient.valueobjects;

import java.util.List;

/**
 * List releases response object for JSON un-marshalling
 * @author mcminnp
 */
public class ListReleasesResponse {
    private RequestFilter requestFilter;
 
    private int totalRecords;
    
    private List<ReleaseInfo> pageResults;

    public RequestFilter getRequestFilter() {
        return requestFilter;
    }

    public void setRequestFilter(RequestFilter requestFilter) {
        this.requestFilter = requestFilter;
    }

    public int getTotalRecords() {
        return totalRecords;
    }

    public void setTotalRecords(int totalRecords) {
        this.totalRecords = totalRecords;
    }

    public List<ReleaseInfo> getPageResults() {
        return pageResults;
    }

    public void setPageResults(List<ReleaseInfo> pageResults) {
        this.pageResults = pageResults;
    }
}