package com.ubs.idp.swiftclient.valueobjects;

import java.util.Date;
import java.util.List;

public class ReleaseInfo {
    private Integer id;
    
    private String name;
    
    private String description;
    
    private Team team;
    
    private String createdBy;
    
    private Date createdTime;
    
    private String lastUpdatedBy;

    private Date lastUpdatedTime;

    private Date releaseDate;
    
    private Boolean locked;
    
    private String deploymentProcess;
    
    private String deploymentTemplate;
    
    private List<Artifact> artifacts;
    
    private List<String> releaseLinks;
    
    private String revision;
    
    private String latestRevision;
    
    private String fieldHandler;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Date getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    public void setLastUpdatedTime(Date lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public Boolean isLocked() {
        return locked;
    }

    public void setLocked(Boolean locked) {
        this.locked = locked;
    }

    public String getDeploymentProcess() {
        return deploymentProcess;
    }

    public void setDeploymentProcess(String deploymentProcess) {
        this.deploymentProcess = deploymentProcess;
    }

    public String getDeploymentTemplate() {
        return deploymentTemplate;
    }

    public void setDeploymentTemplate(String deploymentTemplate) {
        this.deploymentTemplate = deploymentTemplate;
    }

    public List<Artifact> getArtifacts() {
        return artifacts;
    }

    public void setArtifacts(List<Artifact> artifacts) {
        this.artifacts = artifacts;
    }

    public List<String> getReleaseLinks() {
        return releaseLinks;
    }

    public void setReleaseLinks(List<String> releaseLinks) {
        this.releaseLinks = releaseLinks;
    }

    public String getRevision() {
        return revision;
    }

    public void setRevision(String revision) {
        this.revision = revision;
    }

    public String getLatestRevision() {
        return latestRevision;
    }

    public void setLatestRevision(String latestRevision) {
        this.latestRevision = latestRevision;
    }

    public String getFieldHandler() {
        return fieldHandler;
    }

    public void setFieldHandler(String fieldHandler) {
        this.fieldHandler = fieldHandler;
    }
}
