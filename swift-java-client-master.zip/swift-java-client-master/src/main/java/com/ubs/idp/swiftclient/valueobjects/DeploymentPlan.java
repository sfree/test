package com.ubs.idp.swiftclient.valueobjects;

import java.util.List;

/**
 * Deployment plan to move an environment to a specified release
 * @author mcminnp
 */
public class DeploymentPlan {
    private String planId;
    private List<DeploymentAction> actions;
    private List<Message> warnings;
    public String getPlanId() {
        return planId;
    }
    public void setPlanId(String planId) {
        this.planId = planId;
    }
    public List<DeploymentAction> getActions() {
        return actions;
    }
    public void setActions(List<DeploymentAction> actions) {
        this.actions = actions;
    }
    public List<Message> getWarnings() {
        return warnings;
    }
    public void setWarnings(List<Message> warnings) {
        this.warnings = warnings;
    }
}
