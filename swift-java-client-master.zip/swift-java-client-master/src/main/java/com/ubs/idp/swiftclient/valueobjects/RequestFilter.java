package com.ubs.idp.swiftclient.valueobjects;

/**
 * Swift response - request filter
 * @author mcminnp
 */
public class RequestFilter {

    private int start;
    
    private int records;

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getRecords() {
        return records;
    }

    public void setRecords(int records) {
        this.records = records;
    }
    
}
