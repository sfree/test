package com.ubs.idp.swiftclient.valueobjects;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class ArtifactCfg {
    private String groupId;
    private String artifactId;
    private Environment environment;
    private String name;
    private String script;
    private String artifactVersion;
    private int mountPointScheme;
    private Boolean coldStandby;
    private List<Tag> tags;
    private List<DeployTag> deployTags;
    private Date lastUpdatedTime;
    private Map<String, String> scriptArgumentsMap;
    
    public String getGroupId() {
        return groupId;
    }
    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }
    public String getArtifactId() {
        return artifactId;
    }
    public void setArtifactId(String artifactId) {
        this.artifactId = artifactId;
    }
    public Environment getEnvironment() {
        return environment;
    }
    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getScript() {
        return script;
    }
    public void setScript(String script) {
        this.script = script;
    }
    public String getArtifactVersion() {
        return artifactVersion;
    }
    public void setArtifactVersion(String artifactVersion) {
        this.artifactVersion = artifactVersion;
    }
    public int getMountPointScheme() {
        return mountPointScheme;
    }
    public void setMountPointScheme(int mountPointScheme) {
        this.mountPointScheme = mountPointScheme;
    }
    public Boolean getColdStandby() {
		return coldStandby;
	}
	public void setColdStandby(Boolean coldStandby) {
		this.coldStandby = coldStandby;
	}
	public List<Tag> getTags() {
        return tags;
    }
    public void setTags(List<Tag> tags) {
        this.tags = tags;
    }
    public List<DeployTag> getDeployTags() {
        return deployTags;
    }
    public void setDeployTags(List<DeployTag> deployTags) {
        this.deployTags = deployTags;
    }
    public Date getLastUpdatedTime() {
        return lastUpdatedTime;
    }
    public void setLastUpdatedTime(Date lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }
    public Map<String, String> getScriptArgumentsMap() {
        return scriptArgumentsMap;
    }
    public void setScriptArgumentsMap(Map<String, String> scriptArgumentsMap) {
        this.scriptArgumentsMap = scriptArgumentsMap;
    }
}
