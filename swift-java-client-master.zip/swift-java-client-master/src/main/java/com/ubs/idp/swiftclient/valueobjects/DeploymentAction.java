package com.ubs.idp.swiftclient.valueobjects;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

/**
 * Deployment plan action
 * @author mcminnp
 */
public class DeploymentAction {
    @JsonProperty ( "@class" )
    private String clazz;
    private String id;
    private String name;
    private String artifactInstanceId;
    private List<DeploymentAction> included;
    private Boolean execute;
    private String artifactId;
    private String deploymentState;
    @JsonProperty ( "@type" )
    private String type;
    
    public String getClazz() {
        return clazz;
    }
    public void setClazz(String clazz) {
        this.clazz = clazz;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getArtifactInstanceId() {
        return artifactInstanceId;
    }
    public void setArtifactInstanceId(String artifactInstanceId) {
        this.artifactInstanceId = artifactInstanceId;
    }
    public List<DeploymentAction> getIncluded() {
        return included;
    }
    public void setIncluded(List<DeploymentAction> included) {
        this.included = included;
    }
    public Boolean getExecute() {
        return execute;
    }
    public void setExecute(Boolean execute) {
        this.execute = execute;
    }
    public String getArtifactId() {
        return artifactId;
    }
    public void setArtifactId(String artifactId) {
        this.artifactId = artifactId;
    }
    public String getDeploymentState() {
        return deploymentState;
    }
    public void setDeploymentState(String deploymentState) {
        this.deploymentState = deploymentState;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
}
