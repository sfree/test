package com.ubs.idp.swiftclient;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ubs.idp.swiftclient.valueobjects.ErrorResponse;

/**
 * Swift REST client interface Pulled this out into a separate client so we can
 * move to Spring REST templates in subsequent releases if required
 */
@Component("swiftRESTClient")
public class SwiftRESTClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(SwiftRESTClient.class);

    private static final String GET = RequestMethod.GET.toString();
    private static final String PUT = RequestMethod.PUT.toString();
    private static final String POST = RequestMethod.POST.toString();
    private static final String DELETE = RequestMethod.DELETE.toString();

    // Swift currently ONLY supports Chrome - enforces for REST calls too (based
    // on early tests)
    private static final String CHROME_AGENT_EMULATION = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.114 Safari/537.36";

    @Autowired
    @Qualifier("swiftBaseUri")
    private String baseUri;

    @Autowired
    @Qualifier("swiftLwsToken")
    private String lwsToken;

    @Autowired
    @Qualifier("swiftTimeoutMSec")
    private int timeoutMSec;

    @Autowired
    @Qualifier("swiftClientObjectMapper")
    private ObjectMapper mapper;

    public SwiftRESTClient() {
        // default constructor for Spring
        LOGGER.info("Initialise (Spring version) Swift client on {}...", baseUri);
    }

    /**
     * Construct and initialise client
     * 
     * @param baseUri
     * @param lwsToken
     * @param timeoutMSec
     */
    public SwiftRESTClient(String baseUri, String lwsToken, int timeoutMSec) {

        LOGGER.info("Initialise Swift client on {}...", baseUri);

        // Save config
        this.baseUri = baseUri;
        this.lwsToken = lwsToken;
        this.timeoutMSec = timeoutMSec;

        // Initialise mapper
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(Inclusion.NON_NULL);
    }

    /**
     * Perform GET action against specified API
     * 
     * @param apiCall
     * @return
     * @throws IOException
     */
    protected <T> T getSwiftResponseObject(String apiCall, Class<T> responseType) throws IOException {
        return performAction(apiCall, GET, null, responseType);
    }

    /**
     * Perform PUT action against specified API
     * 
     * @param apiCall
     * @param payload
     * @param responseType
     * @return
     * @throws IOException
     */
    protected <T> T putSwiftPayload(String apiCall, Object payloadObj, Class<T> responseType) throws IOException {
        return performAction(apiCall, PUT, payloadObj, responseType);
    }

    /**
     * Perform POST action against specified API
     * 
     * @param apiCall
     * @param payloadObj
     * @param responseType
     * @return
     * @throws IOException
     */
    protected <T> T postSwiftPayload(String apiCall, Object payloadObj, Class<T> responseType) throws IOException {
        return performAction(apiCall, POST, payloadObj, responseType);
    }

    /**
     * Perform DELETE action against specified API
     * 
     * @param apiCall
     * @param payloadObj
     * @param responseType
     * @return
     * @throws IOException
     */
    protected <T> T deleteSwiftPayload(String apiCall, Object payloadObj, Class<T> responseType) throws IOException {
        return performAction(apiCall, DELETE, payloadObj, responseType);
    }

    /**
     * Perform REST action against specified API
     * 
     * @param apiCall
     * @param method
     * @param payloadObj
     * @param responseType
     * @return
     * @throws IOException
     */
    protected <T> T performAction(String apiCall, String method, Object payloadObj, Class<T> responseType)
            throws IOException {

        URL url = new URL(baseUri + apiCall);
        LOGGER.debug("Invoke {} on {}...", method, url);

        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setReadTimeout(timeoutMSec);
        conn.setRequestMethod(method);
        conn.setRequestProperty("User-Agent", CHROME_AGENT_EMULATION);

        if (method.equals(POST) || method.equals(DELETE)) {
            conn.setRequestProperty("Accept", "application/json, text/javascript, */*; q=0.01");
        }

        if (!method.equals(GET)) {
            conn.setRequestProperty("Content-Type", "application/json");
        }

        String cookie = "LWSTOKEN=\"" + lwsToken + "\"";

        conn.addRequestProperty("Cookie", cookie);

        // Optionally send data on PUT/POST/DELETE

        if (payloadObj != null && !method.equals(GET)) {
            conn.setDoOutput(true);
            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
            out.write(mapper.writeValueAsString(payloadObj));
            out.close();
        }

        // Check response
        if (conn.getResponseCode() != 200) {
        	
        	InputStream input = conn.getErrorStream();
			
        	ErrorResponse errorResponse = mapper.readValue(printOutStream(input), ErrorResponse.class);
        	LOGGER.error("Error processing request! Code: {}, message: {}, detail: {}", conn.getResponseCode(), conn.getResponseMessage(), errorResponse.getMessage());
        	LOGGER.error("\tException class: {}", errorResponse.getExceptionClass());
        	if (errorResponse.getStackTrace() != null) {
        		for (String stackTraceRecord : errorResponse.getStackTrace()) {
        			LOGGER.error("\t\t{}", stackTraceRecord);
        		}
        	}
            throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode() + ", detail: " + errorResponse.getMessage());
        }

        String res = IOUtils.toString(conn.getInputStream());
        conn.disconnect();
        LOGGER.debug("Got payload: {}", res);

        if (responseType == null) {
            return null;
        } else {
            return mapper.readValue(res, responseType);
        }
    }

	private InputStream printOutStream(InputStream input)
			throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		byte[] buffer = new byte[1024];
		int len;
		while ((len = input.read(buffer)) > -1 ) {
		    baos.write(buffer, 0, len);
		}
		baos.flush();

		InputStream is1 = new ByteArrayInputStream(baos.toByteArray()); 
		BufferedReader br = new BufferedReader(new InputStreamReader(is1));
		String line = null;
		try {
			while ((line = br.readLine()) != null) {
				LOGGER.info(">>>> {}", line);
			}
		} catch (IOException e) {
			LOGGER.error("exception: ", e);
		}
		return new ByteArrayInputStream(baos.toByteArray());
	}
}
