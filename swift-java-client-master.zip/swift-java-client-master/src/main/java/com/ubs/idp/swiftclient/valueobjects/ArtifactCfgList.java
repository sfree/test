package com.ubs.idp.swiftclient.valueobjects;

import java.util.ArrayList;

/**
 * An array of artifact config values
 * @author mcminnp
 */
public class ArtifactCfgList extends ArrayList<ArtifactCfg> {

}
