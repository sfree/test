Swift Client for Java
=====================

Java client providing service wrapper for Swift RESTfull APIs.

Intended for use in integrating Swift deployments into continuous integration builds using the likes of TeamCity.

For more details, refer to:

* [DS API User Guide (LWS) PDF](http://bw.docweb.ubs.com/doc/livelink/32538948/1.%20DS%20API%20User%20Guide.pdf.pdf?func=docfetcher.fetchdoc&nodeid=32538948)
* [Swift Releases REST API](https://github.ldn.swissbank.com/NeoSwift/docs/blob/master/api/releases.md)
* [Swift Deployment REST API](https://github.ldn.swissbank.com/NeoSwift/docs/blob/master/api/deployment.md)

The embedded integration tests use the enviornment.properties` file in `src/test/resources`

For integration into projects, SSO system accounts should be created rather than using individuals credentials.

For more information see [Using Swift Rest APIs](http://confluence.swissbank.com/display/neo/Using+Swift+Rest+APIs)

Note that the new account will require the **SWIFT-DEV** privilege (see https://arpmanuat.swissbank.com)