package com.ubs.tools.http;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Set;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.powermock.reflect.Whitebox;

import com.ubs.tools.http.GitHubClient.Commit;
import com.ubs.tools.releases.model.Artifact;

public class GitHubClientTest {

    private GitHubClient client;

    @Before
    public void setUp() throws Exception {
        client = new GitHubClient();
    }

    @Test
    @Ignore
    public void testGetCommitsSince() throws JSONException, IOException {
        Artifact current = new Artifact();
        current.setId("idp-das");
        current.setVersion("2.0.0");
        Artifact latest = null;
        Set<Commit> commits = client.getCommitHistory(current, latest);
        for (Commit commit : commits) {
            System.out.println(commit.getJiras());
        }
    }

    @Test
    public void testNormalizeJira_SeparatedBySpace() throws Exception {
        assertEquals("IDPANVIL-20", Whitebox.invokeMethod(client, "normalizeJira", "Idpanvil 20"));
    }

    @Test
    public void testNormalizeJira_MissingSeparator() throws Exception {
        assertEquals("IDPANVIL-20", Whitebox.invokeMethod(client, "normalizeJira", "Idpanvil20"));
    }

    @Test
    public void testNormalizeJira_SeparatorInWrongPlace() throws Exception {
        assertEquals("IDPANVIL-20", Whitebox.invokeMethod(client, "normalizeJira", "Idpa-nvil20"));
        assertEquals("IDPANVIL-20", Whitebox.invokeMethod(client, "normalizeJira", "Idpanvil2-0"));
        assertEquals("IDPANVIL-20",
                Whitebox.invokeMethod(client, "normalizeJira", "-I-d-p-a-n-v-i-l-2-0-"));
    }

}
