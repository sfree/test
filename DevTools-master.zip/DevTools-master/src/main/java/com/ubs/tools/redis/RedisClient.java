package com.ubs.tools.redis;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.PosixParser;

import com.ubs.idp.encrypt.Crypto;

import redis.clients.jedis.Jedis;

public class RedisClient {
	
	private static final String OPTION_HELP = "--help";
	private static final String OPTION_DELETE = "delete";
	private static final String OPTION_FILENAME = "fileName";
	private static final String OPTION_JOBPREFIX = "jobPrefix";
	private static final String OPTION_JOBCOUNT = "jobCount";
	private static final String OPTION_JOBSTARTCOUNT = "jobStartCount";
	private static final String OPTION_PASSWORD = "password";
	private static final String OPTION_HOST = "host";
	private static final String OPTION_PORT = "port";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Options options = new Options();
		
		byte[] bytesx01x0b = {0x01, 0x0b};
		String x01x0b = new String(bytesx01x0b);
		
		byte[] bytesx01x01 = {0x01, 0x01};
		String x01x01 = new String(bytesx01x01);

		byte[] bytesxee = {-0x11};
		String xee = new String(bytesxee);
		
        Option fileNameOpt = new Option(null, OPTION_FILENAME, true, "The file path to pass in the payload");
        fileNameOpt.setRequired(true);
		
        Option deleteOpt = new Option(null, OPTION_DELETE, true, "Pre-delete the keys");
        deleteOpt.setRequired(false);
		
        Option jobPrefixOpt = new Option(null, OPTION_JOBPREFIX, true, "Job prefix");
        jobPrefixOpt.setRequired(true);
		
        Option jobCountOpt = new Option(null, OPTION_JOBCOUNT, true, "Job count");
        jobCountOpt.setRequired(true);
		
        Option jobStartCountOpt = new Option(null, OPTION_JOBSTARTCOUNT, true, "Job start requests per job");
        jobPrefixOpt.setRequired(true);
		
        Option passwordOpt = new Option(null, OPTION_PASSWORD, true, "Authentication password");
        passwordOpt.setRequired(false);
		
        Option hostOpt = new Option(null, OPTION_HOST, true, "Redis host");
        hostOpt.setRequired(false);
		
        Option portOpt = new Option(null, OPTION_PORT, true, "TCP port");
        portOpt.setRequired(false);

        options.addOption(fileNameOpt);
        options.addOption(deleteOpt);
        options.addOption(jobPrefixOpt);
        options.addOption(jobCountOpt);
        options.addOption(jobStartCountOpt);
        options.addOption(passwordOpt);
        options.addOption(hostOpt);
        options.addOption(portOpt);

        printHelp(args, options);

        CommandLineParser clp = new PosixParser();
        CommandLine cmd = null;
        
        try {
            cmd = clp.parse(options, args);
        } catch (Exception e) {
        	System.err.println("Unexpected error: " + e.getMessage());
            printHelp(new String[] { OPTION_HELP }, options);
        }
        
		String fileName = cmd.getOptionValue(OPTION_FILENAME);
		Boolean doDelete = Boolean.parseBoolean(cmd.getOptionValue(OPTION_DELETE));
		
		String samplePayload = x01x0b + "contentType+application/x-java-object;type=java.io.File" +
				x01x01 +
				fileName + xee;
		
		String jobQueuePfx = cmd.getOptionValue(OPTION_JOBPREFIX);

		// Connecting to Redis on localhost
		
		String host = "localhost";
		int port = 6379;
		
		if (cmd.getOptionValue(OPTION_HOST) != null) {
			host = cmd.getOptionValue(OPTION_HOST);
		}
		
		if (cmd.getOptionValue(OPTION_PORT) != null) {
			port = Integer.parseInt(cmd.getOptionValue(OPTION_PORT));
		}
		
		System.out.println("Connecting to " + host + ":" + port + "...");

		Jedis jedis = new Jedis(host, port);
		
		// Add auth
		
		String password = cmd.getOptionValue(OPTION_PASSWORD);
		
		if (password != null) {
			jedis.auth(Crypto.decrypt(password));
		}
		
		int jobCount = Integer.parseInt(cmd.getOptionValue(OPTION_JOBCOUNT));
		int jobStartCount = Integer.parseInt(cmd.getOptionValue(OPTION_JOBSTARTCOUNT));
		
		// Pre-delete...

		if (doDelete) {
			System.out.println("Delete job queues...");
			for (int j = 1 ; j <= jobCount ; j++) {
				jedis.del(jobQueuePfx+j);
			}
		}

		// Push new data
		
		System.out.println("Populate job queues...");

		for (int j = 1 ; j <= jobCount ; j++) {
			for (int i = 0 ; i < jobStartCount ; i++) {
				jedis.lpush(jobQueuePfx+j, samplePayload);
			}
		}
		
		System.out.println("Done!");
	}

    private static void printHelp(String[] args, Options options) {
        for (int i = 0; i < args.length; i++) {
            if (OPTION_HELP.equals(args[i])) {
                HelpFormatter formatter = new HelpFormatter();
                formatter.printHelp(RedisClient.class.getSimpleName(), options);
                System.exit(0);
            }
        }
    }
}
