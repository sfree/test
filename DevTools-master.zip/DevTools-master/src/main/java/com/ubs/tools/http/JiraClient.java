package com.ubs.tools.http;

import java.io.IOException;
import java.security.cert.CertificateException;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JiraClient {

	private static final Logger LOG = LoggerFactory.getLogger(JiraClient.class);

	private static final String JIRA_HOST = "xldn3513vdap.ldn.swissbank.com";

	private static final int JIRA_PORT = 8081;

	// Data IT JIRA - Supported by #ClientDataIT_JIRA_Support
	private static final String JIRA_SUMMARY_URL = "http://" + JIRA_HOST + ":" + JIRA_PORT
			+ "/jira/rest/api/2/issue/%s?fields=summary";

	private static final String AUTH_BASIC_HEADER = "Basic aHVuemlrZGU6amlyYXIwY2tz";

	private final HttpClient httpClient;

	public JiraClient() throws CertificateException, IOException {
		httpClient = HttpClientFactory.createBasicHttpClient();
	}

	public String getSummary(String key) throws JSONException, IOException {
		String uri = String.format(JIRA_SUMMARY_URL, key);
		JSONObject response = new JSONObject(invoke(uri));
		try {
			return response.getJSONObject("fields").getString("summary");
		} catch (JSONException e) {
			LOG.error("Response is missing fields/summary: {}", response.toString());
			return "";
		}
	}

	private String invoke(String uri) throws IOException {
		HttpGet get = new HttpGet(uri);
		get.addHeader("Authorization", AUTH_BASIC_HEADER);
		HttpResponse response = httpClient.execute(get);
		return EntityUtils.toString(response.getEntity());
	}

	public static void main(String[] args) throws JSONException, IOException, CertificateException {
		System.out.println(Base64.encodeBase64String("hunzikde:*****".getBytes()));
		JiraClient client = new JiraClient();
		System.out.println(client.getSummary("IDPC-74"));
	}

}
