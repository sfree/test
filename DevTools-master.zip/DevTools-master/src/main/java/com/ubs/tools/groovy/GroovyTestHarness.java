package com.ubs.tools.groovy;

import groovy.lang.GroovyShell;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintStream;
import java.io.Writer;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.log4j.Appender;
import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;

public class GroovyTestHarness extends JDialog {

    private static final long serialVersionUID = 1L;
    
    private final JPanel contentPanel = new JPanel();
	private JTextArea txtOutput;
	private JSplitPane splitPane;
	private JTextArea txtGroovy;
	
	private Logger log = null;
	private File lastDir = null;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            GroovyTestHarness dialog = new GroovyTestHarness();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);
            
            dialog.initLogger();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Capture root logger into text pane
     */
    public void initLogger() {
        log = Logger.getRootLogger();
        
        Appender newAppender = new OutputAppender();
        
        log.setAdditivity(false);
        
        log.addAppender(newAppender);

    }
    
    /**
     * Create the dialog.
     */
    public GroovyTestHarness() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                closeApp();
            }
        });
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setTitle("Groovy Test Harness");
        setBounds(100, 100, 675, 548);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(new BorderLayout(0, 0));
        {
            splitPane = new JSplitPane();
            splitPane.setResizeWeight(0.5);
            splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
            contentPanel.add(splitPane, BorderLayout.CENTER);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setViewportBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
                splitPane.setRightComponent(scrollPane);
                {
                    txtOutput = new JTextArea();
                    scrollPane.setViewportView(txtOutput);
                }
                {
                    JLabel lblOutput = new JLabel("Output:");
                    scrollPane.setColumnHeaderView(lblOutput);
                }
            }
            {
                JPanel panel = new JPanel();
                splitPane.setLeftComponent(panel);
                panel.setLayout(new BorderLayout(0, 0));
                {
                    {
                        JScrollPane scrollPane = new JScrollPane();
                        scrollPane.setViewportBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
                        panel.add(scrollPane, BorderLayout.CENTER);
                        {
                            txtGroovy = new JTextArea();
                            scrollPane.setViewportView(txtGroovy);
                        }
                        {
                            JLabel lblGroovyScript = new JLabel("Groovy Script:");
                            scrollPane.setColumnHeaderView(lblGroovyScript);
                        }
                    }
                }
                {
                    JPanel panel_1 = new JPanel();
                    panel.add(panel_1, BorderLayout.SOUTH);
                    panel_1.setLayout(new FlowLayout(FlowLayout.RIGHT, 0, 5));
                    {
                        JButton btnLoad = new JButton("Load...");
                        btnLoad.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                loadFile();
                            }
                        });
                        panel_1.add(btnLoad);
                    }
                    {
                        JButton btnSave = new JButton("Save...");
                        btnSave.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                saveFile();
                            }
                        });
                        panel_1.add(btnSave);
                    }
                    JButton btnRun = new JButton("Run...");
                    panel_1.add(btnRun);
                    btnRun.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            runGroovyScript();
                        }
                    });
                }
            }
        }
        {
            JPanel buttonPane = new JPanel();
            buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
            getContentPane().add(buttonPane, BorderLayout.SOUTH);
            {
                JButton cancelButton = new JButton("Exit");
                cancelButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        closeApp();
                    }
                });
                cancelButton.setActionCommand("Cancel");
                buttonPane.add(cancelButton);
            }
        }
    }

    private void closeApp() {
        this.dispose();
        System.exit(0);
    }
    
    private void runGroovyScript() {
        try {
            String groovyScript = txtGroovy.getText();
            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
            
            GroovyShell shell = new GroovyShell();
                        
            PrintStream out = new PrintStream(outStream);

            shell.setProperty("log", log);
            shell.setProperty("out", out);
            
            // Run the script
            
            shell.evaluate(groovyScript);
            
            outputMessage(outStream.toString());
            
        } catch(Exception ex) {
            outputMessage(ex.getMessage());
        }
    }
    
    private void outputMessage(String message) {
        String text = txtOutput.getText();
        
        text += message + "\n";
        
        txtOutput.setText(text);
    }
    
    public class OutputAppender extends AppenderSkeleton {

        @Override
        protected void append(LoggingEvent ev) {
            outputMessage(ev.getMessage().toString());
        }

        @Override
        public void close() {
            // TODO Auto-generated method stub
            
        }

        @Override
        public boolean requiresLayout() {
            // TODO Auto-generated method stub
            return false;
        }

    }
    
    public void loadFile() {
        JFileChooser chooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Groovy Scripts", "groovy");
        chooser.addChoosableFileFilter(filter);
        
        if (lastDir == null) {
            lastDir = new File(".");
        }
        
        chooser.setCurrentDirectory(lastDir);
        
        int ret = chooser.showDialog(null, "Open file");

        if (ret == JFileChooser.APPROVE_OPTION) {
          File file = chooser.getSelectedFile();
          
          lastDir = file.getParentFile();
          
          // Read it in
          
          try {
              BufferedReader br = new BufferedReader(new FileReader(file));
              try {
                  StringBuilder sb = new StringBuilder();
                  String line = br.readLine();

                  while (line != null) {
                      sb.append(line);
                      sb.append(System.lineSeparator());
                      line = br.readLine();
                  }
                  String groovyScript = sb.toString();
                  
                  txtGroovy.setText(groovyScript);
              } finally {
                  br.close();
              }
          } catch(Exception ex) {
              outputMessage(ex.getMessage());
          }
        }
    }
    
    public void saveFile() {
        JFileChooser chooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Groovy Scripts", "groovy");
        chooser.addChoosableFileFilter(filter);
        
        if (lastDir == null) {
            lastDir = new File(".");
        }
        
        chooser.setCurrentDirectory(lastDir);
        
        int ret = chooser.showDialog(null, "Open file");

	    if (ret == JFileChooser.APPROVE_OPTION) {
	      File file = chooser.getSelectedFile();
	      
	      lastDir = file.getParentFile();
	      
	      // Write it out
	      
	      try {
		      Writer out = new FileWriter(file);
		      try {
                  out.write(txtGroovy.getText());
              } finally {
                  out.close();
              }
          } catch(Exception ex) {
              outputMessage(ex.getMessage());
          }
        }
    }
}