package com.ubs.tools.releases.model;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

public class Artifact {

	@XStreamAsAttribute
	private String id;

	@XStreamAsAttribute
	private String repository;

	@XStreamAsAttribute
	private String version;

	@XStreamAsAttribute
	private boolean deployable;

	@XStreamImplicit(itemFieldName = "dependency")
	private List<Dependency> dependencies;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRepository() {
		return repository;
	}

	public void setRepository(String repository) {
		this.repository = repository;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public boolean isDeployable() {
		return deployable;
	}

	public void setDeployable(boolean deployable) {
		this.deployable = deployable;
	}

	public List<Dependency> getDependencies() {
		return dependencies;
	}

	public void setDependencies(List<Dependency> dependencies) {
		this.dependencies = dependencies;
	}

}
