package com.ubs.tools.encoding;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.ubs.idp.base.utils.EncodingUtils;

public class FieldDecoder extends JDialog {

    private static final String ENCODED_STRING_PREFIX = "cb64:";
    
    private final JPanel contentPanel = new JPanel();
    private JTextField txtEncodedDataOrURL;
    private JTextField txtFieldList;
    private JTextField txtEncodedFieldList;
    private JLabel lblStatus;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        try {
            FieldDecoder dialog = new FieldDecoder();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Create the dialog.
     */
    public FieldDecoder() {
        setTitle("FieldListDecoder");
        setBounds(100, 100, 627, 168);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        GridBagLayout gbl_contentPanel = new GridBagLayout();
        gbl_contentPanel.columnWidths = new int[]{0, 0, 0, 0};
        gbl_contentPanel.rowHeights = new int[]{0, 0, 0, 0, 0};
        gbl_contentPanel.columnWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
        gbl_contentPanel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
        contentPanel.setLayout(gbl_contentPanel);
        {
            JLabel lblNewLabel = new JLabel("URL/Encoded Field List");
            GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
            gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
            gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
            gbc_lblNewLabel.gridx = 0;
            gbc_lblNewLabel.gridy = 0;
            contentPanel.add(lblNewLabel, gbc_lblNewLabel);
        }
        {
            txtEncodedDataOrURL = new JTextField();
            GridBagConstraints gbc_txtEncodedDataOrURL = new GridBagConstraints();
            gbc_txtEncodedDataOrURL.insets = new Insets(0, 0, 5, 5);
            gbc_txtEncodedDataOrURL.fill = GridBagConstraints.HORIZONTAL;
            gbc_txtEncodedDataOrURL.gridx = 1;
            gbc_txtEncodedDataOrURL.gridy = 0;
            contentPanel.add(txtEncodedDataOrURL, gbc_txtEncodedDataOrURL);
            txtEncodedDataOrURL.setColumns(10);
        }
        {
            JButton btnDecode = new JButton("Decode...");
            btnDecode.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    doDecode();
                }
            });
            GridBagConstraints gbc_btnDecode = new GridBagConstraints();
            gbc_btnDecode.insets = new Insets(0, 0, 5, 0);
            gbc_btnDecode.gridx = 2;
            gbc_btnDecode.gridy = 0;
            contentPanel.add(btnDecode, gbc_btnDecode);
        }
        {
            JLabel lblDecodedFieldList = new JLabel("Decoded Field List");
            GridBagConstraints gbc_lblDecodedFieldList = new GridBagConstraints();
            gbc_lblDecodedFieldList.insets = new Insets(0, 0, 5, 5);
            gbc_lblDecodedFieldList.anchor = GridBagConstraints.EAST;
            gbc_lblDecodedFieldList.gridx = 0;
            gbc_lblDecodedFieldList.gridy = 1;
            contentPanel.add(lblDecodedFieldList, gbc_lblDecodedFieldList);
        }
        {
            txtFieldList = new JTextField();
            GridBagConstraints gbc_txtFieldList = new GridBagConstraints();
            gbc_txtFieldList.insets = new Insets(0, 0, 5, 5);
            gbc_txtFieldList.fill = GridBagConstraints.HORIZONTAL;
            gbc_txtFieldList.gridx = 1;
            gbc_txtFieldList.gridy = 1;
            contentPanel.add(txtFieldList, gbc_txtFieldList);
            txtFieldList.setColumns(10);
        }
        {
            JButton btnEncode = new JButton("Encode...");
            btnEncode.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    doEncode();
                }
            });
            GridBagConstraints gbc_btnEncode = new GridBagConstraints();
            gbc_btnEncode.insets = new Insets(0, 0, 5, 0);
            gbc_btnEncode.gridx = 2;
            gbc_btnEncode.gridy = 1;
            contentPanel.add(btnEncode, gbc_btnEncode);
        }
        {
            JLabel lblEncodedFieldList = new JLabel("Encoded Field List");
            GridBagConstraints gbc_lblEncodedFieldList = new GridBagConstraints();
            gbc_lblEncodedFieldList.insets = new Insets(0, 0, 5, 5);
            gbc_lblEncodedFieldList.anchor = GridBagConstraints.EAST;
            gbc_lblEncodedFieldList.gridx = 0;
            gbc_lblEncodedFieldList.gridy = 2;
            contentPanel.add(lblEncodedFieldList, gbc_lblEncodedFieldList);
        }
        {
            txtEncodedFieldList = new JTextField();
            GridBagConstraints gbc_txtEncodedFieldList = new GridBagConstraints();
            gbc_txtEncodedFieldList.insets = new Insets(0, 0, 5, 5);
            gbc_txtEncodedFieldList.fill = GridBagConstraints.HORIZONTAL;
            gbc_txtEncodedFieldList.gridx = 1;
            gbc_txtEncodedFieldList.gridy = 2;
            contentPanel.add(txtEncodedFieldList, gbc_txtEncodedFieldList);
            txtEncodedFieldList.setColumns(10);
        }
        {
            JLabel lblStatusLabel = new JLabel("Status:");
            GridBagConstraints gbc_lblStatusLabel = new GridBagConstraints();
            gbc_lblStatusLabel.anchor = GridBagConstraints.EAST;
            gbc_lblStatusLabel.insets = new Insets(0, 0, 0, 5);
            gbc_lblStatusLabel.gridx = 0;
            gbc_lblStatusLabel.gridy = 3;
            contentPanel.add(lblStatusLabel, gbc_lblStatusLabel);
        }
        {
            lblStatus = new JLabel("");
            GridBagConstraints gbc_lblStatus = new GridBagConstraints();
            gbc_lblStatus.anchor = GridBagConstraints.WEST;
            gbc_lblStatus.insets = new Insets(0, 0, 0, 5);
            gbc_lblStatus.gridx = 1;
            gbc_lblStatus.gridy = 3;
            contentPanel.add(lblStatus, gbc_lblStatus);
        }
        {
            JPanel buttonPane = new JPanel();
            buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
            getContentPane().add(buttonPane, BorderLayout.SOUTH);
            {
                JButton btnClose = new JButton("Close");
                btnClose.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        closeApp();
                    }
                });
                btnClose.setActionCommand("Cancel");
                buttonPane.add(btnClose);
            }
        }
    }

    private void doDecode() {
        status("");
        
        String encodedData = txtEncodedDataOrURL.getText();
        
        if (encodedData == null || encodedData.length() == 0) {
            status("No input data?");
            return;
        }
        
        int startPos = encodedData.indexOf(ENCODED_STRING_PREFIX);
        
        if (startPos < 0) {
            status("Invalid input data? (no '" + ENCODED_STRING_PREFIX + "' in string?)");
            return;
        }
        
        encodedData = encodedData.substring(encodedData.indexOf(ENCODED_STRING_PREFIX));
        
        try {
            String res = EncodingUtils.uncompressAndDecode(encodedData);
            
            txtFieldList.setText(res);
            
            int fieldCount = res.split(",").length;
            
            status("OK, " + fieldCount + " fields decoded");
        } catch (Exception e) {
            status(e.getMessage());
        }
    }
    
    private void doEncode() {
        String fieldList = txtFieldList.getText();
        
        try {
            String res = EncodingUtils.compressAndEncode(fieldList);
            
            txtEncodedFieldList.setText(res);
        } catch (Exception e) {
            status(e.getMessage());
        }
    }
    
    private void closeApp() {
        this.dispose();
        System.exit(0);
    }
    
    private void status(String msg) {
        lblStatus.setText(msg);
    }
}
