package com.ubs.tools.releases;

import java.io.IOException;
import java.security.cert.CertificateException;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.json.JSONException;

import com.google.common.collect.ArrayListMultimap;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import com.ubs.tools.http.GitHubClient;
import com.ubs.tools.http.GitHubClient.Commit;
import com.ubs.tools.http.JiraClient;
import com.ubs.tools.releases.model.Artifact;
import com.ubs.tools.releases.model.Release;

public class ReleaseInfo {

    private static final String JIRA_BASE_URL = "http://xldn3513vdap.ldn.swissbank.com:8081/jira/browse/";

    private static final String WIKI_LINK = "[%s|%s]";

    public static void main(String[] args) throws JSONException, CertificateException, IOException {
        XStream xstream = new XStream(new DomDriver());
        xstream.processAnnotations(Release.class);
        Release currentRelease = (Release) xstream
                .fromXML(ReleaseInfo.class.getClassLoader().getResource(
                        String.format("releases/%s.xml", System.getProperty("currentRelease"))));

        String newReleaseVersion = System.getProperty("newRelease", "NA");
        Release newRelease = null;

        if (!newReleaseVersion.equals("NA")) {
            newRelease = (Release) xstream.fromXML(ReleaseInfo.class.getClassLoader().getResource(
                    String.format("releases/%s.xml", newReleaseVersion)));
        }

        System.out.println("|| Artifact || Last Commit || Ticket || Summary ||");
        GitHubClient gitHubClient = new GitHubClient();
        JiraClient jiraClient = new JiraClient();

        for (Artifact artifact : currentRelease.getArtifacts()) {
            Set<Commit> commits = gitHubClient.getCommitHistory(artifact,
                    findArtifact(newRelease, artifact.getId()));

            ArrayListMultimap<String, Commit> commitsByJira = ArrayListMultimap.create();

            for (Commit commit : commits) {
                List<String> jiras = commit.getJiras();
                if (jiras.size() > 0 && !commit.getMessage().startsWith("Merge ")) {
                    for (String jira : jiras) {
                        commitsByJira.put(jira, commit);
                    }
                }
            }

            for (String jira : commitsByJira.keySet()) {
                System.out.println(createRow(jiraClient, jira, artifact, commitsByJira.get(jira)
                        .get(0)));
            }
        }
    }

    private static Artifact findArtifact(Release release, String id) {
        if (release == null) {
            return null;
        }
        for (Artifact artifact : release.getArtifacts()) {
            if (artifact.getId().equals(id)
                    || (artifact.getRepository() != null && artifact.getRepository().equals(id))) {
                return artifact;
            }
        }
        return null;
    }

    private static String createRow(JiraClient jiraClient, String jira, Artifact artifact,
            Commit commit) throws JSONException, IOException {
        StringBuilder message = new StringBuilder();
        message.append("| ");
        message.append(artifact.getId());
        message.append(" | ");
        message.append(commit.getDate().toString("dd/MM/yyyy hh:mm:SS", Locale.UK));
        message.append(" | ");
        message.append(String.format(WIKI_LINK, jira, JIRA_BASE_URL + jira));
        message.append(" | ");
        String summary = jiraClient.getSummary(jira).replaceAll("\\|", "-");
        if (summary.length() > 0) {
            message.append(summary);
        } else {
            message.append("*** INVALID TICKET *** - " + commit.getMessage());
        }
        message.append(" |");
        return message.toString();
    }

}
