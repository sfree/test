package com.ubs.tools.releases;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Helper script that displays the last version of a pom for the specified
 * project directory  
 * @author loverids
 *
 */
public class MavenPomReader
{
	public final static String SNAPSHOT_SUFFIX = "-SNAPSHOT";
	
	public final static String VERSION_TAG = "<version>";
	
	public final static String VERSION_CLOSE_TAG = "</version>";
	
	
	public final static void main(String[] args ) throws IOException
	{
		String currentVersion = extractCurrentPomVersionFromRepo(args[0]);
		String lastVersion = getPreviousPomVersion( currentVersion );
		System.out.println( lastVersion );
		System.exit(0);
	}
	
	
	private static String extractCurrentPomVersionFromRepo( String repoDir )
	{
		File pom = new File(  repoDir + File.separator + "pom.xml");
		if( !pom.exists() )
		{
			throw new RuntimeException("Could not find pom.xml for repo " + repoDir + "! Did it get cloned correctly?!");
		}
		
		return extractVersionFromPomFile( pom );
	}
	
	private static String extractVersionFromPomFile( File pomFile ) 
	{
		String version = "";
		
		try(BufferedReader br = new BufferedReader( new InputStreamReader( new FileInputStream(pomFile ) ) );)
		{	
			boolean inParent = false;
			String line = "";
			while( (line = br.readLine()) != null )
			{
				if( line.trim().startsWith("<parent>") )
				{
					inParent = true;
				}
				if( line.trim().startsWith("</parent>") )
				{
					inParent = false;
				}
				
				if( !inParent && line.trim().startsWith(VERSION_TAG) )
				{
					version = line.substring(line.indexOf(VERSION_TAG) + VERSION_TAG.length(),line.indexOf(VERSION_CLOSE_TAG) );
					return version;
				}
			}
		}
		catch( Exception e )
		{
			throw new RuntimeException("The following error occurred extracting version from pom file " + pomFile + ":" + e,e);	
		}
		throw new RuntimeException("Failed to find " + VERSION_TAG + " tag in pom file " + pomFile + "!?");
	}
	
	private static String getPreviousPomVersion(String currentVersion )
	{
		String lastVersion = "";
		if( !currentVersion.endsWith(SNAPSHOT_SUFFIX) )
		{
			throw new RuntimeException("Pom must be at a SNAPHOT version. Pom version=" + currentVersion);	
		}
		
		lastVersion = currentVersion.substring(currentVersion.lastIndexOf(".")+1,currentVersion.indexOf(SNAPSHOT_SUFFIX));
		int lastVersionNumber = Integer.parseInt(lastVersion) - 1;
		
		lastVersion = currentVersion.substring(0,currentVersion.lastIndexOf(".")+1) + lastVersionNumber; 
		
		
		return lastVersion;
	}

	public static String getNextPomVersion(String currentVersion )
	{
		String nextVersion = "";
		
		nextVersion = currentVersion.substring(currentVersion.lastIndexOf(".")+1);
		int lastVersionNumber = Integer.parseInt(nextVersion) + 1;
		
		nextVersion = currentVersion.substring(0,currentVersion.lastIndexOf(".")+1) + lastVersionNumber; 
		
		
		return nextVersion;
	}

}
