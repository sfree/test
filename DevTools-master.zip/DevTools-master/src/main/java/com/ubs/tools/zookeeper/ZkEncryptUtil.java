package com.ubs.tools.zookeeper;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;

import org.apache.zookeeper.server.auth.DigestAuthenticationProvider;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.security.NoSuchAlgorithmException;

public class ZkEncryptUtil extends JDialog {

    private final JPanel contentPanel = new JPanel();
    private JTextField txtUserName;
    private JTextField txtPassword;
    private JTextField txtEncryptedResult;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        try {
            ZkEncryptUtil dialog = new ZkEncryptUtil();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Create the dialog.
     */
    public ZkEncryptUtil() {
        setBounds(100, 100, 450, 202);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        GridBagLayout gbl_contentPanel = new GridBagLayout();
        gbl_contentPanel.columnWidths = new int[] { 100, 300, 0 };
        gbl_contentPanel.rowHeights = new int[] { 32, 32, 32, 32, 0 };
        gbl_contentPanel.columnWeights = new double[] { 0.0, 1.0, Double.MIN_VALUE };
        gbl_contentPanel.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
        contentPanel.setLayout(gbl_contentPanel);
        {
            JLabel lblUserId = new JLabel("User Name");
            GridBagConstraints gbc_lblUserId = new GridBagConstraints();
            gbc_lblUserId.anchor = GridBagConstraints.EAST;
            gbc_lblUserId.insets = new Insets(0, 0, 5, 5);
            gbc_lblUserId.gridx = 0;
            gbc_lblUserId.gridy = 0;
            contentPanel.add(lblUserId, gbc_lblUserId);
        }
        {
            txtUserName = new JTextField();
            GridBagConstraints gbc_txtUserName = new GridBagConstraints();
            gbc_txtUserName.insets = new Insets(0, 0, 5, 0);
            gbc_txtUserName.fill = GridBagConstraints.HORIZONTAL;
            gbc_txtUserName.gridx = 1;
            gbc_txtUserName.gridy = 0;
            contentPanel.add(txtUserName, gbc_txtUserName);
            txtUserName.setColumns(10);
        }
        {
            JLabel lblPassword = new JLabel("Password");
            GridBagConstraints gbc_lblPassword = new GridBagConstraints();
            gbc_lblPassword.anchor = GridBagConstraints.EAST;
            gbc_lblPassword.insets = new Insets(0, 0, 5, 5);
            gbc_lblPassword.gridx = 0;
            gbc_lblPassword.gridy = 1;
            contentPanel.add(lblPassword, gbc_lblPassword);
        }
        {
            txtPassword = new JTextField();
            GridBagConstraints gbc_txtPassword = new GridBagConstraints();
            gbc_txtPassword.insets = new Insets(0, 0, 5, 0);
            gbc_txtPassword.fill = GridBagConstraints.HORIZONTAL;
            gbc_txtPassword.gridx = 1;
            gbc_txtPassword.gridy = 1;
            contentPanel.add(txtPassword, gbc_txtPassword);
            txtPassword.setColumns(10);
        }
        {
            JButton btnEncrypt = new JButton("Encrypt");
            btnEncrypt.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    doEncrypt();
                }
            });
            GridBagConstraints gbc_btnEncrypt = new GridBagConstraints();
            gbc_btnEncrypt.insets = new Insets(0, 0, 5, 0);
            gbc_btnEncrypt.gridx = 1;
            gbc_btnEncrypt.gridy = 2;
            contentPanel.add(btnEncrypt, gbc_btnEncrypt);
        }
        {
            JLabel lblResult = new JLabel("Result");
            GridBagConstraints gbc_lblResult = new GridBagConstraints();
            gbc_lblResult.insets = new Insets(0, 0, 0, 5);
            gbc_lblResult.anchor = GridBagConstraints.EAST;
            gbc_lblResult.gridx = 0;
            gbc_lblResult.gridy = 3;
            contentPanel.add(lblResult, gbc_lblResult);
        }
        {
            txtEncryptedResult = new JTextField();
            GridBagConstraints gbc_txtEncryptedResult = new GridBagConstraints();
            gbc_txtEncryptedResult.fill = GridBagConstraints.HORIZONTAL;
            gbc_txtEncryptedResult.gridx = 1;
            gbc_txtEncryptedResult.gridy = 3;
            contentPanel.add(txtEncryptedResult, gbc_txtEncryptedResult);
            txtEncryptedResult.setColumns(10);
        }
        {
            JPanel buttonPane = new JPanel();
            buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
            getContentPane().add(buttonPane, BorderLayout.SOUTH);
            {
                JButton btnDone = new JButton("Done");
                btnDone.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        doExit();
                    }
                });
                btnDone.setActionCommand("OK");
                buttonPane.add(btnDone);
                getRootPane().setDefaultButton(btnDone);
            }
        }
    }

    private void doEncrypt() {
        String plainTextValue = txtUserName.getText() + ":" + txtPassword.getText();
        String res;
        try {
            res = DigestAuthenticationProvider.generateDigest(plainTextValue);
            txtEncryptedResult.setText(res);
        } catch (NoSuchAlgorithmException e) {
            txtEncryptedResult.setText(e.getMessage());
            e.printStackTrace();
        }
    }

    private void doExit() {
        this.dispose();
        System.exit(0);
    }
}
