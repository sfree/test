package com.ubs.tools.http;

import java.io.InputStream;
import java.security.KeyStore;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HttpClientFactory {

	private static final Logger LOG = LoggerFactory.getLogger(HttpClientFactory.class);

	private static final String KEYSTORE_LOCATION = "/dsws-client-certs.dat";

	private static final String KEYSTORE_PASSWORD = "changeit";

	private static final String SSO_USERNAME = "sso_idp";

	private static final String SSO_PASSWORD = "sn2gbF57nzz1";

	private static final String RCAS_ENDPOINT_URL = "https://rcas.smlogin.ibb.ubstest.net/loginrouter/rcas_v1_50";

	private static final String RCAS_AUTH_APPGUID = "RCAS_IDP";

	public static final HttpClient createHttpsClient(boolean authEnabled, boolean httpsEnabled,
			String host, String username, String password) {
		HttpClient httpClient = null;

		try {
			HttpClientBuilder builder = HttpClients.custom().setDefaultRequestConfig(
					getRequestConfig());
			if (httpsEnabled) {
				builder = builder.setSSLSocketFactory(getSslSocketFactory());
			}
			if (authEnabled) {
				builder = builder.setDefaultCredentialsProvider(getCredentialProvider(host,
						username, password));
			}
			httpClient = builder.build();
		} catch (Exception e) {
			LOG.error("Failed to create HTTP client", e);
		}

		return httpClient;
	}

	public static final HttpClient createBasicHttpClient() {
		return createHttpsClient(false, false, null, null, null);
	}

	public static final HttpClient createHttpsClient() {
		return createHttpsClient(false, true, null, null, null);
	}

	public static final HttpClient createAuthenticatedHttpsClient() {
		HttpClient httpClient = createHttpsClient(true, true, "rcas.smlogin.ibb.ubstest.net",
				SSO_USERNAME, SSO_PASSWORD);

		// --------------------------------------------------------------------
		// Make RCAS authentication call
		// --------------------------------------------------------------------
		try {
			HttpGet initialGet = new HttpGet(RCAS_ENDPOINT_URL + "?appid=" + RCAS_AUTH_APPGUID);
			HttpResponse response = httpClient.execute(initialGet);

			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode != HttpStatus.SC_OK) {
				throw new RuntimeException(String.format("HTTP status code: %d, reason: %s",
						statusCode, response.getStatusLine().getReasonPhrase()));
			}

			HttpEntity entity = response.getEntity();
			if (entity == null) {
				throw new RuntimeException("Response entity is empty");
			}
			EntityUtils.consumeQuietly(entity);
		} catch (Exception e) {
			LOG.error("Failed to authenticate against WebSSO", e);
		}
		return httpClient;
	}

	private static SSLConnectionSocketFactory getSslSocketFactory() throws Exception {
		KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
		try (InputStream inputStream = HttpClientFactory.class
				.getResourceAsStream(KEYSTORE_LOCATION)) {
			trustStore.load(inputStream, KEYSTORE_PASSWORD.toCharArray());
		}
		SSLContext sslcontext = SSLContexts.custom()
				.loadTrustMaterial(trustStore, new TrustSelfSignedStrategy()).build();
		return new SSLConnectionSocketFactory(sslcontext);
	}

	private static RequestConfig getRequestConfig() {
		return RequestConfig.custom().setAuthenticationEnabled(true).setRedirectsEnabled(true)
				.setCircularRedirectsAllowed(true).setCookieSpec(CookieSpecs.BROWSER_COMPATIBILITY)
				.build();
	}

	private static CredentialsProvider getCredentialProvider(String host, String username,
			String password) {
		HttpHost target = new HttpHost(host, AuthScope.ANY_PORT);
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(new AuthScope(target.getHostName(), target.getPort()),
				new UsernamePasswordCredentials(username, password));
		return credsProvider;
	}

}
