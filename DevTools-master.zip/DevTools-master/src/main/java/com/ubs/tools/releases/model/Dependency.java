package com.ubs.tools.releases.model;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

public class Dependency {

	@XStreamAsAttribute
	private String ref;

	public String getRef() {
		return ref;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}

}
