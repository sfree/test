package com.ubs.tools.metadata;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.neo4j.support.Neo4jTemplate;
import org.springframework.stereotype.Component;

import com.ubs.idp.metadata.client.MetadataService;
import com.ubs.idp.metadata.client.Neo4jUtils;
import com.ubs.idp.metadata.client.properties.MetadataServiceZookeeperDecorator;
import com.ubs.idp.metadata.model.JoinRelation;
import com.ubs.idp.metadata.model.PhysicalAttribute;
import com.ubs.idp.metadata.model.PhysicalDataset;
import com.ubs.idp.metadata.model.RulesTransformer;
//import com.ubs.idp.metadata.repositories.PhysicalDatasetRepository;
//import com.ubs.idp.metadata.repositories.ViewRepository;


@Component
@PropertySource("neo4j.properties")
@ComponentScan({"com.ubs.idp.metadata.client"})
public class MetadataQueryTool
{
    private static final String ENVIRONMENT = "environment";

	public final static String APPLICATION_CONTEXT = "neo4jRemoteContext.xml";

    @Autowired
    @Qualifier("mdsClient")
    MetadataService mds;
    
    @Autowired
    Neo4jUtils neo4jUtils;
    
    @Autowired
    Neo4jTemplate template;

//    @Autowired
//    PhysicalDatasetRepository physicalDatasetRepo;

//    @Autowired
//    ViewRepository viewRepo;

//    private void deleteEntityAndAttributes(String datasetId)
//    {
//    	PhysicalDataset pd = physicalDatasetRepo.findOneById(datasetId);
//    	for( PhysicalAttribute attr : pd.attributes )
//    	{
//    		template.delete(attr);
//    	}
//    	template.delete( pd.getIncomingTransformer() );
//    	template.delete(pd);    	
//    }
    
//    private void fixDSCurrency()
//    {
//    	List<String> attributeNames = Arrays.asList("issue.ubsId","tL.countryUbsId"); 
//
//    	
//    	// Remove the attrubtes from the SOURCE DSCURRENCY
//    	PhysicalDataset pd = physicalDatasetRepo.findOneById("DSCURRENCY");
//    	for( PhysicalAttribute attr : pd.attributes )
//    	{
//    		if(attributeNames.contains( attr.id) )
//    		{
//        		template.delete(attr);    		
//    		}
//    	}    	
//
//    	// Add the rule to create negative sequences    	
//    	RulesTransformer rt = (RulesTransformer)pd.getOutgoingTransformer();
//    	if( !rt.ruleset.contains("NegativeSequenceRule") )
//    	{
//	    	rt.ruleset = rt.ruleset + ",com.ubs.idp.orchestrator.processor.rules.NegativeSequenceRule"; 
//	    	template.save(rt);
//    	}
//    	
//    	// Add the negative sequence attributes to the view
//    	String cypherCommand = "MATCH (v:View {id:'InstrumentSecFunding'}) MATCH (pa:PhysicalAttribute {id:'issue.ubsId'})<-[:OWNS]-(pd:PhysicalDataset {id:'DSCURRENCY.IDP'}) CREATE (v)-[:SELECTS {viewAttributeName:'issue.ubsId',position:7}]->(pa);";
//    	neo4jUtils.executeCyperCommand(cypherCommand);
//    	
//    	cypherCommand = "MATCH (v:View {id:'InstrumentSecFunding'}) MATCH (pa:PhysicalAttribute {id:'tL.countryUbsId'})<-[:OWNS]-(pd:PhysicalDataset {id:'DSCURRENCY.IDP'}) CREATE (v)-[:SELECTS {viewAttributeName:'tL.countryUbsId',position:10}]->(pa);";
//    	neo4jUtils.executeCyperCommand(cypherCommand);
//    	
//    }
    
    private void dumpDatasetAttributePositionsForMock( String[] datasets )
    {
    	for( String ds : datasets )
    	{
    		String line = "when(metadataService.getAttributePositionsForDataset(\"" + ds  + "\")).thenReturn(new HashMap<String,Integer>(){{";
    		Map<String,Integer> map = mds.getAttributePositionsForDataset(ds);
    		Iterator<String> keys = map.keySet().iterator();
    		while( keys.hasNext() )
    		{
    			String key = keys.next();
    			line += "put(\"" + key + "\"," + map.get(key) + ");";
    		}
    		line += "}});";
    		System.out.println(line);
    	}

    }

    private void dumpDatasetKeyAttributePositionsForMock( String[] datasets )
    {
    	for( String ds : datasets )
    	{
    		String line = "when(metadataService.getDatasetKeyAttributePositions(\"" + ds  + "\")).thenReturn(Arrays.asList(";
    		List<Integer> map = mds.getDatasetKeyAttributePositions(ds);
    		String mapStr = map.toString();
    		mapStr = mapStr.substring(1, mapStr.length()- 1 );
    		
    		line += mapStr + "));";
    		System.out.println(line);
    	}

    }

    private void dumpDatasetAttributeNamesForMock( String[] datasets )
    {
    	for( String ds : datasets )
    	{
    		String line = "when(metadataService.getAttributeNamesForDataset(\"" + ds  + "\")).thenReturn(Arrays.asList(";
    		List<String> names = mds.getAttributeNamesForDataset(ds);
    		
    		for( String name : names )
    		{
    			line += "\"" + name + "\",";
    		}
    		line = line.substring(0,line.length()-1);
    		
    		line += "));";
    		System.out.println(line);
    	}

    }

    private void dumpDatasetQueryableAttributePositionsForMock( String[] datasets )
    {
    	for( String ds : datasets )
    	{
    		String line = "when(metadataService.getQueryableAttributePositionsForDataset(\"" + ds  + "\")).thenReturn(Arrays.asList(";
    		List<Integer> map = mds.getQueryableAttributePositionsForDataset(ds);
    		String mapStr = map.toString();
    		mapStr = mapStr.substring(1, mapStr.length()- 1 );
    		
    		line += mapStr + "));";
    		System.out.println(line);
    	}

    }
    
    public void queryMetadata()
    {
        try
        {
        	System.out.println("EQUITY Auth URL=" +  mds.getSourceAuthenticationUriForDataset("EQUITY") );

        	//String[] datasets = new String[]{"RTIM","FFEQUITYISSUE","FFBONDISSUE","FFSTRUCTUREDPRODUCTISSUE","FFWARRANTISSUE","FFEQUITYINDEXTL","EQPRICING","CONVERTIBLES"};        	
        	String[] datasets = new String[]{"MTS.IDP"};
        	
        	dumpDatasetAttributePositionsForMock(datasets);
        	dumpDatasetKeyAttributePositionsForMock(datasets);
        	dumpDatasetAttributeNamesForMock(datasets);
        	dumpDatasetQueryableAttributePositionsForMock(datasets);
        	
        	System.out.println("InstrSecFunding=" + mds.getJoinRelationsForView("InstrumentSecFunding"));
        	
        	for( JoinRelation jr : mds.getJoinRelationsForView("InstrumentSecFunding") )
        	{
        		for( PhysicalDataset pd : jr.getOrderedDatasets() )
        		{
        			System.out.println("Pd=" + pd );
        		}
        	}
        	
        	
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public final static void main(String[] args) throws Exception
    {
    	if (System.getProperty(ENVIRONMENT) == null) {
    		System.out.println("Defaulting to TEST-ENV settings...");
    		System.setProperty(ENVIRONMENT, "TEST-ENV");
    	}
    	
        ApplicationContext context = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT);
        MetadataQueryTool queryTool = context.getBean(MetadataQueryTool.class);

        queryTool.queryMetadata();
    }

}
