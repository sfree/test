package com.ubs.tools.releases;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tool to generate the release notes for all components based on 
 * the current status in Git
 * @author loverids
 *
 */
public class ReleaseNoteGenerator
{
	public final static String[] DEPLOYABLE_ARTIFACTS = {"idp-cassandra","idp-das","idp-neo4j","idp-spring-xd","idp-xd-modules","idp-health-check"};

	
	public final static void main(String[] args ) throws IOException
	{
		try(BufferedReader br = new BufferedReader( new InputStreamReader( new FileInputStream( args[0] ) ) );)
		{
			String line = "";
			String repo = null;
			String version = null;
			boolean startJiras = false;
			
			List<String> jiraCommentsForRelease = new ArrayList<String>();
			Map<String,String> jiraComments = new HashMap<String,String>();
			List<String> newJiras = new ArrayList<String>();
			List<String> changedRepos = new ArrayList<String>();
			Map<String,String> artifactVersions = new HashMap<String,String>();
			

			while((line = br.readLine()) != null )
			{				
				// Pickup the repo name
				if( line.contains("---") )
				{
					// Take the jiras from the last repo and add them to the overall list
					for( String newJira : newJiras )
					{
						jiraCommentsForRelease.add(jiraComments.get(newJira));
					}
					
					// If the last repo has new jiras added then we want to incremenet the version
					if( newJiras.size() > 0 )
					{
						version = MavenPomReader.getNextPomVersion(version);
						changedRepos.add( repo );
					}
					
					if( repo != null )
					{
						artifactVersions.put(repo,version);
					}
					
					repo = line.substring(line.indexOf("- ") + 2, line.indexOf(" -") ).trim();
					
					// Reset vers for new repo
					startJiras = false;
					jiraComments = new HashMap<String,String>();
					newJiras = new ArrayList<String>();
					version = null;
				}

				// Pickup the jiras
				if( line.contains("===") )
				{
					startJiras = true;
				}
				
				// If the line starts with a date, its a jira entry
				Pattern p = Pattern.compile("[0-9][0-9]:[0-9][0-9]:[0-9][0-9]");
				Matcher m = p.matcher(line);
				if( startJiras && m.find())
				{
					// Add all jira comments starting with IDP
					String jiraComment = line.substring(63).trim();
					if( jiraComment.startsWith("IDP") )
					{
						String id = jiraComment.substring(0,jiraComment.indexOf(" ")).trim();
						String comment = jiraComment.substring(jiraComment.indexOf(" ")).trim();
						
						jiraComments.put(id, comment);
					}
				}
				
				// Extract the version
				if( line.startsWith("All done for ") )
				{
					version = line.substring(line.indexOf("All done for ") + 13 ).trim();
				}
				
				
				// Add the new jiras
				if( version != null && line.trim().startsWith("IDP") )
				{
					newJiras.add( line.trim() );
				}				
			}
			
			
			// Take the jiras from the last repo and add them to the overall list
			for( String newJira : newJiras )
			{
				jiraCommentsForRelease.add(jiraComments.get(newJira));
			}
			
			// If the last repo has new jiras added then we want to incremenet the version
			if( newJiras.size() > 0 )
			{
				version = MavenPomReader.getNextPomVersion(version);
				changedRepos.add( repo );
			}
			
			if( repo != null )
			{
				artifactVersions.put(repo,version);
			}
			

			
			System.out.println("h3. +Release <ENTER RELEASE NUMBER>+");
			System.out.println("*Date:* <ENTER RELEASE DATE>");
			System.out.println("*Production deployment date:*");
			System.out.println("");
			System.out.println("h5. Deployable artifacts & versions");
			System.out.println("||artifact ||version|");
			for( String artifact : DEPLOYABLE_ARTIFACTS )
			{
				if( changedRepos.contains(artifact) )
				{
					System.out.println("|*"+ artifact +"*|*"+ artifactVersions.get(artifact) +"*|");
				}
				else
				{
					System.out.println("|"+ artifact +"|"+ artifactVersions.get(artifact) +"|");
				}
			}
			System.out.println("");
			System.out.println("Only artifacts in *bold* need to be deployed");
			System.out.println("");
			System.out.println("h5. Release note");
			for( String jira : jiraCommentsForRelease )
			{
				System.out.println(jira);
			}
		}
	}
	
}
