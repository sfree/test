package com.ubs.tools.http;

import static org.springframework.util.StringUtils.trimAllWhitespace;

import java.io.IOException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.util.EntityUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ubs.tools.releases.model.Artifact;

public class GitHubClient {

    // See whether this can be replaced or restricted
    private static final String OAUTH_TOKEN = "5e7758de33e11b6550870ad8562abf4e10670d8f";

    private static final String ACCESS_TOKEN_PARAM = "&access_token=" + OAUTH_TOKEN;

    private static final String COMMITS_URL = "https://github.ldn.swissbank.com/api/v3/repos/idp/%s/commits?page=%d&per_page=100"
            + ACCESS_TOKEN_PARAM;

    private static final Pattern JIRA_PATTERN = Pattern.compile("([iI][dD][pP]\\w*\\s?-?\\s?\\d+)");

    private static final String RELEASE_MESSAGE_PATTERN = ".*maven-release-plugin.*prepare.*%s-%s";

    private final HttpClient httpClient;

    private static final DateTimeFormatter DTF = DateTimeFormat
            .forPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");

    public GitHubClient() throws CertificateException, IOException {
        httpClient = HttpClientFactory.createHttpsClient();
    }

    private String invoke(String uri) throws IOException {
        HttpResponse response = httpClient.execute(new HttpGet(uri));
        return EntityUtils.toString(response.getEntity());
    }

    private Set<Commit> getCommits(String repo, int page) throws JSONException, IOException {
        Set<Commit> orderedCommits = new LinkedHashSet<>();

        String uri = String.format(COMMITS_URL, repo, page);
        JSONArray commitArray = new JSONArray(invoke(uri));

        for (int i = 0; i < commitArray.length(); i++) {
            JSONObject commit = commitArray.getJSONObject(i);
            JSONObject commitDetails = commit.getJSONObject("commit");
            JSONObject committer = commitDetails.getJSONObject("committer");

            List<String> messageLines = new ArrayList<>(Arrays.asList(commitDetails.getString(
                    "message").split("\\n")));

            for (Iterator<String> iter = messageLines.iterator(); iter.hasNext();) {
                String message = iter.next();
                if (message.startsWith("Merge") || StringUtils.isBlank(message)) {
                    iter.remove();
                }
            }

            String message = StringUtils.join(messageLines, ", ");
            Map<String, String> jiras = extractJiras(message);
            orderedCommits.add(new Commit(commit.getString("sha"), committer.getString("name"),
                    message, jiras, DTF.parseDateTime(committer.getString("date"))));
        }

        // We rely on GitHub returning the commits ordered by commit date descending
        return orderedCommits;
    }

    /**
     * Creates a mapping between the Jira issue name as it appears in the commit message and the
     * normalised version (IDP<XYZ>-<NO>).
     * 
     * @param message
     * @return
     */
    private Map<String, String> extractJiras(String message) {
        Map<String, String> jiras = new HashMap<>();
        Matcher matcher = JIRA_PATTERN.matcher(message);
        while (matcher.find()) {
            jiras.put(matcher.group(1), normalizeJira(matcher.group(1)));
        }
        return jiras;
    }

    private static String normalizeJira(String jira) {
        Pattern jiraPattern = Pattern.compile("([a-zA-Z]+)\\W*(\\d+)");
        Matcher matcher = jiraPattern.matcher(trimAllWhitespace(jira.replaceAll("-", ""))
                .toUpperCase());
        while (matcher.find()) {
            return matcher.group(1) + "-" + matcher.group(2);
        }
        return StringUtils.EMPTY;
    }

    public Set<Commit> getCommitHistory(Artifact currentArtifact, Artifact newArtifact)
            throws JSONException, IOException {
        return getCommitsSince(StringUtils.defaultIfBlank(currentArtifact.getRepository(),
                currentArtifact.getId()), currentArtifact.getId(),
                newArtifact != null ? newArtifact.getId() : "NA", currentArtifact.getVersion(),
                newArtifact != null ? newArtifact.getVersion() : null);
    }

    private Set<Commit> getCommitsSince(String repo, String currentId, String newId,
            String lastVersion, String latestVersion) throws JSONException, IOException {
        Pattern entryPattern = Pattern.compile(String.format(RELEASE_MESSAGE_PATTERN, currentId,
                latestVersion));
        Pattern exitPattern = Pattern.compile(String.format(RELEASE_MESSAGE_PATTERN, currentId,
                lastVersion));
        Set<Commit> latestCommits = new LinkedHashSet<>();

        Set<Commit> commits = new LinkedHashSet<>();

        for (int i = 1; i <= 3; i++) {
            commits.addAll(getCommits(repo, i));
        }
        boolean inRange = latestVersion == null ? true : false;
        for (Commit commit : commits) {
            if (inRange || entryPattern.matcher(commit.getMessage()).matches()) {
                latestCommits.add(commit);
                inRange = true;
            }
            Matcher matcher = exitPattern.matcher(commit.getMessage());
            if (matcher.matches()) {
                return latestCommits;
            }
        }

        if (lastVersion.equals("NEW")) {
            return latestCommits;
        }

        throw new RuntimeException(String.format("No release commit was found for %s-%s",
                currentId, lastVersion));
    }

    public static class Commit {

        private final String sha;

        private final String name;

        private String message;

        private final List<String> jiras;

        private final DateTime date;

        public Commit(String sha, String name, String message, Map<String, String> jiras,
                DateTime date) {
            this.sha = sha;
            this.name = name;
            this.message = message;

            for (Entry<String, String> jira : jiras.entrySet()) {
                this.message = this.message.replaceAll(jira.getKey(), jira.getValue());
            }

            this.jiras = new ArrayList<>(jiras.values());
            this.date = date;
        }

        public String getSha() {
            return sha;
        }

        public String getName() {
            return name;
        }

        public String getMessage() {
            return message;
        }

        public List<String> getJiras() {
            return jiras;
        }

        public DateTime getDate() {
            return date;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((message == null) ? 0 : message.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            Commit other = (Commit) obj;
            if (message == null) {
                if (other.message != null)
                    return false;
            } else if (!message.equals(other.message))
                return false;
            return true;
        }
    }
}
