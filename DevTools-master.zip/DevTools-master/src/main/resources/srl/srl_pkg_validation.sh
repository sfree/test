#!/bin/bash

if [[ $# -ne 2 ]]
then
		this="$(basename "$(test -L "$0" && readlink "$0" || echo "$0")")"
    echo "Error in $this - Invalid argument count"
    echo "Usage: $this PACKAGES_FILE DEPLOYMENT_TASK_ID"
    echo "Example: ./$this release_3.1.txt CTASK0001474666"
    exit 1
fi

HUFS_ROOT=/sbcimp/run/pkgs/

SRL_ROOT=$HUFS_ROOT/SRL/

XML_NAME=.SRL_configuration.xml

AUTH_CMD="$SRL_ROOT/AdminTools/prod/bin/store_zipped_credentials --usercli --overwrite"

SRL_COMMAND="$SRL_ROOT/prod/bin/srl_soapsvc_call --service auth validate_cmr"

eval "$AUTH_CMD"

cat $1 | tr -d "\r" | while read PACKAGE_NAME VERSION; do
  SIGNATURE=`awk -F"\"" '/signature/ {print $2}' $HUFS_ROOT/$PACKAGE_NAME/$VERSION/$XML_NAME`
  echo Validating $PACKAGE_NAME -- $VERSION -- $SIGNATURE
  checkVar=`$SRL_COMMAND $2 $PACKAGE_NAME Install $SIGNATURE FullCheck`
  echo $checkVar
done
