def HOST_NEXUS_REPO_URL = 'http://rkyctools.ldn.swissbank.com:8090/nexus/service/local/repo_groups'
def RELEASES_REPO_URI = 'g-internal-releases-and-snapshots/content'
String projectVersion = "0.0.1-SNAPSHOT"
String artifact = "ZkTestApp"
String group = "com.ubs.idp.training"
String groupPath = group.replaceAll("\\.", "/")

String repositoryURL = HOST_NEXUS_REPO_URL +'/'+ RELEASES_REPO_URI +'/' + groupPath + '/' + artifact + '/' + projectVersion

String metaXML = 
"<metadata modelVersion=\"1.1.0\">\n<groupId>com.ubs.idp.training</groupId>\n<artifactId>ZkTestApp</artifactId>\n<version>0.0.1-SNAPSHOT</version>\n<versioning>\n<snapshot>\n<timestamp>20140127.140430</timestamp>\n<buildNumber>2</buildNumber>\n</snapshot>"

log.info("########### Group path: ${groupPath} ###########")

if (projectVersion.contains("SNAPSHOT")) {
    log.info("########### Snapshot release detected! #############")
    log.info("########### Group:  ${group}")
    log.info("########### Artifact:  ${artifact}")
    log.info("########### projectVersion: ${projectVersion} #############")
            
    // Fetch meta-data xml
            
    def metaXMLFileURL = repositoryURL + '/maven-metadata.xml'
            
    log.info("########### metaXMLFileURL: ${metaXMLFileURL} ############")

    log.info("########### metaXML: ${metaXML} ############")

    def timestampMatcher = metaXML =~/timestamp>(.*)</
    def buildNumberMatcher = metaXML =~/buildNumber>(.*)</

    String timestamp = timestampMatcher[0][1]
    String buildNumber = buildNumberMatcher[0][1]

    log.info("########### timestamp: ${timestamp} ###########")
    log.info("########### buildNumber: ${buildNumber} ###########")
            
    String versionSuffix = projectVersion.replace("-SNAPSHOT", "-${timestamp}-${buildNumber}")
            
    String artifactFilename = artifact +'-'+ versionSuffix +'-jar-with-dependencies.jar'
            
    artifactURL = repositoryURL + '/' + artifactFilename
} else {
    String artifactFilename = artifact +'-'+ projectVersion +'-jar-with-dependencies.jar'
    
    artifactURL = repositoryURL + '/' + artifactFilename
}
    
log.info("########### Returning artifact URL of: ${artifactURL} ###########")

