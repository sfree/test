#!/bin/sh
#
# Author: mcminnp
# Description:
#   Pull out git history for a component as far back as a specified release.
#
#   Example:
#      githist.sh 1.0.8       
#
#   Note:
#      You should ensure you have a pull of the latest code!

if [ $# -ne 1 ]
then
    echo "Syntax error! Missing release version?"
    echo "Syntax:"
    echo "  $0 <release version>"
    exit 1
fi

relver=$1

formatResults() {
    awk -v relver=$relver '
    function addJira(jira) {
        found = "n";
        
        for (i = 1 ; i <= jiraCount ; i++) {
            if (jiras[i] == jira) {
                found = "y";
            }
        }
        
        if (found == "n") {
            jiraCount++;
            jiras[jiraCount] = jira;
        }
    }
    
    function getFirstJIRA(inputString) {
        jiraPat = "[Ii][Dd][Pp][a-z,A-Z]*[- ][0-9]";
        
        tmp = inputString;
        jiraOut = "-";
        
        jirastart = match(tmp, jiraPat);
        jira = substr(tmp, jirastart);

        # Look for first digit
        startOfJiraNum = match(substr(jira, 0), "[0-9]");
        
        if (jirastart > 0 && startOfJiraNum > 0) {
            jiraNum = substr(jira, startOfJiraNum);
            endOfJiraNum = match(jiraNum, "[-, ,\t,\,,$]") - 1;
            
            if (endOfJiraNum < 0) {
                endOfJiraNum = length(jiraNum);
            }
            
            jiraNum = substr(jiraNum, 0, endOfJiraNum);

            # Re-format prefix

            jiraPrefix = substr(jira, 0, startOfJiraNum-2);
            jiraNum = substr(jiraNum, 0, endOfJiraNum);

            jiraOut = sprintf("%s-%d", toupper(jiraPrefix), jiraNum);
        }
        
        return jiraOut;
    }
    
    function scanCommentForJIRAs(comment) {
        jiraPat = "[Ii][Dd][Pp][a-z,A-Z]*[- ][0-9]";

        tmp = sprintf("%s", comment);
        
        while(match(tmp, jiraPat) > 0) {
            jirastart = match(tmp, jiraPat);
            jira = getFirstJIRA(tmp);

            if (jira != "-") {
                # Add to list
                addJira(jira);
            }
            
            # Bump tmp
            
            tmp = substr(tmp, jirastart + length(jira));
        }
    }
    BEGIN {
        author = "";
        date = "";
        conflicts = "n";
        done = "n";
        pattern = sprintf(".*maven-release-plugin.*prepare.*-%s$", relver);
        
        # Spoof declaration
        split("", jiras);
        jiraCount = 0;
        
        # Header
        printf("%33s   %15s %12s   %s\n", "Date", "Author", "JIRA#", "Comment");
        printf("%33s   %15s %12s   %s\n", "====", "======", "=====", "=======");
    }
    {
        if ($1 == "Author:") {
            author = $2;
        } else if ($1 == "Date:") {
            date = substr($0, 7);
        } else if (conflicts == "n" && done == "n") {
            jira = getFirstJIRA($0);
            
            if (jira != "-") {
                addJira(jira);
            }
            
            comment = $0;

            sub(/^[ \t]*/, "", comment);
            
            # Check for other JIRAs in comment
            
            scanCommentForJIRAs(comment);
            
            printf("%33s : %15s %12s   %s\n", date, author, jira, comment);
        }
        
        # Check for target release version and stop output
        
        if (match($0, pattern) > 0 && done == "n") {
            printf("All done for %s\n", relver);
            done = "y";
        }
    }
    END {
        # Dump JIRA list
        printf("\nJIRA Summary:\n");
        
        maxValue = "ZZZ-999999";
        
        # This could be optimized but the list should be pretty small!
        
        for (i = 1 ; i <= jiraCount ; i++) {
            minJira = maxValue;
            minJiraIdx = -1;
            
            for (j = 1 ; j <= jiraCount ; j++) {
                if (jiras[j] < minJira) {
                    minJira = jiras[j];
                    minJiraIdx = j;
                }
            }
            jiras[minJiraIdx] = maxValue;
            
            if (minJira != "ZZZ-999999") {
                printf("\t%s\n", minJira);
            }
        }
    }'
}

getLog() {
    git log | egrep -v "^commit|^Merge|^$|Signed-off-by:|^[ \t]*$|Merge pull request|http.*\.ldn\.swissbank\.com|Merge branch.*git@github.ldn.swissbank.com"
}

getLog | formatResults
