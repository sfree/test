package com.ubs.swift.deployment.api;

import java.util.List;

import com.ubs.swift.deployment.model.DeploymentAction;

public interface DeploymentProcessor {
    /**
     * Executes a deployment against a set of specified artifact instances.
     * <p>
     * This cannot be used for production deployments.
     * 
     * @param deploymentAction
     * @param ids
     * @return
     */
    String executeDeployment(DeploymentAction deploymentAction, List<String> ids);

    /**
     * Deploys the artifacts in an existing release to the specified environment.
     * 
     * @param releaseId
     * @param environment
     * @return the id of the executed deployment
     */
    String executeDeployment(Integer releaseId, String environment);
}
