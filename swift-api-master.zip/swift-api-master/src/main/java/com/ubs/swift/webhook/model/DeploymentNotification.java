package com.ubs.swift.webhook.model;

import java.sql.Timestamp;
import java.util.List;

import com.google.common.base.Objects;

public class DeploymentNotification {

    public static final String DEPLOYMENT_TYPE_RELEASE = "Release";
    public static final String DEPLOYMENT_TYPE_ROLLBACK = "Rollback";

    public static final String EVENT_TYPE = "Deployment";

    // Related to Deployment
    private Integer objectId;
    private String planId;
    private String status;
    private String deploymentType;
    private Timestamp deployTime;
    private String user;
    private List<String> environments;
    private String eventType = DeploymentNotification.EVENT_TYPE;

    // Related to Release
    private final ReleaseDataGroup release = new ReleaseDataGroup();

    public String getEventType() {
        return eventType;
    }

    public void setEventType(final String eventType) {
        this.eventType = eventType;

    }

    public Integer getObjectId() {
        return objectId;
    }

    public void setObjectId(final Integer objectId) {
        this.objectId = objectId;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(final String planId) {
        this.planId = planId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public String getDeploymentType() {
        return deploymentType;
    }

    public void setDeploymentType(final String deploymentType) {
        this.deploymentType = deploymentType;
    }

    public Timestamp getDeployTime() {
        return deployTime;
    }

    public void setDeployTime(final Timestamp deployTime) {
        this.deployTime = deployTime;
    }

    public String getUser() {
        return user;
    }

    public void setUser(final String user) {
        this.user = user;
    }

    public List<String> getEnvironments() {
        return environments;
    }

    public void setEnvironments(final List<String> environments) {
        this.environments = environments;
    }

    public ReleaseDataGroup getRelease() {
        return release;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(planId, status, deploymentType, deployTime, release);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof DeploymentNotification) {
            DeploymentNotification that = (DeploymentNotification) object;
            return Objects.equal(this.planId, that.planId)
                    && Objects.equal(this.status, that.status)
                    && Objects.equal(this.deploymentType, that.deploymentType)
                    && Objects.equal(this.deployTime, that.deployTime)
                    && Objects.equal(this.user, that.user)
                    && Objects.equal(this.environments, that.environments)
                    && Objects.equal(this.release, that.release);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("planId", planId)
                .add("status", status)
                .add("deploymentType", deploymentType)
                .add("deployTime", deployTime)
                .add("user", user)
                .add("environments", environments)
                .add("release", release)
                .toString();
    }

}
