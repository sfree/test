package com.ubs.swift.webhook.model;

import java.util.List;

import com.google.common.base.Objects;

public class ReleaseDataGroup {

    private String name;
    private String description;
    private String organisation;
    private String team;
    private String createdBy;
    private String lastUpdatedBy;
    private List<String> watchingUsers;

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public String getOrganisation() {
        return organisation;
    }

    public void setOrganisation(final String organisation) {
        this.organisation = organisation;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(final String team) {
        this.team = team;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(final String createdBy) {
        this.createdBy = createdBy;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(final String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public List<String> getWatchingUsers() {
        return watchingUsers;
    }

    public void setWatchingUsers(final List<String> watchingUsers) {
        this.watchingUsers = watchingUsers;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, description, organisation, team, createdBy, lastUpdatedBy);
    }

    @Override
    public boolean equals(final Object object) {
        if (object instanceof ReleaseDataGroup) {
            ReleaseDataGroup that = (ReleaseDataGroup) object;
            return Objects.equal(this.name, that.name)
                    && Objects.equal(this.description, that.description)
                    && Objects.equal(this.organisation, that.organisation)
                    && Objects.equal(this.team, that.team)
                    && Objects.equal(this.createdBy, that.createdBy)
                    && Objects.equal(this.lastUpdatedBy, that.lastUpdatedBy)
                    && Objects.equal(this.watchingUsers, that.watchingUsers);
        }
        return false;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("name", name)
                .add("description", description)
                .add("organisation", organisation)
                .add("team", team)
                .add("createdBy", createdBy)
                .add("lastUpdatedBy", lastUpdatedBy)
                .add("watchingUsers", watchingUsers)
                .toString();
    }

}
