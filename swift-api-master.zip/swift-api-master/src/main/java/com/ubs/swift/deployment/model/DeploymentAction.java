package com.ubs.swift.deployment.model;

public enum DeploymentAction {
    Stop,
    Start, // start from any state
    StartOnly, // start only from a stopped state.
    Bounce,
    Redeploy,
    Undeploy;
}