swift-api
=========
This module contains the APIs available for use by clients of swift.  This could be swift-client or other services.

These APIs are provided to prevent external (JAVA) clients from having to recreate the model objects from scratch.  
This ensures consistency between swift-server and clients.

See http://confluence.swissbank.com/display/neo/Using+Swift+Rest+APIs
