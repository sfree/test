# IDP environment

contains environment scripts used by Swift and SRL.  Also contains properties until migrated to Zookeeper
