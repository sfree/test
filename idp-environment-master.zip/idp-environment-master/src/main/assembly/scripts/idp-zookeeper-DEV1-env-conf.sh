#!/bin/bash

export IDP_DATA_DIR=/sbclocal/apps/dyn/data/IDP
export IDP_LOG_DIR=/sbclocal/apps/dyn/logfiles/IDP

# Zk Specific config
export IDP_ZOOKEEPER_BIND_ADDRESS=0.0.0.0
#export IDP_ZOOKEEPER_BIND_ADDRESS=127.0.0.1

# Lock down Zookeeper
export IDP_ZOOKEEPER_ACLS=/xd=digest:foo:VNy+Z9IdXrOUk9Rtia4fQS071t4=:rwdca,/xd=ip:whitelist:rwdca
export IDP_ZOOKEEPER_ACL_ACTION=create

export IDP_ZOOKEEPER_CLUSTER_NAME=STANDALONE
export IDP_ZOOKEEPER_SERVER_HOST_1=xstm5348vdap.stm.swissbank.com
export IDP_ZOOKEEPER_SERVER_CLIENT_PORT_1=2080
export IDP_ZOOKEEPER_SERVER_QUORUM_PORTS_1=2180:2280

# Micromuse / netcool config
export NETCOOL_PRIMARY_HOST=stmsktdev1.stm.swissbank.com
export NETCOOL_BACKUP_HOST=stmsktdev1.stm.swissbank.com
export NETCOOL_CLASSID=249744
export NETCOOL_SAPNAME="INTEGRATED DATA PLATFORM"
export NETCOOL_SAPNUMBER=0
export NETCOOL_STREAM=DATAIT
export NETCOOL_LOCATION=Stamford
export NETCOOL_DEBUGMODE=false
export NETCOOL_THRESHOLD=ERROR
export NETCOOL_ENVIRONMENT=DEV1
