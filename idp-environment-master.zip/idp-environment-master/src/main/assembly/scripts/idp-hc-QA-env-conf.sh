#!/bin/bash

export IDP_DATA_DIR=/sbclocal/apps/dyn/data/IDP
export IDP_LOG_DIR=/sbclocal/apps/dyn/logfiles/IDP

export ENVIRONMENT=QA
export IDP_HC_CASSANDRA_PRIMARY_PROBE_HOST=xstm5357vdap.stm.swissbank.com
export IDP_HC_EXPECTED_STATE_XML=/home/idp_dev/${ENVIRONMENT}-properties/expectedState-QA.xml

export PROPS_DIR=/home/idp_dev/${ENVIRONMENT}-properties
export IDP_HC_CASSANDRA_PRIMARY_PROBE_PORT=7199
export IDP_HC_CASSANDRA_JMX_IS_SECURED=true
export IDP_HC_CASSANDRA_JMX_USERNAME=controlRole
export IDP_HC_CASSANDRA_JMX_PASSWORD=5d492046d002b3a16c8c9851fb214473
export IDP_HC_RCAS_URL=https://rcas.smlogin.ibb.ubstest.net/loginrouter/rcas_v1_50
export IDP_HC_RCAS_APP_GUID=RCAS_IDP
export IDP_HC_RCAS_USERNAME=sso_idp
export IDP_HC_RCAS_PASSWORD=1b1a50dc5ac97cbd9c79c8b93ec5ceac
export IDP_HC_WEB_REQUEST_TIME=7000
export IDP_HC_SOCKET_IS_LISTENING=false
export IDP_HC_SOCKET_PORT=5050
export IDP_HC_SOCKET_REQ_MSG="Are you alive?"
export IDP_HC_SOCKET_RESP_MSG="Yes, I'm alive"
export IDP_HC_SOCKET_UNEXP_REQ_MSG="Unexpected request message"
export IDP_HC_TPOS_MAIL_TO=DL-IDP-DEV@ubs.com
export IDP_HC_TPOS_MAIL_FROM=DL-IDP-DEV@ubs.com
export JAVA_HOME=/sbcimp/run/tp/sun/jre/v1.7.0_21-64bit
export PATH="$JAVA_HOME/bin:$PATH"

# Netcool config
export NETCOOL_PRIMARY_HOST=stmsktdev1.stm.swissbank.com
export NETCOOL_ALTERNATE_HOST=stmsktdev1.stm.swissbank.com
export NETCOOL_CLASSID=249744
export NETCOOL_SAPNAME="INTEGRATED DATA PLATFORM"
export NETCOOL_SAPNUMBER=0
export NETCOOL_STREAM=DATAIT
export NETCOOL_LOCATION=Stamford
export NETCOOL_DEBUGMODE=false
export NETCOOL_THRESHOLD=ERROR
export NETCOOL_ENVIRONMENT=QA
