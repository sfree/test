export ENVIRONMENT=CI

export XD_PROPS_DIR=/home/idp_dev/${ENVIRONMENT}-properties

#!/bin/bash
export IDP_DATA_DIR=/sbclocal/apps/dyn/data/IDP
export IDP_LOG_DIR=/sbclocal/apps/dyn/logfiles/IDP
# XD bind address
export XD_BIND_ADDR=0.0.0.0

export XD_ZOOKEEPER_SERVERS=localhost:2080,localhost:2081,localhost:2082

# Micromuse / netcool config
export NETCOOL_PRIMARY_HOST=stmsktdev1.stm.swissbank.com
export NETCOOL_BACKUP_HOST=stmsktdev1.stm.swissbank.com
export NETCOOL_CLASSID=249744
export NETCOOL_SAPNAME="INTEGRATED DATA PLATFORM"
export NETCOOL_SAPNUMBER=0
export NETCOOL_STREAM=DATAIT
export NETCOOL_LOCATION=Stamford
export NETCOOL_DEBUGMODE=false
export NETCOOL_THRESHOLD=ERROR
export NETCOOL_ENVIRONMENT=CI

# Duplicate of the values in the env-conf.sh file but required as Redis is non-java
# and these are used to configure the static config file
export SPRING_REDIS_PORT=6379
export SPRING_REDIS_HOST=0.0.0.0
export SPRING_REDIS_PASSWORD=e6d389950892d9cded481f95c6f1e7be
