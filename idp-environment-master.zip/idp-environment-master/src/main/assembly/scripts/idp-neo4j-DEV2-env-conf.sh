#!/bin/bash
export ENVIRONMENT=DEV2
export PROPS_DIR=/home/idp_dev/${ENVIRONMENT}-properties

export IDP_DATA_DIR=/sbclocal/apps/dyn/data/IDP
export IDP_LOG_DIR=/sbclocal/apps/dyn/logfiles/IDP
export IDP_ALLOW_LIST=.*
