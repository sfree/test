export ENVIRONMENT=QA

export DAS_PROPS_DIR=/home/idp_dev/${ENVIRONMENT}-properties

export IDP_SECRET_WORD=secret
export IDP_LOG_DIR=/sbclocal/apps/dyn/logfiles/IDP
export IDP_DATA_DIR=/sbclocal/apps/dyn/data/IDP
export IDP_DAS_PORT=9990
export IDP_DAS_INTERNAL_PORT=9989
export IDP_CURRENT_UNIX_USER=`whoami`
export IDP_CHAT_CHANNEL="IDP-SUPPORT"
export APACHE_HOME="/sbcimp/run/pd/apache/2.2.20"
export SM_APP_NAME="filegen"
export SM_ENV="manuat"
export SM_REGION="amer"
export JETTY_BIND_HOST=127.0.0.1
export DAS_REQUEST_LOG_RETAIN_DAYS=3
export DAS_REQUEST_LOG_TIMEZONE=GMT
export DAS_MIN_THREADS=10
export DAS_MAX_THREADS=100

# start
export JAVA_HOME=/sbcimp/run/tp/sun/jre/v1.7.0_21-64bit
export PATH=$JAVA_HOME/bin:/sbclocal/apps/run/tp/CA/SiteMinder/WebAgent/6.0.5.25/bin:$PATH
export LD_LIBRARY_PATH=/sbclocal/apps/run/tp/CA/SiteMinder/WebAgent/6.0.5.25/bin:${LD_LIBRARY_PATH}
export APACHECTL="/sbcimp/run/pd/apache/2.2.20/bin/apachectl"
export JETTYPROXY="y"
