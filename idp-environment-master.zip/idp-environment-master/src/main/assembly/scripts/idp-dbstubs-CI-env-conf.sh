#!/bin/bash
export ENVIRONMENT=CI
export HOSTNAME="`hostname -s`"

export IDP_DATA_DIR=/sbclocal/apps/dyn/data/IDP
export XD_HOME=${IDP_DATA_DIR}/idp-spring-xd/${HOSTNAME}/data/xd
