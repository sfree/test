package com.ubs.idp.environment;

import static org.hamcrest.Matchers.isIn;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.hamcrest.Matchers;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ErrorCollector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertiesValidationTest {

    private static final Logger LOG = LoggerFactory.getLogger(PropertiesValidationTest.class);

    private static Map<String, Environment> environments;

    @Rule
    public ErrorCollector collector = new ErrorCollector();

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        environments = new LinkedHashMap<>();
        Path p = Paths.get("src/main/assembly/properties");
        Files.walkFileTree(p, new SimpleFileVisitor<Path>() {

            private final Pattern envPattern = Pattern.compile("environment-(\\w{1,5}\\d?)[\\.-]");

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                    throws IOException {
                Matcher matcher = envPattern.matcher(file.toString());
                while (matcher.find()) {
                    String envId = matcher.group(1);
                    Environment env = environments.get(envId);
                    if (env == null) {
                        env = new Environment(envId);
                        environments.put(envId, env);
                    }

                    Properties props = new Properties();
                    props.load(Files.newBufferedReader(file, StandardCharsets.UTF_8));
                    if (file.toString().contains("primary")) {
                        env.setPrimary(props);
                        return FileVisitResult.CONTINUE;
                    }
                    if (file.toString().contains("secondary")) {
                        env.setSecondary(props);
                        return FileVisitResult.CONTINUE;
                    }
                    env.setPrimary(props);
                }
                return super.visitFile(file, attrs);
            }
        });
    }

    @Test
    public void noDuplicateKeys() throws IOException {
        Path p = Paths.get("src/main/assembly/properties");
        Files.walkFileTree(p, new SimpleFileVisitor<Path>() {

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                    throws IOException {
                if (!file.toString().endsWith(".properties")) {
                    return FileVisitResult.CONTINUE;
                }
                List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
                Set<String> uniqueKeys = new HashSet<String>();
                for (String line : lines) {
                    if (!line.startsWith("#") && line.trim().length() > 0) {
                        String key = line.substring(0, line.indexOf("="));
                        collector.checkThat(String.format("Key [%s] is a duplicate in %s", key,
                                file.toFile().getName()), key, not(isIn(uniqueKeys)));
                        uniqueKeys.add(key);
                    }
                }

                return super.visitFile(file, attrs);
            }
        });
    }

    @Test
    public void noPendingMerges() throws IOException {
        Path p = Paths.get("src/main/assembly/properties");
        Files.walkFileTree(p, new SimpleFileVisitor<Path>() {

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                    throws IOException {
                List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
                for (String line : lines) {
                    collector.checkThat(line, not(Matchers.startsWith("<<<<<")));
                    collector.checkThat(line, not(Matchers.startsWith("=====")));
                    collector.checkThat(line, not(Matchers.startsWith(">>>>>")));
                }

                return super.visitFile(file, attrs);
            }
        });
    }

    @Test
    public void propertiesCannotBeEmpty() {
        for (Entry<String, Environment> entry : environments.entrySet()) {
            Environment env = entry.getValue();
            assertTrue(String.format("Environment %s" + (env.hasSecondary() ? "-primary" : "")
                    + " should have more than 0 properties", entry.getKey()), env.getPrimary()
                    .size() > 0);
            if (env.hasSecondary()) {
                assertTrue(String.format(
                        "Environment %s-secondary should have more than 0 properties",
                        entry.getKey()), env.getSecondary().size() > 0);
            }
        }
    }

    @Test
    public void amountPrimaryVsSecondary() {
        for (Entry<String, Environment> entry : environments.entrySet()) {
            Environment env = entry.getValue();

            LOG.info("Environment {}" + (env.hasSecondary() ? "-primary" : "")
                    + " has {} unique properties", entry.getKey(), env.getPrimary().size());

            if (env.hasSecondary()) {
                LOG.info("Environment {}-secondary has {} unique properties", entry.getKey(), env
                        .getSecondary().size());
                assertEquals(String.format(
                        "Primary and secondary for %s should have the same amount of properties",
                        env), env.getPrimary().size(), env.getSecondary().size());
            }
        }
    }

    @Test
    public void envCIvsUAT1() {
        Environment ci = environments.get("CI");
        Environment uat1 = environments.get("UAT1");
        String differences = getDifferences(ci, uat1);
        if (differences.length() > 0) {
            LOG.info(differences);
        }
        // assertEquals("", differences);
    }

    @Test
    public void envUAT1vsPRD() {
        Environment uat1 = environments.get("UAT1");
        Environment prd = environments.get("PRD");
        String differences = getDifferences(uat1, prd);
        if (differences.length() > 0) {
            LOG.info(differences);
        }
        // assertEquals("", differences);
    }

    @Test
    public void envCIvsPRD() {
        Environment ci = environments.get("CI");
        Environment prd = environments.get("PRD");
        String differences = getDifferences(ci, prd);
        if (differences.length() > 0) {
            LOG.info(differences);
        }
        // assertEquals("", differences);
    }

    @Test
    @Ignore
    public void allDEVShouldBeTheSame() {
        String differences = getDifferencesForAll("DEV");
        assertEquals("", differences);
    }

    @Test
    public void allUATShouldBeTheSame() {
        String differences = getDifferencesForAll("UAT");
        assertEquals("", differences);
    }

    private String getDifferencesForAll(String envPrefix) {
        StringBuilder sb = new StringBuilder();
        Environment p = null;
        for (Entry<String, Environment> entry : environments.entrySet()) {
            if (entry.getKey().startsWith(envPrefix)) {
                if (p != null) {
                    sb.append(getDifferences(p, entry.getValue()));
                }
                p = entry.getValue();
            }
        }
        return sb.toString();
    }

    private String getDifferences(Environment e1, Environment e2) {
        List<Object> surplus = new ArrayList<Object>();

        Properties p1 = (Properties) e1.getPrimary().clone();
        Properties p2 = (Properties) e2.getPrimary().clone();

        for (Object key : p1.keySet()) {
            if (p2.remove(key) == null) {
                surplus.add(key.toString());
            }
        }

        StringBuilder sb = new StringBuilder();
        if (surplus.size() > 0) {
            String msg = String.format("Available in %s but not in %s", e1.getEnvId(),
                    e2.getEnvId());
            sb.append(msg);
            sb.append(String.format("%n%" + msg.length() + "s", "-").replaceAll(" ", "-"));
            for (Object key : surplus) {
                sb.append(String.format("%n%s", key.toString()));
            }
        }

        if (p2.size() > 0) {
            String msg = String.format("Available in %s but not in %s", e2.getEnvId(),
                    e1.getEnvId());
            sb.append(msg);
            sb.append(String.format("%n%" + msg.length() + "s", "-").replaceAll(" ", "-"));
            for (Object key : p2.keySet()) {
                sb.append(String.format("%n%s", key.toString()));
            }
        }

        return sb.toString();
    }

    static class Environment {

        private String envId;

        private Properties primary;

        private Properties secondary;

        public Environment(String envId) {
            this.envId = envId;
        }

        public String getEnvId() {
            return envId;
        }

        public Properties getPrimary() {
            return primary;
        }

        public void setPrimary(Properties primary) {
            this.primary = primary;
        }

        public Properties getSecondary() {
            return secondary;
        }

        public void setSecondary(Properties secondary) {
            this.secondary = secondary;
        }

        public boolean hasSecondary() {
            return secondary != null;
        }
    }

}
